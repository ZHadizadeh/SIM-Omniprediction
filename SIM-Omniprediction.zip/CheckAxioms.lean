import UL
import Lean.Util.CollectAxioms

/-! Axiom dependencies of the paper’s results. The final check traverses every
declaration in the arXiv namespace, including its subnamespaces. -/

#print axioms UL.Arxiv.thm_1_1a
#print axioms UL.Arxiv.thm_1_1b
#print axioms UL.Arxiv.bounded_action_positive_excess
#print axioms UL.Arxiv.thm_1_1c
#print axioms UL.Arxiv.thm_1_2_existence
#print axioms UL.Arxiv.thm_1_3
#print axioms UL.Arxiv.thm_1_4_learning
#print axioms UL.Arxiv.prop_1_5_unit_sphere
#print axioms UL.Arxiv.thm_1_6_dictionary
#print axioms UL.Arxiv.prop_1_7
#print axioms UL.Arxiv.lem_B_1
#print axioms UL.Arxiv.lem_B_2
#print axioms UL.Arxiv.lem_B_3
#print axioms UL.Arxiv.lem_B_4
#print axioms UL.Arxiv.lem_B_5
#print axioms UL.Arxiv.lem_B_6
#print axioms UL.Arxiv.cor_B_7
#print axioms UL.Arxiv.thm_B_8
#print axioms UL.Arxiv.thm_C_1_joint_link
#print axioms UL.Arxiv.lem_D_1
#print axioms UL.Arxiv.lem_D_2
#print axioms UL.Arxiv.lem_D_3
#print axioms UL.Arxiv.cor_D_4
#print axioms UL.Arxiv.cor_D_5

#print axioms UL.Arxiv.factorThroughActualRank
#print axioms UL.Arxiv.exactFiniteActions
#print axioms UL.Arxiv.Tradeoff.arbitraryMeasurableLower
#print axioms UL.Arxiv.finiteGridMinimizer
#print axioms UL.Arxiv.thm_1_4_joint_prediction
#print axioms UL.Arxiv.measurableDictionaryFit
#print axioms UL.Arxiv.barycentricGradientGram
#print axioms UL.Arxiv.logSmoothingRisk
#print axioms UL.Arxiv.centeredLogitNorm

#print axioms UL.Arxiv.BinarySmoothing.binary_finite_action_refinement
#print axioms UL.Arxiv.Logistic.sample_lower_bound
#print axioms UL.Arxiv.FiniteLearner.run_spec
#print axioms UL.Arxiv.UnroundedSearch.bounded_joint
#print axioms UL.Arxiv.UnroundedSearch.representation
#print axioms UL.Arxiv.thm_1_4_finite_search
#print axioms UL.Arxiv.cor_B_7_scalar_smoothing
#print axioms UL.Arxiv.appendix_D_logistic_sample_lower_bound
#print axioms UL.Arxiv.HilbertSearch.population
#print axioms UL.Arxiv.FiniteLearner.candidate_count
#print axioms UL.Arxiv.ScoreStability.certificate_modulus

#print axioms UL.Arxiv.Notation.scoreMoment_eq
#print axioms UL.Arxiv.Notation.residual_eq_centered
#print axioms UL.Arxiv.Notation.shiftedSimplex_eq
#print axioms UL.Arxiv.Notation.dictionarySimplex_eq

open Lean in
run_cmd
  let env ← getEnv
  let names := env.constants.fold (init := #[]) fun acc n _ =>
    if (`UL.Arxiv).isPrefixOf n then acc.push n else acc
  if names.isEmpty then throwError "No arXiv declarations found"
  let (_, state) := ((names.forM CollectAxioms.collect).run env).run {}
  for a in state.axioms do
    unless #[`propext, `Classical.choice, `Quot.sound].contains a do
      throwError "Unexpected axiom in the arXiv declarations: {a}"
  logInfo m!"Checked {names.size} arXiv declarations. Axioms used: {state.axioms}."

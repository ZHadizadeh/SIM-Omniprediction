# Omniprediction with the Minimum Number of Linear Scores

This repository formalizes results on omniprediction with linear scores in Lean 4. For the global matching losses studied in the paper, the exact worst-case number of linear scores is $\min\{d,K-1\}$ for $K$ classes and $d$ features.

[Theorem index (Lean)](UL/Arxiv.lean) · [Offline theorem explorer (HTML)](explorer/index.html)

## Main results

| Result | Lean source | Scope |
| --- | --- | --- |
| **Theorem 1.1(a)** · Binary existence, global actions | [Statement and proof](UL/Arxiv/Theorem_1_1a.lean) | Binary labels, a finite first feature moment and global actions. For any nonempty compact convex weight set, the forecast obeys the prescribed slope bound and competes with every weight in that same set. |
| **Theorem 1.1(b)** · Binary existence, bounded actions | [Statement](UL/Arxiv/BoundedBinary.lean) · [Proof](UL/Arxiv/Theorem_1_1b.lean) | With bounded features and actions, one monotone Borel forecast competes exactly for a uniformly compact family of continuous nondecreasing targets. Labels may take any value in [0,1]. |
| **Theorem 1.2** · Multiclass existence | [Statement](UL/Stmt/thm_3_1.lean) · [Proof](UL/Proof/thm_3_1.lean) | A finite first feature moment, global actions, strongly convex face-differentiable entropies and compact convex coefficient sets. The [rank factorization](UL/Arxiv/ScoreFactorization.lean) preserves the forecast, both matrix norms and the link slope, including rank zero. For entropies with a full simplex gradient, the [finite-action comparison](UL/Arxiv/FiniteActions.lean) holds on the same forecast with zero excess. |
| **Theorem 1.3** · Joint score–slope tradeoff | [Statement and proof](UL/Arxiv/Tradeoff/AllDimensions.lean) | For every d ≥ 1 and K ≥ 2, the same quadratic instance attains the exact regret for each allowed rank and link slope. The [measurable-link rank bound](UL/Arxiv/Tradeoff/Measurable.lean) applies on the same distribution. |
| **Theorem 1.4** · Learning with bounded features | [Statement](UL/Stmt/thm_5_1.lean) · [Proof](UL/Proof/thm_5_1.lean) | For bounded i.i.d. features and smooth entropies with bounded gradients, the Lean theorem gives the dimension-free sample bound and a measurable learner with finite output range. The [joint prediction rule](UL/Arxiv/JointPrediction.lean) is Borel in sample and query. The [finite probability grid](UL/Arxiv/FiniteFit.lean) proves feasibility and approximation at fixed scores. The [finite score search and population guarantee](UL/Arxiv/HilbertScoreSearch.lean) use the original sample. |
| **Proposition 1.5** · Spherical sample lower bound | [Statement](UL/Stmt/prop_C_5.lean) · [Proof](UL/Proof/prop_C_5.lean) | Quadratic loss and randomized learners. The [unit-sphere statement](UL/Arxiv/SphericalLower.lean) fixes all five parameters to one and gives the dimension used in the paper. |
| **Theorem 1.6** · Learning on Dirichlet dictionaries | [Statement](UL/Stmt/thm_7_1.lean) · [Proof](UL/Proof/thm_7_1.lean) | Bounded Dirichlet dictionaries, smooth entropies and arbitrary conditional labels. The learner uses the [measurable minimum-norm fit](UL/Arxiv/DictionarySelection.lean) on each sample. A [geometric identity](UL/Arxiv/DictionaryGeometry.lean) identifies the pseudoinverse entries with inner products of the intrinsic barycentric gradients. The same file gives the nonobtuse-angle criterion and the four-corner obstruction for a product dictionary. The centered link is a convex gradient. |
| **Proposition 1.7** · One-hot dictionary sample lower bound | [Statement and proof](UL/Arxiv/Proposition_1_7.lean) | On a uniform one-hot Dirichlet dictionary, even randomized learners face a quadratic sample lower bound for a single quadratic entropy. |

## Appendix A · Bounded binary actions

In Theorem 1.1(b), both the decision maker and each linear comparator act in the prescribed interval [−LR, LR]. One nondecreasing probability link serves every target and every choice of optimal action at ties. Its slope is unrestricted. The benchmark is the infimum of expected loss over linear actions with weight norm at most R.

The proof reuses the binary least-squares fit. A sequence of losses and competitors that violate the exact comparison would have vanishing Bayes gaps at those fits. Compactness yields a limiting score, and the residual inequalities give the exact comparison at its limiting forecast. The Lean proof takes a convergent subsequence of competitors. Appendix A.2 gives the compactness argument in terms of joint laws. [Statement](UL/Arxiv/BoundedBinary.lean) · [Proof](UL/Arxiv/Theorem_1_1b.lean)

## Appendix B

| Result | Lean source | Scope |
| --- | --- | --- |
| **Lemma B.1** · Boundary loss and properness | [Statement](UL/Stmt/lem_A_1.lean) · [Proof](UL/Proof/lem_A_1.lean) | Canonical losses on simplex faces and realization by limits of finite actions. |
| **Lemma B.2** · Least-squares fit and continuity | [Statement](UL/Stmt/lem_A_2.lean) · [Proof](UL/Proof/lem_A_2.lean) | Existence and almost-sure uniqueness of the fit, with continuity as the score matrix varies. |
| **Lemma B.3** · Residuals on a simplex face | [Statement](UL/Stmt/lem_A_3.lean) · [Proof](UL/Proof/lem_A_3.lean) | Support of observed labels and differentiation of projected perturbations. |
| **Lemma B.4** · Convex tests and own-score inequality | [Statement](UL/Stmt/lem_A_4.lean) · [Proof](UL/Proof/lem_A_4.lean) | Mean residual and the two tests at a fixed fit. |
| **Lemma B.5** · Facewise convex tests | [Statement](UL/Stmt/lem_A_5.lean) · [Proof](UL/Proof/lem_A_5.lean) | Extends smooth tests to face derivatives. |
| **Lemma B.6** · Simultaneous risk certificate | [Statement](UL/Stmt/lem_A_6.lean) · [Proof](UL/Proof/lem_A_6.lean) | Controls all matching losses using the residual gap. |
| **Corollary B.7** · Finite-action postprocessing | [Statement](UL/Stmt/cor_A_8.lean) · [Proof](UL/Proof/cor_A_8.lean) | Moving probabilities toward the uniform report gives bounded actions at positive tolerance. For log loss the [smoothing estimates](UL/Arxiv/LogSmoothing.lean) give the sharper population risk and centered-logit norm bounds. The [binary refinement](UL/Arxiv/BinarySmoothing.lean) gives the scalar δ/(16β) term. |
| **Theorem B.8** · Exact score–slope tradeoff | [Statement and proof](UL/Arxiv/Tradeoff/AllDimensions.lean) | The feature law is uniform on a ball in a subspace of dimension min(d, K − 1). An affine forecast on the closed ball attains the lower bound, including at rank zero. |

## Appendix C

| Result | Lean source | Scope |
| --- | --- | --- |
| **Theorem C.1** · Joint probability links are necessary | [Statement](UL/Stmt/thm_E_1.lean) · [Proof](UL/Proof/thm_E_1.lean) | For K ≥ 3, restricting even one class probability to one scalar score can force positive regret. |

## Appendix D

| Result | Lean source | Scope |
| --- | --- | --- |
| **Lemma D.1** · Empirical simultaneous comparison | [Statement](UL/Stmt/lem_C_2.lean) · [Proof](UL/Proof/lem_C_2.lean) | Empirical risk certificate and a zero-gap score matrix on the sample span. |
| **Lemma D.2** · Uniform bound for loss profiles | [Statement](UL/Stmt/lem_C_3.lean) · [Proof](UL/Proof/lem_C_3.lean) | Uniform convergence with dependence on the score dimension. |
| **Lemma D.3** · Simplex-valued Lipschitz extension | [Statement](UL/Stmt/lem_C_4.lean) · [Proof](UL/Proof/lem_C_4.lean) | A quadratic program extends the fitted probabilities with the same slope. The extension and its approximation bound include zero-dimensional score spaces. |
| **Corollary D.4** · Monotone single-index learner | [Statement](UL/Stmt/cor_C_6.lean) · [Proof](UL/Proof/cor_C_6.lean) | The bounded-slope monotone learner has a jointly Borel prediction rule. Its proof uses [countable coding of training features](UL/Arxiv/BinarySampleRounding.lean). |
| **Corollary D.5** · Learning smooth and logarithmic losses together | [Statement](UL/Stmt/cor_C_7.lean) · [Proof](UL/Proof/cor_C_7.lean) | A single smoothed forecast for both families. |

## Manuscript notation

The [Lean notation file](UL/Arxiv/Notation.lean) proves the identities relating the centered simplex, the two expressions for the residual, and the population score moment.

| Paper | Lean | Meaning |
| --- | --- | --- |
| d⋆, r | [`dStar, r`](UL/Arxiv/Tradeoff/AllDimensions.lean) | The maximum score rank is d⋆ = min{d, K − 1}. The permitted rank is r. |
| e_Y, Z | [`oneHotLabel`](UL/Def/def_A_fit.lean) · [`centeredLabel`](UL/Proof/thm_7_1/H0_Defs.lean) | The one-hot label is e_Y. Subtracting the uniform probability u gives Z = e_Y − u. |
| 𝒞, P_W, P̃_W | [`centeredSimplex`](UL/Arxiv/Notation.lean) · [`linearFittedPrediction`](UL/Def/def_A_fit.lean) · [`pTilde`](UL/Stmt/lem_C_2.lean) | The probability-valued fit P_W lies in Δ_K. Its centered value P̃_W = P_W − u lies in 𝒞 = Δ_K − u. |
| ξ, b | [`fitResidual`](UL/Def/def_A_fit.lean) · [`fitRes`](UL/Proof/thm_3_2/H0_Defs.lean) | In the multiclass proof ξ = P − e_Y = (P − u) − Z and b = 𝔼⟨ξ, P − u⟩. In the binary proof ξ = P − Y and b = 𝔼[ξP]. |
| g(W), gₙ(W), Γ(W) | [`scoreMoment`](UL/Arxiv/Notation.lean) · [`gₙ`](UL/Stmt/lem_C_2.lean) · [`certificateGap`](UL/Def/def_A_gap.lean) | The population matrix is g(W) = 𝔼[(P_W − e_Y)Xᵀ]. The fixed-point map projects W − g(W). The sample matrix uses P̃_W − Z. |
| ℰ(β, λ, M), A, D | [`SmoothEntropyFamily`](UL/Def/def_5_smooth.lean) · [`A, D`](UL/Stmt/thm_5_1.lean) · [`D₀`](UL/Stmt/lem_C_3.lean) | Lean writes lam for λ. In Theorem 1.4, M bounds the gradient norm, A = LR and D = M + A + βλA. Lemma D.2 uses D₀ = M₀ + CA. |
| osc(F) | [`exists_oscillation_bound`](UL/Proof/lem_A_5/H1_Simplex.lean) | The proof uses the maximum of F minus its minimum on Δ_K to bound F(p) − F(q). The estimates that use this bound call it oscBound. |
| S in Appendix D.7 | [`score`](UL/Arxiv/LogisticExperiment.lean) · [lower bound](UL/Arxiv/LogisticLower.lean) | The scalar score is S = ⟨wₛ, X⟩. The hard instance has conditional probability σ(S) on the unit sphere. |

## Scope of the statistical and smoothing proofs

**Theorem 1.4 and Appendix D.** The [finite search](UL/Arxiv/FiniteLearner.lean) fits feasible probability rows for each candidate score matrix, compares their computed gaps, and extends the selected rows to a new query by a simplex quadratic program. The [training and prediction rule](UL/Arxiv/UnroundedSearch.lean) uses the original training features in sample-ordered Gram–Schmidt coordinates. Lean proves that this rule is jointly Borel measurable in the sample and query, including at rank changes and tied scores. The [population theorem](UL/Arxiv/HilbertScoreSearch.lean) proves the paper’s dimension-free sample rate, coefficient budget and link slope for this same rule in a separable real Hilbert space. Taking B = β and finite-dimensional features gives the setting of Theorem 1.4. For mesh h, the number of score matrices in the grid is at most (1 + 4R/h)^(m rₙ), where m = K − 1 and rₙ is the dimension of the sample span. The proof uses a fixed order to break ties and a conservative grid resolution. Different admissible choices can return different forecasts with the same guarantee.

**After Corollary B.7.** The [scalar smoothing theorem](UL/Arxiv/BinarySmoothing.lean) compares the smoothed forecast with the best linear action over the same compact convex weight set. For each admissible entropy and 0 < δ < 1, its excess risk is at most Jφ(δ)/(1 − δ) + δ/(16β). The proof also establishes continuity of the maximal Jensen gap and its value zero at δ = 0.

**Appendix D, binary logistic loss.** The [sample lower bound](UL/Arxiv/LogisticLower.lean) constructs a realizable logistic model on a unit sphere. At success probability greater than 5/7, even randomized measurable probability forecasts require Ω(ε⁻²) samples as dimension grows. The proof uses a product likelihood-ratio bound and a clipped-logit estimate. The finite-dimensional testing cutoff is n ≤ d²/8. The paper uses n ≤ 4d².

## Additional result · Positive-error extension of Theorem 1.1(b)

For each positive error ε, a single forecast works for every continuous nondecreasing target link on the bounded action interval and every choice of Bayes action. Its nondecreasing link has Lipschitz constant at most 1/(16ε). [Statement and proof](UL/Arxiv/BoundedApproximation.lean)

## Verify the supplement

With Elan installed, run the following commands from the repository root.

```sh
lake exe cache get
lake build UL
lake env lean CheckAxioms.lean
```

The project uses Lean 4.27.0 and Mathlib v4.27.0. The [axiom check](CheckAxioms.lean) requires every numbered declaration to exist and checks the dependencies of every declaration under `UL.Arxiv`, including supporting results in subnamespaces. It fails if any of them uses an axiom outside `propext`, `Classical.choice` and `Quot.sound`.

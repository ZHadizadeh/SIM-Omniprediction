import UL.Arxiv.ComputedFit
import UL.Proof.cor_C_7.H2_LogAndProfiles

namespace UL.Arxiv.ScoreStability
open GridOracle Proof_lem_C_2
variable {K n : ℕ} {X : Type} [NormedAddCommGroup X] [InnerProductSpace ℝ X] [CompleteSpace X]

private theorem paired (x : Fin n → X) (ξ : Fin n → H K) (w : ScoreGrid.V (dim x K)) :
    inner ℝ (empGradVec x ξ) w = (1/(n:ℝ))*∑ i, inner ℝ (ξ i) (toSampleSpanOp (Y:=H K) x w (x i)) := by
  let g := empGradVec x ξ
  let op := toSampleSpanOp (Y:=H K) x
  have h := hsInner_empGrad x ξ (op w)
  dsimp only at h
  rw [← toSampleSpanOp_empGradVec,← hsInner_eq_polarization] at h
  change (1/4:ℝ)*(hilbertSchmidtNorm (op g+op w)^2-hilbertSchmidtNorm (op g-op w)^2) = _ at h
  dsimp only [op] at h
  rw [← toSampleSpanOp_add,← toSampleSpanOp_sub,hilbertSchmidtNorm_toSampleSpanOp,
    hilbertSchmidtNorm_toSampleSpanOp,norm_add_sq_real,norm_sub_sq_real] at h
  change inner ℝ g w = _; linarith

private theorem diffGradient (x : Fin n → X) (ξ ξ' : Fin n → H K) :
    empGradVec x ξ - empGradVec x ξ' = empGradVec x (fun i => ξ i-ξ' i) := by
  apply ext_inner_right ℝ; intro w
  rw [inner_sub_left,paired,paired,paired,← mul_sub,← Finset.sum_sub_distrib]
  congr 1; apply Finset.sum_congr rfl; intro i _; rw [inner_sub_left]

/-- The empirical residual moment is bounded in Frobenius norm by L times
the root-mean-square residual, independently of both dimensions. -/
theorem gradient_rms (hn : 1 ≤ n) (x : Fin n → X) {L : ℝ} (hx : ∀ i, ‖x i‖ ≤ L) (ξ : Fin n → H K) :
    ‖empGradVec x ξ‖ ≤ L * Real.sqrt ((1/(n:ℝ))*∑ i, ‖ξ i‖^2) := by
  let g := empGradVec x ξ
  have hn' : (0:ℝ) < n := Nat.cast_pos.mpr (by omega)
  have hL := (norm_nonneg _).trans (hx ⟨0,by omega⟩)
  have h (i) : inner ℝ (ξ i) (toSampleSpanOp x g (x i)) ≤ ‖ξ i‖*(‖g‖*L) := by
    apply (real_inner_le_norm _ _).trans
    apply mul_le_mul_of_nonneg_left _ (norm_nonneg _)
    exact (norm_apply_le_hilbertSchmidtNorm _ _).trans (by rw [hilbertSchmidtNorm_toSampleSpanOp]; gcongr; exact hx i)
  have step := mul_le_mul_of_nonneg_left (Finset.sum_le_sum (s:=Finset.univ) fun i _ => h i) (by positivity : 0 ≤ 1/(n:ℝ))
  rw [← paired,real_inner_self_eq_norm_sq,← Finset.sum_mul] at step
  have cs := Real.sum_mul_le_sqrt_mul_sqrt (ι:=Fin n) Finset.univ (fun i => ‖ξ i‖) (fun _ => (1:ℝ))
  simp only [mul_one,one_pow,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul] at cs
  have mean : (1/(n:ℝ))*∑ i, ‖ξ i‖ ≤ Real.sqrt ((1/(n:ℝ))*∑ i, ‖ξ i‖^2) := by
    rw [Real.sqrt_mul (by positivity), Real.sqrt_div zero_le_one,Real.sqrt_one]
    have hp := Real.sqrt_pos.mpr hn'
    have hn2 := Real.sq_sqrt hn'.le
    rw [one_div_mul_eq_div,one_div_mul_eq_div]
    apply (div_le_div_iff₀ hn' hp).mpr
    nlinarith only [mul_le_mul_of_nonneg_right cs hp.le,hn2,
      show Real.sqrt (∑ i, ‖ξ i‖^2)*(Real.sqrt (n:ℝ))^2 = Real.sqrt (∑ i, ‖ξ i‖^2)*n by rw [hn2]]
  change ‖g‖ ≤ _
  by_cases hg : ‖g‖ = 0
  · rw [hg]; positivity
  · have pos := lt_of_le_of_ne (norm_nonneg g) (Ne.symm hg)
    apply le_of_mul_le_mul_right (a:=‖g‖) (by
      change ‖g‖ * ‖g‖ ≤ _
      calc _ ≤ ((1/(n:ℝ))*∑ i, ‖ξ i‖)*L*‖g‖ := by nlinarith only [step]
           _ ≤ _ := by rw [mul_comm ((1/(n:ℝ))*∑ i, ‖ξ i‖) L]; exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left mean hL) pos.le) pos

/-- Transferring both fits gives the perturbation estimate in Appendix D. -/
theorem fitted_rms (hn : 1 ≤ n) {A B dist : ℝ} (hB : 0 ≤ B)
    {s t pTilde qTilde Z : Fin n → H K} (hs : ∀ i, ‖s i‖ ≤ A) (ht : ∀ i, ‖t i‖ ≤ A)
    (hd : ∀ i, ‖s i-t i‖ ≤ dist) (hz : ∀ i, uniformVec K+(Z i).val ∈ Simplex K)
    (hP : isOptFitAtScores A B Z s pTilde) (hQ : isOptFitAtScores A B Z t qTilde) :
    (1/(n:ℝ))*∑ i, ‖pTilde i-qTilde i‖^2 ≤ 2*Real.sqrt 2*B*dist := by
  obtain ⟨ρ,hρ,eqP⟩ := hP.1
  obtain ⟨σ,hσ,eqQ⟩ := hQ.1
  have v₁ := fit_vi_fin hn hP hσ
  have v₂ := fit_vi_fin hn hQ hρ
  have transfer (i) : ‖pTilde i-qTilde i‖^2 + inner ℝ (pTilde i-Z i) (σ (s i)-pTilde i) +
      inner ℝ (qTilde i-Z i) (ρ (t i)-qTilde i) ≤ 2*Real.sqrt 2*B*dist := by
    have cap (v v' : H K) (hv : uniformVec K+v.val ∈ Simplex K)
        (hv' : uniformVec K+v'.val ∈ Simplex K) : ‖v-v'‖ ≤ Real.sqrt 2 := by
      simpa only [add_sub_add_left_eq_sub,← Submodule.coe_sub,Submodule.norm_coe] using
        Proof_cor_C_7.norm_sub_le_sqrt_two_of_mem_simplex hv hv'
    have hp : ‖pTilde i-Z i‖ ≤ Real.sqrt 2 := cap _ _ (eqP i ▸ hρ.1 _ (hs i)) (hz i)
    have hq : ‖qTilde i-Z i‖ ≤ Real.sqrt 2 := cap _ _ (eqQ i ▸ hσ.1 _ (ht i)) (hz i)
    have c1 : ‖σ (s i)-qTilde i‖ ≤ B*dist := by rw [eqQ i]; exact (hσ.2 _ _ (hs i) (ht i)).trans (mul_le_mul_of_nonneg_left (hd i) hB)
    have c2 : ‖ρ (t i)-pTilde i‖ ≤ B*dist := by rw [eqP i,norm_sub_rev]; exact (hρ.2 _ _ (hs i) (ht i)).trans (mul_le_mul_of_nonneg_left (hd i) hB)
    have ub1 := (real_inner_le_norm (pTilde i-Z i) (σ (s i)-qTilde i)).trans (mul_le_mul hp c1 (norm_nonneg _) (Real.sqrt_nonneg _))
    have ub2 := (real_inner_le_norm (qTilde i-Z i) (ρ (t i)-pTilde i)).trans (mul_le_mul hq c2 (norm_nonneg _) (Real.sqrt_nonneg _))
    rw [← real_inner_self_eq_norm_sq]
    simp only [inner_sub_left,inner_sub_right] at *; rw [real_inner_comm (qTilde i) (pTilde i)] at *
    linarith
  have h := Finset.sum_le_sum (s:=Finset.univ) (fun i _ => transfer i)
  rw [Finset.sum_add_distrib,Finset.sum_add_distrib,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul] at h
  have hn' : (0:ℝ) < n := Nat.cast_pos.mpr (by omega)
  rw [one_div_mul_eq_div,div_le_iff₀ hn']; linarith

/-- The gap changes by at most √2 L h + 2LR √(2√2 BLh) between score
matrices at Frobenius distance at most h, as in Appendix D. -/
theorem certificate_modulus (hn : 1 ≤ n) (x : Fin n → X) {L R A B h : ℝ}
    (hx : ∀ i, ‖x i‖ ≤ L) (hL : 0 ≤ L) (hB : 0 ≤ B) (hh : 0 ≤ h)
    (w v : ScoreGrid.V (dim x K)) (hwv : ‖w-v‖ ≤ h) (hv : ‖v‖ ≤ R)
    (pTilde qTilde Z : Fin n → H K) (hz : ∀ i, uniformVec K+(Z i).val ∈ Simplex K)
    (hs : ∀ i, ‖toSampleSpanOp (Y:=H K) x w (x i)‖ ≤ A)
    (ht : ∀ i, ‖toSampleSpanOp (Y:=H K) x v (x i)‖ ≤ A)
    (hP : isOptFitAtScores A B Z (fun i => toSampleSpanOp x w (x i)) pTilde)
    (hQ : isOptFitAtScores A B Z (fun i => toSampleSpanOp x v (x i)) qTilde) :
    |certificate x R w pTilde Z - certificate x R v qTilde Z| ≤
      Real.sqrt 2*L*h+2*(L*R)*Real.sqrt (2*Real.sqrt 2*B*(L*h)) := by
  have hR := (norm_nonneg _).trans hv
  have hn' : (0:ℝ) < n := Nat.cast_pos.mpr (by omega)
  let g := empGradVec x (fun i => pTilde i-Z i)
  let f := empGradVec x (fun i => qTilde i-Z i)
  have hdist i : ‖toSampleSpanOp (Y:=H K) x w (x i)-toSampleSpanOp x v (x i)‖ ≤ L*h := by
    rw [← ContinuousLinearMap.sub_apply,← toSampleSpanOp_sub]
    apply (norm_apply_le_hilbertSchmidtNorm _ _).trans
    rw [hilbertSchmidtNorm_toSampleSpanOp,mul_comm L h]
    exact mul_le_mul hwv (hx i) (norm_nonneg _) hh
  have rms := fitted_rms hn hB hs ht hdist hz hP hQ
  have diff : ‖g-f‖ ≤ L*Real.sqrt (2*Real.sqrt 2*B*(L*h)) := by
    dsimp only [g,f]; rw [diffGradient]
    simp_rw [sub_sub_sub_cancel_right]
    exact (gradient_rms hn x hx _).trans (mul_le_mul_of_nonneg_left (Real.sqrt_le_sqrt rms) hL)
  obtain ⟨ρ,hρ,eqP⟩ := hP.1
  have resid (i) : ‖pTilde i-Z i‖ ≤ Real.sqrt 2 := by
    have hp : uniformVec K+(pTilde i).val ∈ Simplex K := eqP i ▸ hρ.1 _ (hs i)
    simpa only [add_sub_add_left_eq_sub,← Submodule.coe_sub,Submodule.norm_coe] using
      Proof_cor_C_7.norm_sub_le_sqrt_two_of_mem_simplex hp (hz i)
  have gr : ‖g‖ ≤ L*Real.sqrt 2 := by
    apply (gradient_rms hn x hx _).trans
    apply mul_le_mul_of_nonneg_left _ hL
    apply Real.sqrt_le_sqrt
    have r2 (i) : ‖pTilde i-Z i‖^2 ≤ 2 := by simpa using pow_le_pow_left₀ (norm_nonneg _) (resid i) 2
    have sum := Finset.sum_le_sum (s:=Finset.univ) fun i _ => r2 i
    rw [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul] at sum
    rw [one_div_mul_eq_div,div_le_iff₀ hn']; linarith
  have decomp : certificate x R w pTilde Z-certificate x R v qTilde Z =
      inner ℝ g (w-v) + inner ℝ (g-f) v + R*(‖g‖-‖f‖) := by
    dsimp [certificate,g,f]; rw [inner_sub_left,inner_sub_right]; ring
  rw [decomp]
  have h1 := (abs_real_inner_le_norm g (w-v)).trans (mul_le_mul gr hwv (norm_nonneg _) (by positivity))
  have h2 := (abs_real_inner_le_norm (g-f) v).trans (mul_le_mul diff hv (norm_nonneg _) (by positivity))
  have h3 := mul_le_mul_of_nonneg_left ((abs_norm_sub_norm_le g f).trans diff) hR
  have h4 := abs_add_le (inner ℝ g (w-v)) (inner ℝ (g-f) v)
  have h5 := abs_add_le (inner ℝ g (w-v)+inner ℝ (g-f) v) (R*(‖g‖-‖f‖))
  rw [abs_mul,abs_of_nonneg hR] at h5
  linarith only [h1,h2,h3,h4,h5,
    show L*Real.sqrt 2*h=Real.sqrt 2*L*h by ring,
    show L*Real.sqrt (2*Real.sqrt 2*B*(L*h))*R+R*(L*Real.sqrt (2*Real.sqrt 2*B*(L*h))) =
      2*(L*R)*Real.sqrt (2*Real.sqrt 2*B*(L*h)) by ring]

end UL.Arxiv.ScoreStability

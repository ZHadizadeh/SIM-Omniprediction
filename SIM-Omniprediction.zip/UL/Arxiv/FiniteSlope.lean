import UL.Arxiv.BoundedBinary
import UL.Proof.thm_3_2
/-! # Finite-slope fits in Appendix A.2

The finite-slope estimate follows from binary least squares and the score fixed point.
The parameter B is free and the error 1/(16B) tends to zero.
-/

open MeasureTheory Set
open UL.Proof_thm_3_2
namespace UL.Arxiv.BoundedBinary
noncomputable section

/-- The fixed-point fit controls every linear direction, and every continuous
nondecreasing test of its report, on a common forecast. -/
theorem exists_finite_slope_fit {d : ℕ} {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (X : Ω → Features d) (Y : Ω → Fin 2)
    (hX : Measurable X) (hY : Measurable Y) (hXi : Integrable (fun ω => ‖X ω‖) μ)
    (R B : ℝ) (hR : 0 < R) (hB : 0 < B) :
    ∃ (w : Features d) (ρ : ℝ → ℝ), ‖w‖ ≤ R ∧ IsProfile B ρ ∧
      let P := fun ω => ρ (inner ℝ w (X ω))
      let ξ := fitRes P Y
      (∀ f : ℝ → ℝ, Continuous f → Monotone f → (∫ ω, ξ ω * f (P ω) ∂μ) ≤ 0) ∧
      (∀ v : Features d, ‖v‖ ≤ R → -(1 / (16 * B)) ≤ ∫ ω, ξ ω * inner ℝ v (X ω) ∂μ) := by
  obtain ⟨profiles, hopt, hvi, _, hcont⟩ :=
    exists_optProfile_and_continuous_drift d Ω μ X Y hX hY B hB hXi
  let g (w : Features d) :=
    ∫ ω, (profiles w (inner ℝ w (X ω)) - yReal (Y ω)) • X ω ∂μ
  obtain ⟨w, hw, hfixed⟩ := exists_fixed_point_score d R hR g hcont
  let ρ := profiles w
  let P := fun ω => ρ (inner ℝ w (X ω))
  let ξ := fitRes P Y
  have hρ : IsProfile B ρ := (hopt w).1
  have hPm : Measurable P :=
    hρ.measurable.comp ((continuous_const.inner continuous_id).measurable.comp hX)
  have hPI : ∀ ω, P ω ∈ Icc (0 : ℝ) 1 := fun _ => hρ.2.2 _
  have hEnd := ae_endpoint_support d Ω μ X Y hX hY B hB w ρ hρ (hvi w)
  have htest (f : ℝ → ℝ) (hc : Continuous f) (hm : Monotone f) :
      (∫ ω, ξ ω * f (P ω) ∂μ) ≤ 0 := by
    let F (x : ℝ) := ∫ s in (0 : ℝ)..x, f s
    have hd (x : ℝ) : HasDerivAt F (f x) x := (hc.integral_hasStrictDerivAt 0 x).hasDerivAt
    have hFd : Differentiable ℝ F := fun x => (hd x).differentiableAt
    have hder : deriv F = f := funext fun x => (hd x).deriv
    have hcv : ConvexOn ℝ univ F := Monotone.convexOn_univ_of_deriv hFd (hder.symm ▸ hm)
    obtain ⟨_, h⟩ := convex_test_ineq d Ω μ X Y hX hY B hB w ρ hρ (hvi w) F
      hFd.continuous.continuousOn (hcv.subset (subset_univ _) (convex_Icc _ _))
      (fun q _ => hFd q)
    change (∫ ω, if P ω ∈ Ioo (0 : ℝ) 1 then ξ ω * deriv F (P ω) else 0 ∂μ) ≤ 0 at h
    refine le_trans (le_of_eq (integral_congr_ae ?_)) h
    filter_upwards [hEnd] with ω hω
    rw [hder]
    split_ifs with hin
    · rfl
    · rcases eq_or_lt_of_le (hPI ω).1 with he | hl
      · have hy := hω.1 he.symm
        simp [ξ, fitRes, he.symm, hy, yReal]
      · have he : P ω = 1 := eq_of_le_of_not_lt (hPI ω).2 (fun hu => hin ⟨hl, hu⟩)
        have hy := hω.2 he
        simp [ξ, fitRes, he, hy, yReal]
  refine ⟨w, ρ, hw, hρ, htest, ?_⟩
  have hmean : (∫ ω, ξ ω ∂μ) = 0 := by
    have hp := htest (fun _ => 1) continuous_const monotone_const
    have hn := htest (fun _ => -1) continuous_const monotone_const
    simp only [mul_one, mul_neg, integral_neg] at hp hn
    linarith
  have hr_le (ω : Ω) : |ξ ω| ≤ 1 := abs_fitRes_le_one hPI Y ω
  have hrm : Measurable ξ := hPm.sub (measurable_yReal hY)
  have hri : Integrable ξ μ := (integrable_const (1 : ℝ)).mono' hrm.aestronglyMeasurable
    (Filter.Eventually.of_forall (fun ω => by simpa [Real.norm_eq_abs] using hr_le ω))
  have hrPi : Integrable (fun ω => ξ ω * P ω) μ := by
    apply (integrable_const (1 : ℝ)).mono' (hrm.mul hPm).aestronglyMeasurable
    filter_upwards with ω
    rw [Real.norm_eq_abs, abs_mul, abs_of_nonneg (hPI ω).1]
    exact (mul_le_mul (hr_le ω) (hPI ω).2 (hPI ω).1 zero_le_one).trans_eq (one_mul 1)
  have hbound : -(1 / 16 : ℝ) ≤ ∫ ω, ξ ω * P ω ∂μ := by
    have hi := integral_mono (μ := μ) (integrable_const (-(1 / 16 : ℝ)))
      (hrPi.sub (hri.mul_const (1 / 2))) (fun ω => (show -(1 / 16 : ℝ) ≤
        ξ ω * P ω - ξ ω * (1 / 2) by
          dsimp [ξ, fitRes]
          rcases yReal_eq_zero_or_one (Y ω) with h | h <;> rw [h] <;>
            nlinarith [sq_nonneg (P ω - 1 / 4), sq_nonneg (P ω - 3 / 4)]))
    simpa only [integral_const, probReal_univ, one_smul, integral_sub hrPi (hri.mul_const _),
      integral_mul_const, hmean, zero_mul, sub_zero, Pi.sub_apply] using hi
  have hown := own_score_ineq d Ω μ X Y hX hY B hB hXi w ρ hρ (hvi w)
  change (∫ ω, ξ ω * P ω ∂μ) ≤ B * ∫ ω, ξ ω * inner ℝ w (X ω) ∂μ at hown
  intro v hv
  have he v := inner_drift_eq d Ω μ X Y hX hY hXi P hPm hPI v
  have hdir := hfixed v hv
  change inner ℝ w (∫ ω, (P ω - yReal (Y ω)) • X ω ∂μ) ≤
    inner ℝ v (∫ ω, (P ω - yReal (Y ω)) • X ω ∂μ) at hdir
  rw [he v, he w] at hdir
  apply le_trans _ hdir
  rw [show -(1 / (16 * B)) = (-(1 / 16)) / B by ring]
  exact (div_le_iff₀ hB).2 (by linarith)

end
end UL.Arxiv.BoundedBinary

import UL.Arxiv.OrderedCoordinates
import UL.Arxiv.FixedSpanSearch

open Set MeasureTheory InnerProductSpace
namespace UL.Arxiv.UnroundedSearch
open GridOracle FiniteLearner Proof_lem_C_2 OrderedCoordinates
open scoped UL.Arxiv.OrderedCoordinates

variable {X : Type} [NormedAddCommGroup X] [InnerProductSpace ℝ X] [CompleteSpace X]
  [MeasurableSpace X] [BorelSpace X] [SecondCountableTopology X] {n K : ℕ}

/-- Train in sample-ordered Gram–Schmidt coordinates, and use the same
coordinates for a new query. The only rounding occurs in the two finite searches. -/
noncomputable def forecast (hK : 2 ≤ K) (hn : 1 ≤ n) {R B : ℝ} (hR : 0 < R) (hB : 0 < B)
    (L lam η : ℝ) (x : Fin n → X) (y : Fin n → Fin K) (z : X) : E K :=
  let J := active x
  FixedSpanSearch.predict (⊤ : Submodule ℝ (EuclideanSpace ℝ J)) hK hn
    (fun i => coords J x (x i)) y hR hB L lam η (coords J x z)

attribute [local irreducible] FixedSpanSearch.predict OrderedCoordinates.coords

/-- Joint measurability holds on the unrounded inputs, including every rank-change stratum. -/
theorem joint {T : Type*} [MeasurableSpace T] (x : T → Fin n → X) (y : T → Fin n → Fin K)
    (z : T → X) (hx : Measurable x) (hy : Measurable y) (hz : Measurable z)
    (hK : 2 ≤ K) (hn : 1 ≤ n) {L R β B lam η : ℝ} (hL : 0 < L) (hR : 0 < R)
    (hβ : 0 < β) (hB : β ≤ B) (hl : 0 < lam) (hη : 0 < η) :
    Measurable (fun t => forecast hK hn hR (hβ.trans_le hB) L lam η (x t) (y t) (z t)) := by
  let f := fun J : Finset (Fin n) => fun t : T =>
    FixedSpanSearch.predict (⊤ : Submodule ℝ (EuclideanSpace ℝ J)) hK hn
      (fun i => coords J (x t) (x t i)) (y t) hR (hβ.trans_le hB) L lam η (coords J (x t) (z t))
  have hm J : Measurable (f J) :=
    FixedSpanSearch.predict_measurable _ (fun i => (coords_measurable J).comp
      (hx.prodMk ((measurable_pi_apply i).comp hx))) hy hK hn hL hR hβ hB hl hη
      ((coords_measurable J).comp (hx.prodMk hz))
  have h : Measurable (fun u : T × Finset (Fin n) => f u.2 u.1) :=
    measurable_from_prod_countable_left hm
  change Measurable (fun t => f (active (x t)) t)
  exact h.comp (measurable_id.prodMk (active_measurable.comp hx))

private theorem bdd_emp {F : Type*} [NormedAddCommGroup F] [InnerProductSpace ℝ F] [CompleteSpace F]
    {L R β lam M : ℝ} (hK : 2 ≤ K) (hR : 0 < R) (x : Fin n → F) (y : Fin n → Fin K)
    (hx : ∀ i, ‖x i‖ ≤ L) {Φ : Simplex K → ℝ} (hΦ : Φ ∈ SmoothEntropyFamily K β lam M) :
    BddBelow (Set.range (fun V : {V : F →L[ℝ] H K // hilbertSchmidtNorm V ≤ R} =>
      (1/(n:ℝ))*∑ i, matchingLoss Φ ((V.val (x i) : H K) : E K) (y i))) := by
  let b := -(|matchingPotential Φ 0| + 3*(R*L))
  refine ⟨(1/(n:ℝ))*∑ _i : Fin n, b,?_⟩
  rintro _ ⟨V,rfl⟩
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  apply Finset.sum_le_sum; intro i _
  have nrm := (norm_apply_le_hilbertSchmidtNorm V.val (x i)).trans (mul_le_mul V.property (hx i) (norm_nonneg _) hR.le)
  have h := UL.Proof_cor_A_8.matchingLoss_abs_le (by omega) hΦ.1.2.1
    ((V.val (x i) : H K) : E K) (y i)
  rw [Submodule.norm_coe] at h
  dsimp [b]; linarith [(abs_le.mp h).1]

/-- Representation and empirical guarantee for the same measurable prediction
rule. A linear comparator is transported to the sample coordinates by the
inverse isometry on the span. This preserves its coefficient budget. -/
theorem empirical (hK : 2 ≤ K) (hn : 1 ≤ n) (x : Fin n → X) (y : Fin n → Fin K)
    {L R β B lam η : ℝ} (hL : 0 < L) (hx : ∀ i, ‖x i‖ ≤ L) (hR : 0 < R)
    (hβ : 0 < β) (hB : β ≤ B) (hl : 0 < lam) (hη : 0 < η) :
    ∃ (W : X →L[ℝ] H K) (ρ : H K → E K), hilbertSchmidtNorm W ≤ R ∧
      (∀ z, ρ z ∈ Simplex K) ∧ LipschitzWith B.toNNReal ρ ∧
      (∀ z, forecast hK hn hR (hβ.trans_le hB) L lam η x y z = ρ (W z)) ∧
      ∀ {M : ℝ} (Φ : Simplex K → ℝ), Φ ∈ SmoothEntropyFamily K β lam M →
      ∀ (V : X →L[ℝ] H K), hilbertSchmidtNorm V ≤ R →
        (1/(n:ℝ))*∑ i, finiteCanonicalLoss Φ (ρ (W (x i))) (y i) ≤
        (1/(n:ℝ))*∑ i, matchingLoss Φ ((V (x i) : H K) : E K) (y i) + 4*η := by
  classical
  let J := active x
  obtain ⟨A,D,hA,conA,conD,back,full⟩ := chart (J:=J) x rfl
  let u := fun i => A (x i)
  have ub i : ‖u i‖ ≤ L := (A.le_opNorm _).trans (by simpa using mul_le_mul conA (hx i) (norm_nonneg _) zero_le_one)
  let w := weights hK u y hR L B lam η
  let W := toSampleSpanOp (Y:=H K) u w.val
  let s := fun i => W (u i)
  let p := rows hK s y B (tolerance n (dim u K) R L lam η)
  obtain ⟨_,normW,_,hp,hcap,range,lip,_,reg⟩ := run_spec hK hn u y hL ub hR hβ hB hl hη
  let ρ := FiniteLearner.extend hK hn s p (hβ.trans_le hB) hp hcap
  refine ⟨W.comp A,ρ,(hs_contraction A W conA).trans normW,range,lip,?_,?_⟩
  · intro z
    unfold forecast
    change FixedSpanSearch.predict (⊤ : Submodule ℝ (EuclideanSpace ℝ J)) hK hn
      (fun i => coords J x (x i)) y hR (hβ.trans_le hB) L lam η (coords J x z) = ρ (W (A z))
    have vec : (fun i => coords J x (x i)) = u := funext fun i => (hA (x i)).symm
    rw [vec,← hA z]
    have eq := FixedSpanSearch.matrix_eq u y ⊤ full hK hR L B lam η
    have rk : Module.finrank ℝ (⊤ : Submodule ℝ (EuclideanSpace ℝ J)) = Module.finrank ℝ (sampleSpan u) :=
      congrArg (fun S : Submodule ℝ (EuclideanSpace ℝ J) => Module.finrank ℝ S) full.symm
    unfold FixedSpanSearch.predict
    dsimp only
    simp only [eq,rk]
    split <;> rename_i hg
    · rfl
    · exact (hg ⟨hp,hcap⟩).elim
  · intro M Φ hΦ V vnorm
    have vnorm' := (hs_contraction D V conD).trans vnorm
    have lower := ciInf_le (bdd_emp hK hR u y ub hΦ) ⟨V.comp D,vnorm'⟩
    have e := (reg Φ hΦ).trans (add_le_add lower le_rfl)
    simpa only [ContinuousLinearMap.comp_apply,u,back] using e

open Proof_thm_5_1

/-- Appendix D clips training features to the prescribed ball. This gives a
prediction rule on all samples and leaves every admissible sample unchanged. -/
noncomputable def boundedForecast (hK : 2 ≤ K) (hn : 1 ≤ n) {R B : ℝ} (hR : 0 < R) (hB : 0 < B)
    (L lam η : ℝ) (x : Fin n → X) (y : Fin n → Fin K) (z : X) : E K :=
  forecast hK hn hR hB L lam η (fun i => clampBall L (x i)) y z

theorem bounded_joint (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R β B lam η : ℝ} (hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) (hB : β ≤ B)
    (hl : 0 < lam) (hη : 0 < η) :
    Measurable (fun z : ((Fin n → X) × (Fin n → Fin K)) × X =>
      boundedForecast hK hn hR (hβ.trans_le hB) L lam η z.1.1 z.1.2 z.2) := by
  apply joint _ _ _ _ (measurable_snd.comp measurable_fst) measurable_snd hK hn hL hR hβ hB hl hη
  exact measurable_pi_lambda _ fun i => (continuous_clampBall hL).measurable.comp
    ((measurable_pi_apply i).comp (measurable_fst.comp measurable_fst))

theorem representation (hK : 2 ≤ K) (hn : 1 ≤ n) (x : Fin n → X) (y : Fin n → Fin K)
    {L R β B lam η : ℝ} (hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) (hB : β ≤ B)
    (hl : 0 < lam) (hη : 0 < η) :
    ∃ (W : X →L[ℝ] H K) (ρ : H K → E K), hilbertSchmidtNorm W ≤ R ∧
      (∀ z, ρ z ∈ Simplex K) ∧ LipschitzWith B.toNNReal ρ ∧
      ∀ z, boundedForecast hK hn hR (hβ.trans_le hB) L lam η x y z = ρ (W z) := by
  obtain ⟨W,ρ,hw,hr,hlip,he,_⟩ := empirical hK hn (fun i => clampBall L (x i)) y hL
    (fun i => norm_clampBall_le hL (x i)) hR hβ hB hl hη
  exact ⟨W,ρ,hw,hr,hlip,he⟩

end UL.Arxiv.UnroundedSearch

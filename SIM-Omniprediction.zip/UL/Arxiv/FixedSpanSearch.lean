import UL.Arxiv.MeasurableFit
import UL.Arxiv.QueryContinuity

set_option maxHeartbeats 350000

open Set MeasureTheory
namespace UL.Arxiv.FixedSpanSearch
open GridOracle FiniteLearner Proof_lem_C_2

variable {X : Type} [NormedAddCommGroup X] [InnerProductSpace ℝ X] [CompleteSpace X]
variable {n K : ℕ}

/-- Explicit matrix multiplication in an orthonormal basis of a fixed span. -/
noncomputable def op (U : Submodule ℝ X) [FiniteDimensional ℝ U]
    (w : ScoreGrid.V (Module.finrank ℝ U * Module.finrank ℝ (H K))) : X →L[ℝ] H K :=
  ∑ k : Fin (Module.finrank ℝ U), ∑ j : Fin (Module.finrank ℝ (H K)),
    w (finProdFinEquiv (k,j)) • (innerSL ℝ ((stdOrthonormalBasis ℝ U k : U) : X)).smulRight
      (stdOrthonormalBasis ℝ (H K) j)

noncomputable def grad (U : Submodule ℝ X) [FiniteDimensional ℝ U] (x : Fin n → X) (ξ : Fin n → H K) :
    ScoreGrid.V (Module.finrank ℝ U * Module.finrank ℝ (H K)) :=
  WithLp.toLp 2 fun j => let ij := finProdFinEquiv.symm j
    (1/(n:ℝ))*∑ i, inner ℝ ((stdOrthonormalBasis ℝ U ij.1 : U) : X) (x i) *
      inner ℝ (ξ i) (stdOrthonormalBasis ℝ (H K) ij.2)

noncomputable def choice (U : Submodule ℝ X) [FiniteDimensional ℝ U]
    (hK : 2 ≤ K) (x : Fin n → X) (y : Fin n → Fin K) {R : ℝ} (hR : 0 < R) (L B lam η : ℝ) :=
  let m := Module.finrank ℝ U * Module.finrank ℝ (H K)
  let h := PrescribedGrid.mesh L R B η
  let t := tolerance n m R L lam η
  let f := fun w : ScoreGrid.V m =>
    let p := rows hK (fun i => op U w (x i)) y B t
    let g := grad U x (fun i => centered hK (p i) - center (label (y i)) hK)
    inner ℝ g w + R * ‖g‖
  index hR h f

noncomputable def matrix (U : Submodule ℝ X) [FiniteDimensional ℝ U]
    (hK : 2 ≤ K) (x : Fin n → X) (y : Fin n → Fin K) {R : ℝ} (hR : 0 < R) (L B lam η : ℝ) :=
  op U (ScoreGrid.point hR (choice U hK x y hR L B lam η)).val

/-- This is the same selected matrix as the sample-span search whenever the
specified span equals that of the data. This identity permits checking the
finite search separately on each rank branch. -/
theorem matrix_eq (x : Fin n → X) (y : Fin n → Fin K) (U : Submodule ℝ X) [FiniteDimensional ℝ U]
    (hu : sampleSpan x = U) (hK : 2 ≤ K) {R : ℝ} (hR : 0 < R) (L B lam η : ℝ) :
    matrix U hK x y hR L B lam η = toSampleSpanOp (Y:=H K) x (weights hK x y hR L B lam η).val := by
  subst U; rfl

variable [MeasurableSpace X] [BorelSpace X] [SecondCountableTopology X]
variable {T : Type*} [MeasurableSpace T]

private theorem centered_meas (hK : 2 ≤ K) : Measurable (centered hK) := by
  classical
  apply measurable_comap_iff.mpr
  change Measurable (fun v : E K => ((centered hK v : H K) : E K))
  have eq : (fun v : E K => ((centered hK v : H K) : E K)) =
      (fun v => if v ∈ Simplex K then v-uniformVec K else 0) := by
    funext v; by_cases h : v ∈ Simplex K <;> simp [centered,GridOracle.center,h]
  rw [eq]
  exact Measurable.ite (Proof_lem_A_5.isCompact_simplex K).isClosed.measurableSet
    (measurable_id.sub measurable_const) measurable_const

private theorem grad_meas {U : Submodule ℝ X} [FiniteDimensional ℝ U]
    {x : T → Fin n → X} {ξ : T → Fin n → H K}
    (hx : ∀ i, Measurable (fun t => x t i)) (hr : ∀ i, Measurable (fun t => ξ t i)) :
    Measurable (fun t => grad U (x t) (ξ t)) := by
  let v t (j : Fin (Module.finrank ℝ U*Module.finrank ℝ (H K))) :=
    let ij := finProdFinEquiv.symm j
    (1/(n:ℝ))*∑ i, inner ℝ ((stdOrthonormalBasis ℝ U ij.1 : U) : X) (x t i) *
      inner ℝ (ξ t i) (stdOrthonormalBasis ℝ (H K) ij.2)
  have hv : Measurable v := measurable_pi_lambda _ fun j =>
    measurable_const.mul (Finset.measurable_fun_sum _ fun i _ =>
      (measurable_const.inner (hx i)).mul ((hr i).inner measurable_const))
  exact (PiLp.continuous_toLp 2 _).measurable.comp hv

private theorem fixed_gap {U : Submodule ℝ X} [FiniteDimensional ℝ U]
    {x : T → Fin n → X} {y : T → Fin n → Fin K}
    (hx : ∀ i, Measurable (fun a => x a i)) (hy : Measurable y)
    (hK : 2 ≤ K) (R B t : ℝ) (w : ScoreGrid.V (Module.finrank ℝ U*Module.finrank ℝ (H K))) :
    let p a := rows hK (fun i => op U w (x a i)) (y a) B t
    let g a := grad U (x a) (fun i => centered hK (p a i) - GridOracle.center (label (y a i)) hK)
    Measurable (fun a => inner ℝ (g a) w + R * ‖g a‖) := by
  intro p g
  have hp : Measurable p := MeasurableFit.probability_rows hK (fun i => (op U w).continuous.measurable.comp (hx i)) hy B t
  have hg : Measurable g := grad_meas hx (fun i => ((centered_meas hK).comp ((measurable_pi_apply i).comp hp)).sub
    ((measurable_of_countable (fun j : Fin K => GridOracle.center (label j) hK)).comp ((measurable_pi_apply i).comp hy)))
  exact (hg.inner measurable_const).add (measurable_const.mul hg.norm)

private theorem generic_pick {F : Type*} {m N : ℕ} (pt : (Fin m → Fin (N+1)) → F)
    (l : List (Fin m → Fin (N+1))) (f : T → F → ℝ) (h : ∀ w, Measurable (fun a => f a w)) :
    Measurable (fun a => ScoreSearch.best (fun i => f a (pt i)) (l.headD (fun _ => 0)) l) :=
  MeasurableFit.best (fun i => h (pt i)) _ _

private theorem varying {I V : Type*} [MeasurableSpace I] [MeasurableSingletonClass I] [Countable I]
    [MeasurableSpace V] (key : T → I) (hm : Measurable key) (f : I → T → V)
    (hf : ∀ i, Measurable (f i)) : Measurable (fun t => f (key t) t) :=
  (measurable_from_prod_countable_left (f := fun z : T × I => f z.2 z.1) hf).comp (measurable_id.prodMk hm)

theorem scores {U : Submodule ℝ X} [FiniteDimensional ℝ U] {x : T → Fin n → X} {y : T → Fin n → Fin K}
    (hx : ∀ i, Measurable (fun a => x a i)) (hy : Measurable y)
    (hK : 2 ≤ K) {R : ℝ} (hR : 0 < R) (L B lam η : ℝ) {z : T → X} (hz : Measurable z) :
    Measurable (fun a => matrix U hK (x a) (y a) hR L B lam η (z a)) := by
  let m := Module.finrank ℝ U*Module.finrank ℝ (H K)
  let h := PrescribedGrid.mesh L R B η
  let t := tolerance n m R L lam η
  let f a (w : ScoreGrid.V m) := let p := rows hK (fun i => op U w (x a i)) (y a) B t
                                 let g := grad U (x a) (fun i => centered hK (p i) - GridOracle.center (label (y a i)) hK)
                                 inner ℝ g w + R*‖g‖
  let N := PrescribedGrid.level m R h
  let pt (a : Fin m → Fin (N+1)) := (ScoreGrid.point hR a).val
  let pick := fun a => choice U hK (x a) (y a) hR L B lam η
  have hm : Measurable pick := generic_pick pt (candidates hR h) f (fixed_gap hx hy hK R B t)
  exact varying pick hm (fun i a => op U (pt i) (z a)) (fun i => (op U (pt i)).continuous.measurable.comp hz)

private abbrev Data (n K : ℕ) (B : ℝ) := {d : (Fin n → H K) × (Fin n → E K) × H K //
  (∀ i, d.2.1 i ∈ Simplex K) ∧ ∀ i j, ‖d.2.1 i-d.2.1 j‖ ≤ B*‖d.1 i-d.1 j‖}

private noncomputable def value (hK : 2 ≤ K) (hn : 1 ≤ n) {B : ℝ} (hB : 0 < B) (d : Data n K B) :=
  FiniteLearner.extend hK hn d.val.1 d.val.2.1 hB d.property.1 d.property.2 d.val.2.2

attribute [local irreducible] FiniteLearner.extend

private theorem continuous_value (hK : 2 ≤ K) (hn : 1 ≤ n) {B : ℝ} (hB : 0 < B) :
    Continuous (value hK hn hB) := by
  unfold value
  exact QueryContinuity.joint (T:=Data n K B) hK hn hB (fun d => d.val.1) (fun d => d.val.2.1)
    (fun d => d.val.2.2) (continuous_fst.comp continuous_subtype_val)
    (continuous_fst.comp (continuous_snd.comp continuous_subtype_val))
    (continuous_snd.comp (continuous_snd.comp continuous_subtype_val))
    (fun d => d.property.1) (fun d => d.property.2)

/-- Borel evaluation when the stored data and the query are measurable. -/
theorem evaluate {s : T → Fin n → H K} {p : T → Fin n → E K} {z : T → H K}
    (hK : 2 ≤ K) (hn : 1 ≤ n) {B : ℝ} (hB : 0 < B)
    (hs : Measurable s) (hp : Measurable p) (hz : Measurable z)
    (mem : ∀ t i, p t i ∈ Simplex K) (cap : ∀ t i j, ‖p t i-p t j‖ ≤ B*‖s t i-s t j‖) :
    Measurable (fun t => FiniteLearner.extend hK hn (s t) (p t) hB (mem t) (cap t) (z t)) := by
  let data (t : T) : Data n K B := ⟨(s t,p t,z t),mem t,cap t⟩
  have hd : Measurable data := (hs.prodMk (hp.prodMk hz)).subtype_mk
  change Measurable (value hK hn hB ∘ data)
  exact (continuous_value hK hn hB).measurable.comp hd

/-- The finite learner's probability at a varying query on one fixed-span
branch. Its inputs can repeat and its output is defined on every bounded sample. -/
noncomputable def predict (U : Submodule ℝ X) [FiniteDimensional ℝ U]
    (hK : 2 ≤ K) (hn : 1 ≤ n) (x : Fin n → X) (y : Fin n → Fin K) {R B : ℝ}
    (hR : 0 < R) (hB : 0 < B) (L lam η : ℝ) (z : X) : E K := by
  classical
  let w := matrix U hK x y hR L B lam η
  let sc := fun i => w (x i)
  let p := rows hK sc y B (tolerance n (Module.finrank ℝ U*Module.finrank ℝ (H K)) R L lam η)
  exact if H : (∀ i, p i ∈ Simplex K) ∧ ∀ i j, ‖p i-p j‖ ≤ B*‖sc i-sc j‖
    then FiniteLearner.extend hK hn sc p hB H.1 H.2 (w z) else uniformVec K

theorem predict_measurable (U : Submodule ℝ X) [FiniteDimensional ℝ U]
    {x : T → Fin n → X} {y : T → Fin n → Fin K}
    (hx : ∀ i, Measurable (fun a => x a i)) (hy : Measurable y)
    (hK : 2 ≤ K) (hn : 1 ≤ n) {L R β B lam η : ℝ} (hL : 0 < L) (hR : 0 < R)
    (hβ : 0 < β) (hB : β ≤ B) (hlam : 0 < lam) (hη : 0 < η)
    {z : T → X} (hz : Measurable z) :
    Measurable (fun t => predict U hK hn (x t) (y t) hR (hβ.trans_le hB) L lam η (z t)) := by
  let W t := matrix U hK (x t) (y t) hR L B lam η
  let sc t := fun i => W t (x t i)
  let tol := tolerance n (Module.finrank ℝ U*Module.finrank ℝ (H K)) R L lam η
  let p t := rows hK (sc t) (y t) B tol
  have hsc i : Measurable (fun t => sc t i) := scores hx hy hK hR L B lam η (hx i)
  have hrows : Measurable p := MeasurableFit.probability_rows hK hsc hy B tol
  have good t : (∀ i, p t i ∈ Simplex K) ∧ ∀ i j, ‖p t i-p t j‖ ≤ B*‖sc t i-sc t j‖ := by
    let m := Module.finrank ℝ U * Module.finrank ℝ (H K)
    have ht : 0 < tol := lt_min zero_lt_one (by
      change 0 < (η/(1+2*R*Real.sqrt (m:ℝ)*L+3*lam))^2/(12*(n:ℝ))
      have nn : 0 < (n:ℝ) := by exact_mod_cast (show 0 < n by omega)
      positivity)
    obtain ⟨hN,hm,hd⟩ := levels_spec (sc t) (hβ.trans_le hB) ht
    let base : Fin n → Simplex K := fun _ => label ⟨0,by omega⟩
    have lip i j : ‖(base i).val-(base j).val‖ ≤ B*‖sc t i-sc t j‖ := by
      dsimp [base]; rw [sub_self,norm_zero]; exact mul_nonneg (hβ.trans_le hB).le (norm_nonneg _)
    exact (fit_spec hK hn hN (sc t) base (fun i => label (y t i)) (hβ.trans_le hB).le ht.le
      (min_le_left _ _) (sep_spec _).2 lip hm hd).1
  have ev := evaluate hK hn (hβ.trans_le hB) (measurable_pi_lambda _ hsc) hrows
    (scores (U:=U) hx hy hK hR L B lam η hz) (fun t => (good t).1) (fun t => (good t).2)
  convert ev using 1
  funext t; unfold predict; dsimp only; split <;> rename_i h
  · rfl
  · exact (h (good t)).elim

end UL.Arxiv.FixedSpanSearch

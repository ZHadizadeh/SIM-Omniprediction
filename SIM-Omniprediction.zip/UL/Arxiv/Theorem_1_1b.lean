import UL.Arxiv.CompactLimit
import UL.Arxiv.LimitRisk

/-! # Theorem 1.1(b) of the arXiv manuscript

Suppose every single-score fit fails for some member of the compact target family.
Pick one violating loss and comparator for each increasingly accurate fit. Under
the fit's own probabilities, the comparator's mean Bayes gap tends to zero.
Compactness of the targets and comparators, followed by rigidity at the two
extreme scores, recovers a deterministic monotone forecast almost surely.
Passing the fit inequalities to the limit then rules out every violation. -/
open Set Filter Topology MeasureTheory
open scoped NNReal
namespace UL.Arxiv.BoundedBinary
noncomputable section

private structure Challenger (d : ℕ) (A : ℝ≥0) where
  predict : Features d → Probability
  measurable_predict : Measurable predict
  target : Target A
  chooseAction : Probability → Action A
  bayes : IsBayes target chooseAction
  competitor : Features d

private def linearAction {d : ℕ} (A : ℝ≥0) (v x : Features d) : Action A := clip A (inner ℝ v x)

private theorem measurable_linearAction {d : ℕ} (A : ℝ≥0) (v : Features d) :
    Measurable (linearAction A v) := continuous_projIcc.measurable.comp
      (continuous_const.inner continuous_id).measurable

private theorem linearAction_eq {d : ℕ} {L R : ℝ≥0} {v x : Features d}
    (hv : ‖v‖ ≤ (R : ℝ)) (hx : ‖x‖ ≤ (L : ℝ)) :
    (linearAction (L*R) v x : ℝ) = inner ℝ v x := by
  simp only [linearAction, clip, Set.projIcc_of_mem _ (score_mem hv hx)]

private def Challenger.gap {d : ℕ} {A : ℝ≥0} (c : Challenger d A) (x : Features d) : ℝ :=
  loss c.target (linearAction A c.competitor x) (c.predict x) -
    loss c.target (c.chooseAction (c.predict x)) (c.predict x)

private theorem le_ball_inf {d : ℕ} {R : ℝ≥0} {risk : Features d → ℝ} {b : ℝ}
    (h : ∀ v : Features d, ‖v‖ ≤ (R : ℝ) → b ≤ risk v) :
    b ≤ ⨅ v : {v : Features d // ‖v‖ ≤ (R : ℝ)}, risk v.1 := by
  letI : Nonempty {v : Features d // ‖v‖ ≤ (R : ℝ)} := ⟨⟨0, by simp⟩⟩
  exact le_ciInf (fun v => h v.1 v.2)

theorem exact : Statement := by
  classical
  intro d Ω _ μ _ X Y hX hY L R hL hR hbound S _ hcompact hmono
  by_contra hno
  let A := L * R
  let ε (n : ℕ) : ℝ := 1 / ((n : ℝ) + 1)
  have he : Tendsto ε atTop (𝓝 0) := tendsto_one_div_add_atTop_nhds_zero_nat
  have hXi : Integrable (fun ω => ‖X ω‖) μ :=
    (integrable_const (L : ℝ)).mono' hX.norm.aestronglyMeasurable (by simpa using hbound)
  have fits (n : ℕ) : ∃ c : Challenger d A,
      c.target ∈ S ∧ ‖c.competitor‖ ≤ (R : ℝ) ∧
      (∫ ω, c.gap (X ω) ∂μ) ≤ ε n ∧
      (∀ f : ℝ → ℝ, Monotone f → ∀ C : ℝ, (∀ x, |f x| ≤ C) →
        (∫ ω, ((c.predict (X ω) : ℝ) - Y ω) * f (c.predict (X ω)) ∂μ) ≤ 0) ∧
      (∀ v : Features d, ‖v‖ ≤ (R : ℝ) →
        -(ε n) ≤ ∫ ω, ((c.predict (X ω) : ℝ) - Y ω) * (linearAction A v (X ω) : ℝ) ∂μ) := by
    let B : ℝ := ((n : ℝ) + 1) / 16
    have hB : 0 < B := by dsimp [B]; positivity
    have hε : 1 / (16 * B) = ε n := by dsimp [B, ε]; ring_nf
    obtain ⟨w, ρ, hw, hm, mρ, ht, hlin⟩ := exists_approximate_moments μ X Y hX hY hXi R B hR hB
    let F (x : Features d) := ρ (inner ℝ w x)
    have hF : Measurable F := mρ.comp (continuous_const.inner continuous_id).measurable
    have bad : ¬ (∀ σ ∈ S, ∀ k, IsBayes σ k → ∀ v : Features d, ‖v‖ ≤ (R : ℝ) →
        (∫ ω, loss σ (k (F (X ω))) (Y ω) ∂μ) ≤
          ∫ ω, loss σ (inner ℝ v (X ω)) (Y ω) ∂μ) :=
      fun h => hno ⟨w, ρ, hw, hm, mρ, fun s hs k hk => le_ball_inf (h s hs k hk)⟩
    push_neg at bad
    obtain ⟨σ, hσ, k, hk, v, hv, hbad⟩ := bad
    let c : Challenger d A := ⟨F, hF, σ, k, hk, v⟩
    have linear (v : Features d) (hv : ‖v‖ ≤ (R : ℝ)) :
        -(ε n) ≤ ∫ ω, ((F (X ω) : ℝ) - Y ω) * (linearAction A v (X ω) : ℝ) ∂μ := by
      rw [← hε]
      apply (hlin v hv).trans_eq
      apply integral_congr_ae
      filter_upwards [hbound] with ω hω
      rw [linearAction_eq hv hω]
    refine ⟨c, hσ, hv, ?_, ht, linear⟩
    apply integral_gap_le hk (hF.comp hX) hY ((measurable_linearAction A v).comp hX)
      (selector_test hk ht) (linear v hv)
    apply lt_of_eq_of_lt _ hbad
    apply integral_congr_ae
    filter_upwards [hbound] with ω hω
    rw [Function.comp_apply, linearAction_eq hv hω]
  choose c hS hv hgap htest hlinear using fits
  have hint (n : ℕ) : Integrable (fun ω => (c n).gap (X ω)) μ := by
    let P ω := (c n).predict (X ω)
    have hm : Measurable P := (c n).measurable_predict.comp hX
    exact (integrable_loss (c n).target ((measurable_linearAction A _).comp hX) hm).sub
      (integrable_loss (c n).target ((c n).bayes.monotone.measurable.comp hm) hm)
  obtain ⟨a, ha, hga⟩ := subseq_vanishing_gap hint
    (fun n ω => sub_nonneg.mpr ((c n).bayes _ _)) hgap he
  obtain ⟨z, hz, b, hb, hzb⟩ :=
    (hcompact.prod (isCompact_closedBall (0 : Features d) (R : ℝ))).tendsto_subseq
      (x := fun n => ((c (a n)).target, (c (a n)).competitor))
      (fun n => ⟨hS _, by simpa [Metric.mem_closedBall, dist_zero_right] using hv (a n)⟩)
  let σ := z.1
  let v := z.2
  have hσ : Monotone σ := hmono σ hz.1
  have hvr : ‖v‖ ≤ (R : ℝ) := by simpa [v, Metric.mem_closedBall, dist_zero_right] using hz.2
  let xlo := ((R : ℝ)⁻¹ * L) • (-v)
  let xhi := ((R : ℝ)⁻¹ * L) • v
  obtain ⟨q, j, hj, hq⟩ := CompactSpace.tendsto_subseq
    (fun n => ((c (a (b n))).predict xlo, (c (a (b n))).predict xhi))
  let i (n : ℕ) := a (b (j n))
  have hi : Tendsto i atTop atTop := ha.tendsto_atTop.comp (hb.tendsto_atTop.comp hj.tendsto_atTop)
  have hs : Tendsto (fun n => (c (i n)).target) atTop (𝓝 σ) :=
    (continuous_fst.continuousAt.tendsto.comp hzb).comp hj.tendsto_atTop
  have hvc : Tendsto (fun n => (c (i n)).competitor) atTop (𝓝 v) :=
    (continuous_snd.continuousAt.tendsto.comp hzb).comp hj.tendsto_atTop
  let ρ := limitLink σ q.1 q.2
  have hρ : Monotone ρ := monotone_limitLink hσ q.1 q.2
  let P ω := ρ (inner ℝ v (X ω))
  have hP : Measurable P := hρ.measurable.comp ((continuous_const.inner continuous_id).measurable.comp hX)
  have hc : ∀ᵐ ω ∂μ, Tendsto (fun n => (c (i n)).predict (X ω)) atTop (𝓝 (P ω)) := by
    filter_upwards [hbound, hga] with ω hω hg
    apply recover_at_feature (F := fun n => (c (i n)).predict) hL hR hvr hω
      (continuous_fst.continuousAt.tendsto.comp hq) (continuous_snd.continuousAt.tendsto.comp hq)
    intro ns hns qq hqq
    apply limit_minimizes (kn := fun n => (c (i (ns n))).chooseAction)
      (tn := fun n => linearAction A (c (i (ns n))).competitor (X ω))
      (fun n => (c (i (ns n))).bayes) (hs.comp hns) _ hqq
    · exact hg.comp (hb.tendsto_atTop.comp (hj.tendsto_atTop.comp hns))
    · exact continuous_projIcc.continuousAt.tendsto.comp ((hvc.comp hns).inner (𝕜 := ℝ) (tendsto_const_nhds (x := X ω)))
  apply hno
  refine ⟨v, ρ, hvr, hρ, hρ.measurable, ?_⟩
  intro σ' _ k hk
  apply le_ball_inf (R := R) (risk := fun v' => ∫ ω, loss σ' (inner ℝ v' (X ω)) (Y ω) ∂μ)
  intro v' hv'
  have h := limit_risk (fun n => (c (i n)).measurable_predict.comp hX) hP hY hc
    (fun n => htest (i n)) (he.comp hi) ((measurable_linearAction A v').comp hX)
    (fun n => hlinear (i n) v' hv') hk
  apply h.trans_eq
  apply integral_congr_ae
  filter_upwards [hbound] with ω hω
  rw [Function.comp_apply, linearAction_eq hv' hω]

end
end UL.Arxiv.BoundedBinary

/-- Bounded-action exact omniprediction for a compact family of continuous
nondecreasing target links, arXiv Theorem 1.1(b). -/
theorem UL.Arxiv.thm_1_1b : UL.Arxiv.BoundedBinary.Statement :=
  UL.Arxiv.BoundedBinary.exact

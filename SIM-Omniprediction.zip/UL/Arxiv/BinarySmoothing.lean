import UL.Arxiv.Theorem_1_1a

open Set MeasureTheory Filter
namespace UL.Arxiv.BinarySmoothing
open Proof_thm_3_2

abbrev I := Set.Icc (0:ℝ) 1
noncomputable def trim (δ p : ℝ) := (1-δ)*p + δ/2

private theorem trim_interior {δ p : ℝ} (hδ : 0 < δ) (h1 : δ < 1) (hp : p ∈ I) :
    trim δ p ∈ Ioo (0:ℝ) 1 := by
  dsimp [trim]
  constructor <;> nlinarith [hp.1, hp.2, mul_nonneg (sub_pos.mpr h1).le hp.1,
    mul_nonneg (sub_pos.mpr h1).le (sub_nonneg.mpr hp.2)]

noncomputable def jensenGap (φ : ↥I → ℝ) (δ : ℝ) :=
  ⨆ p : ↥I, (1-δ)*φ p + δ*extendUnitInterval φ (1/2) - extendUnitInterval φ (trim δ p)

private theorem contExt {φ : ↥I → ℝ} (hc : Continuous φ) :
    ContinuousOn (extendUnitInterval φ) I := by
  rw [continuousOn_iff_continuous_restrict]
  have he : I.restrict (extendUnitInterval φ) = φ := by
    ext q
    exact dif_pos q.2
  rwa [he]

/-- The maximal Jensen gap depends continuously on the smoothing parameter. -/
theorem continuous_jensenGap {φ : ↥I → ℝ} (hc : Continuous φ) :
    Continuous (fun δ : ↥I => jensenGap φ δ) := by
  let F := fun (δ p : ↥I) => (1-(δ:ℝ))*φ p + (δ:ℝ)*extendUnitInterval φ (1/2) - extendUnitInterval φ (trim δ p)
  have ht : Continuous (fun z : ↥I × ↥I => trim z.1 z.2) := by unfold trim; fun_prop
  have htI (z : ↥I × ↥I) : trim z.1 z.2 ∈ I := by
    obtain ⟨d,p⟩ := z
    constructor <;> dsimp [trim] <;> nlinarith [d.2.1,d.2.2,p.2.1,p.2.2,
      mul_nonneg (sub_nonneg.mpr d.2.2) p.2.1,mul_nonneg (sub_nonneg.mpr d.2.2) (sub_nonneg.mpr p.2.2)]
  have hf : Continuous ↿F := by
    apply Continuous.sub _ ((contExt hc).comp_continuous ht htI)
    dsimp [F]; fun_prop
  have H := isCompact_univ.continuous_sSup (f:=F) hf
  simpa only [image_univ] using H

theorem jensenGap_zero (φ : ↥I → ℝ) : jensenGap φ 0 = 0 := by
  simp [jensenGap,trim,extendUnitInterval,Subtype.property]

private theorem convexExt {β : ℝ} {φ : ↥I → ℝ} (hh : φ ∈ BinaryEntropyFamily β) :
    ConvexOn ℝ I (extendUnitInterval φ) := by
  have hq := (convexOn_pow (𝕜:=ℝ) 2).subset (show I ⊆ Ici (0:ℝ) from fun x hx => hx.1) (convex_Icc _ _)
  have h := hh.2.2.2.add (hq.smul (show 0 ≤ 1/(2*β) by have := hh.1; positivity))
  apply h.congr
  intro p _
  simp [Pi.add_apply, smul_eq_mul]

private theorem support {f : ℝ → ℝ} (hf : ConvexOn ℝ I f) {p q : ℝ}
    (hp : p ∈ Ioo (0:ℝ) 1) (hq : q ∈ I) (hd : DifferentiableAt ℝ f p) :
    deriv f p * (q-p) ≤ f q - f p := by
  rcases lt_trichotomy q p with h | rfl | h
  · have H := hf.slope_le_deriv (x:=q) (y:=p) hq (Ioo_subset_Icc_self hp) h hd
    rw [slope_def_field] at H
    have H' := (div_le_iff₀ (sub_pos.mpr h)).mp H
    nlinarith
  · simp
  · have H := hf.deriv_le_slope (x:=p) (y:=q) (Ioo_subset_Icc_self hp) hq h hd
    rw [slope_def_field] at H
    have H' := (le_div_iff₀ (sub_pos.mpr h)).mp H
    nlinarith

private theorem gap_le {β δ p : ℝ} {φ : ↥I → ℝ} (h : φ ∈ BinaryEntropyFamily β)
    (hδ : 0 < δ) (h1 : δ < 1) (hp : p ∈ I) :
    (1-δ)*extendUnitInterval φ p + δ*extendUnitInterval φ (1/2) - extendUnitInterval φ (trim δ p)
      ≤ jensenGap φ δ := by
  have hT : Continuous (fun p : ↥I => trim δ p.val) := by unfold trim; fun_prop
  have hc := (contExt h.2.1).comp_continuous hT (fun p => Ioo_subset_Icc_self (trim_interior hδ h1 p.2))
  have hg : Continuous (fun p : ↥I => (1-δ)*φ p + δ*extendUnitInterval φ (1/2) - extendUnitInterval φ (trim δ p)) :=
    ((continuous_const.mul h.2.1).add continuous_const).sub hc
  simpa only [extendUnitInterval, dif_pos hp] using le_ciSup (isCompact_range hg).bddAbove (⟨p,hp⟩ : ↥I)

private noncomputable def test (φ : ↥I → ℝ) (β δ p : ℝ) :=
  (extendUnitInterval φ (trim δ p) - (1/(2*β))*(trim δ p)^2) / (1-δ)

private theorem testProperties {φ : ↥I → ℝ} {β δ : ℝ} (h : φ ∈ BinaryEntropyFamily β)
    (hδ : 0 < δ) (h1 : δ < 1) :
    ContinuousOn (test φ β δ) I ∧ ConvexOn ℝ I (test φ β δ) ∧
    ∀ p ∈ I, HasDerivAt (test φ β δ) (deriv (extendUnitInterval φ) (trim δ p) - trim δ p/β) p := by
  have b := h.1
  have k := sub_pos.mpr h1
  have ht : Continuous (trim δ) := by unfold trim; fun_prop
  have hi := fun p (hp : p ∈ I) => Ioo_subset_Icc_self (trim_interior hδ h1 hp)
  refine ⟨((contExt h.2.1).comp ht.continuousOn hi |>.sub
    (continuous_const.mul (ht.pow 2)).continuousOn).div_const _, ⟨convex_Icc _ _,?_⟩, ?_⟩
  · intro x hx y hy a c ha hc hac
    have H := h.2.2.2.2 (hi x hx) (hi y hy) ha hc hac
    simp only [smul_eq_mul] at H ⊢
    have he : trim δ (a*x+c*y) = a*trim δ x + c*trim δ y := by
      unfold trim; rw [show c = 1-a by linarith]; ring
    unfold test
    rw [he]
    field_simp [k.ne'] at * <;> nlinarith
  · intro p hp
    have ht' : HasDerivAt (trim δ) (1-δ) p := by
      simpa only [trim, id_eq, mul_one] using (((hasDerivAt_id p).const_mul (1-δ)).add_const (δ/2))
    have hd := (h.2.2.1 _ (trim_interior hδ h1 hp)).hasDerivAt.comp p ht'
    convert (hd.sub ((ht'.pow 2).const_mul (1/(2*β)))).div_const (1-δ) using 1 <;>
      dsimp [test] <;> field_simp [k.ne', b.ne'] <;> ring

/-- Pointwise bound whose convex-test and own-score terms are integrated in the proof. -/
private theorem pointwise {φ : ↥I → ℝ} {β δ p : ℝ} (h : φ ∈ BinaryEntropyFamily β)
    (hδ : 0 < δ) (h1 : δ < 1) (hp : p ∈ I) (y : Fin 2) :
    binaryMatchingLoss φ (deriv (extendUnitInterval φ) (trim δ p)) y ≤
      -extendUnitInterval φ p + (p-yReal y)*p/β +
      (p-yReal y)*deriv (test φ β δ) p + jensenGap φ δ/(1-δ) + δ/(16*β) := by
  let t := trim δ p
  let g := deriv (extendUnitInterval φ) t
  have ht := trim_interior hδ h1 hp
  have tan := fun q (hq : q ∈ I) => support (convexExt h) ht hq (h.2.2.1 _ ht)
  have pot : binaryMatchingPotential φ g ≤ t*g-extendUnitInterval φ t := by
    apply ciSup_le
    intro q
    have hh := tan q q.property
    rw [extendUnitInterval, dif_pos q.property] at hh
    change (q:ℝ)*g-φ q ≤ t*g-extendUnitInterval φ t
    change g*((q:ℝ)-t) ≤ _ at hh
    linarith
  have mid := tan (1/2) (by constructor <;> norm_num)
  change g*(1/2-t) ≤ extendUnitInterval φ (1/2)-extendUnitInterval φ t at mid
  have J := gap_le h hδ h1 hp
  have ht' : 1/2-t = (1-δ)*(1/2-p) := by dsimp [t,trim]; ring
  rw [ht'] at mid
  have hs : -(1/16:ℝ) ≤ (p-yReal y)*(p-1/2) := by
    fin_cases y <;> norm_num [yReal] <;> nlinarith [sq_nonneg (p-1/4),sq_nonneg (p-3/4)]
  have b := h.1
  rw [((testProperties h hδ h1).2.2 p hp).deriv]
  change binaryMatchingPotential φ g - yReal y*g ≤ _
  apply le_trans (sub_le_sub_right pot _)
  change t*g-extendUnitInterval φ t-yReal y*g ≤ -extendUnitInterval φ p + (p-yReal y)*p/β +
    (p-yReal y)*(g-t/β) + jensenGap φ δ/(1-δ) + δ/(16*β)
  have hm := mul_nonneg hδ.le (sub_nonneg.mpr mid)
  have hj := sub_nonneg.mpr J
  have hsq := mul_nonneg (mul_nonneg hδ.le (sub_pos.mpr h1).le) (sub_nonneg.mpr hs)
  change 0 ≤ jensenGap φ δ - ((1-δ)*extendUnitInterval φ p + δ*extendUnitInterval φ (1/2) - extendUnitInterval φ t) at hj
  have k := sub_pos.mpr h1
  apply (le_of_sub_nonneg _)
  apply (nonneg_of_mul_nonneg_right (a := (1-δ)*β) _ (mul_pos k b))
  have he : t = (1-δ)*p + δ/2 := rfl
  let u := extendUnitInterval φ t
  change 0 ≤ _ * (_ - (t*g-u-yReal y*g))
  change 0 ≤ δ * (extendUnitInterval φ (1/2) - u - g*((1-δ)*(1/2-p))) at hm
  change 0 ≤ jensenGap φ δ - ((1-δ)*extendUnitInterval φ p + δ*extendUnitInterval φ (1/2) - u) at hj
  rw [he]
  field_simp [k.ne', b.ne', k, b]
  nlinarith [mul_nonneg b.le hm, mul_nonneg b.le hj]

private theorem smoothed_fit
    (d : ℕ) (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin 2)
    (hX_meas : Measurable X) (hY_meas : Measurable Y)
    (C : Set (EuclideanSpace ℝ (Fin d))) (hC : C.Nonempty)
    (β : ℝ) (hβ : 0 < β)
    (hX_int : MeasureTheory.Integrable (fun ω => ‖X ω‖) μ)
    (w : EuclideanSpace ℝ (Fin d))
    (P : Ω → ℝ) (hP_meas : Measurable P) (hP_mem : ∀ ω : Ω, P ω ∈ Set.Icc (0 : ℝ) 1)
    (h_end : ∀ᵐ ω ∂μ, (P ω = 0 → Y ω = 0) ∧ (P ω = 1 → Y ω = 1))
    (h_own : ∫ ω, fitRes P Y ω * P ω ∂μ ≤ β * ∫ ω, fitRes P Y ω * inner ℝ w (X ω) ∂μ)
    (h_fp : ∀ v : EuclideanSpace ℝ (Fin d), v ∈ C →
      ∫ ω, fitRes P Y ω * inner ℝ w (X ω) ∂μ ≤ ∫ ω, fitRes P Y ω * inner ℝ v (X ω) ∂μ)
    (h_conv_test : ∀ F : ℝ → ℝ,
      ContinuousOn F (Set.Icc (0 : ℝ) 1) →
      ConvexOn ℝ (Set.Icc (0 : ℝ) 1) F →
      (∀ q ∈ Set.Ioo (0 : ℝ) 1, DifferentiableAt ℝ F q) →
      MeasureTheory.Integrable
        (fun ω => if P ω ∈ Set.Ioo (0 : ℝ) 1 then fitRes P Y ω * deriv F (P ω) else 0) μ ∧
      (∫ ω, (if P ω ∈ Set.Ioo (0 : ℝ) 1 then fitRes P Y ω * deriv F (P ω) else 0) ∂μ) ≤ 0) :
    ∀ φ ∈ BinaryEntropyFamily β, ∀ δ : ℝ, 0 < δ → δ < 1 →
      let loss := fun ω => binaryMatchingLoss φ (deriv (extendUnitInterval φ) (trim δ (P ω))) (Y ω)
      Integrable loss μ ∧
      (∫ ω, loss ω ∂μ) ≤ sInf ((fun v : EuclideanSpace ℝ (Fin d) =>
        ∫ ω, binaryMatchingLoss φ (inner ℝ v (X ω)) (Y ω) ∂μ) '' C) +
        jensenGap φ δ/(1-δ) + δ/(16*β) := by
  intro φ hh δ hδ h1 loss
  obtain ⟨hc,hcv,hd⟩ := testProperties hh hδ h1
  obtain ⟨hi,hn⟩ := h_conv_test _ hc hcv fun p hp => (hd p (Ioo_subset_Icc_self hp)).differentiableAt
  let T := fun ω => fitRes P Y ω * deriv (test φ β δ) (P ω)
  have he : (fun ω => if P ω ∈ Ioo (0:ℝ) 1 then T ω else 0) =ᵐ[μ] T := by
    filter_upwards [h_end] with ω hω
    by_cases h : P ω ∈ Ioo (0:ℝ) 1
    · simp [h]
    · have hm := hP_mem ω
      have E : P ω = 0 ∨ P ω = 1 := by
        by_contra! hh
        exact h ⟨lt_of_le_of_ne hm.1 hh.1.symm,lt_of_le_of_ne hm.2 hh.2⟩
      rcases E with e|e
      · simp [h,T,fitRes,e,hω.1 e,yReal]
      · simp [h,T,fitRes,e,hω.2 e,yReal]
  have hTi : Integrable T μ := hi.congr he
  have hTn : (∫ ω, T ω ∂μ) ≤ 0 := (integral_congr_ae he) ▸ hn
  have hφ_cont := hh.2.1
  have hφP_meas : Measurable (fun ω => φ ⟨P ω, hP_mem ω⟩) :=
    hφ_cont.measurable.comp (hP_meas.subtype_mk)
  obtain ⟨C_φ, hC_φ⟩ := isCompact_univ.exists_bound_of_continuousOn hφ_cont.continuousOn
  have hφP_int : MeasureTheory.Integrable (fun ω => φ ⟨P ω, hP_mem ω⟩) μ := by
    refine MeasureTheory.Integrable.of_bound hφP_meas.aestronglyMeasurable C_φ ?_
    filter_upwards with ω
    exact hC_φ ⟨P ω, hP_mem ω⟩ (Set.mem_univ _)
  have hrP_int : MeasureTheory.Integrable (fun ω => fitRes P Y ω * P ω) μ := by
    have hm : Measurable (fun ω => fitRes P Y ω * P ω) :=
      (hP_meas.sub (measurable_yReal hY_meas)).mul hP_meas
    refine MeasureTheory.Integrable.of_bound hm.aestronglyMeasurable 1 ?_
    filter_upwards with ω
    rw [Real.norm_eq_abs, abs_mul]
    calc
      |fitRes P Y ω| * |P ω| ≤ 1 * 1 := by
        gcongr
        · exact abs_fitRes_le_one hP_mem Y ω
        · rw [abs_of_nonneg (hP_mem ω).1]
          exact (hP_mem ω).2
      _ = 1 := one_mul 1

  let c := jensenGap φ δ/(1-δ) + δ/(16*β)
  let upper := fun ω => -φ ⟨P ω,hP_mem ω⟩ + (1/β)*(fitRes P Y ω*P ω) + T ω + c
  have ui : Integrable upper μ := ((hφP_int.neg.add (hrP_int.const_mul _)).add hTi).add (integrable_const _)
  have lu : loss ≤ᵐ[μ] upper := Filter.Eventually.of_forall fun ω => by
    have hp := pointwise hh hδ h1 (hP_mem ω) (Y ω)
    rw [extendUnitInterval, dif_pos (hP_mem ω)] at hp
    dsimp only [upper,loss,T,c,fitRes]
    convert hp using 1 <;> ring
  let lab := fun y => (⟨yReal y, yReal_mem_Icc y⟩ : ↥I)
  have yl : (fun ω => -φ (lab (Y ω))) ≤ᵐ[μ] loss := Filter.Eventually.of_forall fun ω => by
    simpa only [lab,sub_self,zero_mul,add_zero] using
      fenchel_binaryMatchingLoss hφ_cont (lab (Y ω)) (deriv (extendUnitInterval φ) (trim δ (P ω))) (Y ω)
  have yi : Integrable (fun ω => -φ (lab (Y ω))) μ := by
    apply Integrable.of_bound ((measurable_of_finite (fun y => -φ (lab y))).comp hY_meas).aestronglyMeasurable C_φ
    exact Filter.Eventually.of_forall fun ω => by simpa using hC_φ (lab (Y ω)) (Set.mem_univ _)
  have hm : Measurable (fun ω => deriv (extendUnitInterval φ) (trim δ (P ω))) :=
    (measurable_deriv _).comp ((((measurable_const.mul hP_meas).add measurable_const)))
  have li : Integrable loss μ := integrable_of_le_of_le
    (((continuous_binaryMatchingPotential hφ_cont).measurable.comp hm).sub ((measurable_yReal hY_meas).mul hm)).aestronglyMeasurable
    yl lu yi ui
  have hu := integral_mono_ae li ui lu
  have hu' : (∫ ω, upper ω ∂μ) = -(∫ ω, φ ⟨P ω,hP_mem ω⟩ ∂μ)
      + (1/β)*(∫ ω,fitRes P Y ω*P ω ∂μ) + (∫ ω,T ω ∂μ) + c := by
    unfold upper
    let v := fun ω => (1/β)*(fitRes P Y ω*P ω)
    let f := fun ω => -φ ⟨P ω,hP_mem ω⟩
    have hfi : Integrable f μ := hφP_int.neg
    have hvi : Integrable v μ := hrP_int.const_mul _
    change (∫ ω, (f ω+v ω+T ω)+c ∂μ) = _
    rw [integral_add (f:=fun ω => f ω+v ω+T ω) (g:=fun _ => c) ((hfi.add hvi).add hTi) (integrable_const _),
      integral_add (f:=fun ω => f ω+v ω) (g:=T) (hfi.add hvi) hTi,
      integral_add hfi hvi]
    simp [f,v,integral_const_mul]
    exact integral_neg _
  rw [hu'] at hu
  have h_match := (entropy_loss_comparison_on_weights d Ω μ X Y hX_meas hY_meas C hC β hβ hX_int
    w P hP_meas hP_mem h_end h_own h_fp h_conv_test φ hh).2.2.1
  refine ⟨li, ?_⟩
  change (∫ ω, loss ω ∂μ) ≤ _ + _ + _
  rw [add_assoc, ← sub_le_iff_le_add]
  apply le_csInf (hC.image _)
  rintro _ ⟨v,hv,rfl⟩
  have h_score_lb : (1 / β) * ∫ ω, fitRes P Y ω * P ω ∂μ ≤
      ∫ ω, fitRes P Y ω * inner ℝ v (X ω) ∂μ := by
    have hwv := h_fp v hv
    have hdiv : (1 / β) * ∫ ω, fitRes P Y ω * P ω ∂μ ≤
        ∫ ω, fitRes P Y ω * inner ℝ w (X ω) ∂μ := by
      rw [one_div, inv_mul_le_iff₀ hβ]
      linarith
    exact le_trans hdiv hwv
  have h_fenchel_int : -(∫ ω, φ ⟨P ω, hP_mem ω⟩ ∂μ) +
        (∫ ω, fitRes P Y ω * inner ℝ v (X ω) ∂μ) ≤
      ∫ ω, binaryMatchingLoss φ (inner ℝ v (X ω)) (Y ω) ∂μ := by
    have hrv_int := integrable_res_inner d μ hX_meas hY_meas hX_int hP_meas hP_mem v
    have hneg_int : MeasureTheory.Integrable (fun ω => -φ ⟨P ω, hP_mem ω⟩) μ := hφP_int.neg
    have hsum_eq : -(∫ ω, φ ⟨P ω, hP_mem ω⟩ ∂μ) +
          (∫ ω, fitRes P Y ω * inner ℝ v (X ω) ∂μ) =
        ∫ ω, (-φ ⟨P ω, hP_mem ω⟩ + fitRes P Y ω * inner ℝ v (X ω)) ∂μ := by
      rw [MeasureTheory.integral_add hneg_int hrv_int, MeasureTheory.integral_neg]
    rw [hsum_eq]
    refine MeasureTheory.integral_mono (hneg_int.add hrv_int) (h_match v hv) fun ω => ?_
    exact fenchel_binaryMatchingLoss hφ_cont ⟨P ω, hP_mem ω⟩ (inner ℝ v (X ω)) (Y ω)
  dsimp [c] at hu
  linarith


/-- A single monotone single-index forecast obeys both the exact and the
finite-action comparisons. The smoothing parameter may depend on the loss. -/
theorem binary_finite_action_refinement
    (d : ℕ) (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin 2)
    (hX_meas : Measurable X) (hY_meas : Measurable Y)
    (C : Set (EuclideanSpace ℝ (Fin d))) (hCne : C.Nonempty) (hCcomp : IsCompact C) (hCconv : Convex ℝ C)
    (β : ℝ) (hβ : 0 < β)
    (hX_int : MeasureTheory.Integrable (fun ω => ‖X ω‖) μ)
    : ∃ w ∈ C, ∃ ρ : ℝ → ℝ, IsProfile β ρ ∧
      let P := fun ω => ρ (inner ℝ w (X ω))
      ∀ φ ∈ BinaryEntropyFamily β,
        let benchmark := sInf ((fun v : EuclideanSpace ℝ (Fin d) =>
          ∫ ω, binaryMatchingLoss φ (inner ℝ v (X ω)) (Y ω) ∂μ) '' C)
        (∫ ω, (binaryExtendedCanonicalLoss φ (P ω) (Y ω)).toReal ∂μ) ≤ benchmark ∧
        ∀ δ : ℝ, 0 < δ → δ < 1 →
          let loss := fun ω => binaryMatchingLoss φ (deriv (extendUnitInterval φ) (trim δ (P ω))) (Y ω)
          Integrable loss μ ∧ (∫ ω, loss ω ∂μ) ≤ benchmark + jensenGap φ δ/(1-δ) + δ/(16*β) := by
  obtain ⟨w,hw,ρ,hρ,hend,ho,hfp,hconv⟩ := BinaryGlobal.fixed_fit d Ω μ X Y hX_meas hY_meas
    C hCne hCcomp hCconv β hβ hX_int
  let P := fun ω => ρ (inner ℝ w (X ω))
  have hm : Measurable P := hρ.measurable.comp ((continuous_const.inner continuous_id).measurable.comp hX_meas)
  have hmem := fun ω => hρ.2.2 (inner ℝ w (X ω))
  refine ⟨w,hw,ρ,hρ,fun φ hh => ⟨?_,?_⟩⟩
  · exact (entropy_loss_comparison_on_weights d Ω μ X Y hX_meas hY_meas C hCne β hβ hX_int
      w P hm hmem hend ho hfp hconv φ hh).2.2.2.2
  · exact smoothed_fit d Ω μ X Y hX_meas hY_meas C hCne β hβ hX_int w P hm hmem hend ho hfp hconv φ hh

end UL.Arxiv.BinarySmoothing

import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus
import Mathlib.MeasureTheory.Constructions.BorelSpace.Order
import Mathlib.Analysis.Normed.Lp.MeasurableSpace
import Mathlib.Topology.ContinuousMap.Compact
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

/-! # Theorem 1.1(b) · Single-score existence for bounded actions

`Statement` is the full population existence proposition. The declarations below it
give Bayes actions, the loss integrability bounds, and the residual comparison.
The proof of the full statement is in `UL.Arxiv.Theorem_1_1b`.
-/

open MeasureTheory Set
open scoped NNReal

namespace UL.Arxiv.BoundedBinary
noncomputable section

abbrev Probability := Set.Icc (0 : ℝ) 1
abbrev Action (A : ℝ≥0) := Set.Icc (-(A : ℝ)) (A : ℝ)
abbrev Target (A : ℝ≥0) := C(Action A, Probability)
abbrev Features (d : ℕ) := EuclideanSpace ℝ (Fin d)

variable {A : ℝ≥0}

def clip (A : ℝ≥0) : ℝ → Action A :=
  Set.projIcc _ _ (neg_le_self A.coe_nonneg)

def slope (σ : Target A) (t : ℝ) : ℝ := σ (clip A t)

def potential (σ : Target A) (t : ℝ) : ℝ := ∫ s in (0 : ℝ)..t, slope σ s

def loss (σ : Target A) (t y : ℝ) : ℝ := potential σ t - y * t

/-- A fixed choice of a minimizing action at each reported probability, including ties. -/
def IsBayes (σ : Target A) (k : Probability → Action A) : Prop :=
  ∀ (q : Probability) (t : Action A), loss σ (k q) q ≤ loss σ t q

/-- Every comparison uses the same forecast; the linear comparator may depend on σ.
Using continuous maps on the compact interval gives the topology of uniform convergence. -/
def Statement : Prop :=
  ∀ (d : ℕ) (Ω : Type*) [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    (X : Ω → Features d) (Y : Ω → Probability), Measurable X → Measurable Y →
    ∀ (L R : ℝ≥0), 0 < L → 0 < R → (∀ᵐ ω ∂μ, ‖X ω‖ ≤ (L : ℝ)) →
    ∀ (S : Set (Target (L * R))), S.Nonempty → IsCompact S →
    (∀ σ ∈ S, Monotone σ) →
    ∃ (w : Features d) (ρ : ℝ → Probability), ‖w‖ ≤ (R : ℝ) ∧ Monotone ρ ∧ Measurable ρ ∧
      ∀ σ ∈ S, ∀ k : Probability → Action (L * R), IsBayes σ k →
        (∫ ω, loss σ (k (ρ (inner ℝ w (X ω)))) (Y ω) ∂μ) ≤
          ⨅ v : {v : Features d // ‖v‖ ≤ (R : ℝ)},
            ∫ ω, loss σ (inner ℝ v.1 (X ω)) (Y ω) ∂μ

theorem continuous_slope (σ : Target A) : Continuous (slope σ) :=
  continuous_subtype_val.comp (σ.continuous.comp continuous_projIcc)

theorem continuous_potential (σ : Target A) : Continuous (potential σ) :=
  intervalIntegral.continuous_primitive ((continuous_slope σ).intervalIntegrable) 0

theorem continuous_loss (σ : Target A) : Continuous (fun z : ℝ × ℝ => loss σ z.1 z.2) :=
  ((continuous_potential σ).comp continuous_fst).sub (continuous_snd.mul continuous_fst)

theorem exists_bayes (σ : Target A) : ∃ k, IsBayes σ k := by
  classical
  have h (q : Probability) : ∃ t : Action A, ∀ b : Action A, loss σ t q ≤ loss σ b q := by
    have hcont : Continuous (fun t : Action A => loss σ t q) :=
      (continuous_loss σ).comp (continuous_subtype_val.prodMk continuous_const)
    have hne : (Set.univ : Set (Action A)).Nonempty := ⟨clip A 0, trivial⟩
    obtain ⟨t, _, ht⟩ := isCompact_univ.exists_isMinOn hne hcont.continuousOn
    exact ⟨t, fun b => ht (Set.mem_univ b)⟩
  exact ⟨fun q => (h q).choose, fun q => (h q).choose_spec⟩

theorem IsBayes.monotone {σ : Target A} {k : Probability → Action A} (hk : IsBayes σ k) :
    Monotone k := by
  intro p q hpq
  rcases eq_or_lt_of_le hpq with rfl | hlt
  · exact le_rfl
  have h₁ := hk p (k q)
  have h₂ := hk q (k p)
  change (k p : ℝ) ≤ (k q : ℝ)
  change (p : ℝ) < q at hlt
  unfold loss at h₁ h₂
  by_contra! hbad
  nlinarith [mul_pos (sub_pos.mpr hlt) (sub_pos.mpr hbad)]

theorem score_mem {d : ℕ} {L R : ℝ≥0} {v x : Features d}
    (hv : ‖v‖ ≤ (R : ℝ)) (hx : ‖x‖ ≤ (L : ℝ)) :
    inner ℝ v x ∈ Set.Icc (-((L * R : ℝ≥0) : ℝ)) ((L * R : ℝ≥0) : ℝ) := by
  apply abs_le.mp
  calc
    |inner ℝ v x| ≤ ‖v‖ * ‖x‖ := abs_real_inner_le_norm v x
    _ ≤ (R : ℝ) * L := mul_le_mul hv hx (norm_nonneg _) R.coe_nonneg
    _ = _ := mul_comm _ _

private theorem integrable_compact_eval {Ω E : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsFiniteMeasure μ] [TopologicalSpace E] [CompactSpace E]
    [MeasurableSpace E] [OpensMeasurableSpace E] (f : C(E, ℝ)) {z : Ω → E}
    (hz : Measurable z) : Integrable (fun ω => f (z ω)) μ :=
  (integrable_const ‖f‖).mono' (f.continuous.measurable.comp hz).aestronglyMeasurable
    (Filter.Eventually.of_forall (fun ω => f.norm_coe_le_norm (z ω)))

variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]

theorem integrable_loss (σ : Target A) {t : Ω → Action A} {Y : Ω → Probability}
    (ht : Measurable t) (hY : Measurable Y) : Integrable (fun ω => loss σ (t ω) (Y ω)) μ := by
  let f : C(Action A × Probability, ℝ) :=
    ⟨fun z => loss σ z.1 z.2, (continuous_loss σ).comp
      ((continuous_subtype_val.comp continuous_fst).prodMk (continuous_subtype_val.comp continuous_snd))⟩
  exact integrable_compact_eval f (ht.prodMk hY)

theorem integrable_test {P Y : Ω → Probability} {a : Ω → Action A}
    (hP : Measurable P) (hY : Measurable Y) (ha : Measurable a) :
    Integrable (fun ω => ((P ω : ℝ) - Y ω) * (a ω : ℝ)) μ := by
  let f : C((Probability × Probability) × Action A, ℝ) := ⟨fun z =>
    ((z.1.1 : ℝ) - z.1.2) * (z.2 : ℝ), by fun_prop⟩
  exact integrable_compact_eval f ((hP.prodMk hY).prodMk ha)

theorem integral_change_label (σ : Target A) {a : Ω → Action A} {Y P : Ω → Probability}
    (ha : Measurable a) (hY : Measurable Y) (hP : Measurable P) :
    (∫ ω, loss σ (a ω) (Y ω) ∂μ) =
      (∫ ω, loss σ (a ω) (P ω) ∂μ) + ∫ ω, ((P ω : ℝ) - Y ω) * (a ω : ℝ) ∂μ := by
  rw [← integral_add (integrable_loss σ ha hP) (integrable_test hP hY ha)]
  apply integral_congr_ae
  filter_upwards with ω
  unfold loss
  ring

/-- The risk comparison in Appendix A.2 from the two residual inequalities.
The allowance ε also applies to a finite-slope approximate fit. -/
theorem risk_le_of_residual {σ : Target A} {k : Probability → Action A} (hk : IsBayes σ k)
    {P Y : Ω → Probability} {t : Ω → Action A} (hP : Measurable P)
    (hY : Measurable Y) (ht : Measurable t) {ε : ℝ}
    (hreport : (∫ ω, ((P ω : ℝ) - Y ω) * (k (P ω) : ℝ) ∂μ) ≤ 0)
    (hlinear : -ε ≤ ∫ ω, ((P ω : ℝ) - Y ω) * (t ω : ℝ) ∂μ) :
    (∫ ω, loss σ (k (P ω)) (Y ω) ∂μ) ≤ (∫ ω, loss σ (t ω) (Y ω) ∂μ) + ε := by
  have hkP : Measurable (fun ω => k (P ω)) := hk.monotone.measurable.comp hP
  have hmin := integral_mono (integrable_loss (μ := μ) σ hkP hP) (integrable_loss σ ht hP)
    (fun ω => hk (P ω) (t ω))
  rw [integral_change_label σ hkP hY hP, integral_change_label σ ht hY hP]
  linarith

end
end UL.Arxiv.BoundedBinary

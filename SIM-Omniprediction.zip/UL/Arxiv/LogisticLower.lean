import UL.Arxiv.LogisticExperiment

open MeasureTheory Real Set
namespace UL.Arxiv.Logistic
open Proof_prop_C_5_Race2

noncomputable def logit (p : ℝ) := log (p/(1-p))
noncomputable def gap (z t : ℝ) := partition t - partition z - sigmoid z*(t-z)

theorem logit_sigmoid (z : ℝ) : logit (sigmoid z) = z := by
  unfold logit
  suffices sigmoid z / (1-sigmoid z) = exp z by rw [this,log_exp]
  rw [sigmoid_def,Real.exp_neg]
  have h := Real.exp_pos z
  field_simp <;> ring

/-- Conditional expected logistic action loss minus the risk of its linear
Bayes action. On boundary reports each true label probability is positive. -/
noncomputable def reportExcess (z p : ℝ) : ENNReal :=
  if p ∈ Ioo (0:ℝ) 1 then ENNReal.ofReal (gap z (logit p)) else ⊤

theorem expected_action_difference (z t : ℝ) :
    (1-sigmoid z)*partition t + sigmoid z*(partition t-t) -
    ((1-sigmoid z)*partition z + sigmoid z*(partition z-z)) = gap z t := by
  unfold gap; ring

/-- The action-space excess is exactly the ordinary Bernoulli KL divergence
between the true conditional probability and an interior forecast. -/
theorem gap_eq_bernoulli_kl (z : ℝ) {p : ℝ} (hp : p ∈ Ioo (0:ℝ) 1) :
    gap z (logit p) = sigmoid z * log (sigmoid z / p) +
      (1-sigmoid z)*log ((1-sigmoid z)/(1-p)) := by
  have formula {u : ℝ} (h : u ∈ Ioo (0:ℝ) 1) :
      partition (logit u) = -log (1-u) := by
    have h' := sub_pos.mpr h.2
    rw [logit, partition, exp_log (div_pos h.1 h')]
    have H : 1+u/(1-u) = (1-u)⁻¹ := by field_simp [h'.ne']; ring
    rw [H,log_inv]
  have hz : sigmoid z ∈ Ioo (0:ℝ) 1 := ⟨sigmoid_pos _,sigmoid_lt_one _⟩
  have e := formula hz
  rw [logit_sigmoid] at e
  have zl := logit_sigmoid z
  unfold logit at zl
  rw [log_div hz.1.ne' (sub_pos.mpr hz.2).ne'] at zl
  rw [gap,formula hp,e,logit,log_div hp.1.ne' (sub_pos.mpr hp.2).ne',
    log_div hz.1.ne' hp.1.ne', log_div (sub_pos.mpr hz.2).ne' (sub_pos.mpr hp.2).ne']
  linear_combination -(sigmoid z)*zl

theorem label_probability {d : ℕ} (hd : 1 ≤ d) (s : Sign d) :
    ∀ᵐ x ∂sphereProb d, (experiment d).prob s x 1 = sigmoid (score s x) := by
  filter_upwards [sphereProb_norm_eq_one_ae hd] with x hx
  exact probOne_on_ball hd s hx.le

private theorem gap_deriv (z t : ℝ) : HasDerivAt (gap z) (sigmoid t - sigmoid z) t := by
  convert (((partition_deriv t).sub_const (partition z)).sub
    (((hasDerivAt_id t).sub_const z).const_mul (sigmoid z))) using 1 <;> simp [gap]

theorem gap_nonneg (z t : ℝ) : 0 ≤ gap z t := by
  have d : Differentiable ℝ (gap z) := fun t => (gap_deriv z t).differentiableAt
  have r : MonotoneOn (gap z) (Ici z) :=
    monotoneOn_of_deriv_nonneg (convex_Ici _) d.continuous.continuousOn d.differentiableOn fun x hx => by
      rw [(gap_deriv z x).deriv]; exact sub_nonneg.mpr (sigmoid_monotone (interior_subset (s:=Ici z) hx))
  have l : AntitoneOn (gap z) (Iic z) :=
    antitoneOn_of_deriv_nonpos (convex_Iic _) d.continuous.continuousOn d.differentiableOn fun x hx => by
      rw [(gap_deriv z x).deriv]; exact sub_nonpos.mpr (sigmoid_monotone (interior_subset (s:=Iic z) hx))
  rcases le_total z t with h|h
  · simpa [gap] using r (self_mem_Ici) h h
  · simpa [gap] using l h (self_mem_Iic) h

theorem clipped_gap_lower {z : ℝ} (hz : z ∈ Icc (-(1/4:ℝ)) (1/4)) (t : ℝ) :
    (clip t - z)^2/10 ≤ gap z t := by
  let a := clip t
  have ha := clip_mem t
  let f := fun u => gap z u - (u-z)^2/10
  have d (u : ℝ) : HasDerivAt f (sigmoid u - sigmoid z - (u-z)/5) u := by
    convert (gap_deriv z u).sub ((((hasDerivAt_id u).sub_const z).pow 2).div_const 10) using 1 <;>
      simp only [id_eq] <;> ring
  have df : Differentiable ℝ f := fun u => (d u).differentiableAt
  have key : f z ≤ f a := by
    rcases le_total z a with h|h
    · apply monotoneOn_of_deriv_nonneg (convex_Icc z a) df.continuous.continuousOn df.differentiableOn _ (left_mem_Icc.mpr h) (right_mem_Icc.mpr h) h
      intro u hu
      have h' : u ∈ Icc z a := interior_subset hu
      have hbox : u ∈ Icc (-(1/4:ℝ)) (1/4) := ⟨hz.1.trans h'.1,h'.2.trans ha.2⟩
      rw [(d u).deriv]; linarith [sigmoid_slope_lower hz hbox h'.1]
    · apply antitoneOn_of_deriv_nonpos (convex_Icc a z) df.continuous.continuousOn df.differentiableOn _ (left_mem_Icc.mpr h) (right_mem_Icc.mpr h) h
      intro u hu
      have h' : u ∈ Icc a z := interior_subset hu
      have hbox : u ∈ Icc (-(1/4:ℝ)) (1/4) := ⟨ha.1.trans h'.1,h'.2.trans hz.2⟩
      rw [(d u).deriv]; linarith [sigmoid_slope_lower hbox hz h'.2]
  have proj : (sigmoid a-sigmoid z)*(t-a) ≥ 0 := by
    by_cases h : t < -(1/4:ℝ)
    · have ha' : a = -(1/4:ℝ) := by dsimp [a,clip]; rw [min_eq_right (by linarith),max_eq_left h.le]
      rw [ha']; exact mul_nonneg_of_nonpos_of_nonpos (sub_nonpos.mpr (sigmoid_monotone hz.1)) (by linarith)
    by_cases h' : 1/4 < t
    · have ha' : a = (1/4:ℝ) := by dsimp [a,clip]; rw [min_eq_left h'.le,max_eq_right (by norm_num)]
      rw [ha']; exact mul_nonneg (sub_nonneg.mpr (sigmoid_monotone hz.2)) (by linarith)
    · rw [show a = t from clip_id ⟨le_of_not_gt h,le_of_not_gt h'⟩]; simp
  have chain : gap z t = gap z a + gap a t + (sigmoid a - sigmoid z)*(t-a) := by unfold gap; ring
  rw [chain]
  have zero : gap z z = 0 := by simp [gap]
  change gap z z - (z-z)^2/10 ≤ gap z a - (a-z)^2/10 at key
  rw [zero] at key
  linarith [gap_nonneg a t]

theorem report_lower {z : ℝ} (hz : z ∈ Icc (-(1/4:ℝ)) (1/4)) (p : ℝ) :
    ENNReal.ofReal ((clip (logit p)-z)^2/10) ≤ reportExcess z p := by
  unfold reportExcess; split_ifs <;> first | exact le_top | exact ENNReal.ofReal_le_ofReal (clipped_gap_lower hz _)

noncomputable def regret {d : ℕ} (s : Sign d) (p : Feature d → ℝ) :=
  ∫⁻ x, reportExcess (score s x) (p x) ∂sphereProb d

theorem linear_bayes {d : ℕ} (s : Sign d) : regret s (fun x => sigmoid (score s x)) = 0 := by
  simp [regret,reportExcess,Real.sigmoid_pos,Real.sigmoid_lt_one,Set.mem_Ioo,logit_sigmoid,gap]

/-- Finite-sample minimax statement for a probability forecast trained with any
independent random seed. The likelihood-ratio proof uses n ≤ d²/8. -/
theorem logistic_lower {d n : ℕ} (hd : 1 ≤ d) (hn : (n:ℝ) ≤ (d:ℝ)^2/8)
    {Ξ : Type*} [MeasurableSpace Ξ] (ν : Measure Ξ) [IsProbabilityMeasure ν]
    (p : (Ξ × (Fin n → Feature d × Fin 2)) × Feature d → Icc (0:ℝ) 1) (hp : Measurable p) :
    ∃ s : Sign d, observations n ν s {q | regret s (fun x => p (q,x)) < ENNReal.ofReal (1/(1280*(d:ℝ)))} ≤
      ENNReal.ofReal (5/7) := by
  haveI := sphereProb_isProb hd
  let g := fun q x => clip (logit (p (q,x)))
  have hm : Measurable (fun z : (Ξ × (Fin n → Feature d × Fin 2)) × Feature d => g z.1 z.2) :=
    continuous_clip.measurable.comp (Real.measurable_log.comp ((measurable_subtype_coe.comp hp).div
      (measurable_const.sub (measurable_subtype_coe.comp hp))))
  let b := fun q (i : Fin d) => (d:ℝ)*∫ x, x i*g q x ∂sphereProb d
  have hb (i : Fin d) : Measurable (fun q => b q i) :=
    measurable_const.mul (((((EuclideanSpace.proj i).continuous.measurable.comp measurable_snd).mul hm).stronglyMeasurable.integral_prod_right' (ν:=sphereProb d)).measurable)
  obtain ⟨s,hs⟩ := hard_sign hd hn ν b hb
  refine ⟨s,(measure_mono ?_).trans hs⟩
  intro q hq he
  let N := ((Finset.univ.filter fun i => decide (0 ≤ b q i) ≠ s i).card : ℝ)
  change (d:ℝ)/8 ≤ N at he
  have hnrm := sphereProb_norm_eq_one_ae hd
  have cov := spherical_coord_cov hd _ hnrm (sphereProb_hasSphericalFeatureSymmetry hd)
  have hgm : Measurable (g q) := hm.comp (measurable_const.prodMk measurable_id)
  have bs := isotropic_bessel_bound hd _ hnrm cov hgm (1/4) (fun x => abs_le.mpr (clip_mem _)) (weight s)
  have ham := hamming_le_sum_sq_diff (K:=2) hd (b q) s
  let f := fun x => (g q x-score s x)^2/10
  have fm : Measurable f := ((hgm.sub ((continuous_const (y:=weight s)).inner continuous_id).measurable).pow_const 2).div_const _
  have fi : Integrable f (sphereProb d) := by
    refine Integrable.of_bound fm.aestronglyMeasurable 1 ?_
    filter_upwards [hnrm] with x hx
    have a := clip_mem (logit (p (q,x)))
    have z := score_mem hd s hx.le
    rw [Real.norm_eq_abs,abs_of_nonneg (show 0 ≤ f x by dsimp [f]; positivity)]
    change (clip (logit (p (q,x))) -score s x)^2/10 ≤ 1
    nlinarith [mul_nonneg (show 0 ≤ 1/2+(clip (logit (p (q,x))) -score s x) by linarith [a.1,z.2])
      (show 0 ≤ 1/2-(clip (logit (p (q,x))) -score s x) by linarith [a.2,z.1])]
  have lb : ENNReal.ofReal (∫ x,f x ∂sphereProb d) ≤ regret s (fun x => p (q,x)) := by
    rw [ofReal_integral_eq_lintegral_ofReal fi (Filter.Eventually.of_forall fun x => by dsimp [f]; positivity)]
    apply lintegral_mono_ae
    filter_upwards [hnrm] with x hx
    exact report_lower (score_mem hd s hx.le) _
  have dimpos : (0:ℝ) < d := by positivity
  have hb' : ((1/4:ℝ)^2/(2*(d:ℝ)^2))*N ≤ (1/2:ℝ)*∫ x,(g q x-score s x)^2 ∂sphereProb d := by
    apply le_trans _ bs
    rw [show scaleA 2 = 1/4 by norm_num [scaleA]] at ham
    exact ham
  have key : 1/(1280*(d:ℝ)) ≤ ∫ x,f x ∂sphereProb d := by
    dsimp only [f]; rw [integral_div]
    have t := mul_le_mul_of_nonneg_left he (show 0 ≤ (1/4:ℝ)^2/(2*(d:ℝ)^2) by positivity)
    have heq : (1/4:ℝ)^2/(2*(d:ℝ)^2)*((d:ℝ)/8) = 1/(256*(d:ℝ)) := by field_simp; ring
    rw [heq] at t
    have eq : 1/(1280*(d:ℝ)) = (1/(256*(d:ℝ)))/5 := by ring
    rw [eq]; linarith
  exact (not_lt_of_ge ((ENNReal.ofReal_le_ofReal key).trans lb)) hq

/-- Explicit inverse-square lower bound. For every sufficiently small positive
accuracy the feature dimension is chosen before the learner. -/
theorem sample_lower_bound {ε : ℝ} (hε : 0 < ε) (hs : ε ≤ 1/5120) :
    ∃ d : ℕ, 1 ≤ d ∧ (d:ℝ) ≤ 1/(2560*ε) ∧
      ∀ n : ℕ, (n:ℝ) ≤ 1/(8*5120^2*ε^2) →
      ∀ (Ξ : Type*) [MeasurableSpace Ξ] (ν : Measure Ξ) [IsProbabilityMeasure ν]
        (p : (Ξ × (Fin n → Feature d × Fin 2)) × Feature d → Icc (0:ℝ) 1),
        Measurable p → ∃ s : Sign d,
          ‖weight s‖ = 1/4 ∧ regret s (fun x => sigmoid (score s x)) = 0 ∧
          observations n ν s {q | regret s (fun x => p (q,x)) ≤ ENNReal.ofReal ε} ≤
            ENNReal.ofReal (5/7) := by
  let k := 1/(2560*ε)
  let d := ⌊k⌋₊
  have hk : 2 ≤ k := (le_div_iff₀ (by positivity)).mpr (by linarith)
  have hu : (d:ℝ) ≤ k := Nat.floor_le (by linarith)
  have hl : k < (d:ℝ)+1 := Nat.lt_floor_add_one _
  have hd : 1 ≤ d := by exact_mod_cast (show (1:ℝ) ≤ (d:ℝ) by linarith)
  have lo : 1/(5120*ε) ≤ (d:ℝ) := by
    have e : 1/(5120*ε) = k/2 := by dsimp [k]; ring
    rw [e]; linarith
  refine ⟨d,hd,hu,?_⟩
  intro n hn Ξ _ ν _ p hp
  have hn' : (n:ℝ) ≤ (d:ℝ)^2/8 := by
    have hh := pow_le_pow_left₀ (show 0 ≤ 1/(5120*ε) by positivity) lo 2
    have heq : 1/(8*5120^2*ε^2) = (1/(5120*ε))^2/8 := by ring
    rw [heq] at hn; linarith
  obtain ⟨s,h⟩ := logistic_lower hd hn' ν p hp
  refine ⟨s,norm_weight hd s,linear_bayes s,(measure_mono ?_).trans h⟩
  intro q hq
  have hd' : (0:ℝ) < d := by positivity
  have hu' := (le_div_iff₀ (show 0 < 2560*ε by positivity)).mp hu
  have he : ε < 1/(1280*(d:ℝ)) := (lt_div_iff₀ (by positivity)).mpr (by nlinarith)
  exact lt_of_le_of_lt hq ((ENNReal.ofReal_lt_ofReal_iff (by positivity)).mpr he)

end UL.Arxiv.Logistic

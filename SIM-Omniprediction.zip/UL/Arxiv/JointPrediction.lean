import UL.Stmt.thm_5_1

namespace UL.Arxiv

/-- Joint measurability for the finite-output learner of Theorem 1.4.
Only measurability of its choice fibers and of each candidate's query rule is used. -/
theorem measurableFinitePrediction {S X Y H : Type*}
    [MeasurableSpace S] [MeasurableSpace X] [MeasurableSpace Y]
    (heads : Finset H) (select : S → H) (predict : H → X → Y)
    (hmem : ∀ s, select s ∈ heads)
    (hfiber : ∀ h ∈ heads, MeasurableSet {s | select s = h})
    (hquery : ∀ h ∈ heads, Measurable (predict h)) :
    Measurable (fun z : S × X => predict (select z.1) z.2) := by
  classical
  intro A hA
  have heq : (fun z : S × X => predict (select z.1) z.2) ⁻¹' A =
      ⋃ h : ↥heads, {s | select s = h.val} ×ˢ (predict h.val ⁻¹' A) := by
    ext z
    constructor
    · intro hz
      exact Set.mem_iUnion.mpr ⟨⟨select z.1, hmem z.1⟩, rfl, hz⟩
    · intro hz
      obtain ⟨h, hs, hx⟩ := Set.mem_iUnion.mp hz
      change select z.1 = h.val at hs
      change predict (select z.1) z.2 ∈ A
      simpa only [hs] using hx
  rw [heq]
  exact MeasurableSet.iUnion (fun h => (hfiber _ h.property).prod (hquery _ h.property hA))

/-- Specialization to matrix and probability-link pairs, in the types and
under the hypotheses exported by the learning theorem. -/
theorem thm_1_4_joint_prediction {S : Type*} [MeasurableSpace S] {d K : ℕ} {β : ℝ}
    (heads : Finset ((EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K) ×
      (ZeroSumSubspace K → EuclideanSpace ℝ (Fin K))))
    (select : S → (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K) ×
      (ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)))
    (hmem : ∀ s, select s ∈ heads)
    (hfiber : ∀ h ∈ heads, MeasurableSet {s | select s = h})
    (hcap : ∀ h ∈ heads, ∀ s t, ‖h.2 s - h.2 t‖ ≤ β * ‖s-t‖) :
    Measurable (fun z : S × EuclideanSpace ℝ (Fin d) => (select z.1).2 ((select z.1).1 z.2)) := by
  apply measurableFinitePrediction heads select (fun h x => h.2 (h.1 x)) hmem hfiber
  intro h hh
  have hLip : LipschitzWith β.toNNReal h.2 := LipschitzWith.of_dist_le' (fun s t => by
    simpa only [dist_eq_norm] using hcap h hh s t)
  exact (hLip.continuous.comp h.1.continuous).measurable

/-- The finite-candidate learner attains the simultaneous
risk guarantee and has a jointly Borel evaluation map. -/
theorem learningWithJointPrediction (h : UL.S_thm_5_1) : UL.MultiLearningStatement true := by
  intro K hK
  obtain ⟨C,hC,hR⟩ := h K hK
  refine ⟨C,hC,?_⟩
  intro d L R β lam M ε δ hL hrad hβ hlam hM m A D hε hεD hδ hδ' n hn
  obtain ⟨heads,select,valid,hm,hfib,hrisk⟩ :=
    hR d L R β lam M ε δ hL hrad hβ hlam hM hε hεD hδ hδ' n hn
  exact ⟨heads,select,⟨valid,thm_1_4_joint_prediction heads select hm hfib
    (fun h hh => (valid h hh).2.2)⟩,hm,hfib,hrisk⟩

end UL.Arxiv

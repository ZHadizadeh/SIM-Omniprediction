import UL.Arxiv.ScoreSearch
import UL.Proof.thm_5_1.H2_LossAndNet

open Set
namespace UL.Arxiv.GridOracle
open Proof_lem_C_2

abbrev E (K : ℕ) := EuclideanSpace ℝ (Fin K)
noncomputable abbrev H (K : ℕ) := ZeroSumSubspace K
abbrev Rows (n K N : ℕ) := Fin n → Fin K → Fin (N+1)

noncomputable def row {n K N : ℕ} (a : Rows n K N) (i : Fin n) : E K :=
  WithLp.toLp 2 fun j => ((a i j).val:ℝ)/N

def admissible {n K N : ℕ} (s : Fin n → H K) (B : ℝ) (a : Rows n K N) :=
  (∀ i, row a i ∈ Simplex K) ∧ ∀ i j, ‖row a i-row a j‖ ≤ B*‖s i-s j‖

noncomputable def obj {n K : ℕ} (p y : Fin n → E K) :=
  ∑ i, (1/(n:ℝ))*(‖p i-y i‖^2/2)

private def firstRow {n K : ℕ} (hK : 2 ≤ K) (N : ℕ) : Rows n K N :=
  fun _ j => if j = ⟨0,by omega⟩ then Fin.last N else 0

open Classical in
noncomputable def fit {n K : ℕ} (hK : 2 ≤ K) (N : ℕ) (s : Fin n → H K)
    (B : ℝ) (y : Fin n → E K) : Rows n K N :=
  ScoreSearch.best (fun a => obj (row a) y) (firstRow hK N)
    ((Finset.univ : Finset (Rows n K N)).filter (admissible s B)).toList

theorem fit_spec {n K N : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n) (hN : 0 < N)
    (s : Fin n → H K) (p y : Fin n → Simplex K) {B b t : ℝ} (hB : 0 ≤ B)
    (ht : 0 ≤ t) (ht' : t ≤ 1) (hs : ∀ i j, s i ≠ s j → b ≤ ‖s i-s j‖)
    (hl : ∀ i j, ‖(p i).val-(p j).val‖ ≤ B*‖s i-s j‖)
    (hm : Real.sqrt K / N ≤ t) (hh : 2*(Real.sqrt K/N) ≤ t*B*b) :
    let y' := fun i => (y i).val
    let a := fit hK N s B y'
    admissible s B a ∧ obj (row a) y' ≤ obj (fun i => (p i).val) y' + 6*t := by
  classical
  intro y' a
  let feasible := ((Finset.univ : Finset (Rows n K N)).filter (admissible s B)).toList
  have hlst : ∀ v, v ∈ feasible ↔ admissible s B v := by simp [feasible]
  have hfirst : admissible s B (firstRow hK N) := by
    have eq (i : Fin n) : row (firstRow hK N) i = EuclideanSpace.single ⟨0,by omega⟩ (1:ℝ) := by
      ext j; by_cases h : j = ⟨0,by omega⟩ <;> simp [row,firstRow,h,EuclideanSpace.single_apply,eq_comm,Nat.ne_of_gt hN]
    refine ⟨fun i => eq i ▸ Proof_lem_A_1.single_mem_simplex _,fun i j => ?_⟩
    rw [eq i,eq j,sub_self,norm_zero]; positivity
  have mem {α : Type} (f : α → ℝ) (x : α) (l : List α) : ScoreSearch.best f x l ∈ x::l := by
    induction l generalizing x with
    | nil => simp [ScoreSearch.best]
    | cons b t ih =>
      rw [ScoreSearch.best]; split_ifs <;> simp only [List.mem_cons] at * <;> grind
  have ha := mem (fun v => obj (row v) y') (firstRow hK N) feasible
  have hh' : admissible s B a := by
    change a ∈ firstRow hK N :: feasible at ha
    rcases List.mem_cons.mp ha with e|e
    · rw [e]; exact hfirst
    · exact (hlst _).mp e
  obtain ⟨z,hz,_,hobj⟩ := finiteGridMinimizerWithTies hK hN s p y (fun _ => 1/(n:ℝ))
    (by intros; positivity) (by simp [Nat.ne_of_gt (show 0 < n by omega)]) B b t hB ht ht' hs hl hm hh
  have zm : z ∈ feasible := (hlst _).mpr hz
  exact ⟨hh',(ScoreSearch.best_le (fun v => obj (row v) y') (firstRow hK N) feasible z (List.mem_cons_of_mem _ zm)).trans hobj⟩

/-- Minimum of the positive pairwise distances, capped by one. Equal scores
do not affect the denominator. -/
noncomputable def sep {n K : ℕ} (s : Fin n → H K) : ℝ := by
  classical
  exact (insert 1 (((Finset.univ : Finset (Fin n × Fin n)).filter (fun z => s z.1 ≠ s z.2)).image
    (fun z => ‖s z.1-s z.2‖))).min' (by simp)

theorem sep_spec {n K : ℕ} (s : Fin n → H K) :
    0 < sep s ∧ ∀ i j, s i ≠ s j → sep s ≤ ‖s i-s j‖ := by
  classical
  unfold sep
  constructor
  · rw [Finset.lt_min'_iff]
    intro v hv
    simp only [Finset.mem_insert,Finset.mem_image,Finset.mem_filter,Finset.mem_univ,true_and] at hv
    rcases hv with rfl | ⟨ij,h,rfl⟩
    · norm_num
    · exact norm_pos_iff.mpr (sub_ne_zero.mpr h)
  · intro i j h
    apply Finset.min'_le
    apply Finset.mem_insert_of_mem
    exact Finset.mem_image.mpr ⟨(i,j),Finset.mem_filter.mpr ⟨Finset.mem_univ _,h⟩,rfl⟩

/-- Number of subdivisions computed from sample scores and the requested precision. -/
noncomputable def levels {n K : ℕ} (s : Fin n → H K) (B t : ℝ) : ℕ :=
  ⌈max (Real.sqrt K/t) (2*Real.sqrt K/(t*B*sep s))⌉₊+1

theorem levels_spec {n K : ℕ} (s : Fin n → H K) {B t : ℝ} (hb : 0 < B) (ht : 0 < t) :
    let N := levels s B t
    0 < N ∧ Real.sqrt K / N ≤ t ∧ 2*(Real.sqrt K/N) ≤ t*B*sep s := by
  intro N
  have hd : 0 < N := Nat.zero_lt_succ _
  have h := Nat.le_ceil (max (Real.sqrt K/t) (2*Real.sqrt K/(t*B*sep s)))
  have bound : max (Real.sqrt K/t) (2*Real.sqrt K/(t*B*sep s)) ≤ (N:ℝ) :=
    h.trans (by dsimp [N,levels]; push_cast; linarith)
  have a := (div_le_iff₀ ht).mp ((le_max_left _ _).trans bound)
  have b := (div_le_iff₀ (mul_pos (mul_pos ht hb) (sep_spec s).1)).mp ((le_max_right _ _).trans bound)
  refine ⟨hd,(div_le_iff₀ (Nat.cast_pos.mpr hd)).mpr (by linarith),?_⟩
  rw [← mul_div_assoc,div_le_iff₀ (Nat.cast_pos.mpr hd)]; linarith

/-- The empirical squared distance to an optimal feasible fit is controlled
by the objective gap. The result includes repeated observations. -/
theorem sq_error {K n : ℕ} (hn : 1 ≤ n) {A B : ℝ} {Z pTilde qTilde s : Fin n → H K}
    (fitP : isOptFitAtScores A B Z s pTilde) (fitQ : ∃ ρ, isBLipPred K A B ρ ∧ ∀ i, qTilde i = ρ (s i)) :
    (∑ i, ‖qTilde i-pTilde i‖^2) ≤ (∑ i, ‖qTilde i-Z i‖^2) - ∑ i, ‖pTilde i-Z i‖^2 := by
  obtain ⟨ρ,hr,hq⟩ := fitQ
  have vi := fit_vi_fin hn fitP hr
  simp_rw [← hq] at vi
  have eq i : ‖qTilde i-Z i‖^2 = ‖pTilde i-Z i‖^2 + ‖qTilde i-pTilde i‖^2 + 2*inner ℝ (pTilde i-Z i) (qTilde i-pTilde i) := by
    calc _ = ‖(pTilde i-Z i)+(qTilde i-pTilde i)‖^2 := by congr 2; abel
         _ = _ := by rw [norm_add_sq_real]; ring
  simp_rw [eq,Finset.sum_add_distrib,← Finset.mul_sum]
  linarith

end UL.Arxiv.GridOracle

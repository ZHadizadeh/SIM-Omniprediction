import UL.Arxiv.FiniteLearner

open Set MeasureTheory
namespace UL.Arxiv.MeasurableFit
open GridOracle FiniteLearner

variable {T : Type*} [MeasurableSpace T]

private theorem vary {I V : Type*} [MeasurableSpace I] [MeasurableSingletonClass I] [Countable I]
    [MeasurableSpace V] {key : T → I} (hm : Measurable key) {f : I → T → V}
    (hf : ∀ i, Measurable (f i)) : Measurable (fun t => f (key t) t) :=
  (measurable_from_prod_countable_left (f := fun z : T × I => f z.2 z.1) hf).comp (measurable_id.prodMk hm)

/-- The first minimum of a fixed finite list is a measurable index when each
candidate has a measurable score. This includes ties. -/
theorem best {I : Type*} [MeasurableSpace I] {f : T → I → ℝ} (hf : ∀ i, Measurable (fun t => f t i))
    (a : I) (l : List I) : Measurable (fun t => ScoreSearch.best (f t) a l) := by
  induction l generalizing a with
  | nil => exact measurable_const
  | cons i l ih =>
    have e : (fun t => ScoreSearch.best (f t) a (i::l)) =
        (fun t => if f t i < f t a then ScoreSearch.best (f t) i l else ScoreSearch.best (f t) a l) := by
      funext t; rw [ScoreSearch.best]; split_ifs <;> rfl
    rw [e]; exact Measurable.ite (measurableSet_lt (hf i) (hf a)) (ih i) (ih a)

theorem separation {K n : ℕ} {s : T → Fin n → H K} (hs : ∀ i, Measurable (fun t => s t i)) :
    Measurable (fun t => sep (s t)) := by
  classical
  apply measurable_of_Ioi
  intro c
  have he : (fun t => sep (s t)) ⁻¹' Ioi c =
      {t | c < 1 ∧ ∀ i j, s t i ≠ s t j → c < ‖s t i-s t j‖} := by
    ext t
    simp [sep,Finset.lt_min'_iff]; grind
  rw [he]
  exact (measurable_const.and (Measurable.forall fun i => Measurable.forall fun j =>
    (measurableSet_eq_fun (hs i) (hs j)).compl.mem.imp
      (measurableSet_lt measurable_const ((hs i).sub (hs j)).norm).mem)).setOf

/-- The actual feasible-grid fit is Borel both when the grid level changes and
when two scores coincide. No separation lower bound is assumed. -/
theorem probability_rows {K n : ℕ} (hK : 2 ≤ K) {s : T → Fin n → H K}
    {y : T → Fin n → Fin K} (hs : ∀ i, Measurable (fun t => s t i)) (hy : Measurable y)
    (B tol : ℝ) : Measurable (fun t => rows hK (s t) (y t) B tol) := by
  classical
  let mask := fun (N : ℕ) t (a : Rows n K N) => decide (admissible (s t) B a)
  have hm N : Measurable (mask N) := by
    apply measurable_pi_lambda
    intro a
    let P := fun t => admissible (s t) B a
    have meas : Measurable P := measurable_const.and (Measurable.forall fun i => Measurable.forall fun j =>
      (measurableSet_le measurable_const (measurable_const.mul (((hs i).sub (hs j)).norm))).mem)
    exact (measurable_of_countable (fun p : Prop => decide p)).comp meas
  have fixed N : Measurable (fun t => row (fit hK N (s t) B (fun i => (label (y t i)).val))) := by
    let compute := fun z : (Rows n K N → Bool) × (Fin n → Fin K) =>
      row (ScoreSearch.best (fun a => obj (row a) (fun i => (label (z.2 i)).val))
        (fun _ j => if j = ⟨0,by omega⟩ then Fin.last N else 0)
        ((Finset.univ : Finset (Rows n K N)).filter (fun a => z.1 a = true)).toList)
    have eq (t : T) : compute (mask N t,y t) = row (fit hK N (s t) B (fun i => (label (y t i)).val)) := by
      simp [compute,mask,fit] <;> rfl
    simp_rw [← eq]
    exact (measurable_of_countable compute).comp ((hm N).prodMk hy)
  have lev : Measurable (fun t => levels (s t) B tol) :=
    ((measurable_const.max (measurable_const.div (measurable_const.mul (separation hs)))).nat_ceil).add measurable_const
  exact vary lev fixed

end UL.Arxiv.MeasurableFit

import UL.Arxiv.GridOracle

open Set
namespace UL.Arxiv.GridOracle
open Proof_lem_C_2

noncomputable abbrev dim {n : ℕ} {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    (x : Fin n → X) (K : ℕ) := Module.finrank ℝ (sampleSpan x)*Module.finrank ℝ (H K)

section
variable {n K : ℕ} {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X] [CompleteSpace X]

/-- Effect of changing the fitted probabilities on the computed empirical
gradient. The square root of the number of matrix coefficients gives a conservative stopping tolerance. -/
theorem gradient_error (hn : 1 ≤ n) (x : Fin n → X) {L a : ℝ} (hx : ∀ i, ‖x i‖ ≤ L)
    (ha : 0 ≤ a) (pTilde qTilde Z : Fin n → H K) (hd : ∀ i, ‖pTilde i-qTilde i‖ ≤ a) :
    ‖empGradVec x (fun i => pTilde i-Z i) - empGradVec x (fun i => qTilde i-Z i)‖ ≤
      Real.sqrt (dim x K)*L*a := by
  let bE := stdOrthonormalBasis ℝ (sampleSpan x)
  let bH := stdOrthonormalBasis ℝ (H K)
  let diff := empGradVec x (fun i => pTilde i-Z i) - empGradVec x (fun i => qTilde i-Z i)
  have hpos : 0 < n := by omega
  have hd' : 0 < (n:ℝ) := Nat.cast_pos.mpr hpos
  have hL := (norm_nonneg _).trans (hx ⟨0,hpos⟩)
  have hco (j : Fin (dim x K)) : |diff j| ≤ L*a := by
    let k := finProdFinEquiv.symm j
    let t := fun i => inner ℝ ((bE k.1 : sampleSpan x) : X) (x i)
    let u := fun i => inner ℝ (pTilde i-qTilde i) (bH k.2)
    have eq : diff j = (1/(n:ℝ))*∑ i,t i*u i := by
      change (1/(n:ℝ))*∑ i,t i*inner ℝ (pTilde i-Z i) (bH k.2) - (1/(n:ℝ))*∑ i,t i*inner ℝ (qTilde i-Z i) (bH k.2) = _
      rw [← mul_sub,← Finset.sum_sub_distrib]
      congr 1; apply Finset.sum_congr rfl; intro i _
      dsimp [u]; rw [inner_sub_left,inner_sub_left,inner_sub_left]; ring
    have ht (i) : |t i| ≤ L := (abs_real_inner_le_norm _ _).trans (by rw [Submodule.norm_coe,bE.norm_eq_one,one_mul]; exact hx i)
    have hu (i) : |u i| ≤ a := (abs_real_inner_le_norm _ _).trans (by simpa [bH] using hd i)
    rw [eq,abs_mul,abs_of_nonneg (by positivity : 0 ≤ 1/(n:ℝ))]
    calc _ ≤ (1/(n:ℝ))*∑ i, |t i*u i| := mul_le_mul_of_nonneg_left (Finset.abs_sum_le_sum_abs _ _) (by positivity)
         _ ≤ (1/(n:ℝ))*∑ _i : Fin n, L*a := by
           gcongr with i; rw [abs_mul]; exact mul_le_mul (ht i) (hu i) (abs_nonneg _) hL
         _ = L*a := by simp [Nat.ne_of_gt hpos]
  have hs := Finset.sum_le_sum (s:=Finset.univ) fun j _ => sq_le_sq' (abs_le.mp (hco j)).1 (abs_le.mp (hco j)).2
  rw [← UL.Proof_lem_A_4.norm_sq_eq_sum diff, Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul] at hs
  rw [mul_assoc]; apply le_of_sq_le_sq _ (by positivity)
  rwa [mul_pow,Real.sq_sqrt (Nat.cast_nonneg _)]

noncomputable def certificate (x : Fin n → X) (R : ℝ) (w : ScoreGrid.V (dim x K))
    (pTilde Z : Fin n → H K) := let g := empGradVec x (fun i => pTilde i-Z i)
    inner ℝ g w + R*‖g‖

theorem gap_error (hn : 1 ≤ n) (x : Fin n → X) {L R a : ℝ} (hx : ∀ i, ‖x i‖ ≤ L)
    (ha : 0 ≤ a) (w : ScoreGrid.V (dim x K)) (hw : ‖w‖ ≤ R)
    (pTilde qTilde Z : Fin n → H K) (hd : ∀ i, ‖pTilde i-qTilde i‖ ≤ a) :
    |certificate x R w pTilde Z-certificate x R w qTilde Z| ≤ 2*R*(Real.sqrt (dim x K)*L*a) := by
  let g := empGradVec x (fun i => pTilde i-Z i)
  let f := empGradVec x (fun i => qTilde i-Z i)
  have h := gradient_error hn x hx ha pTilde qTilde Z hd
  have hR := (norm_nonneg _).trans hw
  change |(inner ℝ g w + R*‖g‖)-(inner ℝ f w+R*‖f‖)| ≤ _
  rw [show inner ℝ g w + R*‖g‖-(inner ℝ f w+R*‖f‖) = inner ℝ (g-f) w+R*(‖g‖-‖f‖) by rw [inner_sub_left]; ring]
  calc _ ≤ |inner ℝ (g-f) w|+ |R*(‖g‖-‖f‖)| := abs_add_le _ _
       _ ≤ ‖g-f‖*R + R*‖g-f‖ := by
         rw [abs_mul,abs_of_nonneg hR]
         gcongr
         · exact (abs_real_inner_le_norm _ _).trans (mul_le_mul_of_nonneg_left hw (norm_nonneg _))
         · exact abs_norm_sub_norm_le _ _
       _ ≤ _ := by nlinarith only [mul_le_mul_of_nonneg_left h hR]
end

noncomputable def center {K : ℕ} (q : Simplex K) (hK : 2 ≤ K) : H K :=
  ⟨q.val-uniformVec K,Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex q.2 (Proof_lem_A_5.uniformVec_mem_simplex hK)⟩

theorem approximate_rows {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n) (s : Fin n → H K)
    {A B t : ℝ} (hB : 0 < B) (ht : 0 < t) (ht' : t ≤ 1) (hs : ∀ i, ‖s i‖ ≤ A)
    (y : Fin n → Simplex K) (pTilde : Fin n → H K)
    (hP : isOptFitAtScores A B (fun i => center (y i) hK) s pTilde) :
    let N := levels s B t
    let a := fit hK N s B (fun i => (y i).val)
    admissible s B a ∧ ∀ i, ‖row a i -(uniformVec K + (pTilde i).val)‖ ≤ Real.sqrt (12*(n:ℝ)*t) := by
  intro N a
  have F := (exists_isBLip_iff UL.P_lem_C_4 hK hn hB hs pTilde).mp hP.1
  let p (i : Fin n) : Simplex K := ⟨uniformVec K+(pTilde i).val,F.1 i⟩
  have pp (i j) : (p i).val-(p j).val = ((pTilde i-pTilde j : H K) : E K) := by dsimp [p]; abel
  have hcap : ∀ i j, ‖(p i).val-(p j).val‖ ≤ B*‖s i-s j‖ := by
    intro i j; rw [pp,Submodule.norm_coe]; exact F.2 i j
  obtain ⟨hN,hmesh,hslack⟩ := levels_spec s hB ht
  obtain ⟨valid,near⟩ := fit_spec hK hn hN s p y hB.le ht.le ht' (sep_spec s).2 hcap hmesh hslack
  refine ⟨valid,?_⟩
  let qTilde := fun i => center (⟨row a i,valid.1 i⟩ : Simplex K) hK
  let Z := fun i => center (y i) hK
  have qraw (i) : (qTilde i).val = row a i-uniformVec K := rfl
  have zraw (i) : (Z i).val = (y i).val-uniformVec K := rfl
  have pr (i) : (pTilde i).val = (p i).val-uniformVec K := by dsimp [p]; abel
  have good : qTilde ∈ FeasibleFitSet K n B s := by
    constructor
    · intro i; change uniformVec K+(row a i-uniformVec K) ∈ Simplex K
      simpa only [add_sub_cancel] using valid.1 i
    · intro i j; rw [← Submodule.norm_coe,Submodule.coe_sub,qraw,qraw,sub_sub_sub_cancel_right]
      exact valid.2 i j
  have vi := sq_error hn hP ((exists_isBLip_iff UL.P_lem_C_4 hK hn hB hs qTilde).mpr good)
  have id (f : Fin n → E K) : obj f (fun i => (y i).val) = (∑ i, ‖f i-(y i).val‖^2)/(2*(n:ℝ)) := by
    unfold obj; rw [Finset.sum_div]; apply Finset.sum_congr rfl; intro i _; ring
  rw [id,id] at near
  have hd : (0:ℝ) < n := by positivity
  have rel (i) : ‖qTilde i-Z i‖ = ‖row a i-(y i).val‖ := by rw [← Submodule.norm_coe,Submodule.coe_sub,qraw,zraw,sub_sub_sub_cancel_right]
  have rel' (i) : ‖pTilde i-Z i‖ = ‖(p i).val-(y i).val‖ := by rw [← Submodule.norm_coe,Submodule.coe_sub,pr,zraw,sub_sub_sub_cancel_right]
  change _ ≤ (∑ i, ‖qTilde i-Z i‖^2)-∑ i, ‖pTilde i-Z i‖^2 at vi
  simp_rw [rel,rel'] at vi
  intro i
  have hh := Finset.single_le_sum (s:=Finset.univ) (fun j _ => sq_nonneg ‖qTilde j-pTilde j‖) (Finset.mem_univ i)
  have hb : ‖qTilde i-pTilde i‖^2 ≤ 12*(n:ℝ)*t := by
    field_simp [hd,hd.ne'] at near
    linarith
  have ee : ‖row a i-(uniformVec K + (pTilde i).val)‖ = ‖qTilde i-pTilde i‖ := by
    rw [← Submodule.norm_coe,Submodule.coe_sub,qraw]; congr 1; abel
  rw [ee]; apply (Real.le_sqrt (norm_nonneg _) (by positivity)).mpr hb

end UL.Arxiv.GridOracle

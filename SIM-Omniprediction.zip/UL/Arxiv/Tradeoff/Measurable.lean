import UL.Arxiv.Tradeoff.AllDimensions

namespace UL.Arxiv.Tradeoff
open MeasureTheory UL.Proof_thm_A_9 UL.Proof_thm_4_1

private theorem rankOfRestriction {d q K : ℕ} (h : q ≤ d)
    (W : FeatureSpace d →ₗ[ℝ] ZeroSumSubspace K) :
    Module.finrank ℝ (LinearMap.range (W.comp (coordIncl h).toLinearMap))
      ≤ Module.finrank ℝ (LinearMap.range W) :=
  Submodule.finrank_mono (LinearMap.range_comp_le_range ..)


/-- Reflection reverses exactly those coordinates in the kernel. Each pair of
reflected inputs yields the same report, with no regularity assumption on
the link beyond measurability for the integrals. -/
theorem measurableRankLower {K : ℕ} (G : Geometry K) (hK : 2 ≤ K) {R β L : ℝ}
    (hL : 0 < L) (r : ℕ) (hr : r ≤ G.dim)
    (W : FeatureSpace G.dim →ₗ[ℝ] ZeroSumSubspace K) (ρ : ZeroSumSubspace K → Simplex K)
    (hW : Module.finrank ℝ (LinearMap.range W) ≤ r) (hρ : Measurable ρ) :
    let c := intrinsicSlopeParam K G R β
    ((G.dim:ℝ) - r) * c^2 * (L^2 / (G.dim+2)) ≤
      ∫ x, ‖(ρ (W x)).val - intrinsicEtaMap K G hK R β L x‖^2 ∂ballUniformMeasure G.dim L := by
  intro c
  let m := G.dim
  obtain ⟨Q,hker,_⟩ := basisAdaptedToKernel hK W hW
  let J := reflectWhere (fun j : Fin m => r ≤ j.val)
  let μ := ballUniformMeasure m L
  let η := intrinsicEtaMap K G hK R β L
  let g := fun x => ‖(ρ (W x)).val - η x‖^2
  have hm : Measurable g :=
    (((measurable_subtype_coe.comp (hρ.comp W.continuous_of_finiteDimensional.measurable)).sub
      (intrinsicContinuous_etaMap K G hK R β hL).measurable).norm).pow_const 2
  haveI : IsProbabilityMeasure μ := ballUniformMeasure_isProb m hL
  have bounded (x) (hx : ‖x‖ ≤ L) : ‖g x‖ ≤ (1 + ‖uniformVec K‖ + |c| * L)^2 := by
    have hn := UL.Proof_lem_A_5.norm_le_one_of_mem_simplex (ρ (W x)).2
    have hc := intrinsicEtaMap_eq_on_closedBall K G hK R β hL
      (show x ∈ Metric.closedBall 0 L by simpa using hx)
    have hη : ‖η x‖ ≤ ‖uniformVec K‖ + |c| * L := by
      rw [show η x = _ from hc]
      refine (norm_add_le _ _).trans (add_le_add le_rfl ?_)
      rw [norm_smul, Real.norm_eq_abs, Submodule.norm_coe, G.embedding.norm_map]
      exact mul_le_mul_of_nonneg_left hx (abs_nonneg c)
    dsimp [g]
    rw [abs_of_nonneg (sq_nonneg _)]
    exact pow_le_pow_left₀ (norm_nonneg _) ((norm_sub_le _ _).trans (by linarith)) 2
  have hint (A : FeatureSpace m ≃ₗᵢ[ℝ] FeatureSpace m) : Integrable (fun t => g (A t)) μ := by
    apply (memLp_top_of_bound (hm.comp A.continuous.measurable).aestronglyMeasurable
      ((1 + ‖uniformVec K‖ + |c| * L)^2) _).integrable le_top
    filter_upwards [ae_mem_ball_ballUniformMeasure m L] with t ht
    exact bounded _ (by simpa [A.norm_map] using (Metric.ball_subset_closedBall ht))
  let tail := Finset.univ.filter (fun j : Fin m => r ≤ j.val)
  have hd (t : FeatureSpace m) : W (Q (J t)) = W (Q t) := by
    have hdecomp (x : FeatureSpace m) : x = ∑ i : Fin m, x i • EuclideanSpace.single i (1:ℝ) := by
      ext i; rw [UL.Proof_lem_A_3.sum_apply]; simp [EuclideanSpace.single_apply]
    conv_lhs => rw [hdecomp (J t),map_sum,map_sum]
    conv_rhs => rw [hdecomp t,map_sum,map_sum]
    apply Finset.sum_congr rfl
    intro i _
    change W (Q ((if r ≤ i.val then -t i else t i) • _)) = _
    by_cases hi : r ≤ i.val <;> simp [hi, map_smul, hker i]
  have hpoint : ∀ᵐ t ∂μ, (2*c^2) * ∑ j ∈ tail, (t j)^2 ≤ g (Q t) + g (Q (J t)) := by
    filter_upwards [ae_mem_ball_ballUniformMeasure m L] with t ht
    have ht' : ‖t‖ ≤ L := (show ‖t‖ < L by simpa using ht).le
    have ha (A : FeatureSpace m ≃ₗᵢ[ℝ] FeatureSpace m) : η (A t) = uniformVec K + c • (G.embedding (A t)).val :=
      intrinsicEtaMap_eq_on_closedBall K G hK R β hL (by simpa [A.norm_map] using ht')
    have hs : ‖t-J t‖^2 = 4 * ∑ j ∈ tail, (t j)^2 := by
      rw [UL.Proof_lem_A_3.norm_sq_eq_sum, Finset.mul_sum, Finset.sum_filter]
      apply Finset.sum_congr rfl
      intro j _
      change (t j - (if r ≤ j.val then -t j else t j))^2 = _
      split_ifs <;> ring
    have hdiff : η (Q t) - η (Q (J t)) = c • (G.embedding (Q (t-J t))).val := by
      rw [ha Q, show η (Q (J t)) = _ from ha (J.trans Q), map_sub, map_sub,
        Submodule.coe_sub,smul_sub]; abel
    have hs' : ‖η (Q t) - η (Q (J t))‖^2 = c^2 * (4 * ∑ j ∈ tail, (t j)^2) := by
      rw [hdiff,norm_smul,Real.norm_eq_abs,Submodule.norm_coe,G.embedding.norm_map,Q.norm_map,
        mul_pow,sq_abs,hs]
    let z := (ρ (W (Q t))).val
    have H := dist_triangle (η (Q t)) z (η (Q (J t)))
    simp only [dist_eq_norm] at H
    rw [norm_sub_rev (η (Q t)) z] at H
    have HH := pow_le_pow_left₀ (norm_nonneg _) H 2
    dsimp [g]
    rw [hd]
    dsimp [z] at *
    nlinarith [sq_nonneg (‖(ρ (W (Q t))).val-η (Q t)‖-‖(ρ (W (Q t))).val-η (Q (J t))‖)]
  have hi (j : Fin m) : Integrable (fun t : FeatureSpace m => (t j)^2) μ :=
    integrable_of_continuous_ballUniformMeasure hL ((EuclideanSpace.proj j).continuous.pow 2)
  have hb := integral_mono_ae ((integrable_finset_sum tail fun j _ => hi j).const_mul (2*c^2))
    ((hint Q).add (hint (J.trans Q))) hpoint
  simp only [Pi.add_apply] at hb
  rw [integral_const_mul,integral_finset_sum tail fun j _ => hi j, integral_add (hint Q) (hint (J.trans Q))] at hb
  have hj : (∫ t, g ((J.trans Q) t) ∂μ) = ∫ x, g x ∂μ := integral_comp_iso_ballUniformMeasure L (J.trans Q) hm
  have hQ : (∫ t, g (Q t) ∂μ) = ∫ x, g x ∂μ := integral_comp_iso_ballUniformMeasure L Q hm
  rw [hj,hQ] at hb
  have moment (j : Fin m) : (∫ t : FeatureSpace m, (t j)^2 ∂μ) = L^2 / ((m:ℝ)+2) :=
    integral_coord_sq_ballUniformMeasure G.positive hL j
  simp_rw [moment] at hb
  have hcard : tail.card = m-r := by
    change (Finset.univ.filter (fun j : Fin m => r ≤ j.val)).card = _
    have hlt : (Finset.univ.filter (fun j : Fin m => j.val < r)).card = r := by
      have heq : Finset.univ.filter (fun j : Fin m => j.val < r) = Finset.univ.map (Fin.castLEEmb hr) := by
        ext j
        simp only [Finset.mem_filter,Finset.mem_univ,true_and,Finset.mem_map]
        constructor
        · intro hj
          exact ⟨⟨j.val,hj⟩,rfl⟩
        · rintro ⟨i,hi⟩
          subst j
          exact i.isLt
      simp [heq]
    have ha := Finset.card_filter_add_card_filter_not (s := Finset.univ) (p := fun j : Fin m => j.val < r)
    simp [hlt,not_lt] at ha
    omega
  rw [Finset.sum_const,hcard,nsmul_eq_mul,Nat.cast_sub hr] at hb
  linarith

/-- The rank obstruction on the very same distribution, including reports on
the boundary of the simplex and links with no continuity or slope condition. -/
theorem arbitraryMeasurableLower {d K : ℕ} (hd : 1 ≤ d) (hK : 2 ≤ K) {R β L : ℝ}
    (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    (hfloor : β*R*L / Real.sqrt (min d (K-1) : ℕ) < 1/(K:ℝ))
    {r : ℕ} (hr : r ≤ min d (K-1))
    (W : FeatureSpace d →ₗ[ℝ] ZeroSumSubspace K) (ρ : ZeroSumSubspace K → Simplex K)
    (hrank : Module.finrank ℝ (LinearMap.range W) ≤ r) (hρ : Measurable ρ) :
    let dStar := min d (K-1)
    let P := hardLaw hd hK R β L
    let X := coordIncl (min_le_left d (K-1)) ∘ Prod.fst
    let Φ := phiBeta K β
    let c := β * R / Real.sqrt dStar
    (L^2 * ((dStar:ℝ)-r) * c^2 / (2*β*((dStar:ℝ)+2)) : ℝ) ≤
      expectedCanonicalLoss P X Prod.snd Φ (ρ ∘ W) -
        (⨅ V ∈ ComparatorBall d K R, expectedMatchingLoss P X Prod.snd Φ V) := by
  dsimp only
  rw [ambientBenchmark]
  let G := geometry K d hK hd
  let A := W.comp (coordIncl (min_le_left d (K-1))).toLinearMap
  have hrA : Module.finrank ℝ (LinearMap.range A) ≤ r :=
    (rankOfRestriction (min_le_left d (K-1)) W).trans hrank
  have hgeom := measurableRankLower G hK (R := R) (β := β) hL r hr A ρ hrA hρ
  have hh := intrinsicL2_le_regret G hK hR hβ hL hfloor (p := ρ ∘ A)
    (hρ.comp A.continuous_of_finiteDimensional.measurable)
  refine le_trans ?_ hh
  apply EReal.coe_le_coe_iff.mpr
  refine le_trans (le_of_eq ?_) (mul_le_mul_of_nonneg_left hgeom (by positivity : 0 ≤ 1/(2*β)))
  unfold intrinsicSlopeParam
  dsimp only [G, geometry]
  simp only [div_eq_mul_inv, mul_inv_rev]
  ring

end UL.Arxiv.Tradeoff

import UL.Proof.thm_4_1.H1

namespace UL.Arxiv.Tradeoff
open UL.Proof_thm_4_1 MeasureTheory

abbrev FeatureSpace (d : ℕ) := EuclideanSpace ℝ (Fin d)

theorem includeSingle {q d : ℕ} (h : q ≤ d) (j : Fin q) :
    coordIncl h (EuclideanSpace.single j 1) = EuclideanSpace.single (Fin.castLE h j) 1 := by
  ext i
  change (if hi : i.val < q then EuclideanSpace.single j (1 : ℝ) ⟨i.val,hi⟩ else 0) = _
  by_cases hi : i.val < q
  · rw [dif_pos hi]
    simp [EuclideanSpace.single_apply, Fin.ext_iff]
  · rw [dif_neg hi]
    have hn : i ≠ Fin.castLE h j := by
      intro hh
      exact hi (hh ▸ j.isLt)
    simp [EuclideanSpace.single_apply, hn, Ne.symm hn]

theorem normRestrict {q d K : ℕ} (h : q ≤ d) (V : FeatureSpace d →ₗ[ℝ] ZeroSumSubspace K) :
    frobeniusNorm (V.comp (coordIncl h).toLinearMap) ≤ frobeniusNorm V := by
  unfold frobeniusNorm
  apply Real.sqrt_le_sqrt
  simp only [LinearMap.comp_apply, LinearIsometry.coe_toLinearMap, includeSingle]
  let e := Fin.castLEEmb h
  calc _ = ∑ i ∈ Finset.univ.map e, ‖V (EuclideanSpace.single i 1)‖^2 := by
              rw [Finset.sum_map]; rfl
       _ ≤ _ := Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _) fun _ _ _ => sq_nonneg _

theorem restrictExtend {q d K : ℕ} (h : q ≤ d) (V : FeatureSpace q →ₗ[ℝ] ZeroSumSubspace K) :
    (V.comp (coordProj h)).comp (coordIncl h).toLinearMap = V := by
  ext1 x
  exact congrArg V (coordProj_coordIncl h x)

theorem normExtend {q d K : ℕ} (h : q ≤ d) (V : FeatureSpace q →ₗ[ℝ] ZeroSumSubspace K) :
    frobeniusNorm (V.comp (coordProj h)) = frobeniusNorm V := by
  classical
  unfold frobeniusNorm
  congr 1
  let e := Fin.castLEEmb h
  calc _ = ∑ i ∈ Finset.univ.map e, ‖V (coordProj h (EuclideanSpace.single i 1))‖^2 := by
              symm
              apply Finset.sum_subset (Finset.subset_univ _)
              intro i _ hi
              have hp : coordProj h (EuclideanSpace.single i 1) = 0 := by
                ext j
                have hn : i ≠ Fin.castLE h j := fun hj => hi (Finset.mem_map.mpr ⟨j,Finset.mem_univ _,hj.symm⟩)
                simp [coordProj, EuclideanSpace.single_apply, hn, Ne.symm hn]
              simp [hp]
       _ = _ := by
              rw [Finset.sum_map]
              apply Finset.sum_congr rfl
              intro i _
              change ‖V (coordProj h (EuclideanSpace.single (Fin.castLE h i) 1))‖^2 = _
              rw [← includeSingle h i, coordProj_coordIncl]

/-- Extending the features by zero leaves the entire linear risk benchmark unchanged. -/
theorem ambientBenchmark {Ω : Type*} [MeasurableSpace Ω] {d q K : ℕ}
    (h : q ≤ d) (P : Measure Ω) (X : Ω → FeatureSpace q) (Y : Ω → Fin K)
    (Φ : Simplex K → ℝ) (R : ℝ) :
    (⨅ V ∈ ComparatorBall d K R, expectedMatchingLoss P (coordIncl h ∘ X) Y Φ V) =
    ⨅ A ∈ ComparatorBall q K R, expectedMatchingLoss P X Y Φ A := by
  apply le_antisymm
  · refine le_iInf fun A => le_iInf fun hA => ?_
    let V := A.comp (coordProj h)
    have hV : V ∈ ComparatorBall d K R := (normExtend h A).le.trans hA
    have hcomp : expectedMatchingLoss P (coordIncl h ∘ X) Y Φ V = expectedMatchingLoss P X Y Φ A := by
      unfold expectedMatchingLoss
      simp only [Function.comp_apply, V, LinearMap.comp_apply, coordProj_coordIncl]
    exact (iInf₂_le V hV).trans_eq hcomp
  · refine le_iInf fun V => le_iInf fun hV => ?_
    let A := V.comp (coordIncl h).toLinearMap
    have hA : A ∈ ComparatorBall q K R := (normRestrict h V).trans hV
    exact iInf₂_le A hA

end UL.Arxiv.Tradeoff

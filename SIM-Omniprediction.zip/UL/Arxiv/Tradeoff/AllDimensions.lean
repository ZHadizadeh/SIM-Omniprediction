import UL.Arxiv.Tradeoff.Ambient
import UL.Arxiv.Tradeoff.IntrinsicBounds

namespace UL.Arxiv.Tradeoff
open MeasureTheory UL.Proof_thm_A_9 UL.Proof_thm_4_1


noncomputable def value (dStar r : ℕ) (R β L B : ℝ) : ℝ :=
  let c := β * R / Real.sqrt dStar
  L^2 / (2*β*((dStar:ℝ)+2)) *
    (((dStar:ℝ)-r)*c^2 + r*(max (c-B*R/Real.sqrt r) 0)^2)

/-- The common probability model used at every rank and slope. -/
noncomputable def hardLaw {d K : ℕ} (hd : 1 ≤ d) (hK : 2 ≤ K) (R β L : ℝ) :
    Measure (FeatureSpace (min d (K-1)) × Fin K) :=
  jointMeasureP (min d (K-1)) K L (intrinsicEtaMap K (geometry K d hK hd) hK R β L)

/-- Simultaneous lower bound and an attaining forecast on a single distribution.
The feature random variable is an isometric copy of the uniform d⋆-dimensional ball in R^d. -/
theorem thm_B_8 {d K : ℕ} (hd : 1 ≤ d) (hK : 2 ≤ K) {R β L : ℝ}
    (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    (hfloor : β * R * L / Real.sqrt (min d (K-1) : ℕ) < 1 / (K : ℝ)) :
    let dStar := min d (K-1)
    let ι := coordIncl (min_le_left d (K-1))
    let P := hardLaw hd hK R β L
    IsProbabilityMeasure P ∧
      pdf.IsUniform Prod.fst (Metric.ball (0 : FeatureSpace dStar) L) P volume ∧
      let X := ι ∘ Prod.fst
      let Φ := phiBeta K β
      let bench := ⨅ V ∈ ComparatorBall d K R, expectedMatchingLoss P X Prod.snd Φ V
      let regret := fun (p : FeatureSpace d → Simplex K) => expectedCanonicalLoss P X Prod.snd Φ p - bench
      Φ ∈ EntropyFamily K β ∧ bench ≠ ⊥ ∧ bench ≠ ⊤ ∧
      ∀ r ≤ dStar, ∀ B : ℝ, 0 ≤ B →
        (∀ (W : FeatureSpace d →ₗ[ℝ] ZeroSumSubspace K) (ρ : ZeroSumSubspace K → Simplex K),
          Module.finrank ℝ (LinearMap.range W) ≤ r → frobeniusNorm W ≤ R →
          LipschitzWith B.toNNReal ρ → (value dStar r R β L B : EReal) ≤ regret (ρ ∘ W)) ∧
        ∃ (W : FeatureSpace d →ₗ[ℝ] ZeroSumSubspace K) (ρ : ZeroSumSubspace K → Simplex K)
          (A : FeatureSpace dStar →ᵃ[ℝ] FeatureSpace K),
          Module.finrank ℝ (LinearMap.range W) ≤ r ∧ frobeniusNorm W ≤ R ∧
          LipschitzWith B.toNNReal ρ ∧
          (∀ x ∈ Metric.closedBall (0 : FeatureSpace dStar) L, (ρ (W (ι x))).val = A x) ∧
          regret (ρ ∘ W) = (value dStar r R β L B : EReal) := by
  let dStar := min d (K-1)
  let G := geometry K d hK hd
  let ι := coordIncl (min_le_left d (K-1))
  let η := intrinsicEtaMap K G hK R β L
  let P := jointMeasureP dStar K L η
  let Φ := phiBeta K β
  have hη := intrinsicContinuous_etaMap K G hK R β hL
  have hηs := intrinsicEtaMap_mem_simplex G hK hR hβ hL hfloor
  refine ⟨jointMeasureP_isProb dStar K hL hη hηs, jointMeasureP_isUniform dStar K L hη hηs, ?_⟩
  dsimp only
  rw [ambientBenchmark]
  have hbench := intrinsicBench_eq_coe K G hK hR hβ hL hfloor
  refine ⟨phiBeta_mem_entropyFamily hβ, ?_, ?_, ?_⟩
  · exact fun h => EReal.coe_ne_bot _ (hbench.symm.trans h)
  · exact fun h => EReal.coe_ne_top _ (hbench.symm.trans h)
  intro r hr B hB
  let risk := fun (p : FeatureSpace dStar → Simplex K) => expectedCanonicalLoss P Prod.fst Prod.snd Φ p -
    (⨅ V ∈ ComparatorBall dStar K R, expectedMatchingLoss P Prod.fst Prod.snd Φ V)
  have hq : G.dim = dStar := rfl
  have bounds :
      (∀ (W : FeatureSpace dStar →ₗ[ℝ] ZeroSumSubspace K) (ρ : ZeroSumSubspace K → Simplex K),
        Module.finrank ℝ (LinearMap.range W) ≤ r → frobeniusNorm W ≤ R →
        LipschitzWith B.toNNReal ρ → (value dStar r R β L B : EReal) ≤ risk (ρ ∘ W)) ∧
      ∃ (W : FeatureSpace dStar →ₗ[ℝ] ZeroSumSubspace K) (ρ : ZeroSumSubspace K → Simplex K)
        (A : FeatureSpace dStar →ᵃ[ℝ] FeatureSpace K) (C : NNReal), Module.finrank ℝ (LinearMap.range W) ≤ r ∧
        frobeniusNorm W ≤ R ∧ LipschitzWith B.toNNReal ρ ∧ LipschitzWith C (ρ ∘ W) ∧
        (∀ x ∈ Metric.closedBall (0 : FeatureSpace dStar) L, (ρ (W x)).val = A x) ∧
        risk (ρ ∘ W) = (value dStar r R β L B : EReal) := by
    cases r with
    | zero =>
      have h := zeroRank G hK hR hβ hL hfloor hB
      have heq : value dStar 0 R β L B = L^2 * dStar * (β * R / Real.sqrt dStar)^2 / (2*β*((dStar:ℝ)+2)) := by
        simp [value]; ring
      rw [heq]
      exact ⟨h.1,h.2.2⟩
    | succ r =>
      have h := positiveRank G hK hR hβ hL hfloor (Nat.succ_pos _) hr hB
      exact ⟨h.1,h.2.2⟩
  constructor
  · intro W ρ hrW hW hρ
    exact bounds.1 (W.comp ι.toLinearMap) ρ
      ((Submodule.finrank_mono (LinearMap.range_comp_le_range ..)).trans hrW)
      ((normRestrict _ W).trans hW) hρ
  · obtain ⟨W,ρ,A,_,hrW,hW,hρ,_,hA,hval⟩ := bounds.2
    let V := W.comp (coordProj (min_le_left d (K-1)))
    have hsame (x : FeatureSpace dStar) : V (ι x) = W x := congrArg W (coordProj_coordIncl _ x)
    refine ⟨V,ρ,A,(Submodule.finrank_mono (LinearMap.range_comp_le_range ..)).trans hrW,
      (normExtend _ W).le.trans hW,hρ,fun x hx => by rw [hsame]; exact hA x hx,?_⟩
    change expectedCanonicalLoss P Prod.fst Prod.snd Φ (fun x => ρ (V (ι x))) - _ = _
    simpa only [hsame] using hval

end UL.Arxiv.Tradeoff

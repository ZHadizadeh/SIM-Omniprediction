import UL.Proof.thm_A_9.H2_QuadRisk
import UL.Proof.thm_4_1.H1

namespace UL.Arxiv.Tradeoff
open MeasureTheory UL.Proof_thm_A_9

/-- Intrinsic feature coordinates and their isometric copy in centered label space. -/
structure Geometry (K : ℕ) where
  dim : ℕ
  positive : 1 ≤ dim
  embedding : EuclideanSpace ℝ (Fin dim) →ₗᵢ[ℝ] UL.ZeroSumSubspace K

noncomputable def geometry (K d : ℕ) (hK : 2 ≤ K) (hd : 1 ≤ d) : Geometry K where
  dim := min d (K - 1)
  positive := le_min hd (by omega)
  embedding := (zeroSumIso K hK).toLinearIsometry.comp
    (UL.Proof_thm_4_1.coordIncl (min_le_right d (K - 1)))

noncomputable def intrinsicSlopeParam (K : ℕ) (G : Geometry K) (R β : ℝ) : ℝ :=
  β * R / Real.sqrt ((G.dim : ℝ))

lemma intrinsicSlopeParam_pos {K : ℕ} (G : Geometry K) (hK : 2 ≤ K) {R β : ℝ} (hR : 0 < R) (hβ : 0 < β) :
    0 < intrinsicSlopeParam K G R β := by
  unfold intrinsicSlopeParam
  have hm : (0 : ℝ) < (G.dim : ℝ) := by exact_mod_cast (G.positive : 0 < G.dim)
  positivity

noncomputable def intrinsicEtaMap (K : ℕ) (G : Geometry K) (hK : 2 ≤ K) (R β L : ℝ)
    (x : EuclideanSpace ℝ (Fin (G.dim))) : EuclideanSpace ℝ (Fin K) :=
  UL.uniformVec K +
    intrinsicSlopeParam K G R β • ((G.embedding (radialClamp L x) : UL.ZeroSumSubspace K) :
      EuclideanSpace ℝ (Fin K))

lemma intrinsicContinuous_etaMap (K : ℕ) (G : Geometry K) (hK : 2 ≤ K) (R β : ℝ) {L : ℝ} (hL : 0 < L) :
    Continuous (intrinsicEtaMap K G hK R β L) := by
  unfold intrinsicEtaMap
  exact continuous_const.add
    (continuous_const.smul
      (continuous_subtype_val.comp (G.embedding.continuous.comp (continuous_radialClamp hL))))

lemma intrinsicEtaMap_eq_on_closedBall (K : ℕ) (G : Geometry K) (hK : 2 ≤ K) (R β : ℝ) {L : ℝ} (hL : 0 < L)
    {x : EuclideanSpace ℝ (Fin (G.dim))}
    (hx : x ∈ Metric.closedBall (0 : EuclideanSpace ℝ (Fin (G.dim))) L) :
    intrinsicEtaMap K G hK R β L x =
      UL.uniformVec K +
        intrinsicSlopeParam K G R β • ((G.embedding x : UL.ZeroSumSubspace K) :
          EuclideanSpace ℝ (Fin K)) := by
  have hx_norm : ‖x‖ ≤ L := by simpa [Metric.mem_closedBall, dist_zero_right] using hx
  unfold intrinsicEtaMap
  rw [radialClamp_eq_self hL hx_norm]

noncomputable def intrinsicEtaFloor (K : ℕ) (G : Geometry K) (R β L : ℝ) : ℝ :=
  1 / (K : ℝ) - intrinsicSlopeParam K G R β * L

lemma intrinsicEtaFloor_pos {K : ℕ} (G : Geometry K) (hK : 2 ≤ K) {R β L : ℝ}
    (hcond : β * R * L / Real.sqrt (G.dim : ℝ) < 1 / (K : ℝ)) :
    0 < intrinsicEtaFloor K G R β L := by
  unfold intrinsicEtaFloor intrinsicSlopeParam
  linarith [show (β * R / Real.sqrt (G.dim : ℝ)) * L =
    β * R * L / Real.sqrt (G.dim : ℝ) by ring]

lemma intrinsicEtaFloor_le_etaMap {K : ℕ} (G : Geometry K) (hK : 2 ≤ K) {R β L : ℝ}
    (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    (x : EuclideanSpace ℝ (Fin (G.dim))) (j : Fin K) :
    intrinsicEtaFloor K G R β L ≤ intrinsicEtaMap K G hK R β L x j := by
  have hc_pos : 0 < intrinsicSlopeParam K G R β := intrinsicSlopeParam_pos G hK hR hβ
  set v : EuclideanSpace ℝ (Fin K) :=
    ((G.embedding (radialClamp L x) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
  have hv_norm : ‖v‖ ≤ L := by
    change ‖G.embedding (radialClamp L x)‖ ≤ L
    rw [G.embedding.norm_map]
    exact norm_radialClamp_le hL x
  have hvj : |v j| ≤ L := (UL.Proof_lem_A_3.coord_abs_le_norm v j).trans hv_norm
  have hcvj : -(intrinsicSlopeParam K G R β * L) ≤ intrinsicSlopeParam K G R β * v j := by
    have h1 : |intrinsicSlopeParam K G R β * v j| ≤ intrinsicSlopeParam K G R β * L := by
      rw [abs_mul, abs_of_pos hc_pos]
      exact mul_le_mul_of_nonneg_left hvj hc_pos.le
    exact (abs_le.mp h1).1
  change 1 / (K : ℝ) - intrinsicSlopeParam K G R β * L ≤
    UL.uniformVec K j + intrinsicSlopeParam K G R β * v j
  rw [UL.Proof_lem_A_5.uniformVec_apply]
  linarith

lemma intrinsicEtaMap_pos {K : ℕ} (G : Geometry K) (hK : 2 ≤ K) {R β L : ℝ}
    (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    (hcond : β * R * L / Real.sqrt (G.dim : ℝ) < 1 / (K : ℝ))
    (x : EuclideanSpace ℝ (Fin (G.dim))) (j : Fin K) :
    0 < intrinsicEtaMap K G hK R β L x j :=
  lt_of_lt_of_le (intrinsicEtaFloor_pos G hK hcond) (intrinsicEtaFloor_le_etaMap G hK hR hβ hL x j)

lemma intrinsicEtaMap_mem_simplex {K : ℕ} (G : Geometry K) (hK : 2 ≤ K) {R β L : ℝ}
    (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    (hcond : β * R * L / Real.sqrt (G.dim : ℝ) < 1 / (K : ℝ))
    (x : EuclideanSpace ℝ (Fin (G.dim))) :
    intrinsicEtaMap K G hK R β L x ∈ UL.Simplex K := by
  refine ⟨fun j => (intrinsicEtaMap_pos G hK hR hβ hL hcond x j).le, ?_⟩
  unfold intrinsicEtaMap
  set z := G.embedding (radialClamp L x)
  have hz_sum : ∑ j : Fin K, (z : EuclideanSpace ℝ (Fin K)) j = 0 :=
    (UL.Proof_lem_A_5.mem_zeroSumSubspace_iff K _).mp z.2
  simp only [PiLp.add_apply, PiLp.smul_apply, smul_eq_mul, Finset.sum_add_distrib,
    ← Finset.mul_sum, UL.Proof_lem_A_5.sum_uniformVec hK, hz_sum, mul_zero, add_zero]


noncomputable def intrinsicCompV0 (K : ℕ) (G : Geometry K) (hK : 2 ≤ K) (R : ℝ) :
    EuclideanSpace ℝ (Fin (G.dim)) →ₗ[ℝ] UL.ZeroSumSubspace K :=
  (R / Real.sqrt ((G.dim : ℝ))) • G.embedding.toLinearMap

lemma intrinsicCompV0_mem_comparatorBall (K : ℕ) (G : Geometry K) (hK : 2 ≤ K) {R : ℝ} (hR : 0 < R) :
    intrinsicCompV0 K G hK R ∈ UL.ComparatorBall (G.dim) K R := by
  unfold UL.ComparatorBall UL.frobeniusNorm intrinsicCompV0
  rw [Set.mem_setOf_eq]
  have hm : (0 : ℝ) < (G.dim : ℝ) := by exact_mod_cast (G.positive : 0 < G.dim)
  have hscale_pos : 0 < R / Real.sqrt ((G.dim : ℝ)) := by positivity
  have hterm : ∀ i : Fin (G.dim),
      ‖((R / Real.sqrt ((G.dim : ℝ))) • G.embedding.toLinearMap)
        (EuclideanSpace.single i (1 : ℝ))‖ ^ 2 =
        (R / Real.sqrt ((G.dim : ℝ))) ^ 2 := by
    intro i
    rw [LinearMap.smul_apply, norm_smul, Real.norm_eq_abs, abs_of_pos hscale_pos]
    change (R / Real.sqrt ((G.dim : ℝ)) *
      ‖G.embedding (EuclideanSpace.single i (1 : ℝ))‖) ^ 2 = _
    rw [G.embedding.norm_map, EuclideanSpace.norm_single, norm_one, mul_one]
  simp_rw [hterm]
  rw [Finset.sum_const, Finset.card_fin, nsmul_eq_mul, div_pow, Real.sq_sqrt hm.le,
    mul_div_cancel₀ _ hm.ne', Real.sqrt_sq hR.le]


private lemma intrinsicSum_eta_matchingLoss_compV0_eq {K : ℕ} (G : Geometry K) (hK : 2 ≤ K) {R β L : ℝ}
    (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    (hcond : β * R * L / Real.sqrt (G.dim : ℝ) < 1 / (K : ℝ))
    {x : EuclideanSpace ℝ (Fin (G.dim))}
    (hx : x ∈ Metric.ball (0 : EuclideanSpace ℝ (Fin (G.dim))) L) :
    let ηx := intrinsicEtaMap K G hK R β L x
    ∑ y : Fin K, ηx y * UL.matchingLoss (phiBeta K β) (intrinsicCompV0 K G hK R x) y =
      -phiBeta K β ⟨ηx, intrinsicEtaMap_mem_simplex G hK hR hβ hL hcond x⟩ := by
  intro ηx
  have hηx_mem : ηx ∈ UL.Simplex K := intrinsicEtaMap_mem_simplex G hK hR hβ hL hcond x
  have hx_closed : x ∈ Metric.closedBall (0 : EuclideanSpace ℝ (Fin (G.dim))) L :=
    Metric.ball_subset_closedBall hx
  have hV0_eq : (intrinsicCompV0 K G hK R x : EuclideanSpace ℝ (Fin K)) =
      (1 / β) • (ηx - UL.uniformVec K) := by
    dsimp [ηx]
    rw [intrinsicEtaMap_eq_on_closedBall K G hK R β hL hx_closed]
    unfold intrinsicCompV0 intrinsicSlopeParam
    ext j
    change (R / Real.sqrt ((G.dim : ℝ))) *
        ((G.embedding x : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) j =
      (1 / β) * ((UL.uniformVec K j +
        (β * R / Real.sqrt ((G.dim : ℝ))) *
          ((G.embedding x : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) j) -
        UL.uniformVec K j)
    field_simp [hβ.ne']
    ring
  haveI : Nonempty (UL.Simplex K) := ⟨⟨ηx, hηx_mem⟩⟩
  have hpot : UL.matchingPotential (phiBeta K β) (intrinsicCompV0 K G hK R x) =
      phiBeta K β ⟨ηx, hηx_mem⟩ := by
    rw [hV0_eq]
    have h_id : ∀ q : UL.Simplex K,
        inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K)
            ((1 / β) • (ηx - UL.uniformVec K)) - phiBeta K β q =
          phiBeta K β ⟨ηx, hηx_mem⟩ -
            (1 / (2 * β)) * ‖(q : EuclideanSpace ℝ (Fin K)) - ηx‖ ^ 2 := by
      intro q
      dsimp [phiBeta]
      have hsub : (q : EuclideanSpace ℝ (Fin K)) - ηx =
          ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) - (ηx - UL.uniformVec K) := by abel
      rw [hsub, norm_sub_sq_real ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K)
        (ηx - UL.uniformVec K), real_inner_smul_right]
      field_simp [hβ.ne']
      ring
    have h_le : ∀ q : UL.Simplex K,
        inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K)
            ((1 / β) • (ηx - UL.uniformVec K)) - phiBeta K β q ≤
          phiBeta K β ⟨ηx, hηx_mem⟩ := by
      intro q
      rw [h_id q]
      have hnn : 0 ≤ (1 / (2 * β)) * ‖(q : EuclideanSpace ℝ (Fin K)) - ηx‖ ^ 2 := by positivity
      linarith
    unfold UL.matchingPotential
    refine le_antisymm (ciSup_le h_le) ?_
    have h_self :
        inner ℝ (((⟨ηx, hηx_mem⟩ : UL.Simplex K) : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K)
            ((1 / β) • (ηx - UL.uniformVec K)) - phiBeta K β ⟨ηx, hηx_mem⟩ =
          phiBeta K β ⟨ηx, hηx_mem⟩ := by
      rw [h_id ⟨ηx, hηx_mem⟩]
      simp
    rw [← h_self]
    exact le_ciSup (matchingPotential_phiBeta_bddAbove hβ _) ⟨ηx, hηx_mem⟩
  have hsum_eq :
      ∑ y : Fin K, ηx y * UL.matchingLoss (phiBeta K β) (intrinsicCompV0 K G hK R x) y =
        UL.matchingPotential (phiBeta K β) (intrinsicCompV0 K G hK R x) -
          inner ℝ (ηx - UL.uniformVec K) (intrinsicCompV0 K G hK R x) := by
    unfold UL.matchingLoss
    have h1 : ∑ y : Fin K, ηx y *
        (UL.matchingPotential (phiBeta K β) (intrinsicCompV0 K G hK R x) -
          (intrinsicCompV0 K G hK R x : EuclideanSpace ℝ (Fin K)) y) =
        (∑ y : Fin K, ηx y) * UL.matchingPotential (phiBeta K β) (intrinsicCompV0 K G hK R x) -
          ∑ y : Fin K, ηx y * (intrinsicCompV0 K G hK R x : EuclideanSpace ℝ (Fin K)) y := by
      simp_rw [mul_sub, Finset.sum_sub_distrib, ← Finset.sum_mul]
    rw [h1, hηx_mem.2, one_mul, ← UL.Proof_lem_A_3.inner_eq_sum]
    have hu_orth : inner ℝ (UL.uniformVec K) (intrinsicCompV0 K G hK R x : EuclideanSpace ℝ (Fin K)) = 0 := by
      rw [UL.Proof_lem_A_3.inner_eq_sum]
      simp_rw [UL.Proof_lem_A_5.uniformVec_apply]
      rw [← Finset.mul_sum, (UL.Proof_lem_A_5.mem_zeroSumSubspace_iff K _).mp (intrinsicCompV0 K G hK R x).2,
        mul_zero]
    rw [inner_sub_left, hu_orth, sub_zero]
  rw [hsum_eq, hpot, hV0_eq, real_inner_smul_right, real_inner_self_eq_norm_sq]
  dsimp [phiBeta]
  field_simp [hβ.ne']
  ring

noncomputable def intrinsicBenchReal (K : ℕ) (G : Geometry K) (hK : 2 ≤ K) (R β L : ℝ)
    (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    (hcond : β * R * L / Real.sqrt (G.dim : ℝ) < 1 / (K : ℝ)) : ℝ :=
  ∫ x, (-phiBeta K β ⟨intrinsicEtaMap K G hK R β L x, intrinsicEtaMap_mem_simplex G hK hR hβ hL hcond x⟩)
    ∂(ballUniformMeasure (G.dim) L)

theorem intrinsicBench_eq_coe (K : ℕ) (G : Geometry K) (hK : 2 ≤ K) {R β L : ℝ}
    (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    (hcond : β * R * L / Real.sqrt (G.dim : ℝ) < 1 / (K : ℝ)) :
    let m := G.dim
    let P := jointMeasureP m K L (intrinsicEtaMap K G hK R β L)
    (⨅ V ∈ UL.ComparatorBall m K R,
      UL.expectedMatchingLoss P Prod.fst Prod.snd (phiBeta K β) V) =
      ((intrinsicBenchReal K G hK R β L hR hβ hL hcond : ℝ) : EReal) := by
  intro m P
  let η := intrinsicEtaMap K G hK R β L
  have hη_cont : Continuous η := intrinsicContinuous_etaMap K G hK R β hL
  have hη_simp : ∀ x, η x ∈ UL.Simplex K := intrinsicEtaMap_mem_simplex G hK hR hβ hL hcond
  let μ₀ := ballUniformMeasure m L
  have h_eml : ∀ V : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] UL.ZeroSumSubspace K,
      UL.expectedMatchingLoss P Prod.fst Prod.snd (phiBeta K β) V =
        ((∫ x, (∑ y : Fin K, η x y * UL.matchingLoss (phiBeta K β) (V x) y) ∂μ₀ : ℝ) : EReal) := by
    intro V
    have hV_cont : Continuous (fun x : EuclideanSpace ℝ (Fin m) => (V x : EuclideanSpace ℝ (Fin K))) :=
      continuous_subtype_val.comp V.continuous_of_finiteDimensional
    have hG_cont : Continuous (fun z : EuclideanSpace ℝ (Fin m) × Fin K =>
        UL.matchingLoss (phiBeta K β) (V z.1) z.2) := by
      rw [continuous_prod_of_discrete_right]
      exact fun y => (continuous_matchingLoss_phiBeta hK hβ y).comp hV_cont
    obtain ⟨hG_int, hG_eq⟩ :=
      integrable_and_integral_jointMeasureP_of_continuous hL hη_cont hη_simp hG_cont
    unfold UL.expectedMatchingLoss
    rw [erealExpectation_coe_of_integrable P hG_int, hG_eq]
  have hneg_cont : Continuous (fun x : EuclideanSpace ℝ (Fin m) =>
      -phiBeta K β ⟨η x, hη_simp x⟩) := by
    have h_eq : (fun x : EuclideanSpace ℝ (Fin m) => -phiBeta K β ⟨η x, hη_simp x⟩) =
        fun x => -((1 / (2 * β)) * ‖η x - UL.uniformVec K‖ ^ 2) := rfl
    rw [h_eq]
    exact (continuous_const.mul (((hη_cont.sub continuous_const).norm).pow 2)).neg
  have hneg_int : Integrable (fun x => -phiBeta K β ⟨η x, hη_simp x⟩) μ₀ :=
    integrable_of_continuous_ballUniformMeasure hL hneg_cont
  have hV_ge : ∀ V : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] UL.ZeroSumSubspace K,
      ((intrinsicBenchReal K G hK R β L hR hβ hL hcond : ℝ) : EReal) ≤
        UL.expectedMatchingLoss P Prod.fst Prod.snd (phiBeta K β) V := by
    intro V
    rw [h_eml V, EReal.coe_le_coe_iff]
    unfold intrinsicBenchReal
    have hsum_cont : Continuous (fun x : EuclideanSpace ℝ (Fin m) =>
        ∑ y : Fin K, η x y * UL.matchingLoss (phiBeta K β) (V x) y) := by
      have hV_cont : Continuous (fun x : EuclideanSpace ℝ (Fin m) =>
          (V x : EuclideanSpace ℝ (Fin K))) :=
        continuous_subtype_val.comp V.continuous_of_finiteDimensional
      exact continuous_finset_sum Finset.univ fun y _ =>
        ((EuclideanSpace.proj y).continuous.comp hη_cont).mul
          ((continuous_matchingLoss_phiBeta hK hβ y).comp hV_cont)
    exact integral_mono hneg_int (integrable_of_continuous_ballUniformMeasure hL hsum_cont)
      (fun x => sum_eta_matchingLoss_ge hK hβ (hη_simp x) (V x))
  have hV0_eq : UL.expectedMatchingLoss P Prod.fst Prod.snd (phiBeta K β) (intrinsicCompV0 K G hK R) =
      ((intrinsicBenchReal K G hK R β L hR hβ hL hcond : ℝ) : EReal) := by
    rw [h_eml (intrinsicCompV0 K G hK R)]
    congr 1
    unfold intrinsicBenchReal
    refine integral_congr_ae ?_
    filter_upwards [ae_mem_ball_ballUniformMeasure m L] with x hx
    exact intrinsicSum_eta_matchingLoss_compV0_eq G hK hR hβ hL hcond hx
  refine le_antisymm ?_ (le_iInf₂ fun V _ => hV_ge V)
  rw [← hV0_eq]
  exact iInf₂_le (intrinsicCompV0 K G hK R) (intrinsicCompV0_mem_comparatorBall K G hK hR)


theorem intrinsicRegret_eq_l2_of_ae_pos {K : ℕ} (G : Geometry K) (hK : 2 ≤ K) {R β L : ℝ}
    (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    (hcond : β * R * L / Real.sqrt (G.dim : ℝ) < 1 / (K : ℝ))
    {p : EuclideanSpace ℝ (Fin (G.dim)) → UL.Simplex K} (hp : Measurable p)
    (h_ae_pos : ∀ᵐ x ∂(ballUniformMeasure (G.dim) L),
      ∀ y : Fin K, 0 < (p x : EuclideanSpace ℝ (Fin K)) y) :
    let m := G.dim
    let P := jointMeasureP m K L (intrinsicEtaMap K G hK R β L)
    let bench := ⨅ V ∈ UL.ComparatorBall m K R,
      UL.expectedMatchingLoss P Prod.fst Prod.snd (phiBeta K β) V
    UL.expectedCanonicalLoss P Prod.fst Prod.snd (phiBeta K β) p - bench =
      (((1 / (2 * β)) * ∫ x, ‖(p x : EuclideanSpace ℝ (Fin K)) - intrinsicEtaMap K G hK R β L x‖ ^ 2
        ∂(ballUniformMeasure m L) : ℝ) : EReal) := by
  intro m P bench
  let η := intrinsicEtaMap K G hK R β L
  let μ₀ := ballUniformMeasure m L
  have hη_cont : Continuous η := intrinsicContinuous_etaMap K G hK R β hL
  have hη_simp : ∀ x, η x ∈ UL.Simplex K := intrinsicEtaMap_mem_simplex G hK hR hβ hL hcond
  have hq : Measurable (fun x => (p x : EuclideanSpace ℝ (Fin K))) :=
    measurable_subtype_coe.comp hp
  have h_ae_P : ∀ᵐ z ∂P, ∀ y : Fin K, 0 < (p z.1 : EuclideanSpace ℝ (Fin K)) y := by
    have hP_fst : P.fst = ballUniformMeasure (G.dim) L :=
      jointMeasureP_fst_eq m K L hη_cont hη_simp
    rw [← hP_fst] at h_ae_pos
    exact ae_of_ae_map measurable_fst.aemeasurable h_ae_pos
  let F_fin : EuclideanSpace ℝ (Fin m) × Fin K → ℝ :=
    fun z => finiteQuadLoss K β (p z.1 : EuclideanSpace ℝ (Fin K)) z.2
  have hSec (y : Fin K) : Measurable (fun x => F_fin (x,y)) := by
    dsimp only [F_fin, finiteQuadLoss]
    exact (measurable_const.mul (((hq.sub measurable_const).norm).pow_const 2)).sub
      (measurable_const.mul (((EuclideanSpace.proj y).continuous.measurable.comp hq).sub measurable_const))
  have hF : Measurable F_fin := by
    exact measurable_from_prod_countable_left hSec
  haveI : IsProbabilityMeasure μ₀ := ballUniformMeasure_isProb m hL
  obtain ⟨hF_int, hF_eq⟩ := integral_joint_of_sections (L := L) hη_cont hη_simp hF (fun y => by
    let f : UL.Simplex K × UL.Simplex K → ℝ := fun v => (v.1 : EuclideanSpace ℝ (Fin K)) y *
      finiteQuadLoss K β (v.2 : EuclideanSpace ℝ (Fin K)) y
    have hc : Continuous f := by unfold f finiteQuadLoss; fun_prop
    letI : CompactSpace (UL.Simplex K) := isCompact_iff_compactSpace.mp (UL.Proof_lem_A_5.isCompact_simplex K)
    obtain ⟨C,hC⟩ := (isCompact_range hc).isBounded.exists_norm_le
    refine (memLp_top_of_bound (((EuclideanSpace.proj y).continuous.measurable.comp
      hη_cont.measurable).mul (hSec y)).aestronglyMeasurable C ?_).integrable le_top
    exact Filter.Eventually.of_forall fun x => hC _ ⟨(⟨η x,hη_simp x⟩,p x),rfl⟩)
  have hZ_ae : (fun z : EuclideanSpace ℝ (Fin m) × Fin K =>
      UL.extendedCanonicalLoss (phiBeta K β) (p z.1 : EuclideanSpace ℝ (Fin K)) z.2) =ᵐ[P]
      fun z => ((F_fin z : ℝ) : EReal) := by
    filter_upwards [h_ae_P] with z hz
    exact extendedCanonicalLoss_phiBeta_of_pos hK β (p z.1).2 hz z.2
  have hecl_eq : UL.expectedCanonicalLoss P Prod.fst Prod.snd (phiBeta K β) p =
      ((∫ z, F_fin z ∂P : ℝ) : EReal) := by
    unfold UL.expectedCanonicalLoss UL.erealExpectation
    have h1 : (∫⁻ z, (UL.extendedCanonicalLoss (phiBeta K β)
          (p z.1 : EuclideanSpace ℝ (Fin K)) z.2).toENNReal ∂P) =
        ∫⁻ z, ((F_fin z : EReal)).toENNReal ∂P :=
      lintegral_congr_ae (hZ_ae.mono fun _ hz => congrArg EReal.toENNReal hz)
    have h2 : (∫⁻ z, (-UL.extendedCanonicalLoss (phiBeta K β)
          (p z.1 : EuclideanSpace ℝ (Fin K)) z.2).toENNReal ∂P) =
        ∫⁻ z, (-(F_fin z : EReal)).toENNReal ∂P :=
      lintegral_congr_ae (hZ_ae.mono fun _ hz => congrArg (fun u : EReal => (-u).toENNReal) hz)
    rw [h1, h2]
    exact erealExpectation_coe_of_integrable P hF_int
  have hbench : bench = ((intrinsicBenchReal K G hK R β L hR hβ hL hcond : ℝ) : EReal) :=
    intrinsicBench_eq_coe K G hK hR hβ hL hcond
  rw [hecl_eq, hbench, ← EReal.coe_sub, hF_eq]
  congr 1
  have hsum_eq : (fun x : EuclideanSpace ℝ (Fin m) => ∑ y : Fin K, η x y * F_fin (x, y)) =
      fun x => -phiBeta K β ⟨η x, hη_simp x⟩ +
        (1 / (2 * β)) * ‖(p x : EuclideanSpace ℝ (Fin K)) - η x‖ ^ 2 := by
    funext x
    exact sum_eta_finiteQuadLoss_eq hK hβ (p x).2 (hη_simp x)
  have hneg_int : Integrable (fun x => -phiBeta K β ⟨η x, hη_simp x⟩) μ₀ := by
    have h_eq : (fun x : EuclideanSpace ℝ (Fin m) => -phiBeta K β ⟨η x, hη_simp x⟩) =
        fun x => -((1 / (2 * β)) * ‖η x - UL.uniformVec K‖ ^ 2) := rfl
    rw [h_eq]
    exact integrable_of_continuous_ballUniformMeasure hL
      ((continuous_const.mul (((hη_cont.sub continuous_const).norm).pow 2)).neg)
  have hl2_int : Integrable (fun x =>
      (1 / (2 * β)) * ‖(p x : EuclideanSpace ℝ (Fin K)) - η x‖ ^ 2) μ₀ := by
    apply Integrable.const_mul
    apply (memLp_top_of_bound (((hq.sub hη_cont.measurable).norm).pow_const 2).aestronglyMeasurable 4 _).integrable le_top
    filter_upwards with x
    have hle := (norm_sub_le (p x : EuclideanSpace ℝ (Fin K)) (η x)).trans
      (add_le_add (UL.Proof_lem_A_5.norm_le_one_of_mem_simplex (p x).2)
        (UL.Proof_lem_A_5.norm_le_one_of_mem_simplex (hη_simp x)))
    rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
    nlinarith [norm_nonneg ((p x : EuclideanSpace ℝ (Fin K)) - η x)]
  rw [hsum_eq, integral_add hneg_int hl2_int, integral_const_mul]
  unfold intrinsicBenchReal
  ring

theorem intrinsicL2_le_regret {K : ℕ} (G : Geometry K) (hK : 2 ≤ K) {R β L : ℝ}
    (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    (hcond : β * R * L / Real.sqrt (G.dim : ℝ) < 1 / (K : ℝ))
    {p : EuclideanSpace ℝ (Fin (G.dim)) → UL.Simplex K} (hp : Measurable p) :
    let m := G.dim
    let P := jointMeasureP m K L (intrinsicEtaMap K G hK R β L)
    let bench := ⨅ V ∈ UL.ComparatorBall m K R,
      UL.expectedMatchingLoss P Prod.fst Prod.snd (phiBeta K β) V
    (((1 / (2 * β)) * ∫ x, ‖(p x : EuclideanSpace ℝ (Fin K)) - intrinsicEtaMap K G hK R β L x‖ ^ 2
      ∂(ballUniformMeasure m L) : ℝ) : EReal) ≤
      UL.expectedCanonicalLoss P Prod.fst Prod.snd (phiBeta K β) p - bench := by
  intro m P bench
  let μ₀ := ballUniformMeasure m L
  let S_bad : Set (EuclideanSpace ℝ (Fin m)) :=
    {x | ¬ ∀ y : Fin K, 0 < (p x : EuclideanSpace ℝ (Fin K)) y}
  by_cases h_zero : μ₀ S_bad = 0
  · have h_ae_pos : ∀ᵐ x ∂μ₀, ∀ y : Fin K, 0 < (p x : EuclideanSpace ℝ (Fin K)) y :=
      ae_iff.mpr h_zero
    rw [intrinsicRegret_eq_l2_of_ae_pos G hK hR hβ hL hcond hp h_ae_pos]
  · let η := intrinsicEtaMap K G hK R β L
    have hη_cont : Continuous η := intrinsicContinuous_etaMap K G hK R β hL
    have hη_simp : ∀ x, η x ∈ UL.Simplex K := intrinsicEtaMap_mem_simplex G hK hR hβ hL hcond
    haveI : IsProbabilityMeasure P := jointMeasureP_isProb m K hL hη_cont hη_simp
    have hq : Measurable (fun x => (p x : EuclideanSpace ℝ (Fin K))) :=
      measurable_subtype_coe.comp hp
    let E : Fin K → Set (EuclideanSpace ℝ (Fin m)) :=
      fun y => {x | (p x : EuclideanSpace ℝ (Fin K)) y ≤ 0}
    have hE_meas : ∀ y : Fin K, MeasurableSet (E y) := fun y =>
      measurableSet_le ((EuclideanSpace.proj y).continuous.measurable.comp hq) measurable_const
    have hS_eq : S_bad = ⋃ y : Fin K, E y := by
      ext x
      simp only [S_bad, E, Set.mem_setOf_eq, Set.mem_iUnion, not_forall, not_lt]
    have h_exists_y : ∃ y₀ : Fin K, μ₀ (E y₀) ≠ 0 := by
      by_contra h_all_zero
      push_neg at h_all_zero
      apply h_zero
      rw [hS_eq]
      exact measure_iUnion_null h_all_zero
    rcases h_exists_y with ⟨y₀, hy₀_ne⟩
    have hP_pos : P (E y₀ ×ˢ {y₀}) ≠ 0 := by
      rw [jointMeasureP_prod_singleton m K L η (hE_meas y₀) y₀]
      have hfloor_pos : 0 < intrinsicEtaFloor K G R β L := intrinsicEtaFloor_pos G hK hcond
      have h_ge : ENNReal.ofReal (intrinsicEtaFloor K G R β L) * μ₀ (E y₀) ≤
          ∫⁻ x in E y₀, ENNReal.ofReal (η x y₀) ∂μ₀ := by
        rw [← setLIntegral_const]
        exact setLIntegral_mono (measurable_eta_ofReal hη_cont y₀) fun x _ =>
          ENNReal.ofReal_le_ofReal (intrinsicEtaFloor_le_etaMap G hK hR hβ hL x y₀)
      have h_lhs_ne : ENNReal.ofReal (intrinsicEtaFloor K G R β L) * μ₀ (E y₀) ≠ 0 :=
        mul_ne_zero (ENNReal.ofReal_pos.mpr hfloor_pos).ne' hy₀_ne
      exact fun h0 => h_lhs_ne (le_antisymm (h0 ▸ h_ge) (zero_le _))
    have hpos_top :
        (∫⁻ z, (UL.extendedCanonicalLoss (phiBeta K β)
          (p z.1 : EuclideanSpace ℝ (Fin K)) z.2).toENNReal ∂P) = ⊤ := by
      have h_ind_le : ∀ z : EuclideanSpace ℝ (Fin m) × Fin K,
          (E y₀ ×ˢ ({y₀} : Set (Fin K))).indicator (fun _ => (⊤ : ENNReal)) z ≤
            (UL.extendedCanonicalLoss (phiBeta K β)
              (p z.1 : EuclideanSpace ℝ (Fin K)) z.2).toENNReal := by
        intro z
        by_cases hz : z ∈ E y₀ ×ˢ ({y₀} : Set (Fin K))
        · rw [Set.indicator_of_mem hz]
          rcases hz with ⟨hxE, rfl⟩
          have hnot_supp : z.2 ∉ UL.posSupport (p z.1 : EuclideanSpace ℝ (Fin K)) := by
            intro hmem
            have hgt : 0 < (p z.1 : EuclideanSpace ℝ (Fin K)) z.2 :=
              (Finset.mem_filter.mp hmem).2
            exact not_lt_of_ge hxE hgt
          unfold UL.extendedCanonicalLoss
          rw [if_neg hnot_supp]
          simp
        · simp [Set.indicator_of_notMem hz]
      have h_ge :
          (∫⁻ z, (E y₀ ×ˢ ({y₀} : Set (Fin K))).indicator (fun _ => (⊤ : ENNReal)) z ∂P) ≤
            ∫⁻ z, (UL.extendedCanonicalLoss (phiBeta K β)
              (p z.1 : EuclideanSpace ℝ (Fin K)) z.2).toENNReal ∂P :=
        lintegral_mono h_ind_le
      rw [lintegral_indicator ((hE_meas y₀).prod (measurableSet_singleton y₀)),
        setLIntegral_const, ENNReal.top_mul hP_pos] at h_ge
      exact top_unique h_ge
    have hneg_lt_top :
        (∫⁻ z, (-UL.extendedCanonicalLoss (phiBeta K β)
          (p z.1 : EuclideanSpace ℝ (Fin K)) z.2).toENNReal ∂P) ≠ ⊤ := by
      have h_le : (∫⁻ z, (-UL.extendedCanonicalLoss (phiBeta K β)
            (p z.1 : EuclideanSpace ℝ (Fin K)) z.2).toENNReal ∂P) ≤
          ENNReal.ofReal (lossLowerBound K β) := by
        calc (∫⁻ z, (-UL.extendedCanonicalLoss (phiBeta K β)
              (p z.1 : EuclideanSpace ℝ (Fin K)) z.2).toENNReal ∂P)
            ≤ ∫⁻ _z, ENNReal.ofReal (lossLowerBound K β) ∂P :=
                lintegral_mono fun z => neg_extendedCanonicalLoss_toENNReal_le hK hβ (p z.1).2 z.2
          _ = ENNReal.ofReal (lossLowerBound K β) := by simp
      exact ne_of_lt (lt_of_le_of_lt h_le ENNReal.ofReal_lt_top)
    have h_enn_coe : ∀ {a : ENNReal}, a ≠ ⊤ → a.toEReal = ((a.toReal : ℝ) : EReal) := by
      intro a ha
      lift a to NNReal using ha
      rfl
    have hecl_top : UL.expectedCanonicalLoss P Prod.fst Prod.snd (phiBeta K β) p = ⊤ := by
      unfold UL.expectedCanonicalLoss UL.erealExpectation
      rw [hpos_top, h_enn_coe hneg_lt_top, EReal.coe_ennreal_top]
      exact EReal.top_sub_coe _
    have hbench : bench = ((intrinsicBenchReal K G hK R β L hR hβ hL hcond : ℝ) : EReal) :=
      intrinsicBench_eq_coe K G hK hR hβ hL hcond
    rw [hecl_top, hbench, EReal.top_sub_coe]
    exact le_top

end UL.Arxiv.Tradeoff

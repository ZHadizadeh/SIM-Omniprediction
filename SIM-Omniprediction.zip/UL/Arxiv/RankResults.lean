import UL.Arxiv.Tradeoff.Measurable

namespace UL.Arxiv

/-- Theorem 1.3. For every positive feature dimension and every K ≥ 2,
one distribution realizes the exact minimum regret at every rank and slope. -/
alias thm_1_3 := Tradeoff.thm_B_8

/-- Theorem B.8, including affine attainment on the closed support ball. -/
alias thm_B_8 := Tradeoff.thm_B_8

end UL.Arxiv

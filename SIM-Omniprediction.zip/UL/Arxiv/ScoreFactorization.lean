import UL.Proof.thm_A_7.H3_Factorization
import UL.Def.def_2_2

namespace UL.Arxiv

/-- Compress the score space to the image of the given matrix, preserving the
forecast, its slope cap, and both matrix norms. The image may have dimension zero. -/
theorem factorThroughActualRank {d K : ℕ} (hK : 1 ≤ K)
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
    {β : NNReal} (ρ : ZeroSumSubspace K → Simplex K) (hρ : LipschitzWith β ρ) :
    let r := Module.finrank ℝ (LinearMap.range W.toLinearMap)
    r ≤ min d (K - 1) ∧
    ∃ (U : EuclideanSpace ℝ (Fin r) →ₗᵢ[ℝ] ZeroSumSubspace K)
      (A : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin r)),
      W = U.toContinuousLinearMap.comp A ∧
      frobeniusNorm A.toLinearMap = frobeniusNorm W.toLinearMap ∧
      ‖A‖ = ‖W‖ ∧ LipschitzWith β (ρ ∘ U) ∧ ∀ x, (ρ ∘ U) (A x) = ρ (W x) := by
  let S := LinearMap.range W.toLinearMap
  let e := (stdOrthonormalBasis ℝ S).repr
  let lift : EuclideanSpace ℝ (Fin d) →L[ℝ] S :=
    W.codRestrict S fun x => ⟨x, rfl⟩
  let A := e.toLinearIsometry.toContinuousLinearMap.comp lift
  let U := S.subtypeₗᵢ.comp e.symm.toLinearIsometry
  have hWA (x) : U (A x) = W x := congrArg Subtype.val (e.symm_apply_apply (lift x))
  have hnorm (x) : ‖A x‖ = ‖W x‖ := (U.norm_map (A x)).symm.trans (congrArg norm (hWA x))
  refine ⟨le_min ?_ ?_, U, A, ContinuousLinearMap.ext (fun x => (hWA x).symm), ?_, ?_, ?_, ?_⟩
  · simpa using LinearMap.finrank_range_le W.toLinearMap
  · rw [← UL.Proof_thm_A_7.finrank_zeroSumSubspace hK]
    exact Submodule.finrank_le _
  · unfold frobeniusNorm
    congr 1
    exact Finset.sum_congr rfl fun i _ => congrArg (fun t : ℝ => t^2) (hnorm (EuclideanSpace.single i 1))
  · exact le_antisymm (A.opNorm_le_bound (norm_nonneg _) fun x => (hnorm x).le.trans (W.le_opNorm x))
      (W.opNorm_le_bound (norm_nonneg _) fun x => (hnorm x).symm.le.trans (A.le_opNorm x))
  · simpa using hρ.comp U.isometry.lipschitz
  · exact fun x => congrArg ρ (hWA x)

end UL.Arxiv

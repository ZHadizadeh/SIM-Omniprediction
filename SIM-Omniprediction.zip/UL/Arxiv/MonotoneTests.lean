import UL.Arxiv.BoundedBinary
import Mathlib.Topology.Order.Monotone
import Mathlib.Topology.Instances.Rat
/-! # Monotone tests at jumps (Appendix A.2)

Finite grids include all rational numbers and eventually every jump of the target.
This also covers probability laws with atoms at those jumps.
-/
open Set Filter MeasureTheory Topology
namespace UL.Arxiv.BoundedBinary
noncomputable section

private theorem interpolate_on (s : Finset ℝ) (hs : s.Nonempty) {C : ℝ} {f : ℝ → ℝ}
    (hf : Monotone f) (hb : ∀ x, |f x| ≤ C) :
    ∃ g : ℝ → ℝ, Continuous g ∧ Monotone g ∧ (∀ x, |g x| ≤ C) ∧ ∀ x ∈ s, g x = f x := by
  classical
  let slopes := (s ×ˢ s).image (fun xy : ℝ × ℝ => (f xy.1 - f xy.2) / (xy.1 - xy.2))
  obtain ⟨b, hB⟩ := slopes.finite_toSet.bddAbove
  let B := max b 0
  have hB₀ : 0 ≤ B := le_max_right _ _
  let cone (a x : ℝ) := min (f a) (f a + B * (x - a))
  let g := s.sup' hs cone
  have hcont : Continuous g := by
    apply Finset.sup'_mem {h : ℝ → ℝ | Continuous h} (fun _ h _ h' => h.max h')
    intro a _
    exact continuous_const.min (continuous_const.add (continuous_const.mul (continuous_id.sub continuous_const)))
  have hmono : Monotone g := by
    apply Finset.sup'_mem {h : ℝ → ℝ | Monotone h} (fun _ h _ h' => fun x y hxy => max_le_max (h hxy) (h' hxy))
    intro a _ x y hxy
    exact min_le_min le_rfl (add_le_add_right (mul_le_mul_of_nonneg_left (sub_le_sub_right hxy _) hB₀) _)
  refine ⟨fun x => max (-C) (g x), continuous_const.max hcont,
    fun _ _ h => max_le_max le_rfl (hmono h), ?_, ?_⟩
  · intro x
    apply abs_le.mpr
    refine ⟨le_max_left _ _, max_le (by linarith [(abs_nonneg (f x)).trans (hb x)]) ?_⟩
    change s.sup' hs cone x ≤ C
    rw [Finset.sup'_apply]
    exact s.sup'_le hs _ (fun a _ => (min_le_left _ _).trans (abs_le.mp (hb a)).2)
  · intro x hx
    have eq : g x = f x := by
      change s.sup' hs cone x = f x
      rw [Finset.sup'_apply]
      apply le_antisymm
      · apply Finset.sup'_le
        intro a ha
        rcases le_or_gt a x with h | h
        · exact (min_le_left _ _).trans (hf h)
        · have hslope : (f a - f x) / (a - x) ≤ B :=
            (hB (Finset.mem_image.mpr ⟨(a,x), Finset.mem_product.mpr ⟨ha,hx⟩, rfl⟩)).trans
              (le_max_left _ _)
          have hmul := (div_le_iff₀ (sub_pos.mpr h)).mp hslope
          exact (min_le_right _ _).trans (by linarith)
      · simpa [cone] using (Finset.le_sup' (s := s) (fun a => cone a x) hx)
    change max (-C) (g x) = f x
    rw [eq, max_eq_right (abs_le.mp (hb x)).1]

theorem continuous_monotone_approx {f : ℝ → ℝ} (hf : Monotone f) {C : ℝ}
    (hb : ∀ x, |f x| ≤ C) :
    ∃ g : ℕ → ℝ → ℝ, (∀ n, Continuous (g n) ∧ Monotone (g n) ∧ ∀ x, |g n x| ≤ C) ∧
      ∀ x, Tendsto (fun n => g n x) atTop (𝓝 (f x)) := by
  classical
  let D := Set.range (fun q : ℚ => (q : ℝ)) ∪ {x | ¬ContinuousAt f x}
  obtain ⟨u, hu⟩ := ((Set.countable_range _).union hf.countable_not_continuousAt).exists_eq_range
    (show D.Nonempty from ⟨(0 : ℚ), Or.inl ⟨0,rfl⟩⟩)
  let grid (n : ℕ) := (Finset.range (n+1)).image u
  have hne n : (grid n).Nonempty := ⟨u 0, Finset.mem_image.mpr ⟨0, Finset.mem_range.mpr (Nat.zero_lt_succ _), rfl⟩⟩
  choose g hc hm hbounded hmatch using fun n => interpolate_on (grid n) (hne n) hf hb
  have hevent {x : ℝ} (hx : x ∈ D) : ∀ᶠ n in atTop, g n x = f x := by
    have hx' : x ∈ Set.range u := by rw [← hu]; exact hx
    obtain ⟨i, rfl⟩ := hx'
    filter_upwards [eventually_ge_atTop i] with n hn
    exact hmatch n _ (Finset.mem_image.mpr ⟨i, Finset.mem_range.mpr (Nat.lt_succ_of_le hn), rfl⟩)
  refine ⟨g, fun n => ⟨hc n, hm n, hbounded n⟩, ?_⟩
  intro x
  by_cases hcx : ContinuousAt f x
  · apply Metric.tendsto_atTop.mpr
    intro ε hε
    obtain ⟨δ, hδ, hclose⟩ := Metric.continuousAt_iff.mp hcx ε hε
    obtain ⟨a, hax₀, hax⟩ := exists_rat_btwn (show x - δ < x by linarith)
    obtain ⟨b, hxb, hxb₀⟩ := exists_rat_btwn (show x < x + δ by linarith)
    have hfa := hclose (x := (a : ℝ)) (by rw [Real.dist_eq, abs_lt]; constructor <;> linarith)
    have hfb := hclose (x := (b : ℝ)) (by rw [Real.dist_eq, abs_lt]; constructor <;> linarith)
    rw [Real.dist_eq, abs_lt] at hfa hfb
    apply eventually_atTop.mp
    filter_upwards [hevent (x := (a : ℝ)) (Or.inl ⟨a,rfl⟩),
      hevent (x := (b : ℝ)) (Or.inl ⟨b,rfl⟩)] with n ha hb'
    have hl := hm n hax.le
    have hu' := hm n hxb.le
    rw [ha] at hl
    rw [hb'] at hu'
    rw [Real.dist_eq, abs_lt]
    constructor <;> linarith
  · exact tendsto_const_nhds.congr' ((hevent (x := x) (Or.inr hcx)).mono fun _ he => he.symm)

/-- Pass the one-sided residual tests to a possibly discontinuous Bayes selector. -/
theorem test_of_continuous_tests {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    [IsProbabilityMeasure μ] {r P : Ω → ℝ} (hr : Measurable r) (hP : Measurable P)
    (hrb : ∀ᵐ ω ∂μ, |r ω| ≤ 1)
    (htest : ∀ g : ℝ → ℝ, Continuous g → Monotone g → (∫ ω, r ω * g (P ω) ∂μ) ≤ 0)
    {f : ℝ → ℝ} (hf : Monotone f) {C : ℝ} (hb : ∀ x, |f x| ≤ C) :
    (∫ ω, r ω * f (P ω) ∂μ) ≤ 0 := by
  obtain ⟨g, hg, hlim⟩ := continuous_monotone_approx hf hb
  apply le_of_tendsto' (tendsto_integral_of_dominated_convergence (μ := μ)
    (F := fun n ω => r ω * g n (P ω)) (fun _ => C)
    (fun n => (hr.mul ((hg n).1.measurable.comp hP)).aestronglyMeasurable) (integrable_const _) ?_ ?_)
    (fun n => htest _ (hg n).1 (hg n).2.1)
  · intro n
    filter_upwards [hrb] with ω hω
    rw [Real.norm_eq_abs, abs_mul]
    simpa using (mul_le_mul hω ((hg n).2.2 (P ω)) (abs_nonneg _) zero_le_one)
  · exact Filter.Eventually.of_forall fun ω => tendsto_const_nhds.mul (hlim (P ω))

end
end UL.Arxiv.BoundedBinary

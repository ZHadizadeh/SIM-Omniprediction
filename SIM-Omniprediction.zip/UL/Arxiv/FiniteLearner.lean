import UL.Arxiv.ScoreStability
import UL.Arxiv.PrescribedGrid

open Set
namespace UL.Arxiv.FiniteLearner
open GridOracle Proof_lem_C_2

noncomputable def label {K : ℕ} (y : Fin K) : Simplex K :=
  ⟨EuclideanSpace.single y 1, Proof_lem_A_1.single_mem_simplex y⟩

noncomputable def rows {n K : ℕ} (hK : 2 ≤ K) (s : Fin n → H K) (y : Fin n → Fin K)
    (B t : ℝ) : Fin n → E K :=
  row (fit hK (levels s B t) s B (fun i => (label (y i)).val))

open Classical in
noncomputable def centered {K : ℕ} (hK : 2 ≤ K) (v : E K) : H K :=
  if h : v ∈ Simplex K then center ⟨v,h⟩ hK else 0

/-- The unique probability output of the simplex quadratic program in Lemma D.3. -/
noncomputable def extend {n K : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n) (s : Fin n → H K)
    (p : Fin n → E K) {B : ℝ} (hB : 0 < B) (hp : ∀ i, p i ∈ Simplex K)
    (hcap : ∀ i j, ‖p i-p j‖ ≤ B*‖s i-s j‖) : H K → E K := by
  let iso := Proof_thm_C_1_Race3.isoZeroSum hK
  let sm := fun i => iso (s i)
  have hh i j : ‖p i-p j‖ ≤ B*‖sm i-sm j‖ := by
    simpa only [sm,← map_sub,LinearIsometryEquiv.norm_map] using hcap i j
  let h := UL.P_lem_C_4 (K-1) n K (by omega) hn hK sm p hp B hB hh
  let mat : Matrix (Fin K) (Fin n) ℝ := Matrix.of (fun k i => p i k)
  exact fun q => Matrix.toEuclideanLin mat ((h.1 (iso q)).choose)

theorem extend_spec {n K : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n) (s : Fin n → H K)
    (p : Fin n → E K) {B : ℝ} (hB : 0 < B) (hp : ∀ i, p i ∈ Simplex K)
    (hcap : ∀ i j, ‖p i-p j‖ ≤ B*‖s i-s j‖) :
    let ρ := extend hK hn s p hB hp hcap
    (∀ z, ρ z ∈ Simplex K) ∧ LipschitzWith B.toNNReal ρ ∧ ∀ i, ρ (s i) = p i := by
  intro ρ
  let iso := Proof_thm_C_1_Race3.isoZeroSum hK
  let sm := fun i => iso (s i)
  have hh i j : ‖p i-p j‖ ≤ B*‖sm i-sm j‖ := by
    simpa only [sm,← map_sub,LinearIsometryEquiv.norm_map] using hcap i j
  let h := UL.P_lem_C_4 (K-1) n K (by omega) hn hK sm p hp B hB hh
  obtain ⟨hr,hs,hi,hl,_⟩ := h.2.2 (fun q => (h.1 q).choose) (fun q => (h.1 q).choose_spec)
  exact ⟨fun q => hs (hr (iso q)), by simpa only [mul_one] using hl.comp iso.lipschitz, hi⟩

section
variable {K n : ℕ} {X : Type} [NormedAddCommGroup X] [InnerProductSpace ℝ X] [CompleteSpace X]

noncomputable def tolerance (n m : ℕ) (R L lam η : ℝ) : ℝ :=
  let a := η/(1+2*R*Real.sqrt m*L+3*lam)
  min 1 (a^2/(12*(n:ℝ)))

noncomputable def computed (hK : 2 ≤ K) (x : Fin n → X) (y : Fin n → Fin K)
    (R B t : ℝ) (w : ScoreGrid.V (dim x K)) : ℝ :=
  let W := toSampleSpanOp (Y:=H K) x w
  let p := rows hK (fun i => W (x i)) y B t
  certificate x R w (fun i => centered hK (p i)) (fun i => center (label (y i)) hK)

/-- Retain separated representatives of the projected rectangular grid, in
a fixed order. The half-mesh covering property also holds for repeated projections. -/
noncomputable def candidates {m : ℕ} {R : ℝ} (hR : 0 < R) (h : ℝ) :=
  let N := PrescribedGrid.level m R h
  PrescribedGrid.retain (fun a : Fin m → Fin (N+1) => (ScoreGrid.point hR a).val)
    (h/2) Finset.univ.toList

theorem candidates_cover {m : ℕ} {R h : ℝ} (hR : 0 < R) (hh : 0 < h) (w : ScoreGrid.Ball m R) :
    ∃ a ∈ candidates (m:=m) hR h, ‖(ScoreGrid.point hR a).val-w.val‖ ≤ h := by
  obtain ⟨b,hb⟩ := PrescribedGrid.covers hR hh w
  obtain ⟨a,ha,hba⟩ := PrescribedGrid.retain_cover (fun c : Fin m → Fin (PrescribedGrid.level m R h+1) =>
    (ScoreGrid.point hR c).val) (half_pos hh).le Finset.univ.toList b (by simp)
  have tri := dist_triangle (ScoreGrid.point hR a).val (ScoreGrid.point hR b).val w.val
  rw [dist_comm] at hba
  change dist (ScoreGrid.point hR b).val w.val ≤ h/2 at hb
  exact ⟨a,ha,by rw [← dist_eq_norm]; linarith⟩

/-- Appendix D's packing count applies to the list actually searched. -/
theorem candidate_count {m : ℕ} {R h : ℝ} (hR : 0 < R) (hh : 0 < h) :
    ((candidates (m:=m) hR h).length : ℝ) ≤ (1+4*R/h)^m := by
  classical
  let l := candidates (m:=m) hR h
  let pt := fun a : Fin m → Fin (PrescribedGrid.level m R h+1) => (ScoreGrid.point hR a).val
  have pair : l.Pairwise (fun a b => h/2 < dist (pt a) (pt b)) := PrescribedGrid.retain_separated _ _ _
  have nd : l.Nodup := pair.imp (fun d eq => by subst_vars; simpa using (lt_trans (half_pos hh) d))
  have symm : Symmetric (fun a b => h/2 < dist (pt a) (pt b)) := by
    intro a b hab
    rwa [dist_comm]
  have sep := (List.pairwise_iff_coe_toFinset_pairwise nd symm).mpr pair
  have cnt := PrescribedGrid.packing hR hh l.toFinset pt
    (fun a _ => by simpa only [Metric.mem_closedBall,dist_zero_right] using (ScoreGrid.point hR a).property)
    (fun _ ha _ hb ne => sep ha hb ne)
  rwa [List.toFinset_card_of_nodup nd] at cnt

open Classical in
noncomputable def index {m : ℕ} {R : ℝ} (hR : 0 < R) (h : ℝ) (f : ScoreGrid.V m → ℝ) :=
  let l := candidates (m:=m) hR h
  ScoreSearch.best (fun a => f (ScoreGrid.point hR a).val) (l.headD (fun _ => 0)) l

/-- Select a score matrix using the paper's prescribed mesh and computed gaps. -/
noncomputable def weights (hK : 2 ≤ K) (x : Fin n → X) (y : Fin n → Fin K)
    {R : ℝ} (hR : 0 < R) (L B lam η : ℝ) : ScoreGrid.Ball (dim x K) R :=
  let f := computed hK x y R B (tolerance n (dim x K) R L lam η)
  ScoreGrid.point hR (index hR (PrescribedGrid.mesh L R B η) f)

/-- The returned matrix minimizes the computed gap on the finite prescribed net.
Its approximate row fit extends to a joint link with the original slope cap. -/
theorem run_spec (hK : 2 ≤ K) (hn : 1 ≤ n)
    (x : Fin n → X) (y : Fin n → Fin K) {L R β B lam η : ℝ}
    (hL : 0 < L) (hx : ∀ i, ‖x i‖ ≤ L) (hR : 0 < R) (hβ : 0 < β) (hB : β ≤ B)
    (hlam : 0 < lam) (hη : 0 < η) :
    let w := weights hK x y hR L B lam η
    let W := toSampleSpanOp (Y:=H K) x w.val
    let s := fun i => W (x i)
    let t := tolerance n (dim x K) R L lam η
    let f := computed hK x y R B t
    let p := rows hK s y B t
    0 < PrescribedGrid.level (dim x K) R (PrescribedGrid.mesh L R B η) ∧ hilbertSchmidtNorm W ≤ R ∧
      (∀ v ∈ (sampleSpan x)ᗮ, W v = 0) ∧
      ∃ (hp : ∀ i, p i ∈ Simplex K) (hc : ∀ i j, ‖p i-p j‖ ≤ B*‖s i-s j‖),
        let ρ := extend hK hn s p (hβ.trans_le hB) hp hc
        (∀ z, ρ z ∈ Simplex K) ∧ LipschitzWith B.toNNReal ρ ∧ (∀ i, ρ (s i) = p i) ∧
        ∀ {M : ℝ} (Φ : Simplex K → ℝ), Φ ∈ SmoothEntropyFamily K β lam M →
          (1/(n:ℝ))*∑ i, finiteCanonicalLoss Φ (ρ (s i)) (y i) ≤
          (⨅ V : {V : X →L[ℝ] H K // hilbertSchmidtNorm V ≤ R},
            (1/(n:ℝ))*∑ i, matchingLoss Φ ((V.val (x i) : H K) : E K) (y i)) + 4*η := by
  classical
  intro w W s t f p
  let m := dim x K
  let h_lem_C_4 := UL.P_lem_C_4
  have hB_pos := hβ.trans_le hB
  let Z : Fin n → ZeroSumSubspace K := fun i =>
    ⟨EuclideanSpace.single (y i) (1 : ℝ) - uniformVec K,
      Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex
        (Proof_lem_A_1.single_mem_simplex (y i))
        (Proof_lem_A_5.uniformVec_mem_simplex hK)⟩
  have hZ : ∀ i : Fin n,
      (Z i : EuclideanSpace ℝ (Fin K)) = EuclideanSpace.single (y i) (1 : ℝ) - uniformVec K :=
    fun _ => rfl
  have hw_norm : ∀ w : Metric.closedBall (0 : EuclideanSpace ℝ (Fin m)) R, ‖w.1‖ ≤ R := by
    intro w
    have hw : w.1 ∈ Metric.closedBall (0 : EuclideanSpace ℝ (Fin m)) R := w.2
    rwa [Metric.mem_closedBall, dist_zero_right] at hw
  have hw_scores : ∀ w : Metric.closedBall (0 : EuclideanSpace ℝ (Fin m)) R,
      ∀ i : Fin n,
        ‖Proof_lem_C_2.toSampleSpanOp (Y := ZeroSumSubspace K) x w.1 (x i)‖ ≤ L * R := by
    intro w i
    calc ‖Proof_lem_C_2.toSampleSpanOp (Y := ZeroSumSubspace K) x w.1 (x i)‖
        ≤ hilbertSchmidtNorm
            (Proof_lem_C_2.toSampleSpanOp (Y := ZeroSumSubspace K) x w.1) * ‖x i‖ :=
          Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm _ (x i)
      _ = ‖w.1‖ * ‖x i‖ := by
          rw [Proof_lem_C_2.hilbertSchmidtNorm_toSampleSpanOp]
      _ ≤ R * L := mul_le_mul (hw_norm w) (hx i) (norm_nonneg _) hR.le
      _ = L * R := mul_comm R L
  let scoreMap : Metric.closedBall (0 : EuclideanSpace ℝ (Fin m)) R →
      {s : Fin n → ZeroSumSubspace K // ∀ i : Fin n, ‖s i‖ ≤ L * R} :=
    fun w => ⟨fun i => Proof_lem_C_2.toSampleSpanOp (Y := ZeroSumSubspace K) x w.1 (x i),
      hw_scores w⟩
  have h_score_cont : Continuous scoreMap :=
    ((Proof_lem_C_2.continuous_toSampleSpanOp_eval (Y := ZeroSumSubspace K) x).comp
      continuous_subtype_val).subtype_mk _
  let centeredFitMap : Metric.closedBall (0 : EuclideanSpace ℝ (Fin m)) R →
      (Fin n → ZeroSumSubspace K) :=
    fun w => Proof_lem_C_2.optFitScores (L * R) B Z (scoreMap w).1
  have h_centeredFitMap_cont : Continuous centeredFitMap :=
    (Proof_lem_C_2.continuous_optFitScores h_lem_C_4 hK hn hB_pos Z).comp h_score_cont
  let gMap : Metric.closedBall (0 : EuclideanSpace ℝ (Fin m)) R → EuclideanSpace ℝ (Fin m) :=
    fun w => Proof_lem_C_2.empGradVec x (fun i => centeredFitMap w i - Z i)
  have h_gMap_cont : Continuous gMap :=
    (Proof_lem_C_2.continuous_empGradVec x Z).comp h_centeredFitMap_cont

  let gap := fun w : ScoreGrid.Ball m R => inner ℝ (gMap w) w.val + R*‖gMap w‖
  have hg : Continuous gap := (h_gMap_cont.inner continuous_subtype_val).add (continuous_const.mul h_gMap_cont.norm)
  have hz := Proof_lem_C_2.exists_zero_gap_on_ball UL.P_cit_brouwer.{0} hR gMap h_gMap_cont
  let a := η/(1+2*R*Real.sqrt (m:ℝ)*L+3*lam)
  have ha : 0 < a := by dsimp [a]; positivity
  have hn' : (0:ℝ) < n := Nat.cast_pos.mpr (by omega)
  have ht : 0 < t := lt_min zero_lt_one (by change 0 < a^2/(12*(n:ℝ)); positivity)
  have ht' : t ≤ 1 := min_le_left _ _
  have he : Real.sqrt (12*(n:ℝ)*t) ≤ a := by
    apply (Real.sqrt_le_left ha.le).mpr
    have hb : t ≤ a^2/(12*(n:ℝ)) := min_le_right _ _
    linarith [(le_div_iff₀ (by positivity : 0 < 12*(n:ℝ))).mp hb]
  have budget : a*(1+2*R*Real.sqrt (m:ℝ)*L+3*lam) = η := by
    dsimp [a]; field_simp [show (1+2*R*Real.sqrt (m:ℝ)*L+3*lam) ≠ 0 by positivity]
  have blow : 0 ≤ 2*R*Real.sqrt (m:ℝ)*L*a := by positivity
  have tight : 2*R*(Real.sqrt (m:ℝ)*L*a) ≤ η := by nlinarith [mul_nonneg hlam.le ha.le]
  have lossBudget : (3*lam)*a ≤ η := by nlinarith
  let pp := fun v : ScoreGrid.Ball m R => rows hK (scoreMap v).val y B t
  have approx (v : ScoreGrid.Ball m R) :=
    approximate_rows hK hn (scoreMap v).val hB_pos ht ht' (hw_scores v) (fun i => label (y i)) (centeredFitMap v)
      (optFitScores_spec h_lem_C_4 hK hn hB_pos Z (hw_scores v))
  have dif (v : ScoreGrid.Ball m R) (i) : ‖pp v i-(uniformVec K+(centeredFitMap v i).val)‖ ≤ a :=
    ((approx v).2 i).trans he
  have err (v : ScoreGrid.Ball m R) : |f v.val-gap v| ≤ η := by
    apply le_trans _ tight
    apply gap_error hn x hx ha.le v.val (hw_norm v)
    intro i
    have hi := (approx v).1.1 i
    change pp v i ∈ Simplex K at hi
    change ‖centered hK (pp v i)-centeredFitMap v i‖ ≤ a
    rw [centered,dif_pos hi,← Submodule.norm_coe,Submodule.coe_sub]
    change ‖(pp v i-uniformVec K)-(centeredFitMap v i).val‖ ≤ a
    convert dif v i using 2 <;> abel
  obtain ⟨z,hz⟩ := hz
  let h := PrescribedGrid.mesh L R B η
  have hpos := PrescribedGrid.mesh_pos hL hR hB_pos hη
  obtain ⟨c,member,close⟩ := candidates_cover (m:=m) hR hpos z
  let v := ScoreGrid.point hR c
  have optAt (b : ScoreGrid.Ball m R) := optFitScores_spec h_lem_C_4 hK hn hB_pos Z (hw_scores b)
  have Zmem (i) : uniformVec K+(Z i).val ∈ Simplex K := by
    rw [hZ]; simpa only [add_sub_cancel] using Proof_lem_A_1.single_mem_simplex (y i)
  have stab := ScoreStability.certificate_modulus hn x hx hL.le hB_pos.le hpos.le v.val z.val close
    (hw_norm z) (centeredFitMap v) (centeredFitMap z) Z Zmem (hw_scores v) (hw_scores z) (optAt v) (optAt z)
  change |gap v-gap z| ≤ _ at stab
  change gap z = 0 at hz
  rw [hz,sub_zero] at stab
  have small : gap v < η := (le_abs_self _).trans_lt (stab.trans_lt (PrescribedGrid.modulus_on_mesh hL hR hB_pos hη))
  let l := candidates (m:=m) hR h
  have better := ScoreSearch.best_le (fun a => f (ScoreGrid.point hR a).val) (l.headD (fun _ => 0)) l c
    (List.mem_cons_of_mem _ member)
  have selected : f w.val < 2*η := better.trans_lt (by linarith [(abs_le.mp (err v)).2])
  have gapBound : gap w ≤ 3*η := by linarith [(abs_le.mp (err w)).1]
  have hp := (approx w).1.1
  have hc' := (approx w).1.2
  have hr := extend_spec hK hn s p hB_pos hp hc'
  have hW : hilbertSchmidtNorm W ≤ R := (hilbertSchmidtNorm_toSampleSpanOp x w.val).le.trans (hw_norm w)
  refine ⟨Nat.zero_lt_succ _,hW,(fun _ hv => toSampleSpanOp_vanishes_orth x w.val hv),hp,hc',hr.1,hr.2.1,hr.2.2,?_⟩
  intro M Φ hΦ
  simp_rw [hr.2.2]
  have opt := optFitScores_spec h_lem_C_4 hK hn hB_pos Z (hw_scores w)
  have trueEmp := empirical_comparison_bound hK hn x y hL hx hR hβ hB hZ hW (P:=centeredFitMap w) opt hΦ
  have eqG := gamma_toSampleSpanOp_eq x (fun i => centeredFitMap w i-Z i) R w.val
  dsimp only at trueEmp eqG
  have exactgap := eqG.le.trans gapBound
  have F := (exists_isBLip_iff h_lem_C_4 hK hn hB_pos (hw_scores w) (centeredFitMap w)).mp opt.1
  have each (i) : finiteCanonicalLoss Φ (p i) (y i) - finiteCanonicalLoss Φ (uniformVec K+(centeredFitMap w i).val) (y i) ≤ η :=
    (le_abs_self _).trans ((Proof_thm_5_1.finiteCanonicalLoss_lipschitz_on_simplex hK hΦ (hp i) (F.1 i) _).trans
      ((mul_le_mul_of_nonneg_left (dif w i) (by positivity)).trans lossBudget))
  have sum := Finset.sum_le_sum (s:=Finset.univ) fun i _ => each i
  rw [Finset.sum_sub_distrib,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul] at sum
  have scaled := mul_le_mul_of_nonneg_left sum (by positivity : 0 ≤ 1/(n:ℝ))
  rw [mul_sub,show (1/(n:ℝ))*((n:ℝ)*η)=η by field_simp] at scaled
  linarith

end
end UL.Arxiv.FiniteLearner

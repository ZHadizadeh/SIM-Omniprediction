import UL.Proof.cor_C_6.H2_EmpiricalLearner
import UL.Proof.cor_C_6.H3_BinaryProfiles

open TopologicalSpace
namespace UL.Arxiv.BinaryRounding

/-- Borel coding by a dense sequence. Any prediction rule on the countably
many codes becomes jointly measurable if it is continuous in the query. -/
theorem sampleCodes (X : Type*) [NormedAddCommGroup X] [TopologicalSpace.SeparableSpace X]
    [MeasurableSpace X] [BorelSpace X] (η : ℝ) (hη : 0 < η) :
    ∃ code : X → ℕ, Measurable code ∧ ∀ x, ‖x - denseSeq X (code x)‖ ≤ η := by
  classical
  have h (x : X) : ∃ i : ℕ, dist x (denseSeq X i) < η :=
    Metric.denseRange_iff.mp (denseRange_denseSeq X) x η hη
  refine ⟨fun x => Nat.find (h x), measurable_find h (fun i => ?_), fun x => ?_⟩
  · exact isOpen_lt (continuous_id.dist continuous_const) continuous_const |>.measurableSet
  · simpa only [← dist_eq_norm] using (Nat.find_spec (h x)).le

theorem jointEvaluation {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [MeasurableSpace X] [BorelSpace X] {n : ℕ}
    (code : X → ℕ) (hc : Measurable code)
    (w : (Fin n → ℕ × Fin 2) → X) (ρ : (Fin n → ℕ × Fin 2) → ℝ → ℝ)
    (hρ : ∀ a, Continuous (ρ a)) :
    Measurable (fun z : (Fin n → X × Fin 2) × X =>
      let a := fun i => (code (z.1 i).1, (z.1 i).2)
      ρ a (inner ℝ (w a) z.2)) := by
  let encode (s : Fin n → X × Fin 2) := fun i => (code (s i).1, (s i).2)
  have hm : Measurable encode := measurable_pi_lambda _ fun i =>
    (hc.comp (measurable_fst.comp (measurable_pi_apply i))).prodMk
      (measurable_snd.comp (measurable_pi_apply i))
  have h : Measurable (fun z : (Fin n → ℕ × Fin 2) × X => ρ z.1 (inner ℝ (w z.1) z.2)) :=
    measurable_from_prod_countable_right fun a =>
      ((hρ a).comp ((continuous_const (y := w a)).inner continuous_id)).measurable
  exact h.comp ((hm.comp measurable_fst).prodMk measurable_snd)

/-- Move an empirical comparison back from the coded features, charging
both the forecast and the comparator for their change in input. -/
theorem empiricalTransfer {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    {n : ℕ} (hn : 1 ≤ n) (x u : Fin n → X) (y : Fin n → Fin 2)
    {B R lam η : ℝ} (hB : 0 ≤ B) (hR : 0 ≤ R) (hlam : 0 ≤ lam)
    (hx : ∀ i, ‖x i - u i‖ ≤ η) {w v : X} (hw : ‖w‖ ≤ R) (hv : ‖v‖ ≤ R)
    {ρ : ℝ → ℝ} (hρ : LipschitzWith B.toNNReal ρ) (hp : ∀ t, ρ t ∈ Set.Icc (0:ℝ) 1)
    {φ : Set.Icc (0:ℝ) 1 → ℝ} (hφ : Continuous φ)
    {a : ℝ → ℝ} (ha : ∀ s ∈ Set.Icc (0:ℝ) 1, ∀ t ∈ Set.Icc (0:ℝ) 1,
      |a s-a t| ≤ lam * |s-t|)
    (emp : (1/(n:ℝ)) * ∑ i, binaryMatchingLoss φ (a (ρ (inner ℝ w (u i)))) (y i) ≤
      (1/(n:ℝ)) * ∑ i, binaryMatchingLoss φ (inner ℝ v (u i)) (y i)) :
    (1/(n:ℝ)) * ∑ i, binaryMatchingLoss φ (a (ρ (inner ℝ w (x i)))) (y i) ≤
      (1/(n:ℝ)) * ∑ i, binaryMatchingLoss φ (inner ℝ v (x i)) (y i) +
        (lam * B + 1) * R * η := by
  have hdist (z : X) (hz : ‖z‖ ≤ R) (i : Fin n) :
      |inner ℝ z (x i) - inner ℝ z (u i)| ≤ R * η := by
    rw [← inner_sub_right]
    exact (abs_real_inner_le_norm _ _).trans (mul_le_mul hz (hx i) (norm_nonneg _) hR)
  have hpoint (i : Fin n) :
      binaryMatchingLoss φ (a (ρ (inner ℝ w (x i)))) (y i) -
        binaryMatchingLoss φ (a (ρ (inner ℝ w (u i)))) (y i) ≤ lam * (B * (R * η)) := by
    apply (le_abs_self _).trans
    apply (Proof_cor_C_6.abs_binaryMatchingLoss_sub_le hφ _ _ _).trans
    apply (ha _ (hp _) _ (hp _)).trans
    apply mul_le_mul_of_nonneg_left _ hlam
    have h := hρ.dist_le_mul (inner ℝ w (x i)) (inner ℝ w (u i))
    rw [Real.coe_toNNReal B hB, Real.dist_eq, Real.dist_eq] at h
    exact h.trans (mul_le_mul_of_nonneg_left (hdist w hw i) hB)
  have hcomp (i : Fin n) : binaryMatchingLoss φ (inner ℝ v (u i)) (y i) -
      binaryMatchingLoss φ (inner ℝ v (x i)) (y i) ≤ R * η := by
    apply (le_abs_self _).trans
    apply (Proof_cor_C_6.abs_binaryMatchingLoss_sub_le hφ _ _ _).trans
    rw [abs_sub_comm]; exact hdist v hv i
  have avg {f g : Fin n → ℝ} {c : ℝ} (h : ∀ i, f i - g i ≤ c) :
      (1/(n:ℝ)) * ∑ i, f i - (1/(n:ℝ)) * ∑ i, g i ≤ c := by
    have hh := Finset.sum_le_sum (s := Finset.univ) fun i _ => h i
    rw [Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul] at hh
    rw [← mul_sub]
    calc _ ≤ (1/(n:ℝ)) * ((n:ℝ) * c) := mul_le_mul_of_nonneg_left hh (by positivity)
         _ = c := by field_simp [show (n:ℝ) ≠ 0 by exact_mod_cast (show n ≠ 0 by omega)]
  linarith [avg hpoint, avg hcomp, show (lam * B + 1) * R * η = lam * (B * (R*η)) + R*η by ring]

end UL.Arxiv.BinaryRounding

import UL.Arxiv.FiniteSlope
import UL.Arxiv.MonotoneTests
import Mathlib.MeasureTheory.Constructions.UnitInterval
/-! # Appendix A.2, approximation before the compactness argument

A fractional label is realized as the expectation of a binary label using an independent
uniform random variable. Since each matching loss is affine in the label, all the
comparisons transfer back to the original feature-label law.
-/
open Set Filter MeasureTheory
open scoped NNReal
open UL.Proof_thm_3_2
namespace UL.Arxiv.BoundedBinary
noncomputable section

private def draw (y t : Probability) : Fin 2 := if t ≤ y then 1 else 0

private lemma mean_draw (y : Probability) :
    (∫ t : Probability, yReal (draw y t)) = y := by
  have hid : (fun t => yReal (draw y t)) = (Iic y).indicator (1 : Probability → ℝ) := by
    funext t
    by_cases h : t ≤ y <;> simp [draw, h, yReal, Set.indicator, mem_Iic]
  rw [hid, integral_indicator_one measurableSet_Iic, measureReal_def, unitInterval.volume_Iic,
    ENNReal.toReal_ofReal y.2.1]

variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]

private lemma measurable_draw {Y : Ω → Probability} (hY : Measurable Y) :
    Measurable (fun z : Ω × Probability => draw (Y z.1) z.2) :=
  Measurable.ite (measurableSet_le measurable_snd (hY.comp measurable_fst)) measurable_const measurable_const

private theorem residual_transfer {Y P : Ω → Probability} (hY : Measurable Y)
    (hP : Measurable P) {f : Ω → ℝ} (hf : Measurable f) (hfi : Integrable f μ) :
    (∫ z : Ω × Probability, ((P z.1 : ℝ) - yReal (draw (Y z.1) z.2)) * f z.1 ∂(μ.prod volume)) =
      ∫ ω, ((P ω : ℝ) - Y ω) * f ω ∂μ := by
  have hi := (measurePreserving_fst (μ := μ) (ν := (volume : Measure Probability))).integrable_comp_of_integrable hfi.norm
  rw [integral_prod]
  · apply integral_congr_ae
    filter_upwards with ω
    rw [integral_mul_const, integral_sub, integral_const, mean_draw, probReal_univ, one_smul]
    · exact integrable_const _
    · have hm : Measurable (fun t : Probability => draw (Y ω) t) :=
        Measurable.ite measurableSet_Iic measurable_const measurable_const
      apply (integrable_const (1 : ℝ)).mono' (measurable_yReal hm).aestronglyMeasurable
      filter_upwards with t
      rw [Real.norm_eq_abs, abs_of_nonneg (yReal_mem_Icc _).1]
      exact (yReal_mem_Icc _).2
  · apply hi.mono' (((measurable_subtype_coe.comp (hP.comp measurable_fst)).sub
        (measurable_yReal (measurable_draw hY))).mul (hf.comp measurable_fst)).aestronglyMeasurable
    filter_upwards with z
    rw [Real.norm_eq_abs, abs_mul]
    have h := (P z.1).2
    have hy := yReal_mem_Icc (draw (Y z.1) z.2)
    have hbound : |(P z.1 : ℝ) - yReal (draw (Y z.1) z.2)| ≤ 1 :=
      abs_le.mpr ⟨by linarith [h.1, hy.2], by linarith [h.2, hy.1]⟩
    simpa [Function.comp_def, Real.norm_eq_abs] using
      (mul_le_mul_of_nonneg_right hbound (abs_nonneg (f z.1)))

/-- Generate a common monotone fit for all bounded monotone tests, for fractional labels.
The test and moment conclusions are the inputs to the weak-limit step of the paper. -/
theorem exists_approximate_moments_with_slope {d : ℕ} (μ : Measure Ω) [IsProbabilityMeasure μ]
    (X : Ω → Features d) (Y : Ω → Probability) (hX : Measurable X) (hY : Measurable Y)
    (hXi : Integrable (fun ω => ‖X ω‖) μ) (R B : ℝ) (hR : 0 < R) (hB : 0 < B) :
    ∃ (w : Features d) (ρ : ℝ → Probability), ‖w‖ ≤ R ∧ Monotone ρ ∧ Measurable ρ ∧
      LipschitzWith B.toNNReal ρ ∧
      let P := fun ω => ρ (inner ℝ w (X ω))
      (∀ f : ℝ → ℝ, Monotone f → ∀ C : ℝ, (∀ x, |f x| ≤ C) →
        (∫ ω, ((P ω : ℝ) - Y ω) * f (P ω) ∂μ) ≤ 0) ∧
      (∀ v : Features d, ‖v‖ ≤ R →
        -(1 / (16 * B)) ≤ ∫ ω, ((P ω : ℝ) - Y ω) * inner ℝ v (X ω) ∂μ) := by
  let ν := μ.prod (volume : Measure Probability)
  let y (z : Ω × Probability) := draw (Y z.1) z.2
  let X' (z : Ω × Probability) := X z.1
  have hXi' : Integrable (fun z => ‖X' z‖) ν :=
    (measurePreserving_fst (μ := μ) (ν := (volume : Measure Probability))).integrable_comp_of_integrable hXi
  obtain ⟨w, g, hw, hg, ht, hv⟩ := exists_finite_slope_fit ν X' y
    (hX.comp measurable_fst) (measurable_draw hY) hXi' R B hR hB
  let ρ (t : ℝ) : Probability := ⟨g t, hg.2.2 t⟩
  let P (ω : Ω) := ρ (inner ℝ w (X ω))
  have hρ : Monotone ρ := fun _ _ h => hg.1 h
  have hP : Measurable P := hρ.measurable.comp ((continuous_const.inner continuous_id).measurable.comp hX)
  have hval : Measurable (fun z : Ω × Probability => (P z.1 : ℝ)) :=
    measurable_subtype_coe.comp (hP.comp measurable_fst)
  refine ⟨w, ρ, hw, hρ, hρ.measurable, (fun x y => hg.2.1 x y), ?_, ?_⟩
  · intro f hm C hC
    have hf : Measurable (fun ω => f (P ω)) := hm.measurable.comp (measurable_subtype_coe.comp hP)
    have hfi : Integrable (fun ω => f (P ω)) μ := (integrable_const C).mono'
      hf.aestronglyMeasurable (Eventually.of_forall fun ω => by simpa [Real.norm_eq_abs] using hC (P ω))
    apply (residual_transfer hY hP hf hfi).ge.trans
    apply test_of_continuous_tests (hval.sub (measurable_yReal (measurable_draw hY))) hval _ ht hm hC
    exact Eventually.of_forall (abs_fitRes_le_one (fun z : Ω × Probability => (P z.1).2) y)
  · intro v hvR
    have hf : Measurable (fun ω => inner ℝ v (X ω)) := (continuous_const.inner continuous_id).measurable.comp hX
    have hfi : Integrable (fun ω => inner ℝ v (X ω)) μ :=
      (hXi.const_mul ‖v‖).mono' hf.aestronglyMeasurable
        (Eventually.of_forall fun ω => by simpa [Real.norm_eq_abs] using abs_real_inner_le_norm v (X ω))
    exact (hv v hvR).trans_eq (residual_transfer hY hP hf hfi)

theorem exists_approximate_moments {d : ℕ} (μ : Measure Ω) [IsProbabilityMeasure μ]
    (X : Ω → Features d) (Y : Ω → Probability) (hX : Measurable X) (hY : Measurable Y)
    (hXi : Integrable (fun ω => ‖X ω‖) μ) (R B : ℝ) (hR : 0 < R) (hB : 0 < B) :
    ∃ (w : Features d) (ρ : ℝ → Probability), ‖w‖ ≤ R ∧ Monotone ρ ∧ Measurable ρ ∧
      let P := fun ω => ρ (inner ℝ w (X ω))
      (∀ f : ℝ → ℝ, Monotone f → ∀ C : ℝ, (∀ x, |f x| ≤ C) →
        (∫ ω, ((P ω : ℝ) - Y ω) * f (P ω) ∂μ) ≤ 0) ∧
      (∀ v : Features d, ‖v‖ ≤ R →
        -(1 / (16 * B)) ≤ ∫ ω, ((P ω : ℝ) - Y ω) * inner ℝ v (X ω) ∂μ) := by
  obtain ⟨w, ρ, hw, hm, hmeas, _, ht, hv⟩ :=
    exists_approximate_moments_with_slope μ X Y hX hY hXi R B hR hB
  exact ⟨w, ρ, hw, hm, hmeas, ht, hv⟩

/-- Arbitrarily small positive excess for the full target class, including arbitrary choices
at ties. There is no compactness condition on the family at this approximation stage. -/
theorem exists_approximate_forecast_with_slope {d : ℕ} (μ : Measure Ω) [IsProbabilityMeasure μ]
    (X : Ω → Features d) (Y : Ω → Probability) (hX : Measurable X) (hY : Measurable Y)
    (L R : ℝ≥0) (hR : 0 < R) (hL : ∀ᵐ ω ∂μ, ‖X ω‖ ≤ (L : ℝ)) (ε : ℝ) (hε : 0 < ε) :
    ∃ (w : Features d) (ρ : ℝ → Probability), ‖w‖ ≤ (R : ℝ) ∧ Monotone ρ ∧ Measurable ρ ∧
      LipschitzWith (1 / (16 * ε)).toNNReal ρ ∧
      ∀ σ : Target (L * R), ∀ k : Probability → Action (L * R), IsBayes σ k →
        ∀ v : Features d, ‖v‖ ≤ (R : ℝ) →
        (∫ ω, loss σ (k (ρ (inner ℝ w (X ω)))) (Y ω) ∂μ) ≤
          (∫ ω, loss σ (inner ℝ v (X ω)) (Y ω) ∂μ) + ε := by
  have hXi : Integrable (fun ω => ‖X ω‖) μ :=
    (integrable_const (L : ℝ)).mono' hX.norm.aestronglyMeasurable (by simpa using hL)
  let B := 1 / (16 * ε)
  have hB : 0 < B := by dsimp [B]; positivity
  obtain ⟨w, ρ, hw, hm, mρ, hLip, ht, hlin⟩ := exists_approximate_moments_with_slope μ X Y hX hY hXi R B hR hB
  let P ω := ρ (inner ℝ w (X ω))
  have hPm : Measurable P := mρ.comp ((continuous_const.inner continuous_id).measurable.comp hX)
  refine ⟨w, ρ, hw, hm, mρ, hLip, ?_⟩
  intro σ k hk v hv
  let a ω := inner ℝ v (X ω)
  have ha : Measurable a := (continuous_const.inner continuous_id).measurable.comp hX
  have hclip : ∀ᵐ ω ∂μ, (clip (L*R) (a ω) : ℝ) = a ω := by
    filter_upwards [hL] with ω hω
    simp only [a, clip, Set.projIcc_of_mem _ (score_mem hv hω)]
  let f (x : ℝ) := (k (Set.projIcc 0 1 zero_le_one x) : ℝ)
  have hf : Monotone f := fun _ _ h => hk.monotone (Set.monotone_projIcc _ h)
  have hb (x : ℝ) : |f x| ≤ ((L*R : ℝ≥0) : ℝ) := abs_le.mpr (k _).2
  have hrep := ht f hf _ hb
  simp only [f, Set.projIcc_val] at hrep
  have hlinear := hlin v hv
  rw [show 1 / (16 * B) = ε by dsimp [B]; field_simp] at hlinear
  have hlt : -ε ≤ ∫ ω, ((P ω : ℝ) - Y ω) * (clip (L*R) (a ω) : ℝ) ∂μ := by
    apply hlinear.trans_eq
    exact integral_congr_ae (hclip.mono fun ω h => congrArg (fun t => ((P ω : ℝ) - Y ω) * t) h.symm)
  have h := risk_le_of_residual hk hPm hY (continuous_projIcc.measurable.comp ha) hrep hlt
  exact h.trans_eq (congrArg (· + ε) (integral_congr_ae (hclip.mono fun ω he =>
    congrArg (fun t => loss σ t (Y ω)) he)))

theorem exists_approximate_forecast {d : ℕ} (μ : Measure Ω) [IsProbabilityMeasure μ]
    (X : Ω → Features d) (Y : Ω → Probability) (hX : Measurable X) (hY : Measurable Y)
    (L R : ℝ≥0) (hR : 0 < R) (hL : ∀ᵐ ω ∂μ, ‖X ω‖ ≤ (L : ℝ)) (ε : ℝ) (hε : 0 < ε) :
    ∃ (w : Features d) (ρ : ℝ → Probability), ‖w‖ ≤ (R : ℝ) ∧ Monotone ρ ∧ Measurable ρ ∧
      ∀ σ : Target (L * R), ∀ k : Probability → Action (L * R), IsBayes σ k →
        ∀ v : Features d, ‖v‖ ≤ (R : ℝ) →
        (∫ ω, loss σ (k (ρ (inner ℝ w (X ω)))) (Y ω) ∂μ) ≤
          (∫ ω, loss σ (inner ℝ v (X ω)) (Y ω) ∂μ) + ε := by
  obtain ⟨w, ρ, hw, hm, hmeas, _, h⟩ :=
    exists_approximate_forecast_with_slope μ X Y hX hY L R hR hL ε hε
  exact ⟨w, ρ, hw, hm, hmeas, h⟩

end
end UL.Arxiv.BoundedBinary

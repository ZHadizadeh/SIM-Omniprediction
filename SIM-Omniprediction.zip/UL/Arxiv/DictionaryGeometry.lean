import UL.Proof.thm_7_1.Race2.H1_Dirichlet
import UL.Proof.lem_A_1.H1_FaceSubgrad

namespace UL.Arxiv
open Proof_thm_7_1_Race2

/-- On an affinely independent dictionary, the affine barycentric coordinates
interpolate the vertices. The Gram matrix of their gradients is exactly the
pseudoinverse of the centered feature Gram matrix. The identity needs no
assumption on the angles. -/
theorem barycentricGradientGram {N d : ℕ} (x : Fin N → EuclideanSpace ℝ (Fin d))
    (hN : 1 ≤ N) (hrank : (centeredGramMatrix x).rank = N - 1) :
    ∃ (bary : Fin N → EuclideanSpace ℝ (Fin d) → ℝ)
      (g : Fin N → EuclideanSpace ℝ (Fin d)),
      (∀ i p, bary i p = 1 / (N:ℝ) +
        inner ℝ (g i) (p - (1 / (N:ℝ)) • ∑ k, x k)) ∧
      (∀ i j, bary i (x j) = if i = j then 1 else 0) ∧
      (∀ i p, HasFDerivAt (bary i) (innerSL ℝ (g i)) p) ∧
      (∀ i, g i ∈ Submodule.span ℝ (Set.range (fun j => x j - (1 / (N:ℝ)) • ∑ k, x k))) ∧
      (∀ i j, inner ℝ (g i) (g j) = moorePenrosePseudoinverse (centeredGramMatrix x) i j) ∧
      (DirichletFeatureCondition x ↔ ∀ i j, i ≠ j → inner ℝ (g i) (g j) ≤ 0) := by
  classical
  let G := centeredGramMatrix x
  let L := moorePenrosePseudoinverse G
  let C := centeringMatrix N * dictionaryRowMatrix x
  let D := L * C
  let g (i : Fin N) := WithLp.toLp 2 (D i)
  let mean := (1 / (N:ℝ)) • ∑ i, x i
  let bary (i : Fin N) (p : EuclideanSpace ℝ (Fin d)) :=
    1 / (N:ℝ) + (innerSL ℝ (g i)) (p - mean)
  have hGT : G.transpose = G := centeredGramMatrix_transpose x
  have hLT : L.transpose = L := moorePenrose_transpose_of_isSymm hGT
  have hG : C * C.transpose = G := (centeredGramMatrix_eq_mul_transpose x).symm
  have hGL : G * L = centeringMatrix N := centeredGram_mul_pseudoinverse_of_rank hN hrank
  have hLG : L * G = centeringMatrix N := by
    simpa only [Matrix.transpose_mul,hLT,hGT,centeringMatrix_transpose] using
      congrArg Matrix.transpose hGL
  have hvertex : D * C.transpose = centeringMatrix N := by
    change (L * C) * C.transpose = _
    rw [Matrix.mul_assoc, hG, hLG]
  have hGram : D * D.transpose = L := by
    change (L*C)*(L*C).transpose = L
    rw [Matrix.transpose_mul,hLT,← Matrix.mul_assoc,Matrix.mul_assoc L C,hG]
    exact (moorePenrose_spec_of_isSymm hGT).2.1
  have hg (i j : Fin N) : inner ℝ (g i) (g j) = L i j := by
    rw [← hGram]
    simp only [Matrix.mul_apply, Matrix.transpose_apply, Proof_lem_A_1.inner_eq_sum]
    rfl
  have htangent (i : Fin N) :
      g i ∈ Submodule.span ℝ (Set.range (fun j => x j - mean)) := by
    have he : g i = ∑ j, L i j • (x j - mean) := by
      ext k
      change (L * C) i k = _
      rw [Matrix.mul_apply, Proof_lem_A_1.sum_apply]
      exact Finset.sum_congr rfl fun j _ => congrArg (L i j * ·) (centeredDict_row_apply x j k)
    rw [he]
    exact Submodule.sum_mem _ fun j _ =>
      Submodule.smul_mem _ _ (Submodule.subset_span (Set.mem_range_self j))
  refine ⟨bary, g, fun _ _ => rfl, ?_, ?_, htangent, hg, ?_⟩
  · intro i j
    have hv := congrArg (fun M : Matrix (Fin N) (Fin N) ℝ => M i j) hvertex
    simp only [Matrix.mul_apply,Matrix.transpose_apply,centeringMatrix_apply] at hv
    change 1 / (N:ℝ) + inner ℝ (g i) (x j - mean) = _
    rw [Proof_lem_A_1.inner_eq_sum]
    have he : (∑ k, (g i) k * (x j - mean) k) = ∑ k, D i k * C j k :=
      Finset.sum_congr rfl fun k _ => congrArg (D i k * ·) (centeredDict_row_apply x j k).symm
    rw [he, hv]
    ring
  · intro i p
    simpa [bary, Function.comp_def] using
      (((innerSL ℝ (g i)).hasFDerivAt.comp p ((hasFDerivAt_id p).sub_const mean)).const_add
        (1 / (N:ℝ)))
  · constructor
    · intro h i j hij
      rw [hg]
      exact h.2.2 i j hij
    · intro h
      refine ⟨hN, by omega, fun i j hij => ?_⟩
      change L i j ≤ 0
      rw [← hg i j]
      exact h i j hij

/-- For inward facet normals the interior dihedral angle is the supplement
of their angle. The Gram sign test is precisely the nonobtuse-angle test. -/
theorem nonobtuseInteriorAngle {d : ℕ} (v w : EuclideanSpace ℝ (Fin d)) :
    inner ℝ v w ≤ 0 ↔ Real.pi - InnerProductGeometry.angle v w ≤ Real.pi/2 := by
  by_cases hv : v = 0
  · subst v; simp [InnerProductGeometry.angle]
  by_cases hw : w = 0
  · subst w; simp [InnerProductGeometry.angle]
  have hmid : Real.pi/2 ∈ Set.Icc (0:ℝ) Real.pi :=
    ⟨by linarith [Real.pi_pos], by linarith [Real.pi_pos]⟩
  have hangle : InnerProductGeometry.angle v w ∈ Set.Icc (0:ℝ) Real.pi :=
    ⟨InnerProductGeometry.angle_nonneg _ _, InnerProductGeometry.angle_le_pi _ _⟩
  have he := Real.strictAntiOn_cos.le_iff_ge hangle hmid
  rw [InnerProductGeometry.cos_angle,Real.cos_pi_div_two,
    div_le_iff₀ (mul_pos (norm_pos_iff.mpr hv) (norm_pos_iff.mpr hw)),zero_mul] at he
  rw [he]; constructor <;> intro h <;> linarith

/-- A dictionary containing all four corners of an affine rectangle cannot
satisfy the rank condition. This applies to a full product of two nontrivial
categorical blocks, even if additional features are held fixed. -/
theorem rectanglePrecludesDirichlet {N d : ℕ} (x : Fin N → EuclideanSpace ℝ (Fin d))
    (a b c e : Fin N) (hab : a ≠ b) (hac : a ≠ c) (hae : a ≠ e)
    (hx : x a + x e = x b + x c) : ¬ DirichletFeatureCondition x := by
  intro hd
  obtain ⟨bary,g,haff,hvertex,_⟩ := barycentricGradientGram x hd.1 (by
    have h := hd.2.1
    omega)
  have hsum : bary a (x a) + bary a (x e) = bary a (x b) + bary a (x c) := by
    have h := congrArg (fun v => inner ℝ (g a) v) hx
    simp only [inner_add_right] at h
    simp only [haff, inner_sub_right]
    linarith
  simp [hvertex,hab,hac,hae] at hsum

end UL.Arxiv

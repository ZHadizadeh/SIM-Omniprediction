import UL.Proof.thm_7_1.Race2.Centering

namespace UL.Arxiv.OneHot

open MeasureTheory UL.Proof_thm_7_1_Race2

noncomputable def point {d : ℕ} (i : Fin d) : EuclideanSpace ℝ (Fin d) :=
  EuclideanSpace.single i 1

theorem dirichlet {d : ℕ} (hd : 1 ≤ d) : DirichletFeatureCondition (@point d) := by
  classical
  let J := centeringMatrix d
  have hrow : dictionaryRowMatrix (@point d) = 1 := by
    ext i j
    simp [dictionaryRowMatrix, point, EuclideanSpace.single_apply, Matrix.one_apply, eq_comm]
  have hid : J * J = J := centeringMatrix_mul_self hd
  have hgram : centeredGramMatrix (@point d) = J := by
    simpa [centeredGramMatrix, hrow] using hid
  have htrans : J.transpose = J := centeringMatrix_transpose d
  have hpen : IsMoorePenrosePseudoinverse J J :=
    ⟨by rw [hid, hid], by rw [hid, hid], by rw [hid, htrans], by rw [hid, htrans]⟩
  have hpinv : moorePenrosePseudoinverse J = J := by
    unfold moorePenrosePseudoinverse
    rw [dif_pos (show ∃ B, IsMoorePenrosePseudoinverse J B from ⟨J, hpen⟩)]
    exact moorePenrose_unique (Classical.choose_spec _) hpen
  refine ⟨hd, ?_, ?_⟩
  · have hker : LinearMap.ker J.mulVecLin = Submodule.span ℝ {(1 : Fin d → ℝ)} := by
      apply le_antisymm
      · intro x hx
        change J.mulVec x = 0 at hx
        apply Submodule.mem_span_singleton.mpr
        refine ⟨(1 / (d : ℝ)) * ∑ j, x j, ?_⟩
        ext i
        have h := congrFun hx i
        change (∑ j, centeringMatrix d i j * x j) = 0 at h
        simp only [centeringMatrix_apply, sub_mul, Finset.sum_sub_distrib, ite_mul,
          one_mul, zero_mul, Finset.sum_ite_eq, Finset.mem_univ, if_true,
          ← Finset.mul_sum] at h
        change _ * 1 = x i
        rw [mul_one]
        linarith
      · exact Submodule.span_le.mpr (Set.singleton_subset_iff.mpr (centeringMatrix_mulVec_one hd))
    have hone : (1 : Fin d → ℝ) ≠ 0 := by
      intro h
      have := congrFun h ⟨0, by omega⟩
      norm_num at this
    have hrn := LinearMap.finrank_range_add_finrank_ker J.mulVecLin
    rw [hker, finrank_span_singleton hone, Module.finrank_fin_fun] at hrn
    rw [hgram]
    change ((Module.finrank ℝ (LinearMap.range J.mulVecLin) : ℕ) : ℤ) = (d : ℤ) - 1
    omega
  · intro i j hij
    rw [hgram, hpinv]
    change centeringMatrix d i j ≤ 0
    rw [centeringMatrix_apply, if_neg hij]
    exact sub_le_self _ (by positivity)

/-- Uniform mass on the coordinate vectors. -/
noncomputable def law (d : ℕ) : Measure (EuclideanSpace ℝ (Fin d)) :=
  (d : ENNReal)⁻¹ • Measure.sum (fun i : Fin d => Measure.dirac (point i))

theorem law_prob {d : ℕ} (hd : 1 ≤ d) : IsProbabilityMeasure (law d) := by
  constructor
  have hn : (d : ENNReal) ≠ 0 := by exact_mod_cast (show d ≠ 0 by omega)
  simp [law, Measure.sum_fintype, Measure.finset_sum_apply, ENNReal.inv_mul_cancel hn]
  
theorem law_unit {d : ℕ} : ∀ᵐ x ∂law d, ‖x‖ = 1 := by
  unfold law
  apply Measure.ae_smul_measure
  apply Measure.ae_sum_iff.mpr
  intro i
  simp [point, EuclideanSpace.norm_single]

theorem integral_law {d : ℕ} (g : EuclideanSpace ℝ (Fin d) → ℝ) :
    ∫ x, g x ∂law d = (d : ℝ)⁻¹ * ∑ i, g (point i) := by
  rw [law, integral_smul_measure, Measure.sum_fintype,
    integral_finset_sum_measure (fun i _ => integrable_dirac (by simp))]
  simp [ENNReal.toReal_inv]

theorem covariance {d : ℕ} (i j : Fin d) :
    ∫ x, x i * x j ∂law d = if i = j then 1 / (d : ℝ) else 0 := by
  rw [integral_law]
  simp [point, EuclideanSpace.single_apply, one_div]

end UL.Arxiv.OneHot

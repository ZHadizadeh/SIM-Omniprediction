import Mathlib

open Set
namespace UL.Arxiv

/-- A compact family of continuous objectives with a continuous secondary
criterion. The unique lexicographic minimizer is Borel in the data, even
when the primary objective has several minimizers. -/
theorem measurableLexicographicMinimum {S W : Type*} [TopologicalSpace S]
    [MeasurableSpace S] [BorelSpace S] [TopologicalSpace W] [CompactSpace W]
    [MeasurableSpace W] [BorelSpace W]
    (f : S → W → ℝ) (hf : Continuous (Function.uncurry f))
    (g : W → ℝ) (hg : Continuous g) (choose : S → W)
    (hmin : ∀ s w, f s (choose s) ≤ f s w)
    (htie : ∀ s w, f s w = f s (choose s) → g (choose s) ≤ g w)
    (hunique : ∀ s w, f s w = f s (choose s) → g w = g (choose s) → w = choose s) :
    Measurable choose := by
  classical
  let G : Set (S × W) := {z | ∀ v, f z.1 z.2 ≤ f z.1 v}
  have hG : IsClosed G := by
    have heq : G = ⋂ v : W, {z : S × W | f z.1 z.2 ≤ f z.1 v} := by
      ext z; simp [G]
    rw [heq]
    exact isClosed_iInter fun v => isClosed_le hf (hf.comp (continuous_fst.prodMk continuous_const))
  have hval : Measurable (fun s => g (choose s)) := by
    apply measurable_of_Iic
    intro t
    have heq : (fun s => g (choose s)) ⁻¹' Iic t =
        Prod.fst '' (G ∩ {z : S × W | g z.2 ≤ t}) := by
      ext s
      constructor
      · intro h
        exact ⟨(s,choose s),⟨hmin s,h⟩,rfl⟩
      · rintro ⟨⟨s,w⟩,⟨hw,h⟩,rfl⟩
        exact (htie s w (le_antisymm (hw _) (hmin s w))).trans h
    rw [heq]
    exact (isClosedMap_fst_of_compactSpace _ (hG.inter (isClosed_le
      (hg.comp continuous_snd) continuous_const))).measurableSet
  apply measurable_of_isClosed
  intro A hA
  let C : Set ((S × ℝ) × W) := {z | (z.1.1,z.2) ∈ G ∧ z.2 ∈ A ∧ g z.2 ≤ z.1.2}
  have hC : IsClosed C := (hG.preimage ((continuous_fst.comp continuous_fst).prodMk
    continuous_snd)).inter ((hA.preimage continuous_snd).inter
      (isClosed_le (hg.comp continuous_snd) (continuous_snd.comp continuous_fst)))
  have heq : choose ⁻¹' A = (fun s => (s,g (choose s))) ⁻¹' (Prod.fst '' C) := by
    ext s
    constructor
    · intro hs
      exact ⟨((s,g (choose s)),choose s),⟨hmin s,hs,le_rfl⟩,rfl⟩
    · rintro ⟨⟨⟨s',t⟩,w⟩,⟨hw,hwA,hwt⟩,he⟩
      change (s',t) = (s,g (choose s)) at he
      cases he
      have hfw := le_antisymm (hw (choose s)) (hmin s w)
      change choose s ∈ A
      rwa [← hunique s w hfw (le_antisymm hwt (htie s w hfw))]
  rw [heq]
  exact (measurable_id.prodMk hval) (isClosedMap_fst_of_compactSpace _ hC).measurableSet

/-- Apply the selection lemma on a closed Euclidean ball. Convexity of
each least-squares objective makes its minimum-norm minimizer unique. -/
theorem minimumNormBallFit {S E : Type*} [TopologicalSpace S] [MeasurableSpace S]
    [BorelSpace S] [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    [FiniteDimensional ℝ E] [MeasurableSpace E] [BorelSpace E] {R : ℝ} (hR : 0 ≤ R) (f : S → E → ℝ)
    (hf : Continuous (Function.uncurry f))
    (hc : ∀ s, ConvexOn ℝ (Metric.closedBall (0:E) R) (f s)) :
    ∃ select : S → E, Measurable select ∧
      ∀ s, ‖select s‖ ≤ R ∧
        (∀ w, ‖w‖ ≤ R → f s (select s) ≤ f s w) ∧
        ∀ w, ‖w‖ ≤ R → f s w = f s (select s) → ‖select s‖ ≤ ‖w‖ := by
  classical
  let B := Metric.closedBall (0:E) R
  have hB : IsCompact B := isCompact_closedBall _ _
  letI : CompactSpace ↥B := isCompact_iff_compactSpace.mp hB
  have hne : B.Nonempty := ⟨0, by simpa [B] using hR⟩
  have existsTie (s : S) : ∃ w : B, (∀ v : B, f s w ≤ f s v) ∧
      ∀ v : B, f s v = f s w → ‖w.val‖ ≤ ‖v.val‖ := by
    have hcont : Continuous (f s) := hf.comp (continuous_const.prodMk continuous_id)
    obtain ⟨u,hu,hmin⟩ := hB.exists_isMinOn hne hcont.continuousOn
    let A := B ∩ {v | f s v = f s u}
    have ha : IsCompact A := hB.inter_right (isClosed_eq hcont continuous_const)
    obtain ⟨w,hw,ht⟩ := ha.exists_isMinOn (show A.Nonempty from ⟨u,hu,rfl⟩) continuous_norm.continuousOn
    refine ⟨⟨w,hw.1⟩,fun v => hw.2.trans_le (hmin v.2),fun v hv => ht ⟨v.2,hv.trans hw.2⟩⟩
  choose best hmin htie using existsTie
  have unique (s : S) (v : B) (hfv : f s v = f s (best s))
      (hnv : ‖v.val‖ = ‖(best s).val‖) : v = best s := by
    apply Subtype.ext
    by_contra hne'
    let w := (1/2:ℝ) • v.val + (1/2:ℝ) • (best s).val
    have hw : w ∈ B := (hc s).1 v.2 (best s).2 (by norm_num) (by norm_num) (by norm_num)
    have hfmid := (hc s).2 v.2 (best s).2 (show (0:ℝ) ≤ 1/2 by norm_num)
      (show (0:ℝ) ≤ 1/2 by norm_num) (show (1/2:ℝ) + 1/2 = 1 by norm_num)
    have hmid : f s w = f s (best s) := le_antisymm (by
      simp only [smul_eq_mul, hfv] at hfmid
      dsimp [w]
      linarith only [hfmid])
      (hmin s ⟨w,hw⟩)
    have hle := htie s ⟨w,hw⟩ hmid
    have hlt := (norm_midpoint_lt_iff hnv).mpr hne'
    rw [smul_add,hnv] at hlt
    exact hlt.not_ge hle
  have hs : Measurable best := measurableLexicographicMinimum
    (fun s (w : B) => f s w.val) (hf.comp (continuous_fst.prodMk
      (continuous_subtype_val.comp continuous_snd))) (fun w : B => ‖w.val‖)
      (continuous_norm.comp continuous_subtype_val) best hmin htie unique
  refine ⟨fun s => (best s).val, measurable_subtype_coe.comp hs, fun s =>
    ⟨by simpa only [Metric.mem_closedBall,dist_zero_right] using (show (best s).val ∈ Metric.closedBall (0:E) R from (best s).property), ?_, ?_⟩⟩
  · intro w hw
    exact hmin s ⟨w,by simpa [B] using hw⟩
  · intro w hw he
    exact htie s ⟨w,by simpa [B] using hw⟩ he

end UL.Arxiv

import UL.Arxiv.SimplexGrid
import UL.Proof.lem_A_5.H1_Simplex

namespace UL.Arxiv

/-- Feasible finite-grid approximation for the distinct sample scores. Each
row consists of nonnegative integer counts summing to N. Repeated scores can
use the same row, with their original multiplicities in the objective. -/
theorem feasibleGridFitWithTies {n K N : ℕ} {S : Type*} [NormedAddCommGroup S] (hK : 2 ≤ K) (hN : 0 < N)
    (s : Fin n → S) (p : Fin n → Simplex K)
    (B b t : ℝ) (hB : 0 ≤ B) (ht : 0 ≤ t) (ht' : t ≤ 1)
    (hsep : ∀ i j, s i ≠ s j → b ≤ ‖s i - s j‖)
    (hfit : ∀ i j, ‖(p i).val - (p j).val‖ ≤ B * ‖s i-s j‖)
    (hmesh : Real.sqrt K / N ≤ t) (hslack : 2 * (Real.sqrt K / N) ≤ t * B * b) :
    ∃ a : Fin n → Fin K → ℕ, (∀ i, ∑ j, a i j = N) ∧
      let q := fun i => WithLp.toLp 2 (fun j => (a i j : ℝ) / N)
      (∀ i, q i ∈ Simplex K) ∧ (∀ i, ‖q i - (p i).val‖ ≤ 3*t) ∧
      (∀ i j, ‖q i-q j‖ ≤ B * ‖s i-s j‖) := by
  classical
  let u := uniformVec K
  have hu : u ∈ Simplex K := UL.Proof_lem_A_5.uniformVec_mem_simplex hK
  let mix (i : Fin n) : Simplex K := ⟨(1-t) • (p i).val + t • u,
    UL.Proof_lem_A_5.convex_simplex K (p i).2 hu (sub_nonneg.mpr ht') ht (by ring)⟩
  choose rnd htotal hclose using fun q : Simplex K => simplexGridApproximation hN q
  let a := fun i => rnd (mix i)
  have ha := fun i => htotal (mix i)
  have hnear := fun i => hclose (mix i)
  let q := fun i => WithLp.toLp 2 (fun j => (a i j : ℝ) / N)
  refine ⟨a, ha, ?_, ?_, ?_⟩
  · intro i
    refine ⟨fun j => div_nonneg (Nat.cast_nonneg _) (Nat.cast_nonneg _), ?_⟩
    change (∑ j, (a i j : ℝ) / N) = 1
    rw [← Finset.sum_div, ← Nat.cast_sum, ha i, div_self (Nat.cast_ne_zero.mpr hN.ne')]
  · intro i
    have hn : ‖u - (p i).val‖ ≤ 2 := (norm_sub_le _ _).trans (by
      linarith [UL.Proof_lem_A_5.norm_le_one_of_mem_simplex hu,
                UL.Proof_lem_A_5.norm_le_one_of_mem_simplex (p i).2])
    have hs : (mix i).val - (p i).val = t • (u - (p i).val) := by
      dsimp [mix]; module
    calc ‖q i - (p i).val‖ ≤ ‖q i - (mix i).val‖ + ‖(mix i).val - (p i).val‖ := by
             simpa only [dist_eq_norm] using dist_triangle (q i) (mix i).val (p i).val
         _ ≤ 3*t := by rw [hs,norm_smul,Real.norm_eq_abs,abs_of_nonneg ht]; nlinarith [hnear i]
  · intro i j
    by_cases hij : s i = s j
    · have hp : p i = p j := by
        apply Subtype.ext
        apply sub_eq_zero.mp
        apply norm_eq_zero.mp
        apply le_antisymm _ (norm_nonneg _)
        simpa [hij] using hfit i j
      have heq : mix i = mix j := by apply Subtype.ext; dsimp [mix]; rw [hp]
      simp [q,a,heq,hij]
    have hs : (mix i).val - (mix j).val = (1-t) • ((p i).val - (p j).val) := by
      dsimp [mix]; module
    have htri := dist_triangle4_right (q i) (q j) (mix i).val (mix j).val
    simp only [dist_eq_norm, hs, norm_smul, Real.norm_eq_abs, abs_of_nonneg (sub_nonneg.mpr ht')] at htri
    have hnear' : ∀ i, ‖q i - (mix i).val‖ ≤ Real.sqrt K / N := hnear
    have hcap := mul_le_mul_of_nonneg_left (hfit i j) (sub_nonneg.mpr ht')
    have hdist := mul_le_mul_of_nonneg_left (hsep i j hij) (mul_nonneg ht hB)
    nlinarith [hnear' i, hnear' j]

/-- Minimize the empirical half-squared loss over an explicitly finite set
of grid assignments. The weights allow repeated observations at a score. -/
theorem finiteGridMinimizerWithTies {n K N : ℕ} {S : Type*} [NormedAddCommGroup S] (hK : 2 ≤ K) (hN : 0 < N)
    (s : Fin n → S) (p y : Fin n → Simplex K)
    (w : Fin n → ℝ) (hw : ∀ i, 0 ≤ w i) (hw1 : ∑ i, w i = 1)
    (B b t : ℝ) (hB : 0 ≤ B) (ht : 0 ≤ t) (ht' : t ≤ 1)
    (hsep : ∀ i j, s i ≠ s j → b ≤ ‖s i - s j‖)
    (hfit : ∀ i j, ‖(p i).val - (p j).val‖ ≤ B * ‖s i-s j‖)
    (hmesh : Real.sqrt K / N ≤ t) (hslack : 2 * (Real.sqrt K / N) ≤ t * B * b) :
    let report := fun (A : Fin n → Fin K → Fin (N+1)) (i : Fin n) =>
      WithLp.toLp 2 (fun j => ((A i j).val : ℝ) / N)
    let admissible := fun A => (∀ i, report A i ∈ Simplex K) ∧
      (∀ i j, ‖report A i - report A j‖ ≤ B * ‖s i-s j‖)
    let loss := fun (v : Fin n → EuclideanSpace ℝ (Fin K)) =>
      ∑ i, w i * (‖v i - (y i).val‖^2 / 2)
    ∃ A, admissible A ∧ (∀ A', admissible A' → loss (report A) ≤ loss (report A')) ∧
      loss (report A) ≤ loss (fun i => (p i).val) + 6*t := by
  classical
  intro report admissible loss
  obtain ⟨a,ha,hmem,hnear,hslope⟩ :=
    feasibleGridFitWithTies hK hN s p B b t hB ht ht' hsep hfit hmesh hslack
  have hlim (i j) : a i j ≤ N := by
    rw [← ha i]
    exact Finset.single_le_sum (fun k _ => Nat.zero_le (a i k)) (Finset.mem_univ j)
  let A₀ : Fin n → Fin K → Fin (N+1) := fun i j => ⟨a i j, Nat.lt_succ_of_le (hlim i j)⟩
  have hgood : admissible A₀ := ⟨hmem,hslope⟩
  let candidates := Finset.univ.filter admissible
  have hne : candidates.Nonempty := ⟨A₀,Finset.mem_filter.mpr ⟨Finset.mem_univ _,hgood⟩⟩
  obtain ⟨A,hA,hmin⟩ := candidates.exists_min_image (fun a => loss (report a)) hne
  refine ⟨A,(Finset.mem_filter.mp hA).2, fun a ha => hmin a
    (Finset.mem_filter.mpr ⟨Finset.mem_univ _,ha⟩), ?_⟩
  apply (hmin A₀ (Finset.mem_filter.mpr ⟨Finset.mem_univ _,hgood⟩)).trans
  have hone : ∀ {v z : EuclideanSpace ℝ (Fin K)}, v ∈ Simplex K → z ∈ Simplex K → ‖v-z‖ ≤ 2 := by
    intro v z hv hz
    exact (norm_sub_le v z).trans (by linarith [UL.Proof_lem_A_5.norm_le_one_of_mem_simplex hv,
                                              UL.Proof_lem_A_5.norm_le_one_of_mem_simplex hz])
  have hi (i) : ‖report A₀ i - (y i).val‖^2/2 ≤ ‖(p i).val - (y i).val‖^2/2 + 6*t := by
    let x := report A₀ i
    let z := (p i).val
    let l := (y i).val
    have hsum : ‖x-l‖ + ‖z-l‖ ≤ 4 := by linarith [hone (hgood.1 i) (y i).2, hone (p i).2 (y i).2]
    have hdiff : ‖x-l‖ - ‖z-l‖ ≤ 3*t := by
      have hh := dist_triangle x z l
      simp only [dist_eq_norm] at hh
      have hx : ‖x-z‖ ≤ 3*t := hnear i
      linarith
    have hm := mul_le_mul_of_nonneg_right hdiff (add_nonneg (norm_nonneg (x-l)) (norm_nonneg (z-l)))
    change ‖x-l‖^2/2 ≤ ‖z-l‖^2/2 + 6*t
    nlinarith [mul_le_mul_of_nonneg_left hsum (show 0 ≤ 3*t by positivity)]
  have H := Finset.sum_le_sum (s := Finset.univ) fun i _ => mul_le_mul_of_nonneg_left (hi i) (hw i)
  simpa only [mul_add, Finset.sum_add_distrib, ← Finset.sum_mul, hw1, one_mul, loss] using H

/-- Feasible finite-grid approximation for the distinct sample scores. Each
row consists of nonnegative integer counts summing to N. Repeated scores can
use the same row, with their original multiplicities in the objective. -/
theorem feasibleGridFit {n K m N : ℕ} (hK : 2 ≤ K) (hN : 0 < N)
    (s : Fin n → EuclideanSpace ℝ (Fin m)) (p : Fin n → Simplex K)
    (B b t : ℝ) (hB : 0 ≤ B) (ht : 0 ≤ t) (ht' : t ≤ 1)
    (hsep : ∀ i j, i ≠ j → b ≤ ‖s i - s j‖)
    (hfit : ∀ i j, ‖(p i).val - (p j).val‖ ≤ B * ‖s i-s j‖)
    (hmesh : Real.sqrt K / N ≤ t) (hslack : 2 * (Real.sqrt K / N) ≤ t * B * b) :
    ∃ a : Fin n → Fin K → ℕ, (∀ i, ∑ j, a i j = N) ∧
      let q := fun i => WithLp.toLp 2 (fun j => (a i j : ℝ) / N)
      (∀ i, q i ∈ Simplex K) ∧ (∀ i, ‖q i - (p i).val‖ ≤ 3*t) ∧
      (∀ i j, ‖q i-q j‖ ≤ B * ‖s i-s j‖) :=
  feasibleGridFitWithTies hK hN s p B b t hB ht ht' (fun i j h => hsep i j (fun e => h (congrArg s e))) hfit hmesh hslack

/-- Minimize the empirical half-squared loss over an explicitly finite set
of grid assignments. The weights allow repeated observations at a score. -/
theorem finiteGridMinimizer {n K m N : ℕ} (hK : 2 ≤ K) (hN : 0 < N)
    (s : Fin n → EuclideanSpace ℝ (Fin m)) (p y : Fin n → Simplex K)
    (w : Fin n → ℝ) (hw : ∀ i, 0 ≤ w i) (hw1 : ∑ i, w i = 1)
    (B b t : ℝ) (hB : 0 ≤ B) (ht : 0 ≤ t) (ht' : t ≤ 1)
    (hsep : ∀ i j, i ≠ j → b ≤ ‖s i - s j‖)
    (hfit : ∀ i j, ‖(p i).val - (p j).val‖ ≤ B * ‖s i-s j‖)
    (hmesh : Real.sqrt K / N ≤ t) (hslack : 2 * (Real.sqrt K / N) ≤ t * B * b) :
    let report := fun (A : Fin n → Fin K → Fin (N+1)) (i : Fin n) =>
      WithLp.toLp 2 (fun j => ((A i j).val : ℝ) / N)
    let admissible := fun A => (∀ i, report A i ∈ Simplex K) ∧
      (∀ i j, ‖report A i - report A j‖ ≤ B * ‖s i-s j‖)
    let loss := fun (v : Fin n → EuclideanSpace ℝ (Fin K)) =>
      ∑ i, w i * (‖v i - (y i).val‖^2 / 2)
    ∃ A, admissible A ∧ (∀ A', admissible A' → loss (report A) ≤ loss (report A')) ∧
      loss (report A) ≤ loss (fun i => (p i).val) + 6*t :=
  finiteGridMinimizerWithTies hK hN s p y w hw hw1 B b t hB ht ht' (fun i j h => hsep i j (fun e => h (congrArg s e))) hfit hmesh hslack

end UL.Arxiv

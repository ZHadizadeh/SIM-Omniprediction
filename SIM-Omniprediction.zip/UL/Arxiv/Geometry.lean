import UL.Arxiv.BoundedBinary
import Mathlib.Analysis.Calculus.LocalExtr.Basic
import Mathlib.Analysis.Calculus.Deriv.Mul
import Mathlib.Analysis.Normed.Module.FiniteDimension

/-! # Limits at an optimal bounded action (Appendix A.2) -/

open Set Filter Topology MeasureTheory
open scoped NNReal
namespace UL.Arxiv.BoundedBinary
noncomputable section

variable {A : ℝ≥0}

theorem continuous_family_potential : Continuous (fun z : Target A × ℝ => potential z.1 z.2) := by
  apply intervalIntegral.continuous_parametric_primitive_of_continuous (μ := volume)
  exact continuous_subtype_val.comp (continuous_eval.comp
    (continuous_fst.prodMk ((show Continuous (clip A) from continuous_projIcc).comp continuous_snd)))

theorem tendsto_loss {ι : Type*} {l : Filter ι} {σn : ι → Target A} {σ : Target A}
    {an pn : ι → ℝ} {a p : ℝ} (hs : Tendsto σn l (𝓝 σ)) (ha : Tendsto an l (𝓝 a))
    (hp : Tendsto pn l (𝓝 p)) :
    Tendsto (fun n => loss (σn n) (an n) (pn n)) l (𝓝 (loss σ a p)) :=
  (continuous_family_potential.continuousAt.tendsto.comp (hs.prodMk_nhds ha)).sub (hp.mul ha)

/-- The first-order condition works for both endpoints and for interior comparator scores. -/
theorem optimal_slope_sign {σ : Target A} {q : Probability} {t : Action A}
    (hmin : ∀ b : Action A, loss σ t q ≤ loss σ b q) (b : Action A) :
    0 ≤ ((b : ℝ) - t) * ((σ t : ℝ) - q) := by
  have hlocal : IsMinOn (fun x => loss σ x q) (Action A) (t : ℝ) :=
    fun x hx => hmin ⟨x,hx⟩
  have hd : HasDerivAt (fun x => loss σ x q) (slope σ t - q) (t : ℝ) := by
    exact ((continuous_slope σ).integral_hasStrictDerivAt 0 t).hasDerivAt.sub
      (by simpa using (hasDerivAt_id (t : ℝ)).const_mul (q : ℝ))
  have ht := hlocal.localize.hasFDerivWithinAt_nonneg hd.hasFDerivAt.hasFDerivWithinAt
    (sub_mem_posTangentConeAt_of_segment_subset ((convex_Icc _ _).segment_subset t.2 b.2))
  simpa [ContinuousLinearMap.smulRight_apply, smul_eq_mul, slope, clip] using ht

/-- Equality at the right endpoint identifies the feature point exactly. -/
theorem feature_at_right {d : ℕ} {v x : Features d} {L R : ℝ≥0}
    (hR : 0 < R) (hL : 0 < L) (hv : ‖v‖ ≤ (R : ℝ)) (hx : ‖x‖ ≤ (L : ℝ))
    (he : inner ℝ v x = (L : ℝ) * R) : x = ((R : ℝ)⁻¹ * L) • v := by
  have h₁ := real_inner_le_norm v x
  rw [he] at h₁
  have hv' : ‖v‖ = (R : ℝ) := by
    apply le_antisymm hv
    have ha := mul_le_mul_of_nonneg_left hx (norm_nonneg v)
    exact (mul_le_mul_iff_left₀ (show (0 : ℝ) < L from hL)).mp (by linarith)
  have hx' : ‖x‖ = (L : ℝ) := by
    apply le_antisymm hx
    rw [hv'] at h₁
    exact (mul_le_mul_iff_right₀ (show (0 : ℝ) < R from hR)).mp (by linarith)
  have hs := inner_eq_norm_mul_iff_real.mp (show inner ℝ v x = ‖v‖ * ‖x‖ by rw [he, hx', hv', mul_comm])
  rw [hv', hx'] at hs
  rw [← smul_smul, hs, inv_smul_smul₀ (show (R : ℝ) ≠ 0 from ne_of_gt hR)]

theorem feature_at_left {d : ℕ} {v x : Features d} {L R : ℝ≥0}
    (hR : 0 < R) (hL : 0 < L) (hv : ‖v‖ ≤ (R : ℝ)) (hx : ‖x‖ ≤ (L : ℝ))
    (he : inner ℝ v x = -((L : ℝ) * R)) : x = ((R : ℝ)⁻¹ * L) • (-v) := by
  apply feature_at_right hR hL (by simpa using hv) hx
  simp [he]

/-- Replace the endpoint values, keeping the continuous target on the open interval. -/
def limitLink (σ : Target A) (lo hi : Probability) (s : ℝ) : Probability :=
  if s ≤ -(A : ℝ) then min lo (σ (clip A s))
  else if (A : ℝ) ≤ s then max hi (σ (clip A s))
  else σ (clip A s)

theorem monotone_limitLink {σ : Target A} (hσ : Monotone σ) (lo hi : Probability) :
    Monotone (limitLink σ lo hi) := by
  intro a b hab
  have h := hσ (Set.monotone_projIcc (neg_le_self A.coe_nonneg) hab)
  unfold limitLink
  split_ifs <;> first
    | exact min_le_min le_rfl h
    | exact max_le_max le_rfl h
    | exact h
    | exact (min_le_right _ _).trans h
    | exact h.trans (le_max_right _ _)
    | exact (min_le_right _ _).trans (h.trans (le_max_right _ _))
    | exfalso; linarith

end
end UL.Arxiv.BoundedBinary

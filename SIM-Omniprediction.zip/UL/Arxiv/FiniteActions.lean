import UL.Proof.cor_A_8.H1_SimplexGrad
import UL.Proof.lem_A_1.H2_MatchingApprox
import UL.Proof.lem_C_2.H2_SmoothEntropy
import UL.Stmt.thm_3_1

open MeasureTheory Filter
namespace UL.Arxiv
open Proof_lem_A_1

/-- A centered derivative on the entire simplex at every point, including
boundary points. No Lipschitz modulus of the entropy gradient is required. -/
def HasFullSimplexGradient {K : ℕ} (Φ : Simplex K → ℝ) : Prop :=
  ∀ p ∈ Simplex K, ∃ g, HasFaceGradAt Φ Finset.univ p g

/-- A differentiable extension in the affine hull supplies the full gradient.
This applies, in particular, to convex C¹ extensions to a neighborhood. -/
theorem fullGradient_of_extension {K : ℕ} {Φ : Simplex K → ℝ}
    {U : Set (EuclideanSpace ℝ (Fin K))} {f : EuclideanSpace ℝ (Fin K) → ℝ}
    (hU : Simplex K ⊆ U) (heq : ∀ q : Simplex K, f q = Φ q)
    (hd : ∀ p ∈ U, ∃ g ∈ ZeroSumSubspace K, HasFDerivWithinAt f (innerSL ℝ g) U p) :
    HasFullSimplexGradient Φ := by
  intro p hp
  obtain ⟨g, hg, hgd⟩ := hd p (hU hp)
  refine ⟨g, ?_, ?_⟩
  · rwa [Proof_lem_A_5.faceTangentSpace_univ]
  · rw [Proof_lem_A_5.simplexFace_univ]
    refine (hgd.mono hU).congr (fun x hx => ?_) ?_
    · rw [Proof_lem_A_5.extendSimplex_eq_of_mem Φ hx, heq ⟨x,hx⟩]
    · rw [Proof_lem_A_5.extendSimplex_eq_of_mem Φ hp, heq ⟨p,hp⟩]

theorem fullGradient_of_smooth {K : ℕ} {β lam M : ℝ} {Φ : Simplex K → ℝ}
    (h : Φ ∈ SmoothEntropyFamily K β lam M) : HasFullSimplexGradient Φ :=
  fun p hp => ⟨_, Proof_lem_C_2.hasFaceGradAt_univ_simplexGrad h hp⟩

/-- At every supported label the finite Bayes action incurs exactly the
facewise canonical loss, including on proper faces. -/
theorem finiteAction_on_support {K : ℕ} (hK : 2 ≤ K) {β : ℝ} {Φ : Simplex K → ℝ}
    (hΦ : Φ ∈ EntropyFamily K β) (hd : HasFullSimplexGradient Φ)
    (p : Simplex K) {y : Fin K} (hy : y ∈ posSupport p) :
    (finiteCanonicalLoss Φ p y : EReal) = extendedCanonicalLoss Φ p y := by
  classical
  let g := simplexGrad Φ p
  let J := posSupport p.val
  have hg : HasFaceGradAt Φ Finset.univ p g := faceGrad_spec (hd p p.2)
  have hpJ := mem_simplexFaceRelint_posSupport p.2
  have hfull (q : Simplex K) : q.val ∈ SimplexFace K Finset.univ := by
    rw [Proof_lem_A_5.simplexFace_univ]
    exact q.2
  have hmax (q : Simplex K) : inner ℝ q.val g - Φ q ≤ inner ℝ p.val g - Φ p := by
    simpa only [Proof_lem_A_5.extendSimplex_eq_of_mem Φ q.2,
      Proof_lem_A_5.extendSimplex_eq_of_mem Φ p.2] using
      face_max_ineq (Proof_cor_A_8.convexOn_extendSimplex_of_mem_entropyFamily hΦ)
        (hfull p) (hfull q) hg.2
  have hpot : rawPot Φ g = inner ℝ p.val g - Φ p := ciSup_simplex_eq_of_isMax hK hmax
  let T := FaceTangentSpace K J
  let gJ : EuclideanSpace ℝ (Fin K) := T.orthogonalProjection g
  have hgJ : HasFaceGradAt Φ J p gJ := by
    have hsub : SimplexFace K J ⊆ SimplexFace K Finset.univ := fun q hq => hfull ⟨q,hq.1⟩
    refine ⟨Submodule.coe_mem _, HasFDerivAtFilter.of_isLittleO ?_⟩
    refine (hg.2.mono hsub).isLittleO.congr' ?_ (Eventually.of_forall fun _ => rfl)
    filter_upwards [self_mem_nhdsWithin] with q hq
    have he := Proof_cor_A_8.inner_orthProj_eq_of_mem T g (q-p.val)
      (Proof_cor_A_8.sub_mem_faceTangentSpace hpJ.1 hq)
    simp only [innerSL_apply_apply, gJ, he]
  have hproj : faceGrad Φ J p = gJ :=
    Proof_cor_A_8.faceGrad_eq_of_hasFaceGradAt (posSupport_nonempty p.2) hpJ hgJ
  have hpair := Proof_cor_A_8.inner_orthProj_eq_of_mem T g
    (p.val - EuclideanSpace.single y (1:ℝ))
    (Proof_cor_A_8.sub_mem_faceTangentSpace (single_mem_simplexFace hy) hpJ.1)
  change (matchingLoss Φ g y : EReal) = _
  rw [extendedCanonicalLoss, if_pos hy, matchingLoss_of_mem_zeroSum hK hΦ.2.1
    ((mem_faceTangentSpace_iff g).mp hg.1).1 y, hpot,
    Proof_lem_A_5.extendSimplex_eq_of_mem Φ p.2]
  change ((inner ℝ p.val g - Φ p - g y : ℝ) : EReal) =
    ((-Φ p + inner ℝ (faceGrad Φ J p) (p.val - EuclideanSpace.single y 1) : ℝ) : EReal)
  rw [hproj, show inner ℝ gJ (p.val - EuclideanSpace.single y 1) = _ from hpair,
    inner_sub_right, inner_single_right, real_inner_comm g p.val]
  congr 1
  ring

/-- The very same forecast and compact comparator set from Theorem 1.2
give an exact risk comparison using the finite action for every entropy
with a full simplex gradient. -/
theorem exactFiniteActions {K d : ℕ} (hK : 2 ≤ K) {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin K)
    (p : EuclideanSpace ℝ (Fin d) → Simplex K) {β : ℝ}
    (weights : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K))
    (hs : ∀ j : Fin K, ∀ᵐ ω ∂μ, (p (X ω)).val j = 0 → Y ω ≠ j)
    (hr : ∀ Φ ∈ EntropyFamily K β, expectedCanonicalLoss μ X Y Φ p ≤
      ⨅ V ∈ weights, expectedMatchingLoss μ X Y Φ V.toLinearMap)
    {Φ : Simplex K → ℝ} (hΦ : Φ ∈ EntropyFamily K β) (hd : HasFullSimplexGradient Φ) :
    (∀ᵐ ω ∂μ, (finiteCanonicalLoss Φ (p (X ω)) (Y ω) : EReal) =
      extendedCanonicalLoss Φ (p (X ω)) (Y ω)) ∧
    erealExpectation μ (fun ω => (finiteCanonicalLoss Φ (p (X ω)) (Y ω) : EReal)) ≤
      ⨅ V ∈ weights, expectedMatchingLoss μ X Y Φ V.toLinearMap := by
  have he : ∀ᵐ ω ∂μ, (finiteCanonicalLoss Φ (p (X ω)) (Y ω) : EReal) =
      extendedCanonicalLoss Φ (p (X ω)) (Y ω) := by
    filter_upwards [ae_all_iff.mpr hs] with ω hω
    apply finiteAction_on_support hK hΦ hd
    by_contra hx
    exact hω (Y ω) (eq_zero_of_not_mem_posSupport (p (X ω)).2 hx) rfl
  refine ⟨he, le_trans (le_of_eq ?_) (hr Φ hΦ)⟩
  unfold expectedCanonicalLoss erealExpectation
  congr 2
  · exact lintegral_congr_ae (he.mono fun _ h => congrArg EReal.toENNReal h)
  · exact lintegral_congr_ae (he.mono fun _ h => congrArg (fun t : EReal => (-t).toENNReal) h)

end UL.Arxiv

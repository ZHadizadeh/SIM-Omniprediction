import UL.Proof.thm_3_2.H1_Fit
import UL.Proof.thm_3_2.H2_Perturb
import UL.Proof.thm_3_2.H3_LossFixedPoint
set_option autoImplicit false

/-! # Theorem 1.1(a): Global binary actions and compact convex weight sets -/

namespace UL.Arxiv.BinaryGlobal

/-- Both the forecast and each competitor use weights in the given set.
The set of real comparator risks is nonempty (because the weight set is)
and bounded below, so its infimum is finite. -/
def Statement : Prop :=
  ∀ (d : ℕ)
    (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin 2)
    (_hX_meas : Measurable X) (_hY_meas : Measurable Y)
    (β : ℝ) (_hβ : 0 < β)
    (_hX_int : MeasureTheory.Integrable (fun ω => ‖X ω‖) μ)
    (C : Set (EuclideanSpace ℝ (Fin d))) (_hCne : C.Nonempty)
    (_hCcomp : IsCompact C) (_hCconv : Convex ℝ C),
    ∃ (w : EuclideanSpace ℝ (Fin d)) (ρ : ℝ → ℝ),
      w ∈ C ∧
      Monotone ρ ∧
      LipschitzWith (Real.toNNReal β) ρ ∧
      (∀ t : ℝ, ρ t ∈ Set.Icc (0 : ℝ) 1) ∧
      (∀ᵐ ω ∂μ, (ρ (inner ℝ w (X ω)) = 0 → Y ω = 0) ∧
        (ρ (inner ℝ w (X ω)) = 1 → Y ω = 1)) ∧
      ∀ φ ∈ BinaryEntropyFamily β,
        (∀ᵐ ω ∂μ,
          binaryExtendedCanonicalLoss φ (ρ (inner ℝ w (X ω))) (Y ω) ≠ ⊥ ∧
          binaryExtendedCanonicalLoss φ (ρ (inner ℝ w (X ω))) (Y ω) ≠ ⊤) ∧
        MeasureTheory.Integrable
          (fun ω => (binaryExtendedCanonicalLoss φ (ρ (inner ℝ w (X ω))) (Y ω)).toReal) μ ∧
        (∀ v : EuclideanSpace ℝ (Fin d), v ∈ C →
          MeasureTheory.Integrable
            (fun ω => binaryMatchingLoss φ (inner ℝ v (X ω)) (Y ω)) μ) ∧
        BddBelow ((fun v : EuclideanSpace ℝ (Fin d) =>
          ∫ ω, binaryMatchingLoss φ (inner ℝ v (X ω)) (Y ω) ∂μ) '' C) ∧
        (∫ ω, (binaryExtendedCanonicalLoss φ (ρ (inner ℝ w (X ω))) (Y ω)).toReal ∂μ) ≤
          sInf ((fun v : EuclideanSpace ℝ (Fin d) =>
            ∫ ω, binaryMatchingLoss φ (inner ℝ v (X ω)) (Y ω) ∂μ) '' C)

open Proof_thm_3_2

/-- A common fitted profile together with its variational inequalities. -/
theorem fixed_fit
    (d : ℕ) (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin 2)
    (hX_meas : Measurable X) (hY_meas : Measurable Y)
    (C : Set (EuclideanSpace ℝ (Fin d))) (hCne : C.Nonempty) (hCcomp : IsCompact C) (hCconv : Convex ℝ C)
    (β : ℝ) (hβ : 0 < β)
    (hX_int : MeasureTheory.Integrable (fun ω => ‖X ω‖) μ)
    : ∃ w ∈ C, ∃ ρ : ℝ → ℝ, IsProfile β ρ ∧
      let P := fun ω => ρ (inner ℝ w (X ω))
      ( ∀ᵐ ω ∂μ, (P ω = 0 → Y ω = 0) ∧ (P ω = 1 → Y ω = 1)) ∧
      ( ∫ ω, fitRes P Y ω * P ω ∂μ ≤ β * ∫ ω, fitRes P Y ω * inner ℝ w (X ω) ∂μ) ∧
      ( ∀ v : EuclideanSpace ℝ (Fin d), v ∈ C →
      ∫ ω, fitRes P Y ω * inner ℝ w (X ω) ∂μ ≤ ∫ ω, fitRes P Y ω * inner ℝ v (X ω) ∂μ) ∧
      ( ∀ F : ℝ → ℝ,
      ContinuousOn F (Set.Icc (0 : ℝ) 1) →
      ConvexOn ℝ (Set.Icc (0 : ℝ) 1) F →
      (∀ q ∈ Set.Ioo (0 : ℝ) 1, DifferentiableAt ℝ F q) →
      MeasureTheory.Integrable
        (fun ω => if P ω ∈ Set.Ioo (0 : ℝ) 1 then fitRes P Y ω * deriv F (P ω) else 0) μ ∧
      (∫ ω, (if P ω ∈ Set.Ioo (0 : ℝ) 1 then fitRes P Y ω * deriv F (P ω) else 0) ∂μ) ≤ 0) := by
  obtain ⟨ρ_fam, h_opt, h_vi, _, h_cont_g⟩ :=
    Proof_thm_3_2.exists_optProfile_and_continuous_drift
      d Ω μ X Y hX_meas hY_meas β hβ hX_int
  let g : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d) :=
    fun w => ∫ ω, (ρ_fam w (inner ℝ w (X ω)) - Proof_thm_3_2.yReal (Y ω)) • X ω ∂μ
  obtain ⟨w, hw_mem, hw_fp⟩ :=
    Proof_thm_3_2.choose_score C hCne hCcomp hCconv g h_cont_g
  let ρ : ℝ → ℝ := ρ_fam w
  have hρ : Proof_thm_3_2.IsProfile β ρ := (h_opt w).1
  let P : Ω → ℝ := fun ω => ρ (inner ℝ w (X ω))
  have hSw_meas : Measurable (fun ω => inner ℝ w (X ω)) :=
    (continuous_const.inner continuous_id).measurable.comp hX_meas
  have hP_meas : Measurable P := hρ.measurable.comp hSw_meas
  have hP_mem : ∀ ω : Ω, P ω ∈ Set.Icc (0 : ℝ) 1 := fun ω => hρ.2.2 _
  have h_end := Proof_thm_3_2.ae_endpoint_support
    d Ω μ X Y hX_meas hY_meas β hβ w ρ hρ (h_vi w)
  have h_own := Proof_thm_3_2.own_score_ineq
    d Ω μ X Y hX_meas hY_meas β hβ hX_int w ρ hρ (h_vi w)
  have h_conv := fun F hFc hFcv hFd =>
    Proof_thm_3_2.convex_test_ineq
      d Ω μ X Y hX_meas hY_meas β hβ w ρ hρ (h_vi w) F hFc hFcv hFd
  have h_fp_int : ∀ v : EuclideanSpace ℝ (Fin d), v ∈ C →
      ∫ ω, Proof_thm_3_2.fitRes P Y ω * inner ℝ w (X ω) ∂μ ≤
        ∫ ω, Proof_thm_3_2.fitRes P Y ω * inner ℝ v (X ω) ∂μ := by
    intro v hv
    have h_le := hw_fp v hv
    have heq_v := Proof_thm_3_2.inner_drift_eq
      d Ω μ X Y hX_meas hY_meas hX_int P hP_meas hP_mem v
    have heq_w := Proof_thm_3_2.inner_drift_eq
      d Ω μ X Y hX_meas hY_meas hX_int P hP_meas hP_mem w
    change inner ℝ w (g w) ≤ inner ℝ v (g w) at h_le
    dsimp [g] at h_le
    linarith
  exact ⟨w, hw_mem, ρ, hρ, h_end, h_own, h_fp_int, h_conv⟩

/-- Theorem 1.1(a), including its compact convex extension. -/
theorem exact_on_compact_convex : Statement := by
  intro d Ω _ μ _ X Y hX_meas hY_meas β hβ hX_int C hCne hCcomp hCconv
  obtain ⟨w,hw_mem,ρ,hρ,h_end,h_own,h_fp_int,h_conv⟩ := fixed_fit d Ω μ X Y hX_meas hY_meas
    C hCne hCcomp hCconv β hβ hX_int
  let P := fun ω => ρ (inner ℝ w (X ω))
  have hP_meas : Measurable P := hρ.measurable.comp ((continuous_const.inner continuous_id).measurable.comp hX_meas)
  have hP_mem := fun ω => hρ.2.2 (inner ℝ w (X ω))
  refine ⟨w, ρ, hw_mem, hρ.1, hρ.2.1, hρ.2.2, h_end, ?_⟩
  exact Proof_thm_3_2.entropy_loss_comparison_on_weights
    d Ω μ X Y hX_meas hY_meas C hCne β hβ hX_int
    w P hP_meas hP_mem h_end h_own h_fp_int h_conv

end UL.Arxiv.BinaryGlobal

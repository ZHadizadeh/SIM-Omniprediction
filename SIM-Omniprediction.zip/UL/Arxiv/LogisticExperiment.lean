import UL.Proof.prop_C_5.Race2.H2_Sphere
import UL.Arxiv.LogisticComparison
import UL.Proof.prop_C_5.Race2.SignExperiment
import UL.Proof.prop_C_5.Race2.H4_Assouad

open MeasureTheory Real Set
namespace UL.Arxiv.Logistic
open Proof_prop_C_5_Race2

abbrev Feature (d : ℕ) := EuclideanSpace ℝ (Fin d)
abbrev Sign (d : ℕ) := Fin d → Bool

noncomputable def clip (z : ℝ) := max (-(1/4:ℝ)) (min (1/4) z)
noncomputable def weight {d : ℕ} (s : Sign d) := signWeight 2 d s
noncomputable def score {d : ℕ} (s : Sign d) (x : Feature d) := inner ℝ (weight s) x
noncomputable def probOne {d : ℕ} (s : Sign d) (x : Feature d) := sigmoid (clip (score s x))
noncomputable def binaryProbs (p : ℝ) : EuclideanSpace ℝ (Fin 2) :=
  WithLp.toLp 2 fun j => if j = 1 then p else 1-p

theorem clip_mem (z : ℝ) : clip z ∈ Icc (-(1/4:ℝ)) (1/4) :=
  ⟨le_max_left _ _,max_le (by norm_num) (min_le_left _ _)⟩

theorem clip_id {z : ℝ} (hz : z ∈ Icc (-(1/4:ℝ)) (1/4)) : clip z = z := by
  rw [clip,min_eq_right hz.2,max_eq_right hz.1]

theorem continuous_clip : Continuous clip := continuous_const.max (continuous_const.min continuous_id)

theorem norm_weight {d : ℕ} (hd : 1 ≤ d) (s : Sign d) : ‖weight s‖ = 1/4 := by
  have hd' : (0:ℝ) < d := by exact_mod_cast hd
  have u : ∀ i : Fin d, (weight s i)^2 = (scaleA 2 / sqrt d)^2 := by
    intro i; cases h : s i <;> simp [weight, signWeight_apply,h]
  have e := UL.Proof_lem_A_4.norm_sq_eq_sum (weight s)
  simp_rw [u] at e
  simp only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,div_pow,
    Real.sq_sqrt hd'.le] at e
  norm_num [scaleA] at e
  field_simp [hd'.ne'] at e
  nlinarith [norm_nonneg (weight s)]

theorem score_mem {d : ℕ} (hd : 1 ≤ d) (s : Sign d) {x : Feature d} (hx : ‖x‖ ≤ 1) :
    score s x ∈ Icc (-(1/4:ℝ)) (1/4) := by
  apply abs_le.mp
  calc |score s x| ≤ ‖weight s‖ * ‖x‖ := abs_real_inner_le_norm _ _
       _ ≤ 1/4 := by rw [norm_weight hd]; linarith

theorem probOne_on_ball {d : ℕ} (hd : 1 ≤ d) (s : Sign d) {x : Feature d} (hx : ‖x‖ ≤ 1) :
    probOne s x = sigmoid (score s x) := by rw [probOne,clip_id (score_mem hd s hx)]

private theorem prob_bounds {d : ℕ} (s : Sign d) (x : Feature d) :
    1/4 ≤ probOne s x ∧ probOne s x ≤ 3/4 := by
  have h := clip_mem (score s x)
  have hl := sigmoid_monotone h.1
  have hu := sigmoid_monotone h.2
  have a := sigmoid_slope_upper (show -(1/4:ℝ) ≤ 0 by norm_num)
  have b := sigmoid_slope_upper (show (0:ℝ) ≤ 1/4 by norm_num)
  rw [sigmoid_zero] at a b
  change 1/4 ≤ sigmoid _ ∧ sigmoid _ ≤ 3/4
  constructor <;> linarith

private theorem neighbor {d : ℕ} (hd : 1 ≤ d) (s : Sign d) (i : Fin d) {x : Feature d} (hx : ‖x‖ ≤ 1) :
    ‖binaryProbs (probOne s x) - binaryProbs (probOne (Function.update s i (!s i)) x)‖^2 ≤
      (1/((2:ℝ)^2*d))*(x i)^2 := by
  let s' := Function.update s i (!s i)
  have eq : score s x - score s' x = (weight s i-weight s' i)*x i := by
    rw [score,score,← inner_sub_left,UL.Proof_lem_A_4.inner_eq_sum]
    apply Finset.sum_eq_single i
    · intro j _ hj
      simp [weight,PiLp.sub_apply,s',Function.update_of_ne hj]
    · simp
  have hd' : 0 < (d:ℝ) := by positivity
  have c : (weight s i-weight s' i)^2 = 1/(4*(d:ℝ)) := by
    have u : (weight s i-weight s' i)^2 = 4*(scaleA 2/sqrt d)^2 := by
      dsimp [weight,s']; cases h : s i <;> simp [h] <;> ring
    rw [u,div_pow,Real.sq_sqrt hd'.le]
    norm_num [scaleA]; ring
  have hsq : (score s x-score s' x)^2 = (1/(4*(d:ℝ)))*(x i)^2 := by rw [eq,mul_pow,c]
  have hdiff : (probOne s x-probOne s' x)^2 ≤ (score s x-score s' x)^2/16 := by
    rw [probOne_on_ball hd s hx,probOne_on_ball hd s' hx]
    rcases le_total (score s x) (score s' x) with h|h
    · have a := sigmoid_slope_upper h
      have b := sigmoid_monotone h
      nlinarith only [mul_nonneg (sub_nonneg.mpr a) (show 0 ≤ (1/4:ℝ)*(score s' x-score s x) + (sigmoid (score s' x)-sigmoid (score s x)) by linarith)]
    · have a := sigmoid_slope_upper h
      have b := sigmoid_monotone h
      nlinarith only [mul_nonneg (sub_nonneg.mpr a) (show 0 ≤ (1/4:ℝ)*(score s x-score s' x) + (sigmoid (score s x)-sigmoid (score s' x)) by linarith)]
  rw [UL.Proof_lem_A_4.norm_sq_eq_sum,Fin.sum_univ_two]
  change ((1-probOne s x)-(1-probOne s' x))^2 + (probOne s x-probOne s' x)^2 ≤ _
  rw [show (2:ℝ)^2 = 4 by norm_num, ← hsq]
  nlinarith only [hdiff,sq_nonneg (score s x-score s' x)]

noncomputable def experiment (d : ℕ) : SignExperiment.Design 2 d where
  prob s x := binaryProbs (probOne s x)
  cont s := by
    apply (PiLp.continuous_toLp 2 (fun _ : Fin 2 => ℝ)).comp
    apply continuous_pi
    intro i
    have h : Continuous (probOne s) := continuous_sigmoid.comp (continuous_clip.comp ((continuous_const (y:=weight s)).inner continuous_id))
    fin_cases i
    · exact continuous_const.sub h
    · exact h
  mem s x := by
    obtain ⟨h,h'⟩ := prob_bounds s x
    constructor
    · intro i; fin_cases i <;> simp [binaryProbs] <;> linarith
    · rw [Fin.sum_univ_two]; simp [binaryProbs]
  floor s x i := by
    obtain ⟨h,h'⟩ := prob_bounds s x
    fin_cases i <;> norm_num [binaryProbs] <;> linarith
  flip hd s i x hx := by simpa using neighbor hd s i hx

/-- i.i.d. logistic observations and an independent random seed. -/
noncomputable def observations {d : ℕ} (n : ℕ) {Ξ : Type*} [MeasurableSpace Ξ]
    (ν : Measure Ξ) (s : Sign d) :=
  ν.prod (Measure.pi fun _ : Fin n => SignExperiment.law (experiment d) (sphereProb d) s)

/-- Neighboring sign testing for the actual realizable logistic laws. -/
theorem hard_sign {d n : ℕ} (hd : 1 ≤ d) (hn : (n:ℝ) ≤ (d:ℝ)^2/8)
    {Ξ : Type*} [MeasurableSpace Ξ] (ν : Measure Ξ) [IsProbabilityMeasure ν]
    (b : Ξ × (Fin n → Feature d × Fin 2) → Fin d → ℝ) (hb : ∀ i, Measurable (fun z => b z i)) :
    ∃ s : Sign d, observations n ν s {z | (d:ℝ)/8 ≤
      ((Finset.univ.filter fun i => decide (0 ≤ b z i) ≠ s i).card : ℝ)}ᶜ ≤ ENNReal.ofReal (5/7) := by
  haveI := sphereProb_isProb hd
  haveI (s : Sign d) := SignExperiment.jointLaw_isProb (experiment d) (by decide) (sphereProb d) s
  have norm := sphereProb_norm_eq_one_ae hd
  have cov := spherical_coord_cov hd _ norm (sphereProb_hasSphericalFeatureSymmetry hd)
  apply assouad_reverse_markov hd (observations n ν) (fun s => by unfold observations; infer_instance) b hb
  intro s i A hA
  exact SignExperiment.prod_jointLaw_tv_le_quarter (experiment d) (by decide) hd
    (by push_cast; linarith) _ norm cov Ξ ν s i hA

end UL.Arxiv.Logistic

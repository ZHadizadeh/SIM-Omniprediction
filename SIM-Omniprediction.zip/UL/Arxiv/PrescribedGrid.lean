import UL.Arxiv.ScoreGrid

namespace UL.Arxiv.PrescribedGrid

/-- A tolerance for interchanging nearby score matrices in the empirical gap. -/
noncomputable def mesh (L R B η : ℝ) := min R (min (η/(8*L)) (η^2/(128*B*(L*R)^2*L)))

theorem mesh_pos {L R B η : ℝ} (hl : 0 < L) (hr : 0 < R) (hb : 0 < B) (he : 0 < η) :
    0 < mesh L R B η := lt_min hr (lt_min (by positivity) (by positivity))

theorem modulus_on_mesh {L R B η : ℝ} (hl : 0 < L) (hr : 0 < R) (hb : 0 < B) (he : 0 < η) :
    let h := mesh L R B η
    Real.sqrt 2*L*h + 2*(L*R)*Real.sqrt (2*Real.sqrt 2*B*(L*h)) < η := by
  intro h
  have hp : 0 < h := mesh_pos hl hr hb he
  have h1 : h ≤ η/(8*L) := (min_le_right _ _).trans (min_le_left _ _)
  have h2 : h ≤ η^2/(128*B*(L*R)^2*L) := (min_le_right _ _).trans (min_le_right _ _)
  have hm := (le_div_iff₀ (by positivity : 0 < 128*B*(L*R)^2*L)).mp h2
  have hh := (le_div_iff₀ (by positivity : 0 < 8*L)).mp h1
  have sq : Real.sqrt 2 ≤ 2 := (Real.sqrt_le_left (by norm_num)).mpr (by norm_num)
  have root : Real.sqrt (2*Real.sqrt 2*B*(L*h)) ≤ η/(4*(L*R)) := by
    apply (Real.sqrt_le_left (by positivity)).mpr
    rw [div_pow,le_div_iff₀ (by positivity)]
    have sm := mul_le_mul_of_nonneg_right sq (show 0 ≤ 2*B*(L*h)*(4*(L*R))^2 by positivity)
    nlinarith only [hm,sm,show 0 ≤ h*(64*B*(L*R)^2*L) by positivity]
  have r := (le_div_iff₀ (by positivity)).mp root
  nlinarith only [hh,r,he,mul_le_mul_of_nonneg_right sq (show 0 ≤ L*h by positivity)]

noncomputable def level (m : ℕ) (R h : ℝ) : ℕ := ⌈8*R*Real.sqrt m/h⌉₊+1

/-- The rectangular grid has covering radius at most half the prescribed mesh. -/
theorem covers {m : ℕ} {R h : ℝ} (hR : 0 < R) (hp : 0 < h) (w : ScoreGrid.Ball m R) :
    ∃ a : Fin m → Fin (level m R h + 1), dist (ScoreGrid.point hR a) w ≤ h/2 := by
  let N := level m R h
  have hn : 0 < N := Nat.zero_lt_succ _
  have hr := Nat.le_ceil (8*R*Real.sqrt m/h)
  have bound : 8*R*Real.sqrt m/h ≤ (N:ℝ) := hr.trans (by dsimp [N,level]; push_cast; linarith)
  obtain ⟨a,ha⟩ := ScoreGrid.cover hR hn w
  refine ⟨a,ha.trans ((div_le_iff₀ (Nat.cast_pos.mpr hn)).mpr ?_)⟩
  linarith [(div_le_iff₀ hp).mp bound]

section
variable {I S : Type*} [PseudoMetricSpace S]

open Classical in
noncomputable def retain (pt : I → S) (r : ℝ) : List I → List I
  | [] => []
  | a::l =>
    let kept := retain pt r l
    if ∃ b ∈ kept, dist (pt a) (pt b) ≤ r then kept else a::kept

theorem retain_cover (pt : I → S) {r : ℝ} (hr : 0 ≤ r) (l : List I) :
    ∀ a ∈ l, ∃ b ∈ retain pt r l, dist (pt a) (pt b) ≤ r := by
  classical
  induction l with
  | nil => simp
  | cons z l ih =>
    intro a ha
    rw [retain]
    split_ifs with near
    · rcases List.mem_cons.mp ha with e|e
      · simpa [e] using near
      · exact ih a e
    · rcases List.mem_cons.mp ha with rfl|e
      · exact ⟨a,List.mem_cons_self,by simpa using hr⟩
      · obtain ⟨b,hb,hd⟩ := ih a e; exact ⟨b,List.mem_cons_of_mem _ hb,hd⟩

theorem retain_separated (pt : I → S) (r : ℝ) (l : List I) :
    (retain pt r l).Pairwise (fun a b => r < dist (pt a) (pt b)) := by
  classical
  induction l with
  | nil => simp [retain]
  | cons a l ih =>
    rw [retain]; split_ifs with near
    · exact ih
    · exact List.pairwise_cons.mpr ⟨fun b hb => lt_of_not_ge (fun h => near ⟨b,hb,h⟩),ih⟩
end

/-- Number of distinct retained indices in an h/2-separated subset of
the radius-R ball, including the zero-dimensional case. -/
theorem packing {I : Type*} [DecidableEq I] {m : ℕ} {R h : ℝ} (hR : 0 < R) (hh : 0 < h)
    (F : Finset I) (pt : I → ScoreGrid.V m)
    (inside : ∀ i ∈ F, ‖pt i‖ ≤ R)
    (sep : ∀ i ∈ F, ∀ j ∈ F, i ≠ j → h/2 < dist (pt i) (pt j)) :
    (F.card:ℝ) ≤ (1+4*R/h)^m := by
  classical
  by_cases hm : m = 0
  · subst m
    have c : F.card ≤ 1 := Finset.card_le_one.mpr (by
      intro i hi j hj
      by_contra h
      have d := sep i hi j hj h
      rw [Subsingleton.elim (pt i) (pt j),dist_self] at d; linarith)
    simpa using (show (F.card:ℝ) ≤ 1 by exact_mod_cast c)
  haveI : Nonempty (Fin m) := Fin.pos_iff_nonempty.mp (Nat.pos_of_ne_zero hm)
  let μ : MeasureTheory.Measure (ScoreGrid.V m) := MeasureTheory.volume
  let r := h/4
  have hr : 0 < r := by dsimp [r]; positivity
  have dis : Set.PairwiseDisjoint (F : Set I) (fun i => Metric.ball (pt i) r) := by
    intro i hi j hj hij
    apply Set.disjoint_left.mpr
    intro z hz hz'
    have tri := dist_triangle (pt i) z (pt j)
    change dist z (pt i) < r at hz
    change dist z (pt j) < r at hz'
    rw [dist_comm (pt i) z] at tri
    have dd := sep i hi j hj hij
    dsimp [r] at *; linarith
  have incl : (⋃ i ∈ F, Metric.ball (pt i) r) ⊆ Metric.ball 0 (R+r) := by
    intro z hz
    obtain ⟨i,hi,hz⟩ := Set.mem_iUnion₂.mp hz
    have tri := dist_triangle z (pt i) 0
    change dist z (pt i) < r at hz
    rw [dist_zero_right,dist_zero_right] at tri
    change dist z 0 < _; rw [dist_zero_right]; linarith [inside i hi]
  have each i : μ (Metric.ball (pt i) r) = ENNReal.ofReal (r^m)*μ (Metric.ball 0 1) := by
    rw [μ.addHaar_ball _ hr.le,finrank_euclideanSpace_fin]
  have total := MeasureTheory.measure_mono (μ:=μ) incl
  rw [MeasureTheory.measure_biUnion_finset dis (fun _ _ => Metric.isOpen_ball.measurableSet)] at total
  simp_rw [each] at total
  have big : μ (Metric.ball (0 : ScoreGrid.V m) (R+r)) = ENNReal.ofReal ((R+r)^m)*μ (Metric.ball 0 1) := by
    rw [μ.addHaar_ball _ (show 0 ≤ R+r by positivity),finrank_euclideanSpace_fin]
  rw [Finset.sum_const,nsmul_eq_mul,big,← mul_assoc] at total
  have scaled := (ENNReal.mul_le_mul_iff_left (Metric.measure_ball_pos μ (0 : ScoreGrid.V m) zero_lt_one).ne'
    MeasureTheory.measure_ball_lt_top.ne).mp total
  have bound := ENNReal.toReal_le_of_le_ofReal (pow_nonneg (add_nonneg hR.le hr.le) m) scaled
  rw [ENNReal.toReal_mul,ENNReal.toReal_natCast,ENNReal.toReal_ofReal (pow_nonneg hr.le _)] at bound
  have eq : (1+4*R/h) = (R+r)/r := by dsimp [r]; field_simp; ring
  rw [eq,div_pow,le_div_iff₀ (pow_pos hr _)]; exact bound

end UL.Arxiv.PrescribedGrid

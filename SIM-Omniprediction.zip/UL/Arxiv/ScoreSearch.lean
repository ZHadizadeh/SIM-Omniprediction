import UL.Proof.lem_C_2.H3_EmpiricalFit
import UL.Arxiv.ScoreGrid
import UL.Arxiv.FiniteFit
import UL.Proof.lem_C_4
import UL.Proof.cit_brouwer
import UL.Proof.thm_C_1.Race3.H2_EmpiricalAndClass

open MeasureTheory Set
namespace UL.Arxiv.ScoreSearch

/-- Select the first lowest-scoring candidate of an ordered finite list. -/
noncomputable def best {α : Type*} (f : α → ℝ) (head : α) : List α → α
  | [] => head
  | a :: tail => best f (if f a < f head then a else head) tail

theorem best_le {α : Type*} (f : α → ℝ) (head : α) (tail : List α) :
    ∀ a ∈ head :: tail, f (best f head tail) ≤ f a := by
  induction tail generalizing head with
  | nil => simp [best]
  | cons b t ih =>
    intro a ha
    simp only [List.mem_cons] at ha
    rw [best]
    let v := if f b < f head then b else head
    have h := ih v v (List.mem_cons_self)
    have hmin : f v ≤ f b ∧ f v ≤ f head := by dsimp [v]; split_ifs with e <;> simp_all [le_of_lt,le_of_not_gt]
    rcases ha with rfl|rfl|hm
    · exact h.trans hmin.2
    · exact h.trans hmin.1
    · exact ih v a (List.mem_cons_of_mem _ hm)

/-- Quantitative selection and population transfer for a finite list of
empirical certificates. Each fitted forecast is attached to its score matrix. -/
theorem transfer {α L : Type*} (head : α) (tail : List α)
    (exactGap computedGap : α → ℝ) (emp pop : α → L → ℝ) (compEmp compPop : L → ℝ)
    {η e u v : ℝ} (good : ∃ a ∈ head::tail, exactGap a ≤ η)
    (error : ∀ a ∈ head::tail, |computedGap a-exactGap a| ≤ e)
    (reg : ∀ a ∈ head::tail, ∀ l, emp a l ≤ compEmp l + exactGap a + u)
    (dev : ∀ a ∈ head::tail, ∀ l, pop a l ≤ emp a l + v)
    (cmp : ∀ l, compEmp l ≤ compPop l + v) :
    ∀ l, pop (best computedGap head tail) l ≤ compPop l + η + 2*e + u + 2*v := by
  have hm : ∀ (h : α) (t : List α), best computedGap h t ∈ h::t := by
    intro h t; induction t generalizing h with
    | nil => simp [best]
    | cons b t ih =>
      rw [best]
      split_ifs <;> simp only [List.mem_cons] at * <;> grind
  let a := best computedGap head tail
  have ha := hm head tail
  obtain ⟨z,hz,hh⟩ := good
  have h := best_le computedGap head tail z hz
  intro l
  linarith [(abs_le.mp (error _ ha)).1, (abs_le.mp (error z hz)).2, reg _ ha l,dev _ ha l,cmp l]

/-- For every bounded sample, the explicit projected rectangular score grid
contains a finite level whose minimum fitted gap is below the tolerance.
The selected matrix vanishes on the orthogonal complement of the sample span.
The returned simplex-valued link is the same-cap quadratic-program extension. -/
theorem search_scores {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    (X : Type) [NormedAddCommGroup X] [InnerProductSpace ℝ X] [CompleteSpace X]
    (x : Fin n → X) (y : Fin n → Fin K) {L R β B η : ℝ}
    (hL : 0 < L) (hx : ∀ i, ‖x i‖ ≤ L) (hR : 0 < R) (hβ : 0 < β) (hB : β ≤ B) (hη : 0 < η) :
    let m := Module.finrank ℝ (Proof_lem_C_2.sampleSpan x) * Module.finrank ℝ (ZeroSumSubspace K)
    ∃ N : ℕ, 0 < N ∧ ∃ a : Fin m → Fin (N+1),
      let W := Proof_lem_C_2.toSampleSpanOp (Y:=ZeroSumSubspace K) x (ScoreGrid.point hR a).val
      hilbertSchmidtNorm W ≤ R ∧ (∀ v ∈ (Proof_lem_C_2.sampleSpan x)ᗮ, W v = 0) ∧
      ∃ ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K),
        (∀ z, ρ z ∈ Simplex K) ∧ LipschitzWith B.toNNReal ρ ∧
        ∀ {lam M : ℝ} (Φ : Simplex K → ℝ), Φ ∈ SmoothEntropyFamily K β lam M →
          (1/(n:ℝ))*∑ i, finiteCanonicalLoss Φ (ρ (W (x i))) (y i) ≤
          (⨅ V : {V : X →L[ℝ] ZeroSumSubspace K // hilbertSchmidtNorm V ≤ R},
            (1/(n:ℝ))*∑ i, matchingLoss Φ ((V.val (x i) : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) (y i)) + η := by
  classical
  intro m
  let h_lem_C_4 := UL.P_lem_C_4
  have hB_pos := hβ.trans_le hB
  let Z : Fin n → ZeroSumSubspace K := fun i =>
    ⟨EuclideanSpace.single (y i) (1 : ℝ) - uniformVec K,
      Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex
        (Proof_lem_A_1.single_mem_simplex (y i))
        (Proof_lem_A_5.uniformVec_mem_simplex hK)⟩
  have hZ : ∀ i : Fin n,
      (Z i : EuclideanSpace ℝ (Fin K)) = EuclideanSpace.single (y i) (1 : ℝ) - uniformVec K :=
    fun _ => rfl
  have hw_norm : ∀ w : Metric.closedBall (0 : EuclideanSpace ℝ (Fin m)) R, ‖w.1‖ ≤ R := by
    intro w
    have hw : w.1 ∈ Metric.closedBall (0 : EuclideanSpace ℝ (Fin m)) R := w.2
    rwa [Metric.mem_closedBall, dist_zero_right] at hw
  have hw_scores : ∀ w : Metric.closedBall (0 : EuclideanSpace ℝ (Fin m)) R,
      ∀ i : Fin n,
        ‖Proof_lem_C_2.toSampleSpanOp (Y := ZeroSumSubspace K) x w.1 (x i)‖ ≤ L * R := by
    intro w i
    calc ‖Proof_lem_C_2.toSampleSpanOp (Y := ZeroSumSubspace K) x w.1 (x i)‖
        ≤ hilbertSchmidtNorm
            (Proof_lem_C_2.toSampleSpanOp (Y := ZeroSumSubspace K) x w.1) * ‖x i‖ :=
          Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm _ (x i)
      _ = ‖w.1‖ * ‖x i‖ := by
          rw [Proof_lem_C_2.hilbertSchmidtNorm_toSampleSpanOp]
      _ ≤ R * L := mul_le_mul (hw_norm w) (hx i) (norm_nonneg _) hR.le
      _ = L * R := mul_comm R L
  let scoreMap : Metric.closedBall (0 : EuclideanSpace ℝ (Fin m)) R →
      {s : Fin n → ZeroSumSubspace K // ∀ i : Fin n, ‖s i‖ ≤ L * R} :=
    fun w => ⟨fun i => Proof_lem_C_2.toSampleSpanOp (Y := ZeroSumSubspace K) x w.1 (x i),
      hw_scores w⟩
  have h_score_cont : Continuous scoreMap :=
    ((Proof_lem_C_2.continuous_toSampleSpanOp_eval (Y := ZeroSumSubspace K) x).comp
      continuous_subtype_val).subtype_mk _
  let centeredFitMap : Metric.closedBall (0 : EuclideanSpace ℝ (Fin m)) R →
      (Fin n → ZeroSumSubspace K) :=
    fun w => Proof_lem_C_2.optFitScores (L * R) B Z (scoreMap w).1
  have h_centeredFitMap_cont : Continuous centeredFitMap :=
    (Proof_lem_C_2.continuous_optFitScores h_lem_C_4 hK hn hB_pos Z).comp h_score_cont
  let gMap : Metric.closedBall (0 : EuclideanSpace ℝ (Fin m)) R → EuclideanSpace ℝ (Fin m) :=
    fun w => Proof_lem_C_2.empGradVec x (fun i => centeredFitMap w i - Z i)
  have h_gMap_cont : Continuous gMap :=
    (Proof_lem_C_2.continuous_empGradVec x Z).comp h_centeredFitMap_cont

  let gap := fun w : ScoreGrid.Ball m R => inner ℝ (gMap w) w.val + R*‖gMap w‖
  have hg : Continuous gap := (h_gMap_cont.inner continuous_subtype_val).add (continuous_const.mul h_gMap_cont.norm)
  have hz := Proof_lem_C_2.exists_zero_gap_on_ball UL.P_cit_brouwer.{0} hR gMap h_gMap_cont
  obtain ⟨N,hN,a₀,h₀⟩ := ScoreGrid.near_zero (gap:=gap) hR hη hg hz
  let value := fun a : Fin m → Fin (N+1) => gap (ScoreGrid.point hR a)
  let tail := (Finset.univ : Finset (Fin m → Fin (N+1))).toList
  let a := best value (fun _ => 0) tail
  have ha : value a < η := (best_le value _ tail _ (List.mem_cons_of_mem _ (by simp [tail]))).trans_lt h₀
  let w := ScoreGrid.point hR a
  let W := Proof_lem_C_2.toSampleSpanOp (Y:=ZeroSumSubspace K) x w.val
  let pTilde := centeredFitMap w
  have hW_norm : hilbertSchmidtNorm W ≤ R := by unfold W; rw [Proof_lem_C_2.hilbertSchmidtNorm_toSampleSpanOp]; exact hw_norm w
  have hWx_le := hw_scores w
  have hWP_opt := Proof_lem_C_2.optFitScores_spec h_lem_C_4 hK hn hB_pos Z hWx_le
  change Proof_lem_C_2.isOptFitAtScores (L*R) B Z (fun i => W (x i)) pTilde at hWP_opt
  obtain ⟨ρ₀, ⟨hρ₀_simp, hρ₀_lip⟩, hP_eq⟩ := hWP_opt.1
  let p_pts : Fin n → EuclideanSpace ℝ (Fin K) :=
    fun i => UL.uniformVec K + (pTilde i : EuclideanSpace ℝ (Fin K))
  have hp_pts : ∀ i : Fin n, p_pts i ∈ UL.Simplex K := by
    intro i
    dsimp [p_pts]
    rw [hP_eq i]
    exact hρ₀_simp (W (x i)) (hWx_le i)
  let iso := Proof_thm_C_1_Race3.isoZeroSum hK
  let s_pts : Fin n → EuclideanSpace ℝ (Fin (K - 1)) := fun i => iso (W (x i))
  have hLip_pts : ∀ i j : Fin n, ‖p_pts i - p_pts j‖ ≤ B * ‖s_pts i - s_pts j‖ := by
    intro i j
    have hdiff_p : p_pts i - p_pts j =
        (pTilde i : EuclideanSpace ℝ (Fin K)) - (pTilde j : EuclideanSpace ℝ (Fin K)) := by
      dsimp [p_pts]
      abel
    have hnorm_s : ‖s_pts i - s_pts j‖ = ‖W (x i) - W (x j)‖ := by
      rw [← dist_eq_norm, ← dist_eq_norm]
      exact iso.isometry.dist_eq (W (x i)) (W (x j))
    rw [hdiff_p, ← Submodule.coe_sub, Submodule.norm_coe, hnorm_s, hP_eq i, hP_eq j]
    exact hρ₀_lip (W (x i)) (W (x j)) (hWx_le i) (hWx_le j)
  obtain ⟨hExMin, _hUniqMin, hExt⟩ :=
    h_lem_C_4 (K - 1) n K (by omega) hn hK s_pts p_pts hp_pts B hB_pos hLip_pts
  choose θ_s hθ_s using hExMin
  obtain ⟨hρm_hull, hhull_sub, hρm_interp, hρm_lip, _⟩ := hExt θ_s hθ_s
  let P_mat : Matrix (Fin K) (Fin n) ℝ := Matrix.of (fun k i => p_pts i k)
  let ρ_m : EuclideanSpace ℝ (Fin (K - 1)) → EuclideanSpace ℝ (Fin K) :=
    fun s₀ => Matrix.toEuclideanLin P_mat (θ_s s₀)
  let ρ : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) := fun z => ρ_m (iso z)
  have hρ_simp : ∀ z : UL.ZeroSumSubspace K, ρ z ∈ UL.Simplex K :=
    fun z => hhull_sub (hρm_hull (iso z))
  have hρ_lip : LipschitzWith (Real.toNNReal B) ρ := by
    simpa [ρ, mul_one] using hρm_lip.comp iso.lipschitz
  have hρ_interp : ∀ i : Fin n, ρ (W (x i)) = p_pts i :=
    fun i => hρm_interp i

  refine ⟨N,hN,a,hW_norm,(fun _ hv => Proof_lem_C_2.toSampleSpanOp_vanishes_orth x w.val hv),ρ,hρ_simp,hρ_lip,?_⟩
  intro lam M Φ hΦ
  have h := Proof_lem_C_2.empirical_comparison_bound hK hn x y hL hx hR hβ hB hZ hW_norm (P:=pTilde) hWP_opt hΦ
  have eq := Proof_lem_C_2.gamma_toSampleSpanOp_eq x (fun i => pTilde i-Z i) R w.val
  dsimp only at h eq
  change (1/(n:ℝ))*∑ i, finiteCanonicalLoss Φ (ρ (W (x i))) (y i) ≤ _
  simp_rw [hρ_interp]
  apply h.trans
  exact add_le_add le_rfl (eq.le.trans ha.le)

end UL.Arxiv.ScoreSearch

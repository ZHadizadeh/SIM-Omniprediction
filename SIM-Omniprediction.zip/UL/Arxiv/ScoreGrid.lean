import UL.Proof.lem_C_2.H4_BrouwerFixedPoint
import UL.Proof.lem_A_4.H1_SimplexFit

open Metric Set
namespace UL.Arxiv.ScoreGrid

abbrev V (m : ℕ) := EuclideanSpace ℝ (Fin m)
abbrev Ball (m : ℕ) (R : ℝ) := Metric.closedBall (0 : V m) R

/-- Equally spaced grid in the cube, projected onto the Frobenius ball. -/
noncomputable def point {m N : ℕ} {R : ℝ} (hR : 0 < R) (a : Fin m → Fin (N+1)) : Ball m R :=
  ⟨Proof_lem_C_2.projBall R (WithLp.toLp 2 fun j => 2*R*(a j).val/N-R),
    Proof_lem_C_2.projBall_mem_closedBall hR _⟩

private theorem rounding {N : ℕ} (hN : 0 < N) {R z : ℝ} (hR : 0 < R) (hz : |z| ≤ R) :
    ∃ i : Fin (N+1), |2*R*(i.val:ℝ)/N-R-z| ≤ 2*R/N := by
  let t := ((z+R)/(2*R))*(N:ℝ)
  have h := abs_le.mp hz
  have hn : (0:ℝ) < N := by positivity
  have ht : 0 ≤ t := mul_nonneg (div_nonneg (by linarith) (by linarith)) hn.le
  have ht' : t ≤ N := by
    dsimp [t]; exact (mul_le_mul_of_nonneg_right ((div_le_one (by linarith)).mpr (by linarith)) hn.le).trans (by ring_nf; rfl)
  have ha := Nat.floor_le ht
  have hb := Nat.lt_floor_add_one t
  have hw : (⌊t⌋₊:ℝ) ≤ (N:ℝ) := ha.trans ht'
  refine ⟨⟨⌊t⌋₊, Nat.lt_succ_of_le (by exact_mod_cast hw)⟩,abs_le.mpr ⟨?_,?_⟩⟩
  all_goals
    change _ ≤ _
    have eq : t*(2*R) = (z+R)*N := by dsimp [t]; field_simp <;> ring
    dsimp
    field_simp [hn,hn.ne']
    nlinarith [mul_nonneg (sub_nonneg.mpr ha) (show 0 ≤ 2*R by linarith),
      mul_nonneg (sub_nonneg.mpr hb.le) (show 0 ≤ 2*R by linarith)]

theorem cover {m N : ℕ} {R : ℝ} (hR : 0 < R) (hN : 0 < N) (w : Ball m R) :
    ∃ a : Fin m → Fin (N+1), dist (point hR a) w ≤ 4*R*Real.sqrt m/N := by
  have hw : ‖w.val‖ ≤ R := by simpa only [Metric.mem_closedBall,dist_zero_right] using w.property
  choose a ha using fun j : Fin m => rounding hN hR ((PiLp.norm_apply_le w.val j).trans hw)
  let v : V m := WithLp.toLp 2 fun j => 2*R*(a j).val/N-R
  have hsq := UL.Proof_lem_A_4.norm_sq_eq_sum (v-w.val)
  have hh : ∀ j : Fin m, ((v-w.val) j)^2 ≤ (2*R/N)^2 := by
    intro j
    exact sq_le_sq' (abs_le.mp (ha j)).1 (abs_le.mp (ha j)).2
  have hs := Finset.sum_le_sum (s:=Finset.univ) fun j _ => hh j
  rw [← hsq,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul] at hs
  have rad : 0 ≤ 2*R/(N:ℝ) := by positivity
  have H : ‖v-w.val‖ ≤ Real.sqrt m*(2*R/N) := by
    apply le_of_sq_le_sq _ (by positivity)
    rwa [mul_pow,Real.sq_sqrt (Nat.cast_nonneg _)]
  have dp : ‖Proof_lem_C_2.projBall R v - v‖ ≤ ‖v-w.val‖ := by
    by_cases hv : ‖v‖ ≤ R
    · simp [Proof_lem_C_2.projBall,max_eq_left hv,hR.ne']
    · have hp : 0 < ‖v‖ := hR.trans (lt_of_not_ge hv)
      rw [Proof_lem_C_2.projBall,max_eq_right (le_of_not_ge hv),show (R / ‖v‖) • v - v = (R/‖v‖-1) • v by rw [sub_smul,one_smul], norm_smul,Real.norm_eq_abs,
        abs_of_nonpos (sub_nonpos.mpr ((div_le_one hp).mpr (le_of_not_ge hv)))]
      have htri := norm_sub_norm_le v w.val
      field_simp [hp,hp.ne']; nlinarith [mul_nonneg hp.le (sub_nonneg.mpr (show ‖v‖-R ≤ ‖v-w.val‖ by linarith))]
  refine ⟨a,?_⟩
  change dist (Proof_lem_C_2.projBall R v) w.val ≤ _
  rw [dist_eq_norm]
  calc _ ≤ ‖Proof_lem_C_2.projBall R v-v‖+‖v-w.val‖ := norm_sub_le_norm_sub_add_norm_sub _ _ _
       _ ≤ 4*R*Real.sqrt m/N := by linarith only [dp,H,show 4*R*Real.sqrt m/N = 2*(Real.sqrt m*(2*R/N)) by ring]

/-- On the explicit grid, a continuous certificate with a zero has a
candidate below any positive tolerance, including a zero-dimensional span. -/
theorem near_zero {m : ℕ} {R η : ℝ} (hR : 0 < R) (hη : 0 < η)
    {gap : Ball m R → ℝ} (hg : Continuous gap) (hz : ∃ w, gap w = 0) :
    ∃ N : ℕ, 0 < N ∧ ∃ a : Fin m → Fin (N+1), gap (point hR a) < η := by
  obtain ⟨w,hw⟩ := hz
  obtain ⟨r,hr,hm⟩ := Metric.continuousAt_iff.mp (hg.continuousAt (x:=w)) η hη
  obtain ⟨N,hN⟩ := exists_nat_gt (max 0 (4*R*Real.sqrt m/r))
  have hn : 0 < N := by exact_mod_cast (lt_of_le_of_lt (le_max_left _ _) hN)
  obtain ⟨a,ha⟩ := cover hR hn w
  have hrad : 4*R*Real.sqrt m/(N:ℝ) < r := by
    have h := lt_of_le_of_lt (le_max_right _ _) hN
    have h' := (div_lt_iff₀ hr).mp h
    exact (div_lt_iff₀ (Nat.cast_pos.mpr hn)).mpr (by linarith)
  have close := hm (ha.trans_lt hrad)
  rw [hw,Real.dist_eq,sub_zero] at close
  exact ⟨N,hn,a,(le_abs_self _).trans_lt close⟩

end UL.Arxiv.ScoreGrid

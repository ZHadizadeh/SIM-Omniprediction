import UL.Proof.lem_A_2.H3_ContinuityAndMatrix
import UL.Proof.lem_A_5.H2_Moreau
import UL.Proof.thm_7_1.H0_Defs
import UL.Proof.thm_7_1.Race2.H4_EmpiricalAndLink

/-! # Notation in the manuscript

The population fit takes values in the simplex. The empirical fit is often
stored after subtracting its center. These identities relate the two conventions.
-/

namespace UL.Arxiv.Notation

open MeasureTheory

/-- The centered simplex 𝒞 = Δ_K − u in H. -/
abbrev centeredSimplex (K : ℕ) := Proof_thm_7_1.CSet K

theorem shiftedSimplex_eq (K : ℕ) :
    Proof_lem_A_5.shiftedSimplex K = centeredSimplex K := by
  ext s
  change uniformVec K + (s : EuclideanSpace ℝ (Fin K)) ∈ Simplex K ↔
    (s : EuclideanSpace ℝ (Fin K)) + uniformVec K ∈ Simplex K
  rw [add_comm]

theorem dictionarySimplex_eq (K : ℕ) :
    Proof_thm_7_1_Race2.cSetDef K = centeredSimplex K := rfl

/-- Subtracting the center from both P and e_Y preserves the residual ξ. -/
theorem residual_eq_centered {Ω : Type*} {K : ℕ}
    (P : Ω → EuclideanSpace ℝ (Fin K)) (Y : Ω → Fin K) (ω : Ω) :
    fitResidual P Y ω = (P ω - uniformVec K) -
      (Proof_thm_7_1.centeredLabel (Y ω) : EuclideanSpace ℝ (Fin K)) := by
  change P ω - oneHotVec (Y ω) =
    (P ω - uniformVec K) - (oneHotVec (Y ω) - uniformVec K)
  abel

/-- The population matrix g(W) in Lemma B.2, expressed as a continuous linear map. -/
noncomputable def scoreMoment {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    {d K : ℕ} (B : ℝ) (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin K) :=
  ∫ ω, Proof_lem_A_2.matIntegrand μ B W X Y ω ∂μ

theorem scoreMoment_eq {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    {d K : ℕ} (B : ℝ) (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin K) :
    scoreMoment μ B W X Y = ∫ ω, (innerSL ℝ (X ω)).smulRight
      (fitResidual (linearFittedPrediction μ B W X Y) Y ω) ∂μ := rfl

end UL.Arxiv.Notation

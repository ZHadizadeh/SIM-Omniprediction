import UL.Arxiv.Tightness

/-! # Passing the risk comparison to an almost-sure limit of forecasts -/
open Set Filter Topology MeasureTheory
open scoped NNReal
namespace UL.Arxiv.BoundedBinary
noncomputable section
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
variable {A : ℝ≥0}

private theorem abs_residual (q y : Probability) : |(q : ℝ) - y| ≤ 1 :=
  abs_le.mpr ⟨by linarith [q.2.1, y.2.2], by linarith [q.2.2, y.2.1]⟩

/-- A continuous test on the probability interval and a bounded fixed action
are both covered by the same dominated-convergence argument. -/
private theorem moment_limit {Pn : ℕ → Ω → Probability} {P Y : Ω → Probability}
    (hn : ∀ n, Measurable (Pn n)) (hy : Measurable Y)
    (hc : ∀ᵐ ω ∂μ, Tendsto (fun n => Pn n ω) atTop (𝓝 (P ω)))
    {hnf : ℕ → Ω → ℝ} {f : Ω → ℝ} (hm : ∀ n, Measurable (hnf n))
    (hf : ∀ᵐ ω ∂μ, Tendsto (fun n => hnf n ω) atTop (𝓝 (f ω)))
    {C : ℝ} (hb : ∀ n ω, |hnf n ω| ≤ C) :
    Tendsto (fun n => ∫ ω, ((Pn n ω : ℝ) - Y ω) * hnf n ω ∂μ) atTop
      (𝓝 (∫ ω, ((P ω : ℝ) - Y ω) * f ω ∂μ)) := by
  apply tendsto_integral_of_dominated_convergence (fun _ => C)
    (fun n => (((measurable_subtype_coe.comp (hn n)).sub
      (measurable_subtype_coe.comp hy)).mul (hm n)).aestronglyMeasurable) (integrable_const _)
  · intro n
    filter_upwards with ω
    rw [Real.norm_eq_abs, abs_mul]
    simpa using mul_le_mul (abs_residual (Pn n ω) (Y ω)) (hb n ω) (abs_nonneg _) zero_le_one
  · filter_upwards [hc, hf] with ω h₁ h₂
    exact ((continuous_subtype_val.continuousAt.tendsto.comp h₁).sub tendsto_const_nhds).mul h₂

theorem limit_risk {Pn : ℕ → Ω → Probability} {P Y : Ω → Probability}
    (hn : ∀ n, Measurable (Pn n)) (hp : Measurable P) (hy : Measurable Y)
    (hc : ∀ᵐ ω ∂μ, Tendsto (fun n => Pn n ω) atTop (𝓝 (P ω)))
    (htest : ∀ n, ∀ f : ℝ → ℝ, Monotone f → ∀ C : ℝ, (∀ x, |f x| ≤ C) →
      (∫ ω, ((Pn n ω : ℝ) - Y ω) * f (Pn n ω) ∂μ) ≤ 0)
    {ε : ℕ → ℝ} (he : Tendsto ε atTop (𝓝 0))
    {a : Ω → Action A} (ha : Measurable a)
    (hlin : ∀ n, -(ε n) ≤ ∫ ω, ((Pn n ω : ℝ) - Y ω) * (a ω : ℝ) ∂μ)
    {σ : Target A} {k : Probability → Action A} (hk : IsBayes σ k) :
    (∫ ω, loss σ (k (P ω)) (Y ω) ∂μ) ≤ ∫ ω, loss σ (a ω) (Y ω) ∂μ := by
  have hcontinuous (g : ℝ → ℝ) (hg : Continuous g) (hm : Monotone g) :
      (∫ ω, ((P ω : ℝ) - Y ω) * g (P ω) ∂μ) ≤ 0 := by
    let G : C(Probability, ℝ) := ⟨fun q => g q, hg.comp continuous_subtype_val⟩
    let g' (x : ℝ) := g ((projIcc 0 1 zero_le_one x) : ℝ)
    have hbound (q : Probability) : |g q| ≤ ‖G‖ := G.norm_coe_le_norm q
    have hg' : Monotone g' := fun _ _ h => hm (monotone_projIcc _ h)
    apply le_of_tendsto' (moment_limit hn hy hc
      (fun n => hg.measurable.comp (measurable_subtype_coe.comp (hn n)))
      (hc.mono fun ω h => (hg.comp continuous_subtype_val).continuousAt.tendsto.comp h)
      (fun n ω => hbound (Pn n ω)))
    intro n
    simpa only [g', projIcc_val] using htest n g' hg' ‖G‖ (fun x => hbound _)
  have htestP : ∀ f : ℝ → ℝ, Monotone f → ∀ C : ℝ, (∀ x, |f x| ≤ C) →
      (∫ ω, ((P ω : ℝ) - Y ω) * f (P ω) ∂μ) ≤ 0 := fun _ hf _ hb =>
    test_of_continuous_tests ((measurable_subtype_coe.comp hp).sub (measurable_subtype_coe.comp hy))
      (measurable_subtype_coe.comp hp) (Eventually.of_forall fun ω => abs_residual (P ω) (Y ω))
      hcontinuous hf hb
  have hconv := moment_limit hn hy hc (hnf := fun _ ω => (a ω : ℝ)) (f := fun ω => (a ω : ℝ))
    (fun _ => measurable_subtype_coe.comp ha) (Eventually.of_forall fun _ => tendsto_const_nhds)
    (fun _ ω => abs_le.mpr (a ω).2)
  have hlin0 := le_of_tendsto_of_tendsto' he.neg hconv hlin
  simpa only [add_zero] using risk_le_of_residual (ε := 0) hk hp hy ha (selector_test hk htestP)
    (by simpa only [neg_zero] using hlin0)

end
end UL.Arxiv.BoundedBinary

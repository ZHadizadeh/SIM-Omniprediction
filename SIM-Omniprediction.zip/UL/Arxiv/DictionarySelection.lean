import UL.Proof.thm_7_1.H0_Defs
import UL.Arxiv.MinimumNorm
import UL.Proof.thm_7_1.Race2.H4_EmpiricalAndLink

set_option maxHeartbeats 1800000
open MeasureTheory
namespace UL.Arxiv
open Proof_thm_7_1 Proof_thm_7_1_Race2

/-- The affine least-squares minimizer with smallest Frobenius norm is a
Borel function of the sample. No dictionary condition is needed to select
the fit. The geometry is used later to prove its risk guarantee. -/
theorem measurableDictionaryFit {n d K : ℕ} (hn : 1 ≤ n)
    (β R : ℝ) (hR : 0 ≤ R) :
    let X := EuclideanSpace ℝ (Fin d)
    let H : Type := ↥(ZeroSumSubspace K)
    let S := (Fin n → X) × (Fin n → H)
    ∃ (a : S → H) (W : S → X →L[ℝ] H),
      Measurable a ∧ Measurable W ∧ ∀ s, hilbertSchmidtNorm (W s) ≤ R ∧
      (∀ b V, hilbertSchmidtNorm V ≤ R →
        ∑ i, ‖a s + β • W s (s.1 i) - s.2 i‖^2 ≤
        ∑ i, ‖b + β • V (s.1 i) - s.2 i‖^2) ∧
      (∀ b V, hilbertSchmidtNorm V ≤ R →
        (∑ i, ‖b + β • V (s.1 i) - s.2 i‖^2) =
          ∑ i, ‖a s + β • W s (s.1 i) - s.2 i‖^2 →
        hilbertSchmidtNorm (W s) ≤ hilbertSchmidtNorm V) := by
  classical
  intro X H S
  let E := PiLp 2 (fun _ : Fin d => H)
  letI : MeasurableSpace E := borel E
  letI : BorelSpace E := ⟨rfl⟩
  let e := hsPiEquiv d H
  let xb (s : S) := (1 / (n:ℝ)) • ∑ i, s.1 i
  let zb (s : S) := (1 / (n:ℝ)) • ∑ i, s.2 i
  let aof (s : S) (w : E) := zb s - β • e.symm w (xb s)
  let res (s : S) (w : E) (i : Fin n) := aof s w + β • e.symm w (s.1 i) - s.2 i
  let f (s : S) (w : E) := ∑ i, ‖res s w i‖^2
  have hxb : Continuous xb := by dsimp only [xb,S]; fun_prop
  have hzb : Continuous zb := by dsimp only [zb,S]; fun_prop
  have ha : Continuous (Function.uncurry aof) := by
    change Continuous (fun z : S × E => zb z.1 - β • (e.symm z.2) (xb z.1))
    fun_prop
  have hf : Continuous (Function.uncurry f) := by
    apply continuous_finset_sum
    intro i _
    change Continuous (fun z : S × E => ‖Function.uncurry aof z + β • (e.symm z.2) (z.1.1 i) - z.1.2 i‖^2)
    have hx : Continuous (fun z : S × E => z.1.1 i) :=
      (continuous_apply i).comp (continuous_fst.comp continuous_fst)
    have hz : Continuous (fun z : S × E => z.1.2 i) :=
      (continuous_apply i).comp (continuous_snd.comp continuous_fst)
    exact ((ha.add (continuous_const.smul
      ((e.symm.continuous.comp continuous_snd).clm_apply hx))).sub hz).norm.pow 2
  have hconv (s : S) : ConvexOn ℝ (Metric.closedBall (0:E) R) (f s) := by
    refine ⟨convex_closedBall _ _, ?_⟩
    intro x _ y _ u v hu hv huv
    dsimp only [f]
    simp only [smul_eq_mul, Finset.mul_sum, ← Finset.sum_add_distrib]
    apply Finset.sum_le_sum
    intro i _
    change ‖res s (u • x + v • y) i‖^2 ≤ u * ‖res s x i‖^2 + v * ‖res s y i‖^2
    have hz : res s (u • x + v • y) i = u • res s x i + v • res s y i := by
      rw [show v = 1-u by linarith]
      dsimp only [res,aof]
      simp only [map_add,map_smul,ContinuousLinearMap.add_apply,ContinuousLinearMap.smul_apply]
      module
    rw [hz]
    have hl := norm_add_le (u • res s x i) (v • res s y i)
    rw [norm_smul,norm_smul,Real.norm_eq_abs,Real.norm_eq_abs,abs_of_nonneg hu,abs_of_nonneg hv] at hl
    calc _ ≤ (u * ‖res s x i‖ + v * ‖res s y i‖)^2 := pow_le_pow_left₀ (norm_nonneg _) hl 2
         _ ≤ _ := (convexOn_pow (𝕜:=ℝ) 2).2 (norm_nonneg _) (norm_nonneg _) hu hv huv
  obtain ⟨w,hw,hfit⟩ := minimumNormBallFit (S:=S) (E:=E) hR f hf hconv
  have hcA : Measurable (Function.uncurry aof) := ha.measurable
  have hpair : Measurable (fun s : S => (s,w s)) := measurable_id.prodMk hw
  have hameas := hcA.comp hpair
  have hemeas : Measurable (e.symm : E → (X →L[ℝ] H)) := e.symm.continuous.measurable
  have hWmeas := hemeas.comp hw
  refine ⟨(Function.uncurry aof) ∘ (fun s => (s,w s)), e.symm ∘ w,
    hameas, hWmeas, ?_⟩
  dsimp only [Function.comp_apply,Function.uncurry]
  intro s
  obtain ⟨hb,hm,ht⟩ := hfit s
  have hcenter := (centeredInterceptOptimal hn β s.1 s.2).2
  have hopt (b : H) (V : X →L[ℝ] H) (hv : hilbertSchmidtNorm V ≤ R) :
      f s (w s) ≤ ∑ i, ‖b + β • V (s.1 i) - s.2 i‖^2 := by
    have hv' : ‖e V‖ ≤ R := (hilbertSchmidtNorm_eq_norm_hsPiEquiv V).symm.trans_le hv
    apply (hm (e V) hv').trans
    simpa only [f,res,aof,e,ContinuousLinearEquiv.symm_apply_apply,xb,zb] using hcenter b V
  have hsn : hilbertSchmidtNorm (e.symm (w s)) = ‖w s‖ :=
    hilbertSchmidtNorm_eq_norm_hsPiEquiv_symm (d:=d) (Y:=H) (w s)
  refine ⟨hsn.trans_le hb, hopt, ?_⟩
  intro b V hv he
  have hv' : ‖e V‖ ≤ R := (hilbertSchmidtNorm_eq_norm_hsPiEquiv V).symm.trans_le hv
  have hx : f s (e V) ≤ ∑ i, ‖b + β • V (s.1 i) - s.2 i‖^2 := by
    simpa only [f,res,aof,e,ContinuousLinearEquiv.symm_apply_apply,xb,zb] using hcenter b V
  have he' : f s (e V) = f s (w s) := le_antisymm (hx.trans he.le) (hm _ hv')
  exact (hsn.trans_le (ht _ hv' he')).trans_eq (hilbertSchmidtNorm_eq_norm_hsPiEquiv V).symm

end UL.Arxiv

import UL.Arxiv.FiniteLearner

open Set
namespace UL.Arxiv.QueryContinuity
open FiniteLearner GridOracle

/-- A continuous objective on a fixed compact feasible set may have several
minimizers. A continuous observable with the same value at all of them
still depends continuously on the problem data. -/
private theorem optimizer_output {T U V : Type*} [TopologicalSpace T] [TopologicalSpace U]
    [TopologicalSpace V] [CompactSpace U] (q : T × U → ℝ) (g : T × U → V)
    (hq : Continuous q) (hg : Continuous g) (f : T → V)
    (exists_min : ∀ x, ∃ u, ∀ v, q (x,u) ≤ q (x,v))
    (unique : ∀ x u, (∀ v, q (x,u) ≤ q (x,v)) → g (x,u) = f x) : Continuous f := by
  rw [continuous_iff_isClosed]
  intro C hC
  let F : Set (T × U) := (g ⁻¹' C) ∩ ⋂ v : U, {z | q z ≤ q (z.1,v)}
  have hc : IsClosed F := (hC.preimage hg).inter (isClosed_iInter fun v =>
    isClosed_le hq (hq.comp (continuous_fst.prodMk continuous_const)))
  have eq : f ⁻¹' C = Prod.fst '' F := by
    ext x
    constructor
    · intro hx
      obtain ⟨u,hu⟩ := exists_min x
      exact ⟨(x,u),⟨(show g (x,u) ∈ C by rw [unique x u hu]; exact hx),Set.mem_iInter.mpr hu⟩,rfl⟩
    · rintro ⟨⟨x,u⟩,⟨hc,hu⟩,rfl⟩
      change f x ∈ C
      rw [← unique x u (Set.mem_iInter.mp hu)]; exact hc
  rw [eq]; exact isClosedMap_fst_of_compactSpace _ hc

private noncomputable def mix {k n : ℕ} (v : Fin n → E k) (θ : E n) :=
  Matrix.toEuclideanLin (Matrix.of (fun j i => v i j)) θ

private theorem mix_cont {T : Type*} [TopologicalSpace T] {n k : ℕ}
    {s : T → Fin n → E k} {w : T → E n} (hs : Continuous s) (hw : Continuous w) :
    Continuous (fun t => mix (s t) (w t)) := by
  have eq (t : T) : mix (s t) (w t) = ∑ i, (w t i) • s t i := by
    ext j
    change _ = EuclideanSpace.proj j (∑ i, (w t i) • s t i)
    rw [map_sum]
    simp [mix,Matrix.toEuclideanLin_apply,Matrix.mulVec,dotProduct,mul_comm]
  simp_rw [eq]
  exact continuous_finset_sum _ fun i _ => (((EuclideanSpace.proj i).continuous.comp hw).smul
    ((continuous_apply i).comp hs))

/-- The actual quadratic-program forecast, evaluated at a new query, is
jointly continuous as the feasible stored scores, probabilities and query vary. -/
theorem joint {T : Type*} [TopologicalSpace T] {n K : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {B : ℝ} (hB : 0 < B) (s : T → Fin n → H K) (p : T → Fin n → E K) (z : T → H K)
    (hs : Continuous s) (hp : Continuous p) (hz : Continuous z)
    (mem : ∀ t i, p t i ∈ Simplex K) (cap : ∀ t i j, ‖p t i-p t j‖ ≤ B*‖s t i-s t j‖) :
    Continuous (fun t => extend hK hn (s t) (p t) hB (mem t) (cap t) (z t)) := by
  let iso := Proof_thm_C_1_Race3.isoZeroSum hK
  let a := fun t i => iso (s t i)
  let d := fun t => WithLp.toLp 2 (fun i => B^2*‖a t i‖^2-‖p t i‖^2)
  let U := Simplex n
  let q := fun v : T × U => B^2*‖mix (a v.1) v.2.val-(2:ℝ) • iso (z v.1)‖^2
      + ‖mix (p v.1) v.2.val‖^2 + inner ℝ (d v.1) v.2.val
  let g := fun v : T × U => mix (p v.1) v.2.val
  have hc (t : T) (i j : Fin n) : ‖p t i-p t j‖ ≤ B*‖a t i-a t j‖ := by
    simpa only [a,← map_sub,LinearIsometryEquiv.norm_map] using cap t i j
  let h := fun t => UL.P_lem_C_4 (K-1) n K (by omega) hn hK (a t) (p t) (mem t) B hB (hc t)
  have ha : Continuous a := continuous_pi fun i => iso.continuous.comp ((continuous_apply i).comp hs)
  have hd : Continuous d := (PiLp.continuous_toLp 2 _).comp (continuous_pi fun i =>
    (continuous_const.mul (((continuous_apply i).comp ha).norm.pow 2)).sub (((continuous_apply i).comp hp).norm.pow 2))
  have hw : Continuous (fun v : T × U => v.2.val) := continuous_subtype_val.comp continuous_snd
  have hg : Continuous g := mix_cont (hp.comp continuous_fst) hw
  have ds := (mix_cont (ha.comp continuous_fst) hw).sub ((iso.continuous.comp (hz.comp continuous_fst)).const_smul (2:ℝ))
  have hq : Continuous q := (((continuous_const.mul (ds.norm.pow 2)).add (hg.norm.pow 2)).add
    ((hd.comp continuous_fst).inner hw))
  letI : CompactSpace U := isCompact_iff_compactSpace.mp (Proof_lem_A_5.isCompact_simplex n)
  apply optimizer_output q g hq hg
  · intro t
    obtain ⟨v,hv,hm⟩ := (h t).1 (iso (z t))
    exact ⟨⟨v,hv⟩,fun u => hm u.property⟩
  · intro t u hu
    let opt := (h t).1 (iso (z t))
    apply (h t).2.1 (iso (z t)) u.val opt.choose u.property _ opt.choose_spec.1 opt.choose_spec.2
    exact fun v hv => hu ⟨v,hv⟩

end UL.Arxiv.QueryContinuity

import UL.Arxiv.OneHotDictionary
import UL.Proof.prop_C_5

namespace UL.Arxiv

/-- Proposition 1.7. The uniform one-hot dictionary in the indicated dimension
is Dirichlet. Success with probability greater than 5/7 on every joint law
with this marginal costs at least a constant times ε⁻², even for the single
quadratic entropy with all five regularity and radius parameters equal to one. -/
theorem prop_1_7 {K : ℕ} (hK : 2 ≤ K) {ε : ℝ}
    (hε : 0 < ε) (hsmall : ε ≤ 1 / (256 * (K : ℝ) ^ 2)) :
    let d := Nat.floor (1 / (128 * (K : ℝ) ^ 2 * ε))
    1 ≤ d ∧ (1 / (256 * (K : ℝ)^2)) / ε ≤ (d : ℝ) ∧
    (d : ℝ) ≤ (1 / (128 * (K : ℝ)^2)) / ε ∧
    UL.Proof_prop_C_5_Race2.quadEntropy K ∈ SmoothEntropyFamily K 1 1 1 ∧
    DirichletFeatureCondition (@OneHot.point d) ∧
    MeasureTheory.IsProbabilityMeasure (OneHot.law d) ∧
    (∀ᵐ x ∂OneHot.law d, ‖x‖ = 1) ∧ QuadraticSampleLower K d (OneHot.law d) ε := by
  dsimp only
  obtain ⟨hd, hlo, hhi, _, _⟩ :=
    UL.Proof_prop_C_5_Race2.dim_and_sample_arithmetic hK hε hsmall
  letI := OneHot.law_prob hd
  exact ⟨hd, hlo, hhi, UL.Proof_prop_C_5_Race2.quadEntropy_mem_smoothEntropyFamily hK,
    OneHot.dirichlet hd, inferInstance, OneHot.law_unit,
    quadraticSampleLower_of_isotropic hK hε hsmall rfl _ OneHot.law_unit OneHot.covariance⟩

end UL.Arxiv

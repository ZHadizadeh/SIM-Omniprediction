import UL.Def.def_2_1

namespace UL.Arxiv

/-- A grid point obtained by rounding cumulative masses. Consecutive differences
are nonnegative and telescope to N, while every coordinate moves by at most 1/N. -/
theorem simplexGridApproximation {K N : ℕ} (hN : 0 < N) (p : Simplex K) :
    ∃ a : Fin K → ℕ, (∑ i, a i) = N ∧
      ‖(WithLp.toLp 2 fun i : Fin K => (a i : ℝ) / N) - p.val‖ ≤ Real.sqrt K / N := by
  classical
  let mass : ℕ → ℝ := fun i => if h : i < K then p.val ⟨i,h⟩ else 0
  have hm (i) : 0 ≤ mass i := by dsimp [mass]; split <;> first | exact p.property.1 _ | rfl
  let c (i : ℕ) := (N : ℝ) * ∑ j ∈ Finset.range i, mass j
  have hc (i) : 0 ≤ c i := mul_nonneg (Nat.cast_nonneg _) (Finset.sum_nonneg fun j _ => hm j)
  have hs (i) : c (i+1) = c i + N * mass i := by simp [c, Finset.sum_range_succ, mul_add]
  have hmono : Monotone c := monotone_nat_of_le_succ fun i => by
    rw [hs]
    exact le_add_of_nonneg_right (mul_nonneg (Nat.cast_nonneg _) (hm i))
  let k (i : ℕ) := ⌊c i⌋₊
  let a (i : Fin K) := k (i.val+1) - k i.val
  have hmass : ∑ j ∈ Finset.range K, mass j = 1 := by
    rw [← Fin.sum_univ_eq_sum_range (fun i => mass i)]
    simpa [mass] using p.property.2
  have hsum : (∑ i, a i) = N := by
    change (∑ i : Fin K, (fun j : ℕ => k (j+1) - k j) i.val) = _
    rw [Fin.sum_univ_eq_sum_range (fun j : ℕ => k (j+1) - k j), Finset.sum_range_tsub (f := k) (fun i j hij => Nat.floor_mono (hmono hij)) K]
    simp [k,c,hmass]
  refine ⟨a,hsum,?_⟩
  have hN' : 0 < (N : ℝ) := by exact_mod_cast hN
  have herr (i : Fin K) : |(a i : ℝ) / N - p.val i| ≤ 1 / N := by
    have hf := Nat.floor_le (hc i)
    have hf' := Nat.floor_le (hc (i.val+1))
    have hu := Nat.lt_floor_add_one (c i)
    have hu' := Nat.lt_floor_add_one (c (i.val+1))
    change |((k (i.val+1) - k i.val : ℕ) : ℝ) / N - p.val i| ≤ _
    rw [Nat.cast_sub (Nat.floor_mono (hmono (Nat.le_succ _))), abs_le]
    have hc' : c (i.val+1) = c i + N * p.val i := by simpa [mass] using hs i.val
    dsimp only [k]
    constructor <;> field_simp <;> nlinarith
  rw [EuclideanSpace.norm_eq]
  have hsq := Finset.sum_le_sum (s := Finset.univ) fun (i : Fin K) _ =>
    pow_le_pow_left₀ (abs_nonneg _) (herr i) 2
  change Real.sqrt (∑ i : Fin K, ‖(a i : ℝ) / N - p.val i‖^2) ≤ _
  simp only [Real.norm_eq_abs]
  refine (Real.sqrt_le_sqrt hsq).trans_eq ?_
  simp [Real.sqrt_mul (Nat.cast_nonneg K), Real.sqrt_sq (by positivity : 0 ≤ 1 / (N : ℝ)), div_eq_mul_inv]

end UL.Arxiv

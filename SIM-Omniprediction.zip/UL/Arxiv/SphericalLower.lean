import UL.Proof.prop_C_5

namespace UL.Arxiv
open MeasureTheory Proof_prop_C_5_Race2

/-- Proposition 1.5 with the five parameters fixed to one, the explicit
dimension and the uniform unit-sphere marginal used in the paper. -/
theorem prop_1_5_unit_sphere {K : ℕ} (hK : 2 ≤ K) {ε : ℝ}
    (hε : 0 < ε) (hsmall : ε ≤ 1 / (256 * (K : ℝ)^2)) :
    let d := Nat.floor (1 / (128 * (K : ℝ)^2 * ε))
    quadEntropy K ∈ SmoothEntropyFamily K 1 1 1 ∧
      IsProbabilityMeasure (sphereProb d) ∧ (∀ᵐ x ∂sphereProb d, ‖x‖ = 1) ∧
      QuadraticSampleLower K d (sphereProb d) ε := by
  intro d
  obtain ⟨hd, _, _, _, _⟩ := dim_and_sample_arithmetic hK hε hsmall
  haveI : IsProbabilityMeasure (sphereProb d) := sphereProb_isProb hd
  have hx := sphereProb_norm_eq_one_ae hd
  exact ⟨quadEntropy_mem_smoothEntropyFamily hK, inferInstance, hx,
    quadraticSampleLower_of_isotropic hK hε hsmall rfl _ hx
      (spherical_coord_cov hd _ hx (sphereProb_hasSphericalFeatureSymmetry hd))⟩

end UL.Arxiv

import UL.Arxiv.Approximation

open MeasureTheory
open scoped NNReal
namespace UL.Arxiv
open BoundedBinary

/-- Unnumbered positive-excess bounded-action extension of Theorem 1.1(b). The same forecast serves every continuous target and Bayes selection. -/
theorem bounded_action_positive_excess {d : ℕ} {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    [IsProbabilityMeasure μ] (X : Ω → Features d) (Y : Ω → Probability)
    (hX : Measurable X) (hY : Measurable Y) (L R : ℝ≥0) (hR : 0 < R)
    (hL : ∀ᵐ ω ∂μ, ‖X ω‖ ≤ (L : ℝ)) (ε : ℝ) (hε : 0 < ε) :
    ∃ (w : Features d) (ρ : ℝ → Probability), ‖w‖ ≤ (R : ℝ) ∧
      Monotone ρ ∧ Measurable ρ ∧ LipschitzWith (1 / (16 * ε)).toNNReal ρ ∧
      ∀ σ : Target (L * R), ∀ k : Probability → Action (L * R), IsBayes σ k →
        (∫ ω, loss σ (k (ρ (inner ℝ w (X ω)))) (Y ω) ∂μ) ≤
          (⨅ v : {v : Features d // ‖v‖ ≤ (R : ℝ)},
            ∫ ω, loss σ (inner ℝ v.val (X ω)) (Y ω) ∂μ) + ε := by
  obtain ⟨w, ρ, hw, hm, hmeas, hLip, h⟩ :=
    exists_approximate_forecast_with_slope μ X Y hX hY L R hR hL ε hε
  refine ⟨w, ρ, hw, hm, hmeas, hLip, fun σ k hk => ?_⟩
  haveI : Nonempty {v : Features d // ‖v‖ ≤ (R : ℝ)} :=
    ⟨⟨0, by simpa using R.coe_nonneg⟩⟩
  apply sub_le_iff_le_add.mp
  exact le_ciInf (fun v => sub_le_iff_le_add.mpr (h σ k hk v.val v.property))

/-- Compatibility name for the unnumbered positive-excess companion. -/
alias thm_1_1c := bounded_action_positive_excess

end UL.Arxiv

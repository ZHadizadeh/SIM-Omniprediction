import Mathlib.Analysis.InnerProductSpace.GramSchmidtOrtho
import Mathlib.MeasureTheory.Function.SpecialFunctions.Inner
import Mathlib.Tactic

open MeasureTheory InnerProductSpace Set Submodule
namespace UL.Arxiv.SampleBasis

variable {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
  [MeasurableSpace X] [BorelSpace X] [SecondCountableTopology X] {n : ℕ}

/-- Gram–Schmidt in sample order is Borel even where a residual becomes zero. -/
theorem residual (i : Fin n) : Measurable (fun x : Fin n → X => gramSchmidt ℝ x i) := by
  apply (wellFounded_lt (α := Fin n)).induction i
  intro i ih
  simp_rw [gramSchmidt_def ℝ _ i, starProjection_singleton]
  apply (measurable_pi_apply i).sub
  apply Finset.measurable_fun_sum
  intro j hj
  have hm := ih j (Finset.mem_Iio.mp hj)
  exact (((hm.inner (measurable_pi_apply i)).div (hm.norm.pow_const 2)).smul hm)

/-- The normalized slots, the branch retaining each slot, and all query
coordinates are measurable in the original sample and query. -/
theorem coordinates (i : Fin n) :
    Measurable (fun x : Fin n → X => gramSchmidtNormed ℝ x i) ∧
    MeasurableSet {x : Fin n → X | gramSchmidtNormed ℝ x i ≠ 0} ∧
    Measurable (fun z : (Fin n → X) × X => inner ℝ (gramSchmidtNormed ℝ z.1 i) z.2) := by
  have hm : Measurable (fun x : Fin n → X => gramSchmidtNormed ℝ x i) := by
    exact (residual i).norm.inv.smul (residual i)
  exact ⟨hm,(measurableSet_eq_fun hm measurable_const).compl,(hm.comp measurable_fst).inner measurable_snd⟩

/-- After dropping zero slots the vectors are an orthonormal basis of the sample span. -/
theorem basis (x : Fin n → X) :
    let b := gramSchmidtNormed ℝ x
    Orthonormal ℝ (fun j : {i // b i ≠ 0} => b j) ∧
    Submodule.span ℝ (range (fun j : {i // b i ≠ 0} => b j)) = Submodule.span ℝ (range x) := by
  intro b
  refine ⟨gramSchmidtNormed_orthonormal' x,?_⟩
  calc
    _ = Submodule.span ℝ (range b) := by
      apply le_antisymm
      · exact Submodule.span_mono (by rintro _ ⟨i,rfl⟩; exact ⟨i.val,rfl⟩)
      · apply Submodule.span_le.mpr
        rintro _ ⟨i,rfl⟩
        by_cases h : b i = 0
        · rw [h]; exact Submodule.zero_mem _
        · exact Submodule.subset_span ⟨⟨i,h⟩,rfl⟩
    _ = _ := (span_gramSchmidtNormed_range x).trans (span_gramSchmidt ℝ x)

end UL.Arxiv.SampleBasis

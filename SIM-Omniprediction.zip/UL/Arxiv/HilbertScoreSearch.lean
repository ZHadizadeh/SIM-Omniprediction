import UL.Arxiv.UnroundedSearch
import UL.Proof.thm_C_1.Race3.H1_UniverseTransfer
import UL.Proof.thm_C_1.Race3.H3_SampleBound
import UL.Proof.lem_C_3
import UL.Proof.cit_mcdiarmid1989

open MeasureTheory Set
namespace UL.Arxiv.HilbertSearch
open FiniteLearner GridOracle Proof_lem_C_2

/-- On a measurable event of probability at least 1 − δ the finite score
search on the original sample returns a forecast satisfying the simultaneous
population risk bound. The features may belong to any separable real Hilbert space.
The uniform deviation and fitting budgets each contribute half the final tolerance. -/
theorem population :
  ∀ (K : ℕ) (hK : 2 ≤ K),
    ∃ C_K : ℝ, 0 < C_K ∧
      ∀ (X : Type) [NormedAddCommGroup X] [InnerProductSpace ℝ X]
        [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
        [MeasurableSpace X] [BorelSpace X]
        (L R β lam M B : ℝ)
        (hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) (hlam : 0 < lam) (hM : 0 < M)
        (hB : β ≤ B),
        let m : ℕ := K - 1
        let A : ℝ := L * R
        let D : ℝ := M + A + B * lam * A
        ∀ (ε δ : ℝ) (hε0 : 0 < ε) (hεD : ε ≤ D)
          (hδ0 : 0 < δ) (hδ1 : δ < (1 : ℝ) / 2)
          (n : ℕ) (hn : 1 ≤ n),
          (n : ℝ) ≥
            (if m ≤ 2 then
              C_K * (D / ε) ^ 2 * (Real.log (C_K * D / (ε * δ))) ^ 2
            else
              C_K * ((D / ε) ^ m + (D / ε) ^ 2 * Real.log ((2 : ℝ) / δ))) →
            ∀ (ν : MeasureTheory.Measure (X × Fin K)) [MeasureTheory.IsProbabilityMeasure ν],
              (∀ᵐ xy ∂ν, ‖xy.1‖ ≤ L) →
              ∀ (Ω : Type) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
                [MeasureTheory.IsProbabilityMeasure μ]
                (X_samp : Fin n → Ω → X) (Y_samp : Fin n → Ω → Fin K),
                (∀ i : Fin n, Measurable (X_samp i)) →
                (∀ i : Fin n, Measurable (Y_samp i)) →
                ProbabilityTheory.iIndepFun (fun i ω => (X_samp i ω, Y_samp i ω)) μ →
                (∀ i : Fin n,
                  MeasureTheory.Measure.map (fun ω => (X_samp i ω, Y_samp i ω)) μ = ν) →
                Measurable (fun z : ((Fin n → X) × (Fin n → Fin K)) × X =>
                  UnroundedSearch.boundedForecast hK hn hR (hβ.trans_le hB) L lam (ε/8) z.1.1 z.1.2 z.2) ∧
                ∃ good : Set Ω, MeasurableSet good ∧ (μ good).toReal ≥ 1 - δ ∧
                  ∀ ω ∈ good,
                    let x := fun i => X_samp i ω
                    let y := fun i => Y_samp i ω
                    ∃ (W : X →L[ℝ] H K) (ρ : H K → E K), hilbertSchmidtNorm W ≤ R ∧
                      (∀ z, ρ z ∈ Simplex K) ∧ LipschitzWith B.toNNReal ρ ∧
                      (∀ z, UnroundedSearch.boundedForecast hK hn hR (hβ.trans_le hB) L lam (ε/8) x y z = ρ (W z)) ∧
                      ∀ Φ ∈ SmoothEntropyFamily K β lam M,
                       (∫ xy, finiteCanonicalLoss Φ (ρ (W xy.1)) xy.2 ∂ν) ≤
                        sInf ((fun V : X →L[ℝ] H K =>
                          ∫ xy, matchingLoss Φ (V xy.1 : E K) xy.2 ∂ν) ''
                          {V | hilbertSchmidtNorm V ≤ R}) + ε := by
  intro K hK
  obtain ⟨C₃, hC₃_pos, h_unif⟩ := Proof_thm_C_1_Race3.lem_C_3_transfer.{0,0,0,0} (P_lem_C_3.{0,0} P_cit_mcdiarmid1989.{0,0}) K hK
  refine ⟨Proof_thm_C_1_Race3.sampleConstCK K (2*C₃),
    Proof_thm_C_1_Race3.sampleConstCK_pos K (2*C₃), ?_⟩
  intro X _instNACG _instIPS _instCS _instSep _instMS _instBS
    L R β lam M B hL hR hβ hlam hM hB
  dsimp only
  intro ε δ hε0 hεD hδ0 hδ1 n hn hn_ge
  intro ν _instProbν hX_bound Ω _instMSΩ μ _instProbμ X_samp Y_samp hX_meas hY_meas hindep hident
  have hB_pos : 0 < B := lt_of_lt_of_le hβ hB
  let A : ℝ := L * R
  have hA_pos : 0 < A := mul_pos hL hR
  let C : ℝ := 3 * B * lam
  let M₀ : ℝ := 3 * (M + A)
  have hC_pos : 0 < C := by dsimp [C]; positivity
  have hM₀_pos : 0 < M₀ := by dsimp [M₀]; positivity
  have hδ_lt_one : δ < 1 := by linarith
  obtain ⟨E, hE_meas, hE_prob, hE_good⟩ :=
    h_unif X L R C M₀ hL hR hC_pos hM₀_pos n hn δ hδ0 hδ_lt_one
      ν hX_bound Ω μ X_samp Y_samp hX_meas hY_meas hindep hident
  have h2bound_le :
      2 *
        (if K - 1 ≤ 2 then
          C₃ * ((M₀ + C * A) * Real.log (2 * (n : ℝ)) + M₀ * Real.sqrt (Real.log (2 / δ))) /
            Real.sqrt (n : ℝ)
        else
          C₃ * (M₀ + C * A) * ((n : ℝ) ^ (-(1 : ℝ) / ((K - 1 : ℕ) : ℝ))) +
            C₃ * M₀ * Real.sqrt (Real.log (2 / δ) / (n : ℝ))) ≤ ε/2 := by
    have hu := Proof_thm_C_1_Race3.sample_bound_implies_two_bound_le K hK (2*C₃) (by positivity)
      M A B lam ε δ hM hA_pos hB_pos hlam hε0 hεD hδ0 hδ1 n hn hn_ge
    change 2 * (if K-1 ≤ 2 then
        (2*C₃)*((M₀+C*A)*Real.log (2*(n:ℝ))+M₀*Real.sqrt (Real.log (2/δ)))/Real.sqrt (n:ℝ)
      else (2*C₃)*(M₀+C*A)*((n:ℝ)^(-(1:ℝ)/((K-1:ℕ):ℝ)))+
        (2*C₃)*M₀*Real.sqrt (Real.log (2/δ)/(n:ℝ))) ≤ ε at hu
    split <;> rename_i branch
    · rw [if_pos branch] at hu
      apply (le_div_iff₀ (by norm_num : (0:ℝ)<2)).mpr
      convert hu using 1 <;> ring
    · rw [if_neg branch] at hu
      apply (le_div_iff₀ (by norm_num : (0:ℝ)<2)).mpr
      convert hu using 1 <;> ring
  refine ⟨UnroundedSearch.bounded_joint hK hn hL hR hβ hB hlam (by positivity),?_⟩
  refine ⟨E, hE_meas, hE_prob, ?_⟩
  intro ω hω
  let x (i : Fin n) := X_samp i ω
  let y (i : Fin n) := Y_samp i ω
  obtain ⟨hx_norm, h_sup⟩ := hE_good ω hω
  obtain ⟨W,ρ,hW_norm,hρ_simp,hρ_lip,exactForecast,emp⟩ :=
    UnroundedSearch.empirical hK hn x y hL hx_norm hR hβ hB hlam (show 0 < ε/8 by positivity)
  have hc : (fun i => Proof_thm_5_1.clampBall L (x i)) = x :=
    funext fun i => Proof_thm_5_1.clampBall_eq_self hL (hx_norm i)
  refine ⟨W,ρ,hW_norm,hρ_simp,hρ_lip,?_,?_⟩
  · intro z
    change UnroundedSearch.forecast hK hn hR (hβ.trans_le hB) L lam (ε/8)
      (fun i => Proof_thm_5_1.clampBall L (x i)) y z = ρ (W z)
    rw [hc]
    exact exactForecast z
  intro Φ hΦ
  set bound : ℝ :=
    if K - 1 ≤ 2 then
      C₃ * ((M₀ + C * A) * Real.log (2 * (n : ℝ)) + M₀ * Real.sqrt (Real.log (2 / δ))) /
        Real.sqrt (n : ℝ)
    else
      C₃ * (M₀ + C * A) * ((n : ℝ) ^ (-(1 : ℝ) / ((K - 1 : ℕ) : ℝ))) +
        C₃ * M₀ * Real.sqrt (Real.log (2 / δ) / (n : ℝ))
  change sSup ((fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
    |(∫ xy, Proof_thm_C_1_Race3.evalBallProfile L f xy.1 xy.2 ∂ν) -
      ((1 : ℝ) / (n : ℝ)) *
        ∑ i : Fin n, Proof_thm_C_1_Race3.evalBallProfile L f (X_samp i ω) (Y_samp i ω)|) ''
    ScoreProfileClass X K L R C M₀) ≤ bound at h_sup
  have h_bdd_sup := Proof_thm_C_1_Race3.scoreProfileClass_dev_bddAbove
    (L := L) (R := R) (C := C) (hn := hn) hM₀_pos ν
    (fun i => X_samp i ω) (fun i => Y_samp i ω)
  suffices h_le_sInf :
      (∫ xy, finiteCanonicalLoss Φ (ρ (W xy.1)) xy.2 ∂ν) - ε ≤
        sInf ((fun V : X →L[ℝ] ZeroSumSubspace K =>
          ∫ xy, matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 ∂ν) ''
          {V | hilbertSchmidtNorm V ≤ R}) by
    linarith
  refine le_csInf
    ⟨_, ⟨0, by change hilbertSchmidtNorm 0 ≤ R; rw [Proof_lem_C_2.hilbertSchmidtNorm_zero]; exact hR.le, rfl⟩⟩ ?_
  rintro _ ⟨V, hV, rfl⟩
  change hilbertSchmidtNorm V ≤ R at hV
  let f_learn : Metric.closedBall (0 : X) L × Fin K → ℝ :=
    fun xy => finiteCanonicalLoss Φ (ρ (W xy.1.1)) xy.2 - matchingPotential Φ 0
  have hf_learn : f_learn ∈ ScoreProfileClass X K L R C M₀ :=
    Proof_thm_C_1_Race3.learnerProfile_mem_scoreProfileClass hK hL hR hβ hB hΦ
      hW_norm hρ_simp hρ_lip
  have hdev_learn :
      |(∫ xy, Proof_thm_C_1_Race3.evalBallProfile L f_learn xy.1 xy.2 ∂ν) -
        ((1 : ℝ) / (n : ℝ)) *
          ∑ i : Fin n, Proof_thm_C_1_Race3.evalBallProfile L f_learn
            (X_samp i ω) (Y_samp i ω)| ≤ bound :=
    (le_csSup h_bdd_sup ⟨f_learn, hf_learn, rfl⟩).trans h_sup
  have heq_learn :
      (∫ xy, Proof_thm_C_1_Race3.evalBallProfile L f_learn xy.1 xy.2 ∂ν) -
        ((1 : ℝ) / (n : ℝ)) *
          ∑ i : Fin n, Proof_thm_C_1_Race3.evalBallProfile L f_learn
            (X_samp i ω) (Y_samp i ω) =
      (∫ xy, finiteCanonicalLoss Φ (ρ (W xy.1)) xy.2 ∂ν) -
        ((1 : ℝ) / (n : ℝ)) *
          ∑ i : Fin n, finiteCanonicalLoss Φ (ρ (W (X_samp i ω))) (Y_samp i ω) :=
    Proof_thm_C_1_Race3.evalBallProfile_dev_learner_eq hK hn hL hR hβ hB
      hΦ hW_norm hρ_simp hρ_lip ν hX_bound
      (fun i => X_samp i ω) (fun i => Y_samp i ω) hx_norm
  rw [heq_learn] at hdev_learn
  have h_fore_step :
      (∫ xy, finiteCanonicalLoss Φ (ρ (W xy.1)) xy.2 ∂ν) ≤
        ((1 : ℝ) / (n : ℝ)) *
          (∑ i : Fin n, finiteCanonicalLoss Φ (ρ (W (X_samp i ω))) (Y_samp i ω)) + bound := by
    linarith [(abs_le.mp hdev_learn).2]
  have h_emp_step :
      (1/(n:ℝ))*∑ i, finiteCanonicalLoss Φ (ρ (W (X_samp i ω))) (Y_samp i ω) ≤
       (1/(n:ℝ))*∑ i, matchingLoss Φ ((V (X_samp i ω) : H K) : GridOracle.E K) (Y_samp i ω) + 4*(ε/8) :=
    emp Φ hΦ V hV
  let f_comp : Metric.closedBall (0 : X) L × Fin K → ℝ :=
    fun xy => matchingLoss Φ (V xy.1.1 : EuclideanSpace ℝ (Fin K)) xy.2 - matchingPotential Φ 0
  have hf_comp : f_comp ∈ ScoreProfileClass X K L R C M₀ :=
    Proof_thm_C_1_Race3.compProfile_mem_scoreProfileClass hK hL hR hβ hB hΦ hV
  have hdev_comp :
      |(∫ xy, Proof_thm_C_1_Race3.evalBallProfile L f_comp xy.1 xy.2 ∂ν) -
        ((1 : ℝ) / (n : ℝ)) *
          ∑ i : Fin n, Proof_thm_C_1_Race3.evalBallProfile L f_comp
            (X_samp i ω) (Y_samp i ω)| ≤ bound :=
    (le_csSup h_bdd_sup ⟨f_comp, hf_comp, rfl⟩).trans h_sup
  have heq_comp :
      (∫ xy, Proof_thm_C_1_Race3.evalBallProfile L f_comp xy.1 xy.2 ∂ν) -
        ((1 : ℝ) / (n : ℝ)) *
          ∑ i : Fin n, Proof_thm_C_1_Race3.evalBallProfile L f_comp
            (X_samp i ω) (Y_samp i ω) =
      (∫ xy, matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 ∂ν) -
        ((1 : ℝ) / (n : ℝ)) *
          ∑ i : Fin n, matchingLoss Φ
            (V (X_samp i ω) : EuclideanSpace ℝ (Fin K)) (Y_samp i ω) :=
    Proof_thm_C_1_Race3.evalBallProfile_dev_comp_eq hK hn hL hR
      hΦ hV ν hX_bound (fun i => X_samp i ω) (fun i => Y_samp i ω) hx_norm
  rw [heq_comp] at hdev_comp
  have h_comp_step :
      ((1 : ℝ) / (n : ℝ)) *
          (∑ i : Fin n, matchingLoss Φ
            ((V (X_samp i ω) : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) (Y_samp i ω)) ≤
        (∫ xy, matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 ∂ν) + bound := by
    linarith [(abs_le.mp hdev_comp).1]
  linarith

end UL.Arxiv.HilbertSearch

import UL.Arxiv.Geometry
import Mathlib.MeasureTheory.Function.ConvergenceInMeasure
/-! # Recovering a deterministic monotone link at zero gap

The proof takes subsequences of the challenging targets and linear competitors.
At an interior comparator action, every cluster point of the fitted probabilities
must equal the limiting target link. At the two extreme scores we also take
subsequences of the predictions at the only two possible feature preimages.
-/
open Set Filter Topology MeasureTheory
open scoped NNReal
namespace UL.Arxiv.BoundedBinary
noncomputable section

variable {A : ℝ≥0}

/-- If the excess at the reported probability tends to zero, the limit comparator
minimizes expected loss under the limiting report. No continuity of the Bayes selectors
is necessary, since the comparison can be made against each fixed action. -/
theorem limit_minimizes {σn : ℕ → Target A} {σ : Target A} {tn : ℕ → Action A} {t : Action A}
    {pn : ℕ → Probability} {q : Probability} {kn : ℕ → Probability → Action A}
    (hk : ∀ n, IsBayes (σn n) (kn n)) (hs : Tendsto σn atTop (𝓝 σ))
    (ht : Tendsto tn atTop (𝓝 t)) (hp : Tendsto pn atTop (𝓝 q))
    (hgap : Tendsto (fun n => loss (σn n) (tn n) (pn n) - loss (σn n) (kn n (pn n)) (pn n))
      atTop (𝓝 0)) :
    ∀ b : Action A, loss σ t q ≤ loss σ b q := by
  intro b
  have hpc := continuous_subtype_val.continuousAt.tendsto.comp hp
  have htc := continuous_subtype_val.continuousAt.tendsto.comp ht
  have h₁ := tendsto_loss hs htc hpc
  have h₂ := (tendsto_loss hs (tendsto_const_nhds (x := (b : ℝ))) hpc).add hgap
  simpa only [add_zero] using le_of_tendsto_of_tendsto' h₁ h₂
    (fun n => by have h := hk n (pn n) b; dsimp; linarith)

theorem recover_at_feature {d : ℕ} {L R : ℝ≥0} (hL : 0 < L) (hR : 0 < R)
    {v x : Features d} (hv : ‖v‖ ≤ (R : ℝ)) (hx : ‖x‖ ≤ (L : ℝ))
    {σ : Target (L * R)} {F : ℕ → Features d → Probability} {lo hi : Probability}
    (hlo : Tendsto (fun n => F n (((R : ℝ)⁻¹ * L) • (-v))) atTop (𝓝 lo))
    (hhi : Tendsto (fun n => F n (((R : ℝ)⁻¹ * L) • v)) atTop (𝓝 hi))
    (hopt : ∀ (i : ℕ → ℕ), Tendsto i atTop atTop → ∀ q : Probability,
      Tendsto (fun n => F (i n) x) atTop (𝓝 q) →
      ∀ b : Action (L * R), loss σ (clip (L*R) (inner ℝ v x)) q ≤ loss σ b q) :
    Tendsto (fun n => F n x) atTop (𝓝 (limitLink σ lo hi (inner ℝ v x))) := by
  let A := L * R
  let a := inner ℝ v x
  let t := clip A a
  have ha : a ∈ Action A := score_mem hv hx
  have htv : (t : ℝ) = a := by simp [t, clip, Set.projIcc_of_mem _ ha]
  have hA : (0 : ℝ) < A := mul_pos hL hR
  let left : Action A := ⟨-A, by exact left_mem_Icc.mpr (neg_le_self A.coe_nonneg)⟩
  let right : Action A := ⟨A, by exact right_mem_Icc.mpr (neg_le_self A.coe_nonneg)⟩
  apply Filter.tendsto_of_subseq_tendsto
  intro i h_i
  obtain ⟨q, _, j, h_j, hq⟩ := isCompact_univ.tendsto_subseq (x := fun n => F (i n) x) (fun _ => trivial)
  refine ⟨j, ?_⟩
  have hmin := hopt (i ∘ j) (h_i.comp h_j.tendsto_atTop) q hq
  have hleft := optimal_slope_sign hmin left
  have hright := optimal_slope_sign hmin right
  change 0 ≤ (-(A : ℝ) - ↑t) * ((σ t : ℝ) - q) at hleft
  change 0 ≤ ((A : ℝ) - ↑t) * ((σ t : ℝ) - q) at hright
  rw [htv] at hleft hright
  suffices eq : limitLink σ lo hi a = q by
    change Tendsto (fun n => F (i (j n)) x) atTop (𝓝 (limitLink σ lo hi a))
    rw [eq]
    exact hq
  unfold limitLink
  by_cases hl : a ≤ -(A : ℝ)
  · rw [if_pos hl]
    have he := le_antisymm hl ha.1
    have hfeat := feature_at_left hR hL hv hx he
    have heq : q = lo := tendsto_nhds_unique hq (by rw [hfeat]; exact hlo.comp (h_i.comp h_j.tendsto_atTop))
    rw [heq]
    apply min_eq_left
    change (lo : ℝ) ≤ σ t
    rw [← heq]
    rw [he] at hright
    linarith [nonneg_of_mul_nonneg_right hright (show 0 < (A:ℝ) - -A by linarith)]
  · rw [if_neg hl]
    by_cases hr : (A : ℝ) ≤ a
    · rw [if_pos hr]
      have he := le_antisymm ha.2 hr
      have hfeat := feature_at_right hR hL hv hx he
      have heq : q = hi := tendsto_nhds_unique hq (by rw [hfeat]; exact hhi.comp (h_i.comp h_j.tendsto_atTop))
      rw [heq]
      apply max_eq_left
      change (σ t : ℝ) ≤ hi
      rw [← heq]
      rw [he] at hleft
      linarith [nonpos_of_mul_nonneg_right hleft (show -(A:ℝ) - A < 0 by linarith)]
    · rw [if_neg hr]
      apply Subtype.ext
      change (σ t : ℝ) = q
      apply le_antisymm
      · have := nonpos_of_mul_nonneg_right hleft (sub_neg.mpr (lt_of_not_ge hl))
        linarith
      · have := nonneg_of_mul_nonneg_right hright (sub_pos.mpr (lt_of_not_ge hr))
        linarith

end
end UL.Arxiv.BoundedBinary

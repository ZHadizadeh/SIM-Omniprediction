import UL.Arxiv.SampleBasis
import UL.Proof.lem_C_2.H1_HilbertSchmidt

open Set InnerProductSpace MeasureTheory Submodule
namespace UL.Arxiv.OrderedCoordinates
open Proof_lem_C_2

variable {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [MeasurableSpace X] [BorelSpace X] [SecondCountableTopology X] {n : ℕ}

scoped instance (n : ℕ) : MeasurableSpace (Finset (Fin n)) := ⊤
scoped instance (n : ℕ) : DiscreteMeasurableSpace (Finset (Fin n)) := ⟨fun _ => trivial⟩

open Classical in
noncomputable def active (x : Fin n → X) : Finset (Fin n) :=
  Finset.univ.filter fun i => gramSchmidtNormed ℝ x i ≠ 0

theorem active_measurable : Measurable (active (X:=X) (n:=n)) := by
  classical
  apply measurable_to_countable'
  intro J
  have eq : (active (X:=X)) ⁻¹' {J} = {x : Fin n → X | ∀ i, gramSchmidtNormed ℝ x i ≠ 0 ↔ i ∈ J} := by
    ext x
    simp [active,Finset.ext_iff]
  rw [eq]
  exact (Measurable.forall fun i => ((SampleBasis.coordinates (X:=X) i).2.1.mem.iff measurable_const)).setOf

/-- Keep the coordinates with nonzero residual, in their original sample order. -/
noncomputable def coords (J : Finset (Fin n)) (x : Fin n → X) (z : X) : EuclideanSpace ℝ J :=
  WithLp.toLp 2 fun i => inner ℝ (gramSchmidtNormed ℝ x i.val) z

theorem coords_measurable (J : Finset (Fin n)) :
    Measurable (fun t : (Fin n → X) × X => coords J t.1 t.2) :=
  (PiLp.continuous_toLp 2 _).measurable.comp (measurable_pi_lambda _ fun i =>
    (SampleBasis.coordinates (X:=X) i.val).2.2)

/-- On a fixed pattern, coordinates map the entire sample span isometrically
onto the full coordinate space. Encoding a query is a contraction; decoding
a training point recovers its original value. -/
theorem chart {J : Finset (Fin n)} (x : Fin n → X) (hx : active x = J) :
    ∃ (A : X →L[ℝ] EuclideanSpace ℝ J) (D : EuclideanSpace ℝ J →L[ℝ] X),
      (∀ z, A z = coords J x z) ∧ ‖A‖ ≤ 1 ∧ ‖D‖ ≤ 1 ∧
      (∀ i, D (A (x i)) = x i) ∧ sampleSpan (fun i => A (x i)) = ⊤ := by
  classical
  let b := gramSchmidtNormed ℝ x
  have act i : i ∈ J ↔ b i ≠ 0 := by rw [← hx]; simp [active,b]
  let v := fun j : J => b j.val
  have spanV : span ℝ (range v) = sampleSpan x := by
    change span ℝ (range v) = span ℝ (range x)
    rw [← (SampleBasis.basis x).2]
    congr 1
    ext z
    constructor
    · rintro ⟨i,rfl⟩; exact ⟨⟨i.val,(act _).mp i.2⟩,rfl⟩
    · rintro ⟨i,rfl⟩; exact ⟨⟨i.val,(act _).mpr i.2⟩,rfl⟩
  have vm j : v j ∈ sampleSpan x := spanV ▸ subset_span (mem_range_self j)
  let v' := fun j => (⟨v j,vm j⟩ : sampleSpan x)
  have vo : Orthonormal ℝ v := (SampleBasis.basis x).1.comp
    (fun j : J => (⟨j.val,(act _).mp j.property⟩ : {i // b i ≠ 0}))
    (fun _ _ he => Subtype.ext (congrArg (fun q : {i // b i ≠ 0} => q.val) he))
  have vo' : Orthonormal ℝ v' := ((sampleSpan x).subtypeₗᵢ.orthonormal_comp_iff).mp vo
  have vs : span ℝ (range v') = ⊤ := (span_range_subtype_eq_top_iff _ vm).mpr spanV
  let B := OrthonormalBasis.mk vo' vs.ge
  have basis_eq (j : J) : B j = v' j := congrFun (OrthonormalBasis.coe_mk vo' vs.ge) j
  let P := sampleSpan x
  let A := B.repr.toLinearIsometry.toContinuousLinearMap.comp P.orthogonalProjection
  let D := P.subtypeL.comp B.repr.symm.toLinearIsometry.toContinuousLinearMap
  have spec z : A z = coords J x z := by
    ext j
    change B.repr (P.orthogonalProjection z) j = _
    rw [OrthonormalBasis.repr_apply_apply,basis_eq,inner_orthogonalProjection_eq_of_mem_left]
    rfl
  have as (i : Fin n) : A (x i) = B.repr ⟨x i,subset_span (mem_range_self i)⟩ := by
    exact congrArg B.repr (P.orthogonalProjection_mem_subspace_eq_self ⟨x i,subset_span (mem_range_self i)⟩)
  refine ⟨A,D,spec,?_,?_,?_,?_⟩
  · apply ContinuousLinearMap.opNorm_le_bound _ zero_le_one
    intro z; change ‖B.repr (P.orthogonalProjection z)‖ ≤ 1*‖z‖
    rw [B.repr.norm_map,one_mul]; exact P.norm_orthogonalProjection_apply_le z
  · apply ContinuousLinearMap.opNorm_le_bound _ zero_le_one
    intro z; change ‖((B.repr.symm z : P) : X)‖ ≤ 1*‖z‖
    rw [Submodule.norm_coe,B.repr.symm.norm_map,one_mul]
  · intro i; rw [as]; simp [D,P]
  · let xs := fun i => (⟨x i,subset_span (mem_range_self i)⟩ : sampleSpan x)
    have top : span ℝ (range xs) = ⊤ := (span_range_subtype_eq_top_iff _ _).mpr rfl
    change span ℝ (range fun i => A (x i)) = ⊤
    simp_rw [as]
    change span ℝ (range (B.repr.toLinearEquiv.toLinearMap ∘ xs)) = ⊤
    rw [Set.range_comp,← Submodule.map_span,top,Submodule.map_top,LinearEquiv.range]

/-- Precomposing a classifier with a contraction preserves its Hilbert–Schmidt budget. -/
theorem hs_contraction {F G Y : Type*}
    [NormedAddCommGroup F] [InnerProductSpace ℝ F] [CompleteSpace F]
    [NormedAddCommGroup G] [InnerProductSpace ℝ G] [CompleteSpace G]
    [NormedAddCommGroup Y] [InnerProductSpace ℝ Y] [FiniteDimensional ℝ Y]
    (A : F →L[ℝ] G) (V : G →L[ℝ] Y) (ha : ‖A‖ ≤ 1) :
    hilbertSchmidtNorm (V.comp A) ≤ hilbertSchmidtNorm V := by
  have id y : adjVec (V.comp A) y = (ContinuousLinearMap.adjoint A) (adjVec V y) := by
    apply ext_inner_right ℝ
    intro x; rw [inner_adjVec_left,ContinuousLinearMap.adjoint_inner_left,inner_adjVec_left]; rfl
  rw [hilbertSchmidtNorm_eq_sqrt,hilbertSchmidtNorm_eq_sqrt]
  apply Real.sqrt_le_sqrt
  apply Finset.sum_le_sum
  intro j _
  rw [id]
  apply pow_le_pow_left₀ (norm_nonneg _) _ 2
  exact ((ContinuousLinearMap.adjoint A).le_opNorm _).trans (by
    rw [ContinuousLinearMap.adjoint.norm_map]
    simpa using mul_le_mul_of_nonneg_right ha (norm_nonneg (adjVec V _)))

end UL.Arxiv.OrderedCoordinates

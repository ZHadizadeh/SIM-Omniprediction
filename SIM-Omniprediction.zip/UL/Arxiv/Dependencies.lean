import UL.Proof.cit_brouwer
import UL.Proof.cit_mcdiarmid1989
import UL.Proof.lem_A_1
import UL.Proof.lem_A_2
import UL.Proof.lem_A_3
import UL.Proof.lem_A_4
import UL.Proof.lem_A_5
import UL.Proof.lem_A_6
import UL.Proof.thm_A_7
import UL.Proof.thm_3_1
import UL.Proof.cor_A_8
import UL.Proof.thm_A_9
import UL.Proof.thm_4_1
import UL.Proof.thm_3_2
import UL.Proof.lem_C_4
import UL.Proof.lem_C_2
import UL.Proof.lem_C_3
import UL.Proof.thm_C_1
import UL.Proof.thm_5_1
import UL.Proof.prop_C_5
import UL.Proof.cor_C_6
import UL.Proof.cor_C_7
import UL.Proof.thm_E_1
import UL.Proof.thm_7_1

/-! Proof dependencies for the arXiv theorem index. -/
set_option autoImplicit false

namespace UL

theorem T_cit_brouwer : S_cit_brouwer := P_cit_brouwer
theorem T_cit_mcdiarmid1989 : S_cit_mcdiarmid1989 := P_cit_mcdiarmid1989
theorem T_lem_A_1 : S_lem_A_1 := P_lem_A_1
theorem T_lem_A_2 : S_lem_A_2 := P_lem_A_2
theorem T_lem_A_3 : S_lem_A_3 := P_lem_A_3 T_lem_A_2.{0}
theorem T_lem_A_4 : S_lem_A_4 := P_lem_A_4 T_lem_A_3.{0}
theorem T_lem_A_5 : S_lem_A_5 := P_lem_A_5 T_lem_A_3.{0} T_lem_A_4.{0}
theorem T_lem_A_6 : S_lem_A_6 := P_lem_A_6 T_lem_A_1 T_lem_A_3.{0} T_lem_A_4.{0} T_lem_A_5.{0}
theorem T_thm_A_7 : S_thm_A_7 := P_thm_A_7 T_cit_brouwer.{0} T_lem_A_2.{0} T_lem_A_3.{0} T_lem_A_6.{0}
theorem T_thm_3_1 : S_thm_3_1 := P_thm_3_1 T_thm_A_7.{0}
theorem T_cor_A_8 : S_cor_A_8 := P_cor_A_8 T_cit_brouwer.{0} T_lem_A_1 T_lem_A_2.{0} T_lem_A_3.{0} T_lem_A_4.{0} T_lem_A_5.{0} T_lem_A_6.{0} T_thm_A_7.{0}
theorem T_thm_A_9 : S_thm_A_9 := P_thm_A_9
theorem T_thm_4_1 : S_thm_4_1 := P_thm_4_1 T_thm_A_9
theorem T_thm_3_2 : S_thm_3_2 := P_thm_3_2 T_cit_brouwer.{0}
theorem T_lem_C_4 : S_lem_C_4 := P_lem_C_4
theorem T_lem_C_2 : S_lem_C_2 := P_lem_C_2 T_cit_brouwer.{0} T_lem_C_4
theorem T_lem_C_3 : S_lem_C_3 := P_lem_C_3 T_cit_mcdiarmid1989.{0, 0}
theorem T_thm_C_1 : S_thm_C_1 := P_thm_C_1 T_lem_C_2.{0} T_lem_C_3.{0, 0} T_lem_C_4
theorem T_thm_5_1 : S_thm_5_1 := P_thm_5_1 T_thm_C_1.{0, 0} T_lem_C_3.{0, 0}
theorem T_prop_C_5 : S_prop_C_5 := P_prop_C_5
theorem T_cor_C_6 : S_cor_C_6 := P_cor_C_6 T_cit_brouwer.{0} T_lem_C_3.{0, 0}
theorem T_cor_C_7 : S_cor_C_7 := P_cor_C_7 T_lem_C_2.{0} T_lem_C_3.{0, 0} T_lem_C_4
theorem T_thm_E_1 : S_thm_E_1 := P_thm_E_1
theorem T_thm_7_1 : S_thm_7_1 := P_thm_7_1 T_cit_mcdiarmid1989.{0, 0}

end UL

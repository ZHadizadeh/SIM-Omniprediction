import Mathlib.Analysis.SpecialFunctions.Sigmoid
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Tactic

namespace UL.Arxiv.Logistic

open Real Set

theorem sigmoid_slope_upper {a b : ℝ} (hab : a ≤ b) :
    sigmoid b - sigmoid a ≤ (1/4 : ℝ) * (b-a) := by
  apply image_sub_le_mul_sub_of_deriv_le differentiable_sigmoid _ hab
  intro x
  rw [deriv_sigmoid]
  nlinarith [sq_nonneg (sigmoid x - 1/2)]

theorem derivative_lower {x : ℝ} (hx : |x| ≤ 1/4) : 1/5 ≤ deriv sigmoid x := by
  obtain ⟨hx₁,hx₂⟩ := abs_le.mp hx
  have hlo := sigmoid_monotone hx₁
  have hhi := sigmoid_monotone hx₂
  have hleft := sigmoid_slope_upper (show -(1/4 : ℝ) ≤ 0 by norm_num)
  have hright := sigmoid_slope_upper (show (0 : ℝ) ≤ 1/4 by norm_num)
  rw [sigmoid_zero] at hleft hright
  rw [deriv_sigmoid]
  have hprod := mul_nonneg (show 0 ≤ sigmoid x - 7/16 by linarith)
    (show 0 ≤ 9/16 - sigmoid x by linarith)
  nlinarith

theorem sigmoid_slope_lower {a b : ℝ} (ha : a ∈ Icc (-(1/4 : ℝ)) (1/4))
    (hb : b ∈ Icc (-(1/4 : ℝ)) (1/4)) (hab : a ≤ b) :
    (1/5 : ℝ) * (b-a) ≤ sigmoid b - sigmoid a := by
  apply (convex_Icc _ _).mul_sub_le_image_sub_of_le_deriv continuous_sigmoid.continuousOn
    differentiable_sigmoid.differentiableOn _ a ha b hb hab
  exact fun x hx => derivative_lower (abs_le.mpr (interior_subset (s := Icc (-(1/4 : ℝ)) (1/4)) hx))

noncomputable def partition (z : ℝ) := log (1+exp z)

theorem partition_deriv (z : ℝ) : HasDerivAt partition (sigmoid z) z := by
  have hn : 1 + exp z ≠ 0 := by positivity
  have h := ((Real.hasDerivAt_exp z).const_add 1).log hn
  convert h using 1
  rw [sigmoid_def,exp_neg]
  field_simp [Real.exp_ne_zero z, hn] <;> ring

/-- The Bernoulli log-partition gap between two logits is bounded by 1/8
of their squared difference, uniformly over the two real logits. -/
theorem partition_gap (a b : ℝ) :
    partition b - partition a - sigmoid a * (b-a) ≤ (b-a)^2/8 := by
  let f := fun z => partition z - partition a - sigmoid a * (z-a) - (z-a)^2/8
  have hf (z : ℝ) : HasDerivAt f (sigmoid z - sigmoid a - (z-a)/4) z := by
    have hd := (hasDerivAt_id z).sub_const a
    convert (((partition_deriv z).sub_const (partition a)).sub
      (hd.const_mul (sigmoid a))).sub ((hd.pow 2).div_const 8) using 1 <;> simp only [id_eq] <;> ring
  have hfd : Differentiable ℝ f := fun z => (hf z).differentiableAt
  have hmax : f b ≤ f a := by
    rcases le_total a b with hab | hba
    · apply antitoneOn_of_deriv_nonpos (convex_Ici a) hfd.continuous.continuousOn
        hfd.differentiableOn _ (self_mem_Ici) hab hab
      intro z hz
      rw [(hf z).deriv]
      have := sigmoid_slope_upper (show a ≤ z from interior_subset (s := Ici a) hz)
      linarith
    · apply monotoneOn_of_deriv_nonneg (convex_Iic a) hfd.continuous.continuousOn
        hfd.differentiableOn _ hba (self_mem_Iic) hba
      intro z hz
      rw [(hf z).deriv]
      have := sigmoid_slope_upper (show z ≤ a from interior_subset (s := Iic a) hz)
      linarith
  dsimp [f] at hmax
  linarith

end UL.Arxiv.Logistic

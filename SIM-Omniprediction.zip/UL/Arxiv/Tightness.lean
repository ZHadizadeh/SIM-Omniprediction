import UL.Arxiv.Approximation
import Mathlib.MeasureTheory.Function.ConvergenceInMeasure

/-! # Extracting a subsequence whose Bayes gaps vanish almost surely

A competitor beating an approximate fit under the true labels must itself be
approximately optimal under the reported probabilities. This follows from the
two residual bounds and the fact that matching loss is affine in the label. -/
open Set Filter Topology MeasureTheory
open scoped NNReal
namespace UL.Arxiv.BoundedBinary
noncomputable section

variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
variable {A : ℝ≥0}

omit [IsProbabilityMeasure μ] in
/-- Bounded monotone selections can be tested on the whole real line by clipping
the argument into the probability interval. -/
theorem selector_test {P Y : Ω → Probability} {σ : Target A} {k : Probability → Action A}
    (hk : IsBayes σ k)
    (ht : ∀ f : ℝ → ℝ, Monotone f → ∀ C : ℝ, (∀ x, |f x| ≤ C) →
      (∫ ω, ((P ω : ℝ) - Y ω) * f (P ω) ∂μ) ≤ 0) :
    (∫ ω, ((P ω : ℝ) - Y ω) * (k (P ω) : ℝ) ∂μ) ≤ 0 := by
  let f (x : ℝ) := (k (Set.projIcc 0 1 zero_le_one x) : ℝ)
  have hf : Monotone f := fun _ _ h => hk.monotone (Set.monotone_projIcc _ h)
  simpa only [f, Set.projIcc_val] using ht f hf A (fun x => abs_le.mpr (k _).2)

/-- At a challenger with strictly smaller true risk, the mean Bayes gap at the fit
is bounded by the allowance in its comparator moment. -/
theorem integral_gap_le {σ : Target A} {k : Probability → Action A} (hk : IsBayes σ k)
    {P Y : Ω → Probability} {t : Ω → Action A} (hP : Measurable P)
    (hY : Measurable Y) (ht : Measurable t) {ε : ℝ}
    (hreport : (∫ ω, ((P ω : ℝ) - Y ω) * (k (P ω) : ℝ) ∂μ) ≤ 0)
    (hlin : -ε ≤ ∫ ω, ((P ω : ℝ) - Y ω) * (t ω : ℝ) ∂μ)
    (hbad : (∫ ω, loss σ (t ω) (Y ω) ∂μ) < ∫ ω, loss σ (k (P ω)) (Y ω) ∂μ) :
    (∫ ω, loss σ (t ω) (P ω) - loss σ (k (P ω)) (P ω) ∂μ) ≤ ε := by
  have hm : Measurable (fun ω => k (P ω)) := hk.monotone.measurable.comp hP
  rw [integral_sub (integrable_loss σ ht hP) (integrable_loss σ hm hP)]
  rw [integral_change_label σ ht hY hP, integral_change_label σ hm hY hP] at hbad
  linarith

omit [IsProbabilityMeasure μ] in
theorem subseq_vanishing_gap {g : ℕ → Ω → ℝ} {ε : ℕ → ℝ}
    (hi : ∀ n, Integrable (g n) μ) (hn : ∀ n ω, 0 ≤ g n ω)
    (hb : ∀ n, ∫ ω, g n ω ∂μ ≤ ε n) (he : Tendsto ε atTop (𝓝 0)) :
    ∃ i : ℕ → ℕ, StrictMono i ∧ ∀ᵐ ω ∂μ, Tendsto (fun n => g (i n) ω) atTop (𝓝 0) := by
  have hg : Tendsto (fun n => ∫ ω, g n ω ∂μ) atTop (𝓝 0) :=
    tendsto_of_tendsto_of_tendsto_of_le_of_le tendsto_const_nhds he
      (fun n => integral_nonneg (hn n)) hb
  have hid (n : ℕ) : eLpNorm (g n) 1 μ = ENNReal.ofReal (∫ ω, g n ω ∂μ) := by
    rw [eLpNorm_one_eq_lintegral_enorm, ofReal_integral_eq_lintegral_ofReal (hi n)
      (Eventually.of_forall (hn n))]
    exact lintegral_congr (fun ω => Real.enorm_of_nonneg (hn n ω))
  have hnorm : Tendsto (fun n => eLpNorm (g n - 0) 1 μ) atTop (𝓝 0) := by
    simpa only [sub_zero, hid, ENNReal.ofReal_zero, Function.comp_def] using
      ENNReal.continuous_ofReal.continuousAt.tendsto.comp hg
  exact (tendstoInMeasure_of_tendsto_eLpNorm one_ne_zero
    (fun n => (hi n).aestronglyMeasurable) aestronglyMeasurable_zero hnorm).exists_seq_tendsto_ae

end
end UL.Arxiv.BoundedBinary

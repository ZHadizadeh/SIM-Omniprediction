import UL.Proof.lem_A_5.H1_Simplex
import Mathlib.Analysis.SpecialFunctions.Log.Basic

open MeasureTheory
namespace UL.Arxiv

/-- For a supported label, mixing with the uniform report increases its log loss
by at most the sharp multiplicative-smoothing penalty. -/
theorem logSmoothingPointwise {K : ℕ} {T δ p : ℝ} (hT : 0 ≤ T)
    (hδ : 0 < δ) (hδ' : δ < 1) (hp : 0 < p) :
    -T * Real.log ((1-δ)*p + δ/K) ≤ -T * Real.log p - T * Real.log (1-δ) := by
  have hpos : 0 < (1-δ)*p := mul_pos (sub_pos.mpr hδ') hp
  have h := Real.log_le_log hpos (le_add_of_nonneg_right (div_nonneg hδ.le (Nat.cast_nonneg K)))
  rw [Real.log_mul (sub_pos.mpr hδ').ne' hp.ne'] at h
  nlinarith [mul_le_mul_of_nonneg_left h hT]

/-- Transfer any integrable population log-risk guarantee to the finite logits
of the smoothed report. The original true-label probability is positive almost surely. -/
theorem logSmoothingRisk {K : ℕ} (hK : 1 ≤ K) {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (p : Ω → ℝ) (hp : Measurable p)
    (hs : ∀ᵐ x ∂μ, 0 < p x ∧ p x ≤ 1) {T δ bench : ℝ} (hT : 0 < T)
    (hδ : 0 < δ) (hδ' : δ < 1) (hint : Integrable (fun x => -T * Real.log (p x)) μ)
    (hr : (∫ x, -T * Real.log (p x) ∂μ) ≤ bench) :
    (∫ x, -T * Real.log ((1-δ)*p x + δ/K) ∂μ) ≤ bench - T * Real.log (1-δ) := by
  have hK' : (1:ℝ) ≤ K := by exact_mod_cast hK
  have hfloor : 0 < δ/(K:ℝ) := div_pos hδ (by linarith)
  let f := fun x => -T * Real.log ((1-δ)*p x + δ/K)
  have hmeas : Measurable f := by dsimp [f]; fun_prop
  have hi : Integrable f μ := (integrable_const (-T * Real.log (δ/K))).mono' hmeas.aestronglyMeasurable (by
    filter_upwards [hs] with x hx
    have h1 : δ/(K:ℝ) ≤ (1-δ)*p x + δ/K := by nlinarith [mul_nonneg (sub_pos.mpr hδ').le hx.1.le]
    have h2 : (1-δ)*p x + δ/K ≤ 1 := by
      have := div_le_self hδ.le hK'
      nlinarith [mul_le_mul_of_nonneg_left hx.2 (sub_pos.mpr hδ').le]
    have h3 := Real.log_nonpos (hfloor.le.trans h1) h2
    have h4 := Real.log_le_log hfloor h1
    dsimp [f]
    rw [abs_of_nonneg (mul_nonneg_of_nonpos_of_nonpos (neg_nonpos.mpr hT.le) h3)]
    exact mul_le_mul_of_nonpos_left h4 (neg_nonpos.mpr hT.le))
  have hcomp := integral_mono_ae hi (hint.sub (integrable_const (T * Real.log (1-δ)))) (by
    filter_upwards [hs] with x hx
    exact logSmoothingPointwise (K:=K) hT.le hδ hδ' hx.1)
  simp only [Pi.sub_apply] at hcomp
  rw [integral_sub hint (integrable_const _), integral_const, probReal_univ, one_smul] at hcomp
  exact hcomp.trans (sub_le_sub_right hr _)

/-- Euclidean norm of the centered temperature-scaled logits at a report
whose coordinates lie in [δ/K,1]. -/
theorem centeredLogitNorm {K : ℕ} (hK : 1 ≤ K) (p : Fin K → ℝ) {δ T : ℝ}
    (hδ : 0 < δ) (hδ' : δ ≤ 1) (hT : 0 ≤ T) (hp : ∀ i, δ/K ≤ p i ∧ p i ≤ 1) :
    let v := fun i => T * Real.log (p i)
    let avg := (∑ i, v i) / K
    ‖(WithLp.toLp 2 (fun i => v i - avg) : EuclideanSpace ℝ (Fin K))‖ ≤
      (T * Real.sqrt K / 2) * Real.log (K / δ) := by
  intro v avg
  have hk : (1:ℝ) ≤ K := by exact_mod_cast hK
  have hkpos : 0 < (K:ℝ) := by linarith
  let b := T * Real.log (K/δ)
  have hb : 0 ≤ b := mul_nonneg hT (Real.log_nonneg ((one_le_div hδ).mpr (hδ'.trans hk)))
  have hv (i : Fin K) : -b ≤ v i ∧ v i ≤ 0 := by
    obtain ⟨hlo,hhi⟩ := hp i
    have hf := div_pos hδ hkpos
    have h := Real.log_le_log hf hlo
    rw [Real.log_div hδ.ne' hkpos.ne'] at h
    dsimp [v,b]
    rw [Real.log_div hkpos.ne' hδ.ne']
    exact ⟨by nlinarith [mul_le_mul_of_nonneg_left h hT],
      mul_nonpos_of_nonneg_of_nonpos hT (Real.log_nonpos (hf.le.trans hlo) hhi)⟩
  have hav : (K:ℝ)*avg = ∑ i, v i := by dsimp [avg]; field_simp
  have hvar : (∑ i, (v i - avg)^2) ≤ (∑ i, (v i + b/2)^2) := by
    simp only [sub_sq,add_sq,Finset.sum_add_distrib,Finset.sum_sub_distrib,← Finset.mul_sum,
      ← Finset.sum_mul, Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul]
    rw [← hav]
    nlinarith [mul_nonneg hkpos.le (sq_nonneg (avg + b/2))]
  have hsq : (∑ i, (v i - avg)^2) ≤ (K:ℝ)*(b/2)^2 := hvar.trans (by
    calc _ ≤ ∑ _i : Fin K, (b/2)^2 := Finset.sum_le_sum fun i _ => by
              nlinarith [mul_nonpos_of_nonneg_of_nonpos (show 0 ≤ v i + b by linarith [(hv i).1]) (hv i).2]
         _ = _ := by simp)
  rw [← Real.sqrt_sq (norm_nonneg _),PiLp.norm_sq_eq_of_L2]
  change Real.sqrt (∑ i, ‖v i - avg‖^2) ≤ _
  simp only [Real.norm_eq_abs,sq_abs]
  calc _ ≤ Real.sqrt ((K:ℝ)*(b/2)^2) := Real.sqrt_le_sqrt hsq
       _ = _ := by rw [Real.sqrt_mul hkpos.le,Real.sqrt_sq (by positivity : 0 ≤ b/2)]; dsimp [b]; ring

end UL.Arxiv

import UL.Arxiv.Notation
import UL.Arxiv.HilbertScoreSearch
import UL.Arxiv.BinarySmoothing
import UL.Arxiv.LogisticLower
import UL.Arxiv.LogSmoothing
import UL.Arxiv.DictionarySelection
import UL.Arxiv.JointPrediction
import UL.Arxiv.SphericalLower
import UL.Arxiv.DictionaryGeometry
import UL.Arxiv.FiniteActions
import UL.Arxiv.BoundedApproximation
import UL.Arxiv.Dependencies
import UL.Arxiv.RankResults
import UL.Arxiv.FiniteFit
import UL.Arxiv.LogisticComparison
import UL.Arxiv.ScoreFactorization
import UL.Arxiv.Proposition_1_7
import UL.Arxiv.Theorem_1_1a
import UL.Arxiv.Theorem_1_1b

/-! # Results in the order of the arXiv manuscript

The declarations below use the theorem numbers in the paper. -/

namespace UL.Arxiv

/-! ## Main results -/

/-- Theorem 1.1(a). Binary labels, a finite first feature moment and global actions. For any nonempty compact convex weight set, the forecast obeys the prescribed slope bound and competes with every weight in that same set. -/
theorem thm_1_1a : BinaryGlobal.Statement := BinaryGlobal.exact_on_compact_convex

/-- Theorem 1.1(a) for a Euclidean ball of weights. -/
abbrev thm_1_1a_ball : UL.S_thm_3_2 := UL.T_thm_3_2

-- Theorem 1.1(b). UL.Arxiv.thm_1_1b is exported by UL.Arxiv.Theorem_1_1b.

/-- Theorem 1.2. A finite first feature moment, global actions, strongly convex face-differentiable entropies and compact convex coefficient sets. The exact-rank factorization is proved by factorThroughActualRank. -/
theorem thm_1_2_existence : UL.S_thm_3_1 := UL.T_thm_3_1

/-- Theorem 1.3 for feature dimension d = K − 1. The declaration `thm_1_3` covers all feature dimensions. -/
theorem thm_1_3_dim_K_sub_one : UL.S_thm_4_1 := UL.T_thm_4_1

/-- Theorem 1.4, measurable finite-range existence formulation. -/
theorem thm_1_4_learning : UL.MultiLearningStatement true := learningWithJointPrediction UL.T_thm_5_1

/-- Theorem 1.4 and Appendix D, with the score search and the jointly
measurable new-query prediction rule specified on the original features. -/
alias thm_1_4_finite_search := HilbertSearch.population

/-- Proposition 1.5. Quadratic loss and randomized learners. The Lean statement quantifies over regularity constants. The companion prop_1_5_unit_sphere fixes all five to one and specifies the sphere law. -/
theorem prop_1_5_spherical : UL.S_prop_C_5 := UL.T_prop_C_5

/-- Theorem 1.6. Bounded Dirichlet dictionaries, smooth entropies and arbitrary conditional labels. A measurable minimum-norm affine least-squares fit yields the quadratic sample bound. The centered link is a convex gradient. -/
theorem thm_1_6_dictionary : UL.DictionaryLearningStatement true :=
  UL.P_thm_7_1_measurable UL.T_cit_mcdiarmid1989.{0,0}

-- Proposition 1.7 is exported as prop_1_7 by UL.Arxiv.Proposition_1_7.


/-! ## Appendix B -/

/-- Lemma B.1. Canonical losses on simplex faces and realization by limits of finite actions. -/
theorem lem_B_1 : UL.S_lem_A_1 := UL.T_lem_A_1

/-- Lemma B.2. Existence and almost-sure uniqueness of the fit, with continuity as the score matrix varies. -/
theorem lem_B_2 : UL.S_lem_A_2 := UL.T_lem_A_2

/-- Lemma B.3. Support of observed labels and differentiation of projected perturbations. -/
theorem lem_B_3 : UL.S_lem_A_3 := UL.T_lem_A_3

/-- Lemma B.4. Mean residual and the two tests at a fixed fit. -/
theorem lem_B_4 : UL.S_lem_A_4 := UL.T_lem_A_4

/-- Lemma B.5. Extends smooth tests to face derivatives. -/
theorem lem_B_5 : UL.S_lem_A_5 := UL.T_lem_A_5

/-- Lemma B.6. Controls all matching losses using the residual gap. -/
theorem lem_B_6 : UL.S_lem_A_6 := UL.T_lem_A_6

/-- Corollary B.7. Moving probabilities toward the uniform report gives bounded actions at positive tolerance. -/
theorem cor_B_7 : UL.S_cor_A_8 := UL.T_cor_A_8

/-- The scalar finite-action refinement following Corollary B.7. -/
alias cor_B_7_scalar_smoothing := BinarySmoothing.binary_finite_action_refinement

/-- Theorem B.8 for feature dimension d = K − 1. The declaration `thm_B_8` covers all feature dimensions. -/
theorem thm_B_8_dim_K_sub_one : UL.S_thm_A_9 := UL.T_thm_A_9


/-! ## Appendix C -/

/-- Theorem C.1. For K ≥ 3, restricting even one class probability to one scalar score can force positive regret. -/
theorem thm_C_1_joint_link : UL.S_thm_E_1 := UL.T_thm_E_1


/-! ## Appendix D -/

/-- Lemma D.1. Empirical risk certificate and a zero-gap score matrix on the sample span. -/
theorem lem_D_1 : UL.S_lem_C_2 := UL.T_lem_C_2

/-- Lemma D.2. Uniform convergence with dependence on the score dimension. -/
theorem lem_D_2 : UL.S_lem_C_3 := UL.T_lem_C_3

/-- Lemma D.3. A quadratic program extends the fitted probabilities with the same slope. The score dimension may be zero. -/
theorem lem_D_3 : UL.SimplexExtensionAllDimensions := UL.simplexExtensionAllDimensions

/-- Positive-dimensional specialization. -/
theorem lem_D_3_pos_dim : UL.S_lem_C_4 := UL.T_lem_C_4

/-- Corollary D.4. A binary learner for smooth scalar entropies with a bounded-slope nondecreasing link. -/
theorem cor_D_4 : UL.BinaryLearningStatement true :=
  UL.P_cor_C_6_measurable UL.T_cit_brouwer.{0} UL.T_lem_C_3.{0,0}

/-- Corollary D.5. A single smoothed forecast for both families. -/
theorem cor_D_5 : UL.S_cor_C_7 := UL.T_cor_C_7

/-- Appendix D, binary logistic sample lower bound at fixed high confidence. -/
alias appendix_D_logistic_sample_lower_bound := Logistic.sample_lower_bound

end UL.Arxiv

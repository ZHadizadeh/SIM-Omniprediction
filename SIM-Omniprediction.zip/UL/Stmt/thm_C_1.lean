import Mathlib
import UL.Def.def_2_1
import UL.Def.def_2_matching
import UL.Def.def_5_smooth
import UL.Def.def_C_profiles
set_option autoImplicit false

namespace UL

/-- Auxiliary statement used by the arXiv proofs. -/
def S_thm_C_1 : Prop :=
  ∀ (K : ℕ) (hK : 2 ≤ K),
    ∃ C_K : ℝ, 0 < C_K ∧
      ∀ (X : Type*) [NormedAddCommGroup X] [InnerProductSpace ℝ X]
        [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
        [MeasurableSpace X] [BorelSpace X]
        (L R β lam M B : ℝ)
        (hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) (hlam : 0 < lam) (hM : 0 < M)
        (hB : β ≤ B),
        let m : ℕ := K - 1
        let A : ℝ := L * R
        let D : ℝ := M + A + B * lam * A
        ∀ (ε δ : ℝ) (hε0 : 0 < ε) (hεD : ε ≤ D)
          (hδ0 : 0 < δ) (hδ1 : δ < (1 : ℝ) / 2)
          (n : ℕ) (hn : 1 ≤ n),
          (n : ℝ) ≥
            (if m ≤ 2 then
              C_K * (D / ε) ^ 2 * (Real.log (C_K * D / (ε * δ))) ^ 2
            else
              C_K * ((D / ε) ^ m + (D / ε) ^ 2 * Real.log ((2 : ℝ) / δ))) →
          ∃ (learnerW : (Fin n → X × Fin K) → (X →L[ℝ] ZeroSumSubspace K))
            (learnerRho : (Fin n → X × Fin K) →
              (ZeroSumSubspace K → EuclideanSpace ℝ (Fin K))),
            (∀ sample : Fin n → X × Fin K,
              hilbertSchmidtNorm (learnerW sample) ≤ R ∧
              (∀ s : ZeroSumSubspace K, learnerRho sample s ∈ Simplex K) ∧
              LipschitzWith (Real.toNNReal B) (learnerRho sample)) ∧
            ∀ (ν : MeasureTheory.Measure (X × Fin K)) [MeasureTheory.IsProbabilityMeasure ν],
              (∀ᵐ xy ∂ν, ‖xy.1‖ ≤ L) →
              ∀ (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
                [MeasureTheory.IsProbabilityMeasure μ]
                (X_samp : Fin n → Ω → X) (Y_samp : Fin n → Ω → Fin K),
                (∀ i : Fin n, Measurable (X_samp i)) →
                (∀ i : Fin n, Measurable (Y_samp i)) →
                ProbabilityTheory.iIndepFun (fun i ω => (X_samp i ω, Y_samp i ω)) μ →
                (∀ i : Fin n,
                  MeasureTheory.Measure.map (fun ω => (X_samp i ω, Y_samp i ω)) μ = ν) →
                ∃ E : Set Ω, MeasurableSet E ∧ (μ E).toReal ≥ 1 - δ ∧
                  ∀ ω ∈ E,
                    let sample : Fin n → X × Fin K := fun i => (X_samp i ω, Y_samp i ω)
                    let W : X →L[ℝ] ZeroSumSubspace K := learnerW sample
                    let ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) := learnerRho sample
                    let p : X → EuclideanSpace ℝ (Fin K) := fun x => ρ (W x)
                    ∀ Φ ∈ SmoothEntropyFamily K β lam M,
                      (∫ xy, finiteCanonicalLoss Φ (p xy.1) xy.2 ∂ν) ≤
                        sInf ((fun V : X →L[ℝ] ZeroSumSubspace K =>
                          ∫ xy, matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 ∂ν) ''
                          {V | hilbertSchmidtNorm V ≤ R}) + ε

end UL

import Mathlib
import UL.Def.def_2_1
import UL.Def.def_3_binary
import UL.Def.def_5_smooth
import UL.Def.def_C_profiles
set_option autoImplicit false

namespace UL

/-- Formal statement for arXiv Corollary D.4, monotone single-index learner. See the scope in the theorem index. -/
def BinaryLearningStatement (jointlyMeasurable : Bool) : Prop :=
  ∃ C : ℝ, 0 < C ∧
    ∀ (X : Type*) [NormedAddCommGroup X] [InnerProductSpace ℝ X]
      [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
      [MeasurableSpace X] [BorelSpace X]
      (L R β lam M B : ℝ)
      (hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) (hlam : 0 < lam) (hM : 0 < M)
      (hB : β ≤ B),
      let D_bin : ℝ := M + L * R + B * lam * L * R
      ∀ (ε δ : ℝ) (hε0 : 0 < ε) (hεD : ε ≤ D_bin)
        (hδ0 : 0 < δ) (hδ1 : δ < (1 : ℝ) / 2)
        (n : ℕ) (hn : 1 ≤ n),
        (n : ℝ) ≥ C * (D_bin / ε) ^ 2 * (Real.log (C * D_bin / (ε * δ))) ^ 2 →
        ∃ (learnerW : (Fin n → X × Fin 2) → X)
          (learnerRho : (Fin n → X × Fin 2) → (ℝ → ℝ)),
          let feasible := ∀ sample : Fin n → X × Fin 2,
            ‖learnerW sample‖ ≤ R ∧
            Monotone (learnerRho sample) ∧
            LipschitzWith (Real.toNNReal B) (learnerRho sample) ∧
            (∀ t : ℝ, learnerRho sample t ∈ Set.Icc (0 : ℝ) 1)
          (if jointlyMeasurable then feasible ∧
            Measurable (fun z : (Fin n → X × Fin 2) × X =>
              learnerRho z.1 (inner ℝ (learnerW z.1) z.2)) else feasible) ∧
          ∀ (ν : MeasureTheory.Measure (X × Fin 2)) [MeasureTheory.IsProbabilityMeasure ν],
            (∀ᵐ xy ∂ν, ‖xy.1‖ ≤ L) →
            ∀ (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
              [MeasureTheory.IsProbabilityMeasure μ]
              (X_samp : Fin n → Ω → X) (Y_samp : Fin n → Ω → Fin 2),
              (∀ i : Fin n, Measurable (X_samp i)) →
              (∀ i : Fin n, Measurable (Y_samp i)) →
              ProbabilityTheory.iIndepFun (fun i ω => (X_samp i ω, Y_samp i ω)) μ →
              (∀ i : Fin n,
                MeasureTheory.Measure.map (fun ω => (X_samp i ω, Y_samp i ω)) μ = ν) →
              ∃ E : Set Ω, MeasurableSet E ∧ (μ E).toReal ≥ 1 - δ ∧
                ∀ ω ∈ E,
                  let sample : Fin n → X × Fin 2 := fun i => (X_samp i ω, Y_samp i ω)
                  let w : X := learnerW sample
                  let ρ : ℝ → ℝ := learnerRho sample
                  let p : X → ℝ := fun x => ρ (inner ℝ w x)
                  ∀ (φ : Set.Icc (0 : ℝ) 1 → ℝ) (U : Set ℝ) (φ_ext : ℝ → ℝ),
                    φ ∈ BinaryEntropyFamily β →
                    IsOpen U →
                    Set.Icc (0 : ℝ) 1 ⊆ U →
                    (∀ q : Set.Icc (0 : ℝ) 1, φ_ext q = φ q) →
                    DifferentiableOn ℝ φ_ext U →
                    ContinuousOn (deriv φ_ext) U →
                    (∀ q ∈ Set.Icc (0 : ℝ) 1, |deriv φ_ext q| ≤ M) →
                    (∀ q ∈ Set.Icc (0 : ℝ) 1, ∀ q' ∈ Set.Icc (0 : ℝ) 1,
                      |deriv φ_ext q - deriv φ_ext q'| ≤ lam * |q - q'|) →
                    (∫ xy, binaryMatchingLoss φ (deriv φ_ext (p xy.1)) xy.2 ∂ν) ≤
                      sInf ((fun v : X =>
                        ∫ xy, binaryMatchingLoss φ (inner ℝ v xy.1) xy.2 ∂ν) ''
                        {v : X | ‖v‖ ≤ R}) + ε

/-- Binary learning guarantee with a monotone single-index predictor. -/
abbrev S_cor_C_6.{u,v} : Prop := BinaryLearningStatement.{u,v} false

end UL

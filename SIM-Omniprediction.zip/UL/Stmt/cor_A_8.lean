import Mathlib
import UL.Def.def_2_1
import UL.Def.def_2_matching
import UL.Def.def_A_fit
import UL.Def.def_A_gap
set_option autoImplicit false

namespace UL

/-- Formal statement for arXiv Corollary B.7, finite-action postprocessing. See the scope in the theorem index. -/
def S_cor_A_8.{u} : Prop :=
  ∀ (Ω : Type u) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (d K : ℕ) (_hK : 1 ≤ K)
    (β : ℝ) (_hβ : 0 < β)
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin K)
    (_hX : Measurable X) (_hY : Measurable Y)
    (_hX_int : MeasureTheory.Integrable (fun ω => ‖X ω‖) μ)
    (𝒲 : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K))
    (_h𝒲 : IsCompactConvexScoreSet 𝒲)
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K) (_hW : W ∈ 𝒲)
    (ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K))
    (_hρ : IsLipschitzLSFitProfile μ β (linearScore W X) Y ρ)
    (_hΓ : certificateGap μ β 𝒲 X Y W = 0)
    (Φ : Simplex K → ℝ) (_hΦ : Φ ∈ EntropyFamily K β),
    let P : Ω → EuclideanSpace ℝ (Fin K) := fun ω => ρ (W (X ω))
    let p_δ : ℝ → EuclideanSpace ℝ (Fin K) → EuclideanSpace ℝ (Fin K) :=
      fun δ p => (1 - δ) • p + δ • uniformVec K
    let kΦδ : ℝ → EuclideanSpace ℝ (Fin K) → EuclideanSpace ℝ (Fin K) :=
      fun δ p => simplexGrad Φ (p_δ δ p)
    let jensenGap : (Simplex K → ℝ) → ℝ → ℝ :=
      fun Ψ δ => sSup ((fun p =>
        (1 - δ) * extendSimplex Ψ p + δ * extendSimplex Ψ (uniformVec K) -
          extendSimplex Ψ (p_δ δ p)) '' Simplex K)
    let JΦ : ℝ → ℝ := jensenGap Φ
    (∀ δ ∈ Set.Ioo (0 : ℝ) 1,
      (∀ p ∈ Simplex K, kΦδ δ p ∈ ZeroSumSubspace K) ∧
      ContinuousOn (kΦδ δ) (Simplex K) ∧
      Bornology.IsBounded (kΦδ δ '' Simplex K) ∧
      MeasureTheory.Integrable (fun ω => matchingLoss Φ (kΦδ δ (P ω)) (Y ω)) μ ∧
      (∀ V ∈ 𝒲, MeasureTheory.Integrable (fun ω => matchingLoss Φ (V (X ω)) (Y ω)) μ) ∧
      BddBelow ((fun V => ∫ ω, matchingLoss Φ (V (X ω)) (Y ω) ∂μ) '' 𝒲) ∧
      (∫ ω, matchingLoss Φ (kΦδ δ (P ω)) (Y ω) ∂μ) ≤
        sInf ((fun V => ∫ ω, matchingLoss Φ (V (X ω)) (Y ω) ∂μ) '' 𝒲) +
          JΦ δ / (1 - δ) + δ * (1 - 1 / (K : ℝ)) / (4 * β)) ∧
    Filter.Tendsto JΦ (nhdsWithin 0 (Set.Ioi 0)) (nhds 0) ∧
    (∀ (A : EuclideanSpace ℝ (Fin K) →ᵃ[ℝ] ℝ), ∀ δ ∈ Set.Ioo (0 : ℝ) 1,
      jensenGap (fun q => Φ q + A q.1) δ = JΦ δ) ∧
    (∀ ε : ℝ, 0 < ε →
      ∃ δ ∈ Set.Ioo (0 : ℝ) 1,
        (∫ ω, matchingLoss Φ (kΦδ δ (P ω)) (Y ω) ∂μ) ≤
          sInf ((fun V => ∫ ω, matchingLoss Φ (V (X ω)) (Y ω) ∂μ) '' 𝒲) + ε)

end UL

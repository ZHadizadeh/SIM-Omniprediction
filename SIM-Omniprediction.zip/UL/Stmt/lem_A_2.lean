import Mathlib
import UL.Def.def_2_1
import UL.Def.def_A_fit
set_option autoImplicit false

namespace UL

/-- Formal statement for arXiv Lemma B.2, least-squares fit and continuity. See the scope in the theorem index. -/
def S_lem_A_2 : Prop :=
  ∀ (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (d K : ℕ) (B : ℝ) (hB : 0 < B)
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin K)
    (hX : Measurable X) (hY : Measurable Y),
    (∀ W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K,
      (∃ P : Ω → EuclideanSpace ℝ (Fin K), IsLinearLipschitzLSFit μ B W X Y P) ∧
      (∀ P₁ P₂ : Ω → EuclideanSpace ℝ (Fin K),
        IsLinearLipschitzLSFit μ B W X Y P₁ →
        IsLinearLipschitzLSFit μ B W X Y P₂ →
        P₁ =ᵐ[μ] P₂)) ∧
    (∀ (W_seq : ℕ → EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
       (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K),
      Filter.Tendsto W_seq Filter.atTop (nhds W) →
      Filter.Tendsto
        (fun n => MeasureTheory.eLpNorm
          (linearFittedPrediction μ B (W_seq n) X Y - linearFittedPrediction μ B W X Y) 2 μ)
        Filter.atTop (nhds 0)) ∧
    (MeasureTheory.Integrable X μ →
      (∀ W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K,
        MeasureTheory.Integrable
          (fun ω => (innerSL ℝ (X ω)).smulRight
            (linearFittedPrediction μ B W X Y ω - oneHotLabel Y ω)) μ) ∧
      (∀ (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
         (x : EuclideanSpace ℝ (Fin d)),
        (∫ ω, (innerSL ℝ (X ω)).smulRight
          (linearFittedPrediction μ B W X Y ω - oneHotLabel Y ω) ∂μ) x ∈ ZeroSumSubspace K) ∧
      Continuous (fun W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K =>
        ∫ ω, (innerSL ℝ (X ω)).smulRight
          (linearFittedPrediction μ B W X Y ω - oneHotLabel Y ω) ∂μ))

end UL

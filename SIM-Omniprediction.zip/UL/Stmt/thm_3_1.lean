import Mathlib
import UL.Def.def_2_1
import UL.Def.def_2_matching
import UL.Def.def_2_2
set_option autoImplicit false

namespace UL

/-- Formal statement for arXiv Theorem 1.2, multiclass existence. See the scope in the theorem index. -/
def S_thm_3_1.{u} : Prop :=
  ∀ (Ω : Type u) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (d K : ℕ) (hK : 2 ≤ K)
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin K)
    (hX : Measurable X) (hY : Measurable Y)
    (hX_int : MeasureTheory.Integrable (fun ω => ‖X ω‖) μ),
    (∀ (R β : ℝ), 0 < R → 0 < β →
      ∃ (W : EuclideanSpace ℝ (Fin d) →ₗ[ℝ] ZeroSumSubspace K)
        (ρ : ZeroSumSubspace K → Simplex K),
        frobeniusNorm W ≤ R ∧
        LipschitzWith (Real.toNNReal β) ρ ∧
        let p : EuclideanSpace ℝ (Fin d) → Simplex K := ρ ∘ W
        ExactlyOmnipredicts μ X Y β R p ∧
        (∀ Φ ∈ EntropyFamily K β,
          expectedCanonicalLoss μ X Y Φ p ≠ ⊥ ∧
          expectedCanonicalLoss μ X Y Φ p ≠ ⊤ ∧
          (∀ V ∈ ComparatorBall d K R,
            expectedMatchingLoss μ X Y Φ V ≠ ⊥ ∧
            expectedMatchingLoss μ X Y Φ V ≠ ⊤) ∧
          (⨅ V ∈ ComparatorBall d K R, expectedMatchingLoss μ X Y Φ V) ≠ ⊥ ∧
          (⨅ V ∈ ComparatorBall d K R, expectedMatchingLoss μ X Y Φ V) ≠ ⊤) ∧
        (∀ j : Fin K, ∀ᵐ ω ∂μ, (p (X ω) : EuclideanSpace ℝ (Fin K)) j = 0 → Y ω ≠ j)) ∧
    (∀ (β : ℝ), 0 < β →
      ∀ (𝒲 : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)),
        𝒲.Nonempty → IsCompact 𝒲 → Convex ℝ 𝒲 →
        ∃ W ∈ 𝒲, ∃ (ρ : ZeroSumSubspace K → Simplex K),
          LipschitzWith (Real.toNNReal β) ρ ∧
          let p : EuclideanSpace ℝ (Fin d) → Simplex K := fun x => ρ (W x)
          (∀ Φ ∈ EntropyFamily K β,
            expectedCanonicalLoss μ X Y Φ p ≤
              ⨅ V ∈ 𝒲, expectedMatchingLoss μ X Y Φ V.toLinearMap ∧
            expectedCanonicalLoss μ X Y Φ p ≠ ⊥ ∧
            expectedCanonicalLoss μ X Y Φ p ≠ ⊤ ∧
            (∀ V ∈ 𝒲,
              expectedMatchingLoss μ X Y Φ V.toLinearMap ≠ ⊥ ∧
              expectedMatchingLoss μ X Y Φ V.toLinearMap ≠ ⊤) ∧
            (⨅ V ∈ 𝒲, expectedMatchingLoss μ X Y Φ V.toLinearMap) ≠ ⊥ ∧
            (⨅ V ∈ 𝒲, expectedMatchingLoss μ X Y Φ V.toLinearMap) ≠ ⊤) ∧
          (∀ j : Fin K, ∀ᵐ ω ∂μ, (p (X ω) : EuclideanSpace ℝ (Fin K)) j = 0 → Y ω ≠ j)) ∧
    (∀ (R : ℝ), 0 ≤ R →
      let opBall : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K) := {V | ‖V‖ ≤ R}
      let frobBall : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K) :=
        {V | frobeniusNorm V.toLinearMap ≤ R}
      opBall.Nonempty ∧ IsCompact opBall ∧ Convex ℝ opBall ∧
      frobBall.Nonempty ∧ IsCompact frobBall ∧ Convex ℝ frobBall ∧
      (∀ (A : AffineSubspace ℝ (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)),
        IsCompact (opBall ∩ (A : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K))) ∧
        Convex ℝ (opBall ∩ (A : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K))) ∧
        IsCompact (frobBall ∩ (A : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K))) ∧
        Convex ℝ (frobBall ∩ (A : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)))) ∧
      (∀ (C : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)),
        IsClosed C → Convex ℝ C →
        IsCompact (opBall ∩ C) ∧ Convex ℝ (opBall ∩ C) ∧
        IsCompact (frobBall ∩ C) ∧ Convex ℝ (frobBall ∩ C)))

end UL

import Mathlib
import UL.Def.def_2_1
import UL.Def.def_5_smooth
import UL.Def.def_C_profiles
set_option autoImplicit false

namespace UL

/-- Formal statement for arXiv Lemma D.2, uniform bound for loss profiles. See the scope in the theorem index. -/
def S_lem_C_3 : Prop :=
  ∀ (K : ℕ) (hK : 2 ≤ K),
    ∃ C_K : ℝ, 0 < C_K ∧
      ∀ (X : Type*) [NormedAddCommGroup X] [InnerProductSpace ℝ X]
        [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
        [MeasurableSpace X] [BorelSpace X]
        (L R C M₀ : ℝ)
        (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀)
        (n : ℕ) (hn : 1 ≤ n)
        (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1)
        (ν : MeasureTheory.Measure (X × Fin K)) [MeasureTheory.IsProbabilityMeasure ν]
        (hX_bound : ∀ᵐ xy ∂ν, ‖xy.1‖ ≤ L)
        (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
        [MeasureTheory.IsProbabilityMeasure μ]
        (X_samp : Fin n → Ω → X) (Y_samp : Fin n → Ω → Fin K)
        (hX_meas : ∀ i : Fin n, Measurable (X_samp i))
        (hY_meas : ∀ i : Fin n, Measurable (Y_samp i))
        (hindep : ProbabilityTheory.iIndepFun (fun i ω => (X_samp i ω, Y_samp i ω)) μ)
        (hident : ∀ i : Fin n, MeasureTheory.Measure.map (fun ω => (X_samp i ω, Y_samp i ω)) μ = ν),
        let m : ℕ := K - 1
        let A : ℝ := L * R
        let D₀ : ℝ := M₀ + C * A
        let evalProfile : (Metric.closedBall (0 : X) L × Fin K → ℝ) → X → Fin K → ℝ :=
          open Classical in
          fun f x y => if hx : x ∈ Metric.closedBall (0 : X) L then f (⟨x, hx⟩, y) else 0
        let bound : ℝ :=
          if m ≤ 2 then
            C_K * (D₀ * Real.log (2 * (n : ℝ)) + M₀ * Real.sqrt (Real.log (2 / δ))) /
              Real.sqrt (n : ℝ)
          else
            C_K * D₀ * ((n : ℝ) ^ (-(1 : ℝ) / (m : ℝ))) +
              C_K * M₀ * Real.sqrt (Real.log (2 / δ) / (n : ℝ))
        ∃ E : Set Ω, MeasurableSet E ∧ (μ E).toReal ≥ 1 - δ ∧
          ∀ ω ∈ E,
            sSup ((fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
              |(∫ xy, evalProfile f xy.1 xy.2 ∂ν) -
                ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalProfile f (X_samp i ω) (Y_samp i ω)|) ''
              ScoreProfileClass X K L R C M₀) ≤ bound

end UL

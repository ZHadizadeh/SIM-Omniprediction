import Mathlib
import UL.Def.def_2_1
import UL.Def.def_2_matching
import UL.Def.def_5_smooth
import UL.Def.def_7_dirichlet
set_option autoImplicit false

namespace UL

/-- Formal statement for arXiv Theorem 1.6, learning on Dirichlet dictionaries. See the scope in the theorem index. -/
def DictionaryLearningStatement (measurableFit : Bool) : Prop :=
  ∃ c : ℝ,
    0 < c ∧
    ∀ (n d K N : ℕ), 1 ≤ n → 2 ≤ K →
      ∀ (L R β lam M : ℝ),
        0 < L → 0 < R → 0 < β → 0 < lam → 0 < M →
        let D : ℝ := M + L * R + β * lam * L * R
        let C_set : Set (ZeroSumSubspace K) :=
          {z | (z : EuclideanSpace ℝ (Fin K)) + uniformVec K ∈ Simplex K}
        let projC : ZeroSumSubspace K → ZeroSumSubspace K :=
          open Classical in
          fun v =>
            if h : ∃ z ∈ C_set, IsMinOn (fun z' => ‖v - z'‖) C_set z then
              Classical.choose h
            else 0
        ∀ (ε δ : ℝ),
          0 < ε → ε ≤ D → 0 < δ → δ < (1 : ℝ) / 2 →
          ∃ (fitA : (Fin n → EuclideanSpace ℝ (Fin d)) → (Fin n → Fin K) → ZeroSumSubspace K)
            (fitW : (Fin n → EuclideanSpace ℝ (Fin d)) → (Fin n → Fin K) →
              (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)),
          let structureOnSample := ∀ (xs : Fin n → EuclideanSpace ℝ (Fin d)) (ys : Fin n → Fin K),
              let aHat := fitA xs ys
              let WHat := fitW xs ys
              hilbertSchmidtNorm WHat ≤ R ∧
              Module.finrank ℝ (LinearMap.range WHat.toLinearMap) ≤ K - 1 ∧
              (let ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) :=
                fun s => uniformVec K + (projC (aHat + β • s) : EuclideanSpace ℝ (Fin K))
               (∀ s : ZeroSumSubspace K, ρ s ∈ Simplex K) ∧
               LipschitzWith (Real.toNNReal β) ρ ∧
               ∃ Ψ : ZeroSumSubspace K → ℝ,
                 ConvexOn ℝ Set.univ Ψ ∧
                 Differentiable ℝ Ψ ∧
                 ∀ s : ZeroSumSubspace K,
                   ρ s - uniformVec K = (↑(gradient Ψ s) : EuclideanSpace ℝ (Fin K)))
          (if measurableFit then structureOnSample ∧ Measurable (Function.uncurry fitA) ∧
            Measurable (Function.uncurry fitW) else structureOnSample) ∧
          ((n : ℝ) ≥ c * (D ^ 2 / ε ^ 2) * Real.log ((2 : ℝ) / δ) →
            ∀ (x_dict : Fin N → EuclideanSpace ℝ (Fin d)),
              DirichletFeatureCondition x_dict →
              (∀ j : Fin N, ‖x_dict j‖ ≤ L) →
              ∀ (ν : MeasureTheory.Measure (EuclideanSpace ℝ (Fin d) × Fin K))
                [MeasureTheory.IsProbabilityMeasure ν],
                (∀ᵐ xy ∂ν, xy.1 ∈ Set.range x_dict) →
                ∀ (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
                  [MeasureTheory.IsProbabilityMeasure μ]
                  (X : Fin n → Ω → EuclideanSpace ℝ (Fin d))
                  (Y : Fin n → Ω → Fin K),
                  (∀ i : Fin n, Measurable (X i)) →
                  (∀ i : Fin n, Measurable (Y i)) →
                  ProbabilityTheory.iIndepFun (fun i ω => (X i ω, Y i ω)) μ →
                  (∀ i : Fin n, MeasureTheory.Measure.map (fun ω => (X i ω, Y i ω)) μ = ν) →
                  (μ {ω |
                    let aHat := fitA (fun i => X i ω) (fun i => Y i ω)
                    let WHat := fitW (fun i => X i ω) (fun i => Y i ω)
                    (let pHat : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin K) :=
                      fun x => uniformVec K + (projC (aHat + β • WHat x) : EuclideanSpace ℝ (Fin K))
                     ∀ Φ ∈ SmoothEntropyFamily K β lam M,
                       (∫ xy, finiteCanonicalLoss Φ (pHat xy.1) xy.2 ∂ν) ≤
                         sInf ((fun V : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K =>
                           ∫ xy, matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 ∂ν) ''
                           {V | hilbertSchmidtNorm V ≤ R}) + ε)}).toReal ≥ 1 - δ)

/-- Statistical learning guarantee for a Dirichlet dictionary. -/
abbrev S_thm_7_1.{u} : Prop := DictionaryLearningStatement.{u} false

end UL

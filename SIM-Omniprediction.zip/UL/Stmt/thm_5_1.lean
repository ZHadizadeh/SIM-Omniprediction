import Mathlib
import UL.Def.def_2_1
import UL.Def.def_2_matching
import UL.Def.def_5_smooth
set_option autoImplicit false

namespace UL

/-- Formal statement for arXiv Theorem 1.4, learning with bounded features. See the scope in the theorem index. -/
def MultiLearningStatement (jointlyMeasurable : Bool) : Prop :=
  ∀ (K : ℕ) (_hK : 2 ≤ K),
    ∃ (C_K : ℝ), 1 ≤ C_K ∧
      ∀ (d : ℕ) (L R β lam M ε δ : ℝ)
        (_hL : 0 < L) (_hR : 0 < R) (_hβ : 0 < β) (_hlam : 0 < lam) (_hM : 0 < M),
        let m : ℕ := K - 1
        let A : ℝ := L * R
        let D : ℝ := M + A + β * lam * A
        ∀ (_hε_pos : 0 < ε) (_hε_le : ε ≤ D)
          (_hδ_pos : 0 < δ) (_hδ_lt : δ < (1 : ℝ) / 2)
          (n : ℕ),
          (if m ≤ 2 then
              C_K * (D / ε) ^ 2 * (Real.log (C_K * D / (ε * δ))) ^ 2 ≤ (n : ℝ)
            else
              C_K * ((D / ε) ^ m + (D / ε) ^ 2 * Real.log (2 / δ)) ≤ (n : ℝ)) →
          ∃ (H_cand : Finset ((EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K) ×
              (ZeroSumSubspace K → EuclideanSpace ℝ (Fin K))))
            (learner : (Fin n → EuclideanSpace ℝ (Fin d) × Fin K) →
              (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K) ×
                (ZeroSumSubspace K → EuclideanSpace ℝ (Fin K))),
            let valid := ∀ h ∈ H_cand,
              hilbertSchmidtNorm h.1 ≤ R ∧
              (∀ s : ZeroSumSubspace K, h.2 s ∈ Simplex K) ∧
              (∀ s s' : ZeroSumSubspace K, ‖h.2 s - h.2 s'‖ ≤ β * ‖s - s'‖)
            (if jointlyMeasurable then valid ∧
              Measurable (fun z : (Fin n → EuclideanSpace ℝ (Fin d) × Fin K) × EuclideanSpace ℝ (Fin d) =>
                (learner z.1).2 ((learner z.1).1 z.2)) else valid) ∧
            (∀ S : Fin n → EuclideanSpace ℝ (Fin d) × Fin K, learner S ∈ H_cand) ∧
            (∀ h ∈ H_cand, MeasurableSet {S : Fin n → EuclideanSpace ℝ (Fin d) × Fin K | learner S = h}) ∧
            ∀ (μ : MeasureTheory.Measure (EuclideanSpace ℝ (Fin d) × Fin K)),
              MeasureTheory.IsProbabilityMeasure μ →
              (∀ᵐ z ∂μ, ‖z.1‖ ≤ L) →
              ENNReal.ofReal (1 - δ) ≤
                (MeasureTheory.Measure.pi (fun _ : Fin n => μ))
                  { S : Fin n → EuclideanSpace ℝ (Fin d) × Fin K |
                    let W := (learner S).1
                    let ρ := (learner S).2
                    ∀ Φ ∈ SmoothEntropyFamily K β lam M,
                      ∫ z, matchingLoss Φ (finiteCanonicalAction Φ (ρ (W z.1))) z.2 ∂μ ≤
                        (⨅ V : {V : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K //
                            hilbertSchmidtNorm V ≤ R},
                          ∫ z, matchingLoss Φ
                            ((V.1 z.1 : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) z.2 ∂μ) + ε }

/-- Learning guarantee for a finite set of candidate forecasts. -/
abbrev S_thm_5_1 : Prop := MultiLearningStatement false

end UL

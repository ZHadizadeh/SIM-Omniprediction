import Mathlib
import UL.Def.def_3_binary
set_option autoImplicit false

namespace UL

/-- Euclidean-ball case of arXiv Theorem 1.1(a). The full statement is in UL.Arxiv.Theorem_1_1a. -/
def S_thm_3_2 : Prop :=
  ∀ (d : ℕ)
    (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin 2)
    (hX_meas : Measurable X) (hY_meas : Measurable Y)
    (R β : ℝ) (hR : 0 < R) (hβ : 0 < β)
    (hX_int : MeasureTheory.Integrable (fun ω => ‖X ω‖) μ),
    ∃ (w : EuclideanSpace ℝ (Fin d)) (ρ : ℝ → ℝ),
      ‖w‖ ≤ R ∧
      Monotone ρ ∧
      LipschitzWith (Real.toNNReal β) ρ ∧
      (∀ t : ℝ, ρ t ∈ Set.Icc (0 : ℝ) 1) ∧
      (∀ᵐ ω ∂μ, (ρ (inner ℝ w (X ω)) = 0 → Y ω = 0) ∧
        (ρ (inner ℝ w (X ω)) = 1 → Y ω = 1)) ∧
      ∀ φ ∈ BinaryEntropyFamily β,
        (∀ᵐ ω ∂μ,
          binaryExtendedCanonicalLoss φ (ρ (inner ℝ w (X ω))) (Y ω) ≠ ⊥ ∧
          binaryExtendedCanonicalLoss φ (ρ (inner ℝ w (X ω))) (Y ω) ≠ ⊤) ∧
        MeasureTheory.Integrable
          (fun ω => (binaryExtendedCanonicalLoss φ (ρ (inner ℝ w (X ω))) (Y ω)).toReal) μ ∧
        (∀ v : EuclideanSpace ℝ (Fin d), ‖v‖ ≤ R →
          MeasureTheory.Integrable
            (fun ω => binaryMatchingLoss φ (inner ℝ v (X ω)) (Y ω)) μ) ∧
        (∫ ω, (binaryExtendedCanonicalLoss φ (ρ (inner ℝ w (X ω))) (Y ω)).toReal ∂μ) ≤
          sInf ((fun v : EuclideanSpace ℝ (Fin d) =>
            ∫ ω, binaryMatchingLoss φ (inner ℝ v (X ω)) (Y ω) ∂μ) '' {v | ‖v‖ ≤ R})

end UL

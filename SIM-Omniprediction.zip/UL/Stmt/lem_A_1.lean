import Mathlib
import UL.Def.def_2_1
import UL.Def.def_2_matching
set_option autoImplicit false

namespace UL

/-- Formal statement for arXiv Lemma B.1, boundary loss and properness. See the scope in the theorem index. -/
def S_lem_A_1 : Prop :=
  ∀ (K : ℕ) (hK : 2 ≤ K) (Φ : Simplex K → ℝ)
    (hCont : Continuous Φ)
    (hConv : ConvexOn ℝ (Simplex K) (extendSimplex Φ))
    (hDiff : ∀ J : Finset (Fin K), J.Nonempty →
      ∀ p ∈ SimplexFaceRelint K J, ∃ g, HasFaceGradAt Φ J p g),
    (∀ q ∈ Simplex K,
      (∑ y : Fin K, ((q y : ℝ) : EReal) * extendedCanonicalLoss Φ q y =
        ((-extendSimplex Φ q : ℝ) : EReal)) ∧
      (∀ p ∈ Simplex K,
        ∑ y : Fin K, ((q y : ℝ) : EReal) * extendedCanonicalLoss Φ q y ≤
          ∑ y : Fin K, ((q y : ℝ) : EReal) * extendedCanonicalLoss Φ p y)) ∧
    (∀ p ∈ Simplex K, ∀ y : Fin K,
      ((-extendSimplex Φ (EuclideanSpace.single y (1 : ℝ)) : ℝ) : EReal) ≤
        extendedCanonicalLoss Φ p y) ∧
    (∀ p ∈ Simplex K, ∃ a : ℕ → EuclideanSpace ℝ (Fin K),
      (∀ t : ℕ, a t ∈ ZeroSumSubspace K) ∧
      ∀ y : Fin K, Filter.Tendsto
        (fun t : ℕ => ((matchingLoss Φ (a t) y : ℝ) : EReal))
        Filter.atTop (nhds (extendedCanonicalLoss Φ p y))) ∧
    (∀ p ∈ SimplexFaceRelint K Finset.univ,
      simplexGrad Φ p ∈ ZeroSumSubspace K ∧
      ∀ y : Fin K,
        ((matchingLoss Φ (simplexGrad Φ p) y : ℝ) : EReal) =
          extendedCanonicalLoss Φ p y)

end UL

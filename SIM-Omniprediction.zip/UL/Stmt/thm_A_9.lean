import Mathlib
import UL.Def.def_2_1
import UL.Def.def_2_matching
import UL.Def.def_2_2
set_option autoImplicit false

namespace UL

/-- Theorem B.8 for feature dimension d = K − 1. The general statement is in `UL.Arxiv.Tradeoff.AllDimensions`. -/
def S_thm_A_9 : Prop :=
  ∀ (K : ℕ) (hK : 2 ≤ K)
    (R β L : ℝ) (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    (hcond : β * R * L / Real.sqrt ((K : ℝ) - 1) < 1 / (K : ℝ)),
    let m : ℕ := K - 1
    ∃ (P : MeasureTheory.Measure (EuclideanSpace ℝ (Fin m) × Fin K))
      (Φ : Simplex K → ℝ),
      let X : EuclideanSpace ℝ (Fin m) × Fin K → EuclideanSpace ℝ (Fin m) := Prod.fst
      let Y : EuclideanSpace ℝ (Fin m) × Fin K → Fin K := Prod.snd
      let bench : EReal := ⨅ V ∈ ComparatorBall m K R, expectedMatchingLoss P X Y Φ V
      let regret : (EuclideanSpace ℝ (Fin m) → Simplex K) → EReal :=
        fun p => expectedCanonicalLoss P X Y Φ p - bench
      let c : ℝ := β * R / Real.sqrt (m : ℝ)
      MeasureTheory.IsProbabilityMeasure P ∧
      MeasureTheory.pdf.IsUniform X
        (Metric.ball (0 : EuclideanSpace ℝ (Fin m)) L) P MeasureTheory.volume ∧
      Φ ∈ EntropyFamily K β ∧
      (∃ (M : EuclideanSpace ℝ (Fin K) →ₗ[ℝ] EuclideanSpace ℝ (Fin K))
         (b : EuclideanSpace ℝ (Fin K)) (c₀ : ℝ),
        ∀ q : Simplex K,
          Φ q = inner ℝ (q : EuclideanSpace ℝ (Fin K)) (M (q : EuclideanSpace ℝ (Fin K))) +
            inner ℝ b (q : EuclideanSpace ℝ (Fin K)) + c₀) ∧
      bench ≠ ⊥ ∧
      bench ≠ ⊤ ∧
      (∀ (r : ℕ), 1 ≤ r → r ≤ m → ∀ (B : ℝ), 0 ≤ B →
        let val : ℝ :=
          (L ^ 2 / (2 * β * ((m : ℝ) + 2))) *
            (((m : ℝ) - (r : ℝ)) * c ^ 2 +
              (r : ℝ) * (max (c - B * R / Real.sqrt (r : ℝ)) 0) ^ 2)
        (∀ (W : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] ZeroSumSubspace K)
           (ρ : ZeroSumSubspace K → Simplex K),
          Module.finrank ℝ (LinearMap.range W) ≤ r →
          frobeniusNorm W ≤ R →
          LipschitzWith (Real.toNNReal B) ρ →
          (val : EReal) ≤ regret (ρ ∘ W)) ∧
        (⨅ (W : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] ZeroSumSubspace K)
           (_ : Module.finrank ℝ (LinearMap.range W) ≤ r)
           (_ : frobeniusNorm W ≤ R)
           (ρ : ZeroSumSubspace K → Simplex K)
           (_ : LipschitzWith (Real.toNNReal B) ρ),
          regret (ρ ∘ W)) = (val : EReal) ∧
        (∃ (W : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] ZeroSumSubspace K)
           (ρ : ZeroSumSubspace K → Simplex K)
           (A_aff : EuclideanSpace ℝ (Fin m) →ᵃ[ℝ] EuclideanSpace ℝ (Fin K))
           (K_lip : NNReal),
          Module.finrank ℝ (LinearMap.range W) ≤ r ∧
          frobeniusNorm W ≤ R ∧
          LipschitzWith (Real.toNNReal B) ρ ∧
          LipschitzWith K_lip (ρ ∘ W) ∧
          (∀ x ∈ Metric.closedBall (0 : EuclideanSpace ℝ (Fin m)) L,
            (ρ (W x) : EuclideanSpace ℝ (Fin K)) = A_aff x) ∧
          regret (ρ ∘ W) = (val : EReal))) ∧
      (∀ (B : ℝ), 0 ≤ B →
        let val₀ : ℝ := L ^ 2 * (m : ℝ) * c ^ 2 / (2 * β * ((m : ℝ) + 2))
        (∀ (W : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] ZeroSumSubspace K)
           (ρ : ZeroSumSubspace K → Simplex K),
          Module.finrank ℝ (LinearMap.range W) ≤ 0 →
          frobeniusNorm W ≤ R →
          LipschitzWith (Real.toNNReal B) ρ →
          (val₀ : EReal) ≤ regret (ρ ∘ W)) ∧
        (⨅ (W : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] ZeroSumSubspace K)
           (_ : Module.finrank ℝ (LinearMap.range W) ≤ 0)
           (_ : frobeniusNorm W ≤ R)
           (ρ : ZeroSumSubspace K → Simplex K)
           (_ : LipschitzWith (Real.toNNReal B) ρ),
          regret (ρ ∘ W)) = (val₀ : EReal) ∧
        (∃ (W : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] ZeroSumSubspace K)
           (ρ : ZeroSumSubspace K → Simplex K)
           (A_aff : EuclideanSpace ℝ (Fin m) →ᵃ[ℝ] EuclideanSpace ℝ (Fin K))
           (K_lip : NNReal),
          Module.finrank ℝ (LinearMap.range W) ≤ 0 ∧
          frobeniusNorm W ≤ R ∧
          LipschitzWith (Real.toNNReal B) ρ ∧
          LipschitzWith K_lip (ρ ∘ W) ∧
          (∀ x ∈ Metric.closedBall (0 : EuclideanSpace ℝ (Fin m)) L,
            (ρ (W x) : EuclideanSpace ℝ (Fin K)) = A_aff x) ∧
          regret (ρ ∘ W) = (val₀ : EReal)))

end UL

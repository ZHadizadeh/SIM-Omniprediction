import Mathlib
import UL.Def.def_2_1
import UL.Def.def_2_matching
import UL.Def.def_A_fit
import UL.Def.def_A_gap
set_option autoImplicit false

namespace UL

/-- Formal statement for arXiv Lemma B.6, simultaneous risk certificate. See the scope in the theorem index. -/
def S_lem_A_6.{u} : Prop :=
  ∀ (Ω : Type u) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (d K : ℕ) (_hK : 1 ≤ K)
    (β B : ℝ) (_hβ : 0 < β) (_hB : β ≤ B)
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin K)
    (_hX : Measurable X) (_hY : Measurable Y)
    (_hX_int : MeasureTheory.Integrable (fun ω => ‖X ω‖) μ)
    (𝒲 : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K))
    (_h𝒲 : IsCompactConvexScoreSet 𝒲)
    (W V : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
    (_hW : W ∈ 𝒲) (_hV : V ∈ 𝒲)
    (Φ : Simplex K → ℝ) (_hΦ : Φ ∈ EntropyFamily K β),
    let P_W : Ω → EuclideanSpace ℝ (Fin K) := linearFittedPrediction μ B W X Y
    let qΦ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) :=
      fun a => uniformVec K +
        ((gradient (fun s : ZeroSumSubspace K => matchingPotential Φ s) a :
          ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
    (∀ᵐ ω ∂μ, extendedCanonicalLoss Φ (P_W ω) (Y ω) ≠ ⊤) ∧
    MeasureTheory.Integrable (fun ω => (extendedCanonicalLoss Φ (P_W ω) (Y ω)).toReal) μ ∧
    MeasureTheory.Integrable (fun ω => matchingLoss Φ (V (X ω)) (Y ω)) μ ∧
    (∫ ω, (extendedCanonicalLoss Φ (P_W ω) (Y ω)).toReal ∂μ) -
        (∫ ω, matchingLoss Φ (V (X ω)) (Y ω) ∂μ) ≤
      certificateGap μ B 𝒲 X Y W -
        ∫ ω, (extendSimplex Φ (P_W ω) + matchingPotential Φ (V (X ω)) -
          inner ℝ (P_W ω - uniformVec K) (V (X ω) : EuclideanSpace ℝ (Fin K))) ∂μ ∧
    certificateGap μ B 𝒲 X Y W -
        ∫ ω, (extendSimplex Φ (P_W ω) + matchingPotential Φ (V (X ω)) -
          inner ℝ (P_W ω - uniformVec K) (V (X ω) : EuclideanSpace ℝ (Fin K))) ∂μ ≤
      certificateGap μ B 𝒲 X Y W -
        (1 / (2 * β)) * ∫ ω, ‖P_W ω - qΦ (V (X ω))‖ ^ 2 ∂μ

end UL

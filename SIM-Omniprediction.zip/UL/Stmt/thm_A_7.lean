import Mathlib
import UL.Def.def_2_1
import UL.Def.def_2_matching
import UL.Def.def_A_fit
import UL.Def.def_A_gap
set_option autoImplicit false

namespace UL

/-- Auxiliary statement used by the arXiv proofs. -/
def S_thm_A_7.{u} : Prop :=
  ∀ (Ω : Type u) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (d K : ℕ) (_hK : 1 ≤ K)
    (β : ℝ) (_hβ : 0 < β)
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin K)
    (_hX : Measurable X) (_hY : Measurable Y)
    (_hX_int : MeasureTheory.Integrable (fun ω => ‖X ω‖) μ)
    (𝒲 : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K))
    (_h𝒲 : IsCompactConvexScoreSet 𝒲),
    ∃ W ∈ 𝒲, ∃ ρ ∈ LipschitzSimplexMaps K β,
      (∀ Φ ∈ EntropyFamily K β,
        (∀ᵐ ω ∂μ, extendedCanonicalLoss Φ (ρ (W (X ω))) (Y ω) ≠ ⊤) ∧
        MeasureTheory.Integrable
          (fun ω => (extendedCanonicalLoss Φ (ρ (W (X ω))) (Y ω)).toReal) μ ∧
        (∀ V ∈ 𝒲, MeasureTheory.Integrable (fun ω => matchingLoss Φ (V (X ω)) (Y ω)) μ) ∧
        BddBelow ((fun V => ∫ ω, matchingLoss Φ (V (X ω)) (Y ω) ∂μ) '' 𝒲) ∧
        (∫ ω, (extendedCanonicalLoss Φ (ρ (W (X ω))) (Y ω)).toReal ∂μ) ≤
          sInf ((fun V => ∫ ω, matchingLoss Φ (V (X ω)) (Y ω) ∂μ) '' 𝒲)) ∧
      (∀ j : Fin K, ∀ᵐ ω ∂μ, ρ (W (X ω)) j = 0 → Y ω ≠ j) ∧
      ∃ (U : EuclideanSpace ℝ (Fin (K - 1)) →ₗᵢ[ℝ] ZeroSumSubspace K)
        (A : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin (K - 1))),
        W = U.toContinuousLinearMap.comp A ∧
        Real.sqrt (∑ i : Fin d, ‖A (EuclideanSpace.single i 1)‖ ^ 2) =
          Real.sqrt (∑ i : Fin d, ‖W (EuclideanSpace.single i 1)‖ ^ 2) ∧
        ‖A‖ = ‖W‖ ∧
        LipschitzWith (Real.toNNReal β) (fun z => ρ (U z)) ∧
        (∀ z, ρ (U z) ∈ Simplex K)

end UL

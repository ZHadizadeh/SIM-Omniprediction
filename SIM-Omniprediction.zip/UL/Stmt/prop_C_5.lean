import Mathlib
import UL.Def.def_2_1
import UL.Def.def_2_matching
import UL.Def.def_5_smooth
import UL.Def.def_D_rot_defect
set_option autoImplicit false

namespace UL

/-- Formal statement for arXiv Proposition 1.5, spherical sample lower bound. See the scope in the theorem index. -/
def S_prop_C_5 : Prop :=
  ∀ (K : ℕ) (_hK : 2 ≤ K),
    ∃ (L R β lam M ε₀ c₁ c₂ c₃ : ℝ),
      0 < L ∧ 0 < R ∧ 0 < β ∧ 0 < lam ∧ 0 < M ∧
      0 < ε₀ ∧ 0 < c₁ ∧ c₁ ≤ c₂ ∧ 0 < c₃ ∧
      let Φ_quad : Simplex K → ℝ :=
        fun q => ((1 : ℝ) / 2) * ‖(q : EuclideanSpace ℝ (Fin K)) - uniformVec K‖ ^ 2
      Φ_quad ∈ SmoothEntropyFamily K β lam M ∧
      ∀ (ε : ℝ), 0 < ε → ε ≤ ε₀ →
        ∃ (d : ℕ) (μ_X : MeasureTheory.Measure (EuclideanSpace ℝ (Fin d))),
          1 ≤ d ∧
          c₁ / ε ≤ (d : ℝ) ∧ (d : ℝ) ≤ c₂ / ε ∧
          MeasureTheory.IsProbabilityMeasure μ_X ∧
          (∀ᵐ x ∂μ_X, ‖x‖ = 1) ∧
          (∀ᵐ x ∂μ_X, ‖x‖ ≤ L) ∧
          HasSphericalFeatureSymmetry μ_X ∧
          ∀ (n : ℕ)
            (Ξ : Type) [MeasurableSpace Ξ] (ν : MeasureTheory.Measure Ξ)
            [MeasureTheory.IsProbabilityMeasure ν]
            (p_hat : Ξ → (Fin n → EuclideanSpace ℝ (Fin d) × Fin K) →
              EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin K)),
            Measurable (fun q : Ξ × (Fin n → EuclideanSpace ℝ (Fin d) × Fin K) ×
                EuclideanSpace ℝ (Fin d) => p_hat q.1 q.2.1 q.2.2) →
            (∀ (ξ : Ξ) (S : Fin n → EuclideanSpace ℝ (Fin d) × Fin K)
                (x : EuclideanSpace ℝ (Fin d)),
              p_hat ξ S x ∈ Simplex K) →
            (∀ (μ : MeasureTheory.Measure (EuclideanSpace ℝ (Fin d) × Fin K)),
              MeasureTheory.IsProbabilityMeasure μ →
              μ.fst = μ_X →
              ENNReal.ofReal ((5 : ℝ) / 7) <
                (ν.prod (MeasureTheory.Measure.pi (fun _ : Fin n => μ)))
                  { q : Ξ × (Fin n → EuclideanSpace ℝ (Fin d) × Fin K) |
                    ∫ z, finiteCanonicalLoss Φ_quad (p_hat q.1 q.2 z.1) z.2 ∂μ ≤
                      (⨅ V : {V : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K //
                          hilbertSchmidtNorm V ≤ R},
                        ∫ z, matchingLoss Φ_quad
                          ((V.1 z.1 : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) z.2 ∂μ) + ε }) →
            c₃ / ε ^ 2 ≤ (n : ℝ)

end UL

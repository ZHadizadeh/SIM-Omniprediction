import Mathlib
import UL.Def.def_2_1
import UL.Def.def_2_matching
import UL.Def.def_E_separate
set_option autoImplicit false

namespace UL

/-- Formal statement for arXiv Theorem C.1, joint probability links are necessary. See the scope in the theorem index. -/
def S_thm_E_1 : Prop :=
  ∀ (K : ℕ) (hK : 3 ≤ K) (R β L : ℝ) (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L),
    ∃ (P : MeasureTheory.Measure (EuclideanSpace ℝ (Fin (K - 1)) × Fin K))
      (Φ : Simplex K → ℝ),
      let X : EuclideanSpace ℝ (Fin (K - 1)) × Fin K → EuclideanSpace ℝ (Fin (K - 1)) := Prod.fst
      let Y : EuclideanSpace ℝ (Fin (K - 1)) × Fin K → Fin K := Prod.snd
      let μX : MeasureTheory.Measure (EuclideanSpace ℝ (Fin (K - 1))) := P.fst
      let frobNorm : (EuclideanSpace ℝ (Fin (K - 1)) →L[ℝ] ZeroSumSubspace K) → ℝ :=
        fun V => Real.sqrt (∑ i : Fin (K - 1), ‖V (EuclideanSpace.single i (1 : ℝ))‖ ^ 2)
      let expCanonicalLoss :
          (EuclideanSpace ℝ (Fin (K - 1)) → EuclideanSpace ℝ (Fin K)) → EReal :=
        fun p =>
          ((∫⁻ z, (extendedCanonicalLoss Φ (p (X z)) (Y z)).toENNReal ∂P : ENNReal) : EReal) -
            ((∫⁻ z, (-extendedCanonicalLoss Φ (p (X z)) (Y z)).toENNReal ∂P : ENNReal) : EReal)
      let linBench : ℝ :=
        sInf ((fun V : EuclideanSpace ℝ (Fin (K - 1)) →L[ℝ] ZeroSumSubspace K =>
          ∫ z, matchingLoss Φ (V (X z)) (Y z) ∂P) '' {V | frobNorm V ≤ R})
      MeasureTheory.IsProbabilityMeasure P ∧
      MeasureTheory.pdf.IsUniform X
        (Metric.ball (0 : EuclideanSpace ℝ (Fin (K - 1))) L) P MeasureTheory.volume ∧
      MeasureTheory.Integrable (fun x => ‖x‖) μX ∧
      Φ ∈ EntropyFamily K β ∧
      (∀ V : EuclideanSpace ℝ (Fin (K - 1)) →L[ℝ] ZeroSumSubspace K,
        MeasureTheory.Integrable (fun z => matchingLoss Φ (V (X z)) (Y z)) P) ∧
      (∃ V₀ : EuclideanSpace ℝ (Fin (K - 1)) →L[ℝ] ZeroSumSubspace K,
        frobNorm V₀ = R ∧
        Differentiable ℝ (matchingPotential Φ) ∧
        let η : EuclideanSpace ℝ (Fin (K - 1)) → EuclideanSpace ℝ (Fin K) :=
          fun x => uniformVec K + gradient (matchingPotential Φ) (V₀ x : EuclideanSpace ℝ (Fin K))
        (∀ x : EuclideanSpace ℝ (Fin (K - 1)), η x ∈ Simplex K) ∧
        (∀ A : Set (EuclideanSpace ℝ (Fin (K - 1))), MeasurableSet A →
          ∀ y : Fin K, P (A ×ˢ {y}) = ∫⁻ x in A, ENNReal.ofReal (η x y) ∂μX) ∧
        linBench = ∫ z, matchingLoss Φ (V₀ (X z)) (Y z) ∂P ∧
        (∀ (x : EuclideanSpace ℝ (Fin (K - 1))) (a : ZeroSumSubspace K),
          ∑ y : Fin K, η x y * matchingLoss Φ (V₀ x) y ≤
            ∑ y : Fin K, η x y * matchingLoss Φ a y) ∧
        ((linBench : ℝ) : EReal) = expCanonicalLoss η ∧
        (∀ q : EuclideanSpace ℝ (Fin (K - 1)) → EuclideanSpace ℝ (Fin K),
          Measurable q → (∀ x : EuclideanSpace ℝ (Fin (K - 1)), q x ∈ Simplex K) →
          ((linBench : ℝ) : EReal) ≤ expCanonicalLoss q) ∧
        (∃ (W : EuclideanSpace ℝ (Fin (K - 1)) →L[ℝ] EuclideanSpace ℝ (Fin (K - 1)))
           (ρ : EuclideanSpace ℝ (Fin (K - 1)) → EuclideanSpace ℝ (Fin K)),
          Real.sqrt (∑ i : Fin (K - 1), ‖W (EuclideanSpace.single i (1 : ℝ))‖ ^ 2) ≤ R ∧
          LipschitzWith (Real.toNNReal β) ρ ∧
          (∀ s : EuclideanSpace ℝ (Fin (K - 1)), ρ s ∈ Simplex K) ∧
          (∀ x : EuclideanSpace ℝ (Fin (K - 1)), η x = ρ (W x)))) ∧
      (∃ γ : ℝ, 0 < γ ∧
        (∀ p : EuclideanSpace ℝ (Fin (K - 1)) → EuclideanSpace ℝ (Fin K),
          Measurable p →
          (∀ x : EuclideanSpace ℝ (Fin (K - 1)), p x ∈ Simplex K) →
          (∃ (j : Fin K) (a : EuclideanSpace ℝ (Fin (K - 1))) (f : ℝ → ℝ),
            Measurable f ∧
            (∀ t : ℝ, f t ∈ Set.Icc (0 : ℝ) 1) ∧
            (∀ᵐ x ∂μX, p x j = f (inner ℝ a x))) →
          ((linBench + γ : ℝ) : EReal) ≤ expCanonicalLoss p) ∧
        (∀ p : EuclideanSpace ℝ (Fin (K - 1)) → EuclideanSpace ℝ (Fin K),
          HasSeparateLinkArchitectureAE μX p →
          ((linBench + γ : ℝ) : EReal) ≤ expCanonicalLoss p ∧
            ¬ (expCanonicalLoss p ≤ ((linBench : ℝ) : EReal))))

end UL

import Mathlib
import UL.Def.def_2_1
import UL.Def.def_A_fit
set_option autoImplicit false

namespace UL

/-- Formal statement for arXiv Lemma B.5, facewise convex tests. See the scope in the theorem index. -/
def S_lem_A_5 : Prop :=
  ∀ (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (K : ℕ) (hK : 2 ≤ K)
    (P : Ω → EuclideanSpace ℝ (Fin K)) (Y : Ω → Fin K)
    (hP_meas : Measurable P) (hY_meas : Measurable Y)
    (hP : ∀ ω : Ω, P ω ∈ Simplex K)
    (hsupp : ∀ j : Fin K, ∀ᵐ ω ∂μ, P ω j = 0 → oneHotLabel Y ω j = 0)
    (hsmooth : ∀ (f : ZeroSumSubspace K → ℝ),
      Differentiable ℝ f →
      ConvexOn ℝ Set.univ f →
      (∃ L : NNReal, LipschitzWith L (gradient f)) →
      ∫ ω, inner ℝ (fitResidual P Y ω)
        (↑(gradient f ((ZeroSumSubspace K).orthogonalProjection (P ω - uniformVec K))) :
          EuclideanSpace ℝ (Fin K)) ∂μ ≤ 0)
    (F : Simplex K → ℝ)
    (hF_cont : Continuous F)
    (hF_conv : ConvexOn ℝ (Simplex K) (extendSimplex F))
    (hF_diff : ∀ J : Finset (Fin K), J.Nonempty →
      ∀ p ∈ SimplexFaceRelint K J, ∃ g, HasFaceGradAt F J p g),
    let prod : Ω → ℝ := fun ω =>
      inner ℝ (fitResidual P Y ω)
        (faceGrad F (open Classical in Finset.univ.filter (fun j : Fin K => 0 < P ω j)) (P ω))
    (∫ ω, prod ω ∂μ ≤ 0) ∧ MeasureTheory.Integrable prod μ

end UL

import Mathlib
import UL.Def.def_2_1
import UL.Def.def_2_matching
import UL.Def.def_5_smooth
set_option autoImplicit false

namespace UL

/-- Corollary D.5. Joint learning of smooth and logarithmic losses on bounded features. -/
def S_cor_C_7 : Prop :=
  ∃ C_samp : ℕ → ℝ, (∀ K : ℕ, 2 ≤ K → 1 ≤ C_samp K) ∧
    ∀ (K : ℕ), 2 ≤ K →
      let m : ℕ := K - 1
      let C_K : ℝ := C_samp K
      let logMatchingLoss : ℝ → ZeroSumSubspace K → Fin K → ℝ :=
        fun T a y =>
          T * Real.log (∑ j : Fin K, Real.exp ((a : EuclideanSpace ℝ (Fin K)) j / T)) -
            (a : EuclideanSpace ℝ (Fin K)) y
      ∀ (L R β lam M T_min T_max : ℝ),
        0 < L → 0 < R → 0 < β → 0 < lam → 0 < M →
        (SmoothEntropyFamily K β lam M).Nonempty →
        0 < T_min → T_min ≤ T_max → (1 : ℝ) / (2 * β) ≤ T_min →
        let A : ℝ := L * R
        let D₀ : ℝ := M + A + β * lam * A
        let τ_of : ℝ → ℝ :=
          fun ε => min ((1 : ℝ) / 2) (ε / (8 * (Real.sqrt 2 * lam + 2 * T_max)))
        let D_τ_of : ℝ → ℝ :=
          fun ε =>
            M + A + T_max * Real.log ((K : ℝ) / τ_of ε) +
              β * A * (lam + (K : ℝ) * T_max / τ_of ε)
        let sampleBound : ℝ → ℝ → ℝ :=
          fun ε δ =>
            if m ≤ 2 then
              C_K * (D_τ_of ε / ε) ^ 2 * (Real.log (C_K * D_τ_of ε / (ε * δ))) ^ 2
            else
              C_K * ((D_τ_of ε / ε) ^ m + (D_τ_of ε / ε) ^ 2 * Real.log ((2 : ℝ) / δ))
        (∀ (δ : ℝ), 0 < δ → δ < (1 : ℝ) / 2 →
          ∃ (C_rate : ℝ) (q_log : ℕ), 0 < C_rate ∧
            ∀ (ε : ℝ), 0 < ε → ε ≤ D₀ →
              sampleBound ε δ ≤
                C_rate * ((1 : ℝ) / ε) ^ (if K ≤ 3 then 4 else 2 * (K - 1)) *
                  (Real.log ((2 : ℝ) + 1 / ε)) ^ q_log) ∧
        (∀ (X : Type*) [NormedAddCommGroup X] [InnerProductSpace ℝ X]
            [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
            [MeasurableSpace X] [BorelSpace X]
            (ε δ : ℝ),
          0 < δ → δ < (1 : ℝ) / 2 → 0 < ε → ε ≤ D₀ →
          let τ : ℝ := τ_of ε
          ∀ (n : ℕ), 1 ≤ n → (n : ℝ) ≥ sampleBound ε δ →
            ∃ (learnerW : (Fin n → X × Fin K) → (X →L[ℝ] ZeroSumSubspace K))
              (learnerRho : (Fin n → X × Fin K) →
                (ZeroSumSubspace K → EuclideanSpace ℝ (Fin K))),
              (∀ sample : Fin n → X × Fin K,
                let W : X →L[ℝ] ZeroSumSubspace K := learnerW sample
                let ρ_τ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) := learnerRho sample
                let p_τ : X → EuclideanSpace ℝ (Fin K) := fun x => ρ_τ (W x)
                hilbertSchmidtNorm W ≤ R ∧
                (∀ s : ZeroSumSubspace K, ρ_τ s ∈ Simplex K) ∧
                LipschitzWith (Real.toNNReal ((1 - τ) * β)) ρ_τ ∧
                (1 - τ) * β ≤ β ∧
                (∀ (x : X) (j : Fin K), τ / (K : ℝ) ≤ p_τ x j)) ∧
              ∀ (ν : MeasureTheory.Measure (X × Fin K)) [MeasureTheory.IsProbabilityMeasure ν],
                (∀ᵐ xy ∂ν, ‖xy.1‖ ≤ L) →
                ∀ (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
                  [MeasureTheory.IsProbabilityMeasure μ]
                  (X_samp : Fin n → Ω → X) (Y_samp : Fin n → Ω → Fin K),
                  (∀ i : Fin n, Measurable (X_samp i)) →
                  (∀ i : Fin n, Measurable (Y_samp i)) →
                  ProbabilityTheory.iIndepFun (fun i ω => (X_samp i ω, Y_samp i ω)) μ →
                  (∀ i : Fin n,
                    MeasureTheory.Measure.map (fun ω => (X_samp i ω, Y_samp i ω)) μ = ν) →
                  ∃ E : Set Ω, MeasurableSet E ∧ (μ E).toReal ≥ 1 - δ ∧
                    ∀ ω ∈ E,
                      let sample : Fin n → X × Fin K := fun i => (X_samp i ω, Y_samp i ω)
                      let W : X →L[ℝ] ZeroSumSubspace K := learnerW sample
                      let ρ_τ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) := learnerRho sample
                      let p_τ : X → EuclideanSpace ℝ (Fin K) := fun x => ρ_τ (W x)
                      (∀ Φ ∈ SmoothEntropyFamily K β lam M,
                        (∫ xy, finiteCanonicalLoss Φ (p_τ xy.1) xy.2 ∂ν) ≤
                          sInf ((fun V : X →L[ℝ] ZeroSumSubspace K =>
                            ∫ xy, matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 ∂ν) ''
                            {V | hilbertSchmidtNorm V ≤ R}) + ε) ∧
                      (∀ T ∈ Set.Icc T_min T_max,
                        (∫ xy, (-T * Real.log (p_τ xy.1 xy.2)) ∂ν) ≤
                          sInf ((fun V : X →L[ℝ] ZeroSumSubspace K =>
                            ∫ xy, logMatchingLoss T (V xy.1) xy.2 ∂ν) ''
                            {V | hilbertSchmidtNorm V ≤ R}) + ε))

end UL

import Mathlib
import UL.Def.def_2_1
import UL.Def.def_A_fit
set_option autoImplicit false

namespace UL

/-- Formal statement for arXiv Lemma B.3, residuals on a simplex face. See the scope in the theorem index. -/
def S_lem_A_3 : Prop :=
  ∀ (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (K : ℕ) (hK : 2 ≤ K)
    (B : ℝ) (hB : 0 < B)
    (S : Ω → ZeroSumSubspace K) (Y : Ω → Fin K)
    (hS_meas : Measurable S) (hY_meas : Measurable Y)
    (P : Ω → EuclideanSpace ℝ (Fin K))
    (hFit : IsLipschitzLSFit μ B S Y P),
    let eY : Ω → EuclideanSpace ℝ (Fin K) := oneHotLabel Y
    let ξ : Ω → EuclideanSpace ℝ (Fin K) := fitResidual P Y
    let projSimplex : EuclideanSpace ℝ (Fin K) → EuclideanSpace ℝ (Fin K) :=
      fun x =>
        open Classical in
        if h : ∃ q : EuclideanSpace ℝ (Fin K),
            q ∈ Simplex K ∧ IsMinOn (fun q' => ‖x - q'‖) (Simplex K) q then
          Classical.choose h
        else
          0
    (∀ j : Fin K, ∀ᵐ ω ∂μ, P ω j = 0 → eY ω j = 0) ∧
    (∀ v : Ω → ZeroSumSubspace K,
      MeasureTheory.Integrable v μ →
      (∀ (ω : Ω) (t : ℝ),
        P ω + t • (v ω : EuclideanSpace ℝ (Fin K)) ∈ affineSpan ℝ (Simplex K)) ∧
      Filter.Tendsto
        (fun t : ℝ =>
          ∫ ω, inner ℝ (ξ ω)
            (((1 : ℝ) / t) •
              (projSimplex (P ω + t • (v ω : EuclideanSpace ℝ (Fin K))) - P ω)) ∂μ)
        (nhdsWithin (0 : ℝ) (Set.Ioi 0))
        (nhds (∫ ω, inner ℝ (ξ ω) (v ω : EuclideanSpace ℝ (Fin K)) ∂μ)))

end UL

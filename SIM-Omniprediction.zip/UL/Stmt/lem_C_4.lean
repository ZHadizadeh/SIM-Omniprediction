import Mathlib
import UL.Def.def_2_1
set_option autoImplicit false

namespace UL

/-- ArXiv Lemma D.3 for all score dimensions, including zero. -/
def SimplexExtensionAllDimensions : Prop :=
  ∀ (m n K : ℕ)
    (hn : 1 ≤ n) (hK : 2 ≤ K)
    (s : Fin n → EuclideanSpace ℝ (Fin m))
    (p : Fin n → EuclideanSpace ℝ (Fin K))
    (hp : ∀ i : Fin n, p i ∈ Simplex K)
    (B : ℝ) (hB : 0 < B)
    (hLip : ∀ i j : Fin n, ‖p i - p j‖ ≤ B * ‖s i - s j‖),
    let S : Matrix (Fin m) (Fin n) ℝ := Matrix.of (fun r i => s i r)
    let P : Matrix (Fin K) (Fin n) ℝ := Matrix.of (fun k i => p i k)
    let d : EuclideanSpace ℝ (Fin n) :=
      (WithLp.equiv 2 (Fin n → ℝ)).symm (fun i => B ^ 2 * ‖s i‖ ^ 2 - ‖p i‖ ^ 2)
    let Q : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin n) → ℝ :=
      fun s₀ θ =>
        B ^ 2 * ‖Matrix.toEuclideanLin S θ - (2 : ℝ) • s₀‖ ^ 2 +
          ‖Matrix.toEuclideanLin P θ‖ ^ 2 + inner ℝ d θ
    (∀ s₀ : EuclideanSpace ℝ (Fin m), ∃ θ ∈ Simplex n, IsMinOn (Q s₀) (Simplex n) θ) ∧
    (∀ (s₀ : EuclideanSpace ℝ (Fin m)) (θ θ' : EuclideanSpace ℝ (Fin n)),
      θ ∈ Simplex n → IsMinOn (Q s₀) (Simplex n) θ →
      θ' ∈ Simplex n → IsMinOn (Q s₀) (Simplex n) θ' →
      Matrix.toEuclideanLin P θ = Matrix.toEuclideanLin P θ') ∧
    (∀ θ_s : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin n),
      (∀ s₀ : EuclideanSpace ℝ (Fin m),
        θ_s s₀ ∈ Simplex n ∧ IsMinOn (Q s₀) (Simplex n) (θ_s s₀)) →
      let ρ : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin K) :=
        fun s₀ => Matrix.toEuclideanLin P (θ_s s₀)
      (∀ s₀ : EuclideanSpace ℝ (Fin m), ρ s₀ ∈ convexHull ℝ (Set.range p)) ∧
      convexHull ℝ (Set.range p) ⊆ Simplex K ∧
      (∀ i : Fin n, ρ (s i) = p i) ∧
      LipschitzWith (Real.toNNReal B) ρ ∧
      (∀ (s₀ : EuclideanSpace ℝ (Fin m)) (θ_hat : EuclideanSpace ℝ (Fin n)) (ζ : ℝ),
        θ_hat ∈ Simplex n → 0 ≤ ζ →
        Q s₀ θ_hat ≤ sInf (Q s₀ '' Simplex n) + ζ →
        ‖Matrix.toEuclideanLin P θ_hat - ρ s₀‖ ≤ Real.sqrt ζ))

/-- Positive-dimensional specialization used by existing callers. -/
def S_lem_C_4 : Prop :=
  ∀ (m n K : ℕ)
    (hm : 1 ≤ m) (hn : 1 ≤ n) (hK : 2 ≤ K)
    (s : Fin n → EuclideanSpace ℝ (Fin m))
    (p : Fin n → EuclideanSpace ℝ (Fin K))
    (hp : ∀ i : Fin n, p i ∈ Simplex K)
    (B : ℝ) (hB : 0 < B)
    (hLip : ∀ i j : Fin n, ‖p i - p j‖ ≤ B * ‖s i - s j‖),
    let S : Matrix (Fin m) (Fin n) ℝ := Matrix.of (fun r i => s i r)
    let P : Matrix (Fin K) (Fin n) ℝ := Matrix.of (fun k i => p i k)
    let d : EuclideanSpace ℝ (Fin n) :=
      (WithLp.equiv 2 (Fin n → ℝ)).symm (fun i => B ^ 2 * ‖s i‖ ^ 2 - ‖p i‖ ^ 2)
    let Q : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin n) → ℝ :=
      fun s₀ θ =>
        B ^ 2 * ‖Matrix.toEuclideanLin S θ - (2 : ℝ) • s₀‖ ^ 2 +
          ‖Matrix.toEuclideanLin P θ‖ ^ 2 + inner ℝ d θ
    (∀ s₀ : EuclideanSpace ℝ (Fin m), ∃ θ ∈ Simplex n, IsMinOn (Q s₀) (Simplex n) θ) ∧
    (∀ (s₀ : EuclideanSpace ℝ (Fin m)) (θ θ' : EuclideanSpace ℝ (Fin n)),
      θ ∈ Simplex n → IsMinOn (Q s₀) (Simplex n) θ →
      θ' ∈ Simplex n → IsMinOn (Q s₀) (Simplex n) θ' →
      Matrix.toEuclideanLin P θ = Matrix.toEuclideanLin P θ') ∧
    (∀ θ_s : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin n),
      (∀ s₀ : EuclideanSpace ℝ (Fin m),
        θ_s s₀ ∈ Simplex n ∧ IsMinOn (Q s₀) (Simplex n) (θ_s s₀)) →
      let ρ : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin K) :=
        fun s₀ => Matrix.toEuclideanLin P (θ_s s₀)
      (∀ s₀ : EuclideanSpace ℝ (Fin m), ρ s₀ ∈ convexHull ℝ (Set.range p)) ∧
      convexHull ℝ (Set.range p) ⊆ Simplex K ∧
      (∀ i : Fin n, ρ (s i) = p i) ∧
      LipschitzWith (Real.toNNReal B) ρ ∧
      (∀ (s₀ : EuclideanSpace ℝ (Fin m)) (θ_hat : EuclideanSpace ℝ (Fin n)) (ζ : ℝ),
        θ_hat ∈ Simplex n → 0 ≤ ζ →
        Q s₀ θ_hat ≤ sInf (Q s₀ '' Simplex n) + ζ →
        ‖Matrix.toEuclideanLin P θ_hat - ρ s₀‖ ≤ Real.sqrt ζ))

end UL

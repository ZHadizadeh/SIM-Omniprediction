import Mathlib
import UL.Def.def_2_1
import UL.Def.def_2_matching
import UL.Def.def_5_smooth
set_option autoImplicit false

namespace UL

/-- Formal statement for arXiv Lemma D.1, empirical simultaneous comparison. See the scope in the theorem index. -/
def S_lem_C_2 : Prop :=
  ∀ (K : ℕ) (_hK : 2 ≤ K)
    (X : Type*) [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    (n : ℕ) (_hn : 1 ≤ n)
    (x : Fin n → X) (y : Fin n → Fin K)
    (L R β B lam M : ℝ)
    (_hL : 0 < L) (_hx : ∀ i : Fin n, ‖x i‖ ≤ L)
    (_hR : 0 < R) (_hβ : 0 < β) (_hB : β ≤ B)
    (_hlam : 0 < lam) (_hM : 0 < M),
    let u : EuclideanSpace ℝ (Fin K) := uniformVec K
    let A : ℝ := L * R
    let memCenteredSimplex : ZeroSumSubspace K → Prop :=
      fun p => u + (p : EuclideanSpace ℝ (Fin K)) ∈ Simplex K
    let isBLip : (ZeroSumSubspace K → ZeroSumSubspace K) → Prop :=
      fun rhoTilde =>
        (∀ s : ZeroSumSubspace K, ‖s‖ ≤ A → memCenteredSimplex (rhoTilde s)) ∧
        (∀ s s' : ZeroSumSubspace K, ‖s‖ ≤ A → ‖s'‖ ≤ A → ‖rhoTilde s - rhoTilde s'‖ ≤ B * ‖s - s'‖)
    ∃ Z : Fin n → ZeroSumSubspace K,
      (∀ i : Fin n, (Z i : EuclideanSpace ℝ (Fin K)) = EuclideanSpace.single (y i) (1 : ℝ) - u) ∧
      let isOptimalFit : (X →L[ℝ] ZeroSumSubspace K) → (Fin n → ZeroSumSubspace K) → Prop :=
        fun W pTilde =>
          (∃ rhoTilde : ZeroSumSubspace K → ZeroSumSubspace K,
            isBLip rhoTilde ∧ ∀ i : Fin n, pTilde i = rhoTilde (W (x i))) ∧
          (∀ otherProfile : ZeroSumSubspace K → ZeroSumSubspace K, isBLip otherProfile →
            (1 / (n : ℝ)) * ∑ i : Fin n, ‖pTilde i - Z i‖ ^ 2 ≤
              (1 / (n : ℝ)) * ∑ i : Fin n, ‖otherProfile (W (x i)) - Z i‖ ^ 2)
      let gamma_n : (X →L[ℝ] ZeroSumSubspace K) → (Fin n → ZeroSumSubspace K) → ℝ :=
        fun W pTilde =>
          let gₙ : X →L[ℝ] ZeroSumSubspace K :=
            (1 / (n : ℝ)) • ∑ i : Fin n, (innerSL ℝ (x i)).smulRight (pTilde i - Z i)
          ((1 : ℝ) / 4) * (hilbertSchmidtNorm (gₙ + W) ^ 2 - hilbertSchmidtNorm (gₙ - W) ^ 2) +
            R * hilbertSchmidtNorm gₙ
      (∀ W : X →L[ℝ] ZeroSumSubspace K, hilbertSchmidtNorm W ≤ R →
        (∃ pTilde : Fin n → ZeroSumSubspace K,
          isOptimalFit W pTilde ∧ (∀ otherCenteredFit : Fin n → ZeroSumSubspace K, isOptimalFit W otherCenteredFit → otherCenteredFit = pTilde)) ∧
        (∀ pTilde : Fin n → ZeroSumSubspace K, isOptimalFit W pTilde →
          ∀ Φ ∈ SmoothEntropyFamily K β lam M,
            (1 / (n : ℝ)) * ∑ i : Fin n,
                finiteCanonicalLoss Φ (u + (pTilde i : EuclideanSpace ℝ (Fin K))) (y i) ≤
              (⨅ V : {V : X →L[ℝ] ZeroSumSubspace K // hilbertSchmidtNorm V ≤ R},
                (1 / (n : ℝ)) * ∑ i : Fin n,
                  matchingLoss Φ ((V.1 (x i) : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) (y i)) +
                gamma_n W pTilde)) ∧
      (∃ W : X →L[ℝ] ZeroSumSubspace K,
        hilbertSchmidtNorm W ≤ R ∧
        (∀ v ∈ (Submodule.span ℝ (Set.range x))ᗮ, W v = 0) ∧
        ∃ pTilde : Fin n → ZeroSumSubspace K, isOptimalFit W pTilde ∧ gamma_n W pTilde = 0)

end UL

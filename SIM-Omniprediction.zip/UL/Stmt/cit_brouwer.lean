import Mathlib
set_option autoImplicit false

namespace UL

/-- Auxiliary statement used by the arXiv proofs. -/
def S_cit_brouwer : Prop :=
  ∀ (E : Type*) [NormedAddCommGroup E] [InnerProductSpace ℝ E] [FiniteDimensional ℝ E]
    (C : Set E),
    C.Nonempty → IsCompact C → Convex ℝ C →
    ∀ (f : C → C), Continuous f → ∃ x : C, f x = x

end UL

import Mathlib
set_option autoImplicit false

namespace UL

/-- Auxiliary statement used by the arXiv proofs. -/
def S_cit_mcdiarmid1989 : Prop :=
  ∀ (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (n : ℕ) (α : Fin n → Type*) [∀ i, MeasurableSpace (α i)]
    (Z : ∀ i : Fin n, Ω → α i)
    (hZ_meas : ∀ i : Fin n, Measurable (Z i))
    (hZ_indep : ProbabilityTheory.iIndepFun Z μ)
    (g : (∀ i : Fin n, α i) → ℝ) (c : Fin n → ℝ)
    (hg_meas : Measurable g)
    (hg_diff : ∀ (i : Fin n) (z : ∀ j : Fin n, α j) (z' : α i),
      |g z - g (Function.update z i z')| ≤ c i)
    (hc_nonneg : ∀ i : Fin n, 0 ≤ c i),
    (∀ t : ℝ, 0 ≤ t →
      (μ {ω | g (fun i => Z i ω) - (∫ ω', g (fun i => Z i ω') ∂μ) ≥ t}).toReal ≤
        if (∑ i, c i ^ 2) = 0 then (if t = 0 then 1 else 0)
        else Real.exp (-2 * t ^ 2 / (∑ i, c i ^ 2))) ∧
    (∀ δ : ℝ, 0 < δ → δ < 1 →
      (μ {ω | |g (fun i => Z i ω) - (∫ ω', g (fun i => Z i ω') ∂μ)| ≤
          Real.sqrt ((1 / 2 : ℝ) * (∑ i, c i ^ 2) * Real.log (2 / δ))}).toReal ≥ 1 - δ ∧
      (μ {ω | g (fun i => Z i ω) - (∫ ω', g (fun i => Z i ω') ∂μ) ≤
          Real.sqrt ((1 / 2 : ℝ) * (∑ i, c i ^ 2) * Real.log (1 / δ))}).toReal ≥ 1 - δ)

end UL

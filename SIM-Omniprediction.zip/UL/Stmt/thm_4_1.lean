import Mathlib
import UL.Def.def_2_1
import UL.Def.def_2_matching
import UL.Def.def_2_2
set_option autoImplicit false

namespace UL

/-- Theorem 1.3 for feature dimension d = K − 1. The general statement is in `UL.Arxiv.Tradeoff.AllDimensions`. -/
def S_thm_4_1 : Prop :=
  ∀ (K : ℕ) (hK : 2 ≤ K) (R β L : ℝ) (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    (hcond : β * R * L / Real.sqrt ((K : ℝ) - 1) < 1 / (K : ℝ)),
    let m : ℕ := K - 1
    let c : ℝ := β * R / Real.sqrt (m : ℝ)
    ∃ (P : MeasureTheory.Measure (EuclideanSpace ℝ (Fin m) × Fin K))
      (Φ : Simplex K → ℝ),
      let X : EuclideanSpace ℝ (Fin m) × Fin K → EuclideanSpace ℝ (Fin m) := Prod.fst
      let Y : EuclideanSpace ℝ (Fin m) × Fin K → Fin K := Prod.snd
      let bench : EReal := ⨅ V ∈ ComparatorBall m K R, expectedMatchingLoss P X Y Φ V
      let feasibleForecasts : ℕ → ℝ → Set (EuclideanSpace ℝ (Fin m) → Simplex K) :=
        fun r B =>
          {p | ∃ (k : ℕ), k ≤ r ∧
            ∃ (A : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] EuclideanSpace ℝ (Fin k))
              (h : EuclideanSpace ℝ (Fin k) → Simplex K),
              frobeniusNorm A ≤ R ∧
              LipschitzWith (Real.toNNReal B) h ∧
              ∀ x : EuclideanSpace ℝ (Fin m), p x = h (A x)}
      MeasureTheory.IsProbabilityMeasure P ∧
      MeasureTheory.pdf.IsUniform X
        (Metric.ball (0 : EuclideanSpace ℝ (Fin m)) L) P MeasureTheory.volume ∧
      Φ ∈ EntropyFamily K β ∧
      (∃ (Q : QuadraticForm ℝ (EuclideanSpace ℝ (Fin K)))
         (ℓ : EuclideanSpace ℝ (Fin K) →ₗ[ℝ] ℝ) (c₀ : ℝ),
        ∀ q : Simplex K,
          Φ q = Q (q : EuclideanSpace ℝ (Fin K)) + ℓ (q : EuclideanSpace ℝ (Fin K)) + c₀) ∧
      (∀ (r : ℕ), 1 ≤ r → r ≤ m → ∀ (B : ℝ), 0 ≤ B →
        let val : ℝ :=
          (L ^ 2 / (2 * β * ((m : ℝ) + 2))) *
            (((m : ℝ) - (r : ℝ)) * c ^ 2 +
              (r : ℝ) * (max (c - B * R / Real.sqrt (r : ℝ)) 0) ^ 2)
        (⨅ p ∈ feasibleForecasts r B, (expectedCanonicalLoss P X Y Φ p - bench)) =
          ((val : ℝ) : EReal) ∧
        (∃ p ∈ feasibleForecasts r B,
          expectedCanonicalLoss P X Y Φ p - bench = ((val : ℝ) : EReal))) ∧
      (∀ (B : ℝ), 0 ≤ B →
        let val₀ : ℝ := L ^ 2 * (m : ℝ) * c ^ 2 / (2 * β * ((m : ℝ) + 2))
        (⨅ p ∈ feasibleForecasts 0 B, (expectedCanonicalLoss P X Y Φ p - bench)) =
          ((val₀ : ℝ) : EReal) ∧
        (∃ p ∈ feasibleForecasts 0 B,
          expectedCanonicalLoss P X Y Φ p - bench = ((val₀ : ℝ) : EReal)))

end UL

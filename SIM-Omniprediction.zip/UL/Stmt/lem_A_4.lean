import Mathlib
import UL.Def.def_2_1
import UL.Def.def_A_fit
set_option autoImplicit false

namespace UL

/-- Formal statement for arXiv Lemma B.4, convex tests and own-score inequality. See the scope in the theorem index. -/
def S_lem_A_4 : Prop :=
  ∀ (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (K : ℕ) (B : ℝ)
    (S : Ω → ZeroSumSubspace K) (Y : Ω → Fin K)
    (P : Ω → EuclideanSpace ℝ (Fin K)),
    0 < B →
    MeasureTheory.Integrable S μ →
    Measurable Y →
    IsLipschitzLSFit μ B S Y P →
    (∫ ω, fitResidual P Y ω ∂μ = 0) ∧
    (∀ (f : ZeroSumSubspace K → ℝ),
      Differentiable ℝ f →
      ConvexOn ℝ Set.univ f →
      (∃ L : NNReal, LipschitzWith L (gradient f)) →
      ∫ ω, inner ℝ (fitResidual P Y ω)
        (↑(gradient f ((ZeroSumSubspace K).orthogonalProjection (P ω - uniformVec K))) :
          EuclideanSpace ℝ (Fin K)) ∂μ ≤ 0) ∧
    (B * ∫ ω, inner ℝ (fitResidual P Y ω) (S ω : EuclideanSpace ℝ (Fin K)) ∂μ ≥
      ∫ ω, inner ℝ (fitResidual P Y ω) (P ω - uniformVec K) ∂μ)

end UL

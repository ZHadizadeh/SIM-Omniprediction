import UL.Stmt.lem_A_5
import Mathlib

set_option autoImplicit false

namespace UL.Proof_lem_A_5

open scoped RealInnerProductSpace
open Set Filter Topology MeasureTheory

@[simp]
lemma onesVec_apply (K : ℕ) (j : Fin K) : UL.onesVec K j = 1 := rfl

@[simp]
lemma uniformVec_apply (K : ℕ) (j : Fin K) : UL.uniformVec K j = 1 / (K : ℝ) := by
  simp [UL.uniformVec]

lemma sum_uniformVec {K : ℕ} (hK : 2 ≤ K) : ∑ j : Fin K, UL.uniformVec K j = 1 := by
  have hK0 : (K : ℝ) ≠ 0 := by exact_mod_cast (by omega : K ≠ 0)
  simp [Finset.sum_const, nsmul_eq_mul, mul_inv_cancel₀ hK0]

lemma uniformVec_mem_simplexFaceRelint_univ {K : ℕ} (hK : 2 ≤ K) :
    UL.uniformVec K ∈ UL.SimplexFaceRelint K Finset.univ := by
  have hKpos : (0 : ℝ) < K := by exact_mod_cast (by omega : 0 < K)
  refine ⟨⟨⟨fun j => ?_, sum_uniformVec hK⟩, fun j hj => False.elim (hj (Finset.mem_univ j))⟩,
    fun j _ => ?_⟩
  · simp only [uniformVec_apply]
    positivity
  · simp only [uniformVec_apply]
    positivity

lemma uniformVec_mem_simplex {K : ℕ} (hK : 2 ≤ K) :
    UL.uniformVec K ∈ UL.Simplex K :=
  (uniformVec_mem_simplexFaceRelint_univ hK).1.1

lemma mem_zeroSumSubspace_iff (K : ℕ) (v : EuclideanSpace ℝ (Fin K)) :
    v ∈ UL.ZeroSumSubspace K ↔ ∑ j : Fin K, v j = 0 := by
  simp [UL.ZeroSumSubspace, LinearMap.mem_ker, PiLp.inner_apply]

lemma mem_faceTangentSpace_iff (K : ℕ) (J : Finset (Fin K)) (v : EuclideanSpace ℝ (Fin K)) :
    v ∈ UL.FaceTangentSpace K J ↔ (∑ j : Fin K, v j = 0) ∧ (∀ j : Fin K, j ∉ J → v j = 0) := by
  simp [UL.FaceTangentSpace, Submodule.mem_inf, Submodule.mem_iInf,
    mem_zeroSumSubspace_iff, LinearMap.mem_ker]

lemma faceTangentSpace_univ (K : ℕ) :
    UL.FaceTangentSpace K Finset.univ = UL.ZeroSumSubspace K := by
  ext v
  simp [mem_faceTangentSpace_iff, mem_zeroSumSubspace_iff]

lemma simplexFace_univ (K : ℕ) :
    UL.SimplexFace K Finset.univ = UL.Simplex K := by
  ext q
  simp [UL.SimplexFace]

lemma simplexFace_subset_simplex (K : ℕ) (J : Finset (Fin K)) :
    UL.SimplexFace K J ⊆ UL.Simplex K :=
  fun _ hq => hq.1

lemma simplexFaceRelint_subset_simplexFace (K : ℕ) (J : Finset (Fin K)) :
    UL.SimplexFaceRelint K J ⊆ UL.SimplexFace K J :=
  fun _ hq => hq.1

lemma simplexFaceRelint_subset_simplex (K : ℕ) (J : Finset (Fin K)) :
    UL.SimplexFaceRelint K J ⊆ UL.Simplex K :=
  fun _ hq => hq.1.1

lemma sub_mem_zeroSumSubspace_of_mem_simplex {K : ℕ} {p q : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ UL.Simplex K) (hq : q ∈ UL.Simplex K) :
    p - q ∈ UL.ZeroSumSubspace K := by
  rw [mem_zeroSumSubspace_iff]
  simp [Finset.sum_sub_distrib, hp.2, hq.2]

lemma coe_orthogonalProjection_of_mem_zeroSumSubspace {K : ℕ} {v : EuclideanSpace ℝ (Fin K)}
    (hv : v ∈ UL.ZeroSumSubspace K) :
    ((UL.ZeroSumSubspace K).orthogonalProjection v : EuclideanSpace ℝ (Fin K)) = v := by
  rw [Submodule.orthogonalProjection_mem_subspace_eq_self ⟨v, hv⟩]

lemma coe_orthogonalProjection_sub_uniformVec {K : ℕ} {p : EuclideanSpace ℝ (Fin K)}
    (hK : 2 ≤ K) (hp : p ∈ UL.Simplex K) :
    ((UL.ZeroSumSubspace K).orthogonalProjection (p - UL.uniformVec K) :
      EuclideanSpace ℝ (Fin K)) = p - UL.uniformVec K :=
  coe_orthogonalProjection_of_mem_zeroSumSubspace
    (sub_mem_zeroSumSubspace_of_mem_simplex hp (uniformVec_mem_simplex hK))

lemma oneHotVec_mem_simplex {K : ℕ} (y : Fin K) : UL.oneHotVec y ∈ UL.Simplex K := by
  refine ⟨fun j => ?_, ?_⟩
  · simp only [UL.oneHotVec, EuclideanSpace.single_apply]
    split_ifs <;> norm_num
  · simp [UL.oneHotVec, EuclideanSpace.single_apply]

lemma oneHotLabel_mem_simplex {Ω : Type*} {K : ℕ} (Y : Ω → Fin K) (ω : Ω) :
    UL.oneHotLabel Y ω ∈ UL.Simplex K :=
  oneHotVec_mem_simplex (Y ω)

lemma norm_le_one_of_mem_simplex {K : ℕ} {q : EuclideanSpace ℝ (Fin K)}
    (hq : q ∈ UL.Simplex K) : ‖q‖ ≤ 1 := by
  have hsq : ‖q‖ ^ 2 ≤ 1 ^ 2 := by
    rw [EuclideanSpace.norm_sq_eq]
    have hle : ∑ i : Fin K, ‖q i‖ ^ 2 ≤ (∑ i : Fin K, q i) ^ 2 := by
      have h1 : ∑ i : Fin K, ‖q i‖ ^ 2 = ∑ i : Fin K, q i * q i := by
        refine Finset.sum_congr rfl fun i _ => ?_
        rw [Real.norm_of_nonneg (hq.1 i), sq]
      rw [h1, hq.2, one_pow, ← hq.2]
      refine Finset.sum_le_sum fun i _ => ?_
      have hi_le : q i ≤ 1 := by
        rw [← hq.2]
        exact Finset.single_le_sum (fun j _ => hq.1 j) (Finset.mem_univ i)
      nlinarith [hq.1 i]
    simpa [hq.2] using hle
  nlinarith [norm_nonneg q]

lemma norm_fitResidual_le_two {Ω : Type*} {K : ℕ}
    {P : Ω → EuclideanSpace ℝ (Fin K)} (Y : Ω → Fin K)
    (hP : ∀ ω, P ω ∈ UL.Simplex K) (ω : Ω) :
    ‖UL.fitResidual P Y ω‖ ≤ 2 := by
  calc
    ‖UL.fitResidual P Y ω‖ = ‖P ω - UL.oneHotLabel Y ω‖ := rfl
    _ ≤ ‖P ω‖ + ‖UL.oneHotLabel Y ω‖ := norm_sub_le _ _
    _ ≤ 1 + 1 := add_le_add (norm_le_one_of_mem_simplex (hP ω))
        (norm_le_one_of_mem_simplex (oneHotLabel_mem_simplex Y ω))
    _ = 2 := by norm_num

lemma isClosed_simplex (K : ℕ) : IsClosed (UL.Simplex K) := by
  have h1 : IsClosed {q : EuclideanSpace ℝ (Fin K) | ∀ j : Fin K, 0 ≤ q j} := by
    simpa [setOf_forall] using isClosed_iInter fun j : Fin K =>
      isClosed_le continuous_const (EuclideanSpace.proj j).continuous
  have h2 : IsClosed {q : EuclideanSpace ℝ (Fin K) | ∑ j : Fin K, q j = 1} :=
    isClosed_eq (continuous_finset_sum _ fun j _ => (EuclideanSpace.proj j).continuous)
      continuous_const
  exact h1.inter h2

lemma isCompact_simplex (K : ℕ) : IsCompact (UL.Simplex K) := by
  refine Metric.isCompact_of_isClosed_isBounded (isClosed_simplex K) ?_
  rw [isBounded_iff_forall_norm_le]
  exact ⟨1, fun q hq => norm_le_one_of_mem_simplex hq⟩

lemma convex_simplex (K : ℕ) : Convex ℝ (UL.Simplex K) := by
  intro p hp q hq a b ha hb hab
  refine ⟨fun j => ?_, ?_⟩
  · simp only [PiLp.add_apply, PiLp.smul_apply, smul_eq_mul]
    exact add_nonneg (mul_nonneg ha (hp.1 j)) (mul_nonneg hb (hq.1 j))
  · simp only [PiLp.add_apply, PiLp.smul_apply, smul_eq_mul,
      Finset.sum_add_distrib, ← Finset.mul_sum, hp.2, hq.2, mul_one]
    exact hab

lemma convex_simplexFace (K : ℕ) (J : Finset (Fin K)) : Convex ℝ (UL.SimplexFace K J) := by
  intro p hp q hq a b ha hb hab
  refine ⟨convex_simplex K hp.1 hq.1 ha hb hab, fun j hj => ?_⟩
  simp [hp.2 j hj, hq.2 j hj]

lemma extendSimplex_eq_of_mem {K : ℕ} (F : UL.Simplex K → ℝ)
    {q : EuclideanSpace ℝ (Fin K)} (hq : q ∈ UL.Simplex K) :
    UL.extendSimplex F q = F ⟨q, hq⟩ := by
  simp [UL.extendSimplex, hq]

lemma continuousOn_extendSimplex {K : ℕ} {F : UL.Simplex K → ℝ} (hF : Continuous F) :
    ContinuousOn (UL.extendSimplex F) (UL.Simplex K) := by
  rw [continuousOn_iff_continuous_restrict]
  convert hF using 1
  ext ⟨q, hq⟩
  simp [UL.extendSimplex, hq]

lemma exists_oscillation_bound {K : ℕ} (hK : 2 ≤ K) {F : UL.Simplex K → ℝ}
    (hF : Continuous F) :
    ∃ oscBound : ℝ, 0 ≤ oscBound ∧ ∀ p ∈ UL.Simplex K, ∀ q ∈ UL.Simplex K,
      UL.extendSimplex F p - UL.extendSimplex F q ≤ oscBound := by
  have hne : (UL.Simplex K).Nonempty := ⟨UL.uniformVec K, uniformVec_mem_simplex hK⟩
  have hcomp : IsCompact (UL.Simplex K) := isCompact_simplex K
  have hcont : ContinuousOn (UL.extendSimplex F) (UL.Simplex K) := continuousOn_extendSimplex hF
  obtain ⟨p_max, hp_max, hmax⟩ := hcomp.exists_isMaxOn hne hcont
  obtain ⟨p_min, hp_min, hmin⟩ := hcomp.exists_isMinOn hne hcont
  rw [isMaxOn_iff] at hmax
  rw [isMinOn_iff] at hmin
  refine ⟨UL.extendSimplex F p_max - UL.extendSimplex F p_min, ?_, fun p hp q hq => ?_⟩
  · have := hmin p_max hp_max
    linarith
  · have h1 : UL.extendSimplex F p ≤ UL.extendSimplex F p_max := hmax p hp
    have h2 : UL.extendSimplex F p_min ≤ UL.extendSimplex F q := hmin q hq
    linarith

lemma support_nonempty_and_mem_relint {K : ℕ} {p : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ UL.Simplex K) :
    let J := open Classical in Finset.univ.filter (fun j : Fin K => 0 < p j)
    J.Nonempty ∧ p ∈ UL.SimplexFaceRelint K J := by
  classical
  dsimp only
  set J := Finset.univ.filter (fun j : Fin K => 0 < p j)
  have hmem : p ∈ UL.SimplexFaceRelint K J := by
    refine ⟨⟨hp, fun j hj => ?_⟩, fun j hj => (Finset.mem_filter.mp hj).2⟩
    have hj' : ¬ (0 < p j) := fun hpos => hj (Finset.mem_filter.mpr ⟨Finset.mem_univ j, hpos⟩)
    linarith [hp.1 j]
  have hne : J.Nonempty := by
    by_contra h_empty
    rw [Finset.not_nonempty_iff_eq_empty] at h_empty
    have hzero : ∀ j : Fin K, p j = 0 := fun j => by
      have hj : j ∉ J := by simp [h_empty]
      exact hmem.1.2 j hj
    have hsum : ∑ j : Fin K, p j = 0 := Finset.sum_eq_zero fun j _ => hzero j
    linarith [hp.2]
  exact ⟨hne, hmem⟩

lemma fitResidual_mem_faceTangentSpace_ae {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} {K : ℕ}
    {P : Ω → EuclideanSpace ℝ (Fin K)} {Y : Ω → Fin K}
    (hP : ∀ ω, P ω ∈ UL.Simplex K)
    (hsupp : ∀ j : Fin K, ∀ᵐ ω ∂μ, P ω j = 0 → UL.oneHotLabel Y ω j = 0) :
    ∀ᵐ ω ∂μ, UL.fitResidual P Y ω ∈
      UL.FaceTangentSpace K (open Classical in Finset.univ.filter (fun j : Fin K => 0 < P ω j)) := by
  have hall : ∀ᵐ ω ∂μ, ∀ j : Fin K, P ω j = 0 → UL.oneHotLabel Y ω j = 0 :=
    ae_all_iff.mpr hsupp
  filter_upwards [hall] with ω hω
  classical
  rw [mem_faceTangentSpace_iff]
  refine ⟨?_, fun j hj => ?_⟩
  · rw [← mem_zeroSumSubspace_iff]
    exact sub_mem_zeroSumSubspace_of_mem_simplex (hP ω) (oneHotLabel_mem_simplex Y ω)
  · have hnotpos : ¬ (0 < P ω j) := fun hpos =>
      hj (Finset.mem_filter.mpr ⟨Finset.mem_univ j, hpos⟩)
    have hp0 : P ω j = 0 := le_antisymm (not_lt.mp hnotpos) ((hP ω).1 j)
    have hz0 : UL.oneHotLabel Y ω j = 0 := hω j hp0
    simp [UL.fitResidual, hp0, hz0]

lemma trimmed_mem_simplexFaceRelint_univ {K : ℕ} (hK : 2 ≤ K)
    {p : EuclideanSpace ℝ (Fin K)} (hp : p ∈ UL.Simplex K)
    {ε : ℝ} (hε0 : 0 < ε) (hε1 : ε < 1) :
    (1 - ε) • p + ε • UL.uniformVec K ∈ UL.SimplexFaceRelint K Finset.univ := by
  have h1e : 0 ≤ 1 - ε := by linarith
  have hu := uniformVec_mem_simplexFaceRelint_univ hK
  have hmem : (1 - ε) • p + ε • UL.uniformVec K ∈ UL.Simplex K :=
    convex_simplex K hp hu.1.1 h1e hε0.le (by ring)
  refine ⟨⟨hmem, fun j hj => False.elim (hj (Finset.mem_univ j))⟩, fun j hj => ?_⟩
  simp only [PiLp.add_apply, PiLp.smul_apply, smul_eq_mul]
  have h1 : 0 ≤ (1 - ε) * p j := mul_nonneg h1e (hp.1 j)
  have h2 : 0 < ε * UL.uniformVec K j := mul_pos hε0 (hu.2 j hj)
  linarith

lemma faceGrad_spec {K : ℕ} {F : UL.Simplex K → ℝ} {J : Finset (Fin K)}
    {p : EuclideanSpace ℝ (Fin K)} (h : ∃ g, UL.HasFaceGradAt F J p g) :
    UL.HasFaceGradAt F J p (UL.faceGrad F J p) := by
  classical
  simp only [UL.faceGrad, dif_pos h]
  exact Classical.choose_spec h

/-- Supporting hyperplane / subgradient inequality on any face `SimplexFace K J`. -/
lemma subgradient_ineq_of_hasFaceGradAt {K : ℕ} {F : UL.Simplex K → ℝ}
    (hF_conv : ConvexOn ℝ (UL.Simplex K) (UL.extendSimplex F))
    {J : Finset (Fin K)} {p g q : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ UL.SimplexFace K J) (hg : UL.HasFaceGradAt F J p g)
    (hq : q ∈ UL.SimplexFace K J) :
    ⟪g, q - p⟫ ≤ UL.extendSimplex F q - UL.extendSimplex F p := by
  let γ : ℝ → EuclideanSpace ℝ (Fin K) := fun t => p + t • (q - p)
  have hγ0 : γ 0 = p := by simp [γ]
  have hγ_deriv : HasDerivAt γ (q - p) 0 := by
    have h1 : HasDerivAt (fun t : ℝ => t • (q - p)) ((1 : ℝ) • (q - p)) 0 :=
      (hasDerivAt_id (0 : ℝ)).smul_const (q - p)
    simpa [γ] using h1.const_add p
  have hγ_maps : MapsTo γ (Ioo (0 : ℝ) 1) (UL.SimplexFace K J) := by
    intro t ht
    have hγt : γ t = (1 - t) • p + t • q := by
      simp [γ, sub_smul, smul_sub]
      abel
    rw [hγt]
    exact convex_simplexFace K J hp hq (by linarith [ht.2]) ht.1.le (by ring)
  have hγ_within : HasDerivWithinAt γ (q - p) (Ioo (0 : ℝ) 1) 0 :=
    hγ_deriv.hasDerivWithinAt
  have hcomp : HasDerivWithinAt (fun t : ℝ => UL.extendSimplex F (γ t))
      ((innerSL ℝ g) (q - p)) (Ioo (0 : ℝ) 1) 0 := by
    have hf : HasFDerivWithinAt (UL.extendSimplex F) (innerSL ℝ g) (UL.SimplexFace K J) (γ 0) := by
      rw [hγ0]; exact hg.2
    exact hf.comp_hasDerivWithinAt 0 hγ_within hγ_maps
  have hslope_tendsto : Tendsto
      (fun t : ℝ => (UL.extendSimplex F (γ t) - UL.extendSimplex F p) / t)
      (𝓝[>] (0 : ℝ)) (𝓝 ⟪g, q - p⟫) := by
    have hdiff : Ioo (0 : ℝ) 1 \ {0} = Ioo (0 : ℝ) 1 := by
      ext x
      simp only [mem_diff, mem_Ioo, mem_singleton_iff, and_iff_left_iff_imp]
      intro hx
      linarith [hx.1]
    have hnhds : 𝓝[Ioo (0 : ℝ) 1] (0 : ℝ) = 𝓝[>] (0 : ℝ) :=
      nhdsWithin_Ioo_eq_nhdsGT zero_lt_one
    rw [hasDerivWithinAt_iff_tendsto_slope, hdiff, hnhds] at hcomp
    have hcongr : (fun t : ℝ => (UL.extendSimplex F (γ t) - UL.extendSimplex F p) / t) =ᶠ[𝓝[>] 0]
        slope (fun t : ℝ => UL.extendSimplex F (γ t)) 0 := by
      filter_upwards [self_mem_nhdsWithin] with t _
      simp [slope_def_field, hγ0]
    simpa [innerSL_apply_apply] using hcomp.congr' hcongr.symm
  have hslope_le : ∀ᶠ t : ℝ in 𝓝[>] (0 : ℝ),
      (UL.extendSimplex F (γ t) - UL.extendSimplex F p) / t ≤
        UL.extendSimplex F q - UL.extendSimplex F p := by
    filter_upwards [Ioo_mem_nhdsGT zero_lt_one] with t ht
    have hγt : γ t = (1 - t) • p + t • q := by
      simp [γ, sub_smul, smul_sub]
      abel
    have hconv_ineq : UL.extendSimplex F (γ t) ≤
        (1 - t) * UL.extendSimplex F p + t * UL.extendSimplex F q := by
      rw [hγt]
      exact hF_conv.2 hp.1 hq.1 (by linarith [ht.2]) ht.1.le (by ring)
    rw [div_le_iff₀ ht.1]
    linarith
  exact le_of_tendsto hslope_tendsto hslope_le

/-- Perturbing `p ∈ SimplexFaceRelint K J` along `v ∈ FaceTangentSpace K J` stays in
`SimplexFaceRelint K J` for small `|t|`. -/
lemma exists_relint_perturbation {K : ℕ} {J : Finset (Fin K)} (hJ : J.Nonempty)
    {p v : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ UL.SimplexFaceRelint K J) (hv : v ∈ UL.FaceTangentSpace K J) :
    ∃ h₀ : ℝ, 0 < h₀ ∧ ∀ t : ℝ, |t| ≤ h₀ → p + t • v ∈ UL.SimplexFaceRelint K J := by
  obtain ⟨hv_sum, hv_out⟩ := (mem_faceTangentSpace_iff K J v).mp hv
  let m : ℝ := J.inf' hJ (fun j => p j)
  have hm_pos : 0 < m := (Finset.lt_inf'_iff hJ).mpr fun j hj => hp.2 j hj
  let h₀ : ℝ := m / (2 * (‖v‖ + 1))
  have hh₀_pos : 0 < h₀ := by
    have : 0 < 2 * (‖v‖ + 1) := by positivity
    exact div_pos hm_pos this
  refine ⟨h₀, hh₀_pos, fun t ht => ?_⟩
  have h_pos_on_J : ∀ j ∈ J, 0 < (p + t • v) j := by
    intro j hj
    have hpj : m ≤ p j := Finset.inf'_le (fun i => p i) hj
    have hvj_abs : |v j| ≤ ‖v‖ := by
      simpa [Real.norm_eq_abs] using (PiLp.norm_apply_le v j)
    have htv : |t * v j| ≤ m / 2 := by
      calc
        |t * v j| = |t| * |v j| := abs_mul t (v j)
        _ ≤ h₀ * ‖v‖ := mul_le_mul ht hvj_abs (abs_nonneg _) hh₀_pos.le
        _ = m * ‖v‖ / (2 * (‖v‖ + 1)) := by ring
        _ ≤ m * (‖v‖ + 1) / (2 * (‖v‖ + 1)) := by
          gcongr
          linarith
        _ = m / 2 := by
          have hne : ‖v‖ + 1 ≠ 0 := by positivity
          field_simp [hne]
    have htv_lower : -(m / 2) ≤ t * v j := (abs_le.mp htv).1
    simp only [PiLp.add_apply, PiLp.smul_apply, smul_eq_mul]
    linarith
  have h_out_J : ∀ j : Fin K, j ∉ J → (p + t • v) j = 0 := by
    intro j hj
    simp [hp.1.2 j hj, hv_out j hj]
  have h_nonneg : ∀ j : Fin K, 0 ≤ (p + t • v) j := by
    intro j
    by_cases hj : j ∈ J
    · exact (h_pos_on_J j hj).le
    · simp [h_out_J j hj]
  have h_sum : ∑ j : Fin K, (p + t • v) j = 1 := by
    simp [Finset.sum_add_distrib, ← Finset.mul_sum, hp.1.1.2, hv_sum]
  exact ⟨⟨⟨h_nonneg, h_sum⟩, h_out_J⟩, h_pos_on_J⟩

/-- Directional derivative of `extendSimplex F` along a tangent vector `v ∈ FaceTangentSpace K J`
at `p ∈ SimplexFaceRelint K J`. -/
lemma hasDerivAt_line_of_hasFaceGradAt {K : ℕ} {F : UL.Simplex K → ℝ}
    {J : Finset (Fin K)} (hJ : J.Nonempty)
    {p g v : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ UL.SimplexFaceRelint K J)
    (hg : UL.HasFaceGradAt F J p g)
    (hv : v ∈ UL.FaceTangentSpace K J) :
    HasDerivAt (fun t : ℝ => UL.extendSimplex F (p + t • v)) ⟪g, v⟫ 0 := by
  obtain ⟨h₀, hh₀_pos, hpert⟩ := exists_relint_perturbation hJ hp hv
  let γ : ℝ → EuclideanSpace ℝ (Fin K) := fun t => p + t • v
  have hγ0 : γ 0 = p := by simp [γ]
  have hγ_deriv : HasDerivAt γ v 0 := by
    have h1 : HasDerivAt (fun t : ℝ => t • v) ((1 : ℝ) • v) 0 :=
      (hasDerivAt_id (0 : ℝ)).smul_const v
    simpa [γ] using h1.const_add p
  have h_mem_nhds : Ioo (-h₀) h₀ ∈ 𝓝 (0 : ℝ) := Ioo_mem_nhds (by linarith) hh₀_pos
  have h_maps : MapsTo γ (Ioo (-h₀) h₀) (UL.SimplexFace K J) := by
    intro t ht
    have h_abs : |t| ≤ h₀ := abs_le.mpr ⟨ht.1.le, ht.2.le⟩
    exact (hpert t h_abs).1
  have hf : HasFDerivWithinAt (UL.extendSimplex F) (innerSL ℝ g) (UL.SimplexFace K J) (γ 0) := by
    rw [hγ0]; exact hg.2
  have hcomp : HasDerivWithinAt (fun t : ℝ => UL.extendSimplex F (γ t))
      ((innerSL ℝ g) v) (Ioo (-h₀) h₀) 0 :=
    hf.comp_hasDerivWithinAt 0 hγ_deriv.hasDerivWithinAt h_maps
  simpa [γ, innerSL_apply_apply] using hcomp.hasDerivAt h_mem_nhds

end UL.Proof_lem_A_5

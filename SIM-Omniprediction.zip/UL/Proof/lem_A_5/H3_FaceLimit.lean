import UL.Proof.lem_A_5.H1_Simplex

set_option autoImplicit false

namespace UL.Proof_lem_A_5

open scoped RealInnerProductSpace
open Set Filter Topology

private lemma tendsto_extendSimplex_trimmed {K : ℕ} (hK : 2 ≤ K)
    {F : UL.Simplex K → ℝ} (hF_cont : Continuous F)
    {q : EuclideanSpace ℝ (Fin K)} (hq : q ∈ UL.Simplex K) :
    Tendsto (fun ε : ℝ => UL.extendSimplex F ((1 - ε) • q + ε • UL.uniformVec K))
      (𝓝[>] (0 : ℝ)) (𝓝 (UL.extendSimplex F q)) := by
  have hu : UL.uniformVec K ∈ UL.Simplex K := uniformVec_mem_simplex hK
  have hcont_on : ContinuousOn (UL.extendSimplex F) (UL.Simplex K) :=
    continuousOn_extendSimplex hF_cont
  let φ : ℝ → EuclideanSpace ℝ (Fin K) := fun ε => (1 - ε) • q + ε • UL.uniformVec K
  have hφ_cont : Continuous φ := by fun_prop
  have hφ0 : φ 0 = q := by simp [φ]
  have hφ_maps : MapsTo φ (Ioo (0 : ℝ) 1) (UL.Simplex K) := by
    intro ε hε
    exact convex_simplex K hq hu (by linarith [hε.2]) hε.1.le (by ring)
  have hwithin : ContinuousWithinAt (UL.extendSimplex F) (UL.Simplex K) (φ 0) := by
    rw [hφ0]
    exact hcont_on q hq
  have hcomp : Tendsto (fun ε => UL.extendSimplex F (φ ε))
      (𝓝[Ioo (0 : ℝ) 1] 0) (𝓝 (UL.extendSimplex F (φ 0))) :=
    hwithin.tendsto.comp (hφ_cont.continuousWithinAt.tendsto_nhdsWithin hφ_maps)
  rw [nhdsWithin_Ioo_eq_nhdsGT zero_lt_one, hφ0] at hcomp
  exact hcomp

/-- Pointwise convergence of the trimmed inner product to the face gradient inner product
for any `p ∈ SimplexFaceRelint K J` and `v ∈ FaceTangentSpace K J`. -/
theorem face_inner_tendsto {K : ℕ} (hK : 2 ≤ K)
    {F : UL.Simplex K → ℝ} (hF_cont : Continuous F)
    (hF_conv : ConvexOn ℝ (UL.Simplex K) (UL.extendSimplex F))
    (hF_diff : ∀ J : Finset (Fin K), J.Nonempty →
      ∀ p ∈ UL.SimplexFaceRelint K J, ∃ g, UL.HasFaceGradAt F J p g)
    {J : Finset (Fin K)} (hJ : J.Nonempty)
    {p v : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ UL.SimplexFaceRelint K J) (hv : v ∈ UL.FaceTangentSpace K J) :
    Tendsto
      (fun ε : ℝ => ⟪v, UL.faceGrad F Finset.univ ((1 - ε) • p + ε • UL.uniformVec K)⟫)
      (𝓝[>] (0 : ℝ))
      (𝓝 ⟪v, UL.faceGrad F J p⟫) := by
  have huniv_ne : (Finset.univ : Finset (Fin K)).Nonempty :=
    ⟨⟨0, by omega⟩, Finset.mem_univ _⟩
  set gJ := UL.faceGrad F J p
  have hgJ : UL.HasFaceGradAt F J p gJ := faceGrad_spec (hF_diff J hJ p hp)
  obtain ⟨h₀, hh₀_pos, hpert⟩ := exists_relint_perturbation hJ hp hv
  have hderiv : HasDerivAt (fun t : ℝ => UL.extendSimplex F (p + t • v)) ⟪gJ, v⟫ 0 :=
    hasDerivAt_line_of_hasFaceGradAt hJ hp hgJ hv
  have hslope_Base : Tendsto
      (fun t : ℝ => (UL.extendSimplex F (p + t • v) - UL.extendSimplex F p) / t)
      (𝓝[≠] (0 : ℝ)) (𝓝 ⟪gJ, v⟫) := by
    rw [hasDerivAt_iff_tendsto_slope] at hderiv
    have hcongr : (fun t : ℝ => (UL.extendSimplex F (p + t • v) - UL.extendSimplex F p) / t)
        =ᶠ[𝓝[≠] 0] slope (fun t : ℝ => UL.extendSimplex F (p + t • v)) 0 := by
      filter_upwards [self_mem_nhdsWithin] with t _
      simp [slope_def_field]
    exact hderiv.congr' hcongr.symm
  have hslope_pos : Tendsto
      (fun h : ℝ => (UL.extendSimplex F (p + h • v) - UL.extendSimplex F p) / h)
      (𝓝[>] (0 : ℝ)) (𝓝 ⟪gJ, v⟫) :=
    hslope_Base.mono_left (nhdsWithin_mono 0 fun _ hx => ne_of_gt hx)
  have hneg_maps : Tendsto (fun h : ℝ => -h) (𝓝[>] (0 : ℝ)) (𝓝[≠] (0 : ℝ)) := by
    refine tendsto_nhdsWithin_of_tendsto_nhds_of_eventually_within _ ?_ ?_
    · simpa using (continuous_neg.tendsto (0 : ℝ)).mono_left nhdsWithin_le_nhds
    · filter_upwards [self_mem_nhdsWithin] with h (hh : 0 < h)
      simp [ne_of_gt hh]
  have hslope_neg : Tendsto
      (fun h : ℝ => (UL.extendSimplex F p - UL.extendSimplex F (p - h • v)) / h)
      (𝓝[>] (0 : ℝ)) (𝓝 ⟪gJ, v⟫) := by
    have h1 := hslope_Base.comp hneg_maps
    refine h1.congr' ?_
    filter_upwards [self_mem_nhdsWithin] with h (hh : 0 < h)
    dsimp [Function.comp]
    rw [neg_smul, ← sub_eq_add_neg]
    ring
  rw [Metric.tendsto_nhds]
  intro η hη
  have hη2 : 0 < η / 2 := half_pos hη
  have hev_pos : ∀ᶠ h : ℝ in 𝓝[>] (0 : ℝ),
      (UL.extendSimplex F (p + h • v) - UL.extendSimplex F p) / h < ⟪gJ, v⟫ + η / 2 :=
    (tendsto_order.mp hslope_pos).2 _ (by linarith)
  have hev_neg : ∀ᶠ h : ℝ in 𝓝[>] (0 : ℝ),
      ⟪gJ, v⟫ - η / 2 < (UL.extendSimplex F p - UL.extendSimplex F (p - h • v)) / h :=
    (tendsto_order.mp hslope_neg).1 _ (by linarith)
  have hev_range : ∀ᶠ h : ℝ in 𝓝[>] (0 : ℝ), h ∈ Ioo 0 h₀ := Ioo_mem_nhdsGT hh₀_pos
  have hev_all : ∀ᶠ h : ℝ in 𝓝[>] (0 : ℝ),
      h ∈ Ioo 0 h₀ ∧
      (UL.extendSimplex F (p + h • v) - UL.extendSimplex F p) / h < ⟪gJ, v⟫ + η / 2 ∧
      ⟪gJ, v⟫ - η / 2 < (UL.extendSimplex F p - UL.extendSimplex F (p - h • v)) / h :=
    hev_range.and (hev_pos.and hev_neg)
  obtain ⟨h, hh_range, hh_upper, hh_lower⟩ := hev_all.exists
  have hh_pos : 0 < h := hh_range.1
  have hh_le : h ≤ h₀ := hh_range.2.le
  set q_pos := p + h • v
  set q_neg := p - h • v
  have hq_pos_mem : q_pos ∈ UL.Simplex K :=
    (hpert h (by rw [abs_of_pos hh_pos]; exact hh_le)).1.1
  have hq_neg_mem : q_neg ∈ UL.Simplex K := by
    have h_eq : q_neg = p + (-h) • v := by simp [q_neg, sub_eq_add_neg]
    rw [h_eq]
    exact (hpert (-h) (by rw [abs_neg, abs_of_pos hh_pos]; exact hh_le)).1.1
  have hp_mem : p ∈ UL.Simplex K := hp.1.1
  have hu_mem : UL.uniformVec K ∈ UL.Simplex K := uniformVec_mem_simplex hK
  have h_denom_tendsto : Tendsto (fun ε : ℝ => (1 - ε) * h) (𝓝[>] (0 : ℝ)) (𝓝 h) := by
    have hc : Continuous (fun ε : ℝ => (1 - ε) * h) := by fun_prop
    simpa using (hc.tendsto 0).mono_left nhdsWithin_le_nhds
  have h_quot_upper_tendsto : Tendsto
      (fun ε : ℝ =>
        (UL.extendSimplex F ((1 - ε) • q_pos + ε • UL.uniformVec K) -
          UL.extendSimplex F ((1 - ε) • p + ε • UL.uniformVec K)) / ((1 - ε) * h))
      (𝓝[>] (0 : ℝ))
      (𝓝 ((UL.extendSimplex F q_pos - UL.extendSimplex F p) / h)) :=
    ((tendsto_extendSimplex_trimmed hK hF_cont hq_pos_mem).sub
      (tendsto_extendSimplex_trimmed hK hF_cont hp_mem)).div h_denom_tendsto hh_pos.ne'
  have h_quot_lower_tendsto : Tendsto
      (fun ε : ℝ =>
        (UL.extendSimplex F ((1 - ε) • p + ε • UL.uniformVec K) -
          UL.extendSimplex F ((1 - ε) • q_neg + ε • UL.uniformVec K)) / ((1 - ε) * h))
      (𝓝[>] (0 : ℝ))
      (𝓝 ((UL.extendSimplex F p - UL.extendSimplex F q_neg) / h)) :=
    ((tendsto_extendSimplex_trimmed hK hF_cont hp_mem).sub
      (tendsto_extendSimplex_trimmed hK hF_cont hq_neg_mem)).div h_denom_tendsto hh_pos.ne'
  have hev_u : ∀ᶠ ε : ℝ in 𝓝[>] (0 : ℝ),
      (UL.extendSimplex F ((1 - ε) • q_pos + ε • UL.uniformVec K) -
        UL.extendSimplex F ((1 - ε) • p + ε • UL.uniformVec K)) / ((1 - ε) * h) <
        ⟪gJ, v⟫ + η / 2 :=
    (tendsto_order.mp h_quot_upper_tendsto).2 _ hh_upper
  have hev_l : ∀ᶠ ε : ℝ in 𝓝[>] (0 : ℝ),
      ⟪gJ, v⟫ - η / 2 <
      (UL.extendSimplex F ((1 - ε) • p + ε • UL.uniformVec K) -
        UL.extendSimplex F ((1 - ε) • q_neg + ε • UL.uniformVec K)) / ((1 - ε) * h) :=
    (tendsto_order.mp h_quot_lower_tendsto).1 _ hh_lower
  filter_upwards [Ioo_mem_nhdsGT zero_lt_one, hev_u, hev_l] with ε hε h_up h_lo
  set pε := (1 - ε) • p + ε • UL.uniformVec K
  set gε := UL.faceGrad F Finset.univ pε
  have hpε_relint : pε ∈ UL.SimplexFaceRelint K Finset.univ :=
    trimmed_mem_simplexFaceRelint_univ hK hp_mem hε.1 hε.2
  have hgε : UL.HasFaceGradAt F Finset.univ pε gε :=
    faceGrad_spec (hF_diff Finset.univ huniv_ne pε hpε_relint)
  have h1e_pos : 0 < 1 - ε := by linarith [hε.2]
  have h1eh_pos : 0 < (1 - ε) * h := mul_pos h1e_pos hh_pos
  -- Upper bound via q_pos_ε
  set q_pos_ε := (1 - ε) • q_pos + ε • UL.uniformVec K
  have hq_pos_ε_face : q_pos_ε ∈ UL.SimplexFace K Finset.univ := by
    rw [simplexFace_univ]
    exact convex_simplex K hq_pos_mem hu_mem h1e_pos.le hε.1.le (by ring)
  have hsub_pos : ⟪gε, q_pos_ε - pε⟫ ≤ UL.extendSimplex F q_pos_ε - UL.extendSimplex F pε :=
    subgradient_ineq_of_hasFaceGradAt hF_conv hpε_relint.1 hgε hq_pos_ε_face
  have hdiff_pos : q_pos_ε - pε = ((1 - ε) * h) • v := by
    simp only [q_pos_ε, pε, q_pos, smul_add, mul_smul]
    abel
  have hgε_le : ⟪gε, v⟫ ≤ (UL.extendSimplex F q_pos_ε - UL.extendSimplex F pε) / ((1 - ε) * h) := by
    rw [le_div_iff₀ h1eh_pos, mul_comm]
    simpa [hdiff_pos, inner_smul_right] using hsub_pos
  -- Lower bound via q_neg_ε
  set q_neg_ε := (1 - ε) • q_neg + ε • UL.uniformVec K
  have hq_neg_ε_face : q_neg_ε ∈ UL.SimplexFace K Finset.univ := by
    rw [simplexFace_univ]
    exact convex_simplex K hq_neg_mem hu_mem h1e_pos.le hε.1.le (by ring)
  have hsub_neg : ⟪gε, q_neg_ε - pε⟫ ≤ UL.extendSimplex F q_neg_ε - UL.extendSimplex F pε :=
    subgradient_ineq_of_hasFaceGradAt hF_conv hpε_relint.1 hgε hq_neg_ε_face
  have hdiff_neg : q_neg_ε - pε = -(((1 - ε) * h) • v) := by
    simp only [q_neg_ε, pε, q_neg, smul_sub, mul_smul]
    abel
  have hgε_ge : (UL.extendSimplex F pε - UL.extendSimplex F q_neg_ε) / ((1 - ε) * h) ≤ ⟪gε, v⟫ := by
    rw [div_le_iff₀ h1eh_pos, mul_comm]
    have hsub_neg' : -(((1 - ε) * h) * ⟪gε, v⟫) ≤
        UL.extendSimplex F q_neg_ε - UL.extendSimplex F pε := by
      simpa [hdiff_neg, inner_neg_right, inner_smul_right] using hsub_neg
    linarith
  rw [Real.dist_eq, real_inner_comm gε v, real_inner_comm gJ v, abs_lt]
  constructor <;> linarith

/-- Uniform lower bound `-2 * oscBound` on `⟪p - z, faceGrad F univ ((1 - ε) • p + ε • u)⟫`
for `p, z ∈ Simplex K` and `0 < ε ≤ 1 / 2`. -/
theorem trimmed_inner_lower_bound {K : ℕ} (hK : 2 ≤ K)
    {F : UL.Simplex K → ℝ}
    (hF_conv : ConvexOn ℝ (UL.Simplex K) (UL.extendSimplex F))
    (hF_diff : ∀ J : Finset (Fin K), J.Nonempty →
      ∀ p ∈ UL.SimplexFaceRelint K J, ∃ g, UL.HasFaceGradAt F J p g)
    {oscBound : ℝ} (hOsc_nonneg : 0 ≤ oscBound)
    (hOsc : ∀ q₁ ∈ UL.Simplex K, ∀ q₂ ∈ UL.Simplex K,
      UL.extendSimplex F q₁ - UL.extendSimplex F q₂ ≤ oscBound)
    {p z : EuclideanSpace ℝ (Fin K)} (hp : p ∈ UL.Simplex K) (hz : z ∈ UL.Simplex K)
    {ε : ℝ} (hε0 : 0 < ε) (hε_half : ε ≤ 1 / 2) :
    -2 * oscBound ≤ ⟪p - z, UL.faceGrad F Finset.univ ((1 - ε) • p + ε • UL.uniformVec K)⟫ := by
  have huniv_ne : (Finset.univ : Finset (Fin K)).Nonempty :=
    ⟨⟨0, by omega⟩, Finset.mem_univ _⟩
  have hε1 : ε < 1 := by linarith
  have h1e_pos : 0 < 1 - ε := by linarith
  set u := UL.uniformVec K
  set pε := (1 - ε) • p + ε • u
  set gε := UL.faceGrad F Finset.univ pε
  have hpε_relint : pε ∈ UL.SimplexFaceRelint K Finset.univ :=
    trimmed_mem_simplexFaceRelint_univ hK hp hε0 hε1
  have hgε : UL.HasFaceGradAt F Finset.univ pε gε :=
    faceGrad_spec (hF_diff Finset.univ huniv_ne pε hpε_relint)
  have hu_face : u ∈ UL.SimplexFace K Finset.univ := by
    rw [simplexFace_univ]; exact uniformVec_mem_simplex hK
  have hz_face : z ∈ UL.SimplexFace K Finset.univ := by
    rw [simplexFace_univ]; exact hz
  -- Subgradient at z: ⟪gε, z - pε⟫ ≤ F(z) - F(pε) ≤ oscBound
  have h_at_z : -oscBound ≤ ⟪pε - z, gε⟫ := by
    have h1 := subgradient_ineq_of_hasFaceGradAt hF_conv hpε_relint.1 hgε hz_face
    have h2 := hOsc z hz pε hpε_relint.1.1
    have h3 : ⟪pε - z, gε⟫ = -⟪gε, z - pε⟫ := by
      rw [real_inner_comm gε (pε - z), ← inner_neg_right, neg_sub]
    linarith
  -- Subgradient at u: ⟪gε, u - pε⟫ ≤ F(u) - F(pε) ≤ oscBound
  have h_at_u : -oscBound ≤ ⟪pε - u, gε⟫ := by
    have h1 := subgradient_ineq_of_hasFaceGradAt hF_conv hpε_relint.1 hgε hu_face
    have h2 := hOsc u (uniformVec_mem_simplex hK) pε hpε_relint.1.1
    have h3 : ⟪pε - u, gε⟫ = -⟪gε, u - pε⟫ := by
      rw [real_inner_comm gε (pε - u), ← inner_neg_right, neg_sub]
    linarith
  -- Algebraic decomposition: p - z = (pε - z) + (ε / (1 - ε)) • (pε - u)
  have hpε_sub_u : pε - u = (1 - ε) • (p - u) := by
    simp only [pε, sub_smul, one_smul, smul_sub]
    abel
  have hdecomp : p - z = (pε - z) + (ε / (1 - ε)) • (pε - u) := by
    rw [hpε_sub_u, smul_smul, div_mul_cancel₀ _ h1e_pos.ne']
    simp only [pε, sub_smul, one_smul, smul_sub]
    abel
  have h_inner_decomp : ⟪p - z, gε⟫ = ⟪pε - z, gε⟫ + (ε / (1 - ε)) * ⟪pε - u, gε⟫ := by
    rw [hdecomp, inner_add_left, inner_smul_left]
    simp
  have hratio_nonneg : 0 ≤ ε / (1 - ε) := div_nonneg hε0.le h1e_pos.le
  have hratio_le_one : ε / (1 - ε) ≤ 1 := by
    rw [div_le_one h1e_pos]
    linarith
  have h_term2 : -oscBound ≤ (ε / (1 - ε)) * ⟪pε - u, gε⟫ := by
    have hmul : (ε / (1 - ε)) * (-oscBound) ≤ (ε / (1 - ε)) * ⟪pε - u, gε⟫ :=
      mul_le_mul_of_nonneg_left h_at_u hratio_nonneg
    nlinarith
  linarith

end UL.Proof_lem_A_5

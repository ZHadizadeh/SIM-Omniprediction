import UL.Proof.lem_A_5.H1_Simplex

set_option autoImplicit false

namespace UL.Proof_lem_A_5

open scoped RealInnerProductSpace Gradient
open Set Filter Topology MeasureTheory

/-! ### Part 1: Centered simplex `𝒞 = Δ_K − u` and interior `C_int` in `H = ZeroSumSubspace K` -/

def shiftedSimplex (K : ℕ) : Set (UL.ZeroSumSubspace K) :=
  {s | UL.uniformVec K + (s : EuclideanSpace ℝ (Fin K)) ∈ UL.Simplex K}

def shiftedRelint (K : ℕ) : Set (UL.ZeroSumSubspace K) :=
  {s | UL.uniformVec K + (s : EuclideanSpace ℝ (Fin K)) ∈ UL.SimplexFaceRelint K Finset.univ}

noncomputable def shiftedFun {K : ℕ} (F : UL.Simplex K → ℝ) (s : UL.ZeroSumSubspace K) : ℝ :=
  UL.extendSimplex F (UL.uniformVec K + (s : EuclideanSpace ℝ (Fin K)))

lemma shiftedRelint_subset (K : ℕ) : shiftedRelint K ⊆ shiftedSimplex K :=
  fun _ hs => hs.1.1

lemma zero_mem_shiftedRelint {K : ℕ} (hK : 2 ≤ K) :
    (0 : UL.ZeroSumSubspace K) ∈ shiftedRelint K := by
  simpa [shiftedRelint] using uniformVec_mem_simplexFaceRelint_univ hK

lemma zero_mem_shiftedSimplex {K : ℕ} (hK : 2 ≤ K) :
    (0 : UL.ZeroSumSubspace K) ∈ shiftedSimplex K :=
  shiftedRelint_subset K (zero_mem_shiftedRelint hK)

lemma mem_shiftedRelint_iff {K : ℕ} (hK : 2 ≤ K) (s : UL.ZeroSumSubspace K) :
    s ∈ shiftedRelint K ↔
      ∀ j : Fin K, 0 < (UL.uniformVec K + (s : EuclideanSpace ℝ (Fin K))) j := by
  constructor
  · intro hs j
    exact hs.2 j (Finset.mem_univ j)
  · intro hpos
    have hs_sum : ∑ j : Fin K, (s : EuclideanSpace ℝ (Fin K)) j = 0 :=
      (mem_zeroSumSubspace_iff K s.1).mp s.2
    have hsum : ∑ j : Fin K, (UL.uniformVec K + (s : EuclideanSpace ℝ (Fin K))) j = 1 := by
      simp only [PiLp.add_apply, Finset.sum_add_distrib, sum_uniformVec hK, hs_sum, add_zero]
    refine ⟨⟨⟨fun j => (hpos j).le, hsum⟩,
      fun j hj => False.elim (hj (Finset.mem_univ j))⟩, fun j _ => hpos j⟩

lemma isOpen_shiftedRelint {K : ℕ} (hK : 2 ≤ K) : IsOpen (shiftedRelint K) := by
  have heq : shiftedRelint K =
      ⋂ j : Fin K, {s : UL.ZeroSumSubspace K |
        0 < (UL.uniformVec K + (s : EuclideanSpace ℝ (Fin K))) j} := by
    ext s
    simp [mem_shiftedRelint_iff hK]
  rw [heq]
  refine isOpen_iInter_of_finite fun j => ?_
  have hc : Continuous (fun s : UL.ZeroSumSubspace K =>
      (UL.uniformVec K + (s : EuclideanSpace ℝ (Fin K))) j) :=
    (EuclideanSpace.proj j).continuous.comp
      (continuous_const.add (UL.ZeroSumSubspace K).subtypeL.continuous)
  exact isOpen_lt continuous_const hc

lemma isCompact_shiftedSimplex (K : ℕ) : IsCompact (shiftedSimplex K) := by
  have hclosed : IsClosed (shiftedSimplex K) :=
    (isClosed_simplex K).preimage
      (continuous_const.add (UL.ZeroSumSubspace K).subtypeL.continuous)
  refine Metric.isCompact_of_isClosed_isBounded hclosed ?_
  rw [isBounded_iff_forall_norm_le]
  refine ⟨1 + ‖UL.uniformVec K‖, fun s hs => ?_⟩
  have h1 : ‖UL.uniformVec K + (s : EuclideanSpace ℝ (Fin K))‖ ≤ 1 :=
    norm_le_one_of_mem_simplex hs
  have h2 : ‖(s : EuclideanSpace ℝ (Fin K))‖ = ‖s‖ := Submodule.norm_coe s
  have h3 : ‖(s : EuclideanSpace ℝ (Fin K))‖ =
      ‖(UL.uniformVec K + (s : EuclideanSpace ℝ (Fin K))) - UL.uniformVec K‖ := by
    congr 1; abel
  calc
    ‖s‖ = ‖(UL.uniformVec K + (s : EuclideanSpace ℝ (Fin K))) - UL.uniformVec K‖ := by
      rw [← h2, h3]
    _ ≤ ‖UL.uniformVec K + (s : EuclideanSpace ℝ (Fin K))‖ + ‖UL.uniformVec K‖ :=
      norm_sub_le _ _
    _ ≤ 1 + ‖UL.uniformVec K‖ := by linarith

lemma convex_shiftedSimplex (K : ℕ) : Convex ℝ (shiftedSimplex K) := by
  intro s₁ hs₁ s₂ hs₂ a b ha hb hab
  change UL.uniformVec K + ↑(a • s₁ + b • s₂) ∈ UL.Simplex K
  have heq : UL.uniformVec K + ((a • s₁ + b • s₂ : UL.ZeroSumSubspace K) :
      EuclideanSpace ℝ (Fin K)) =
      a • (UL.uniformVec K + (s₁ : EuclideanSpace ℝ (Fin K))) +
      b • (UL.uniformVec K + (s₂ : EuclideanSpace ℝ (Fin K))) := by
    push_cast
    calc
      UL.uniformVec K + (a • (s₁ : EuclideanSpace ℝ (Fin K)) +
          b • (s₂ : EuclideanSpace ℝ (Fin K)))
        = (a + b) • UL.uniformVec K + (a • (s₁ : EuclideanSpace ℝ (Fin K)) +
            b • (s₂ : EuclideanSpace ℝ (Fin K))) := by rw [hab, one_smul]
      _ = a • (UL.uniformVec K + (s₁ : EuclideanSpace ℝ (Fin K))) +
          b • (UL.uniformVec K + (s₂ : EuclideanSpace ℝ (Fin K))) := by
        simp only [add_smul, smul_add]
        abel
  rw [heq]
  exact convex_simplex K hs₁ hs₂ ha hb hab

lemma continuousOn_shiftedFun {K : ℕ} {F : UL.Simplex K → ℝ} (hF_cont : Continuous F) :
    ContinuousOn (shiftedFun F) (shiftedSimplex K) := by
  have hc : Continuous (fun s : UL.ZeroSumSubspace K =>
      UL.uniformVec K + (s : EuclideanSpace ℝ (Fin K))) :=
    continuous_const.add (UL.ZeroSumSubspace K).subtypeL.continuous
  exact (continuousOn_extendSimplex hF_cont).comp hc.continuousOn (fun _ hs => hs)

lemma convexOn_shiftedFun {K : ℕ} {F : UL.Simplex K → ℝ}
    (hF_conv : ConvexOn ℝ (UL.Simplex K) (UL.extendSimplex F)) :
    ConvexOn ℝ (shiftedSimplex K) (shiftedFun F) := by
  refine ⟨convex_shiftedSimplex K, fun s₁ hs₁ s₂ hs₂ a b ha hb hab => ?_⟩
  unfold shiftedFun
  have heq : UL.uniformVec K + ((a • s₁ + b • s₂ : UL.ZeroSumSubspace K) :
      EuclideanSpace ℝ (Fin K)) =
      a • (UL.uniformVec K + (s₁ : EuclideanSpace ℝ (Fin K))) +
      b • (UL.uniformVec K + (s₂ : EuclideanSpace ℝ (Fin K))) := by
    push_cast
    calc
      UL.uniformVec K + (a • (s₁ : EuclideanSpace ℝ (Fin K)) +
          b • (s₂ : EuclideanSpace ℝ (Fin K)))
        = (a + b) • UL.uniformVec K + (a • (s₁ : EuclideanSpace ℝ (Fin K)) +
            b • (s₂ : EuclideanSpace ℝ (Fin K))) := by rw [hab, one_smul]
      _ = a • (UL.uniformVec K + (s₁ : EuclideanSpace ℝ (Fin K))) +
          b • (UL.uniformVec K + (s₂ : EuclideanSpace ℝ (Fin K))) := by
        simp only [add_smul, smul_add]
        abel
  rw [heq]
  exact hF_conv.2 hs₁ hs₂ ha hb hab

/-! ### Part 2: Gradient of `shiftedFun` on `shiftedRelint` and its continuity -/

lemma hasGradientAt_shiftedFun {K : ℕ} (hK : 2 ≤ K)
    {F : UL.Simplex K → ℝ}
    (hF_diff : ∀ J : Finset (Fin K), J.Nonempty →
      ∀ p ∈ UL.SimplexFaceRelint K J, ∃ g, UL.HasFaceGradAt F J p g)
    {s : UL.ZeroSumSubspace K} (hs : s ∈ shiftedRelint K) :
    ∃ gH : UL.ZeroSumSubspace K,
      (gH : EuclideanSpace ℝ (Fin K)) =
        UL.faceGrad F Finset.univ (UL.uniformVec K + (s : EuclideanSpace ℝ (Fin K))) ∧
      HasGradientAt (shiftedFun F) gH s := by
  have huniv_ne : (Finset.univ : Finset (Fin K)).Nonempty :=
    ⟨⟨0, by omega⟩, Finset.mem_univ _⟩
  set p := UL.uniformVec K + (s : EuclideanSpace ℝ (Fin K))
  set gE := UL.faceGrad F Finset.univ p
  have hgE : UL.HasFaceGradAt F Finset.univ p gE :=
    faceGrad_spec (hF_diff Finset.univ huniv_ne p hs)
  have hgE_mem : gE ∈ UL.ZeroSumSubspace K := by
    rw [← faceTangentSpace_univ K]
    exact hgE.1
  let gH : UL.ZeroSumSubspace K := ⟨gE, hgE_mem⟩
  refine ⟨gH, rfl, ?_⟩
  rw [hasGradientAt_iff_hasFDerivAt]
  let aff : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) :=
    fun x => UL.uniformVec K + (x : EuclideanSpace ℝ (Fin K))
  have haff_deriv : HasFDerivAt aff (UL.ZeroSumSubspace K).subtypeL s := by
    simpa [aff] using ((UL.ZeroSumSubspace K).subtypeL.hasFDerivAt).const_add (UL.uniformVec K)
  have hmaps : MapsTo aff (shiftedSimplex K) (UL.SimplexFace K Finset.univ) := by
    intro x hx
    rw [simplexFace_univ]
    exact hx
  have hcomp_within : HasFDerivWithinAt (shiftedFun F)
      ((innerSL ℝ gE).comp (UL.ZeroSumSubspace K).subtypeL) (shiftedSimplex K) s :=
    hgE.2.comp s haff_deriv.hasFDerivWithinAt hmaps
  have h_mem_nhds : shiftedSimplex K ∈ 𝓝 s :=
    Filter.mem_of_superset ((isOpen_shiftedRelint hK).mem_nhds hs) (shiftedRelint_subset K)
  have hcomp : HasFDerivAt (shiftedFun F)
      ((innerSL ℝ gE).comp (UL.ZeroSumSubspace K).subtypeL) s :=
    hcomp_within.hasFDerivAt h_mem_nhds
  have hclm_eq : (innerSL ℝ gE).comp (UL.ZeroSumSubspace K).subtypeL =
      InnerProductSpace.toDual ℝ (UL.ZeroSumSubspace K) gH := by
    ext v
    simp [gH]
  rwa [hclm_eq] at hcomp

lemma coe_gradient_shiftedFun {K : ℕ} (hK : 2 ≤ K)
    {F : UL.Simplex K → ℝ}
    (hF_diff : ∀ J : Finset (Fin K), J.Nonempty →
      ∀ p ∈ UL.SimplexFaceRelint K J, ∃ g, UL.HasFaceGradAt F J p g)
    {s : UL.ZeroSumSubspace K} (hs : s ∈ shiftedRelint K) :
    (↑(∇ (shiftedFun F) s) : EuclideanSpace ℝ (Fin K)) =
      UL.faceGrad F Finset.univ (UL.uniformVec K + (s : EuclideanSpace ℝ (Fin K))) := by
  obtain ⟨gH, hgH_coe, hgH_grad⟩ := hasGradientAt_shiftedFun hK hF_diff hs
  rw [hgH_grad.gradient, hgH_coe]

lemma subgradient_shiftedFun {K : ℕ} (hK : 2 ≤ K)
    {F : UL.Simplex K → ℝ}
    (hF_conv : ConvexOn ℝ (UL.Simplex K) (UL.extendSimplex F))
    (hF_diff : ∀ J : Finset (Fin K), J.Nonempty →
      ∀ p ∈ UL.SimplexFaceRelint K J, ∃ g, UL.HasFaceGradAt F J p g)
    {s y : UL.ZeroSumSubspace K} (hs : s ∈ shiftedRelint K) (hy : y ∈ shiftedSimplex K) :
    ⟪∇ (shiftedFun F) s, y - s⟫ ≤ shiftedFun F y - shiftedFun F s := by
  have huniv_ne : (Finset.univ : Finset (Fin K)).Nonempty :=
    ⟨⟨0, by omega⟩, Finset.mem_univ _⟩
  set p := UL.uniformVec K + (s : EuclideanSpace ℝ (Fin K))
  set q := UL.uniformVec K + (y : EuclideanSpace ℝ (Fin K))
  have hq_face : q ∈ UL.SimplexFace K Finset.univ := by
    rw [simplexFace_univ]; exact hy
  have hg : UL.HasFaceGradAt F Finset.univ p (UL.faceGrad F Finset.univ p) :=
    faceGrad_spec (hF_diff Finset.univ huniv_ne p hs)
  have hineq := subgradient_ineq_of_hasFaceGradAt hF_conv hs.1 hg hq_face
  have hinner : ⟪∇ (shiftedFun F) s, y - s⟫ = ⟪UL.faceGrad F Finset.univ p, q - p⟫ := by
    change ⟪(↑(∇ (shiftedFun F) s) : EuclideanSpace ℝ (Fin K)),
      ((y - s : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))⟫ =
      ⟪UL.faceGrad F Finset.univ p, q - p⟫
    rw [coe_gradient_shiftedFun hK hF_diff hs]
    congr 1
    simp [p, q]
  simpa [shiftedFun, p, q, hinner] using hineq

lemma norm_gradient_shiftedFun_le {K : ℕ} (hK : 2 ≤ K)
    {F : UL.Simplex K → ℝ}
    (hF_conv : ConvexOn ℝ (UL.Simplex K) (UL.extendSimplex F))
    (hF_diff : ∀ J : Finset (Fin K), J.Nonempty →
      ∀ p ∈ UL.SimplexFaceRelint K J, ∃ g, UL.HasFaceGradAt F J p g)
    {oscBound : ℝ} (hOsc_nonneg : 0 ≤ oscBound)
    (hOsc : ∀ q₁ ∈ UL.Simplex K, ∀ q₂ ∈ UL.Simplex K,
      UL.extendSimplex F q₁ - UL.extendSimplex F q₂ ≤ oscBound)
    {s : UL.ZeroSumSubspace K} (hs : s ∈ shiftedRelint K)
    {r₀ : ℝ} (hr₀ : 0 < r₀)
    (hball : Metric.closedBall s r₀ ⊆ shiftedSimplex K) :
    ‖∇ (shiftedFun F) s‖ ≤ oscBound / r₀ := by
  set g := ∇ (shiftedFun F) s
  by_cases hg0 : g = 0
  · simp [hg0, div_nonneg hOsc_nonneg hr₀.le]
  · have hgnorm : 0 < ‖g‖ := norm_pos_iff.mpr hg0
    let y : UL.ZeroSumSubspace K := s + (r₀ / ‖g‖) • g
    have hy_ball : y ∈ Metric.closedBall s r₀ := by
      rw [Metric.mem_closedBall, dist_eq_norm]
      have hdiff : y - s = (r₀ / ‖g‖) • g := by simp [y]
      rw [hdiff, norm_smul, Real.norm_of_nonneg (div_nonneg hr₀.le hgnorm.le),
        div_mul_cancel₀ _ hgnorm.ne']
    have hy_mem : y ∈ shiftedSimplex K := hball hy_ball
    have hsub := subgradient_shiftedFun hK hF_conv hF_diff hs hy_mem
    have hosc : shiftedFun F y - shiftedFun F s ≤ oscBound := hOsc _ hy_mem _ hs.1.1
    have hinner : ⟪g, y - s⟫ = r₀ * ‖g‖ := by
      have hdiff : y - s = (r₀ / ‖g‖) • g := by simp [y]
      rw [hdiff, inner_smul_right, real_inner_self_eq_norm_sq, sq, ← mul_assoc,
        div_mul_cancel₀ _ hgnorm.ne']
    rw [le_div_iff₀ hr₀, mul_comm]
    linarith

lemma continuousOn_gradient_shiftedFun {K : ℕ} (hK : 2 ≤ K)
    {F : UL.Simplex K → ℝ} (hF_cont : Continuous F)
    (hF_conv : ConvexOn ℝ (UL.Simplex K) (UL.extendSimplex F))
    (hF_diff : ∀ J : Finset (Fin K), J.Nonempty →
      ∀ p ∈ UL.SimplexFaceRelint K J, ∃ g, UL.HasFaceGradAt F J p g) :
    ContinuousOn (∇ (shiftedFun F)) (shiftedRelint K) := by
  obtain ⟨oscBound, hOsc_nonneg, hOsc⟩ := exists_oscillation_bound hK hF_cont
  rw [(isOpen_shiftedRelint hK).continuousOn_iff]
  intro s₀ hs₀
  obtain ⟨R, hR_pos, hR_sub⟩ := Metric.isOpen_iff.mp (isOpen_shiftedRelint hK) s₀ hs₀
  set r₀ : ℝ := R / 3 with hr₀_def
  have hr₀_pos : 0 < r₀ := by positivity
  have h_ball2_relint : Metric.closedBall s₀ (2 * r₀) ⊆ shiftedRelint K := by
    intro z hz
    apply hR_sub
    rw [Metric.mem_ball]
    have hz' : dist z s₀ ≤ 2 * r₀ := Metric.mem_closedBall.mp hz
    linarith [hr₀_def]
  have h_grad_bdd : ∀ x ∈ Metric.closedBall s₀ r₀,
      ∇ (shiftedFun F) x ∈ Metric.closedBall (0 : UL.ZeroSumSubspace K) (oscBound / r₀) := by
    intro x hx
    have hx_relint : x ∈ shiftedRelint K := h_ball2_relint (Metric.closedBall_subset_closedBall
      (by linarith) hx)
    have hx_ball_sub : Metric.closedBall x r₀ ⊆ shiftedSimplex K := by
      intro w hw
      apply shiftedRelint_subset K
      apply h_ball2_relint
      rw [Metric.mem_closedBall] at hw hx ⊢
      calc
        dist w s₀ ≤ dist w x + dist x s₀ := dist_triangle w x s₀
        _ ≤ r₀ + r₀ := add_le_add hw hx
        _ = 2 * r₀ := by ring
    rw [Metric.mem_closedBall, dist_zero_right]
    exact norm_gradient_shiftedFun_le hK hF_conv hF_diff hOsc_nonneg hOsc hx_relint hr₀_pos hx_ball_sub
  change Tendsto (∇ (shiftedFun F)) (𝓝 s₀) (𝓝 (∇ (shiftedFun F) s₀))
  refine tendsto_of_subseq_tendsto fun ns hns => ?_
  have hev_in : ∀ᶠ n : ℕ in atTop, ns n ∈ Metric.closedBall s₀ r₀ :=
    hns.eventually (Metric.closedBall_mem_nhds s₀ hr₀_pos)
  rw [Filter.eventually_atTop] at hev_in
  obtain ⟨N, hN⟩ := hev_in
  have h_seq_in : ∀ k : ℕ, ∇ (shiftedFun F) (ns (k + N)) ∈
      Metric.closedBall (0 : UL.ZeroSumSubspace K) (oscBound / r₀) :=
    fun k => h_grad_bdd (ns (k + N)) (hN (k + N) (Nat.le_add_left N k))
  obtain ⟨g_star, _, φ, hφ_mono, hφ_tendsto⟩ :=
    (isCompact_closedBall (0 : UL.ZeroSumSubspace K) (oscBound / r₀)).tendsto_subseq h_seq_in
  refine ⟨fun k => φ k + N, ?_⟩
  suffices hg_eq : g_star = ∇ (shiftedFun F) s₀ by
    rwa [← hg_eq]
  have hsub_ns : Tendsto (fun k => ns (φ k + N)) atTop (𝓝 s₀) :=
    hns.comp (tendsto_atTop_mono
      (fun k => le_trans (hφ_mono.id_le k) (Nat.le_add_right _ _)) tendsto_id)
  have h_Φ_cont_s₀ : ContinuousAt (shiftedFun F) s₀ := by
    have hmem : shiftedSimplex K ∈ 𝓝 s₀ :=
      Filter.mem_of_superset ((isOpen_shiftedRelint hK).mem_nhds hs₀) (shiftedRelint_subset K)
    exact (continuousOn_shiftedFun hF_cont).continuousAt hmem
  have h_subgrad_star : ∀ y ∈ shiftedSimplex K,
      ⟪g_star, y - s₀⟫ ≤ shiftedFun F y - shiftedFun F s₀ := by
    intro y hy
    have h_lhs : Tendsto (fun k => ⟪∇ (shiftedFun F) (ns (φ k + N)), y - ns (φ k + N)⟫)
        atTop (𝓝 ⟪g_star, y - s₀⟫) :=
      Filter.Tendsto.inner hφ_tendsto (tendsto_const_nhds.sub hsub_ns)
    have h_rhs : Tendsto (fun k => shiftedFun F y - shiftedFun F (ns (φ k + N)))
        atTop (𝓝 (shiftedFun F y - shiftedFun F s₀)) :=
      tendsto_const_nhds.sub (h_Φ_cont_s₀.tendsto.comp hsub_ns)
    have h_ineq : ∀ k : ℕ, ⟪∇ (shiftedFun F) (ns (φ k + N)), y - ns (φ k + N)⟫ ≤
        shiftedFun F y - shiftedFun F (ns (φ k + N)) := by
      intro k
      have h_mem_ball : ns (φ k + N) ∈ Metric.closedBall s₀ r₀ :=
        hN (φ k + N) (Nat.le_add_left N (φ k))
      have h_relint : ns (φ k + N) ∈ shiftedRelint K :=
        h_ball2_relint (Metric.closedBall_subset_closedBall (by linarith) h_mem_ball)
      exact subgradient_shiftedFun hK hF_conv hF_diff h_relint hy
    exact le_of_tendsto_of_tendsto h_lhs h_rhs (Eventually.of_forall h_ineq)
  obtain ⟨g₀, _, hg₀_grad⟩ := hasGradientAt_shiftedFun hK hF_diff hs₀
  have hg₀_eq : ∇ (shiftedFun F) s₀ = g₀ := hg₀_grad.gradient
  rw [hg₀_eq]
  have h_le_all : ∀ v : UL.ZeroSumSubspace K, ⟪g_star, v⟫ ≤ ⟪g₀, v⟫ := by
    intro v
    have hline_cont : Continuous (fun t : ℝ => s₀ + t • v) := by fun_prop
    have hline_ev : ∀ᶠ t : ℝ in 𝓝[>] (0 : ℝ), s₀ + t • v ∈ shiftedSimplex K := by
      have h1 : ∀ᶠ t : ℝ in 𝓝 (0 : ℝ), s₀ + t • v ∈ shiftedRelint K := by
        have h0 : s₀ + (0 : ℝ) • v = s₀ := by simp
        have hopen := (isOpen_shiftedRelint hK).preimage hline_cont
        exact hopen.mem_nhds (by simpa [h0] using hs₀)
      exact (h1.filter_mono nhdsWithin_le_nhds).mono fun _ ht => shiftedRelint_subset K ht
    have hline_deriv : HasDerivAt (fun t : ℝ => shiftedFun F (s₀ + t • v)) ⟪g₀, v⟫ 0 := by
      have hd1 : HasDerivAt (fun t : ℝ => s₀ + t • v) v 0 := by
        have h := (hasDerivAt_id (0 : ℝ)).smul_const v
        simpa using h.const_add s₀
      have hf : HasFDerivAt (shiftedFun F) (InnerProductSpace.toDual ℝ _ g₀) (s₀ + (0 : ℝ) • v) := by
        simpa using hg₀_grad.hasFDerivAt
      simpa using hf.comp_hasDerivAt 0 hd1
    have hslope_tendsto : Tendsto
        (fun t : ℝ => (shiftedFun F (s₀ + t • v) - shiftedFun F s₀) / t)
        (𝓝[>] (0 : ℝ)) (𝓝 ⟪g₀, v⟫) := by
      rw [hasDerivAt_iff_tendsto_slope] at hline_deriv
      have h1 := hline_deriv.mono_left (nhdsWithin_mono 0 fun _ hx => ne_of_gt hx)
      refine h1.congr' ?_
      filter_upwards [self_mem_nhdsWithin] with t _
      simp [slope_def_field]
    have hslope_ge : ∀ᶠ t : ℝ in 𝓝[>] (0 : ℝ),
        ⟪g_star, v⟫ ≤ (shiftedFun F (s₀ + t • v) - shiftedFun F s₀) / t := by
      filter_upwards [self_mem_nhdsWithin, hline_ev] with t (ht : 0 < t) hy
      rw [le_div_iff₀ ht, mul_comm]
      have hsub := h_subgrad_star (s₀ + t • v) hy
      have hdiff : (s₀ + t • v) - s₀ = t • v := by abel
      simpa [hdiff, inner_smul_right] using hsub
    exact ge_of_tendsto hslope_tendsto hslope_ge
  have h0 : ⟪g_star - g₀, g_star - g₀⟫ ≤ 0 := by
    have h := h_le_all (g_star - g₀)
    rw [inner_sub_left]
    linarith
  have hnorm0 : ‖g_star - g₀‖ ^ 2 ≤ 0 := by
    rwa [← real_inner_self_eq_norm_sq]
  have hdiff0 : g_star - g₀ = 0 := by
    have hn : ‖g_star - g₀‖ = 0 := le_antisymm (by nlinarith [norm_nonneg (g_star - g₀)])
      (norm_nonneg _)
    exact norm_eq_zero.mp hn
  exact sub_eq_zero.mp hdiff0

/-! ### Part 3: Moreau envelope `moreauEnv` on `ZeroSumSubspace K` -/

noncomputable def moreauObj {K : ℕ} (F : UL.Simplex K → ℝ) (δ : ℝ)
    (s a : UL.ZeroSumSubspace K) : ℝ :=
  shiftedFun F a + (1 / (2 * δ)) * ‖a - s‖ ^ 2

lemma exists_proxPoint {K : ℕ} (hK : 2 ≤ K) {F : UL.Simplex K → ℝ}
    (hF_cont : Continuous F) (δ : ℝ) (s : UL.ZeroSumSubspace K) :
    ∃ p ∈ shiftedSimplex K, IsMinOn (moreauObj F δ s) (shiftedSimplex K) p := by
  have hne : (shiftedSimplex K).Nonempty := ⟨0, zero_mem_shiftedSimplex hK⟩
  have hcont : ContinuousOn (moreauObj F δ s) (shiftedSimplex K) := by
    refine (continuousOn_shiftedFun hF_cont).add ?_
    have hc : Continuous (fun a : UL.ZeroSumSubspace K => (1 / (2 * δ)) * ‖a - s‖ ^ 2) := by
      fun_prop
    exact hc.continuousOn
  exact (isCompact_shiftedSimplex K).exists_isMinOn hne hcont

noncomputable def proxPoint {K : ℕ} (hK : 2 ≤ K) {F : UL.Simplex K → ℝ}
    (hF_cont : Continuous F) (δ : ℝ) (s : UL.ZeroSumSubspace K) : UL.ZeroSumSubspace K :=
  Classical.choose (exists_proxPoint hK hF_cont δ s)

lemma proxPoint_mem {K : ℕ} (hK : 2 ≤ K) {F : UL.Simplex K → ℝ}
    (hF_cont : Continuous F) (δ : ℝ) (s : UL.ZeroSumSubspace K) :
    proxPoint hK hF_cont δ s ∈ shiftedSimplex K :=
  (Classical.choose_spec (exists_proxPoint hK hF_cont δ s)).1

lemma proxPoint_isMinOn {K : ℕ} (hK : 2 ≤ K) {F : UL.Simplex K → ℝ}
    (hF_cont : Continuous F) (δ : ℝ) (s : UL.ZeroSumSubspace K) :
    IsMinOn (moreauObj F δ s) (shiftedSimplex K) (proxPoint hK hF_cont δ s) :=
  (Classical.choose_spec (exists_proxPoint hK hF_cont δ s)).2

noncomputable def moreauEnv {K : ℕ} (hK : 2 ≤ K) {F : UL.Simplex K → ℝ}
    (hF_cont : Continuous F) (δ : ℝ) (s : UL.ZeroSumSubspace K) : ℝ :=
  moreauObj F δ s (proxPoint hK hF_cont δ s)

lemma moreauEnv_le {K : ℕ} (hK : 2 ≤ K) {F : UL.Simplex K → ℝ}
    (hF_cont : Continuous F) (δ : ℝ) (s : UL.ZeroSumSubspace K)
    {a : UL.ZeroSumSubspace K} (ha : a ∈ shiftedSimplex K) :
    moreauEnv hK hF_cont δ s ≤ moreauObj F δ s a :=
  isMinOn_iff.mp (proxPoint_isMinOn hK hF_cont δ s) a ha

/-- First-order variational inequality for `proxPoint`:
`shiftedFun F p - shiftedFun F a ≤ (1 / δ) * ⟪s - p, p - a⟫` for all `a ∈ shiftedSimplex K`. -/
lemma proxPoint_variational_ineq {K : ℕ} (hK : 2 ≤ K) {F : UL.Simplex K → ℝ}
    (hF_cont : Continuous F)
    (hF_conv : ConvexOn ℝ (UL.Simplex K) (UL.extendSimplex F))
    {δ : ℝ} (hδ : 0 < δ) (s : UL.ZeroSumSubspace K)
    {a : UL.ZeroSumSubspace K} (ha : a ∈ shiftedSimplex K) :
    let p := proxPoint hK hF_cont δ s
    shiftedFun F p - shiftedFun F a ≤ (1 / δ) * ⟪s - p, p - a⟫ := by
  set p := proxPoint hK hF_cont δ s
  have hp : p ∈ shiftedSimplex K := proxPoint_mem hK hF_cont δ s
  have hΦ_conv := convexOn_shiftedFun hF_conv
  have h_for_t : ∀ t : ℝ, 0 < t → t < 1 →
      shiftedFun F p - shiftedFun F a ≤
        (1 / δ) * ⟪s - p, p - a⟫ + (t / (2 * δ)) * ‖a - p‖ ^ 2 := by
    intro t ht0 ht1
    let pt : UL.ZeroSumSubspace K := (1 - t) • p + t • a
    have hpt_mem : pt ∈ shiftedSimplex K :=
      convex_shiftedSimplex K hp ha (by linarith) ht0.le (by ring)
    have hmin : moreauObj F δ s p ≤ moreauObj F δ s pt :=
      moreauEnv_le hK hF_cont δ s hpt_mem
    have hconv : shiftedFun F pt ≤ (1 - t) * shiftedFun F p + t * shiftedFun F a :=
      hΦ_conv.2 hp ha (by linarith) ht0.le (by ring)
    have hpt_sub : pt - s = (p - s) + t • (a - p) := by
      simp only [pt, sub_smul, one_smul, smul_sub]
      abel
    have hnorm_sq : ‖pt - s‖ ^ 2 =
        ‖p - s‖ ^ 2 + 2 * t * ⟪p - s, a - p⟫ + t ^ 2 * ‖a - p‖ ^ 2 := by
      rw [hpt_sub, norm_add_sq_real, norm_smul, Real.norm_of_nonneg ht0.le,
        inner_smul_right, mul_pow]
      ring
    have hinner_eq : ⟪p - s, a - p⟫ = ⟪s - p, p - a⟫ := by
      have h1 : p - s = -(s - p) := by abel
      have h2 : a - p = -(p - a) := by abel
      rw [h1, h2, inner_neg_left, inner_neg_right, neg_neg]
    unfold moreauObj at hmin
    rw [hnorm_sq, hinner_eq] at hmin
    have hcomb : t * (shiftedFun F p - shiftedFun F a) ≤
        (1 / (2 * δ)) * (2 * t * ⟪s - p, p - a⟫ + t ^ 2 * ‖a - p‖ ^ 2) := by
      linarith
    have hdiv : shiftedFun F p - shiftedFun F a ≤
        ((1 / (2 * δ)) * (2 * t * ⟪s - p, p - a⟫ + t ^ 2 * ‖a - p‖ ^ 2)) / t := by
      rw [le_div_iff₀ ht0]
      linarith
    have hsimp : ((1 / (2 * δ)) * (2 * t * ⟪s - p, p - a⟫ + t ^ 2 * ‖a - p‖ ^ 2)) / t =
        (1 / δ) * ⟪s - p, p - a⟫ + (t / (2 * δ)) * ‖a - p‖ ^ 2 := by
      have ht_ne : t ≠ 0 := ht0.ne'
      have hδ_ne : δ ≠ 0 := hδ.ne'
      field_simp [ht_ne, hδ_ne]
    linarith
  by_contra hlt
  push_neg at hlt
  set gap := (shiftedFun F p - shiftedFun F a) - (1 / δ) * ⟪s - p, p - a⟫ with hgap_def
  have hgap_pos : 0 < gap := by linarith [hgap_def]
  let t₀ : ℝ := min (1 / 2) (gap * δ / (‖a - p‖ ^ 2 + 1))
  have ht₀_pos : 0 < t₀ := lt_min (by norm_num) (by positivity)
  have ht₀_lt : t₀ < 1 := lt_of_le_of_lt (min_le_left _ _) (by norm_num)
  have hineq := h_for_t t₀ ht₀_pos ht₀_lt
  have hrem : (t₀ / (2 * δ)) * ‖a - p‖ ^ 2 ≤ gap / 2 := by
    have ht₀_le : t₀ ≤ gap * δ / (‖a - p‖ ^ 2 + 1) := min_le_right _ _
    have h1 : (t₀ / (2 * δ)) * ‖a - p‖ ^ 2 ≤
        ((gap * δ / (‖a - p‖ ^ 2 + 1)) / (2 * δ)) * ‖a - p‖ ^ 2 := by
      gcongr
    have h2 : ((gap * δ / (‖a - p‖ ^ 2 + 1)) / (2 * δ)) * ‖a - p‖ ^ 2 =
        (gap / 2) * (‖a - p‖ ^ 2 / (‖a - p‖ ^ 2 + 1)) := by
      have hδ_ne : δ ≠ 0 := hδ.ne'
      have hden_ne : ‖a - p‖ ^ 2 + 1 ≠ 0 := by positivity
      field_simp [hδ_ne, hden_ne]
    have h3 : ‖a - p‖ ^ 2 / (‖a - p‖ ^ 2 + 1) ≤ 1 := by
      rw [div_le_one (by positivity)]
      linarith
    calc
      (t₀ / (2 * δ)) * ‖a - p‖ ^ 2 ≤
          (gap / 2) * (‖a - p‖ ^ 2 / (‖a - p‖ ^ 2 + 1)) := by linarith
      _ ≤ (gap / 2) * 1 := mul_le_mul_of_nonneg_left h3 (by positivity)
      _ = gap / 2 := mul_one _
  linarith [hgap_def]

/-- Nonexpansiveness (`1`-Lipschitz) of `proxPoint`. -/
lemma norm_proxPoint_sub_le {K : ℕ} (hK : 2 ≤ K) {F : UL.Simplex K → ℝ}
    (hF_cont : Continuous F)
    (hF_conv : ConvexOn ℝ (UL.Simplex K) (UL.extendSimplex F))
    {δ : ℝ} (hδ : 0 < δ) (s₁ s₂ : UL.ZeroSumSubspace K) :
    ‖proxPoint hK hF_cont δ s₁ - proxPoint hK hF_cont δ s₂‖ ≤ ‖s₁ - s₂‖ := by
  set p₁ := proxPoint hK hF_cont δ s₁
  set p₂ := proxPoint hK hF_cont δ s₂
  have hp₁ : p₁ ∈ shiftedSimplex K := proxPoint_mem hK hF_cont δ s₁
  have hp₂ : p₂ ∈ shiftedSimplex K := proxPoint_mem hK hF_cont δ s₂
  have hvi₁ : shiftedFun F p₁ - shiftedFun F p₂ ≤ (1 / δ) * ⟪s₁ - p₁, p₁ - p₂⟫ :=
    proxPoint_variational_ineq hK hF_cont hF_conv hδ s₁ hp₂
  have hvi₂ : shiftedFun F p₂ - shiftedFun F p₁ ≤ (1 / δ) * ⟪s₂ - p₂, p₂ - p₁⟫ :=
    proxPoint_variational_ineq hK hF_cont hF_conv hδ s₂ hp₁
  have hsum : 0 ≤ (1 / δ) * (⟪s₁ - p₁, p₁ - p₂⟫ + ⟪s₂ - p₂, p₂ - p₁⟫) := by
    linarith
  have hsum2 : 0 ≤ ⟪s₁ - p₁, p₁ - p₂⟫ + ⟪s₂ - p₂, p₂ - p₁⟫ := by
    have hpos : 0 < 1 / δ := one_div_pos.mpr hδ
    nlinarith
  have halg : ⟪s₁ - p₁, p₁ - p₂⟫ + ⟪s₂ - p₂, p₂ - p₁⟫ =
      ⟪s₁ - s₂, p₁ - p₂⟫ - ‖p₁ - p₂‖ ^ 2 := by
    have hneg : p₂ - p₁ = -(p₁ - p₂) := by abel
    rw [hneg, inner_neg_right, ← sub_eq_add_neg, ← inner_sub_left]
    have hsub : (s₁ - p₁) - (s₂ - p₂) = (s₁ - s₂) - (p₁ - p₂) := by abel
    rw [hsub, inner_sub_left, real_inner_self_eq_norm_sq]
  have hsq : ‖p₁ - p₂‖ ^ 2 ≤ ‖s₁ - s₂‖ * ‖p₁ - p₂‖ := by
    have hcs : ⟪s₁ - s₂, p₁ - p₂⟫ ≤ ‖s₁ - s₂‖ * ‖p₁ - p₂‖ := real_inner_le_norm _ _
    linarith
  by_cases hp0 : ‖p₁ - p₂‖ = 0
  · rw [hp0]; exact norm_nonneg _
  · have hp_pos : 0 < ‖p₁ - p₂‖ := lt_of_le_of_ne (norm_nonneg _) (Ne.symm hp0)
    nlinarith

/-- Quadratic Taylor remainder bound for `moreauEnv`, yielding `HasGradientAt`. -/
lemma hasGradientAt_moreauEnv {K : ℕ} (hK : 2 ≤ K) {F : UL.Simplex K → ℝ}
    (hF_cont : Continuous F)
    (hF_conv : ConvexOn ℝ (UL.Simplex K) (UL.extendSimplex F))
    {δ : ℝ} (hδ : 0 < δ) (s : UL.ZeroSumSubspace K) :
    HasGradientAt (moreauEnv hK hF_cont δ)
      ((1 / δ) • (s - proxPoint hK hF_cont δ s)) s := by
  have h_upper : ∀ x y : UL.ZeroSumSubspace K,
      moreauEnv hK hF_cont δ y - moreauEnv hK hF_cont δ x -
        ⟪(1 / δ) • (x - proxPoint hK hF_cont δ x), y - x⟫ ≤
        (1 / (2 * δ)) * ‖y - x‖ ^ 2 := by
    intro x y
    set px := proxPoint hK hF_cont δ x
    have hpx : px ∈ shiftedSimplex K := proxPoint_mem hK hF_cont δ x
    have hle : moreauEnv hK hF_cont δ y ≤ moreauObj F δ y px :=
      moreauEnv_le hK hF_cont δ y hpx
    have heq : moreauObj F δ y px - moreauEnv hK hF_cont δ x =
        (1 / (2 * δ)) * (‖px - y‖ ^ 2 - ‖px - x‖ ^ 2) := by
      unfold moreauEnv moreauObj
      change (shiftedFun F px + (1 / (2 * δ)) * ‖px - y‖ ^ 2) -
        (shiftedFun F px + (1 / (2 * δ)) * ‖px - x‖ ^ 2) = _
      ring
    have hnorm_diff : ‖px - y‖ ^ 2 - ‖px - x‖ ^ 2 =
        2 * ⟪x - px, y - x⟫ + ‖y - x‖ ^ 2 := by
      have hsub : px - y = (px - x) - (y - x) := by abel
      rw [hsub, norm_sub_sq_real]
      have hinner : ⟪px - x, y - x⟫ = -⟪x - px, y - x⟫ := by
        have hn : px - x = -(x - px) := by abel
        rw [hn, inner_neg_left]
      rw [hinner]
      ring
    have hinner_smul : ⟪(1 / δ) • (x - px), y - x⟫ = (1 / δ) * ⟪x - px, y - x⟫ := by
      rw [inner_smul_left]; simp
    have hδ_ne : δ ≠ 0 := hδ.ne'
    have hcalc : (1 / (2 * δ)) * (2 * ⟪x - px, y - x⟫ + ‖y - x‖ ^ 2) -
        (1 / δ) * ⟪x - px, y - x⟫ = (1 / (2 * δ)) * ‖y - x‖ ^ 2 := by
      field_simp [hδ_ne]
      ring
    rw [hnorm_diff] at heq
    rw [hinner_smul]
    linarith
  have h_abs : ∀ s' : UL.ZeroSumSubspace K,
      ‖moreauEnv hK hF_cont δ s' - moreauEnv hK hF_cont δ s -
        ⟪(1 / δ) • (s - proxPoint hK hF_cont δ s), s' - s⟫‖ ≤
        (1 / (2 * δ)) * ‖s' - s‖ ^ 2 := by
    intro s'
    rw [Real.norm_eq_abs, abs_le]
    refine ⟨?_, h_upper s s'⟩
    set p := proxPoint hK hF_cont δ s
    set p' := proxPoint hK hF_cont δ s'
    have hswap := h_upper s' s
    have hnorm_symm : ‖s - s'‖ = ‖s' - s‖ := norm_sub_rev s s'
    rw [hnorm_symm] at hswap
    have hinner_swap : ⟪(1 / δ) • (s' - p'), s - s'⟫ = -(1 / δ) * ⟪s' - p', s' - s⟫ := by
      have hn : s - s' = -(s' - s) := by abel
      rw [hn, inner_neg_right, inner_smul_left]
      simp
    have hinner_s : ⟪(1 / δ) • (s - p), s' - s⟫ = (1 / δ) * ⟪s - p, s' - s⟫ := by
      rw [inner_smul_left]; simp
    have hdiff_inner : ⟪s' - p', s' - s⟫ - ⟪s - p, s' - s⟫ =
        ‖s' - s‖ ^ 2 - ⟪p' - p, s' - s⟫ := by
      rw [← inner_sub_left]
      have hsub : (s' - p') - (s - p) = (s' - s) - (p' - p) := by abel
      rw [hsub, inner_sub_left, real_inner_self_eq_norm_sq]
    have hcs : ⟪p' - p, s' - s⟫ ≤ ‖s' - s‖ ^ 2 := by
      calc
        ⟪p' - p, s' - s⟫ ≤ ‖p' - p‖ * ‖s' - s‖ := real_inner_le_norm _ _
        _ ≤ ‖s' - s‖ * ‖s' - s‖ := mul_le_mul_of_nonneg_right
            (norm_proxPoint_sub_le hK hF_cont hF_conv hδ s' s) (norm_nonneg _)
        _ = ‖s' - s‖ ^ 2 := (sq _).symm
    have hpos : 0 < 1 / δ := one_div_pos.mpr hδ
    have h1 : (1 / δ) * ⟪s' - p', s' - s⟫ - (1 / δ) * ⟪s - p, s' - s⟫ ≥ 0 := by
      have hdist : (1 / δ) * ⟪s' - p', s' - s⟫ - (1 / δ) * ⟪s - p, s' - s⟫ =
          (1 / δ) * (⟪s' - p', s' - s⟫ - ⟪s - p, s' - s⟫) := by ring
      rw [hdist, hdiff_inner]
      have : 0 ≤ ‖s' - s‖ ^ 2 - ⟪p' - p, s' - s⟫ := by linarith
      exact mul_nonneg hpos.le this
    rw [hinner_swap] at hswap
    rw [hinner_s]
    linarith
  rw [hasGradientAt_iff_tendsto]
  have h_squeeze : ∀ s' : UL.ZeroSumSubspace K,
      ‖s' - s‖⁻¹ * ‖moreauEnv hK hF_cont δ s' - moreauEnv hK hF_cont δ s -
        ⟪(1 / δ) • (s - proxPoint hK hF_cont δ s), s' - s⟫‖ ≤
        (1 / (2 * δ)) * ‖s' - s‖ := by
    intro s'
    by_cases hs0 : ‖s' - s‖ = 0
    · have hzero : s' = s := sub_eq_zero.mp (norm_eq_zero.mp hs0)
      simp [hzero]
    · have hpos : 0 < ‖s' - s‖ := lt_of_le_of_ne (norm_nonneg _) (Ne.symm hs0)
      calc
        ‖s' - s‖⁻¹ * ‖moreauEnv hK hF_cont δ s' - moreauEnv hK hF_cont δ s -
            ⟪(1 / δ) • (s - proxPoint hK hF_cont δ s), s' - s⟫‖
          ≤ ‖s' - s‖⁻¹ * ((1 / (2 * δ)) * ‖s' - s‖ ^ 2) :=
            mul_le_mul_of_nonneg_left (h_abs s') (inv_nonneg.mpr hpos.le)
        _ = (1 / (2 * δ)) * ‖s' - s‖ := by
          rw [sq]
          field_simp [hs0]
  have h_upper_tendsto : Tendsto (fun s' : UL.ZeroSumSubspace K => (1 / (2 * δ)) * ‖s' - s‖)
      (𝓝 s) (𝓝 0) := by
    have hc : Continuous (fun s' : UL.ZeroSumSubspace K => (1 / (2 * δ)) * ‖s' - s‖) := by
      fun_prop
    simpa using hc.tendsto s
  exact squeeze_zero (fun _ => by positivity) h_squeeze h_upper_tendsto

lemma differentiable_moreauEnv {K : ℕ} (hK : 2 ≤ K) {F : UL.Simplex K → ℝ}
    (hF_cont : Continuous F)
    (hF_conv : ConvexOn ℝ (UL.Simplex K) (UL.extendSimplex F))
    {δ : ℝ} (hδ : 0 < δ) :
    Differentiable ℝ (moreauEnv hK hF_cont δ) :=
  fun s => (hasGradientAt_moreauEnv hK hF_cont hF_conv hδ s).differentiableAt

lemma gradient_moreauEnv_eq {K : ℕ} (hK : 2 ≤ K) {F : UL.Simplex K → ℝ}
    (hF_cont : Continuous F)
    (hF_conv : ConvexOn ℝ (UL.Simplex K) (UL.extendSimplex F))
    {δ : ℝ} (hδ : 0 < δ) (s : UL.ZeroSumSubspace K) :
    ∇ (moreauEnv hK hF_cont δ) s = (1 / δ) • (s - proxPoint hK hF_cont δ s) :=
  (hasGradientAt_moreauEnv hK hF_cont hF_conv hδ s).gradient

lemma convexOn_moreauEnv {K : ℕ} (hK : 2 ≤ K) {F : UL.Simplex K → ℝ}
    (hF_cont : Continuous F)
    (hF_conv : ConvexOn ℝ (UL.Simplex K) (UL.extendSimplex F))
    {δ : ℝ} (hδ : 0 < δ) :
    ConvexOn ℝ Set.univ (moreauEnv hK hF_cont δ) := by
  refine ⟨convex_univ, fun s₁ _ s₂ _ a b ha hb hab => ?_⟩
  set p₁ := proxPoint hK hF_cont δ s₁
  set p₂ := proxPoint hK hF_cont δ s₂
  have hp₁ : p₁ ∈ shiftedSimplex K := proxPoint_mem hK hF_cont δ s₁
  have hp₂ : p₂ ∈ shiftedSimplex K := proxPoint_mem hK hF_cont δ s₂
  have hp_comb : a • p₁ + b • p₂ ∈ shiftedSimplex K :=
    convex_shiftedSimplex K hp₁ hp₂ ha hb hab
  have hle := moreauEnv_le hK hF_cont δ (a • s₁ + b • s₂) hp_comb
  have hΦ_ineq : shiftedFun F (a • p₁ + b • p₂) ≤
      a * shiftedFun F p₁ + b * shiftedFun F p₂ :=
    (convexOn_shiftedFun hF_conv).2 hp₁ hp₂ ha hb hab
  have hdiff : (a • p₁ + b • p₂) - (a • s₁ + b • s₂) = a • (p₁ - s₁) + b • (p₂ - s₂) := by
    simp only [smul_sub]
    abel
  have hnorm_ineq : ‖a • (p₁ - s₁) + b • (p₂ - s₂)‖ ^ 2 ≤
      a * ‖p₁ - s₁‖ ^ 2 + b * ‖p₂ - s₂‖ ^ 2 := by
    have htri : ‖a • (p₁ - s₁) + b • (p₂ - s₂)‖ ≤ a * ‖p₁ - s₁‖ + b * ‖p₂ - s₂‖ := by
      calc
        ‖a • (p₁ - s₁) + b • (p₂ - s₂)‖ ≤ ‖a • (p₁ - s₁)‖ + ‖b • (p₂ - s₂)‖ := norm_add_le _ _
        _ = a * ‖p₁ - s₁‖ + b * ‖p₂ - s₂‖ := by
          rw [norm_smul, norm_smul, Real.norm_of_nonneg ha, Real.norm_of_nonneg hb]
    have hsq1 : ‖a • (p₁ - s₁) + b • (p₂ - s₂)‖ ^ 2 ≤ (a * ‖p₁ - s₁‖ + b * ‖p₂ - s₂‖) ^ 2 :=
      pow_le_pow_left₀ (norm_nonneg _) htri 2
    have hsq2 : a * ‖p₁ - s₁‖ ^ 2 + b * ‖p₂ - s₂‖ ^ 2 -
        (a * ‖p₁ - s₁‖ + b * ‖p₂ - s₂‖) ^ 2 =
        a * b * (‖p₁ - s₁‖ - ‖p₂ - s₂‖) ^ 2 := by
      have hb_eq : b = 1 - a := by linarith
      rw [hb_eq]
      ring
    have hnonneg : 0 ≤ a * b * (‖p₁ - s₁‖ - ‖p₂ - s₂‖) ^ 2 := by positivity
    linarith
  unfold moreauObj at hle
  rw [hdiff] at hle
  have hpos : 0 ≤ 1 / (2 * δ) := by positivity
  have hmul : (1 / (2 * δ)) * ‖a • (p₁ - s₁) + b • (p₂ - s₂)‖ ^ 2 ≤
      (1 / (2 * δ)) * (a * ‖p₁ - s₁‖ ^ 2 + b * ‖p₂ - s₂‖ ^ 2) :=
    mul_le_mul_of_nonneg_left hnorm_ineq hpos
  have h_e1 : moreauEnv hK hF_cont δ s₁ = shiftedFun F p₁ + (1 / (2 * δ)) * ‖p₁ - s₁‖ ^ 2 := rfl
  have h_e2 : moreauEnv hK hF_cont δ s₂ = shiftedFun F p₂ + (1 / (2 * δ)) * ‖p₂ - s₂‖ ^ 2 := rfl
  have hdist : a * (shiftedFun F p₁ + (1 / (2 * δ)) * ‖p₁ - s₁‖ ^ 2) +
      b * (shiftedFun F p₂ + (1 / (2 * δ)) * ‖p₂ - s₂‖ ^ 2) =
      (a * shiftedFun F p₁ + b * shiftedFun F p₂) +
      (1 / (2 * δ)) * (a * ‖p₁ - s₁‖ ^ 2 + b * ‖p₂ - s₂‖ ^ 2) := by ring
  rw [smul_eq_mul, smul_eq_mul, h_e1, h_e2, hdist]
  linarith

lemma lipschitz_gradient_moreauEnv {K : ℕ} (hK : 2 ≤ K) {F : UL.Simplex K → ℝ}
    (hF_cont : Continuous F)
    (hF_conv : ConvexOn ℝ (UL.Simplex K) (UL.extendSimplex F))
    {δ : ℝ} (hδ : 0 < δ) :
    ∃ L : NNReal, LipschitzWith L (∇ (moreauEnv hK hF_cont δ)) := by
  refine ⟨Real.toNNReal (2 / δ), LipschitzWith.of_dist_le_mul fun s₁ s₂ => ?_⟩
  rw [Real.coe_toNNReal _ (by positivity), dist_eq_norm, dist_eq_norm,
    gradient_moreauEnv_eq hK hF_cont hF_conv hδ s₁,
    gradient_moreauEnv_eq hK hF_cont hF_conv hδ s₂, ← smul_sub, norm_smul,
    Real.norm_of_nonneg (by positivity)]
  have hsub : (s₁ - proxPoint hK hF_cont δ s₁) - (s₂ - proxPoint hK hF_cont δ s₂) =
      (s₁ - s₂) - (proxPoint hK hF_cont δ s₁ - proxPoint hK hF_cont δ s₂) := by abel
  rw [hsub]
  have htri : ‖(s₁ - s₂) - (proxPoint hK hF_cont δ s₁ - proxPoint hK hF_cont δ s₂)‖ ≤
      2 * ‖s₁ - s₂‖ := by
    calc
      ‖(s₁ - s₂) - (proxPoint hK hF_cont δ s₁ - proxPoint hK hF_cont δ s₂)‖
        ≤ ‖s₁ - s₂‖ + ‖proxPoint hK hF_cont δ s₁ - proxPoint hK hF_cont δ s₂‖ := norm_sub_le _ _
      _ ≤ ‖s₁ - s₂‖ + ‖s₁ - s₂‖ := add_le_add le_rfl
          (norm_proxPoint_sub_le hK hF_cont hF_conv hδ s₁ s₂)
      _ = 2 * ‖s₁ - s₂‖ := by ring
  calc
    (1 / δ) * ‖(s₁ - s₂) - (proxPoint hK hF_cont δ s₁ - proxPoint hK hF_cont δ s₂)‖
      ≤ (1 / δ) * (2 * ‖s₁ - s₂‖) := mul_le_mul_of_nonneg_left htri (by positivity)
    _ = (2 / δ) * ‖s₁ - s₂‖ := by ring

/-! ### Part 4: Convergence on the trimmed simplex and `trimmed_test_nonpos` -/

lemma closedBall_trimmed_subset_shiftedRelint {K : ℕ} (hK : 2 ≤ K)
    {s : UL.ZeroSumSubspace K} (hs : s ∈ shiftedSimplex K)
    {ε : ℝ} (hε0 : 0 < ε) (hε1 : ε < 1) :
    Metric.closedBall ((1 - ε) • s) (ε / (2 * (K : ℝ))) ⊆ shiftedRelint K := by
  have hKpos : (0 : ℝ) < K := by exact_mod_cast (by omega : 0 < K)
  intro w hw
  rw [mem_shiftedRelint_iff hK]
  intro j
  rw [Metric.mem_closedBall, dist_eq_norm] at hw
  have hw_coord : |((w - (1 - ε) • s : UL.ZeroSumSubspace K) :
      EuclideanSpace ℝ (Fin K)) j| ≤ ε / (2 * (K : ℝ)) := by
    calc
      |((w - (1 - ε) • s : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) j|
        ≤ ‖((w - (1 - ε) • s : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))‖ := by
          simpa [Real.norm_eq_abs] using
            PiLp.norm_apply_le ((w - (1 - ε) • s : UL.ZeroSumSubspace K) :
              EuclideanSpace ℝ (Fin K)) j
      _ = ‖w - (1 - ε) • s‖ := Submodule.norm_coe _
      _ ≤ ε / (2 * (K : ℝ)) := hw
  have h_trimmed_coord : (UL.uniformVec K + (((1 - ε) • s : UL.ZeroSumSubspace K) :
      EuclideanSpace ℝ (Fin K))) j ≥ ε / (K : ℝ) := by
    have heq : UL.uniformVec K + (((1 - ε) • s : UL.ZeroSumSubspace K) :
        EuclideanSpace ℝ (Fin K)) =
        (1 - ε) • (UL.uniformVec K + (s : EuclideanSpace ℝ (Fin K))) +
        ε • UL.uniformVec K := by
      push_cast
      simp only [sub_smul, one_smul, smul_add]
      abel
    rw [heq, PiLp.add_apply, PiLp.smul_apply, PiLp.smul_apply, smul_eq_mul, smul_eq_mul,
      uniformVec_apply]
    have hnonneg : 0 ≤ (1 - ε) * (UL.uniformVec K + (s : EuclideanSpace ℝ (Fin K))) j :=
      mul_nonneg (by linarith) (hs.1 j)
    have hmul : ε * (1 / (K : ℝ)) = ε / (K : ℝ) := by ring
    linarith
  have hw_decomp : (UL.uniformVec K + (w : EuclideanSpace ℝ (Fin K))) j =
      (UL.uniformVec K + (((1 - ε) • s : UL.ZeroSumSubspace K) :
        EuclideanSpace ℝ (Fin K))) j +
      ((w - (1 - ε) • s : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) j := by
    push_cast
    simp only [PiLp.add_apply, PiLp.sub_apply]
    ring
  have h_lower : -(ε / (2 * (K : ℝ))) ≤
      ((w - (1 - ε) • s : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) j :=
    (abs_le.mp hw_coord).1
  have hhalf_pos : 0 < ε / (2 * (K : ℝ)) := by positivity
  have hdiff_pos : ε / (K : ℝ) - ε / (2 * (K : ℝ)) = ε / (2 * (K : ℝ)) := by
    have hK0 : (K : ℝ) ≠ 0 := hKpos.ne'
    field_simp [hK0]
    ring
  rw [hw_decomp]
  linarith

lemma norm_proxPoint_sub_self_sq_le {K : ℕ} (hK : 2 ≤ K) {F : UL.Simplex K → ℝ}
    (hF_cont : Continuous F)
    {oscBound : ℝ} (hOsc : ∀ q₁ ∈ UL.Simplex K, ∀ q₂ ∈ UL.Simplex K,
      UL.extendSimplex F q₁ - UL.extendSimplex F q₂ ≤ oscBound)
    {δ : ℝ} (hδ : 0 < δ) {s' : UL.ZeroSumSubspace K} (hs' : s' ∈ shiftedSimplex K) :
    ‖proxPoint hK hF_cont δ s' - s'‖ ^ 2 ≤ 2 * δ * oscBound := by
  have hle : moreauObj F δ s' (proxPoint hK hF_cont δ s') ≤ moreauObj F δ s' s' :=
    moreauEnv_le hK hF_cont δ s' hs'
  have hp_mem : proxPoint hK hF_cont δ s' ∈ shiftedSimplex K :=
    proxPoint_mem hK hF_cont δ s'
  have hosc : shiftedFun F s' - shiftedFun F (proxPoint hK hF_cont δ s') ≤ oscBound :=
    hOsc _ hs' _ hp_mem
  have h0 : moreauObj F δ s' s' = shiftedFun F s' := by
    unfold moreauObj
    simp
  rw [h0] at hle
  unfold moreauObj at hle
  have h1 : (1 / (2 * δ)) * ‖proxPoint hK hF_cont δ s' - s'‖ ^ 2 ≤ oscBound := by linarith
  have h2δ : 0 < 2 * δ := by positivity
  have hδ_ne : δ ≠ 0 := hδ.ne'
  have hmul := mul_le_mul_of_nonneg_left h1 h2δ.le
  have hcancel : (2 * δ) * ((1 / (2 * δ)) * ‖proxPoint hK hF_cont δ s' - s'‖ ^ 2) =
      ‖proxPoint hK hF_cont δ s' - s'‖ ^ 2 := by
    field_simp [hδ_ne]
  linarith

/-- If `proxPoint hK hF_cont δ s'` lies in the open interior `shiftedRelint K`,
then `gradient (moreauEnv ...) s' = gradient (shiftedFun F) (proxPoint ...)`. -/
lemma gradient_moreauEnv_eq_gradient_shiftedFun_of_mem_relint {K : ℕ} (hK : 2 ≤ K)
    {F : UL.Simplex K → ℝ} (hF_cont : Continuous F)
    (hF_conv : ConvexOn ℝ (UL.Simplex K) (UL.extendSimplex F))
    (hF_diff : ∀ J : Finset (Fin K), J.Nonempty →
      ∀ p ∈ UL.SimplexFaceRelint K J, ∃ g, UL.HasFaceGradAt F J p g)
    {δ : ℝ} (hδ : 0 < δ) {s' : UL.ZeroSumSubspace K}
    (hp_relint : proxPoint hK hF_cont δ s' ∈ shiftedRelint K) :
    ∇ (moreauEnv hK hF_cont δ) s' = ∇ (shiftedFun F) (proxPoint hK hF_cont δ s') := by
  set p := proxPoint hK hF_cont δ s'
  rw [gradient_moreauEnv_eq hK hF_cont hF_conv hδ s']
  obtain ⟨gH, _, hgH_grad⟩ := hasGradientAt_shiftedFun hK hF_diff hp_relint
  rw [hgH_grad.gradient]
  -- Local minimum of `moreauObj F δ s'` at `p ∈ shiftedRelint K`
  have h_loc_min : IsLocalMin (moreauObj F δ s') p := by
    have hmem : shiftedSimplex K ∈ 𝓝 p :=
      Filter.mem_of_superset ((isOpen_shiftedRelint hK).mem_nhds hp_relint)
        (shiftedRelint_subset K)
    exact (proxPoint_isMinOn hK hF_cont δ s').isLocalMin hmem
  -- `moreauObj F δ s'` has gradient `gH + (1 / δ) • (p - s')` at `p`
  have h_quad_grad : HasGradientAt (fun a : UL.ZeroSumSubspace K => (1 / (2 * δ)) * ‖a - s'‖ ^ 2)
      ((1 / δ) • (p - s')) p := by
    rw [hasGradientAt_iff_tendsto]
    have h_ident : ∀ a : UL.ZeroSumSubspace K,
        (1 / (2 * δ)) * ‖a - s'‖ ^ 2 - (1 / (2 * δ)) * ‖p - s'‖ ^ 2 -
          ⟪(1 / δ) • (p - s'), a - p⟫ = (1 / (2 * δ)) * ‖a - p‖ ^ 2 := by
      intro a
      have hdecomp : a - s' = (p - s') + (a - p) := by abel
      rw [hdecomp, norm_add_sq_real, inner_smul_left]
      simp only [RCLike.conj_to_real]
      have hδ_ne : δ ≠ 0 := hδ.ne'
      field_simp [hδ_ne]
      ring
    have h_eq_fn : (fun a : UL.ZeroSumSubspace K =>
        ‖a - p‖⁻¹ * ‖(1 / (2 * δ)) * ‖a - s'‖ ^ 2 - (1 / (2 * δ)) * ‖p - s'‖ ^ 2 -
          ⟪(1 / δ) • (p - s'), a - p⟫‖) =
        fun a => ‖a - p‖⁻¹ * ((1 / (2 * δ)) * ‖a - p‖ ^ 2) := by
      ext a
      rw [h_ident a, Real.norm_of_nonneg (by positivity)]
    rw [h_eq_fn]
    have h_squeeze : ∀ a : UL.ZeroSumSubspace K,
        ‖a - p‖⁻¹ * ((1 / (2 * δ)) * ‖a - p‖ ^ 2) ≤ (1 / (2 * δ)) * ‖a - p‖ := by
      intro a
      by_cases ha : ‖a - p‖ = 0
      · simp [ha]
      · have heq_a : ‖a - p‖⁻¹ * ((1 / (2 * δ)) * ‖a - p‖ ^ 2) = (1 / (2 * δ)) * ‖a - p‖ := by
          rw [sq]
          field_simp [ha]
        rw [heq_a]
    have hc : Continuous (fun a : UL.ZeroSumSubspace K => (1 / (2 * δ)) * ‖a - p‖) := by fun_prop
    exact squeeze_zero (fun _ => by positivity) h_squeeze (by simpa using hc.tendsto p)
  have h_obj_fderiv : HasFDerivAt (moreauObj F δ s')
      (InnerProductSpace.toDual ℝ _ (gH + (1 / δ) • (p - s'))) p := by
    have hadd := hgH_grad.hasFDerivAt.add h_quad_grad.hasFDerivAt
    have hmap : InnerProductSpace.toDual ℝ (UL.ZeroSumSubspace K) gH +
        InnerProductSpace.toDual ℝ (UL.ZeroSumSubspace K) ((1 / δ) • (p - s')) =
        InnerProductSpace.toDual ℝ (UL.ZeroSumSubspace K) (gH + (1 / δ) • (p - s')) := by
      ext v
      exact (inner_add_left gH ((1 / δ) • (p - s')) v).symm
    rwa [hmap] at hadd
  have hzero_clm := h_loc_min.hasFDerivAt_eq_zero h_obj_fderiv
  have hzero : gH + (1 / δ) • (p - s') = 0 := by
    have hself : ⟪gH + (1 / δ) • (p - s'), gH + (1 / δ) • (p - s')⟫ = 0 :=
      DFunLike.congr_fun hzero_clm (gH + (1 / δ) • (p - s'))
    exact inner_self_eq_zero.mp hself
  have heq : (1 / δ) • (s' - p) = -((1 / δ) • (p - s')) := by
    rw [← smul_neg, neg_sub]
  rw [heq]
  exact (eq_neg_of_add_eq_zero_left hzero).symm

/-- Rescaled Moreau envelope test inequality at fixed `(ε, δ)`. -/
private lemma smooth_test_at_moreau {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    {K : ℕ} (hK : 2 ≤ K)
    {P : Ω → EuclideanSpace ℝ (Fin K)} {Y : Ω → Fin K}
    (hsmooth : ∀ (f : UL.ZeroSumSubspace K → ℝ),
      Differentiable ℝ f →
      ConvexOn ℝ Set.univ f →
      (∃ L : NNReal, LipschitzWith L (gradient f)) →
      ∫ ω, ⟪UL.fitResidual P Y ω,
        (↑(gradient f ((UL.ZeroSumSubspace K).orthogonalProjection (P ω - UL.uniformVec K))) :
          EuclideanSpace ℝ (Fin K))⟫ ∂μ ≤ 0)
    {F : UL.Simplex K → ℝ} (hF_cont : Continuous F)
    (hF_conv : ConvexOn ℝ (UL.Simplex K) (UL.extendSimplex F))
    {ε δ : ℝ} (hε1 : ε < 1) (hδ : 0 < δ) :
    ∫ ω, ⟪UL.fitResidual P Y ω,
      (↑(∇ (moreauEnv hK hF_cont δ)
        ((1 - ε) • (UL.ZeroSumSubspace K).orthogonalProjection (P ω - UL.uniformVec K))) :
        EuclideanSpace ℝ (Fin K))⟫ ∂μ ≤ 0 := by
  have h1e_pos : 0 < 1 - ε := by linarith
  let f : UL.ZeroSumSubspace K → ℝ :=
    fun x => moreauEnv hK hF_cont δ ((1 - ε) • x) / (1 - ε)
  have hf_grad : ∀ x : UL.ZeroSumSubspace K,
      HasGradientAt f (∇ (moreauEnv hK hF_cont δ) ((1 - ε) • x)) x := by
    intro x
    set g := ∇ (moreauEnv hK hF_cont δ) ((1 - ε) • x)
    have hg : HasFDerivAt (moreauEnv hK hF_cont δ)
        (InnerProductSpace.toDual ℝ _ g) ((1 - ε) • x) :=
      (differentiable_moreauEnv hK hF_cont hF_conv hδ ((1 - ε) • x)).hasGradientAt.hasFDerivAt
    have hscale : HasFDerivAt (fun y : UL.ZeroSumSubspace K => (1 - ε) • y)
        ((1 - ε) • ContinuousLinearMap.id ℝ (UL.ZeroSumSubspace K)) x := by
      simpa using (ContinuousLinearMap.id ℝ (UL.ZeroSumSubspace K)).hasFDerivAt.const_smul (1 - ε)
    have hcomp := hg.comp x hscale
    have hdiv : HasFDerivAt f
        ((1 / (1 - ε)) • ((InnerProductSpace.toDual ℝ _ g).comp
          ((1 - ε) • ContinuousLinearMap.id ℝ (UL.ZeroSumSubspace K)))) x := by
      simpa [f, div_eq_inv_mul] using hcomp.const_smul (1 / (1 - ε))
    rw [hasGradientAt_iff_hasFDerivAt]
    refine hdiv.congr_fderiv ?_
    ext v
    simp only [ContinuousLinearMap.smul_apply, ContinuousLinearMap.comp_apply,
      ContinuousLinearMap.id_apply, smul_eq_mul]
    rw [map_smul, smul_eq_mul]
    have hne : 1 - ε ≠ 0 := h1e_pos.ne'
    field_simp [hne]
  have hf_diff : Differentiable ℝ f := fun x => (hf_grad x).differentiableAt
  have hf_grad_eq : gradient f = fun x => ∇ (moreauEnv hK hF_cont δ) ((1 - ε) • x) :=
    funext fun x => (hf_grad x).gradient
  have hf_conv : ConvexOn ℝ Set.univ f := by
    refine ⟨convex_univ, fun x₁ _ x₂ _ a b ha hb hab => ?_⟩
    change moreauEnv hK hF_cont δ ((1 - ε) • (a • x₁ + b • x₂)) / (1 - ε) ≤
      a * (moreauEnv hK hF_cont δ ((1 - ε) • x₁) / (1 - ε)) +
      b * (moreauEnv hK hF_cont δ ((1 - ε) • x₂) / (1 - ε))
    have hlin : (1 - ε) • (a • x₁ + b • x₂) = a • ((1 - ε) • x₁) + b • ((1 - ε) • x₂) := by
      rw [smul_add, smul_comm (1 - ε) a, smul_comm (1 - ε) b]
    rw [hlin]
    have hconv_m := (convexOn_moreauEnv hK hF_cont hF_conv hδ).2
      (mem_univ ((1 - ε) • x₁)) (mem_univ ((1 - ε) • x₂)) ha hb hab
    simp only [smul_eq_mul] at hconv_m
    rw [div_le_iff₀ h1e_pos]
    have hcalc : (a * (moreauEnv hK hF_cont δ ((1 - ε) • x₁) / (1 - ε)) +
        b * (moreauEnv hK hF_cont δ ((1 - ε) • x₂) / (1 - ε))) * (1 - ε) =
        a * moreauEnv hK hF_cont δ ((1 - ε) • x₁) +
        b * moreauEnv hK hF_cont δ ((1 - ε) • x₂) := by
      have hne : 1 - ε ≠ 0 := h1e_pos.ne'
      field_simp [hne]
    linarith
  have hf_lip : ∃ L : NNReal, LipschitzWith L (gradient f) := by
    obtain ⟨Lm, hLm⟩ := lipschitz_gradient_moreauEnv hK hF_cont hF_conv hδ
    rw [hf_grad_eq]
    have hscale_lip : LipschitzWith (Real.toNNReal (1 - ε))
        (fun x : UL.ZeroSumSubspace K => (1 - ε) • x) := by
      refine LipschitzWith.of_dist_le_mul fun x₁ x₂ => ?_
      rw [Real.coe_toNNReal _ h1e_pos.le, dist_eq_norm, dist_eq_norm, ← smul_sub,
        norm_smul, Real.norm_of_nonneg h1e_pos.le]
    exact ⟨Lm * Real.toNNReal (1 - ε), hLm.comp hscale_lip⟩
  have hres := hsmooth f hf_diff hf_conv hf_lip
  rwa [hf_grad_eq] at hres

/-- **Main theorem of `H2_Moreau`** (equation `(core:trimmed-test)` in the paper):
For any `0 < ε < 1`, the `ε`-trimmed gradient inner product is integrable and has
nonpositive expectation. -/
theorem trimmed_test_nonpos
    {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    {K : ℕ} (hK : 2 ≤ K)
    {P : Ω → EuclideanSpace ℝ (Fin K)} {Y : Ω → Fin K}
    (hP_meas : Measurable P) (hY_meas : Measurable Y)
    (hP : ∀ ω, P ω ∈ UL.Simplex K)
    (hsmooth : ∀ (f : UL.ZeroSumSubspace K → ℝ),
      Differentiable ℝ f →
      ConvexOn ℝ Set.univ f →
      (∃ L : NNReal, LipschitzWith L (gradient f)) →
      ∫ ω, ⟪UL.fitResidual P Y ω,
        (↑(gradient f ((UL.ZeroSumSubspace K).orthogonalProjection (P ω - UL.uniformVec K))) :
          EuclideanSpace ℝ (Fin K))⟫ ∂μ ≤ 0)
    {F : UL.Simplex K → ℝ} (hF_cont : Continuous F)
    (hF_conv : ConvexOn ℝ (UL.Simplex K) (UL.extendSimplex F))
    (hF_diff : ∀ J : Finset (Fin K), J.Nonempty →
      ∀ p ∈ UL.SimplexFaceRelint K J, ∃ g, UL.HasFaceGradAt F J p g)
    {ε : ℝ} (hε0 : 0 < ε) (hε1 : ε < 1) :
    (∫ ω, ⟪UL.fitResidual P Y ω,
      UL.faceGrad F Finset.univ ((1 - ε) • P ω + ε • UL.uniformVec K)⟫ ∂μ ≤ 0) ∧
    Integrable (fun ω => ⟪UL.fitResidual P Y ω,
      UL.faceGrad F Finset.univ ((1 - ε) • P ω + ε • UL.uniformVec K)⟫) μ := by
  obtain ⟨oscBound, hOsc_nonneg, hOsc⟩ := exists_oscillation_bound hK hF_cont
  have hKpos : (0 : ℝ) < K := by exact_mod_cast (by omega : 0 < K)
  set ρ : ℝ := ε / (2 * (K : ℝ)) with hρ_def
  have hρ_pos : 0 < ρ := by positivity
  have hρ2_pos : 0 < ρ / 2 := half_pos hρ_pos
  -- Measurable random vectors
  let s_rv : Ω → UL.ZeroSumSubspace K :=
    fun ω => (UL.ZeroSumSubspace K).orthogonalProjection (P ω - UL.uniformVec K)
  have hs_rv_meas : Measurable s_rv :=
    (UL.ZeroSumSubspace K).orthogonalProjection.continuous.measurable.comp
      (hP_meas.sub measurable_const)
  have hs_rv_mem : ∀ ω : Ω, s_rv ω ∈ shiftedSimplex K := by
    intro ω
    change UL.uniformVec K + (↑(s_rv ω) : EuclideanSpace ℝ (Fin K)) ∈ UL.Simplex K
    have hcoe := coe_orthogonalProjection_sub_uniformVec hK (hP ω)
    have heq : UL.uniformVec K + (↑(s_rv ω) : EuclideanSpace ℝ (Fin K)) = P ω := by
      change UL.uniformVec K +
        (↑((UL.ZeroSumSubspace K).orthogonalProjection (P ω - UL.uniformVec K)) :
          EuclideanSpace ℝ (Fin K)) = P ω
      rw [hcoe]; abel
    rw [heq]; exact hP ω
  have hr_meas : Measurable (UL.fitResidual P Y) := by
    have hZ_meas : Measurable (UL.oneHotLabel Y) :=
      (measurable_of_finite (UL.oneHotVec (K := K))).comp hY_meas
    exact hP_meas.sub hZ_meas
  let sε_rv : Ω → UL.ZeroSumSubspace K := fun ω => (1 - ε) • s_rv ω
  have hsε_meas : Measurable sε_rv := (continuous_const_smul (1 - ε)).measurable.comp hs_rv_meas
  have hsε_relint : ∀ ω : Ω, sε_rv ω ∈ shiftedRelint K := by
    intro ω
    exact closedBall_trimmed_subset_shiftedRelint hK (hs_rv_mem ω) hε0 hε1
      (Metric.mem_closedBall_self hρ_pos.le)
  -- Relate `faceGrad F univ ((1 - ε) • P ω + ε • u)` to `∇ (shiftedFun F) (sε_rv ω)`
  have h_target_eq : ∀ ω : Ω,
      UL.faceGrad F Finset.univ ((1 - ε) • P ω + ε • UL.uniformVec K) =
        (↑(∇ (shiftedFun F) (sε_rv ω)) : EuclideanSpace ℝ (Fin K)) := by
    intro ω
    rw [coe_gradient_shiftedFun hK hF_diff (hsε_relint ω)]
    congr 1
    have hcoe : (↑(s_rv ω) : EuclideanSpace ℝ (Fin K)) = P ω - UL.uniformVec K :=
      coe_orthogonalProjection_sub_uniformVec hK (hP ω)
    have hsε_coe : (↑(sε_rv ω) : EuclideanSpace ℝ (Fin K)) =
        (1 - ε) • (↑(s_rv ω) : EuclideanSpace ℝ (Fin K)) := rfl
    rw [hsε_coe, hcoe]
    simp only [sub_smul, one_smul, smul_sub]
    abel
  -- Measurability & integrability of target function
  set target : Ω → ℝ := fun ω =>
    ⟪UL.fitResidual P Y ω, UL.faceGrad F Finset.univ ((1 - ε) • P ω + ε • UL.uniformVec K)⟫
  have hgrad_cont : ContinuousOn (∇ (shiftedFun F)) (shiftedRelint K) :=
    continuousOn_gradient_shiftedFun hK hF_cont hF_conv hF_diff
  have hgrad_rv_meas : Measurable (fun ω : Ω => ∇ (shiftedFun F) (sε_rv ω)) := by
    let sε_sub : Ω → shiftedRelint K := fun ω => ⟨sε_rv ω, hsε_relint ω⟩
    have hsub_meas : Measurable sε_sub := hsε_meas.subtype_mk
    exact (continuousOn_iff_continuous_restrict.mp hgrad_cont).measurable.comp hsub_meas
  have htarget_meas : Measurable target := by
    have heq : target = fun ω =>
        ⟪UL.fitResidual P Y ω, (↑(∇ (shiftedFun F) (sε_rv ω)) : EuclideanSpace ℝ (Fin K))⟫ := by
      ext ω
      exact congr_arg (fun v => ⟪UL.fitResidual P Y ω, v⟫) (h_target_eq ω)
    rw [heq]
    exact Measurable.inner hr_meas
      ((UL.ZeroSumSubspace K).subtypeL.continuous.measurable.comp hgrad_rv_meas)
  have htarget_bdd : ∀ ω : Ω, ‖target ω‖ ≤ 2 * (oscBound / ρ) := by
    intro ω
    have hball_sub : Metric.closedBall (sε_rv ω) ρ ⊆ shiftedSimplex K :=
      (closedBall_trimmed_subset_shiftedRelint hK (hs_rv_mem ω) hε0 hε1).trans
        (shiftedRelint_subset K)
    have hgnorm : ‖∇ (shiftedFun F) (sε_rv ω)‖ ≤ oscBound / ρ :=
      norm_gradient_shiftedFun_le hK hF_conv hF_diff hOsc_nonneg hOsc (hsε_relint ω) hρ_pos hball_sub
    change ‖⟪UL.fitResidual P Y ω,
      UL.faceGrad F Finset.univ ((1 - ε) • P ω + ε • UL.uniformVec K)⟫‖ ≤ 2 * (oscBound / ρ)
    rw [h_target_eq ω]
    calc
      ‖⟪UL.fitResidual P Y ω, (↑(∇ (shiftedFun F) (sε_rv ω)) : EuclideanSpace ℝ (Fin K))⟫‖
        ≤ ‖UL.fitResidual P Y ω‖ *
            ‖(↑(∇ (shiftedFun F) (sε_rv ω)) : EuclideanSpace ℝ (Fin K))‖ :=
          norm_inner_le_norm _ _
      _ = ‖UL.fitResidual P Y ω‖ * ‖∇ (shiftedFun F) (sε_rv ω)‖ := by
          rw [Submodule.norm_coe]
      _ ≤ 2 * (oscBound / ρ) := mul_le_mul (norm_fitResidual_le_two Y hP ω) hgnorm
          (norm_nonneg _) (by norm_num)
  have htarget_int : Integrable target μ :=
    Integrable.of_bound htarget_meas.aestronglyMeasurable (2 * (oscBound / ρ))
      (Eventually.of_forall htarget_bdd)
  refine ⟨?_, htarget_int⟩
  -- Take sequence δ_m = δ₀ / (m + 1) with δ₀ small enough that proxPoint stays in closedBall(sε, ρ/2)
  let δ₀ : ℝ := (ρ / 2) ^ 2 / (4 * (oscBound + 1))
  have hδ₀_pos : 0 < δ₀ := by positivity
  let δ_seq : ℕ → ℝ := fun m => δ₀ / ((m : ℝ) + 1)
  have hδ_pos : ∀ m : ℕ, 0 < δ_seq m := fun m => div_pos hδ₀_pos (by positivity)
  have hδ_le : ∀ m : ℕ, δ_seq m ≤ δ₀ := fun m => by
    dsimp [δ_seq]
    exact div_le_self hδ₀_pos.le (by linarith [(Nat.cast_nonneg m : (0 : ℝ) ≤ m)])
  have hδ_tendsto : Tendsto δ_seq atTop (𝓝 0) :=
    tendsto_const_nhds.div_atTop (tendsto_natCast_atTop_atTop.atTop_add tendsto_const_nhds)
  let fn : ℕ → Ω → ℝ := fun m ω =>
    ⟪UL.fitResidual P Y ω,
      (↑(∇ (moreauEnv hK hF_cont (δ_seq m)) (sε_rv ω)) : EuclideanSpace ℝ (Fin K))⟫
  -- Key geometric property for every m and ω: proxPoint is within ρ/2 of sε_rv ω
  have h_prox_dist : ∀ (m : ℕ) (ω : Ω),
      ‖proxPoint hK hF_cont (δ_seq m) (sε_rv ω) - sε_rv ω‖ ^ 2 ≤
        2 * δ_seq m * oscBound := by
    intro m ω
    have hsε_mem : sε_rv ω ∈ shiftedSimplex K := shiftedRelint_subset K (hsε_relint ω)
    exact norm_proxPoint_sub_self_sq_le hK hF_cont hOsc (hδ_pos m) hsε_mem
  have h_prox_in_half_ball : ∀ (m : ℕ) (ω : Ω),
      proxPoint hK hF_cont (δ_seq m) (sε_rv ω) ∈ Metric.closedBall (sε_rv ω) (ρ / 2) := by
    intro m ω
    rw [Metric.mem_closedBall, dist_eq_norm]
    have hsq : ‖proxPoint hK hF_cont (δ_seq m) (sε_rv ω) - sε_rv ω‖ ^ 2 ≤ (ρ / 2) ^ 2 := by
      calc
        ‖proxPoint hK hF_cont (δ_seq m) (sε_rv ω) - sε_rv ω‖ ^ 2
          ≤ 2 * δ_seq m * oscBound := h_prox_dist m ω
        _ ≤ 2 * δ₀ * (oscBound + 1) := by
          have h1 : δ_seq m ≤ δ₀ := hδ_le m
          nlinarith [hδ_pos m]
        _ = (ρ / 2) ^ 2 / 2 := by
          dsimp [δ₀]
          have hne : oscBound + 1 ≠ 0 := by positivity
          field_simp [hne]
          ring
        _ ≤ (ρ / 2) ^ 2 := by nlinarith [sq_nonneg (ρ / 2)]
    exact (abs_le_of_sq_le_sq' hsq hρ2_pos.le).2
  have h_fn_meas : ∀ m : ℕ, AEStronglyMeasurable (fn m) μ := by
    intro m
    obtain ⟨Lm, hLm⟩ := lipschitz_gradient_moreauEnv hK hF_cont hF_conv (hδ_pos m)
    have hgm : Measurable (fun ω => ∇ (moreauEnv hK hF_cont (δ_seq m)) (sε_rv ω)) :=
      hLm.continuous.measurable.comp hsε_meas
    exact (Measurable.inner hr_meas
      ((UL.ZeroSumSubspace K).subtypeL.continuous.measurable.comp hgm)).aestronglyMeasurable
  have h_fn_bound : ∀ (m : ℕ) (ω : Ω), ‖fn m ω‖ ≤ 2 * (oscBound / (ρ / 2)) := by
    intro m ω
    set p := proxPoint hK hF_cont (δ_seq m) (sε_rv ω)
    have hp_half : p ∈ Metric.closedBall (sε_rv ω) (ρ / 2) := h_prox_in_half_ball m ω
    have hp_relint : p ∈ shiftedRelint K :=
      closedBall_trimmed_subset_shiftedRelint hK (hs_rv_mem ω) hε0 hε1
        (Metric.closedBall_subset_closedBall (by linarith [hρ_def]) hp_half)
    have hp_ball_sub : Metric.closedBall p (ρ / 2) ⊆ shiftedSimplex K := by
      intro z hz
      apply shiftedRelint_subset K
      apply closedBall_trimmed_subset_shiftedRelint hK (hs_rv_mem ω) hε0 hε1
      rw [Metric.mem_closedBall] at hz hp_half ⊢
      calc
        dist z (sε_rv ω) ≤ dist z p + dist p (sε_rv ω) := dist_triangle z p (sε_rv ω)
        _ ≤ ρ / 2 + ρ / 2 := add_le_add hz hp_half
        _ = ρ := by ring
    have hgrad_eq := gradient_moreauEnv_eq_gradient_shiftedFun_of_mem_relint
      hK hF_cont hF_conv hF_diff (hδ_pos m) hp_relint
    have hgnorm : ‖∇ (shiftedFun F) p‖ ≤ oscBound / (ρ / 2) :=
      norm_gradient_shiftedFun_le hK hF_conv hF_diff hOsc_nonneg hOsc hp_relint hρ2_pos hp_ball_sub
    change ‖⟪UL.fitResidual P Y ω,
      (↑(∇ (moreauEnv hK hF_cont (δ_seq m)) (sε_rv ω)) : EuclideanSpace ℝ (Fin K))⟫‖ ≤
      2 * (oscBound / (ρ / 2))
    rw [hgrad_eq]
    calc
      ‖⟪UL.fitResidual P Y ω, (↑(∇ (shiftedFun F) p) : EuclideanSpace ℝ (Fin K))⟫‖
        ≤ ‖UL.fitResidual P Y ω‖ * ‖(↑(∇ (shiftedFun F) p) : EuclideanSpace ℝ (Fin K))‖ :=
          norm_inner_le_norm _ _
      _ = ‖UL.fitResidual P Y ω‖ * ‖∇ (shiftedFun F) p‖ := by rw [Submodule.norm_coe]
      _ ≤ 2 * (oscBound / (ρ / 2)) := mul_le_mul (norm_fitResidual_le_two Y hP ω) hgnorm
          (norm_nonneg _) (by norm_num)
  have h_fn_tendsto : ∀ ω : Ω, Tendsto (fun m => fn m ω) atTop (𝓝 (target ω)) := by
    intro ω
    have hp_tendsto : Tendsto (fun m => proxPoint hK hF_cont (δ_seq m) (sε_rv ω))
        atTop (𝓝 (sε_rv ω)) := by
      rw [tendsto_iff_norm_sub_tendsto_zero]
      have hub : Tendsto (fun m => Real.sqrt (2 * δ_seq m * oscBound)) atTop (𝓝 0) := by
        have h1 : Tendsto (fun m => 2 * δ_seq m * oscBound) atTop (𝓝 (2 * 0 * oscBound)) :=
          (hδ_tendsto.const_mul 2).mul_const oscBound
        simpa using Real.continuous_sqrt.tendsto 0 |>.comp (by simpa using h1)
      refine squeeze_zero (fun _ => norm_nonneg _) (fun m => ?_) hub
      exact Real.le_sqrt_of_sq_le (h_prox_dist m ω)
    have hgrad_at : ContinuousAt (∇ (shiftedFun F)) (sε_rv ω) :=
      hgrad_cont.continuousAt ((isOpen_shiftedRelint hK).mem_nhds (hsε_relint ω))
    have hgrad_m_eq : ∀ m : ℕ, ∇ (moreauEnv hK hF_cont (δ_seq m)) (sε_rv ω) =
        ∇ (shiftedFun F) (proxPoint hK hF_cont (δ_seq m) (sε_rv ω)) := by
      intro m
      have hp_relint : proxPoint hK hF_cont (δ_seq m) (sε_rv ω) ∈ shiftedRelint K :=
        closedBall_trimmed_subset_shiftedRelint hK (hs_rv_mem ω) hε0 hε1
          (Metric.closedBall_subset_closedBall (by linarith [hρ_def]) (h_prox_in_half_ball m ω))
      exact gradient_moreauEnv_eq_gradient_shiftedFun_of_mem_relint
        hK hF_cont hF_conv hF_diff (hδ_pos m) hp_relint
    have h_inner_tendsto : Tendsto (fun m => fn m ω) atTop
        (𝓝 ⟪UL.fitResidual P Y ω, (↑(∇ (shiftedFun F) (sε_rv ω)) : EuclideanSpace ℝ (Fin K))⟫) := by
      have hg_tendsto : Tendsto (fun m => ∇ (moreauEnv hK hF_cont (δ_seq m)) (sε_rv ω))
          atTop (𝓝 (∇ (shiftedFun F) (sε_rv ω))) := by
        simp_rw [hgrad_m_eq]
        exact hgrad_at.tendsto.comp hp_tendsto
      exact Filter.Tendsto.inner tendsto_const_nhds
        ((UL.ZeroSumSubspace K).subtypeL.continuous.tendsto _ |>.comp hg_tendsto)
    have h_t_eq : target ω =
        ⟪UL.fitResidual P Y ω, (↑(∇ (shiftedFun F) (sε_rv ω)) : EuclideanSpace ℝ (Fin K))⟫ :=
      congr_arg (fun v => ⟪UL.fitResidual P Y ω, v⟫) (h_target_eq ω)
    rwa [h_t_eq]
  have h_int_tendsto : Tendsto (fun m => ∫ ω, fn m ω ∂μ) atTop (𝓝 (∫ ω, target ω ∂μ)) :=
    tendsto_integral_of_dominated_convergence (fun _ => 2 * (oscBound / (ρ / 2)))
      h_fn_meas (integrable_const _)
      (fun m => Eventually.of_forall (h_fn_bound m))
      (Eventually.of_forall h_fn_tendsto)
  have h_fn_int_le : ∀ m : ℕ, ∫ ω, fn m ω ∂μ ≤ 0 := fun m =>
    smooth_test_at_moreau μ hK hsmooth hF_cont hF_conv hε1 (hδ_pos m)
  exact le_of_tendsto h_int_tendsto (Eventually.of_forall h_fn_int_le)

end UL.Proof_lem_A_5

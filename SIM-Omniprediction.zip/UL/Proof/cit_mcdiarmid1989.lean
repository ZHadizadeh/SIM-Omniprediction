import UL.Stmt.cit_mcdiarmid1989
set_option autoImplicit false

namespace UL

namespace Proof_cit_mcdiarmid1989_Race3

open MeasureTheory ProbabilityTheory Real
open scoped NNReal ENNReal

lemma cons_zero_eq_update {n : ℕ} {α : Fin (n + 1) → Type*}
    (x x' : α 0) (y : ∀ i : Fin n, α (Fin.succ i)) :
    Fin.cons x' y = Function.update (Fin.cons x y) 0 x' := by
  ext j
  refine Fin.cases ?_ ?_ j
  · simp
  · intro i
    rw [Fin.cons_succ, Function.update_of_ne (Fin.succ_ne_zero i), Fin.cons_succ]

lemma cons_update_succ {n : ℕ} {α : Fin (n + 1) → Type*}
    (x : α 0) (y : ∀ i : Fin n, α (Fin.succ i)) (i : Fin n) (y' : α (Fin.succ i)) :
    Fin.cons x (Function.update y i y') =
      Function.update (Fin.cons x y) (Fin.succ i) y' := by
  ext j
  refine Fin.cases ?_ ?_ j
  · rw [Fin.cons_zero, Function.update_of_ne (Fin.succ_ne_zero i).symm, Fin.cons_zero]
  · intro k
    by_cases hk : k = i
    · subst hk; simp
    · have hsk : Fin.succ k ≠ Fin.succ i := (Fin.succ_injective _).ne hk
      rw [Fin.cons_succ, Function.update_of_ne hk, Function.update_of_ne hsk, Fin.cons_succ]

lemma piFinSuccAbove_symm_zero_apply {n : ℕ} {α : Fin (n + 1) → Type*}
    [∀ i, MeasurableSpace (α i)]
    (p : α 0 × (∀ i : Fin n, α (Fin.succ i))) :
    (MeasurableEquiv.piFinSuccAbove α 0).symm p = Fin.cons p.1 p.2 := by
  rw [MeasurableEquiv.piFinSuccAbove_symm_apply]
  simp [Fin.insertNthEquiv, Equiv.coe_fn_mk, Fin.insertNth_zero]

lemma abs_sub_le_sum_of_bounded_diff {n : ℕ} {α : Fin n → Type*}
    {g : (∀ i : Fin n, α i) → ℝ} {c : Fin n → ℝ}
    (hg_diff : ∀ (i : Fin n) (z : ∀ j : Fin n, α j) (z' : α i),
      |g z - g (Function.update z i z')| ≤ c i)
    (z w : ∀ i : Fin n, α i) :
    |g z - g w| ≤ ∑ i : Fin n, c i := by
  induction n with
  | zero =>
    have hzw : z = w := Subsingleton.elim z w
    simp [hzw]
  | succ n ih =>
    let z' : ∀ j : Fin (n + 1), α j := Function.update z 0 (w 0)
    have h1 : |g z - g z'| ≤ c 0 := hg_diff 0 z (w 0)
    let g' : (∀ i : Fin n, α (Fin.succ i)) → ℝ := fun y ↦ g (Fin.cons (w 0) y)
    have hg'_diff : ∀ (i : Fin n) (y : ∀ j : Fin n, α (Fin.succ j)) (y' : α (Fin.succ i)),
        |g' y - g' (Function.update y i y')| ≤ c (Fin.succ i) := by
      intro i y y'
      dsimp only [g']
      rw [cons_update_succ]
      exact hg_diff (Fin.succ i) (Fin.cons (w 0) y) y'
    have hz'_eq : Fin.cons (w 0) (Fin.tail z') = z' := by
      have h0 : z' 0 = w 0 := by simp [z']
      rw [← h0, Fin.cons_self_tail]
    have hw_eq : Fin.cons (w 0) (Fin.tail w) = w := Fin.cons_self_tail w
    have h2 : |g z' - g w| ≤ ∑ i : Fin n, c (Fin.succ i) := by
      rw [← hz'_eq, ← hw_eq]
      exact ih hg'_diff (Fin.tail z') (Fin.tail w)
    rw [Fin.sum_univ_succ]
    exact (abs_sub_le (g z) (g z') (g w)).trans (add_le_add h1 h2)

lemma eq_of_sum_sq_eq_zero {n : ℕ} {α : Fin n → Type*}
    {g : (∀ i : Fin n, α i) → ℝ} {c : Fin n → ℝ}
    (hg_diff : ∀ (i : Fin n) (z : ∀ j : Fin n, α j) (z' : α i),
      |g z - g (Function.update z i z')| ≤ c i)
    (hS0 : (∑ i : Fin n, c i ^ 2) = 0)
    (z w : ∀ i : Fin n, α i) :
    g z = g w := by
  have hc0 : ∀ i : Fin n, c i = 0 := by
    have hsq0 : ∀ i ∈ (Finset.univ : Finset (Fin n)), c i ^ 2 = 0 :=
      (Finset.sum_eq_zero_iff_of_nonneg (fun i _ ↦ sq_nonneg (c i))).mp hS0
    intro i
    exact sq_eq_zero_iff.mp (hsq0 i (Finset.mem_univ i))
  have hdiff := abs_sub_le_sum_of_bounded_diff hg_diff z w
  simp only [hc0, Finset.sum_const_zero, abs_nonpos_iff, sub_eq_zero] at hdiff
  exact hdiff

lemma integrable_of_bounded_diff {n : ℕ} {α : Fin n → Type*} [∀ i, MeasurableSpace (α i)]
    {P : Measure (∀ i : Fin n, α i)} [IsProbabilityMeasure P]
    {g : (∀ i : Fin n, α i) → ℝ} {c : Fin n → ℝ}
    (hg_meas : Measurable g)
    (hg_diff : ∀ (i : Fin n) (z : ∀ j : Fin n, α j) (z' : α i),
      |g z - g (Function.update z i z')| ≤ c i) :
    Integrable g P := by
  obtain ⟨z₀⟩ := nonempty_of_isProbabilityMeasure P
  refine Integrable.of_bound hg_meas.aestronglyMeasurable (|g z₀| + ∑ i : Fin n, c i)
    (ae_of_all _ fun z ↦ ?_)
  rw [Real.norm_eq_abs]
  have hdiff := abs_sub_le_sum_of_bounded_diff hg_diff z z₀
  have htri : |g z| ≤ |g z₀| + |g z - g z₀| := by
    calc |g z|
      _ = |g z₀ + (g z - g z₀)| := by ring_nf
      _ ≤ |g z₀| + |g z - g z₀| := abs_add_le _ _
  linarith

lemma integrable_exp_of_bounded_diff {n : ℕ} {α : Fin n → Type*} [∀ i, MeasurableSpace (α i)]
    {P : Measure (∀ i : Fin n, α i)} [IsProbabilityMeasure P]
    {g : (∀ i : Fin n, α i) → ℝ} {c : Fin n → ℝ}
    (hg_meas : Measurable g)
    (hg_diff : ∀ (i : Fin n) (z : ∀ j : Fin n, α j) (z' : α i),
      |g z - g (Function.update z i z')| ≤ c i)
    (m t : ℝ) :
    Integrable (fun z ↦ Real.exp (t * (g z - m))) P := by
  obtain ⟨z₀⟩ := nonempty_of_isProbabilityMeasure P
  let B : ℝ := |g z₀| + (∑ i : Fin n, |c i|) + |m|
  refine Integrable.of_bound (by fun_prop) (Real.exp (|t| * B)) (ae_of_all _ fun z ↦ ?_)
  rw [Real.norm_eq_abs, abs_of_pos (Real.exp_pos _), Real.exp_le_exp]
  have hsum_le : ∑ i : Fin n, c i ≤ ∑ i : Fin n, |c i| :=
    Finset.sum_le_sum fun i _ ↦ le_abs_self (c i)
  have hdiff := abs_sub_le_sum_of_bounded_diff hg_diff z z₀
  have htri1 : |g z - m| ≤ |g z₀ + (g z - g z₀)| + |m| := by
    have heq : g z - m = g z₀ + (g z - g z₀) - m := by ring
    rw [heq]
    exact abs_sub _ _
  have htri2 : |g z₀ + (g z - g z₀)| ≤ |g z₀| + |g z - g z₀| := abs_add_le _ _
  have hgz : |g z - m| ≤ B := by
    dsimp [B]
    linarith
  calc t * (g z - m)
    _ ≤ |t * (g z - m)| := le_abs_self _
    _ = |t| * |g z - m| := abs_mul _ _
    _ ≤ |t| * B := mul_le_mul_of_nonneg_left hgz (abs_nonneg t)

lemma mgf_slice_le {α₀ : Type*} [MeasurableSpace α₀]
    (ν₀ : Measure α₀) [IsProbabilityMeasure ν₀]
    {f : α₀ → ℝ} {c₀ : ℝ}
    (hf_meas : Measurable f)
    (hf_diff : ∀ x x' : α₀, |f x - f x'| ≤ c₀)
    (t : ℝ) :
    ∫ x, Real.exp (t * (f x - ∫ x', f x' ∂ν₀)) ∂ν₀ ≤
      Real.exp (((‖c₀‖₊ / 2) ^ 2 : ℝ≥0) * t ^ 2 / 2) := by
  haveI : Nonempty α₀ := nonempty_of_isProbabilityMeasure ν₀
  obtain ⟨x₀⟩ := ‹Nonempty α₀›
  have hbdd : BddBelow (Set.range f) := by
    refine ⟨f x₀ - c₀, ?_⟩
    rintro _ ⟨x, rfl⟩
    have h := hf_diff x₀ x
    linarith [le_abs_self (f x₀ - f x)]
  let A : ℝ := ⨅ x : α₀, f x
  have hA_le : ∀ x : α₀, A ≤ f x := fun x ↦ ciInf_le hbdd x
  have hf_le_A : ∀ x : α₀, f x ≤ A + c₀ := by
    intro x
    suffices f x - c₀ ≤ A by linarith
    refine le_ciInf fun x' ↦ ?_
    have h := hf_diff x x'
    linarith [le_abs_self (f x - f x')]
  have hf_int : Integrable f ν₀ := by
    refine Integrable.of_bound hf_meas.aestronglyMeasurable (|f x₀| + c₀) (ae_of_all _ fun x ↦ ?_)
    rw [Real.norm_eq_abs]
    have h := hf_diff x x₀
    have htri : |f x| ≤ |f x₀| + |f x - f x₀| := by
      calc |f x|
        _ = |f x₀ + (f x - f x₀)| := by ring_nf
        _ ≤ |f x₀| + |f x - f x₀| := abs_add_le _ _
    linarith
  let m₀ : ℝ := ∫ x', f x' ∂ν₀
  have h_mean : ∫ x, (f x - m₀) ∂ν₀ = 0 := by
    rw [integral_sub hf_int (integrable_const m₀), integral_const, probReal_univ, smul_eq_mul,
      one_mul, sub_self]
  have h_icc : ∀ᵐ x ∂ν₀, f x - m₀ ∈ Set.Icc (A - m₀) (A + c₀ - m₀) :=
    ae_of_all _ fun x ↦ ⟨sub_le_sub_right (hA_le x) m₀, sub_le_sub_right (hf_le_A x) m₀⟩
  have h_subG := ProbabilityTheory.hasSubgaussianMGF_of_mem_Icc_of_integral_eq_zero
    (hf_meas.sub measurable_const).aemeasurable h_icc h_mean
  have hsub : (A + c₀ - m₀) - (A - m₀) = c₀ := by ring
  rw [hsub] at h_subG
  exact h_subG.mgf_le t

lemma hasSubgaussianMGF_pi_of_bounded_diff
    {n : ℕ} {α : Fin n → Type*} [∀ i, MeasurableSpace (α i)]
    (ν : ∀ i : Fin n, Measure (α i)) [∀ i, IsProbabilityMeasure (ν i)]
    (g : (∀ i : Fin n, α i) → ℝ) (c : Fin n → ℝ)
    (hg_meas : Measurable g)
    (hg_diff : ∀ (i : Fin n) (z : ∀ j : Fin n, α j) (z' : α i),
      |g z - g (Function.update z i z')| ≤ c i) :
    ProbabilityTheory.HasSubgaussianMGF
      (fun z ↦ g z - ∫ z', g z' ∂(Measure.pi ν))
      (∑ i : Fin n, (‖c i‖₊ / 2) ^ 2)
      (Measure.pi ν) := by
  induction n with
  | zero =>
    have hzero : (fun z : ∀ i : Fin 0, α i ↦ g z - ∫ z', g z' ∂(Measure.pi ν)) = fun _ ↦ 0 := by
      ext z
      have hconst : (fun z' : ∀ i : Fin 0, α i ↦ g z') = fun _ ↦ g z := by
        ext z'
        exact congrArg g (Subsingleton.elim z' z)
      rw [hconst, integral_const, probReal_univ, smul_eq_mul, one_mul, sub_self]
    rw [hzero]
    simpa using ProbabilityTheory.HasSubgaussianMGF.fun_zero (μ := Measure.pi ν)
  | succ n ih =>
    let ν' : ∀ i : Fin n, Measure (α (Fin.succ i)) := fun i ↦ ν (Fin.succ i)
    let P := Measure.pi ν
    let P' := Measure.pi ν'
    let e := (MeasurableEquiv.piFinSuccAbove α 0).symm
    have he : MeasurePreserving e ((ν 0).prod P') P :=
      (measurePreserving_piFinSuccAbove ν 0).symm
    have hge_meas : Measurable (fun p : α 0 × (∀ i : Fin n, α (Fin.succ i)) ↦ g (e p)) :=
      hg_meas.comp e.measurable
    let h : (∀ i : Fin n, α (Fin.succ i)) → ℝ := fun y ↦ ∫ x : α 0, g (e (x, y)) ∂(ν 0)
    have hh_meas : Measurable h :=
      hge_meas.stronglyMeasurable.integral_prod_left'.measurable
    have hslice_meas : ∀ y : ∀ i : Fin n, α (Fin.succ i),
        Measurable (fun x : α 0 ↦ g (Fin.cons x y)) := by
      intro y
      have h_eq : (fun x : α 0 ↦ g (Fin.cons x y)) = fun x : α 0 ↦ g (e (x, y)) := by
        ext x; rw [piFinSuccAbove_symm_zero_apply]
      rw [h_eq]
      exact hge_meas.comp (measurable_id.prodMk measurable_const)
    have hslice_diff : ∀ (y : ∀ i : Fin n, α (Fin.succ i)) (x x' : α 0),
        |g (Fin.cons x y) - g (Fin.cons x' y)| ≤ c 0 := by
      intro y x x'
      rw [cons_zero_eq_update x x' y]
      exact hg_diff 0 (Fin.cons x y) x'
    have hslice_int : ∀ y : ∀ i : Fin n, α (Fin.succ i),
        Integrable (fun x : α 0 ↦ g (Fin.cons x y)) (ν 0) := by
      intro y
      obtain ⟨x₀⟩ := nonempty_of_isProbabilityMeasure (ν 0)
      refine Integrable.of_bound (hslice_meas y).aestronglyMeasurable
        (|g (Fin.cons x₀ y)| + c 0) (ae_of_all _ fun x ↦ ?_)
      rw [Real.norm_eq_abs]
      have hd := hslice_diff y x x₀
      have htri : |g (Fin.cons x y)| ≤ |g (Fin.cons x₀ y)| + |g (Fin.cons x y) - g (Fin.cons x₀ y)| := by
        calc |g (Fin.cons x y)|
          _ = |g (Fin.cons x₀ y) + (g (Fin.cons x y) - g (Fin.cons x₀ y))| := by ring_nf
          _ ≤ |g (Fin.cons x₀ y)| + |g (Fin.cons x y) - g (Fin.cons x₀ y)| := abs_add_le _ _
      linarith
    have hh_apply : ∀ y : ∀ i : Fin n, α (Fin.succ i),
        h y = ∫ x : α 0, g (Fin.cons x y) ∂(ν 0) := by
      intro y
      dsimp only [h]
      congr 1 with x
      rw [piFinSuccAbove_symm_zero_apply]
    have hh_diff : ∀ (i : Fin n) (y : ∀ j : Fin n, α (Fin.succ j)) (y' : α (Fin.succ i)),
        |h y - h (Function.update y i y')| ≤ c (Fin.succ i) := by
      intro i y y'
      rw [hh_apply y, hh_apply (Function.update y i y'),
        ← integral_sub (hslice_int y) (hslice_int (Function.update y i y'))]
      calc |∫ x : α 0, (g (Fin.cons x y) - g (Fin.cons x (Function.update y i y'))) ∂(ν 0)|
        _ ≤ ∫ x : α 0, |g (Fin.cons x y) - g (Fin.cons x (Function.update y i y'))| ∂(ν 0) := by
            simpa [Real.norm_eq_abs] using
              norm_integral_le_integral_norm
                (fun x : α 0 ↦ g (Fin.cons x y) - g (Fin.cons x (Function.update y i y')))
        _ ≤ ∫ _ : α 0, c (Fin.succ i) ∂(ν 0) := by
            refine integral_mono ((hslice_int y).sub (hslice_int _)).abs (integrable_const _)
              fun x ↦ ?_
            rw [cons_update_succ]
            exact hg_diff (Fin.succ i) (Fin.cons x y) y'
        _ = c (Fin.succ i) := by
            rw [integral_const, probReal_univ, smul_eq_mul, one_mul]
    have hg_int_P : Integrable g P := integrable_of_bounded_diff hg_meas hg_diff
    have hge_int_prod : Integrable (fun p ↦ g (e p)) ((ν 0).prod P') :=
      (he.integrable_comp_emb e.measurableEmbedding).mpr hg_int_P
    have hm_eq : ∫ y, h y ∂P' = ∫ z, g z ∂P := by
      rw [← he.integral_comp']
      exact (integral_prod_symm (fun p ↦ g (e p)) hge_int_prod).symm
    have h_ih := ih ν' h (fun i ↦ c (Fin.succ i)) hh_meas hh_diff
    let m : ℝ := ∫ z', g z' ∂P
    refine ⟨fun t ↦ integrable_exp_of_bounded_diff hg_meas hg_diff m t, fun t ↦ ?_⟩
    have hexp_int_P : Integrable (fun z ↦ Real.exp (t * (g z - m))) P :=
      integrable_exp_of_bounded_diff hg_meas hg_diff m t
    have hexp_int_prod : Integrable (fun p ↦ Real.exp (t * (g (e p) - m))) ((ν 0).prod P') :=
      (he.integrable_comp_emb e.measurableEmbedding).mpr hexp_int_P
    have houter_int : Integrable
        (fun y ↦ ∫ x : α 0, Real.exp (t * (g (e (x, y)) - m)) ∂(ν 0)) P' :=
      hexp_int_prod.swap.integral_prod_left
    let c₀_nn : ℝ≥0 := (‖c 0‖₊ / 2) ^ 2
    let c'_nn : ℝ≥0 := ∑ i : Fin n, (‖c (Fin.succ i)‖₊ / 2) ^ 2
    have hm_eq_pi : (∫ z', h z' ∂Measure.pi ν') = m := hm_eq
    have h_ih_int : Integrable (fun y ↦ Real.exp (t * (h y - m))) P' := by
      have h1 := h_ih.integrable_exp_mul t
      rwa [hm_eq_pi] at h1
    have h_ih_mgf : (∫ y, Real.exp (t * (h y - m)) ∂P') ≤ Real.exp (c'_nn * t ^ 2 / 2) := by
      have h1 := h_ih.mgf_le t
      rwa [mgf, hm_eq_pi] at h1
    calc mgf (fun z ↦ g z - m) P t
      _ = ∫ z, Real.exp (t * (g z - m)) ∂P := rfl
      _ = ∫ p, Real.exp (t * (g (e p) - m)) ∂((ν 0).prod P') :=
          (he.integral_comp' (fun z ↦ Real.exp (t * (g z - m)))).symm
      _ = ∫ y, ∫ x : α 0, Real.exp (t * (g (e (x, y)) - m)) ∂(ν 0) ∂P' :=
          integral_prod_symm _ hexp_int_prod
      _ ≤ ∫ y, Real.exp (t * (h y - m)) * Real.exp (c₀_nn * t ^ 2 / 2) ∂P' := by
          refine integral_mono houter_int (h_ih_int.mul_const _) fun y ↦ ?_
          have hfactor : (fun x : α 0 ↦ Real.exp (t * (g (e (x, y)) - m))) =
              fun x : α 0 ↦ Real.exp (t * (h y - m)) *
                Real.exp (t * (g (Fin.cons x y) - h y)) := by
            ext x
            rw [piFinSuccAbove_symm_zero_apply, ← Real.exp_add]
            congr 1
            ring
          rw [hfactor, integral_const_mul]
          refine mul_le_mul_of_nonneg_left ?_ (Real.exp_nonneg _)
          simpa [hh_apply y, c₀_nn] using
            mgf_slice_le (ν 0) (hslice_meas y) (hslice_diff y) t
      _ = (∫ y, Real.exp (t * (h y - m)) ∂P') * Real.exp (c₀_nn * t ^ 2 / 2) :=
          integral_mul_const _ _
      _ ≤ Real.exp (c'_nn * t ^ 2 / 2) * Real.exp (c₀_nn * t ^ 2 / 2) :=
          mul_le_mul_of_nonneg_right h_ih_mgf (Real.exp_nonneg _)
      _ = Real.exp ((∑ i : Fin (n + 1), (‖c i‖₊ / 2) ^ 2 : ℝ≥0) * t ^ 2 / 2) := by
          rw [← Real.exp_add, Fin.sum_univ_succ]
          congr 1
          dsimp only [c₀_nn, c'_nn]
          push_cast
          ring

end Proof_cit_mcdiarmid1989_Race3

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_cit_mcdiarmid1989 : S_cit_mcdiarmid1989 := by
  unfold S_cit_mcdiarmid1989
  intro Ω _ μ _ n α _ Z hZ_meas hZ_indep g c hg_meas hg_diff _hc_nonneg
  let Φ : Ω → (∀ i : Fin n, α i) := fun ω i ↦ Z i ω
  have hΦ_meas : Measurable Φ := measurable_pi_iff.2 hZ_meas
  let ν : ∀ i : Fin n, MeasureTheory.Measure (α i) := fun i ↦ μ.map (Z i)
  haveI hν_prob : ∀ i : Fin n, MeasureTheory.IsProbabilityMeasure (ν i) :=
    fun i ↦ MeasureTheory.Measure.isProbabilityMeasure_map (hZ_meas i).aemeasurable
  have hmap : μ.map Φ = MeasureTheory.Measure.pi ν :=
    (ProbabilityTheory.iIndepFun_iff_map_fun_eq_pi_map
      (fun i ↦ (hZ_meas i).aemeasurable)).mp hZ_indep
  let C_nn : NNReal := ∑ i : Fin n, (‖c i‖₊ / 2) ^ 2
  let X : Ω → ℝ := fun ω ↦ g (Φ ω) - ∫ ω', g (Φ ω') ∂μ
  have hX_meas : Measurable X := (hg_meas.comp hΦ_meas).sub measurable_const
  have hX_subG : ProbabilityTheory.HasSubgaussianMGF X C_nn μ := by
    have hpi := Proof_cit_mcdiarmid1989_Race3.hasSubgaussianMGF_pi_of_bounded_diff
      ν g c hg_meas hg_diff
    rw [← hmap] at hpi
    have hcomp := ProbabilityTheory.HasSubgaussianMGF.of_map hΦ_meas.aemeasurable hpi
    have hX_eq : X = (fun z ↦ g z - ∫ z', g z' ∂(μ.map Φ)) ∘ Φ := by
      ext ω
      simp only [X, Function.comp_apply]
      rw [MeasureTheory.integral_map hΦ_meas.aemeasurable hg_meas.aestronglyMeasurable]
    rw [hX_eq]
    exact hcomp
  let S : ℝ := ∑ i : Fin n, c i ^ 2
  have hS_nonneg : 0 ≤ S := Finset.sum_nonneg fun i _ ↦ sq_nonneg (c i)
  have hC_coe : (C_nn : ℝ) = S / 4 := by
    dsimp [C_nn, S]
    push_cast
    rw [Finset.sum_div]
    refine Finset.sum_congr rfl fun i _ ↦ ?_
    rw [Real.norm_eq_abs]
    have hsq : |c i| ^ 2 = c i ^ 2 := sq_abs (c i)
    linarith
  have htail_pos : S ≠ 0 → ∀ t : ℝ, 0 ≤ t →
      (μ {ω | t ≤ X ω}).toReal ≤ Real.exp (-2 * t ^ 2 / S) := by
    intro hS0 t ht
    have h1 := hX_subG.measure_ge_le ht
    rw [MeasureTheory.Measure.real] at h1
    refine h1.trans_eq ?_
    congr 1
    rw [hC_coe]
    field_simp [hS0]
    ring
  have htail_neg : S ≠ 0 → ∀ t : ℝ, 0 ≤ t →
      (μ {ω | t ≤ -X ω}).toReal ≤ Real.exp (-2 * t ^ 2 / S) := by
    intro hS0 t ht
    have h1 := hX_subG.neg.measure_ge_le ht
    rw [MeasureTheory.Measure.real] at h1
    refine h1.trans_eq ?_
    congr 1
    rw [hC_coe]
    field_simp [hS0]
    ring
  have hX_zero_of_S_zero : S = 0 → ∀ ω : Ω, X ω = 0 := by
    intro hS0 ω
    obtain ⟨ω₀⟩ := MeasureTheory.nonempty_of_isProbabilityMeasure μ
    have hconst : (fun ω' : Ω ↦ g (Φ ω')) = fun _ ↦ g (Φ ω₀) := by
      ext ω'
      exact Proof_cit_mcdiarmid1989_Race3.eq_of_sum_sq_eq_zero hg_diff hS0 (Φ ω') (Φ ω₀)
    dsimp [X]
    rw [congrFun hconst ω, hconst, MeasureTheory.integral_const, MeasureTheory.probReal_univ,
      smul_eq_mul, one_mul, sub_self]
  constructor
  · intro t ht
    change (μ {ω | t ≤ X ω}).toReal ≤
      if S = 0 then (if t = 0 then 1 else 0) else Real.exp (-2 * t ^ 2 / S)
    split_ifs with hS0 ht0
    · exact MeasureTheory.measureReal_le_one
    · have hX0 := hX_zero_of_S_zero hS0
      have ht_pos : 0 < t := lt_of_le_of_ne ht (Ne.symm ht0)
      have hempty : {ω : Ω | t ≤ X ω} = ∅ := by
        ext ω
        simp only [Set.mem_setOf_eq, hX0 ω, Set.mem_empty_iff_false, iff_false, not_le]
        exact ht_pos
      simp [hempty]
    · exact htail_pos hS0 t ht
  · intro δ hδ0 hδ1
    by_cases hS0 : S = 0
    · have hX0 := hX_zero_of_S_zero hS0
      constructor
      · have huniv : {ω : Ω | |X ω| ≤ Real.sqrt ((1 / 2 : ℝ) * S * Real.log (2 / δ))} =
            Set.univ := by
          ext ω
          simp [hX0 ω, hS0]
        rw [huniv]
        change 1 - δ ≤ μ.real Set.univ
        rw [MeasureTheory.probReal_univ]
        linarith
      · have huniv : {ω : Ω | X ω ≤ Real.sqrt ((1 / 2 : ℝ) * S * Real.log (1 / δ))} =
            Set.univ := by
          ext ω
          simp [hX0 ω, hS0]
        rw [huniv]
        change 1 - δ ≤ μ.real Set.univ
        rw [MeasureTheory.probReal_univ]
        linarith
    · have hS_pos : 0 < S := lt_of_le_of_ne hS_nonneg (Ne.symm hS0)
      constructor
      · let t₂ : ℝ := Real.sqrt ((1 / 2 : ℝ) * S * Real.log (2 / δ))
        let E₂ : Set Ω := {ω | |X ω| ≤ t₂}
        have hE₂_meas : MeasurableSet E₂ :=
          measurableSet_le hX_meas.abs measurable_const
        have hlog2_pos : 0 < Real.log (2 / δ) := by
          apply Real.log_pos
          rw [lt_div_iff₀ hδ0]
          linarith
        have harg2_nonneg : 0 ≤ (1 / 2 : ℝ) * S * Real.log (2 / δ) := by positivity
        have ht₂_sq : t₂ ^ 2 = (1 / 2 : ℝ) * S * Real.log (2 / δ) :=
          Real.sq_sqrt harg2_nonneg
        have hexp2 : Real.exp (-2 * t₂ ^ 2 / S) = δ / 2 := by
          have hrew : -2 * t₂ ^ 2 / S = Real.log (δ / 2) := by
            rw [ht₂_sq]
            have h1 : -2 * ((1 / 2 : ℝ) * S * Real.log (2 / δ)) / S = -Real.log (2 / δ) := by
              field_simp [hS0]
            rw [h1, ← Real.log_inv, inv_div]
          rw [hrew, Real.exp_log (by linarith)]
        have hcompl_sub : E₂ᶜ ⊆ {ω | t₂ ≤ X ω} ∪ {ω | t₂ ≤ -X ω} := by
          intro ω hω
          simp only [E₂, Set.mem_compl_iff, Set.mem_setOf_eq, not_le, lt_abs] at hω
          rcases hω with hω | hω
          · exact Or.inl (le_of_lt hω)
          · exact Or.inr (le_of_lt hω)
        have hcompl_le : μ.real E₂ᶜ ≤ δ := by
          calc μ.real E₂ᶜ
            _ ≤ μ.real ({ω | t₂ ≤ X ω} ∪ {ω | t₂ ≤ -X ω}) :=
                MeasureTheory.measureReal_mono hcompl_sub
            _ ≤ μ.real {ω | t₂ ≤ X ω} + μ.real {ω | t₂ ≤ -X ω} :=
                MeasureTheory.measureReal_union_le _ _
            _ ≤ Real.exp (-2 * t₂ ^ 2 / S) + Real.exp (-2 * t₂ ^ 2 / S) :=
                add_le_add (htail_pos hS0 t₂ (Real.sqrt_nonneg _))
                  (htail_neg hS0 t₂ (Real.sqrt_nonneg _))
            _ = δ / 2 + δ / 2 := by rw [hexp2]
            _ = δ := by ring
        have hprob := MeasureTheory.probReal_add_probReal_compl (μ := μ) hE₂_meas
        change 1 - δ ≤ μ.real E₂
        linarith
      · let t₁ : ℝ := Real.sqrt ((1 / 2 : ℝ) * S * Real.log (1 / δ))
        let E₁ : Set Ω := {ω | X ω ≤ t₁}
        have hE₁_meas : MeasurableSet E₁ :=
          measurableSet_le hX_meas measurable_const
        have hlog1_pos : 0 < Real.log (1 / δ) := by
          apply Real.log_pos
          rw [lt_div_iff₀ hδ0]
          linarith
        have harg1_nonneg : 0 ≤ (1 / 2 : ℝ) * S * Real.log (1 / δ) := by positivity
        have ht₁_sq : t₁ ^ 2 = (1 / 2 : ℝ) * S * Real.log (1 / δ) :=
          Real.sq_sqrt harg1_nonneg
        have hexp1 : Real.exp (-2 * t₁ ^ 2 / S) = δ := by
          have hrew : -2 * t₁ ^ 2 / S = Real.log δ := by
            rw [ht₁_sq]
            have h1 : -2 * ((1 / 2 : ℝ) * S * Real.log (1 / δ)) / S = -Real.log (1 / δ) := by
              field_simp [hS0]
            rw [h1, one_div, Real.log_inv, neg_neg]
          rw [hrew, Real.exp_log hδ0]
        have hcompl_sub : E₁ᶜ ⊆ {ω | t₁ ≤ X ω} := by
          intro ω hω
          simp only [E₁, Set.mem_compl_iff, Set.mem_setOf_eq, not_le] at hω
          exact le_of_lt hω
        have hcompl_le : μ.real E₁ᶜ ≤ δ := by
          calc μ.real E₁ᶜ
            _ ≤ μ.real {ω | t₁ ≤ X ω} := MeasureTheory.measureReal_mono hcompl_sub
            _ ≤ Real.exp (-2 * t₁ ^ 2 / S) := htail_pos hS0 t₁ (Real.sqrt_nonneg _)
            _ = δ := hexp1
        have hprob := MeasureTheory.probReal_add_probReal_compl (μ := μ) hE₁_meas
        change 1 - δ ≤ μ.real E₁
        linarith

end UL

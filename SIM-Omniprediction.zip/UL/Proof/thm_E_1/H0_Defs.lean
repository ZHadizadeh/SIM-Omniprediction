import Mathlib
import UL.Stmt.thm_E_1
set_option autoImplicit false

namespace UL.Proof_thm_E_1

noncomputable def shannonTemp (β : ℝ) : ℝ :=
  1 / (2 * β)

lemma shannonTemp_pos {β : ℝ} (hβ : 0 < β) : 0 < shannonTemp β := by
  unfold shannonTemp
  positivity

noncomputable def shannonEntropy (K : ℕ) (T : ℝ) (q : UL.Simplex K) : ℝ :=
  T * ∑ j : Fin K, q.1 j * Real.log (q.1 j)

noncomputable def softmaxMap (K : ℕ) (T : ℝ) (a : EuclideanSpace ℝ (Fin K)) :
    EuclideanSpace ℝ (Fin K) :=
  (WithLp.equiv 2 (Fin K → ℝ)).symm fun j =>
    Real.exp (a j / T) / ∑ k : Fin K, Real.exp (a k / T)

@[simp]
lemma softmaxMap_apply (K : ℕ) (T : ℝ) (a : EuclideanSpace ℝ (Fin K)) (j : Fin K) :
    softmaxMap K T a j = Real.exp (a j / T) / ∑ k : Fin K, Real.exp (a k / T) :=
  rfl

lemma sum_exp_div_pos {K : ℕ} (hK : 1 ≤ K) (T : ℝ) (a : EuclideanSpace ℝ (Fin K)) :
    0 < ∑ k : Fin K, Real.exp (a k / T) := by
  have hne : (Finset.univ : Finset (Fin K)).Nonempty := by
    haveI : Nonempty (Fin K) := ⟨⟨0, by omega⟩⟩
    exact Finset.univ_nonempty
  exact Finset.sum_pos (fun k _ => Real.exp_pos _) hne

lemma softmaxMap_pos {K : ℕ} (hK : 1 ≤ K) (T : ℝ) (a : EuclideanSpace ℝ (Fin K)) (j : Fin K) :
    0 < softmaxMap K T a j := by
  rw [softmaxMap_apply]
  exact div_pos (Real.exp_pos _) (sum_exp_div_pos hK T a)

lemma softmaxMap_mem_simplex {K : ℕ} (hK : 1 ≤ K) (T : ℝ) (a : EuclideanSpace ℝ (Fin K)) :
    softmaxMap K T a ∈ UL.Simplex K := by
  refine ⟨fun j => (softmaxMap_pos hK T a j).le, ?_⟩
  simp only [softmaxMap_apply, ← Finset.sum_div]
  exact div_self (sum_exp_div_pos hK T a).ne'

theorem finrank_zeroSumSubspace (K : ℕ) (hK : 2 ≤ K) :
    Module.finrank ℝ (UL.ZeroSumSubspace K) = K - 1 := by
  unfold UL.ZeroSumSubspace
  set f : EuclideanSpace ℝ (Fin K) →ₗ[ℝ] ℝ := (innerSL ℝ (UL.onesVec K)).toLinearMap
  have hf_surj : Function.Surjective f := by
    intro c
    refine ⟨EuclideanSpace.single ⟨0, by omega⟩ c, ?_⟩
    simp [f, UL.onesVec, EuclideanSpace.inner_single_right]
  have h_rk := LinearMap.finrank_range_add_finrank_ker f
  rw [LinearMap.range_eq_top.mpr hf_surj, finrank_top, Module.finrank_self,
    finrank_euclideanSpace_fin] at h_rk
  omega

noncomputable def zeroSumBasis (K : ℕ) (hK : 2 ≤ K) :
    OrthonormalBasis (Fin (K - 1)) ℝ (UL.ZeroSumSubspace K) :=
  (stdOrthonormalBasis ℝ (UL.ZeroSumSubspace K)).reindex
    (finCongr (finrank_zeroSumSubspace K hK))

noncomputable def zeroSumIso (K : ℕ) (hK : 2 ≤ K) :
    EuclideanSpace ℝ (Fin (K - 1)) ≃ₗᵢ[ℝ] UL.ZeroSumSubspace K :=
  (zeroSumBasis K hK).repr.symm

noncomputable def scoreScale (K : ℕ) (R : ℝ) : ℝ :=
  R / Real.sqrt ((K - 1 : ℕ) : ℝ)

lemma scoreScale_pos {K : ℕ} (hK : 2 ≤ K) {R : ℝ} (hR : 0 < R) :
    0 < scoreScale K R := by
  unfold scoreScale
  have hm : (0 : ℝ) < ((K - 1 : ℕ) : ℝ) := by exact_mod_cast (by omega : 0 < K - 1)
  positivity

noncomputable def shannonAlpha (K : ℕ) (R β : ℝ) : ℝ :=
  scoreScale K R / shannonTemp β

lemma shannonAlpha_pos {K : ℕ} (hK : 2 ≤ K) {R β : ℝ} (hR : 0 < R) (hβ : 0 < β) :
    0 < shannonAlpha K R β :=
  div_pos (scoreScale_pos hK hR) (shannonTemp_pos hβ)

noncomputable def scoreOpV0 (K : ℕ) (hK : 2 ≤ K) (R : ℝ) :
    EuclideanSpace ℝ (Fin (K - 1)) →L[ℝ] UL.ZeroSumSubspace K :=
  scoreScale K R • (zeroSumIso K hK).toLinearIsometry.toContinuousLinearMap

noncomputable def scoreOpW (K : ℕ) (R : ℝ) :
    EuclideanSpace ℝ (Fin (K - 1)) →L[ℝ] EuclideanSpace ℝ (Fin (K - 1)) :=
  scoreScale K R • ContinuousLinearMap.id ℝ (EuclideanSpace ℝ (Fin (K - 1)))

noncomputable def shannonRho (K : ℕ) (hK : 2 ≤ K) (β : ℝ)
    (s : EuclideanSpace ℝ (Fin (K - 1))) : EuclideanSpace ℝ (Fin K) :=
  softmaxMap K (shannonTemp β) ((zeroSumIso K hK s : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))

noncomputable def shannonEta (K : ℕ) (hK : 2 ≤ K) (R β : ℝ)
    (x : EuclideanSpace ℝ (Fin (K - 1))) : EuclideanSpace ℝ (Fin K) :=
  softmaxMap K (shannonTemp β) ((scoreOpV0 K hK R x : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))

lemma shannonEta_mem_simplex {K : ℕ} (hK : 2 ≤ K) (R β : ℝ)
    (x : EuclideanSpace ℝ (Fin (K - 1))) :
    shannonEta K hK R β x ∈ UL.Simplex K :=
  softmaxMap_mem_simplex (by omega) (shannonTemp β) _

lemma shannonEta_pos {K : ℕ} (hK : 2 ≤ K) (R β : ℝ)
    (x : EuclideanSpace ℝ (Fin (K - 1))) (y : Fin K) :
    0 < shannonEta K hK R β x y :=
  softmaxMap_pos (by omega) (shannonTemp β) _ y

lemma shannonEta_eq_rho_comp_W {K : ℕ} (hK : 2 ≤ K) (R β : ℝ)
    (x : EuclideanSpace ℝ (Fin (K - 1))) :
    shannonEta K hK R β x = shannonRho K hK β (scoreOpW K R x) := by
  unfold shannonEta shannonRho scoreOpV0 scoreOpW
  simp [map_smul]

noncomputable def ballUniformMeasure (m : ℕ) (L : ℝ) :
    MeasureTheory.Measure (EuclideanSpace ℝ (Fin m)) :=
  ProbabilityTheory.cond MeasureTheory.volume (Metric.ball (0 : EuclideanSpace ℝ (Fin m)) L)

noncomputable def jointMeasureP (m K : ℕ) (L : ℝ)
    (η : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin K)) :
    MeasureTheory.Measure (EuclideanSpace ℝ (Fin m) × Fin K) :=
  ∑ y : Fin K,
    ((ballUniformMeasure m L).withDensity (fun x => ENNReal.ofReal (η x y))).map (fun x => (x, y))

end UL.Proof_thm_E_1

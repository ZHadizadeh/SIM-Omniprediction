import Mathlib
import UL.Proof.thm_E_1.H0_Defs
import UL.Proof.lem_A_5.H1_Simplex
set_option autoImplicit false

namespace UL.Proof_thm_E_1

theorem frobNorm_scoreOpV0 (K : ℕ) (hK : 2 ≤ K) {R : ℝ} (hR : 0 < R) :
    Real.sqrt (∑ i : Fin (K - 1), ‖scoreOpV0 K hK R (EuclideanSpace.single i (1 : ℝ))‖ ^ 2) = R := by
  have hterm : ∀ i : Fin (K - 1),
      ‖scoreOpV0 K hK R (EuclideanSpace.single i (1 : ℝ))‖ = scoreScale K R := by
    intro i
    unfold scoreOpV0
    rw [ContinuousLinearMap.smul_apply, norm_smul, Real.norm_eq_abs,
      abs_of_pos (scoreScale_pos hK hR)]
    change scoreScale K R * ‖zeroSumIso K hK (EuclideanSpace.single i (1 : ℝ))‖ = scoreScale K R
    rw [(zeroSumIso K hK).norm_map, EuclideanSpace.norm_single, norm_one, mul_one]
  simp_rw [hterm]
  have hm : (0 : ℝ) < ((K - 1 : ℕ) : ℝ) := by exact_mod_cast (by omega : 0 < K - 1)
  have hsum : ∑ _i : Fin (K - 1), scoreScale K R ^ 2 = R ^ 2 := by
    unfold scoreScale
    rw [Finset.sum_const, Finset.card_fin, nsmul_eq_mul, div_pow, Real.sq_sqrt hm.le,
      mul_div_cancel₀ _ hm.ne']
  rw [hsum, Real.sqrt_sq hR.le]

theorem frobNorm_scoreOpW_le (K : ℕ) (hK : 2 ≤ K) {R : ℝ} (hR : 0 < R) :
    Real.sqrt (∑ i : Fin (K - 1), ‖scoreOpW K R (EuclideanSpace.single i (1 : ℝ))‖ ^ 2) ≤ R := by
  have hterm : ∀ i : Fin (K - 1),
      ‖scoreOpW K R (EuclideanSpace.single i (1 : ℝ))‖ = scoreScale K R := by
    intro i
    unfold scoreOpW
    rw [ContinuousLinearMap.smul_apply, ContinuousLinearMap.id_apply, norm_smul,
      Real.norm_eq_abs, abs_of_pos (scoreScale_pos hK hR), EuclideanSpace.norm_single,
      norm_one, mul_one]
  simp_rw [hterm]
  have hm : (0 : ℝ) < ((K - 1 : ℕ) : ℝ) := by exact_mod_cast (by omega : 0 < K - 1)
  have hsum : ∑ _i : Fin (K - 1), scoreScale K R ^ 2 = R ^ 2 := by
    unfold scoreScale
    rw [Finset.sum_const, Finset.card_fin, nsmul_eq_mul, div_pow, Real.sq_sqrt hm.le,
      mul_div_cancel₀ _ hm.ne']
  rw [hsum, Real.sqrt_sq hR.le]

theorem lipschitzWith_shannonRho (K : ℕ) (hK : 2 ≤ K) {β : ℝ}
    (hSoftLip : LipschitzWith (Real.toNNReal β) (softmaxMap K (shannonTemp β))) :
    LipschitzWith (Real.toNNReal β) (shannonRho K hK β) := by
  rw [lipschitzWith_iff_dist_le_mul]
  intro s₁ s₂
  unfold shannonRho
  refine (hSoftLip.dist_le_mul _ _).trans ?_
  have hdist : dist ((zeroSumIso K hK s₁ : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
      ((zeroSumIso K hK s₂ : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) = dist s₁ s₂ := by
    rw [dist_eq_norm, dist_eq_norm, ← Submodule.coe_sub, Submodule.norm_coe,
      ← map_sub, (zeroSumIso K hK).norm_map]
  rw [hdist]

theorem shannonRho_mem_simplex (K : ℕ) (hK : 2 ≤ K) (β : ℝ)
    (s : EuclideanSpace ℝ (Fin (K - 1))) :
    shannonRho K hK β s ∈ UL.Simplex K :=
  softmaxMap_mem_simplex (by omega) (shannonTemp β) _

private lemma exists_unit_ortho {m : ℕ} (hm : 2 ≤ m) (a : EuclideanSpace ℝ (Fin m)) :
    ∃ w : EuclideanSpace ℝ (Fin m), ‖w‖ = 1 ∧ inner ℝ a w = 0 := by
  let i0 : Fin m := ⟨0, by omega⟩
  let i1 : Fin m := ⟨1, by omega⟩
  have hi01 : i0 ≠ i1 := by simp [i0, i1]
  let e0 : EuclideanSpace ℝ (Fin m) := EuclideanSpace.single i0 (1 : ℝ)
  let e1 : EuclideanSpace ℝ (Fin m) := EuclideanSpace.single i1 (1 : ℝ)
  have ha0 : inner ℝ a e0 = a i0 := by
    simp [e0, EuclideanSpace.inner_single_right]
  have ha1 : inner ℝ a e1 = a i1 := by
    simp [e1, EuclideanSpace.inner_single_right]
  by_cases h0 : a i0 = 0
  · refine ⟨e0, ?_, ?_⟩
    · simp [e0]
    · rw [ha0, h0]
  · let v : EuclideanSpace ℝ (Fin m) := (a i1) • e0 - (a i0) • e1
    have hv_orth : inner ℝ a v = 0 := by
      simp only [v, inner_sub_right, inner_smul_right, ha0, ha1]
      ring
    have hv_ne : v ≠ 0 := by
      intro hv0
      have hv1 : v i1 = 0 := by simp [hv0]
      have he01 : e0 i1 = 0 := by
        simp [e0, EuclideanSpace.single_apply, hi01.symm]
      have he11 : e1 i1 = 1 := by
        simp [e1, EuclideanSpace.single_apply]
      have hv1_eq : v i1 = -a i0 := by
        simp [v, he01, he11]
      exact h0 (by linarith only [hv1, hv1_eq])
    have hnorm_ne : ‖v‖ ≠ 0 := norm_ne_zero_iff.mpr hv_ne
    refine ⟨‖v‖⁻¹ • v, ?_, ?_⟩
    · rw [norm_smul, Real.norm_eq_abs, abs_of_nonneg (inv_nonneg.mpr (norm_nonneg v)),
        inv_mul_cancel₀ hnorm_ne]
    · rw [inner_smul_right, hv_orth, mul_zero]

private lemma nonneg_on_Icc_of_hasDerivAt {g g' : ℝ → ℝ}
    (hg0 : 0 ≤ g 0) (hd : ∀ y : ℝ, HasDerivAt g (g' y) y)
    (hg' : ∀ y ∈ Set.Icc (0 : ℝ) 1, 0 ≤ g' y)
    {x : ℝ} (hx : x ∈ Set.Icc (0 : ℝ) 1) : 0 ≤ g x := by
  have hdiff : Differentiable ℝ g := fun y => (hd y).differentiableAt
  have hm := monotoneOn_of_hasDerivWithinAt_nonneg (convex_Icc (0 : ℝ) 1)
    hdiff.continuous.continuousOn
    (fun y _ => (hd y).hasDerivWithinAt)
    (fun y hy => hg' y (interior_subset hy))
  exact hg0.trans (hm ⟨le_rfl, zero_le_one⟩ hx hx.1)

private lemma exp_le_four_of_abs_le_one {x : ℝ} (hx : |x| ≤ 1) :
    Real.exp x ≤ 4 := by
  have hx1 : x ≤ 1 := (le_abs_self x).trans hx
  have he1 : Real.exp x ≤ Real.exp 1 := Real.exp_le_exp.mpr hx1
  have he3 : Real.exp 1 < 3 := Real.exp_one_lt_three
  linarith only [he1, he3]

private lemma abs_exp_sub_quad_le_cube {x : ℝ} (hx : |x| ≤ 1) :
    |Real.exp x - (1 + x + x ^ 2 / 2)| ≤ |x| ^ 3 := by
  by_cases hx0 : 0 ≤ x
  · have hxI : x ∈ Set.Icc (0 : ℝ) 1 := ⟨hx0, (abs_of_nonneg hx0) ▸ hx⟩
    have hlow : 1 + x + x ^ 2 / 2 ≤ Real.exp x := Real.quadratic_le_exp_of_nonneg hx0
    let g2 : ℝ → ℝ := fun y => 1 + 6 * y - Real.exp y
    let g1 : ℝ → ℝ := fun y => 1 + y + 3 * y ^ 2 - Real.exp y
    let g0 : ℝ → ℝ := fun y => 1 + y + y ^ 2 / 2 + y ^ 3 - Real.exp y
    have hg2 : ∀ y ∈ Set.Icc (0 : ℝ) 1, 0 ≤ g2 y := by
      intro y hy
      refine nonneg_on_Icc_of_hasDerivAt (g' := fun z => 6 - Real.exp z) (by simp [g2]) ?_ ?_ hy
      · intro z
        have hd1 : HasDerivAt (fun t : ℝ => 1 + 6 * t) 6 z := by
          simpa using ((hasDerivAt_id z).const_mul 6).const_add 1
        exact hd1.sub (Real.hasDerivAt_exp z)
      · intro z hz
        have hez : Real.exp z ≤ Real.exp 1 := Real.exp_le_exp.mpr hz.2
        have he3 : Real.exp 1 < 3 := Real.exp_one_lt_three
        linarith only [hez, he3]
    have hg1 : ∀ y ∈ Set.Icc (0 : ℝ) 1, 0 ≤ g1 y := by
      intro y hy
      refine nonneg_on_Icc_of_hasDerivAt (g' := g2) (by simp [g1]) ?_ hg2 hy
      intro z
      have hd_poly : HasDerivAt (fun t : ℝ => 1 + t + 3 * t ^ 2) (1 + 6 * z) z := by
        have h1 : HasDerivAt (fun t : ℝ => 1 + t) 1 z := by
          simpa using (hasDerivAt_id z).const_add 1
        have h2 : HasDerivAt (fun t : ℝ => 3 * t ^ 2) (3 * (2 * z ^ 1)) z :=
          (hasDerivAt_pow 2 z).const_mul 3
        convert h1.add h2 using 1
        ring
      exact hd_poly.sub (Real.hasDerivAt_exp z)
    have hg0 : 0 ≤ 1 + x + x ^ 2 / 2 + x ^ 3 - Real.exp x := by
      change 0 ≤ g0 x
      refine nonneg_on_Icc_of_hasDerivAt (g' := g1) (by simp [g0]) ?_ hg1 hxI
      intro z
      have hd_poly : HasDerivAt (fun t : ℝ => 1 + t + t ^ 2 / 2 + t ^ 3)
          (1 + z + 3 * z ^ 2) z := by
        have h1 : HasDerivAt (fun t : ℝ => 1 + t) 1 z := by
          simpa using (hasDerivAt_id z).const_add 1
        have h2 : HasDerivAt (fun t : ℝ => t ^ 2 / 2) ((2 * z ^ 1) / 2) z :=
          (hasDerivAt_pow 2 z).div_const 2
        have h3 : HasDerivAt (fun t : ℝ => t ^ 3) (3 * z ^ 2) z := by
          simpa using hasDerivAt_pow 3 z
        convert (h1.add h2).add h3 using 1
        ring
      exact hd_poly.sub (Real.hasDerivAt_exp z)
    have hx3 : 0 ≤ x ^ 3 := pow_nonneg hx0 3
    rw [abs_of_nonneg hx0]
    exact abs_le.mpr ⟨by linarith only [hlow, hx3], by linarith only [hg0]⟩
  · push_neg at hx0
    let s : ℝ := -x
    have hs0 : 0 ≤ s := by dsimp [s]; linarith only [hx0]
    have habs_eq : |x| = s := by simp [s, abs_of_neg hx0]
    have hs1 : s ≤ 1 := by linarith only [hx, habs_eq]
    have hsI : s ∈ Set.Icc (0 : ℝ) 1 := ⟨hs0, hs1⟩
    let h1 : ℝ → ℝ := fun y => 1 - y + y ^ 2 / 2 - Real.exp (-y)
    let h2 : ℝ → ℝ := fun y => Real.exp (-y) - (1 - y + y ^ 2 / 2 - y ^ 3 / 6)
    have hh1 : ∀ y ∈ Set.Icc (0 : ℝ) 1, 0 ≤ h1 y := by
      intro y hy
      refine nonneg_on_Icc_of_hasDerivAt (g' := fun z => -1 + z + Real.exp (-z))
        (by simp [h1]) ?_ ?_ hy
      · intro z
        have hd_poly : HasDerivAt (fun t : ℝ => 1 - t + t ^ 2 / 2) (-1 + z) z := by
          have ha : HasDerivAt (fun t : ℝ => 1 - t) (-1) z := by
            simpa using (hasDerivAt_id z).const_sub 1
          have hb : HasDerivAt (fun t : ℝ => t ^ 2 / 2) ((2 * z ^ 1) / 2) z :=
            (hasDerivAt_pow 2 z).div_const 2
          convert ha.add hb using 1
          ring
        have hd_exp : HasDerivAt (fun t : ℝ => Real.exp (-t)) (-Real.exp (-z)) z := by
          simpa using (Real.hasDerivAt_exp (-z)).comp z (hasDerivAt_id z).neg
        convert hd_poly.sub hd_exp using 1
        ring
      · intro z _
        have hexp_ge := Real.add_one_le_exp (-z)
        linarith only [hexp_ge]
    have hh2 : 0 ≤ Real.exp (-s) - (1 - s + s ^ 2 / 2 - s ^ 3 / 6) := by
      change 0 ≤ h2 s
      refine nonneg_on_Icc_of_hasDerivAt (g' := h1) (by simp [h2]) ?_ hh1 hsI
      intro z
      have hd_exp : HasDerivAt (fun t : ℝ => Real.exp (-t)) (-Real.exp (-z)) z := by
        simpa using (Real.hasDerivAt_exp (-z)).comp z (hasDerivAt_id z).neg
      have hd_poly : HasDerivAt (fun t : ℝ => 1 - t + t ^ 2 / 2 - t ^ 3 / 6)
          (-1 + z - z ^ 2 / 2) z := by
        have ha : HasDerivAt (fun t : ℝ => 1 - t) (-1) z := by
          simpa using (hasDerivAt_id z).const_sub 1
        have hb : HasDerivAt (fun t : ℝ => t ^ 2 / 2) ((2 * z ^ 1) / 2) z :=
          (hasDerivAt_pow 2 z).div_const 2
        have hc : HasDerivAt (fun t : ℝ => t ^ 3 / 6) ((3 * z ^ 2) / 6) z :=
          (hasDerivAt_pow 3 z).div_const 6
        convert (ha.add hb).sub hc using 1
        ring
      convert hd_exp.sub hd_poly using 1
      dsimp [h1]
      ring
    have hs_hi : 0 ≤ 1 - s + s ^ 2 / 2 - Real.exp (-s) := hh1 s hsI
    have hx_eq : x = -s := by dsimp [s]; ring
    have hsq_eq : (-s) ^ 2 = s ^ 2 := by ring
    have hpow : 0 ≤ s ^ 3 := pow_nonneg hs0 3
    rw [habs_eq, hx_eq, hsq_eq]
    refine abs_le.mpr ⟨?_, ?_⟩
    · linarith only [hh2, hpow]
    · linarith only [hs_hi, hpow]

private lemma exists_exp_jump {K : ℕ} (hK : 3 ≤ K) {α L : ℝ}
    (hα : 0 < α) (hL : 0 < L)
    {c : Fin K → ℝ} (hsum_c : ∑ k : Fin K, c k = 0) (hsum_c_sq : ∑ k : Fin K, c k ^ 2 = α ^ 2)
    (j : Fin K) :
    let u := min (1 / (32 * (K : ℝ))) (α * L / 4)
    let τ := u / α
    let Δ := u ^ 2 / (32 * (K : ℝ) ^ 2)
    ∃ t_star : ℝ, (t_star = τ ∨ t_star = -τ) ∧
      Δ ≤ |Real.exp (c j * t_star) / (∑ k : Fin K, Real.exp (c k * t_star)) - 1 / (K : ℝ)| := by
  intro u τ Δ
  have hK_real : (3 : ℝ) ≤ (K : ℝ) := by exact_mod_cast hK
  have hK_pos : (0 : ℝ) < (K : ℝ) := by linarith only [hK_real]
  have hu_pos : 0 < u := lt_min (by positivity) (by positivity)
  have hu_le_K : u ≤ 1 / (32 * (K : ℝ)) := min_le_left _ _
  have hu_le_one : u ≤ 1 := by
    have h1 : 1 / (32 * (K : ℝ)) ≤ 1 := by
      rw [div_le_iff₀ (by positivity)]
      linarith only [hK_real]
    exact hu_le_K.trans h1
  have hτ_pos : 0 < τ := div_pos hu_pos hα
  have hc_abs : ∀ k : Fin K, |c k| ≤ α := by
    intro k
    have hsq : c k ^ 2 ≤ α ^ 2 := by
      rw [← hsum_c_sq]
      exact Finset.single_le_sum (fun m _ => sq_nonneg (c m)) (Finset.mem_univ k)
    have habs_sq : |c k| ^ 2 = c k ^ 2 := sq_abs (c k)
    have habs_nn : 0 ≤ |c k| := abs_nonneg (c k)
    nlinarith only [hsq, habs_sq, habs_nn, hα]
  let D : ℝ → ℝ := fun t => (K : ℝ) * Real.exp (c j * t) - ∑ k : Fin K, Real.exp (c k * t)
  let R_rem : ℝ → Fin K → ℝ := fun t k => Real.exp (c k * t) - (1 + c k * t + (c k * t) ^ 2 / 2)
  let E : ℝ → ℝ := fun t => (K : ℝ) * R_rem t j - ∑ k : Fin K, R_rem t k
  have hD_decomp : ∀ t : ℝ,
      D t = (K : ℝ) * c j * t + ((K : ℝ) * c j ^ 2 - α ^ 2) * (t ^ 2 / 2) + E t := by
    intro t
    have hexp_k : ∀ k : Fin K,
        Real.exp (c k * t) = 1 + c k * t + c k ^ 2 * (t ^ 2 / 2) + R_rem t k := by
      intro k
      dsimp [R_rem]
      ring
    have hsum_exp : ∑ k : Fin K, Real.exp (c k * t) =
        (K : ℝ) + α ^ 2 * (t ^ 2 / 2) + ∑ k : Fin K, R_rem t k := by
      simp_rw [hexp_k]
      rw [Finset.sum_add_distrib, Finset.sum_add_distrib, Finset.sum_add_distrib]
      have hs1 : ∑ _k : Fin K, (1 : ℝ) = (K : ℝ) := by simp [Finset.sum_const, nsmul_eq_mul]
      have hs2 : ∑ k : Fin K, c k * t = 0 := by
        rw [← Finset.sum_mul, hsum_c, zero_mul]
      have hs3 : ∑ k : Fin K, c k ^ 2 * (t ^ 2 / 2) = α ^ 2 * (t ^ 2 / 2) := by
        rw [← Finset.sum_mul, hsum_c_sq]
      rw [hs1, hs2, hs3]
      ring
    dsimp [D, E]
    rw [hsum_exp, hexp_k j]
    ring
  have hct_le : ∀ {t : ℝ}, (t = τ ∨ t = -τ) → ∀ k : Fin K, |c k * t| ≤ u := by
    intro t ht k
    have ht_abs : |t| = τ := by
      rcases ht with rfl | rfl
      · exact abs_of_pos hτ_pos
      · rw [abs_neg, abs_of_pos hτ_pos]
    rw [abs_mul, ht_abs]
    calc
      |c k| * τ ≤ α * (u / α) := mul_le_mul_of_nonneg_right (hc_abs k) hτ_pos.le
      _ = u := mul_div_cancel₀ u hα.ne'
  have hE_bound : ∀ {t : ℝ}, (t = τ ∨ t = -τ) → |E t| ≤ 2 * (K : ℝ) * u ^ 3 := by
    intro t ht
    have hR_le : ∀ k : Fin K, |R_rem t k| ≤ u ^ 3 := by
      intro k
      have h1 : |c k * t| ≤ u := hct_le ht k
      have h2 : |R_rem t k| ≤ |c k * t| ^ 3 :=
        abs_exp_sub_quad_le_cube (h1.trans hu_le_one)
      exact h2.trans (pow_le_pow_left₀ (abs_nonneg _) h1 3)
    dsimp [E]
    calc
      |(K : ℝ) * R_rem t j - ∑ k : Fin K, R_rem t k|
          ≤ |(K : ℝ) * R_rem t j| + |∑ k : Fin K, R_rem t k| := abs_sub _ _
      _ ≤ (K : ℝ) * |R_rem t j| + ∑ k : Fin K, |R_rem t k| := by
        rw [abs_mul, abs_of_pos hK_pos]
        gcongr
        exact Finset.abs_sum_le_sum_abs _ _
      _ ≤ (K : ℝ) * u ^ 3 + ∑ _k : Fin K, u ^ 3 := by
        gcongr with k _
        · exact hR_le j
        · exact hR_le k
      _ = 2 * (K : ℝ) * u ^ 3 := by
        simp [Finset.sum_const, nsmul_eq_mul]
        ring
  have hE_sum : |E τ| + |E (-τ)| ≤ u ^ 2 / 8 := by
    have h1 := hE_bound (Or.inl rfl)
    have h2 := hE_bound (Or.inr rfl)
    have hKu : (K : ℝ) * u ≤ 1 / 32 := by
      have hmul := mul_le_mul_of_nonneg_left hu_le_K hK_pos.le
      have hne : (K : ℝ) ≠ 0 := hK_pos.ne'
      calc
        (K : ℝ) * u ≤ (K : ℝ) * (1 / (32 * (K : ℝ))) := hmul
        _ = 1 / 32 := by field_simp [hne]
    have h4 : 4 * (K : ℝ) * u ^ 3 ≤ u ^ 2 / 8 := by
      calc
        4 * (K : ℝ) * u ^ 3 = 4 * ((K : ℝ) * u) * u ^ 2 := by ring
        _ ≤ 4 * (1 / 32) * u ^ 2 := by gcongr
        _ = u ^ 2 / 8 := by ring
    linarith only [h1, h2, h4]
  have hex_D : ∃ t_star : ℝ, (t_star = τ ∨ t_star = -τ) ∧ u ^ 2 / 8 ≤ |D t_star| := by
    by_cases hcase : α ^ 2 / 2 ≤ (K : ℝ) * c j ^ 2
    · have hKcj_sq : α ^ 2 ≤ ((K : ℝ) * |c j|) ^ 2 := by
        have hα2 : α ^ 2 ≤ 3 * (α ^ 2 / 2) := by
          have := sq_nonneg α
          linarith only [this]
        calc
          α ^ 2 ≤ 3 * (α ^ 2 / 2) := hα2
          _ ≤ (K : ℝ) * ((K : ℝ) * c j ^ 2) :=
              mul_le_mul hK_real hcase (by positivity) hK_pos.le
          _ = (K : ℝ) ^ 2 * |c j| ^ 2 := by rw [sq_abs]; ring
          _ = ((K : ℝ) * |c j|) ^ 2 := by ring
      have hKcj : α ≤ (K : ℝ) * |c j| := by
        have hpos_rhs : 0 ≤ (K : ℝ) * |c j| := mul_nonneg hK_pos.le (abs_nonneg _)
        nlinarith only [hKcj_sq, hpos_rhs, hα]
      have hlin_big : 2 * u ^ 2 ≤ |2 * (K : ℝ) * c j * τ| := by
        have hmul : 2 * α * τ ≤ 2 * ((K : ℝ) * |c j|) * τ :=
          mul_le_mul_of_nonneg_right (by linarith only [hKcj]) hτ_pos.le
        have hατ : 2 * α * τ = 2 * u := by
          dsimp [τ]
          have hne : α ≠ 0 := hα.ne'
          field_simp [hne]
        have habs_lin : |2 * (K : ℝ) * c j * τ| = 2 * ((K : ℝ) * |c j|) * τ := by
          have hpos_2Kτ : 0 < 2 * (K : ℝ) * τ := by positivity
          calc
            |2 * (K : ℝ) * c j * τ| = |(2 * (K : ℝ) * τ) * c j| := by
              congr 1
              ring
            _ = |2 * (K : ℝ) * τ| * |c j| := abs_mul _ _
            _ = (2 * (K : ℝ) * τ) * |c j| := by rw [abs_of_pos hpos_2Kτ]
            _ = 2 * ((K : ℝ) * |c j|) * τ := by ring
        have hu2 : u ^ 2 ≤ u := by nlinarith only [hu_pos, hu_le_one]
        linarith only [hmul, hατ, habs_lin, hu2]
      have hdiff_eq : 2 * (K : ℝ) * c j * τ = (D τ - D (-τ)) - (E τ - E (-τ)) := by
        rw [hD_decomp τ, hD_decomp (-τ)]
        ring
      have hE_diff : |E τ - E (-τ)| ≤ |E τ| + |E (-τ)| := abs_sub _ _
      have htri1 : |2 * (K : ℝ) * c j * τ| ≤ |D τ - D (-τ)| + |E τ - E (-τ)| := by
        rw [hdiff_eq]
        exact abs_sub _ _
      have htri2 : |D τ - D (-τ)| ≤ |D τ| + |D (-τ)| := abs_sub _ _
      have hD_diff : u ^ 2 / 4 ≤ |D τ| + |D (-τ)| := by
        have hu_pos2 : 0 ≤ u ^ 2 := sq_nonneg u
        linarith only [hlin_big, htri1, htri2, hE_diff, hE_sum, hu_pos2]
      by_cases hτ_big : u ^ 2 / 8 ≤ |D τ|
      · exact ⟨τ, Or.inl rfl, hτ_big⟩
      · exact ⟨-τ, Or.inr rfl, by linarith only [hD_diff, hτ_big]⟩
    · push_neg at hcase
      have hquad_big : u ^ 2 / 2 ≤ |((K : ℝ) * c j ^ 2 - α ^ 2) * τ ^ 2| := by
        have hneg : (K : ℝ) * c j ^ 2 - α ^ 2 < 0 := by
          have hα2 : 0 < α ^ 2 := sq_pos_of_pos hα
          linarith only [hcase, hα2]
        have habs_q : α ^ 2 / 2 ≤ |(K : ℝ) * c j ^ 2 - α ^ 2| := by
          rw [abs_of_neg hneg]
          linarith only [hcase]
        have hτ2 : α ^ 2 / 2 * τ ^ 2 = u ^ 2 / 2 := by
          dsimp [τ]
          have hne : α ≠ 0 := hα.ne'
          field_simp [hne]
        calc
          u ^ 2 / 2 = α ^ 2 / 2 * τ ^ 2 := hτ2.symm
          _ ≤ |(K : ℝ) * c j ^ 2 - α ^ 2| * τ ^ 2 :=
              mul_le_mul_of_nonneg_right habs_q (sq_nonneg τ)
          _ = |((K : ℝ) * c j ^ 2 - α ^ 2) * τ ^ 2| := by
              rw [abs_mul, abs_of_nonneg (sq_nonneg τ)]
      have hsum_eq : ((K : ℝ) * c j ^ 2 - α ^ 2) * τ ^ 2 =
          (D τ + D (-τ)) - (E τ + E (-τ)) := by
        rw [hD_decomp τ, hD_decomp (-τ)]
        ring
      have hE_add : |E τ + E (-τ)| ≤ |E τ| + |E (-τ)| := abs_add_le _ _
      have htri1 : |((K : ℝ) * c j ^ 2 - α ^ 2) * τ ^ 2| ≤
          |D τ + D (-τ)| + |E τ + E (-τ)| := by
        rw [hsum_eq]
        exact abs_sub _ _
      have htri2 : |D τ + D (-τ)| ≤ |D τ| + |D (-τ)| := abs_add_le _ _
      have hD_add : u ^ 2 / 4 ≤ |D τ| + |D (-τ)| := by
        have hu_pos2 : 0 ≤ u ^ 2 := sq_nonneg u
        linarith only [hquad_big, htri1, htri2, hE_add, hE_sum, hu_pos2]
      by_cases hτ_big : u ^ 2 / 8 ≤ |D τ|
      · exact ⟨τ, Or.inl rfl, hτ_big⟩
      · exact ⟨-τ, Or.inr rfl, by linarith only [hD_add, hτ_big]⟩
  obtain ⟨t_star, ht_star, hD_star⟩ := hex_D
  refine ⟨t_star, ht_star, ?_⟩
  have hsum_pos : 0 < ∑ k : Fin K, Real.exp (c k * t_star) :=
    Finset.sum_pos (fun k _ => Real.exp_pos _) ⟨j, Finset.mem_univ j⟩
  have hsum_le : ∑ k : Fin K, Real.exp (c k * t_star) ≤ 4 * (K : ℝ) := by
    calc
      ∑ k : Fin K, Real.exp (c k * t_star) ≤ ∑ _k : Fin K, (4 : ℝ) := by
        refine Finset.sum_le_sum fun k _ => ?_
        exact exp_le_four_of_abs_le_one ((hct_le ht_star k).trans hu_le_one)
      _ = 4 * (K : ℝ) := by
        simp [Finset.sum_const, nsmul_eq_mul]
        ring
  have hdenom_pos : 0 < (K : ℝ) * ∑ k : Fin K, Real.exp (c k * t_star) :=
    mul_pos hK_pos hsum_pos
  have hdenom_le : (K : ℝ) * ∑ k : Fin K, Real.exp (c k * t_star) ≤ 4 * (K : ℝ) ^ 2 := by
    calc
      (K : ℝ) * ∑ k : Fin K, Real.exp (c k * t_star) ≤ (K : ℝ) * (4 * (K : ℝ)) :=
        mul_le_mul_of_nonneg_left hsum_le hK_pos.le
      _ = 4 * (K : ℝ) ^ 2 := by ring
  have hfrac_eq : Real.exp (c j * t_star) / (∑ k : Fin K, Real.exp (c k * t_star)) - 1 / (K : ℝ) =
      D t_star / ((K : ℝ) * ∑ k : Fin K, Real.exp (c k * t_star)) := by
    rw [div_sub_div _ _ hsum_pos.ne' hK_pos.ne']
    dsimp [D]
    ring
  rw [hfrac_eq, abs_div, abs_of_pos hdenom_pos]
  calc
    Δ = (u ^ 2 / 8) / (4 * (K : ℝ) ^ 2) := by
      dsimp [Δ]
      ring
    _ ≤ |D t_star| / (4 * (K : ℝ) ^ 2) := by gcongr
    _ ≤ |D t_star| / ((K : ℝ) * ∑ k : Fin K, Real.exp (c k * t_star)) :=
      div_le_div_of_nonneg_left (by positivity) hdenom_pos hdenom_le

private lemma exists_softmax_jump {K : ℕ} (hK : 3 ≤ K) {R β L : ℝ}
    (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    {w : EuclideanSpace ℝ (Fin (K - 1))} (hw : ‖w‖ = 1) (j : Fin K) :
    let α := shannonAlpha K R β
    let u := min (1 / (32 * (K : ℝ))) (α * L / 4)
    let τ := u / α
    let Δ := u ^ 2 / (32 * (K : ℝ) ^ 2)
    ∃ t_star : ℝ, (t_star = τ ∨ t_star = -τ) ∧
      Δ ≤ |shannonEta K (by omega) R β (t_star • w) j - shannonEta K (by omega) R β 0 j| := by
  intro α u τ Δ
  have hK2 : 2 ≤ K := by omega
  have hα : 0 < α := shannonAlpha_pos hK2 hR hβ
  let zw : EuclideanSpace ℝ (Fin K) :=
    ((zeroSumIso K hK2 w : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
  let c : Fin K → ℝ := fun k => α * zw k
  have hsum_zw : ∑ k : Fin K, zw k = 0 :=
    (UL.Proof_lem_A_5.mem_zeroSumSubspace_iff K zw).mp (zeroSumIso K hK2 w).2
  have hsum_c : ∑ k : Fin K, c k = 0 := by
    simp only [c, ← Finset.mul_sum, hsum_zw, mul_zero]
  have hnorm_zw : ∑ k : Fin K, zw k ^ 2 = 1 := by
    have h1 : ‖zw‖ = 1 := by
      rw [Submodule.norm_coe, (zeroSumIso K hK2).norm_map, hw]
    have h2 := EuclideanSpace.norm_sq_eq zw
    rw [h1, one_pow] at h2
    simpa [Real.norm_eq_abs, sq_abs] using h2.symm
  have hsum_c_sq : ∑ k : Fin K, c k ^ 2 = α ^ 2 := by
    calc
      ∑ k : Fin K, c k ^ 2 = ∑ k : Fin K, α ^ 2 * zw k ^ 2 := by
        refine Finset.sum_congr rfl fun k _ => ?_
        dsimp [c]
        ring
      _ = α ^ 2 * ∑ k : Fin K, zw k ^ 2 := (Finset.mul_sum _ _ _).symm
      _ = α ^ 2 := by rw [hnorm_zw, mul_one]
  have hlin_arg : ∀ (t : ℝ) (k : Fin K),
      ((scoreOpV0 K hK2 R (t • w) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) k /
        shannonTemp β = c k * t := by
    intro t k
    unfold scoreOpV0
    rw [ContinuousLinearMap.smul_apply]
    change ((scoreScale K R • zeroSumIso K hK2 (t • w) : UL.ZeroSumSubspace K) :
        EuclideanSpace ℝ (Fin K)) k / shannonTemp β = c k * t
    rw [map_smul, smul_smul, Submodule.coe_smul, PiLp.smul_apply, smul_eq_mul]
    dsimp [c, α, shannonAlpha, zw]
    ring
  have heta_line : ∀ (t : ℝ) (k : Fin K),
      shannonEta K hK2 R β (t • w) k =
        Real.exp (c k * t) / ∑ m : Fin K, Real.exp (c m * t) := by
    intro t k
    unfold shannonEta
    rw [softmaxMap_apply, hlin_arg t k]
    congr 1
    refine Finset.sum_congr rfl fun m _ => ?_
    rw [hlin_arg t m]
  have heta_zero : shannonEta K hK2 R β 0 j = 1 / (K : ℝ) := by
    have h0 : (0 : EuclideanSpace ℝ (Fin (K - 1))) = (0 : ℝ) • w := by simp
    rw [h0, heta_line 0 j]
    simp [Finset.sum_const, nsmul_eq_mul]
  obtain ⟨t_star, ht_star, hjump⟩ := exists_exp_jump hK hα hL hsum_c hsum_c_sq j
  refine ⟨t_star, ht_star, ?_⟩
  rw [heta_line t_star j, heta_zero]
  exact hjump

private lemma integrableOn_of_measurable_bdd {m : ℕ}
    {h : EuclideanSpace ℝ (Fin m) → ℝ} (hh : Measurable h)
    {M : ℝ} (hbdd : ∀ x, ‖h x‖ ≤ M)
    {S : Set (EuclideanSpace ℝ (Fin m))} (hS : MeasureTheory.volume S < ⊤) :
    MeasureTheory.IntegrableOn h S MeasureTheory.volume := by
  haveI : Fact (MeasureTheory.volume S < ⊤) := ⟨hS⟩
  exact (MeasureTheory.memLp_top_of_bound hh.aestronglyMeasurable M
    (Filter.Eventually.of_forall hbdd)).integrable le_top

theorem exists_ridge_l2_gap (K : ℕ) (hK : 3 ≤ K) {R β L : ℝ}
    (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    (hEtaLip : ∀ x y : EuclideanSpace ℝ (Fin (K - 1)),
      ‖shannonEta K (by omega) R β x - shannonEta K (by omega) R β y‖ ≤
        shannonAlpha K R β * ‖x - y‖) :
    ∃ c_star : ℝ, 0 < c_star ∧
      ∀ (p : EuclideanSpace ℝ (Fin (K - 1)) → EuclideanSpace ℝ (Fin K)),
        Measurable p →
        (∀ x : EuclideanSpace ℝ (Fin (K - 1)), p x ∈ UL.Simplex K) →
        (∃ (j : Fin K) (a : EuclideanSpace ℝ (Fin (K - 1))) (f : ℝ → ℝ),
          Measurable f ∧
          (∀ t : ℝ, f t ∈ Set.Icc (0 : ℝ) 1) ∧
          (∀ᵐ x ∂(ballUniformMeasure (K - 1) L), p x j = f (inner ℝ a x))) →
        c_star ≤ ∫ x, ‖shannonEta K (by omega) R β x - p x‖ ^ 2 ∂(ballUniformMeasure (K - 1) L) := by
  let α : ℝ := shannonAlpha K R β
  have hα : 0 < α := shannonAlpha_pos (by omega) hR hβ
  let u : ℝ := min (1 / (32 * (K : ℝ))) (α * L / 4)
  have hu : 0 < u := lt_min (by positivity) (by positivity)
  let τ : ℝ := u / α
  have hτ : 0 < τ := div_pos hu hα
  have hτ_le : τ ≤ L / 4 := by
    dsimp [τ]
    rw [div_le_iff₀ hα]
    have : u ≤ α * L / 4 := min_le_right _ _
    linarith
  let Δ : ℝ := u ^ 2 / (32 * (K : ℝ) ^ 2)
  have hΔ : 0 < Δ := by positivity
  let r : ℝ := min (τ / 3) (Δ / (4 * α))
  have hr : 0 < r := lt_min (by positivity) (by positivity)
  have hr_τ : r ≤ τ / 3 := min_le_left _ _
  have hr_Δ : r ≤ Δ / (4 * α) := min_le_right _ _
  let B_L : Set (EuclideanSpace ℝ (Fin (K - 1))) := Metric.ball 0 L
  let B_r : Set (EuclideanSpace ℝ (Fin (K - 1))) := Metric.ball 0 r
  have hvol_BL_pos : 0 < (MeasureTheory.volume B_L).toReal :=
    ENNReal.toReal_pos (Metric.measure_ball_pos MeasureTheory.volume 0 hL).ne'
      MeasureTheory.measure_ball_lt_top.ne
  have hvol_Br_pos : 0 < (MeasureTheory.volume B_r).toReal :=
    ENNReal.toReal_pos (Metric.measure_ball_pos MeasureTheory.volume 0 hr).ne'
      MeasureTheory.measure_ball_lt_top.ne
  let c_star : ℝ :=
    (MeasureTheory.volume B_L).toReal⁻¹ * ((Δ ^ 2 / 8) * (MeasureTheory.volume B_r).toReal)
  refine ⟨c_star, by positivity, ?_⟩
  intro p hp_meas hp_simp ⟨j, a, f, _hf_meas, _hf_Icc, hp_ae⟩
  let η : EuclideanSpace ℝ (Fin (K - 1)) → EuclideanSpace ℝ (Fin K) :=
    shannonEta K (by omega) R β
  have hη_lip : LipschitzWith (Real.toNNReal α) η := by
    rw [lipschitzWith_iff_dist_le_mul]
    intro x y
    rw [dist_eq_norm, dist_eq_norm, Real.coe_toNNReal α hα.le]
    exact hEtaLip x y
  have hη_meas : Measurable η := hη_lip.continuous.measurable
  obtain ⟨w, hw_norm, hw_orth⟩ := exists_unit_ortho (m := K - 1) (by omega) a
  obtain ⟨t_star, ht_star, hjump⟩ := exists_softmax_jump hK hR hβ hL hw_norm j
  let s : EuclideanSpace ℝ (Fin (K - 1)) := t_star • w
  have hs_norm : ‖s‖ = τ := by
    have ht_abs : |t_star| = τ := by
      rcases ht_star with rfl | rfl
      · exact abs_of_pos hτ
      · rw [abs_neg, abs_of_pos hτ]
    rw [norm_smul, Real.norm_eq_abs, ht_abs, hw_norm, mul_one]
  have hs_orth : inner ℝ a s = 0 := by
    rw [inner_smul_right, hw_orth, mul_zero]
  have hBr_sub : B_r ⊆ B_L := Metric.ball_subset_ball (by linarith only [hr_τ, hτ_le, hτ])
  have hBs_sub : Metric.ball s r ⊆ B_L := by
    intro y hy
    rw [Metric.mem_ball, dist_zero_right]
    have htri : ‖y‖ ≤ ‖s‖ + ‖y - s‖ := norm_le_insert' y s
    have hys : ‖y - s‖ < r := by simpa [Metric.mem_ball, dist_eq_norm] using hy
    linarith only [htri, hys, hs_norm, hr_τ, hτ_le, hτ]
  have hdisj : Disjoint B_r (Metric.ball s r) := by
    rw [Set.disjoint_left]
    intro y hy0 hys
    rw [Metric.mem_ball, dist_zero_right] at hy0
    rw [Metric.mem_ball, dist_eq_norm] at hys
    have htri : ‖s‖ ≤ ‖y‖ + ‖s - y‖ := by
      simpa using norm_add_le y (s - y)
    rw [norm_sub_rev] at htri
    linarith only [htri, hy0, hys, hs_norm, hr_τ, hτ]
  have hp_res : ∀ᵐ x ∂(MeasureTheory.volume.restrict B_L), p x j = f (inner ℝ a x) := by
    have hlt_top : MeasureTheory.volume (Metric.ball (0 : EuclideanSpace ℝ (Fin (K - 1))) L) ≠ ⊤ :=
      MeasureTheory.measure_ball_lt_top.ne
    unfold ballUniformMeasure ProbabilityTheory.cond at hp_ae
    simpa [MeasureTheory.ae_iff, B_L, hlt_top] using hp_ae
  have hp_vol : ∀ᵐ x ∂MeasureTheory.volume, x ∈ B_L → p x j = f (inner ℝ a x) :=
    (MeasureTheory.ae_restrict_iff' measurableSet_ball).mp hp_res
  have hp_shift_vol : ∀ᵐ z ∂MeasureTheory.volume,
      z + s ∈ B_L → p (z + s) j = f (inner ℝ a (z + s)) :=
    (MeasureTheory.measurePreserving_add_right MeasureTheory.volume s).quasiMeasurePreserving.tendsto_ae.eventually
      hp_vol
  let g : EuclideanSpace ℝ (Fin (K - 1)) → ℝ := fun x => ‖η x - p x‖ ^ 2
  have hg_meas : Measurable g := ((hη_meas.sub hp_meas).norm).pow_const 2
  have hg_nonneg : ∀ x, 0 ≤ g x := fun x => sq_nonneg _
  have hg_norm_le : ∀ x, ‖g x‖ ≤ 4 := by
    intro x
    have h1 : ‖η x - p x‖ ≤ 2 := by
      calc
        ‖η x - p x‖ ≤ ‖η x‖ + ‖p x‖ := norm_sub_le _ _
        _ ≤ 1 + 1 := add_le_add
          (UL.Proof_lem_A_5.norm_le_one_of_mem_simplex (shannonEta_mem_simplex (by omega) R β x))
          (UL.Proof_lem_A_5.norm_le_one_of_mem_simplex (hp_simp x))
        _ = 2 := by norm_num
    rw [Real.norm_eq_abs, abs_of_nonneg (hg_nonneg x)]
    change ‖η x - p x‖ ^ 2 ≤ 4
    have h0 : 0 ≤ ‖η x - p x‖ := norm_nonneg _
    nlinarith only [h0, h1]
  have hcoord_sq_le : ∀ x, (η x j - p x j) ^ 2 ≤ g x := by
    intro x
    dsimp [g]
    rw [EuclideanSpace.norm_sq_eq]
    have hle := Finset.single_le_sum (fun k _ => sq_nonneg ‖(η x - p x) k‖) (Finset.mem_univ j)
    simpa [Real.norm_eq_abs, sq_abs] using hle
  have hjump' : Δ ≤ |η s j - η 0 j| := hjump
  have hae_Br : ∀ᵐ z ∂(MeasureTheory.volume.restrict B_r),
      Δ ^ 2 / 8 ≤ g z + g (z + s) := by
    rw [MeasureTheory.ae_restrict_iff' measurableSet_ball]
    filter_upwards [hp_vol, hp_shift_vol] with z hz0 hzs hz_mem
    have hz_norm : ‖z‖ < r := by simpa [B_r] using hz_mem
    have hzs_mem : z + s ∈ Metric.ball s r := by
      rw [Metric.mem_ball, dist_eq_norm, add_sub_cancel_right]
      exact hz_norm
    have hp_eq : p z j = p (z + s) j := by
      rw [hz0 (hBr_sub hz_mem), hzs (hBs_sub hzs_mem), inner_add_right, hs_orth, add_zero]
    have hlip1 : |η z j - η 0 j| ≤ Δ / 4 := by
      calc
        |η z j - η 0 j| = |(η z - η 0) j| := rfl
        _ ≤ ‖η z - η 0‖ := by simpa [Real.norm_eq_abs] using PiLp.norm_apply_le (η z - η 0) j
        _ ≤ α * ‖z - 0‖ := hEtaLip z 0
        _ ≤ α * r := by
          rw [sub_zero]
          exact mul_le_mul_of_nonneg_left hz_norm.le hα.le
        _ ≤ α * (Δ / (4 * α)) := mul_le_mul_of_nonneg_left hr_Δ hα.le
        _ = Δ / 4 := by
          have hne : α ≠ 0 := hα.ne'
          field_simp [hne]
    have hlip2 : |η (z + s) j - η s j| ≤ Δ / 4 := by
      calc
        |η (z + s) j - η s j| = |(η (z + s) - η s) j| := rfl
        _ ≤ ‖η (z + s) - η s‖ := by
          simpa [Real.norm_eq_abs] using PiLp.norm_apply_le (η (z + s) - η s) j
        _ ≤ α * ‖(z + s) - s‖ := hEtaLip (z + s) s
        _ ≤ α * r := by
          rw [add_sub_cancel_right]
          exact mul_le_mul_of_nonneg_left hz_norm.le hα.le
        _ ≤ α * (Δ / (4 * α)) := mul_le_mul_of_nonneg_left hr_Δ hα.le
        _ = Δ / 4 := by
          have hne : α ≠ 0 := hα.ne'
          field_simp [hne]
    have hgap_z : Δ / 2 ≤ |η (z + s) j - η z j| := by
      have htri : |η s j - η 0 j| ≤
          |η (z + s) j - η z j| + |η (z + s) j - η s j| + |η z j - η 0 j| := by
        have hdecomp : η s j - η 0 j =
            (η (z + s) j - η z j) - (η (z + s) j - η s j) + (η z j - η 0 j) := by ring
        have hsub_abs := abs_sub (η (z + s) j - η z j) (η (z + s) j - η s j)
        calc
          |η s j - η 0 j|
              = |((η (z + s) j - η z j) - (η (z + s) j - η s j)) + (η z j - η 0 j)| := by
                rw [hdecomp]
          _ ≤ |(η (z + s) j - η z j) - (η (z + s) j - η s j)| + |η z j - η 0 j| :=
                abs_add_le _ _
          _ ≤ |η (z + s) j - η z j| + |η (z + s) j - η s j| + |η z j - η 0 j| := by
                linarith only [hsub_abs]
      linarith only [hjump', htri, hlip1, hlip2]
    have hsq_sum : Δ ^ 2 / 8 ≤ (η z j - p z j) ^ 2 + (η (z + s) j - p (z + s) j) ^ 2 := by
      rw [← hp_eq]
      have hsq_diff : (Δ / 2) ^ 2 ≤ (η (z + s) j - η z j) ^ 2 := by
        have := mul_self_le_mul_self (by positivity) hgap_z
        simpa [sq, sq_abs] using this
      have hpar := sq_nonneg (η z j + η (z + s) j - 2 * p z j)
      have hident : 2 * ((η z j - p z j) ^ 2 + (η (z + s) j - p z j) ^ 2) =
          (η (z + s) j - η z j) ^ 2 + (η z j + η (z + s) j - 2 * p z j) ^ 2 := by ring
      have hhalf : Δ ^ 2 / 4 = (Δ / 2) ^ 2 := by ring
      linarith only [hsq_diff, hpar, hident, hhalf]
    exact hsq_sum.trans (add_le_add (hcoord_sq_le z) (hcoord_sq_le (z + s)))
  have hint_BL : MeasureTheory.IntegrableOn g B_L MeasureTheory.volume :=
    integrableOn_of_measurable_bdd hg_meas hg_norm_le MeasureTheory.measure_ball_lt_top
  have hint_Br : MeasureTheory.IntegrableOn g B_r MeasureTheory.volume :=
    integrableOn_of_measurable_bdd hg_meas hg_norm_le MeasureTheory.measure_ball_lt_top
  have hint_Bs : MeasureTheory.IntegrableOn g (Metric.ball s r) MeasureTheory.volume :=
    integrableOn_of_measurable_bdd hg_meas hg_norm_le MeasureTheory.measure_ball_lt_top
  have hint_Br_shift : MeasureTheory.IntegrableOn (fun z => g (z + s)) B_r MeasureTheory.volume :=
    integrableOn_of_measurable_bdd (hg_meas.comp (measurable_id.add_const s))
      (fun z => hg_norm_le (z + s)) MeasureTheory.measure_ball_lt_top
  have hshift_int : ∫ y in Metric.ball s r, g y ∂MeasureTheory.volume =
      ∫ z in B_r, g (z + s) ∂MeasureTheory.volume := by
    rw [← MeasureTheory.integral_indicator measurableSet_ball,
        ← MeasureTheory.integral_indicator measurableSet_ball,
        ← MeasureTheory.integral_add_right_eq_self (fun y => (Metric.ball s r).indicator g y) s]
    refine congrArg (MeasureTheory.integral MeasureTheory.volume) (funext fun z => ?_)
    have hmem_iff : z + s ∈ Metric.ball s r ↔ z ∈ B_r := by
      simp [B_r, Metric.mem_ball, dist_eq_norm]
    by_cases hz : z ∈ B_r
    · rw [Set.indicator_of_mem (hmem_iff.mpr hz), Set.indicator_of_mem hz]
    · rw [Set.indicator_of_notMem (mt hmem_iff.mp hz), Set.indicator_of_notMem hz]
  have hint_const : MeasureTheory.Integrable (fun _ => Δ ^ 2 / 8)
      (MeasureTheory.volume.restrict B_r) := by
    haveI : Fact (MeasureTheory.volume B_r < ⊤) := ⟨MeasureTheory.measure_ball_lt_top⟩
    exact MeasureTheory.integrable_const _
  have hBr_lower : (Δ ^ 2 / 8) * (MeasureTheory.volume B_r).toReal ≤
      ∫ x in B_L, g x ∂MeasureTheory.volume := by
    have hsub_union : B_r ∪ Metric.ball s r ⊆ B_L := Set.union_subset hBr_sub hBs_sub
    calc
      (Δ ^ 2 / 8) * (MeasureTheory.volume B_r).toReal
          = ∫ _ in B_r, (Δ ^ 2 / 8) ∂MeasureTheory.volume := by
            rw [MeasureTheory.setIntegral_const, MeasureTheory.measureReal_def, smul_eq_mul,
              mul_comm]
      _ ≤ ∫ z in B_r, (g z + g (z + s)) ∂MeasureTheory.volume :=
            MeasureTheory.integral_mono_ae hint_const (hint_Br.add hint_Br_shift) hae_Br
      _ = (∫ z in B_r, g z ∂MeasureTheory.volume) +
            ∫ z in B_r, g (z + s) ∂MeasureTheory.volume :=
            MeasureTheory.integral_add hint_Br hint_Br_shift
      _ = (∫ z in B_r, g z ∂MeasureTheory.volume) +
            ∫ y in Metric.ball s r, g y ∂MeasureTheory.volume := by rw [hshift_int]
      _ = ∫ x in B_r ∪ Metric.ball s r, g x ∂MeasureTheory.volume :=
            (MeasureTheory.setIntegral_union hdisj measurableSet_ball hint_Br hint_Bs).symm
      _ ≤ ∫ x in B_L, g x ∂MeasureTheory.volume :=
            MeasureTheory.setIntegral_mono_set hint_BL
              (Filter.Eventually.of_forall hg_nonneg) hsub_union.eventuallyLE
  have hcond_int : ∫ x, g x ∂(ballUniformMeasure (K - 1) L) =
      (MeasureTheory.volume B_L).toReal⁻¹ * ∫ x in B_L, g x ∂MeasureTheory.volume := by
    unfold ballUniformMeasure ProbabilityTheory.cond
    rw [MeasureTheory.integral_smul_measure, ENNReal.toReal_inv, smul_eq_mul]
  change c_star ≤ ∫ x, g x ∂(ballUniformMeasure (K - 1) L)
  rw [hcond_int]
  exact mul_le_mul_of_nonneg_left hBr_lower (inv_nonneg.mpr hvol_BL_pos.le)

end UL.Proof_thm_E_1

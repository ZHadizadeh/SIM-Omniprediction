import Mathlib
import UL.Proof.thm_E_1.H0_Defs
import UL.Proof.cor_A_8.H1_SimplexGrad
import UL.Proof.lem_A_1.H1_FaceSubgrad
import UL.Proof.lem_A_5.H1_Simplex
set_option autoImplicit false

namespace UL.Proof_thm_E_1

/-! ### Private Helpers: Derivative Congruence, Zero-Sum Norm, and KL Inequality -/

private lemma hasDerivAt_of_eq {f₁ f₂ : ℝ → ℝ} {d₁ d₂ x : ℝ}
    (h : HasDerivAt f₁ d₁ x) (hf : ∀ y, f₂ y = f₁ y) (hd : d₂ = d₁) :
    HasDerivAt f₂ d₂ x := by
  rwa [funext hf, hd]

private lemma hasFDerivAt_of_eq {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] {f₁ f₂ : E → F} {L₁ L₂ : E →L[ℝ] F} {x : E}
    (h : HasFDerivAt f₁ L₁ x) (hf : ∀ y, f₂ y = f₁ y) (hL : ∀ v, L₂ v = L₁ v) :
    HasFDerivAt f₂ L₂ x := by
  rwa [funext hf, ContinuousLinearMap.ext hL]

private lemma sum_sq_le_sq_sum_of_nonneg {K : ℕ} {f : Fin K → ℝ} (hf : ∀ j, 0 ≤ f j) :
    ∑ j : Fin K, (f j) ^ 2 ≤ (∑ j : Fin K, f j) ^ 2 := by
  have h1 : (∑ j : Fin K, f j) ^ 2 = ∑ j : Fin K, f j * (∑ k : Fin K, f k) := by
    rw [sq, Finset.sum_mul]
  rw [h1]
  refine Finset.sum_le_sum fun j _ => ?_
  have hle : f j ≤ ∑ k : Fin K, f k :=
    Finset.single_le_sum (fun k _ => hf k) (Finset.mem_univ j)
  nlinarith [hf j]

private lemma two_mul_norm_sq_le_sum_abs_sq {K : ℕ} {v : EuclideanSpace ℝ (Fin K)}
    (hv : ∑ j : Fin K, v j = 0) :
    2 * ‖v‖ ^ 2 ≤ (∑ j : Fin K, |v j|) ^ 2 := by
  have hdecomp : ∀ x : ℝ,
      max x 0 - max (-x) 0 = x ∧
      max x 0 + max (-x) 0 = |x| ∧
      (max x 0) ^ 2 + (max (-x) 0) ^ 2 = x ^ 2 := by
    intro x
    rcases le_total 0 x with hx | hx
    · rw [max_eq_left hx, max_eq_right (by linarith), abs_of_nonneg hx]
      exact ⟨by ring, by ring, by ring⟩
    · rw [max_eq_right hx, max_eq_left (by linarith), abs_of_nonpos hx]
      exact ⟨by ring, by ring, by ring⟩
  set S_pos : ℝ := ∑ j : Fin K, max (v j) 0
  set S_neg : ℝ := ∑ j : Fin K, max (-v j) 0
  have hS_eq : S_pos = S_neg := by
    have hdiff : S_pos - S_neg = ∑ j : Fin K, v j := by
      dsimp [S_pos, S_neg]
      rw [← Finset.sum_sub_distrib]
      exact Finset.sum_congr rfl fun j _ => (hdecomp (v j)).1
    linarith
  have h_abs_sum : ∑ j : Fin K, |v j| = 2 * S_pos := by
    have hsum : ∑ j : Fin K, |v j| = S_pos + S_neg := by
      dsimp [S_pos, S_neg]
      rw [← Finset.sum_add_distrib]
      exact Finset.sum_congr rfl fun j _ => (hdecomp (v j)).2.1.symm
    linarith
  have h_norm_sq : ‖v‖ ^ 2 ≤ 2 * S_pos ^ 2 := by
    rw [EuclideanSpace.norm_sq_eq]
    have h1 : ∑ j : Fin K, ‖v j‖ ^ 2 =
        (∑ j : Fin K, (max (v j) 0) ^ 2) + ∑ j : Fin K, (max (-v j) 0) ^ 2 := by
      rw [← Finset.sum_add_distrib]
      refine Finset.sum_congr rfl fun j _ => ?_
      rw [Real.norm_eq_abs, sq_abs]
      exact (hdecomp (v j)).2.2.symm
    have hp_le : ∑ j : Fin K, (max (v j) 0) ^ 2 ≤ S_pos ^ 2 :=
      sum_sq_le_sq_sum_of_nonneg fun j => le_max_right _ _
    have hn_le : ∑ j : Fin K, (max (-v j) 0) ^ 2 ≤ S_neg ^ 2 :=
      sum_sq_le_sq_sum_of_nonneg fun j => le_max_right _ _
    rw [h1, ← hS_eq] at *
    linarith
  rw [h_abs_sum]
  nlinarith

private lemma kpt_scalar_ineq {t : ℝ} (ht : 0 ≤ t) :
    3 * (t - 1) ^ 2 ≤ (2 * t + 4) * (t * Real.log t - t + 1) := by
  rcases eq_or_lt_of_le ht with rfl | ht_pos
  · norm_num
  · let f : ℝ → ℝ := fun x => (2 * x + 4) * (x * Real.log x - x + 1) - 3 * (x - 1) ^ 2
    let g : ℝ → ℝ := fun x => 4 * ((x + 1) * Real.log x - 2 * (x - 1))
    let g' : ℝ → ℝ := fun x => 4 * (Real.log x + x⁻¹ - 1)
    have hd_g : ∀ x : ℝ, 0 < x → HasDerivAt g (g' x) x := by
      intro x hx
      have h1 := (hasDerivAt_id' x).add_const 1
      have h2 := Real.hasDerivAt_log hx.ne'
      have h3 := ((hasDerivAt_id' x).sub_const 1).const_mul 2
      exact hasDerivAt_of_eq (((h1.mul h2).sub h3).const_mul 4)
        (fun y => by simp [g])
        (by dsimp [g']; field_simp [hx.ne']; ring)
    have hg'_nn : ∀ x : ℝ, 0 < x → 0 ≤ g' x := by
      intro x hx
      have hlog := Real.log_le_sub_one_of_pos (inv_pos.mpr hx)
      rw [Real.log_inv] at hlog
      dsimp [g']
      linarith
    have hg_mono : MonotoneOn g (Set.Ioi (0 : ℝ)) := by
      refine monotoneOn_of_hasDerivWithinAt_nonneg (convex_Ioi 0)
        (fun x hx => (hd_g x hx).continuousAt.continuousWithinAt)
        (fun x hx => (hd_g x (interior_subset hx)).hasDerivWithinAt)
        (fun x hx => hg'_nn x (interior_subset hx))
    have hg1 : g 1 = 0 := by simp [g]
    have hd_f : ∀ x : ℝ, 0 < x → HasDerivAt f (g x) x := by
      intro x hx
      have h1 := ((hasDerivAt_id' x).const_mul 2).add_const 4
      have h2 := ((Real.hasDerivAt_mul_log hx.ne').sub (hasDerivAt_id' x)).add_const 1
      have h3 := (((hasDerivAt_id' x).sub_const 1).pow 2).const_mul 3
      exact hasDerivAt_of_eq ((h1.mul h2).sub h3)
        (fun y => by simp [f])
        (by dsimp [g]; norm_num; ring)
    have hf1 : f 1 = 0 := by simp [f]
    suffices hfn : 0 ≤ f t by
      dsimp [f] at hfn
      linarith
    rcases le_total t 1 with ht1 | h1t
    · have hf_anti : AntitoneOn f (Set.Ioc (0 : ℝ) 1) := by
        refine antitoneOn_of_hasDerivWithinAt_nonpos (convex_Ioc 0 1)
          (fun x hx => (hd_f x hx.1).continuousAt.continuousWithinAt)
          (fun x hx => (hd_f x (interior_subset hx).1).hasDerivWithinAt)
          (fun x hx => ?_)
        have hx' := interior_subset hx
        have hle := hg_mono hx'.1 (Set.mem_Ioi.mpr zero_lt_one) hx'.2
        linarith
      have hle := hf_anti ⟨ht_pos, ht1⟩ ⟨zero_lt_one, le_rfl⟩ ht1
      linarith
    · have hf_mono : MonotoneOn f (Set.Ici (1 : ℝ)) := by
        refine monotoneOn_of_hasDerivWithinAt_nonneg (convex_Ici 1)
          (fun x hx => by
            have hx1 : (1 : ℝ) ≤ x := hx
            exact (hd_f x (by linarith)).continuousAt.continuousWithinAt)
          (fun x hx => by
            have hx1 : (1 : ℝ) ≤ x := interior_subset hx
            exact (hd_f x (by linarith)).hasDerivWithinAt)
          (fun x hx => ?_)
        have hx1 : (1 : ℝ) ≤ x := interior_subset hx
        have hge := hg_mono (Set.mem_Ioi.mpr zero_lt_one) (Set.mem_Ioi.mpr (by linarith)) hx1
        linarith
      have hge := hf_mono Set.self_mem_Ici h1t h1t
      linarith

private lemma kpt_two_var_ineq {u v : ℝ} (hu : 0 ≤ u) (hv : 0 ≤ v) (huv : v = 0 → u = 0) :
    3 * (u - v) ^ 2 ≤ (2 * u + 4 * v) * (u * Real.log u - u * Real.log v - u + v) ∧
      0 ≤ u * Real.log u - u * Real.log v - u + v := by
  rcases eq_or_lt_of_le hv with rfl | hv_pos
  · rw [huv rfl]
    norm_num
  · rcases eq_or_lt_of_le hu with rfl | hu_pos
    · refine ⟨by nlinarith [sq_nonneg v], by linarith⟩
    · have hsc := kpt_scalar_ineq (div_nonneg hu hv_pos.le)
      have hmul : 3 * (u / v - 1) ^ 2 * v ^ 2 ≤
          (2 * (u / v) + 4) * ((u / v) * Real.log (u / v) - (u / v) + 1) * v ^ 2 :=
        mul_le_mul_of_nonneg_right hsc (sq_nonneg v)
      rw [Real.log_div hu_pos.ne' hv_pos.ne'] at hmul
      have hL : 3 * (u / v - 1) ^ 2 * v ^ 2 = 3 * (u - v) ^ 2 := by
        field_simp [hv_pos.ne']
      have hR : (2 * (u / v) + 4) * ((u / v) * (Real.log u - Real.log v) - (u / v) + 1) * v ^ 2 =
          (2 * u + 4 * v) * (u * Real.log u - u * Real.log v - u + v) := by
        field_simp [hv_pos.ne']
      rw [hL, hR] at hmul
      refine ⟨hmul, ?_⟩
      have hpos : 0 < 2 * u + 4 * v := by positivity
      have hnn : 0 ≤ 3 * (u - v) ^ 2 := by positivity
      nlinarith

private lemma norm_sub_sq_le_kl {K : ℕ} {p q : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ UL.Simplex K) (hq : q ∈ UL.Simplex K)
    (habs : ∀ j : Fin K, q j = 0 → p j = 0) :
    ‖p - q‖ ^ 2 ≤ ∑ j : Fin K, (p j * Real.log (p j) - p j * Real.log (q j)) := by
  let w : Fin K → ℝ := fun j => (2 * p j + 4 * q j) / 3
  let d : Fin K → ℝ := fun j => p j * Real.log (p j) - p j * Real.log (q j) - p j + q j
  have hw_nn : ∀ j : Fin K, 0 ≤ w j := fun j => by
    dsimp [w]
    linarith [hp.1 j, hq.1 j]
  have hd_nn : ∀ j : Fin K, 0 ≤ d j := fun j =>
    (kpt_two_var_ineq (hp.1 j) (hq.1 j) (habs j)).2
  have hterm : ∀ j : Fin K, |(p - q) j| ≤ Real.sqrt (w j) * Real.sqrt (d j) := by
    intro j
    rw [PiLp.sub_apply]
    have hkpt := (kpt_two_var_ineq (hp.1 j) (hq.1 j) (habs j)).1
    have hsq : (p j - q j) ^ 2 ≤ w j * d j := by
      dsimp [w, d]
      linarith
    calc |p j - q j|
        = Real.sqrt ((p j - q j) ^ 2) := (Real.sqrt_sq_eq_abs _).symm
      _ ≤ Real.sqrt (w j * d j) := Real.sqrt_le_sqrt hsq
      _ = Real.sqrt (w j) * Real.sqrt (d j) := Real.sqrt_mul (hw_nn j) (d j)
  have hcs : ∑ j : Fin K, |(p - q) j| ≤
      Real.sqrt (∑ j : Fin K, w j) * Real.sqrt (∑ j : Fin K, d j) :=
    (Finset.sum_le_sum fun j _ => hterm j).trans (Real.sum_sqrt_mul_sqrt_le Finset.univ hw_nn hd_nn)
  have hl1_nn : 0 ≤ ∑ j : Fin K, |(p - q) j| :=
    Finset.sum_nonneg fun j _ => abs_nonneg _
  have hl1_sq : (∑ j : Fin K, |(p - q) j|) ^ 2 ≤ (∑ j : Fin K, w j) * (∑ j : Fin K, d j) := by
    have hpow : (∑ j : Fin K, |(p - q) j|) ^ 2 ≤
        (Real.sqrt (∑ j : Fin K, w j) * Real.sqrt (∑ j : Fin K, d j)) ^ 2 :=
      pow_le_pow_left₀ hl1_nn hcs 2
    rwa [mul_pow, Real.sq_sqrt (Finset.sum_nonneg fun j _ => hw_nn j),
      Real.sq_sqrt (Finset.sum_nonneg fun j _ => hd_nn j)] at hpow
  have hsum_w : ∑ j : Fin K, w j = 2 := by
    dsimp [w]
    simp only [← Finset.sum_div, Finset.sum_add_distrib, ← Finset.mul_sum, hp.2, hq.2]
    norm_num
  have hsum_d : ∑ j : Fin K, d j =
      ∑ j : Fin K, (p j * Real.log (p j) - p j * Real.log (q j)) := by
    dsimp [d]
    have h1 : ∑ j : Fin K, (p j * Real.log (p j) - p j * Real.log (q j) - p j + q j) =
        (∑ j : Fin K, (p j * Real.log (p j) - p j * Real.log (q j))) -
          (∑ j : Fin K, p j) + (∑ j : Fin K, q j) := by
      simp [Finset.sum_add_distrib, Finset.sum_sub_distrib]
    rw [h1, hp.2, hq.2]
    ring
  have hv_zero : ∑ j : Fin K, (p - q) j = 0 := by
    simp [Finset.sum_sub_distrib, hp.2, hq.2]
  have hl2 := two_mul_norm_sq_le_sum_abs_sq hv_zero
  rw [hsum_w, hsum_d] at hl1_sq
  linarith

/-! ### Private Helpers: Continuity, Face Gradients, and Matching Potential -/

private lemma continuous_shannonEntropy (K : ℕ) (T : ℝ) :
    Continuous (shannonEntropy K T) := by
  unfold shannonEntropy
  refine continuous_const.mul (continuous_finset_sum Finset.univ fun j _ => ?_)
  exact Real.continuous_mul_log.comp
    ((EuclideanSpace.proj j).continuous.comp continuous_subtype_val)

private noncomputable def shannonFaceMean (K : ℕ) (T : ℝ) (J : Finset (Fin K))
    (p : EuclideanSpace ℝ (Fin K)) : ℝ :=
  (∑ r ∈ J, T * (Real.log (p r) + 1)) / (J.card : ℝ)

private noncomputable def shannonFaceGrad (K : ℕ) (T : ℝ) (J : Finset (Fin K))
    (p : EuclideanSpace ℝ (Fin K)) : EuclideanSpace ℝ (Fin K) :=
  (WithLp.equiv 2 (Fin K → ℝ)).symm fun j =>
    if j ∈ J then T * (Real.log (p j) + 1) - shannonFaceMean K T J p else 0

@[simp]
private lemma shannonFaceGrad_apply (K : ℕ) (T : ℝ) (J : Finset (Fin K))
    (p : EuclideanSpace ℝ (Fin K)) (j : Fin K) :
    shannonFaceGrad K T J p j =
      if j ∈ J then T * (Real.log (p j) + 1) - shannonFaceMean K T J p else 0 :=
  rfl

private lemma hasFaceGradAt_shannonEntropy {K : ℕ} (T : ℝ) {J : Finset (Fin K)}
    (hJ : J.Nonempty) {p : EuclideanSpace ℝ (Fin K)} (hp : p ∈ UL.SimplexFaceRelint K J) :
    UL.HasFaceGradAt (shannonEntropy K T) J p (shannonFaceGrad K T J p) := by
  set c := shannonFaceMean K T J p
  set g := shannonFaceGrad K T J p
  have hg_mem : g ∈ UL.FaceTangentSpace K J := by
    rw [UL.Proof_lem_A_5.mem_faceTangentSpace_iff]
    refine ⟨?_, fun j hj => by simp [g, c, hj]⟩
    have hsub : ∑ j : Fin K, g j = ∑ j ∈ J, (T * (Real.log (p j) + 1) - c) := by
      rw [← Finset.sum_subset (Finset.subset_univ J) (fun j _ hj => by simp [g, c, hj])]
      exact Finset.sum_congr rfl fun j hj => by simp [g, c, hj]
    rw [hsub, Finset.sum_sub_distrib, Finset.sum_const, nsmul_eq_mul]
    have hcard_ne : (J.card : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr hJ.card_pos.ne'
    dsimp [c, shannonFaceMean]
    rw [mul_div_cancel₀ _ hcard_ne, sub_self]
  refine ⟨hg_mem, ?_⟩
  let π : Fin K → (EuclideanSpace ℝ (Fin K) →L[ℝ] ℝ) := fun j => EuclideanSpace.proj j
  let G : EuclideanSpace ℝ (Fin K) → ℝ :=
    fun q => (∑ j ∈ J, (T * (q j * Real.log (q j)) - c * q j)) + c
  have hG_fderiv : HasFDerivAt G (innerSL ℝ g) p := by
    have hterm : ∀ j ∈ J, HasFDerivAt
        ((fun x : ℝ => T * (x * Real.log x) - c * x) ∘ ⇑(π j))
        ((T * (Real.log (p j) + 1) - c) • π j) p := by
      intro j hj
      have hpj_ne : p j ≠ 0 := (hp.2 j hj).ne'
      have hd1 : HasDerivAt (fun x : ℝ => T * (x * Real.log x) - c * x)
          (T * (Real.log (p j) + 1) - c) (p j) :=
        hasDerivAt_of_eq
          (((Real.hasDerivAt_mul_log hpj_ne).const_mul T).sub
            ((hasDerivAt_id' (p j)).const_mul c))
          (fun x => by simp)
          (by ring)
      exact hd1.comp_hasFDerivAt p ((π j).hasFDerivAt (x := p))
    refine hasFDerivAt_of_eq ((HasFDerivAt.sum hterm).add_const c)
      (fun q => by simp [G, Finset.sum_apply, π])
      (fun v => ?_)
    rw [innerSL_apply_apply, UL.Proof_lem_A_1.inner_eq_sum, ContinuousLinearMap.sum_apply]
    have hsub : ∑ j : Fin K, g j * v j =
        ∑ j ∈ J, (T * (Real.log (p j) + 1) - c) * v j := by
      rw [← Finset.sum_subset (Finset.subset_univ J) (fun j _ hj => by simp [g, c, hj])]
      exact Finset.sum_congr rfl fun j hj => by simp [g, c, hj]
    rw [hsub]
    refine Finset.sum_congr rfl fun j _ => ?_
    simp [π]
  have hG_eq : ∀ q ∈ UL.SimplexFace K J,
      UL.extendSimplex (shannonEntropy K T) q = G q := by
    intro q hq
    rw [UL.Proof_lem_A_5.extendSimplex_eq_of_mem (shannonEntropy K T) hq.1]
    unfold shannonEntropy
    dsimp [G]
    have h1 : ∑ j : Fin K, q j * Real.log (q j) = ∑ j ∈ J, q j * Real.log (q j) :=
      (Finset.sum_subset (Finset.subset_univ J) fun j _ hj => by rw [hq.2 j hj, zero_mul]).symm
    have h2 : ∑ j ∈ J, q j = 1 := by
      have hsub : ∑ j : Fin K, q j = ∑ j ∈ J, q j :=
        (Finset.sum_subset (Finset.subset_univ J) fun j _ hj => hq.2 j hj).symm
      linarith [hq.1.2]
    have h3 : ∑ j ∈ J, (T * (q j * Real.log (q j)) - c * q j) =
        T * (∑ j ∈ J, q j * Real.log (q j)) - c * (∑ j ∈ J, q j) := by
      rw [Finset.sum_sub_distrib, ← Finset.mul_sum, ← Finset.mul_sum]
    rw [h1, h3, h2]
    ring
  exact hG_fderiv.hasFDerivWithinAt.congr hG_eq (hG_eq p hp.1)

private lemma log_softmaxMap {K : ℕ} (hK : 1 ≤ K) (T : ℝ)
    (a : EuclideanSpace ℝ (Fin K)) (j : Fin K) :
    Real.log (softmaxMap K T a j) = a j / T - Real.log (∑ k : Fin K, Real.exp (a k / T)) := by
  rw [softmaxMap_apply, Real.log_div (Real.exp_pos _).ne' (sum_exp_div_pos hK T a).ne',
    Real.log_exp]

private lemma matchingPotential_shannon_eq {K : ℕ} (hK : 1 ≤ K) {T : ℝ} (hT : 0 < T)
    (a : EuclideanSpace ℝ (Fin K)) :
    UL.matchingPotential (shannonEntropy K T) a =
      T * Real.log (∑ k : Fin K, Real.exp (a k / T)) - inner ℝ (UL.uniformVec K) a := by
  set partitionSum := ∑ k : Fin K, Real.exp (a k / T)
  set qstar := softmaxMap K T a
  have hqstar_mem : qstar ∈ UL.Simplex K := softmaxMap_mem_simplex hK T a
  haveI : Nonempty (UL.Simplex K) := ⟨⟨qstar, hqstar_mem⟩⟩
  have hid : ∀ q : UL.Simplex K,
      inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) a - shannonEntropy K T q =
        (T * Real.log partitionSum - inner ℝ (UL.uniformVec K) a) -
          T * ∑ j : Fin K, (q.1 j * Real.log (q.1 j) - q.1 j * Real.log (qstar j)) := by
    intro q
    rw [inner_sub_left, UL.Proof_lem_A_1.inner_eq_sum]
    unfold shannonEntropy
    have hsum_a : ∑ j : Fin K, q.1 j * a j =
        T * (∑ j : Fin K, q.1 j * Real.log (qstar j)) + T * Real.log partitionSum := by
      have hpt : ∀ j : Fin K, q.1 j * a j =
          T * (q.1 j * Real.log (qstar j)) + q.1 j * (T * Real.log partitionSum) := by
        intro j
        have hlog := log_softmaxMap hK T a j
        change Real.log (qstar j) = a j / T - Real.log partitionSum at hlog
        have haj : a j = T * Real.log (qstar j) + T * Real.log partitionSum := by
          field_simp [hT.ne'] at hlog ⊢
          linarith
        rw [haj]
        ring
      calc ∑ j : Fin K, q.1 j * a j
          = ∑ j : Fin K, (T * (q.1 j * Real.log (qstar j)) + q.1 j * (T * Real.log partitionSum)) :=
            Finset.sum_congr rfl fun j _ => hpt j
        _ = T * (∑ j : Fin K, q.1 j * Real.log (qstar j)) +
              (∑ j : Fin K, q.1 j) * (T * Real.log partitionSum) := by
            rw [Finset.sum_add_distrib, ← Finset.mul_sum, ← Finset.sum_mul]
        _ = T * (∑ j : Fin K, q.1 j * Real.log (qstar j)) + T * Real.log partitionSum := by
            rw [q.2.2, one_mul]
    rw [hsum_a, Finset.sum_sub_distrib]
    ring
  unfold UL.matchingPotential
  refine le_antisymm ?_ ?_
  · refine ciSup_le fun q => ?_
    rw [hid q]
    have hkl : 0 ≤ ∑ j : Fin K, (q.1 j * Real.log (q.1 j) - q.1 j * Real.log (qstar j)) :=
      (sq_nonneg ‖q.1 - qstar‖).trans
        (norm_sub_sq_le_kl q.2 hqstar_mem fun j h0 =>
          absurd h0 (softmaxMap_pos hK T a j).ne')
    have hprod : 0 ≤ T * ∑ j : Fin K, (q.1 j * Real.log (q.1 j) - q.1 j * Real.log (qstar j)) :=
      mul_nonneg hT.le hkl
    linarith
  · have hle := le_ciSup
      (UL.Proof_cor_A_8.matchingPotential_bddAbove (continuous_shannonEntropy K T) a)
      ⟨qstar, hqstar_mem⟩
    rw [hid ⟨qstar, hqstar_mem⟩] at hle
    simp only [sub_self, Finset.sum_const_zero, mul_zero, sub_zero] at hle
    exact hle

private lemma hasGradientAt_matchingPotential_shannon {K : ℕ} (hK : 1 ≤ K) {T : ℝ} (hT : 0 < T)
    (a : EuclideanSpace ℝ (Fin K)) :
    HasGradientAt (UL.matchingPotential (shannonEntropy K T))
      (softmaxMap K T a - UL.uniformVec K) a := by
  rw [hasGradientAt_iff_hasFDerivAt]
  let π : Fin K → (EuclideanSpace ℝ (Fin K) →L[ℝ] ℝ) := fun k => EuclideanSpace.proj k
  let partitionSum : EuclideanSpace ℝ (Fin K) → ℝ := fun b => ∑ k : Fin K, Real.exp (b k / T)
  have hZ_pos : 0 < partitionSum a := sum_exp_div_pos hK T a
  have hZ_fderiv : HasFDerivAt partitionSum
      (∑ k : Fin K, (Real.exp (a k / T) / T) • π k) a := by
    have hsum : HasFDerivAt (∑ k ∈ (Finset.univ : Finset (Fin K)),
        (fun x : ℝ => Real.exp (x / T)) ∘ ⇑(π k))
        (∑ k ∈ (Finset.univ : Finset (Fin K)),
          (Real.exp (a k / T) / T) • π k) a := by
      refine HasFDerivAt.sum fun k _ => ?_
      have hd : HasDerivAt (fun x : ℝ => Real.exp (x / T)) (Real.exp (a k / T) / T) (a k) :=
        hasDerivAt_of_eq (((hasDerivAt_id' (a k)).div_const T).exp)
          (fun _ => rfl) (by ring)
      exact hd.comp_hasFDerivAt a ((π k).hasFDerivAt (x := a))
    exact hasFDerivAt_of_eq hsum (fun b => by simp [partitionSum, Finset.sum_apply, π]) (fun _ => rfl)
  have hlogZ := ((Real.hasDerivAt_log hZ_pos.ne').comp_hasFDerivAt a hZ_fderiv).const_mul T
  have hsub := hlogZ.sub ((innerSL ℝ (UL.uniformVec K)).hasFDerivAt (x := a))
  refine hasFDerivAt_of_eq hsub
    (fun b => by
      rw [matchingPotential_shannon_eq hK hT b]
      rfl)
    (fun v => ?_)
  rw [InnerProductSpace.toDual_apply_apply, inner_sub_left, UL.Proof_lem_A_1.inner_eq_sum]
  simp only [π, ContinuousLinearMap.sub_apply, ContinuousLinearMap.smul_apply,
    ContinuousLinearMap.sum_apply, innerSL_apply_apply, smul_eq_mul, softmaxMap_apply]
  change (∑ x : Fin K, (Real.exp (a x / T) / partitionSum a) * v x) - inner ℝ (UL.uniformVec K) v =
    T * ((partitionSum a)⁻¹ * ∑ x : Fin K, (Real.exp (a x / T) / T) * v x) - inner ℝ (UL.uniformVec K) v
  congr 1
  rw [Finset.mul_sum, Finset.mul_sum]
  refine Finset.sum_congr rfl fun k _ => ?_
  field_simp [hT.ne', hZ_pos.ne']

/-! ### Public Theorems -/

theorem shannonEntropy_mem_entropyFamily (K : ℕ) (hK : 2 ≤ K) {β : ℝ} (hβ : 0 < β) :
    shannonEntropy K (shannonTemp β) ∈ UL.EntropyFamily K β := by
  have _ := hK
  set T := shannonTemp β
  have hT : 0 < T := shannonTemp_pos hβ
  refine ⟨hβ, continuous_shannonEntropy K T,
    fun J hJ p hp => ⟨shannonFaceGrad K T J p, hasFaceGradAt_shannonEntropy T hJ hp⟩, ?_⟩
  refine ⟨UL.Proof_lem_A_5.convex_simplex K, fun x hx y hy a b ha hb hab => ?_⟩
  dsimp only
  simp only [smul_eq_mul]
  rcases eq_or_lt_of_le ha with rfl | ha_pos
  · have hb1 : b = 1 := by linarith
    subst hb1
    simp
  · rcases eq_or_lt_of_le hb with rfl | hb_pos
    · have ha1 : a = 1 := by linarith
      subst ha1
      simp
    · set m := a • x + b • y
      set u := UL.uniformVec K
      have hm : m ∈ UL.Simplex K := UL.Proof_lem_A_5.convex_simplex K hx hy ha hb hab
      have hx_abs : ∀ j : Fin K, m j = 0 → x j = 0 := by
        intro j hmj
        simp only [m, PiLp.add_apply, PiLp.smul_apply, smul_eq_mul] at hmj
        nlinarith [hx.1 j, hy.1 j]
      have hy_abs : ∀ j : Fin K, m j = 0 → y j = 0 := by
        intro j hmj
        simp only [m, PiLp.add_apply, PiLp.smul_apply, smul_eq_mul] at hmj
        nlinarith [hx.1 j, hy.1 j]
      have hkl_x := norm_sub_sq_le_kl hx hm hx_abs
      have hkl_y := norm_sub_sq_le_kl hy hm hy_abs
      have hjensen_rhs : a * UL.extendSimplex (shannonEntropy K T) x +
          b * UL.extendSimplex (shannonEntropy K T) y -
          UL.extendSimplex (shannonEntropy K T) m =
          T * (a * (∑ j : Fin K, (x j * Real.log (x j) - x j * Real.log (m j))) +
            b * (∑ j : Fin K, (y j * Real.log (y j) - y j * Real.log (m j)))) := by
        rw [UL.Proof_lem_A_5.extendSimplex_eq_of_mem _ hx,
          UL.Proof_lem_A_5.extendSimplex_eq_of_mem _ hy,
          UL.Proof_lem_A_5.extendSimplex_eq_of_mem _ hm]
        unfold shannonEntropy
        dsimp only
        have hm_sum : ∑ j : Fin K, m j * Real.log (m j) =
            a * (∑ j : Fin K, x j * Real.log (m j)) +
              b * (∑ j : Fin K, y j * Real.log (m j)) := by
          rw [ Finset.mul_sum, Finset.mul_sum, ← Finset.sum_add_distrib]
          refine Finset.sum_congr rfl fun j _ => ?_
          simp only [m, PiLp.add_apply, PiLp.smul_apply, smul_eq_mul]
          ring
        rw [Finset.sum_sub_distrib, Finset.sum_sub_distrib, hm_sum]
        ring
      have hnorm_id1 : a * ‖x - m‖ ^ 2 + b * ‖y - m‖ ^ 2 = a * b * ‖x - y‖ ^ 2 := by
        have hxm : x - m = b • (x - y) := by
          calc x - m = (a + b) • x - (a • x + b • y) := by rw [hab, one_smul]
            _ = b • (x - y) := by rw [add_smul, smul_sub]; abel
        have hym : y - m = -(a • (x - y)) := by
          calc y - m = (a + b) • y - (a • x + b • y) := by rw [hab, one_smul]
            _ = -(a • (x - y)) := by rw [add_smul, smul_sub]; abel
        rw [hxm, hym, norm_neg, norm_smul, norm_smul, Real.norm_eq_abs, Real.norm_eq_abs,
          abs_of_pos hb_pos, abs_of_pos ha_pos]
        calc a * (b * ‖x - y‖) ^ 2 + b * (a * ‖x - y‖) ^ 2
            = a * b * (a + b) * ‖x - y‖ ^ 2 := by ring
          _ = a * b * ‖x - y‖ ^ 2 := by rw [hab, mul_one]
      have hnorm_id2 : a * ‖x - u‖ ^ 2 + b * ‖y - u‖ ^ 2 - ‖m - u‖ ^ 2 =
          a * b * ‖x - y‖ ^ 2 := by
        set v := x - u
        set w := y - u
        have hcomb : m - u = a • v + b • w := by
          calc (a • x + b • y) - u = (a • x + b • y) - (a + b) • u := by rw [hab, one_smul]
            _ = a • v + b • w := by rw [add_smul, smul_sub, smul_sub]; abel
        have hvw : v - w = x - y := by dsimp [v, w]; abel
        have h1 : ‖a • v + b • w‖ ^ 2 =
            a ^ 2 * ‖v‖ ^ 2 + 2 * a * b * inner ℝ v w + b ^ 2 * ‖w‖ ^ 2 := by
          rw [norm_add_sq_real, norm_smul, norm_smul, Real.norm_eq_abs, Real.norm_eq_abs,
            abs_of_pos ha_pos, abs_of_pos hb_pos, inner_smul_left, inner_smul_right]
          simp only [conj_trivial]
          ring
        have h2 : ‖v - w‖ ^ 2 = ‖v‖ ^ 2 - 2 * inner ℝ v w + ‖w‖ ^ 2 := norm_sub_sq_real v w
        rw [hcomb, ← hvw]
        calc a * ‖v‖ ^ 2 + b * ‖w‖ ^ 2 - ‖a • v + b • w‖ ^ 2
            = a * (a + b) * ‖v‖ ^ 2 + b * (a + b) * ‖w‖ ^ 2 - ‖a • v + b • w‖ ^ 2 := by
                rw [hab]; ring
          _ = a * b * (‖v‖ ^ 2 - 2 * inner ℝ v w + ‖w‖ ^ 2) := by rw [h1]; ring
          _ = a * b * ‖v - w‖ ^ 2 := by rw [h2]
      have hcomb_ineq : T * (a * ‖x - u‖ ^ 2 + b * ‖y - u‖ ^ 2 - ‖m - u‖ ^ 2) ≤
          a * UL.extendSimplex (shannonEntropy K T) x +
            b * UL.extendSimplex (shannonEntropy K T) y -
            UL.extendSimplex (shannonEntropy K T) m := by
        rw [hnorm_id2, ← hnorm_id1, hjensen_rhs]
        exact mul_le_mul_of_nonneg_left
          (add_le_add (mul_le_mul_of_nonneg_left hkl_x ha) (mul_le_mul_of_nonneg_left hkl_y hb))
          hT.le
      change UL.extendSimplex (shannonEntropy K T) m - T * ‖m - u‖ ^ 2 ≤
        a * (UL.extendSimplex (shannonEntropy K T) x - T * ‖x - u‖ ^ 2) +
          b * (UL.extendSimplex (shannonEntropy K T) y - T * ‖y - u‖ ^ 2)
      linarith

theorem differentiable_matchingPotential_shannon (K : ℕ) (hK : 2 ≤ K) {β : ℝ} (hβ : 0 < β) :
    Differentiable ℝ (UL.matchingPotential (shannonEntropy K (shannonTemp β))) :=
  fun a => (hasGradientAt_matchingPotential_shannon (by omega) (shannonTemp_pos hβ) a).differentiableAt

theorem uniformVec_add_gradient_matchingPotential_shannon
    (K : ℕ) (hK : 2 ≤ K) {β : ℝ} (hβ : 0 < β) (a : EuclideanSpace ℝ (Fin K)) :
    UL.uniformVec K + gradient (UL.matchingPotential (shannonEntropy K (shannonTemp β))) a =
      softmaxMap K (shannonTemp β) a := by
  rw [(hasGradientAt_matchingPotential_shannon (by omega) (shannonTemp_pos hβ) a).gradient,
    add_sub_cancel]

theorem lipschitzWith_softmaxMap (K : ℕ) (hK : 2 ≤ K) {β : ℝ} (hβ : 0 < β) :
    LipschitzWith (Real.toNNReal β) (softmaxMap K (shannonTemp β)) := by
  have hK1 : 1 ≤ K := by omega
  set T := shannonTemp β
  have hT : 0 < T := shannonTemp_pos hβ
  rw [lipschitzWith_iff_dist_le_mul]
  intro a b
  rw [Real.coe_toNNReal β hβ.le, dist_eq_norm, dist_eq_norm]
  set p := softmaxMap K T a
  set q := softmaxMap K T b
  have hp : p ∈ UL.Simplex K := softmaxMap_mem_simplex hK1 T a
  have hq : q ∈ UL.Simplex K := softmaxMap_mem_simplex hK1 T b
  have hkl1 := norm_sub_sq_le_kl hp hq fun j h0 => absurd h0 (softmaxMap_pos hK1 T b j).ne'
  have hkl2 := norm_sub_sq_le_kl hq hp fun j h0 => absurd h0 (softmaxMap_pos hK1 T a j).ne'
  rw [norm_sub_rev] at hkl2
  have hsym : 2 * ‖p - q‖ ^ 2 ≤
      ∑ j : Fin K, (p j - q j) * (Real.log (p j) - Real.log (q j)) := by
    have hsum_eq : (∑ j : Fin K, (p j * Real.log (p j) - p j * Real.log (q j))) +
        (∑ j : Fin K, (q j * Real.log (q j) - q j * Real.log (p j))) =
        ∑ j : Fin K, (p j - q j) * (Real.log (p j) - Real.log (q j)) := by
      rw [← Finset.sum_add_distrib]
      exact Finset.sum_congr rfl fun j _ => by ring
    linarith
  have hrhs_eq : ∑ j : Fin K, (p j - q j) * (Real.log (p j) - Real.log (q j)) =
      2 * β * inner ℝ (p - q) (a - b) := by
    set Za := ∑ k : Fin K, Real.exp (a k / T)
    set Zb := ∑ k : Fin K, Real.exp (b k / T)
    have hlog_diff : ∀ j : Fin K,
        Real.log (p j) - Real.log (q j) =
          (1 / T) * (a j - b j) - (Real.log Za - Real.log Zb) := by
      intro j
      rw [log_softmaxMap hK1 T a j, log_softmaxMap hK1 T b j]
      change (a j / T - Real.log Za) - (b j / T - Real.log Zb) = _
      ring
    have h1 : ∑ j : Fin K, (p j - q j) * (Real.log (p j) - Real.log (q j)) =
        (1 / T) * (∑ j : Fin K, (p j - q j) * (a j - b j)) -
          (∑ j : Fin K, (p j - q j)) * (Real.log Za - Real.log Zb) := by
      calc ∑ j : Fin K, (p j - q j) * (Real.log (p j) - Real.log (q j))
          = ∑ j : Fin K, ((1 / T) * ((p j - q j) * (a j - b j)) -
              (p j - q j) * (Real.log Za - Real.log Zb)) := by
            refine Finset.sum_congr rfl fun j _ => ?_
            rw [hlog_diff j]
            ring
        _ = (1 / T) * (∑ j : Fin K, (p j - q j) * (a j - b j)) -
              (∑ j : Fin K, (p j - q j)) * (Real.log Za - Real.log Zb) := by
            rw [Finset.sum_sub_distrib, ← Finset.mul_sum, ← Finset.sum_mul]
    have hsum_pq : ∑ j : Fin K, (p j - q j) = 0 := by
      rw [Finset.sum_sub_distrib, hp.2, hq.2, sub_self]
    have h_inner : ∑ j : Fin K, (p j - q j) * (a j - b j) = inner ℝ (p - q) (a - b) := by
      rw [UL.Proof_lem_A_1.inner_eq_sum]
      rfl
    have hT_inv : 1 / T = 2 * β := by
      dsimp [T, shannonTemp]
      field_simp [hβ.ne']
    rw [h1, hsum_pq, zero_mul, sub_zero, h_inner, hT_inv]
  have hcs : inner ℝ (p - q) (a - b) ≤ ‖p - q‖ * ‖a - b‖ := real_inner_le_norm _ _
  have hsq_le : 2 * ‖p - q‖ ^ 2 ≤ 2 * β * (‖p - q‖ * ‖a - b‖) := by
    rw [hrhs_eq] at hsym
    exact hsym.trans (mul_le_mul_of_nonneg_left hcs (by positivity))
  by_cases hpq : ‖p - q‖ = 0
  · rw [hpq]
    positivity
  · have hpq_pos : 0 < ‖p - q‖ := lt_of_le_of_ne (norm_nonneg _) (Ne.symm hpq)
    nlinarith

theorem matchingLoss_shannon_zeroSum (K : ℕ) (hK : 2 ≤ K) {β : ℝ} (hβ : 0 < β)
    (a : UL.ZeroSumSubspace K) (y : Fin K) :
    UL.matchingLoss (shannonEntropy K (shannonTemp β)) (a : EuclideanSpace ℝ (Fin K)) y =
      -shannonTemp β * Real.log (softmaxMap K (shannonTemp β) (a : EuclideanSpace ℝ (Fin K)) y) := by
  have hK1 : 1 ≤ K := by omega
  set T := shannonTemp β
  have hT : 0 < T := shannonTemp_pos hβ
  have hu_orth : inner ℝ (UL.uniformVec K) (a : EuclideanSpace ℝ (Fin K)) = 0 := by
    have h1 : inner ℝ (UL.onesVec K) (a : EuclideanSpace ℝ (Fin K)) = 0 :=
      (UL.Proof_lem_A_1.mem_zeroSumSubspace_iff _).mp a.2
    unfold UL.uniformVec
    rw [inner_smul_left]
    simp [h1]
  unfold UL.matchingLoss
  rw [matchingPotential_shannon_eq hK1 hT, hu_orth, sub_zero, log_softmaxMap hK1 T _ y]
  field_simp [hT.ne']
  ring

theorem matchingLoss_shannon_zeroSum_nonneg (K : ℕ) (hK : 2 ≤ K) {β : ℝ} (hβ : 0 < β)
    (a : UL.ZeroSumSubspace K) (y : Fin K) :
    0 ≤ UL.matchingLoss (shannonEntropy K (shannonTemp β)) (a : EuclideanSpace ℝ (Fin K)) y := by
  rw [matchingLoss_shannon_zeroSum K hK hβ a y]
  have hK1 : 1 ≤ K := by omega
  set p := softmaxMap K (shannonTemp β) (a : EuclideanSpace ℝ (Fin K))
  have hp_pos : 0 < p y := softmaxMap_pos hK1 _ _ y
  have hp_mem : p ∈ UL.Simplex K := softmaxMap_mem_simplex hK1 _ _
  have hp_le_one : p y ≤ 1 := by
    rw [← hp_mem.2]
    exact Finset.single_le_sum (fun j _ => hp_mem.1 j) (Finset.mem_univ y)
  have hlog : Real.log (p y) ≤ 0 := Real.log_nonpos hp_pos.le hp_le_one
  have hT : 0 < shannonTemp β := shannonTemp_pos hβ
  nlinarith

theorem shannon_cond_bayes_opt (K : ℕ) (hK : 2 ≤ K) {β : ℝ} (hβ : 0 < β)
    (a₀ a : UL.ZeroSumSubspace K) :
    ∑ y : Fin K,
        softmaxMap K (shannonTemp β) (a₀ : EuclideanSpace ℝ (Fin K)) y *
          UL.matchingLoss (shannonEntropy K (shannonTemp β)) (a₀ : EuclideanSpace ℝ (Fin K)) y ≤
      ∑ y : Fin K,
        softmaxMap K (shannonTemp β) (a₀ : EuclideanSpace ℝ (Fin K)) y *
          UL.matchingLoss (shannonEntropy K (shannonTemp β)) (a : EuclideanSpace ℝ (Fin K)) y := by
  have hK1 : 1 ≤ K := by omega
  set T := shannonTemp β
  have hT : 0 < T := shannonTemp_pos hβ
  set η₀ := softmaxMap K T (a₀ : EuclideanSpace ℝ (Fin K))
  set η := softmaxMap K T (a : EuclideanSpace ℝ (Fin K))
  have hdiff : (∑ y : Fin K,
        η₀ y * UL.matchingLoss (shannonEntropy K T) (a : EuclideanSpace ℝ (Fin K)) y) -
      (∑ y : Fin K,
        η₀ y * UL.matchingLoss (shannonEntropy K T) (a₀ : EuclideanSpace ℝ (Fin K)) y) =
      T * ∑ y : Fin K, (η₀ y * Real.log (η₀ y) - η₀ y * Real.log (η y)) := by
    rw [← Finset.sum_sub_distrib, Finset.mul_sum]
    refine Finset.sum_congr rfl fun y _ => ?_
    rw [matchingLoss_shannon_zeroSum K hK hβ a y, matchingLoss_shannon_zeroSum K hK hβ a₀ y]
    change η₀ y * (-T * Real.log (η y)) - η₀ y * (-T * Real.log (η₀ y)) =
      T * (η₀ y * Real.log (η₀ y) - η₀ y * Real.log (η y))
    ring
  have hkl : 0 ≤ ∑ y : Fin K, (η₀ y * Real.log (η₀ y) - η₀ y * Real.log (η y)) :=
    (sq_nonneg ‖η₀ - η‖).trans
      (norm_sub_sq_le_kl (softmaxMap_mem_simplex hK1 T _) (softmaxMap_mem_simplex hK1 T _)
        fun y h0 => absurd h0 (softmaxMap_pos hK1 T _ y).ne')
  have hnn : 0 ≤ T * ∑ y : Fin K, (η₀ y * Real.log (η₀ y) - η₀ y * Real.log (η y)) :=
    mul_nonneg hT.le hkl
  linarith

theorem extendedCanonicalLoss_shannon_eq (K : ℕ) (hK : 2 ≤ K) {β : ℝ} (hβ : 0 < β)
    {p : EuclideanSpace ℝ (Fin K)} (hp : p ∈ UL.Simplex K) (y : Fin K) :
    UL.extendedCanonicalLoss (shannonEntropy K (shannonTemp β)) p y =
      if 0 < p y then ((-shannonTemp β * Real.log (p y) : ℝ) : EReal) else ⊤ := by
  have _ := hK
  have _ := hβ
  set T := shannonTemp β
  set J := UL.posSupport p
  unfold UL.extendedCanonicalLoss
  change (if y ∈ J then _ else ⊤) = _
  by_cases hy : 0 < p y
  · have hyJ : y ∈ J := (UL.Proof_lem_A_1.mem_posSupport_iff p y).mpr hy
    rw [if_pos hyJ, if_pos hy]
    congr 1
    have hJ : J.Nonempty := UL.Proof_lem_A_1.posSupport_nonempty hp
    have hp_rel : p ∈ UL.SimplexFaceRelint K J := UL.Proof_lem_A_1.mem_simplexFaceRelint_posSupport hp
    have hfg : UL.faceGrad (shannonEntropy K T) J p = shannonFaceGrad K T J p :=
      UL.Proof_cor_A_8.faceGrad_eq_of_hasFaceGradAt hJ hp_rel (hasFaceGradAt_shannonEntropy T hJ hp_rel)
    rw [hfg, inner_sub_right, UL.Proof_lem_A_1.inner_single_right,
      shannonFaceGrad_apply, if_pos hyJ]
    set c := shannonFaceMean K T J p
    have hgp : inner ℝ (shannonFaceGrad K T J p) p =
        UL.extendSimplex (shannonEntropy K T) p + T - c := by
      rw [UL.Proof_lem_A_1.inner_eq_sum,
        UL.Proof_lem_A_5.extendSimplex_eq_of_mem (shannonEntropy K T) hp]
      unfold shannonEntropy
      have hterm : ∀ j : Fin K,
          shannonFaceGrad K T J p j * p j =
            T * (p j * Real.log (p j)) + (T - c) * p j := by
        intro j
        rw [shannonFaceGrad_apply]
        by_cases hj : j ∈ J
        · rw [if_pos hj]
          ring
        · have hpj0 : p j = 0 := UL.Proof_lem_A_1.eq_zero_of_not_mem_posSupport hp hj
          rw [if_neg hj, hpj0]
          ring
      calc ∑ j : Fin K, shannonFaceGrad K T J p j * p j
          = ∑ j : Fin K, (T * (p j * Real.log (p j)) + (T - c) * p j) :=
            Finset.sum_congr rfl fun j _ => hterm j
        _ = T * (∑ j : Fin K, p j * Real.log (p j)) + (T - c) * (∑ j : Fin K, p j) := by
            rw [Finset.sum_add_distrib, ← Finset.mul_sum, ← Finset.mul_sum]
        _ = T * (∑ j : Fin K, p j * Real.log (p j)) + T - c := by
            rw [hp.2]
            ring
    rw [hgp]
    ring
  · have hyJ : y ∉ J := fun hmem => hy ((UL.Proof_lem_A_1.mem_posSupport_iff p y).mp hmem)
    rw [if_neg hyJ, if_neg hy]

theorem extendedCanonicalLoss_shannon_nonneg (K : ℕ) (hK : 2 ≤ K) {β : ℝ} (hβ : 0 < β)
    {p : EuclideanSpace ℝ (Fin K)} (hp : p ∈ UL.Simplex K) (y : Fin K) :
    0 ≤ UL.extendedCanonicalLoss (shannonEntropy K (shannonTemp β)) p y := by
  rw [extendedCanonicalLoss_shannon_eq K hK hβ hp y]
  split_ifs with hy
  · rw [EReal.coe_nonneg]
    have hp_le_one : p y ≤ 1 := by
      rw [← hp.2]
      exact Finset.single_le_sum (fun j _ => hp.1 j) (Finset.mem_univ y)
    have hlog : Real.log (p y) ≤ 0 := Real.log_nonpos hy.le hp_le_one
    have hT : 0 < shannonTemp β := shannonTemp_pos hβ
    nlinarith
  · exact le_top

theorem shannon_pointwise_ennreal_gap (K : ℕ) (hK : 2 ≤ K) {β : ℝ} (hβ : 0 < β)
    (a₀ : UL.ZeroSumSubspace K) {q : EuclideanSpace ℝ (Fin K)} (hq : q ∈ UL.Simplex K) :
    let η₀ := softmaxMap K (shannonTemp β) (a₀ : EuclideanSpace ℝ (Fin K))
    ENNReal.ofReal
        (∑ y : Fin K, η₀ y *
          UL.matchingLoss (shannonEntropy K (shannonTemp β)) (a₀ : EuclideanSpace ℝ (Fin K)) y) +
      ENNReal.ofReal (shannonTemp β * ‖η₀ - q‖ ^ 2) ≤
      ∑ y : Fin K,
        ENNReal.ofReal (η₀ y) *
          (UL.extendedCanonicalLoss (shannonEntropy K (shannonTemp β)) q y).toENNReal := by
  dsimp only
  have hK1 : 1 ≤ K := by omega
  set T := shannonTemp β
  have hT : 0 < T := shannonTemp_pos hβ
  set η₀ := softmaxMap K T (a₀ : EuclideanSpace ℝ (Fin K))
  by_cases hq_pos : ∀ y : Fin K, 0 < q y
  · have hrhs : ∑ y : Fin K,
        ENNReal.ofReal (η₀ y) *
          (UL.extendedCanonicalLoss (shannonEntropy K T) q y).toENNReal =
        ENNReal.ofReal (∑ y : Fin K, η₀ y * (-T * Real.log (q y))) := by
      have hterm : ∀ y : Fin K,
          ENNReal.ofReal (η₀ y) *
            (UL.extendedCanonicalLoss (shannonEntropy K T) q y).toENNReal =
          ENNReal.ofReal (η₀ y * (-T * Real.log (q y))) := by
        intro y
        rw [extendedCanonicalLoss_shannon_eq K hK hβ hq y, if_pos (hq_pos y),
          EReal.toENNReal_of_ne_top (EReal.coe_ne_top _), EReal.toReal_coe,
          ← ENNReal.ofReal_mul (softmaxMap_pos hK1 T _ y).le]
      calc ∑ y : Fin K,
            ENNReal.ofReal (η₀ y) *
              (UL.extendedCanonicalLoss (shannonEntropy K T) q y).toENNReal
          = ∑ y : Fin K, ENNReal.ofReal (η₀ y * (-T * Real.log (q y))) :=
            Finset.sum_congr rfl fun y _ => hterm y
        _ = ENNReal.ofReal (∑ y : Fin K, η₀ y * (-T * Real.log (q y))) := by
            refine (ENNReal.ofReal_sum_of_nonneg fun y _ => ?_).symm
            have hqy_le : q y ≤ 1 := by
              rw [← hq.2]
              exact Finset.single_le_sum (fun j _ => hq.1 j) (Finset.mem_univ y)
            exact mul_nonneg (softmaxMap_pos hK1 T _ y).le
              (by nlinarith [Real.log_nonpos (hq_pos y).le hqy_le])
    have hlhs1_nn : 0 ≤ ∑ y : Fin K, η₀ y *
        UL.matchingLoss (shannonEntropy K T) (a₀ : EuclideanSpace ℝ (Fin K)) y :=
      Finset.sum_nonneg fun y _ => mul_nonneg (softmaxMap_pos hK1 T _ y).le
        (matchingLoss_shannon_zeroSum_nonneg K hK hβ a₀ y)
    have hlhs2_nn : 0 ≤ T * ‖η₀ - q‖ ^ 2 := mul_nonneg hT.le (sq_nonneg _)
    rw [hrhs, ← ENNReal.ofReal_add hlhs1_nn hlhs2_nn]
    refine ENNReal.ofReal_le_ofReal ?_
    have hlhs1_eq : ∑ y : Fin K, η₀ y *
        UL.matchingLoss (shannonEntropy K T) (a₀ : EuclideanSpace ℝ (Fin K)) y =
        ∑ y : Fin K, η₀ y * (-T * Real.log (η₀ y)) :=
      Finset.sum_congr rfl fun y _ => by rw [matchingLoss_shannon_zeroSum K hK hβ a₀ y]
    rw [hlhs1_eq]
    have hdiff : (∑ y : Fin K, η₀ y * (-T * Real.log (q y))) -
        (∑ y : Fin K, η₀ y * (-T * Real.log (η₀ y))) =
        T * ∑ y : Fin K, (η₀ y * Real.log (η₀ y) - η₀ y * Real.log (q y)) := by
      rw [← Finset.sum_sub_distrib, Finset.mul_sum]
      exact Finset.sum_congr rfl fun y _ => by ring
    have hkl : T * ‖η₀ - q‖ ^ 2 ≤
        T * ∑ y : Fin K, (η₀ y * Real.log (η₀ y) - η₀ y * Real.log (q y)) :=
      mul_le_mul_of_nonneg_left
        (norm_sub_sq_le_kl (softmaxMap_mem_simplex hK1 T (a₀ : EuclideanSpace ℝ (Fin K))) hq
          fun y h0 => absurd h0 (hq_pos y).ne')
        hT.le
    linarith
  · push_neg at hq_pos
    obtain ⟨y₀, hy₀⟩ := hq_pos
    have hy₀_not : ¬ (0 < q y₀) := not_lt.mpr hy₀
    have hterm_top : ENNReal.ofReal (η₀ y₀) *
        (UL.extendedCanonicalLoss (shannonEntropy K T) q y₀).toENNReal = ⊤ := by
      rw [extendedCanonicalLoss_shannon_eq K hK hβ hq y₀, if_neg hy₀_not, EReal.toENNReal_top]
      have hne : ENNReal.ofReal (η₀ y₀) ≠ 0 :=
        (ENNReal.ofReal_pos.mpr (softmaxMap_pos hK1 T _ y₀)).ne'
      exact ENNReal.mul_top hne
    have hrhs_top : ⊤ ≤ ∑ y : Fin K,
        ENNReal.ofReal (η₀ y) *
          (UL.extendedCanonicalLoss (shannonEntropy K T) q y).toENNReal := by
      rw [← hterm_top]
      exact Finset.single_le_sum
        (f := fun y : Fin K =>
          ENNReal.ofReal (η₀ y) *
            (UL.extendedCanonicalLoss (shannonEntropy K T) q y).toENNReal)
        (fun _ _ => zero_le _) (Finset.mem_univ y₀)
    exact le_top.trans hrhs_top

end UL.Proof_thm_E_1

import Mathlib
import UL.Proof.thm_E_1.H0_Defs
import UL.Proof.cor_A_8.H1_SimplexGrad
import UL.Proof.lem_A_1.H1_FaceSubgrad
import UL.Proof.lem_A_5.H1_Simplex
import UL.Proof.lem_A_6.H3_RiskAndGap
set_option autoImplicit false

namespace UL.Proof_thm_E_1

open MeasureTheory

private lemma ballUniformMeasure_isProb (m : ℕ) {L : ℝ} (hL : 0 < L) :
    IsProbabilityMeasure (ballUniformMeasure m L) := by
  unfold ballUniformMeasure
  exact ProbabilityTheory.cond_isProbabilityMeasure_of_finite
    (Metric.measure_ball_pos volume (0 : EuclideanSpace ℝ (Fin m)) hL).ne'
    measure_ball_lt_top.ne

private lemma measurable_eta_ofReal {m K : ℕ}
    {η : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin K)}
    (hη_cont : Continuous η) (y : Fin K) :
    Measurable (fun x => ENNReal.ofReal (η x y)) :=
  ENNReal.measurable_ofReal.comp (((EuclideanSpace.proj y).continuous.comp hη_cont).measurable)

private lemma measurable_into_euclideanSpace {α : Type*} [MeasurableSpace α] {K : ℕ}
    {q : α → EuclideanSpace ℝ (Fin K)}
    (hq : ∀ j : Fin K, Measurable (fun x => q x j)) :
    Measurable q := by
  have h_eq : q = fun x => ∑ j : Fin K, (q x j) • EuclideanSpace.single j (1 : ℝ) := by
    funext x
    exact (UL.Proof_lem_A_1.sum_smul_single (q x)).symm
  rw [h_eq]
  exact Finset.measurable_sum Finset.univ (fun j _ => (hq j).smul_const _)

theorem jointMeasureP_fst_eq (m K : ℕ) {L : ℝ} (_hL : 0 < L)
    {η : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin K)}
    (hη_cont : Continuous η) (hη_simp : ∀ x, η x ∈ UL.Simplex K) :
    (jointMeasureP m K L η).fst = ballUniformMeasure m L := by
  ext A hA
  rw [Measure.fst_apply hA]
  unfold jointMeasureP
  rw [Measure.coe_finset_sum, Finset.sum_apply]
  have hterm : ∀ y : Fin K,
      (((ballUniformMeasure m L).withDensity (fun x => ENNReal.ofReal (η x y))).map
        (fun x => (x, y))) (Prod.fst ⁻¹' A) =
        ∫⁻ x in A, ENNReal.ofReal (η x y) ∂(ballUniformMeasure m L) := by
    intro y
    have hmap : Measurable (fun x : EuclideanSpace ℝ (Fin m) => (x, y)) :=
      measurable_id.prodMk measurable_const
    rw [Measure.map_apply hmap (measurable_fst hA)]
    have hpre : (fun x : EuclideanSpace ℝ (Fin m) => (x, y)) ⁻¹' (Prod.fst ⁻¹' A) = A := rfl
    rw [hpre, withDensity_apply _ hA]
  simp_rw [hterm]
  rw [← lintegral_finset_sum Finset.univ
    (fun y _ => measurable_eta_ofReal hη_cont y)]
  have hsum_one : ∀ x : EuclideanSpace ℝ (Fin m),
      ∑ y : Fin K, ENNReal.ofReal (η x y) = 1 := by
    intro x
    rw [← ENNReal.ofReal_sum_of_nonneg (fun y _ => (hη_simp x).1 y), (hη_simp x).2,
      ENNReal.ofReal_one]
  simp_rw [hsum_one]
  exact setLIntegral_one A

theorem jointMeasureP_isProb (m K : ℕ) (_hm : 1 ≤ m) {L : ℝ} (hL : 0 < L)
    {η : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin K)}
    (hη_cont : Continuous η) (hη_simp : ∀ x, η x ∈ UL.Simplex K) :
    MeasureTheory.IsProbabilityMeasure (jointMeasureP m K L η) := by
  haveI : IsProbabilityMeasure (ballUniformMeasure m L) := ballUniformMeasure_isProb m hL
  refine ⟨?_⟩
  rw [← Measure.fst_univ, jointMeasureP_fst_eq m K hL hη_cont hη_simp]
  exact measure_univ

theorem jointMeasureP_isUniform (m K : ℕ) {L : ℝ} (hL : 0 < L)
    {η : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin K)}
    (hη_cont : Continuous η) (hη_simp : ∀ x, η x ∈ UL.Simplex K) :
    MeasureTheory.pdf.IsUniform Prod.fst (Metric.ball (0 : EuclideanSpace ℝ (Fin m)) L)
      (jointMeasureP m K L η) MeasureTheory.volume :=
  jointMeasureP_fst_eq m K hL hη_cont hη_simp

theorem integrable_norm_ballUniformMeasure (m : ℕ) (_hm : 1 ≤ m) {L : ℝ} (hL : 0 < L) :
    MeasureTheory.Integrable (fun x : EuclideanSpace ℝ (Fin m) => ‖x‖)
      (ballUniformMeasure m L) := by
  haveI : IsProbabilityMeasure (ballUniformMeasure m L) := ballUniformMeasure_isProb m hL
  have h_ae_mem : ∀ᵐ x ∂(ballUniformMeasure m L),
      x ∈ Metric.ball (0 : EuclideanSpace ℝ (Fin m)) L :=
    ProbabilityTheory.ae_cond_mem measurableSet_ball
  have h_ae_bdd : ∀ᵐ x ∂(ballUniformMeasure m L), ‖‖x‖‖ ≤ L := by
    filter_upwards [h_ae_mem] with x hx
    rw [Real.norm_eq_abs, abs_of_nonneg (norm_nonneg x)]
    exact (mem_ball_zero_iff.mp hx).le
  exact (memLp_top_of_bound continuous_norm.aestronglyMeasurable L h_ae_bdd).integrable le_top

theorem jointMeasureP_prod_singleton (m K : ℕ) {L : ℝ} (_hL : 0 < L)
    {η : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin K)}
    (_hη_cont : Continuous η) (_hη_simp : ∀ x, η x ∈ UL.Simplex K)
    (A : Set (EuclideanSpace ℝ (Fin m))) (hA : MeasurableSet A) (y : Fin K) :
    jointMeasureP m K L η (A ×ˢ {y}) =
      ∫⁻ x in A, ENNReal.ofReal (η x y) ∂(ballUniformMeasure m L) := by
  unfold jointMeasureP
  rw [Measure.coe_finset_sum, Finset.sum_apply]
  have hmeas_prod : MeasurableSet (A ×ˢ ({y} : Set (Fin K))) :=
    hA.prod (measurableSet_singleton y)
  rw [Finset.sum_eq_single y]
  · have hmap : Measurable (fun x : EuclideanSpace ℝ (Fin m) => (x, y)) :=
      measurable_id.prodMk measurable_const
    rw [Measure.map_apply hmap hmeas_prod]
    have hpre : (fun x : EuclideanSpace ℝ (Fin m) => (x, y)) ⁻¹' (A ×ˢ {y}) = A := by
      ext x
      simp
    rw [hpre, withDensity_apply _ hA]
  · intro y' _ hy'
    have hmap : Measurable (fun x : EuclideanSpace ℝ (Fin m) => (x, y')) :=
      measurable_id.prodMk measurable_const
    rw [Measure.map_apply hmap hmeas_prod]
    have hpre : (fun x : EuclideanSpace ℝ (Fin m) => (x, y')) ⁻¹' (A ×ˢ {y}) = ∅ := by
      ext x
      simp [hy']
    rw [hpre, measure_empty]
  · intro hy_abs
    exact False.elim (hy_abs (Finset.mem_univ y))

private lemma lintegral_jointMeasureP {m K : ℕ} (L : ℝ)
    {η : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin K)}
    (hη_cont : Continuous η)
    {F : EuclideanSpace ℝ (Fin m) × Fin K → ENNReal} (hF : Measurable F) :
    ∫⁻ z, F z ∂(jointMeasureP m K L η) =
      ∫⁻ x, (∑ y : Fin K, ENNReal.ofReal (η x y) * F (x, y)) ∂(ballUniformMeasure m L) := by
  unfold jointMeasureP
  rw [lintegral_finset_sum_measure]
  have hterm : ∀ y : Fin K,
      ∫⁻ z, F z ∂(((ballUniformMeasure m L).withDensity
        (fun x => ENNReal.ofReal (η x y))).map (fun x => (x, y))) =
      ∫⁻ x, ENNReal.ofReal (η x y) * F (x, y) ∂(ballUniformMeasure m L) := by
    intro y
    have hmap : Measurable (fun x : EuclideanSpace ℝ (Fin m) => (x, y)) :=
      measurable_id.prodMk measurable_const
    have hFy : Measurable (fun x : EuclideanSpace ℝ (Fin m) => F (x, y)) := hF.comp hmap
    rw [lintegral_map hF hmap,
      lintegral_withDensity_eq_lintegral_mul _ (measurable_eta_ofReal hη_cont y) hFy]
    rfl
  simp_rw [hterm]
  rw [← lintegral_finset_sum Finset.univ]
  intro y _
  exact (measurable_eta_ofReal hη_cont y).mul (hF.comp (measurable_id.prodMk measurable_const))

private lemma integrable_of_continuous_ballUniformMeasure {m : ℕ} {L : ℝ} (hL : 0 < L)
    {g : EuclideanSpace ℝ (Fin m) → ℝ} (hg_cont : Continuous g) :
    Integrable g (ballUniformMeasure m L) := by
  haveI : IsProbabilityMeasure (ballUniformMeasure m L) := ballUniformMeasure_isProb m hL
  obtain ⟨C, hC⟩ :=
    (isCompact_closedBall (0 : EuclideanSpace ℝ (Fin m)) L).exists_bound_of_continuousOn
      hg_cont.continuousOn
  have h_ae_mem : ∀ᵐ x ∂(ballUniformMeasure m L),
      x ∈ Metric.ball (0 : EuclideanSpace ℝ (Fin m)) L :=
    ProbabilityTheory.ae_cond_mem measurableSet_ball
  have h_ae_bdd : ∀ᵐ x ∂(ballUniformMeasure m L), ‖g x‖ ≤ C := by
    filter_upwards [h_ae_mem] with x hx
    exact hC x (Metric.ball_subset_closedBall hx)
  exact (memLp_top_of_bound hg_cont.aestronglyMeasurable C h_ae_bdd).integrable le_top

private lemma integrable_and_integral_jointMeasureP_of_continuous {m K : ℕ} {L : ℝ} (hL : 0 < L)
    {η : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin K)}
    (hη_cont : Continuous η) (hη_simp : ∀ x, η x ∈ UL.Simplex K)
    {G : EuclideanSpace ℝ (Fin m) × Fin K → ℝ} (hG_cont : Continuous G) :
    Integrable G (jointMeasureP m K L η) ∧
      ∫ z, G z ∂(jointMeasureP m K L η) =
        ∫ x, (∑ y : Fin K, η x y * G (x, y)) ∂(ballUniformMeasure m L) := by
  let μ₀ := ballUniformMeasure m L
  have h_comp_int : ∀ y : Fin K,
      Integrable (fun x => η x y * G (x, y)) μ₀ := by
    intro y
    refine integrable_of_continuous_ballUniformMeasure hL ?_
    exact ((EuclideanSpace.proj y).continuous.comp hη_cont).mul
      (hG_cont.comp (continuous_id.prodMk continuous_const))
  have h_wd_int : ∀ y : Fin K,
      Integrable (fun x => G (x, y)) (μ₀.withDensity (fun x => ENNReal.ofReal (η x y))) := by
    intro y
    rw [integrable_withDensity_iff (measurable_eta_ofReal hη_cont y)
      (Filter.Eventually.of_forall fun _ => ENNReal.ofReal_lt_top)]
    refine (h_comp_int y).congr (Filter.Eventually.of_forall fun x => ?_)
    dsimp only
    rw [ENNReal.toReal_ofReal ((hη_simp x).1 y), mul_comm]
  have h_map_int : ∀ y : Fin K,
      Integrable G ((μ₀.withDensity (fun x => ENNReal.ofReal (η x y))).map (fun x => (x, y))) := by
    intro y
    have hmap : Measurable (fun x : EuclideanSpace ℝ (Fin m) => (x, y)) :=
      measurable_id.prodMk measurable_const
    exact (integrable_map_measure hG_cont.aestronglyMeasurable hmap.aemeasurable).mpr (h_wd_int y)
  have hG_int : Integrable G (jointMeasureP m K L η) := by
    unfold jointMeasureP
    exact integrable_finset_sum_measure.mpr (fun y _ => h_map_int y)
  refine ⟨hG_int, ?_⟩
  unfold jointMeasureP
  rw [integral_finset_sum_measure (fun y _ => h_map_int y)]
  have hterm : ∀ y : Fin K,
      ∫ z, G z ∂((μ₀.withDensity (fun x => ENNReal.ofReal (η x y))).map (fun x => (x, y))) =
        ∫ x, η x y * G (x, y) ∂μ₀ := by
    intro y
    have hmap : Measurable (fun x : EuclideanSpace ℝ (Fin m) => (x, y)) :=
      measurable_id.prodMk measurable_const
    rw [integral_map hmap.aemeasurable hG_cont.aestronglyMeasurable,
      integral_withDensity_eq_integral_toReal_smul (measurable_eta_ofReal hη_cont y)
        (Filter.Eventually.of_forall fun _ => ENNReal.ofReal_lt_top)]
    refine integral_congr_ae (Filter.Eventually.of_forall fun x => ?_)
    dsimp only [smul_eq_mul]
    rw [ENNReal.toReal_ofReal ((hη_simp x).1 y)]
  simp_rw [hterm]
  rw [← integral_finset_sum Finset.univ (fun y _ => h_comp_int y)]

private lemma continuous_matchingLoss_y (K : ℕ) (hK : 1 ≤ K) {β : ℝ}
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.EntropyFamily K β)
    (V : EuclideanSpace ℝ (Fin (K - 1)) →L[ℝ] UL.ZeroSumSubspace K) (y : Fin K) :
    Continuous (fun x : EuclideanSpace ℝ (Fin (K - 1)) => UL.matchingLoss Φ (V x) y) := by
  have hV : Continuous (fun x : EuclideanSpace ℝ (Fin (K - 1)) =>
      ((V x : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))) :=
    continuous_subtype_val.comp V.continuous
  have h1 : Continuous (fun x : EuclideanSpace ℝ (Fin (K - 1)) =>
      UL.matchingPotential Φ ((V x : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))) :=
    (UL.Proof_cor_A_8.continuous_matchingPotential hK hΦ.2.1).comp hV
  have h2 : Continuous (fun x : EuclideanSpace ℝ (Fin (K - 1)) =>
      ((V x : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) y) :=
    (EuclideanSpace.proj y).continuous.comp hV
  exact h1.sub h2

private lemma continuous_matchingLoss_comp (K : ℕ) (hK : 1 ≤ K) {β : ℝ}
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.EntropyFamily K β)
    (V : EuclideanSpace ℝ (Fin (K - 1)) →L[ℝ] UL.ZeroSumSubspace K) :
    Continuous (fun z : EuclideanSpace ℝ (Fin (K - 1)) × Fin K => UL.matchingLoss Φ (V z.1) z.2) := by
  rw [continuous_prod_of_discrete_right]
  exact continuous_matchingLoss_y K hK hΦ V

theorem integrable_matchingLoss_jointMeasureP (K : ℕ) (hK : 3 ≤ K) {β L : ℝ} (hL : 0 < L)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.EntropyFamily K β)
    {η : EuclideanSpace ℝ (Fin (K - 1)) → EuclideanSpace ℝ (Fin K)}
    (hη_cont : Continuous η) (hη_simp : ∀ x, η x ∈ UL.Simplex K)
    (V : EuclideanSpace ℝ (Fin (K - 1)) →L[ℝ] UL.ZeroSumSubspace K) :
    MeasureTheory.Integrable
      (fun z : EuclideanSpace ℝ (Fin (K - 1)) × Fin K => UL.matchingLoss Φ (V z.1) z.2)
      (jointMeasureP (K - 1) K L η) :=
  (integrable_and_integral_jointMeasureP_of_continuous hL hη_cont hη_simp
    (continuous_matchingLoss_comp K (by omega) hΦ V)).1

theorem linBench_eq_and_nonneg (K : ℕ) (hK : 3 ≤ K) {R β L : ℝ} (hL : 0 < L)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.EntropyFamily K β)
    {η : EuclideanSpace ℝ (Fin (K - 1)) → EuclideanSpace ℝ (Fin K)}
    (hη_cont : Continuous η) (hη_simp : ∀ x, η x ∈ UL.Simplex K)
    {V₀ : EuclideanSpace ℝ (Fin (K - 1)) →L[ℝ] UL.ZeroSumSubspace K}
    (hV₀_norm : Real.sqrt (∑ i : Fin (K - 1), ‖V₀ (EuclideanSpace.single i (1 : ℝ))‖ ^ 2) ≤ R)
    (h_bayes : ∀ (x : EuclideanSpace ℝ (Fin (K - 1))) (a : UL.ZeroSumSubspace K),
      ∑ y : Fin K, η x y * UL.matchingLoss Φ (V₀ x) y ≤
        ∑ y : Fin K, η x y * UL.matchingLoss Φ a y)
    (h_ml_nonneg : ∀ (x : EuclideanSpace ℝ (Fin (K - 1))) (y : Fin K),
      0 ≤ UL.matchingLoss Φ (V₀ x) y) :
    sInf ((fun V : EuclideanSpace ℝ (Fin (K - 1)) →L[ℝ] UL.ZeroSumSubspace K =>
        ∫ z, UL.matchingLoss Φ (V z.1) z.2 ∂(jointMeasureP (K - 1) K L η)) ''
      {V | Real.sqrt (∑ i : Fin (K - 1), ‖V (EuclideanSpace.single i (1 : ℝ))‖ ^ 2) ≤ R}) =
      ∫ z, UL.matchingLoss Φ (V₀ z.1) z.2 ∂(jointMeasureP (K - 1) K L η) ∧
    0 ≤ ∫ z, UL.matchingLoss Φ (V₀ z.1) z.2 ∂(jointMeasureP (K - 1) K L η) := by
  let P := jointMeasureP (K - 1) K L η
  let μ₀ := ballUniformMeasure (K - 1) L
  have hV_le : ∀ V : EuclideanSpace ℝ (Fin (K - 1)) →L[ℝ] UL.ZeroSumSubspace K,
      ∫ z, UL.matchingLoss Φ (V₀ z.1) z.2 ∂P ≤
        ∫ z, UL.matchingLoss Φ (V z.1) z.2 ∂P := by
    intro V
    rw [(integrable_and_integral_jointMeasureP_of_continuous hL hη_cont hη_simp
        (continuous_matchingLoss_comp K (by omega) hΦ V₀)).2,
      (integrable_and_integral_jointMeasureP_of_continuous hL hη_cont hη_simp
        (continuous_matchingLoss_comp K (by omega) hΦ V)).2]
    have h_int_V₀ : Integrable (fun x => ∑ y : Fin K, η x y * UL.matchingLoss Φ (V₀ x) y) μ₀ := by
      refine integrable_of_continuous_ballUniformMeasure hL ?_
      refine continuous_finset_sum Finset.univ (fun y _ => ?_)
      exact ((EuclideanSpace.proj y).continuous.comp hη_cont).mul
        (continuous_matchingLoss_y K (by omega) hΦ V₀ y)
    have h_int_V : Integrable (fun x => ∑ y : Fin K, η x y * UL.matchingLoss Φ (V x) y) μ₀ := by
      refine integrable_of_continuous_ballUniformMeasure hL ?_
      refine continuous_finset_sum Finset.univ (fun y _ => ?_)
      exact ((EuclideanSpace.proj y).continuous.comp hη_cont).mul
        (continuous_matchingLoss_y K (by omega) hΦ V y)
    exact integral_mono h_int_V₀ h_int_V (fun x => h_bayes x (V x))
  let S := (fun V : EuclideanSpace ℝ (Fin (K - 1)) →L[ℝ] UL.ZeroSumSubspace K =>
      ∫ z, UL.matchingLoss Φ (V z.1) z.2 ∂P) ''
    {V | Real.sqrt (∑ i : Fin (K - 1), ‖V (EuclideanSpace.single i (1 : ℝ))‖ ^ 2) ≤ R}
  have h_mem : (∫ z, UL.matchingLoss Φ (V₀ z.1) z.2 ∂P) ∈ S := ⟨V₀, hV₀_norm, rfl⟩
  have h_bdd : BddBelow S := by
    refine ⟨∫ z, UL.matchingLoss Φ (V₀ z.1) z.2 ∂P, ?_⟩
    rintro _ ⟨V, _, rfl⟩
    exact hV_le V
  refine ⟨le_antisymm (csInf_le h_bdd h_mem) ?_,
    integral_nonneg (fun z => h_ml_nonneg z.1 z.2)⟩
  refine le_csInf ⟨_, h_mem⟩ ?_
  rintro _ ⟨V, _, rfl⟩
  exact hV_le V

theorem expCanonicalLoss_eta_eq (K : ℕ) (hK : 3 ≤ K) {β L : ℝ} (hL : 0 < L)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.EntropyFamily K β)
    {η : EuclideanSpace ℝ (Fin (K - 1)) → EuclideanSpace ℝ (Fin K)}
    (hη_cont : Continuous η) (hη_simp : ∀ x, η x ∈ UL.Simplex K)
    (V₀ : EuclideanSpace ℝ (Fin (K - 1)) →L[ℝ] UL.ZeroSumSubspace K)
    (h_ecl_eta : ∀ (x : EuclideanSpace ℝ (Fin (K - 1))) (y : Fin K),
      UL.extendedCanonicalLoss Φ (η x) y = ((UL.matchingLoss Φ (V₀ x) y : ℝ) : EReal))
    (h_ml_nonneg : ∀ (x : EuclideanSpace ℝ (Fin (K - 1))) (y : Fin K),
      0 ≤ UL.matchingLoss Φ (V₀ x) y) :
    let P := jointMeasureP (K - 1) K L η
    ((∫ z, UL.matchingLoss Φ (V₀ z.1) z.2 ∂P : ℝ) : EReal) =
      ((∫⁻ z, (UL.extendedCanonicalLoss Φ (η z.1) z.2).toENNReal ∂P : ENNReal) : EReal) -
        ((∫⁻ z, (-UL.extendedCanonicalLoss Φ (η z.1) z.2).toENNReal ∂P : ENNReal) : EReal) := by
  intro P
  have h_neg_zero : ∀ z : EuclideanSpace ℝ (Fin (K - 1)) × Fin K,
      (-UL.extendedCanonicalLoss Φ (η z.1) z.2).toENNReal = 0 := by
    intro z
    rw [h_ecl_eta z.1 z.2, ← EReal.coe_neg]
    exact EReal.toENNReal_of_nonpos (EReal.coe_nonpos.mpr (neg_nonpos.mpr (h_ml_nonneg z.1 z.2)))
  have h_pos_eq : ∀ z : EuclideanSpace ℝ (Fin (K - 1)) × Fin K,
      (UL.extendedCanonicalLoss Φ (η z.1) z.2).toENNReal =
        ENNReal.ofReal (UL.matchingLoss Φ (V₀ z.1) z.2) := by
    intro z
    rw [h_ecl_eta z.1 z.2, EReal.real_coe_toENNReal]
  simp_rw [h_neg_zero, h_pos_eq, lintegral_zero, EReal.coe_ennreal_zero, sub_zero]
  have h_int : Integrable (fun z => UL.matchingLoss Φ (V₀ z.1) z.2) P :=
    integrable_matchingLoss_jointMeasureP K hK hL hΦ hη_cont hη_simp V₀
  rw [← ofReal_integral_eq_lintegral_ofReal h_int
      (Filter.Eventually.of_forall fun z => h_ml_nonneg z.1 z.2),
    EReal.coe_ennreal_ofReal, max_eq_left
      (integral_nonneg fun z => h_ml_nonneg z.1 z.2)]

theorem expCanonicalLoss_ge_linBench_add_l2 (K : ℕ) (hK : 3 ≤ K) {T β L : ℝ}
    (hT : 0 ≤ T) (hL : 0 < L)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.EntropyFamily K β)
    {η : EuclideanSpace ℝ (Fin (K - 1)) → EuclideanSpace ℝ (Fin K)}
    (hη_cont : Continuous η) (hη_simp : ∀ x, η x ∈ UL.Simplex K)
    (V₀ : EuclideanSpace ℝ (Fin (K - 1)) →L[ℝ] UL.ZeroSumSubspace K)
    (h_ecl_form : ∀ (p : EuclideanSpace ℝ (Fin K)), p ∈ UL.Simplex K → ∀ y : Fin K,
      UL.extendedCanonicalLoss Φ p y =
        if 0 < p y then ((-T * Real.log (p y) : ℝ) : EReal) else ⊤)
    (h_ml_nonneg : ∀ (x : EuclideanSpace ℝ (Fin (K - 1))) (y : Fin K),
      0 ≤ UL.matchingLoss Φ (V₀ x) y)
    (h_ptwise_gap : ∀ (x : EuclideanSpace ℝ (Fin (K - 1))) (q : EuclideanSpace ℝ (Fin K)),
      q ∈ UL.Simplex K →
      ENNReal.ofReal (∑ y : Fin K, η x y * UL.matchingLoss Φ (V₀ x) y) +
        ENNReal.ofReal (T * ‖η x - q‖ ^ 2) ≤
        ∑ y : Fin K, ENNReal.ofReal (η x y) * (UL.extendedCanonicalLoss Φ q y).toENNReal)
    {q : EuclideanSpace ℝ (Fin (K - 1)) → EuclideanSpace ℝ (Fin K)}
    (hq_meas : Measurable q) (hq_simp : ∀ x, q x ∈ UL.Simplex K) :
    let P := jointMeasureP (K - 1) K L η
    (((∫ z, UL.matchingLoss Φ (V₀ z.1) z.2 ∂P) +
        T * ∫ x, ‖η x - q x‖ ^ 2 ∂(ballUniformMeasure (K - 1) L) : ℝ) : EReal) ≤
      ((∫⁻ z, (UL.extendedCanonicalLoss Φ (q z.1) z.2).toENNReal ∂P : ENNReal) : EReal) -
        ((∫⁻ z, (-UL.extendedCanonicalLoss Φ (q z.1) z.2).toENNReal ∂P : ENNReal) : EReal) := by
  intro P
  let μ₀ := ballUniformMeasure (K - 1) L
  haveI : IsProbabilityMeasure μ₀ := ballUniformMeasure_isProb (K - 1) hL
  have h_neg_zero : ∀ z : EuclideanSpace ℝ (Fin (K - 1)) × Fin K,
      (-UL.extendedCanonicalLoss Φ (q z.1) z.2).toENNReal = 0 := by
    intro z
    rw [h_ecl_form (q z.1) (hq_simp z.1) z.2]
    split_ifs with hpos
    · rw [← EReal.coe_neg]
      have hq_le1 : q z.1 z.2 ≤ 1 := by
        rw [← (hq_simp z.1).2]
        exact Finset.single_le_sum (fun j _ => (hq_simp z.1).1 j) (Finset.mem_univ z.2)
      have hlog : Real.log (q z.1 z.2) ≤ 0 := Real.log_nonpos hpos.le hq_le1
      have hneg_le : -(-T * Real.log (q z.1 z.2)) ≤ 0 := by nlinarith
      exact EReal.toENNReal_of_nonpos (EReal.coe_nonpos.mpr hneg_le)
    · simp
  simp_rw [h_neg_zero, lintegral_zero, EReal.coe_ennreal_zero, sub_zero]
  let F : EuclideanSpace ℝ (Fin (K - 1)) × Fin K → ENNReal :=
    fun z => (UL.extendedCanonicalLoss Φ (q z.1) z.2).toENNReal
  have hF_meas : Measurable F := by
    have hF_eq : F = fun z =>
        if 0 < q z.1 z.2 then ENNReal.ofReal (-T * Real.log (q z.1 z.2)) else ⊤ := by
      funext z
      dsimp only [F]
      rw [h_ecl_form (q z.1) (hq_simp z.1) z.2]
      split_ifs with hpos
      · exact EReal.real_coe_toENNReal (-T * Real.log (q z.1 z.2))
      · exact EReal.toENNReal_top
    rw [hF_eq]
    have heval_cont : Continuous (fun p : EuclideanSpace ℝ (Fin K) × Fin K => p.1 p.2) := by
      rw [continuous_prod_of_discrete_right]
      exact fun y => (EuclideanSpace.proj y).continuous
    have hqz_meas : Measurable (fun z : EuclideanSpace ℝ (Fin (K - 1)) × Fin K => q z.1 z.2) :=
      heval_cont.measurable.comp ((hq_meas.comp measurable_fst).prodMk measurable_snd)
    refine Measurable.ite (measurableSet_lt measurable_const hqz_meas) ?_ measurable_const
    exact ENNReal.measurable_ofReal.comp
      (measurable_const.mul (Real.measurable_log.comp hqz_meas))
  have h_disint : ∫⁻ z, F z ∂P =
      ∫⁻ x, (∑ y : Fin K, ENNReal.ofReal (η x y) * F (x, y)) ∂μ₀ :=
    lintegral_jointMeasureP L hη_cont hF_meas
  let g₁ : EuclideanSpace ℝ (Fin (K - 1)) → ℝ :=
    fun x => ∑ y : Fin K, η x y * UL.matchingLoss Φ (V₀ x) y
  let g₂ : EuclideanSpace ℝ (Fin (K - 1)) → ℝ :=
    fun x => T * ‖η x - q x‖ ^ 2
  have hg₁_cont : Continuous g₁ := by
    refine continuous_finset_sum Finset.univ (fun y _ => ?_)
    exact ((EuclideanSpace.proj y).continuous.comp hη_cont).mul
      (continuous_matchingLoss_y K (by omega) hΦ V₀ y)
  have hg₁_int : Integrable g₁ μ₀ :=
    integrable_of_continuous_ballUniformMeasure hL hg₁_cont
  have hg₁_nn : ∀ x, 0 ≤ g₁ x := fun x =>
    Finset.sum_nonneg (fun y _ => mul_nonneg ((hη_simp x).1 y) (h_ml_nonneg x y))
  have hsq_meas : Measurable (fun x => ‖η x - q x‖ ^ 2) :=
    (((hη_cont.measurable.sub hq_meas).norm).pow_const 2)
  have hsq_int : Integrable (fun x => ‖η x - q x‖ ^ 2) μ₀ := by
    refine (memLp_top_of_bound hsq_meas.aestronglyMeasurable 4
      (Filter.Eventually.of_forall fun x => ?_)).integrable le_top
    rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
    have hdiff : ‖η x - q x‖ ≤ 2 := by
      calc ‖η x - q x‖
          ≤ ‖η x‖ + ‖q x‖ := norm_sub_le _ _
        _ ≤ 1 + 1 := add_le_add
            (UL.Proof_lem_A_5.norm_le_one_of_mem_simplex (hη_simp x))
            (UL.Proof_lem_A_5.norm_le_one_of_mem_simplex (hq_simp x))
        _ = 2 := by norm_num
    nlinarith [norm_nonneg (η x - q x)]
  have hg₂_int : Integrable g₂ μ₀ := hsq_int.const_mul T
  have hg₂_nn : ∀ x, 0 ≤ g₂ x := fun x => mul_nonneg hT (sq_nonneg _)
  have h_lin_le :
      (∫⁻ x, ENNReal.ofReal (g₁ x) ∂μ₀) + (∫⁻ x, ENNReal.ofReal (g₂ x) ∂μ₀) ≤
        ∫⁻ z, F z ∂P := by
    have hg₁_ofReal_meas : Measurable (fun x => ENNReal.ofReal (g₁ x)) :=
      ENNReal.measurable_ofReal.comp hg₁_cont.measurable
    rw [h_disint, ← lintegral_add_left hg₁_ofReal_meas]
    exact lintegral_mono (fun x => h_ptwise_gap x (q x) (hq_simp x))
  have h_part1 : ∫⁻ x, ENNReal.ofReal (g₁ x) ∂μ₀ =
      ENNReal.ofReal (∫ z, UL.matchingLoss Φ (V₀ z.1) z.2 ∂P) := by
    rw [← ofReal_integral_eq_lintegral_ofReal hg₁_int (Filter.Eventually.of_forall hg₁_nn),
      (integrable_and_integral_jointMeasureP_of_continuous hL hη_cont hη_simp
        (continuous_matchingLoss_comp K (by omega) hΦ V₀)).2]
  have h_part2 : ∫⁻ x, ENNReal.ofReal (g₂ x) ∂μ₀ =
      ENNReal.ofReal (T * ∫ x, ‖η x - q x‖ ^ 2 ∂μ₀) := by
    rw [← ofReal_integral_eq_lintegral_ofReal hg₂_int (Filter.Eventually.of_forall hg₂_nn)]
    dsimp only [g₂]
    rw [integral_const_mul]
  have hA_nn : 0 ≤ ∫ z, UL.matchingLoss Φ (V₀ z.1) z.2 ∂P :=
    integral_nonneg (fun z => h_ml_nonneg z.1 z.2)
  have hB_nn : 0 ≤ T * ∫ x, ‖η x - q x‖ ^ 2 ∂μ₀ :=
    mul_nonneg hT (integral_nonneg (fun _ => sq_nonneg _))
  rw [h_part1, h_part2, ← ENNReal.ofReal_add hA_nn hB_nn] at h_lin_le
  have h_ereal := EReal.coe_ennreal_le_coe_ennreal_iff.mpr h_lin_le
  rwa [EReal.coe_ennreal_ofReal,
    max_eq_left (add_nonneg hA_nn hB_nn)] at h_ereal

theorem separateLinkArchitectureAE_gap (K : ℕ) (hK : 3 ≤ K)
    (P : MeasureTheory.Measure (EuclideanSpace ℝ (Fin (K - 1)) × Fin K))
    (Φ : UL.Simplex K → ℝ) (linBench γ : ℝ) (hγ : 0 < γ)
    (h_ridge : ∀ p : EuclideanSpace ℝ (Fin (K - 1)) → EuclideanSpace ℝ (Fin K),
      Measurable p →
      (∀ x : EuclideanSpace ℝ (Fin (K - 1)), p x ∈ UL.Simplex K) →
      (∃ (j : Fin K) (a : EuclideanSpace ℝ (Fin (K - 1))) (f : ℝ → ℝ),
        Measurable f ∧
        (∀ t : ℝ, f t ∈ Set.Icc (0 : ℝ) 1) ∧
        (∀ᵐ x ∂P.fst, p x j = f (inner ℝ a x))) →
      ((linBench + γ : ℝ) : EReal) ≤
        ((∫⁻ z, (UL.extendedCanonicalLoss Φ (p z.1) z.2).toENNReal ∂P : ENNReal) : EReal) -
          ((∫⁻ z, (-UL.extendedCanonicalLoss Φ (p z.1) z.2).toENNReal ∂P : ENNReal) : EReal))
    (p : EuclideanSpace ℝ (Fin (K - 1)) → EuclideanSpace ℝ (Fin K))
    (hp : UL.HasSeparateLinkArchitectureAE P.fst p) :
    let expCanonicalLoss := fun q : EuclideanSpace ℝ (Fin (K - 1)) → EuclideanSpace ℝ (Fin K) =>
      ((∫⁻ z, (UL.extendedCanonicalLoss Φ (q z.1) z.2).toENNReal ∂P : ENNReal) : EReal) -
        ((∫⁻ z, (-UL.extendedCanonicalLoss Φ (q z.1) z.2).toENNReal ∂P : ENNReal) : EReal)
    ((linBench + γ : ℝ) : EReal) ≤ expCanonicalLoss p ∧
      ¬ (expCanonicalLoss p ≤ ((linBench : ℝ) : EReal)) := by
  classical
  intro expCanonicalLoss
  obtain ⟨q, ⟨_, a, r, hr, rfl, hq_simp_ae⟩, hpq_ae⟩ := hp
  set qMap := UL.separateLinkMap a r
  have hq_meas : Measurable qMap := by
    refine measurable_into_euclideanSpace (fun j => ?_)
    have h_coord : (fun x => qMap x j) =
        if hj : j.val < K - 1 then
          fun x => r ⟨j.val, hj⟩ (inner ℝ (a ⟨j.val, hj⟩) x)
        else
          fun x => 1 - ∑ i : Fin (K - 1), r i (inner ℝ (a i) x) := by
      funext x
      dsimp [qMap, UL.separateLinkMap]
      split_ifs <;> rfl
    rw [h_coord]
    split_ifs with hj
    · exact (hr ⟨j.val, hj⟩).1.comp ((innerSL ℝ (a ⟨j.val, hj⟩)).continuous.measurable)
    · refine measurable_const.sub ?_
      exact Finset.measurable_sum Finset.univ
        (fun i _ => (hr i).1.comp ((innerSL ℝ (a i)).continuous.measurable))
  let q' : EuclideanSpace ℝ (Fin (K - 1)) → EuclideanSpace ℝ (Fin K) :=
    fun x => if qMap x ∈ UL.Simplex K then qMap x else UL.uniformVec K
  have hq'_meas : Measurable q' :=
    Measurable.ite (hq_meas (UL.Proof_lem_A_5.isClosed_simplex K).measurableSet)
      hq_meas measurable_const
  have hq'_simp : ∀ x, q' x ∈ UL.Simplex K := by
    intro x
    dsimp [q']
    split_ifs with hx
    · exact hx
    · exact UL.Proof_lem_A_5.uniformVec_mem_simplex (by omega)
  have hpq'_ae_fst : ∀ᵐ x ∂P.fst, p x = q' x := by
    filter_upwards [hpq_ae, hq_simp_ae] with x hpx hqx
    dsimp [q']
    rw [if_pos hqx, hpx]
  have hpq'_ae_P : ∀ᵐ z ∂P, p z.1 = q' z.1 :=
    ae_of_ae_map measurable_fst.aemeasurable hpq'_ae_fst
  have h_loss_eq : expCanonicalLoss p = expCanonicalLoss q' := by
    dsimp [expCanonicalLoss]
    have h1 : (∫⁻ z, (UL.extendedCanonicalLoss Φ (p z.1) z.2).toENNReal ∂P) =
        ∫⁻ z, (UL.extendedCanonicalLoss Φ (q' z.1) z.2).toENNReal ∂P := by
      refine lintegral_congr_ae ?_
      filter_upwards [hpq'_ae_P] with z hz
      rw [hz]
    have h2 : (∫⁻ z, (-UL.extendedCanonicalLoss Φ (p z.1) z.2).toENNReal ∂P) =
        ∫⁻ z, (-UL.extendedCanonicalLoss Φ (q' z.1) z.2).toENNReal ∂P := by
      refine lintegral_congr_ae ?_
      filter_upwards [hpq'_ae_P] with z hz
      rw [hz]
    rw [h1, h2]
  let j₀ : Fin K := ⟨0, by omega⟩
  let i₀ : Fin (K - 1) := ⟨0, by omega⟩
  have hq'_ridge : ∃ (j : Fin K) (a₀ : EuclideanSpace ℝ (Fin (K - 1))) (f : ℝ → ℝ),
      Measurable f ∧
      (∀ t : ℝ, f t ∈ Set.Icc (0 : ℝ) 1) ∧
      (∀ᵐ x ∂P.fst, q' x j = f (inner ℝ a₀ x)) := by
    refine ⟨j₀, a i₀, r i₀, (hr i₀).1, (hr i₀).2, ?_⟩
    filter_upwards [hq_simp_ae] with x hqx
    dsimp only [q']
    rw [if_pos hqx]
    have hj₀ : j₀.val < K - 1 := by dsimp [j₀]; omega
    dsimp only [qMap, UL.separateLinkMap]
    change (if hj : j₀.val < K - 1 then r ⟨j₀.val, hj⟩ (inner ℝ (a ⟨j₀.val, hj⟩) x) else _) = _
    rw [dif_pos hj₀]
  have hgap : ((linBench + γ : ℝ) : EReal) ≤ expCanonicalLoss q' :=
    h_ridge q' hq'_meas hq'_simp hq'_ridge
  rw [← h_loss_eq] at hgap
  refine ⟨hgap, ?_⟩
  intro hle
  have hbad : ((linBench + γ : ℝ) : EReal) ≤ ((linBench : ℝ) : EReal) := hgap.trans hle
  have hbad_real : linBench + γ ≤ linBench := EReal.coe_le_coe_iff.mp hbad
  linarith

end UL.Proof_thm_E_1

import UL.Stmt.lem_A_4
import UL.Stmt.lem_A_3
import UL.Proof.lem_A_4.H3_Main
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_lem_A_4 (h_lem_A_3 : S_lem_A_3) : S_lem_A_4 := by
  unfold S_lem_A_4
  intro Ω _ μ _ K B S Y P hB hS_int hY_meas hFit
  rcases K with _ | _ | K'
  · by_cases hne : Nonempty Ω
    · exact Fin.elim0 (Y (Classical.choice hne))
    · exfalso
      haveI : IsEmpty Ω := not_nonempty_iff.mp hne
      have h1 : μ Set.univ = 1 := MeasureTheory.measure_univ
      have hempty : (Set.univ : Set Ω) = ∅ := Set.eq_empty_of_isEmpty _
      rw [hempty, MeasureTheory.measure_empty] at h1
      exact zero_ne_one h1
  · obtain ⟨ρ, hProfile, rfl⟩ := hFit
    have hr_zero : ∀ ω : Ω, fitResidual (fun ω => ρ (S ω)) Y ω = 0 := by
      intro ω
      have hP0 : ρ (S ω) 0 = 1 := by
        have h := (hProfile.2.1.2.2 (S ω)).2
        simpa using h
      have hZ0 : oneHotLabel Y ω 0 = 1 := by
        have hY0 : Y ω = 0 := Fin.ext (Nat.lt_one_iff.mp (Y ω).isLt)
        simp [oneHotLabel, oneHotVec, hY0, EuclideanSpace.single_apply]
      ext j
      fin_cases j
      simp [fitResidual, hP0, hZ0]
    simp [hr_zero]
  · have hK : 2 ≤ K' + 2 := by omega
    obtain ⟨ρ, hProfile, rfl⟩ := hFit
    have hS_aem : AEMeasurable S μ := hS_int.aestronglyMeasurable.aemeasurable
    let S' : Ω → ZeroSumSubspace (K' + 2) := hS_aem.mk S
    have hS'_meas : Measurable S' := hS_aem.measurable_mk
    have hSS' : S =ᵐ[μ] S' := hS_aem.ae_eq_mk
    have hS'_int : MeasureTheory.Integrable S' μ := hS_int.congr hSS'
    have hRisk_eq : ∀ ρ₁ : ZeroSumSubspace (K' + 2) → EuclideanSpace ℝ (Fin (K' + 2)),
        lsFitRisk μ S Y ρ₁ = lsFitRisk μ S' Y ρ₁ := by
      intro ρ₁
      unfold lsFitRisk
      refine MeasureTheory.integral_congr_ae ?_
      filter_upwards [hSS'] with ω hω
      rw [hω]
    have hProfile' : IsLipschitzLSFitProfile μ B S' Y ρ := by
      refine ⟨hProfile.1, hProfile.2.1, fun ρ₁ hρ₁ => ?_⟩
      have h : lsFitRisk μ S Y ρ ≤ lsFitRisk μ S Y ρ₁ := hProfile.2.2 hρ₁
      change lsFitRisk μ S' Y ρ ≤ lsFitRisk μ S' Y ρ₁
      rwa [← hRisk_eq ρ, ← hRisk_eq ρ₁]
    obtain ⟨h1', h2', h3'⟩ :=
      UL.Proof_lem_A_4.prove_cross_universe h_lem_A_3 μ hK hB hS'_meas hS'_int hY_meas hProfile'
    refine ⟨?_, ?_, ?_⟩
    · have hcongr : (∫ ω, fitResidual (fun ω => ρ (S ω)) Y ω ∂μ) =
          ∫ ω, fitResidual (fun ω => ρ (S' ω)) Y ω ∂μ := by
        refine MeasureTheory.integral_congr_ae ?_
        filter_upwards [hSS'] with ω hω
        simp [fitResidual, hω]
      rwa [hcongr]
    · intro f hf_diff hf_conv hL
      have hcongr :
          (∫ ω, inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω)
            (↑(gradient f ((ZeroSumSubspace (K' + 2)).orthogonalProjection
              (ρ (S ω) - uniformVec (K' + 2)))) : EuclideanSpace ℝ (Fin (K' + 2))) ∂μ) =
          ∫ ω, inner ℝ (fitResidual (fun ω => ρ (S' ω)) Y ω)
            (↑(gradient f ((ZeroSumSubspace (K' + 2)).orthogonalProjection
              (ρ (S' ω) - uniformVec (K' + 2)))) : EuclideanSpace ℝ (Fin (K' + 2))) ∂μ := by
        refine MeasureTheory.integral_congr_ae ?_
        filter_upwards [hSS'] with ω hω
        simp [fitResidual, hω]
      rw [hcongr]
      exact h2' f hf_diff hf_conv hL
    · have hcongr1 :
          (∫ ω, inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω)
            (S ω : EuclideanSpace ℝ (Fin (K' + 2))) ∂μ) =
          ∫ ω, inner ℝ (fitResidual (fun ω => ρ (S' ω)) Y ω)
            (S' ω : EuclideanSpace ℝ (Fin (K' + 2))) ∂μ := by
        refine MeasureTheory.integral_congr_ae ?_
        filter_upwards [hSS'] with ω hω
        simp [fitResidual, hω]
      have hcongr2 :
          (∫ ω, inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω)
            (ρ (S ω) - uniformVec (K' + 2)) ∂μ) =
          ∫ ω, inner ℝ (fitResidual (fun ω => ρ (S' ω)) Y ω)
            (ρ (S' ω) - uniformVec (K' + 2)) ∂μ := by
        refine MeasureTheory.integral_congr_ae ?_
        filter_upwards [hSS'] with ω hω
        simp [fitResidual, hω]
      rwa [hcongr1, hcongr2]

end UL

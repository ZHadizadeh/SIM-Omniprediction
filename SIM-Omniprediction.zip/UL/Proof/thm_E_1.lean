import UL.Stmt.thm_E_1
import UL.Proof.thm_E_1.H1_Shannon
import UL.Proof.thm_E_1.H2_RidgeGap
import UL.Proof.thm_E_1.H3_MeasureRisk
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_thm_E_1 : S_thm_E_1 := by
  unfold S_thm_E_1
  intro K hK R β L hR hβ hL
  have hK2 : 2 ≤ K := by omega
  have hm1 : 1 ≤ K - 1 := by omega
  let T : ℝ := Proof_thm_E_1.shannonTemp β
  have hT_pos : 0 < T := Proof_thm_E_1.shannonTemp_pos hβ
  let Φ : Simplex K → ℝ := Proof_thm_E_1.shannonEntropy K T
  let η₀ : EuclideanSpace ℝ (Fin (K - 1)) → EuclideanSpace ℝ (Fin K) :=
    Proof_thm_E_1.shannonEta K hK2 R β
  let P : MeasureTheory.Measure (EuclideanSpace ℝ (Fin (K - 1)) × Fin K) :=
    Proof_thm_E_1.jointMeasureP (K - 1) K L η₀
  let V₀ : EuclideanSpace ℝ (Fin (K - 1)) →L[ℝ] ZeroSumSubspace K :=
    Proof_thm_E_1.scoreOpV0 K hK2 R
  have hSoftLip : LipschitzWith (Real.toNNReal β) (Proof_thm_E_1.softmaxMap K T) :=
    Proof_thm_E_1.lipschitzWith_softmaxMap K hK2 hβ
  have hη₀_cont : Continuous η₀ := by
    unfold η₀ Proof_thm_E_1.shannonEta
    exact hSoftLip.continuous.comp (continuous_subtype_val.comp V₀.continuous)
  have hη₀_simp : ∀ x, η₀ x ∈ Simplex K :=
    Proof_thm_E_1.shannonEta_mem_simplex hK2 R β
  have hΦ_ent : Φ ∈ EntropyFamily K β :=
    Proof_thm_E_1.shannonEntropy_mem_entropyFamily K hK2 hβ
  have hfst : P.fst = Proof_thm_E_1.ballUniformMeasure (K - 1) L :=
    Proof_thm_E_1.jointMeasureP_fst_eq (K - 1) K hL hη₀_cont hη₀_simp
  refine ⟨P, Φ, ?_⟩
  dsimp only
  have hP_prob : MeasureTheory.IsProbabilityMeasure P :=
    Proof_thm_E_1.jointMeasureP_isProb (K - 1) K hm1 hL hη₀_cont hη₀_simp
  have hP_unif : MeasureTheory.pdf.IsUniform Prod.fst
      (Metric.ball (0 : EuclideanSpace ℝ (Fin (K - 1))) L) P MeasureTheory.volume :=
    Proof_thm_E_1.jointMeasureP_isUniform (K - 1) K hL hη₀_cont hη₀_simp
  have hX_int : MeasureTheory.Integrable (fun x => ‖x‖) P.fst := by
    rw [hfst]
    exact Proof_thm_E_1.integrable_norm_ballUniformMeasure (K - 1) hm1 hL
  have hML_int : ∀ V : EuclideanSpace ℝ (Fin (K - 1)) →L[ℝ] ZeroSumSubspace K,
      MeasureTheory.Integrable (fun z => matchingLoss Φ (V z.1) z.2) P :=
    Proof_thm_E_1.integrable_matchingLoss_jointMeasureP K hK hL hΦ_ent hη₀_cont hη₀_simp
  have hV₀_frob :
      Real.sqrt (∑ i : Fin (K - 1), ‖V₀ (EuclideanSpace.single i (1 : ℝ))‖ ^ 2) = R :=
    Proof_thm_E_1.frobNorm_scoreOpV0 K hK2 hR
  have hPot_diff : Differentiable ℝ (matchingPotential Φ) :=
    Proof_thm_E_1.differentiable_matchingPotential_shannon K hK2 hβ
  have hη_eq : ∀ x : EuclideanSpace ℝ (Fin (K - 1)),
      uniformVec K + gradient (matchingPotential Φ) (V₀ x : EuclideanSpace ℝ (Fin K)) = η₀ x :=
    fun x => Proof_thm_E_1.uniformVec_add_gradient_matchingPotential_shannon K hK2 hβ (V₀ x)
  have h_bayes : ∀ (x : EuclideanSpace ℝ (Fin (K - 1))) (a : ZeroSumSubspace K),
      ∑ y : Fin K, η₀ x y * matchingLoss Φ (V₀ x) y ≤
        ∑ y : Fin K, η₀ x y * matchingLoss Φ a y :=
    fun x a => Proof_thm_E_1.shannon_cond_bayes_opt K hK2 hβ (V₀ x) a
  have h_ml_nonneg : ∀ (x : EuclideanSpace ℝ (Fin (K - 1))) (y : Fin K),
      0 ≤ matchingLoss Φ (V₀ x) y :=
    fun x y => Proof_thm_E_1.matchingLoss_shannon_zeroSum_nonneg K hK2 hβ (V₀ x) y
  obtain ⟨hLinBench_eq, _hLinBench_nn⟩ :=
    Proof_thm_E_1.linBench_eq_and_nonneg K hK hL hΦ_ent hη₀_cont hη₀_simp
      hV₀_frob.le h_bayes h_ml_nonneg
  have h_ecl_eta : ∀ (x : EuclideanSpace ℝ (Fin (K - 1))) (y : Fin K),
      extendedCanonicalLoss Φ (η₀ x) y = ((matchingLoss Φ (V₀ x) y : ℝ) : EReal) := by
    intro x y
    rw [Proof_thm_E_1.extendedCanonicalLoss_shannon_eq K hK2 hβ (hη₀_simp x) y,
      if_pos (Proof_thm_E_1.shannonEta_pos hK2 R β x y),
      Proof_thm_E_1.matchingLoss_shannon_zeroSum K hK2 hβ (V₀ x) y]
    rfl
  have h_ecl_form : ∀ (p : EuclideanSpace ℝ (Fin K)), p ∈ Simplex K → ∀ y : Fin K,
      extendedCanonicalLoss Φ p y =
        if 0 < p y then ((-T * Real.log (p y) : ℝ) : EReal) else ⊤ :=
    fun p hp y => Proof_thm_E_1.extendedCanonicalLoss_shannon_eq K hK2 hβ hp y
  have h_ptwise_gap : ∀ (x : EuclideanSpace ℝ (Fin (K - 1))) (q : EuclideanSpace ℝ (Fin K)),
      q ∈ Simplex K →
      ENNReal.ofReal (∑ y : Fin K, η₀ x y * matchingLoss Φ (V₀ x) y) +
        ENNReal.ofReal (T * ‖η₀ x - q‖ ^ 2) ≤
        ∑ y : Fin K, ENNReal.ofReal (η₀ x y) * (extendedCanonicalLoss Φ q y).toENNReal :=
    fun x q hq => Proof_thm_E_1.shannon_pointwise_ennreal_gap K hK2 hβ (V₀ x) hq
  refine ⟨hP_prob, hP_unif, hX_int, hΦ_ent, hML_int, ?_, ?_⟩
  · refine ⟨V₀, hV₀_frob, hPot_diff, ?_⟩
    dsimp only
    simp_rw [hη_eq]
    refine ⟨hη₀_simp, ?_, hLinBench_eq, h_bayes, ?_, ?_, ?_⟩
    · intro A hA y
      rw [hfst]
      exact Proof_thm_E_1.jointMeasureP_prod_singleton (K - 1) K hL hη₀_cont hη₀_simp A hA y
    · rw [hLinBench_eq]
      exact Proof_thm_E_1.expCanonicalLoss_eta_eq K hK hL hΦ_ent hη₀_cont hη₀_simp
        V₀ h_ecl_eta h_ml_nonneg
    · intro q hq_meas hq_simp
      rw [hLinBench_eq]
      have hgap := Proof_thm_E_1.expCanonicalLoss_ge_linBench_add_l2 K hK hT_pos.le hL hΦ_ent
        hη₀_cont hη₀_simp V₀ h_ecl_form h_ml_nonneg h_ptwise_gap hq_meas hq_simp
      have h_l2_nn : 0 ≤ T * ∫ x, ‖η₀ x - q x‖ ^ 2 ∂(Proof_thm_E_1.ballUniformMeasure (K - 1) L) :=
        mul_nonneg hT_pos.le (MeasureTheory.integral_nonneg (fun _ => sq_nonneg _))
      have h_le : ((∫ z, matchingLoss Φ (V₀ z.1) z.2 ∂P : ℝ) : EReal) ≤
          (((∫ z, matchingLoss Φ (V₀ z.1) z.2 ∂P) +
            T * ∫ x, ‖η₀ x - q x‖ ^ 2 ∂(Proof_thm_E_1.ballUniformMeasure (K - 1) L) : ℝ) : EReal) :=
        EReal.coe_le_coe_iff.mpr (by linarith)
      exact h_le.trans hgap
    · refine ⟨Proof_thm_E_1.scoreOpW K R, Proof_thm_E_1.shannonRho K hK2 β,
        Proof_thm_E_1.frobNorm_scoreOpW_le K hK2 hR,
        Proof_thm_E_1.lipschitzWith_shannonRho K hK2 hSoftLip,
        Proof_thm_E_1.shannonRho_mem_simplex K hK2 β,
        Proof_thm_E_1.shannonEta_eq_rho_comp_W hK2 R β⟩
  · have hEtaLip : ∀ x y : EuclideanSpace ℝ (Fin (K - 1)),
        ‖η₀ x - η₀ y‖ ≤ Proof_thm_E_1.shannonAlpha K R β * ‖x - y‖ := by
      intro x y
      have h1 := hSoftLip.dist_le_mul
        ((V₀ x : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
        ((V₀ y : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
      rw [dist_eq_norm, dist_eq_norm, Real.coe_toNNReal β hβ.le] at h1
      have hV₀_diff : ‖((V₀ x : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) -
          ((V₀ y : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))‖ =
          Proof_thm_E_1.scoreScale K R * ‖x - y‖ := by
        have hc : 0 < Proof_thm_E_1.scoreScale K R := Proof_thm_E_1.scoreScale_pos hK2 hR
        calc ‖((V₀ x : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) -
              ((V₀ y : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))‖
            = ‖V₀ x - V₀ y‖ := (Submodule.norm_coe (V₀ x - V₀ y)).symm
          _ = ‖V₀ (x - y)‖ := by rw [← map_sub]
          _ = ‖Proof_thm_E_1.scoreScale K R • Proof_thm_E_1.zeroSumIso K hK2 (x - y)‖ := rfl
          _ = Proof_thm_E_1.scoreScale K R * ‖x - y‖ := by
              rw [norm_smul, Real.norm_eq_abs, abs_of_pos hc, LinearIsometryEquiv.norm_map]
      rw [hV₀_diff] at h1
      have h_coeff : β * Proof_thm_E_1.scoreScale K R ≤ Proof_thm_E_1.shannonAlpha K R β := by
        unfold Proof_thm_E_1.shannonAlpha Proof_thm_E_1.shannonTemp
        have hc : 0 < Proof_thm_E_1.scoreScale K R := Proof_thm_E_1.scoreScale_pos hK2 hR
        have h_eq : Proof_thm_E_1.scoreScale K R / (1 / (2 * β)) =
            2 * (β * Proof_thm_E_1.scoreScale K R) := by
          field_simp [hβ.ne']
        rw [h_eq]
        nlinarith
      calc ‖η₀ x - η₀ y‖
          ≤ β * (Proof_thm_E_1.scoreScale K R * ‖x - y‖) := h1
        _ = (β * Proof_thm_E_1.scoreScale K R) * ‖x - y‖ := by ring
        _ ≤ Proof_thm_E_1.shannonAlpha K R β * ‖x - y‖ :=
            mul_le_mul_of_nonneg_right h_coeff (norm_nonneg _)
    obtain ⟨c_star, hc_pos, hc_bound⟩ :=
      Proof_thm_E_1.exists_ridge_l2_gap K hK hR hβ hL hEtaLip
    let γ : ℝ := T * c_star
    have hγ_pos : 0 < γ := mul_pos hT_pos hc_pos
    have h_ridge : ∀ p : EuclideanSpace ℝ (Fin (K - 1)) → EuclideanSpace ℝ (Fin K),
        Measurable p →
        (∀ x : EuclideanSpace ℝ (Fin (K - 1)), p x ∈ Simplex K) →
        (∃ (j : Fin K) (a : EuclideanSpace ℝ (Fin (K - 1))) (f : ℝ → ℝ),
          Measurable f ∧
          (∀ t : ℝ, f t ∈ Set.Icc (0 : ℝ) 1) ∧
          (∀ᵐ x ∂P.fst, p x j = f (inner ℝ a x))) →
        (((sInf ((fun V : EuclideanSpace ℝ (Fin (K - 1)) →L[ℝ] ZeroSumSubspace K =>
            ∫ z, matchingLoss Φ (V z.1) z.2 ∂P) ''
          {V | Real.sqrt (∑ i : Fin (K - 1), ‖V (EuclideanSpace.single i (1 : ℝ))‖ ^ 2) ≤ R})) +
            γ : ℝ) : EReal) ≤
          ((∫⁻ z, (extendedCanonicalLoss Φ (p z.1) z.2).toENNReal ∂P : ENNReal) : EReal) -
            ((∫⁻ z, (-extendedCanonicalLoss Φ (p z.1) z.2).toENNReal ∂P : ENNReal) : EReal) := by
      intro p hp_meas hp_simp hex
      rw [hfst] at hex
      have hl2 := hc_bound p hp_meas hp_simp hex
      rw [hLinBench_eq]
      have hgap := Proof_thm_E_1.expCanonicalLoss_ge_linBench_add_l2 K hK hT_pos.le hL hΦ_ent
        hη₀_cont hη₀_simp V₀ h_ecl_form h_ml_nonneg h_ptwise_gap hp_meas hp_simp
      have h_le : (((∫ z, matchingLoss Φ (V₀ z.1) z.2 ∂P) + γ : ℝ) : EReal) ≤
          (((∫ z, matchingLoss Φ (V₀ z.1) z.2 ∂P) +
            T * ∫ x, ‖η₀ x - p x‖ ^ 2 ∂(Proof_thm_E_1.ballUniformMeasure (K - 1) L) : ℝ) : EReal) := by
        refine EReal.coe_le_coe_iff.mpr ?_
        dsimp [γ]
        nlinarith [mul_le_mul_of_nonneg_left hl2 hT_pos.le]
      exact h_le.trans hgap
    refine ⟨γ, hγ_pos, h_ridge, ?_⟩
    intro p hp_sep
    exact Proof_thm_E_1.separateLinkArchitectureAE_gap K hK P Φ _ γ hγ_pos h_ridge p hp_sep

end UL

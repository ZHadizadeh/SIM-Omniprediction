import UL.Stmt.lem_C_4
import UL.Stmt.lem_C_2
import UL.Stmt.cit_brouwer
import UL.Proof.lem_C_2.H1_HilbertSchmidt
import UL.Proof.lem_C_2.H2_SmoothEntropy
import UL.Proof.lem_C_2.H3_EmpiricalFit
import UL.Proof.lem_C_2.H4_BrouwerFixedPoint
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_lem_C_2 (h_cit_brouwer : S_cit_brouwer) (h_lem_C_4 : S_lem_C_4) : S_lem_C_2 := by
  unfold S_lem_C_2
  intro K hK X _instNACG _instIPS _instCS _instSep n hn x y L R β B lam M
    hL hx hR hβ hB _hlam _hM
  have hB_pos : 0 < B := lt_of_lt_of_le hβ hB
  let Z : Fin n → ZeroSumSubspace K := fun i =>
    ⟨EuclideanSpace.single (y i) (1 : ℝ) - uniformVec K,
      Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex
        (Proof_lem_A_1.single_mem_simplex (y i))
        (Proof_lem_A_5.uniformVec_mem_simplex hK)⟩
  have hZ : ∀ i : Fin n,
      (Z i : EuclideanSpace ℝ (Fin K)) = EuclideanSpace.single (y i) (1 : ℝ) - uniformVec K :=
    fun _ => rfl
  refine ⟨Z, hZ, ?_, ?_⟩
  · intro W hW
    have hs_bound : ∀ i : Fin n, ‖W (x i)‖ ≤ L * R := by
      intro i
      calc ‖W (x i)‖
          ≤ hilbertSchmidtNorm W * ‖x i‖ :=
            Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm W (x i)
        _ ≤ R * L := mul_le_mul hW (hx i) (norm_nonneg _) hR.le
        _ = L * R := mul_comm R L
    refine ⟨⟨Proof_lem_C_2.optFitScores (L * R) B Z (fun i => W (x i)),
        Proof_lem_C_2.optFitScores_spec h_lem_C_4 hK hn hB_pos Z hs_bound,
        fun otherCenteredFit hP' => Proof_lem_C_2.isOptFitAtScores_unique hn
          (Proof_lem_C_2.optFitScores_spec h_lem_C_4 hK hn hB_pos Z hs_bound) hP'⟩,
      fun pTilde hP Φ hΦ =>
        Proof_lem_C_2.empirical_comparison_bound hK hn x y hL hx hR hβ hB hZ hW hP hΦ⟩
  · let N : ℕ :=
      Module.finrank ℝ (Proof_lem_C_2.sampleSpan x) * Module.finrank ℝ (ZeroSumSubspace K)
    have hw_norm : ∀ w : Metric.closedBall (0 : EuclideanSpace ℝ (Fin N)) R, ‖w.1‖ ≤ R := by
      intro w
      have hw : w.1 ∈ Metric.closedBall (0 : EuclideanSpace ℝ (Fin N)) R := w.2
      rwa [Metric.mem_closedBall, dist_zero_right] at hw
    have hw_scores : ∀ w : Metric.closedBall (0 : EuclideanSpace ℝ (Fin N)) R,
        ∀ i : Fin n,
          ‖Proof_lem_C_2.toSampleSpanOp (Y := ZeroSumSubspace K) x w.1 (x i)‖ ≤ L * R := by
      intro w i
      calc ‖Proof_lem_C_2.toSampleSpanOp (Y := ZeroSumSubspace K) x w.1 (x i)‖
          ≤ hilbertSchmidtNorm
              (Proof_lem_C_2.toSampleSpanOp (Y := ZeroSumSubspace K) x w.1) * ‖x i‖ :=
            Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm _ (x i)
        _ = ‖w.1‖ * ‖x i‖ := by
            rw [Proof_lem_C_2.hilbertSchmidtNorm_toSampleSpanOp]
        _ ≤ R * L := mul_le_mul (hw_norm w) (hx i) (norm_nonneg _) hR.le
        _ = L * R := mul_comm R L
    let scoreMap : Metric.closedBall (0 : EuclideanSpace ℝ (Fin N)) R →
        {s : Fin n → ZeroSumSubspace K // ∀ i : Fin n, ‖s i‖ ≤ L * R} :=
      fun w => ⟨fun i => Proof_lem_C_2.toSampleSpanOp (Y := ZeroSumSubspace K) x w.1 (x i),
        hw_scores w⟩
    have h_score_cont : Continuous scoreMap :=
      ((Proof_lem_C_2.continuous_toSampleSpanOp_eval (Y := ZeroSumSubspace K) x).comp
        continuous_subtype_val).subtype_mk _
    let centeredFitMap : Metric.closedBall (0 : EuclideanSpace ℝ (Fin N)) R →
        (Fin n → ZeroSumSubspace K) :=
      fun w => Proof_lem_C_2.optFitScores (L * R) B Z (scoreMap w).1
    have h_centeredFitMap_cont : Continuous centeredFitMap :=
      (Proof_lem_C_2.continuous_optFitScores h_lem_C_4 hK hn hB_pos Z).comp h_score_cont
    let gMap : Metric.closedBall (0 : EuclideanSpace ℝ (Fin N)) R → EuclideanSpace ℝ (Fin N) :=
      fun w => Proof_lem_C_2.empGradVec x (fun i => centeredFitMap w i - Z i)
    have h_gMap_cont : Continuous gMap :=
      (Proof_lem_C_2.continuous_empGradVec x Z).comp h_centeredFitMap_cont
    obtain ⟨w_star, h_gap_zero⟩ :=
      Proof_lem_C_2.exists_zero_gap_on_ball h_cit_brouwer hR gMap h_gMap_cont
    let W_star : X →L[ℝ] ZeroSumSubspace K :=
      Proof_lem_C_2.toSampleSpanOp (Y := ZeroSumSubspace K) x w_star.1
    let pTildeStar : Fin n → ZeroSumSubspace K := centeredFitMap w_star
    refine ⟨W_star, ?_, ?_, pTildeStar, ?_, ?_⟩
    · dsimp [W_star]
      rw [Proof_lem_C_2.hilbertSchmidtNorm_toSampleSpanOp]
      exact hw_norm w_star
    · intro v hv
      exact Proof_lem_C_2.toSampleSpanOp_vanishes_orth x w_star.1 hv
    · exact Proof_lem_C_2.optFitScores_spec h_lem_C_4 hK hn hB_pos Z (hw_scores w_star)
    · have h_eq := Proof_lem_C_2.gamma_toSampleSpanOp_eq x (fun i => pTildeStar i - Z i) R w_star.1
      dsimp only at h_eq
      exact h_eq.trans h_gap_zero

end UL

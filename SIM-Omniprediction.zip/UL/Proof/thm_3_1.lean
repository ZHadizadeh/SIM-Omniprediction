import UL.Stmt.thm_3_1
import UL.Stmt.thm_A_7
import UL.Proof.thm_A_7.H1_Law
import UL.Proof.thm_7_1.H0_Defs
set_option autoImplicit false

namespace UL

open MeasureTheory
open UL.Proof_thm_A_7

private lemma erealExpectation_congr_ae {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) {Z₁ Z₂ : Ω → EReal} (h : Z₁ =ᵐ[μ] Z₂) :
    erealExpectation μ Z₁ = erealExpectation μ Z₂ := by
  unfold erealExpectation
  have h₁ : (∫⁻ ω, (Z₁ ω).toENNReal ∂μ) = ∫⁻ ω, (Z₂ ω).toENNReal ∂μ :=
    lintegral_congr_ae (h.mono fun _ hω => by simp [hω])
  have h₂ : (∫⁻ ω, (-Z₁ ω).toENNReal ∂μ) = ∫⁻ ω, (-Z₂ ω).toENNReal ∂μ :=
    lintegral_congr_ae (h.mono fun _ hω => by simp [hω])
  rw [h₁, h₂]

private lemma erealExpectation_coe_eq_integral {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) {f : Ω → ℝ} (hf : Integrable f μ) :
    erealExpectation μ (fun ω => (f ω : EReal)) = ((∫ ω, f ω ∂μ : ℝ) : EReal) := by
  unfold erealExpectation
  have hpos_eq : (fun ω => ((f ω : EReal)).toENNReal) = (fun ω => ENNReal.ofReal (f ω)) := by
    ext ω; rfl
  have hneg_eq : (fun ω => (-(f ω : EReal)).toENNReal) = (fun ω => ENNReal.ofReal (-f ω)) := by
    ext ω; rfl
  rw [hpos_eq, hneg_eq]
  have hpos_lt : (∫⁻ ω, ENNReal.ofReal (f ω) ∂μ) < ⊤ := by
    refine lt_of_le_of_lt (lintegral_mono fun ω => ?_) hf.2
    rw [Real.enorm_eq_ofReal_abs]
    exact ENNReal.ofReal_le_ofReal (le_abs_self _)
  have hneg_lt : (∫⁻ ω, ENNReal.ofReal (-f ω) ∂μ) < ⊤ := by
    refine lt_of_le_of_lt (lintegral_mono fun ω => ?_) hf.neg.2
    rw [Real.enorm_eq_ofReal_abs]
    exact ENNReal.ofReal_le_ofReal (le_abs_self _)
  rw [MeasureTheory.integral_eq_lintegral_pos_part_sub_lintegral_neg_part hf]
  rw [EReal.coe_sub, ← EReal.coe_ennreal_toReal hpos_lt.ne, ← EReal.coe_ennreal_toReal hneg_lt.ne]

private lemma extendedCanonicalLoss_ne_bot {K : ℕ} (Φ : Simplex K → ℝ)
    (p : EuclideanSpace ℝ (Fin K)) (y : Fin K) :
    extendedCanonicalLoss Φ p y ≠ ⊥ := by
  unfold extendedCanonicalLoss
  split_ifs
  · exact EReal.coe_ne_bot _
  · simp

private lemma frobeniusNorm_eq_norm_hsPiEquiv {d : ℕ} {Y : Type*}
    [NormedAddCommGroup Y] [InnerProductSpace ℝ Y] [FiniteDimensional ℝ Y]
    (V : EuclideanSpace ℝ (Fin d) →L[ℝ] Y) :
    frobeniusNorm V.toLinearMap = ‖UL.Proof_thm_7_1.hsPiEquiv d Y V‖ := by
  unfold frobeniusNorm
  rw [PiLp.norm_eq_of_L2]
  rfl

private lemma conj3_balls_and_constraints_gen (d : ℕ) (Y : Type*)
    [NormedAddCommGroup Y] [InnerProductSpace ℝ Y] [FiniteDimensional ℝ Y]
    (R : ℝ) (hR : 0 ≤ R) :
    let opBall : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] Y) := {V | ‖V‖ ≤ R}
    let frobBall : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] Y) :=
      {V | frobeniusNorm V.toLinearMap ≤ R}
    opBall.Nonempty ∧ IsCompact opBall ∧ Convex ℝ opBall ∧
    frobBall.Nonempty ∧ IsCompact frobBall ∧ Convex ℝ frobBall ∧
    (∀ (A : AffineSubspace ℝ (EuclideanSpace ℝ (Fin d) →L[ℝ] Y)),
      IsCompact (opBall ∩ (A : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] Y))) ∧
      Convex ℝ (opBall ∩ (A : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] Y))) ∧
      IsCompact (frobBall ∩ (A : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] Y))) ∧
      Convex ℝ (frobBall ∩ (A : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] Y)))) ∧
    (∀ (C : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] Y)),
      IsClosed C → Convex ℝ C →
      IsCompact (opBall ∩ C) ∧ Convex ℝ (opBall ∩ C) ∧
      IsCompact (frobBall ∩ C) ∧ Convex ℝ (frobBall ∩ C)) := by
  intro opBall frobBall
  let e := UL.Proof_thm_7_1.hsPiEquiv d Y
  have hop_eq : opBall = Metric.closedBall (0 : EuclideanSpace ℝ (Fin d) →L[ℝ] Y) R := by
    ext V
    simp [opBall, Metric.mem_closedBall, dist_zero_right]
  have hop_ne : opBall.Nonempty := ⟨0, by simp [opBall, hR]⟩
  have hop_conv : Convex ℝ opBall := by rw [hop_eq]; exact convex_closedBall _ R
  have hop_closed : IsClosed opBall := isClosed_le continuous_norm continuous_const
  let M : ℝ := ‖e.toContinuousLinearMap‖ * R
  have hop_sub : opBall ⊆ e.symm '' Metric.closedBall (0 : PiLp 2 (fun _ : Fin d => Y)) M := by
    intro V hV
    refine ⟨e V, ?_, e.symm_apply_apply V⟩
    rw [Metric.mem_closedBall, dist_zero_right]
    calc ‖e V‖ = ‖e.toContinuousLinearMap V‖ := rfl
      _ ≤ ‖e.toContinuousLinearMap‖ * ‖V‖ := e.toContinuousLinearMap.le_opNorm V
      _ ≤ ‖e.toContinuousLinearMap‖ * R :=
          mul_le_mul_of_nonneg_left hV (norm_nonneg e.toContinuousLinearMap)
  have hop_comp : IsCompact opBall :=
    ((isCompact_closedBall (0 : PiLp 2 (fun _ : Fin d => Y)) M).image e.symm.continuous).of_isClosed_subset
      hop_closed hop_sub
  have hfrob_eq : frobBall =
      e.symm '' Metric.closedBall (0 : PiLp 2 (fun _ : Fin d => Y)) R := by
    ext V
    simp only [frobBall, Set.mem_setOf_eq, Set.mem_image, Metric.mem_closedBall, dist_zero_right,
      frobeniusNorm_eq_norm_hsPiEquiv]
    constructor
    · intro h
      exact ⟨e V, h, e.symm_apply_apply V⟩
    · rintro ⟨f, hf, rfl⟩
      simpa [e] using hf
  have hfrob_ne : frobBall.Nonempty := ⟨0, by simp [frobBall, frobeniusNorm, hR]⟩
  have hfrob_comp : IsCompact frobBall := by
    rw [hfrob_eq]
    exact (isCompact_closedBall (0 : PiLp 2 (fun _ : Fin d => Y)) R).image e.symm.continuous
  have hfrob_conv : Convex ℝ frobBall := by
    rw [hfrob_eq]
    exact (convex_closedBall (0 : PiLp 2 (fun _ : Fin d => Y)) R).linear_image
      e.symm.toLinearEquiv.toLinearMap
  have hC_inter : ∀ (C : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] Y)), IsClosed C → Convex ℝ C →
      IsCompact (opBall ∩ C) ∧ Convex ℝ (opBall ∩ C) ∧
      IsCompact (frobBall ∩ C) ∧ Convex ℝ (frobBall ∩ C) := by
    intro C hC_cl hC_cv
    exact ⟨hop_comp.inter_right hC_cl, hop_conv.inter hC_cv,
      hfrob_comp.inter_right hC_cl, hfrob_conv.inter hC_cv⟩
  have hA_inter : ∀ (A : AffineSubspace ℝ (EuclideanSpace ℝ (Fin d) →L[ℝ] Y)),
      IsCompact (opBall ∩ (A : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] Y))) ∧
      Convex ℝ (opBall ∩ (A : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] Y))) ∧
      IsCompact (frobBall ∩ (A : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] Y))) ∧
      Convex ℝ (frobBall ∩ (A : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] Y))) := by
    intro A
    have hA_cl : IsClosed (A : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] Y)) := by
      rcases Set.eq_empty_or_nonempty (A : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] Y)) with
          h_emp | ⟨x₀, hx₀⟩
      · rw [h_emp]
        exact isClosed_empty
      · let S : Submodule ℝ (PiLp 2 (fun _ : Fin d => Y)) :=
          A.direction.map e.toLinearEquiv.toLinearMap
        have hpre : (A : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] Y)) =
            (fun x => e (x - x₀)) ⁻¹' (S : Set (PiLp 2 (fun _ : Fin d => Y))) := by
          ext x
          have hmem : x ∈ (A : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] Y)) ↔ x - x₀ ∈ A.direction := by
            simpa [vsub_eq_sub] using (AffineSubspace.vsub_right_mem_direction_iff_mem hx₀ x).symm
          rw [hmem, Set.mem_preimage, SetLike.mem_coe, Submodule.mem_map]
          constructor
          · intro hx
            exact ⟨x - x₀, hx, rfl⟩
          · rintro ⟨u, hu, heu⟩
            have hux : u = x - x₀ := e.injective heu
            rwa [← hux]
        rw [hpre]
        exact S.closed_of_finiteDimensional.preimage
          (e.continuous.comp (continuous_id.sub continuous_const))
    exact hC_inter (A : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] Y)) hA_cl A.convex
  exact ⟨hop_ne, hop_comp, hop_conv, hfrob_ne, hfrob_comp, hfrob_conv, hA_inter, hC_inter⟩

private lemma conj2_from_thm_A_7.{u₁, u₂} (h_thm_A_7 : S_thm_A_7.{u₁})
    {Ω : Type u₂} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    {d K : ℕ} (hK : 2 ≤ K)
    {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin K}
    (hX : Measurable X) (hY : Measurable Y)
    (hX_int : Integrable (fun ω => ‖X ω‖) μ)
    {β : ℝ} (hβ : 0 < β)
    {𝒲 : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)}
    (h𝒲_ne : 𝒲.Nonempty) (h𝒲_comp : IsCompact 𝒲) (h𝒲_conv : Convex ℝ 𝒲) :
    ∃ W ∈ 𝒲, ∃ (ρ : ZeroSumSubspace K → Simplex K),
      LipschitzWith (Real.toNNReal β) ρ ∧
      let p : EuclideanSpace ℝ (Fin d) → Simplex K := fun x => ρ (W x)
      (∀ Φ ∈ EntropyFamily K β,
        expectedCanonicalLoss μ X Y Φ p ≤
          ⨅ V ∈ 𝒲, expectedMatchingLoss μ X Y Φ V.toLinearMap ∧
        expectedCanonicalLoss μ X Y Φ p ≠ ⊥ ∧
        expectedCanonicalLoss μ X Y Φ p ≠ ⊤ ∧
        (∀ V ∈ 𝒲,
          expectedMatchingLoss μ X Y Φ V.toLinearMap ≠ ⊥ ∧
          expectedMatchingLoss μ X Y Φ V.toLinearMap ≠ ⊤) ∧
        (⨅ V ∈ 𝒲, expectedMatchingLoss μ X Y Φ V.toLinearMap) ≠ ⊥ ∧
        (⨅ V ∈ 𝒲, expectedMatchingLoss μ X Y Φ V.toLinearMap) ≠ ⊤) ∧
      (∀ j : Fin K, ∀ᵐ ω ∂μ, (p (X ω) : EuclideanSpace ℝ (Fin K)) j = 0 → Y ω ≠ j) := by
  let μ₁ : Measure (LawSpace.{u₁} d K) := lawMeas.{u₁, u₂} μ X Y
  haveI : IsProbabilityMeasure μ₁ := isProbabilityMeasure_lawMeas.{u₁, u₂} μ hX hY
  have hf₁_aem : AEMeasurable (lawMap.{u₁, u₂} X Y) μ :=
    (measurable_lawMap.{u₁, u₂} hX hY).aemeasurable
  have hX₁ : Measurable (@lawX.{u₁} d K) := measurable_lawX.{u₁} d K
  have hY₁ : Measurable (@lawY.{u₁} d K) := measurable_lawY.{u₁} d K
  have hX₁_int : Integrable (fun z : LawSpace.{u₁} d K => ‖lawX.{u₁} z‖) μ₁ :=
    integrable_norm_lawX.{u₁, u₂} hX hY hX_int
  have hK1 : 1 ≤ K := by omega
  have h𝒲 : IsCompactConvexScoreSet 𝒲 := ⟨h𝒲_ne, h𝒲_comp, h𝒲_conv⟩
  obtain ⟨W, hW_mem, ρ₀, hρ₀_mem, h_omni₁, h_supp₁, _⟩ :=
    h_thm_A_7 (LawSpace.{u₁} d K) μ₁ d K hK1 β hβ
      (@lawX.{u₁} d K) (@lawY.{u₁} d K) hX₁ hY₁ hX₁_int 𝒲 h𝒲
  let ρ : ZeroSumSubspace K → Simplex K := fun s => ⟨ρ₀ s, hρ₀_mem.2.2 s⟩
  have hρ_lip : LipschitzWith (Real.toNNReal β) ρ := hρ₀_mem.2.1
  refine ⟨W, hW_mem, ρ, hρ_lip, ?_, ?_⟩
  · intro Φ hΦ
    obtain ⟨h_ne_top₁, h_int_can₁, h_int_mat₁, h_bdd₁, h_le₁⟩ := h_omni₁ Φ hΦ
    have h_ne_top : ∀ᵐ ω ∂μ, extendedCanonicalLoss Φ (ρ₀ (W (X ω))) (Y ω) ≠ ⊤ := by
      have hset_eq : {z : LawSpace.{u₁} d K |
          extendedCanonicalLoss Φ (ρ₀ (W (lawX.{u₁} z))) (lawY.{u₁} z) ≠ ⊤} =
          {z : LawSpace.{u₁} d K | 0 < ρ₀ (W (lawX.{u₁} z)) (lawY.{u₁} z)} := by
        ext z
        exact extendedCanonicalLoss_ne_top_iff Φ (ρ₀ (W (lawX.{u₁} z))) (lawY.{u₁} z)
      have hmeas_set : MeasurableSet {z : LawSpace.{u₁} d K |
          extendedCanonicalLoss Φ (ρ₀ (W (lawX.{u₁} z))) (lawY.{u₁} z) ≠ ⊤} := by
        rw [hset_eq]
        have hp_meas : Measurable (fun z : LawSpace.{u₁} d K => ρ₀ (W (lawX.{u₁} z))) :=
          hρ₀_mem.2.1.continuous.measurable.comp (W.continuous.measurable.comp hX₁)
        exact measurableSet_lt measurable_const (measurable_eval_fin hp_meas hY₁)
      exact (ae_map_iff hf₁_aem hmeas_set).mp h_ne_top₁
    let f_can : Ω → ℝ := fun ω => (extendedCanonicalLoss Φ (ρ₀ (W (X ω))) (Y ω)).toReal
    have h_int_can : Integrable f_can μ :=
      (integrable_map_measure h_int_can₁.aestronglyMeasurable hf₁_aem).mp h_int_can₁
    have h_eq_can_int : ∫ z, (extendedCanonicalLoss Φ (ρ₀ (W (lawX.{u₁} z))) (lawY.{u₁} z)).toReal ∂μ₁ =
        ∫ ω, f_can ω ∂μ := by
      change ∫ z, _ ∂(μ.map (lawMap.{u₁, u₂} X Y)) = _
      rw [integral_map hf₁_aem h_int_can₁.aestronglyMeasurable]
      rfl
    have h_ae_coe :
        (fun ω => extendedCanonicalLoss Φ (ρ₀ (W (X ω))) (Y ω)) =ᵐ[μ]
          fun ω => ((f_can ω : ℝ) : EReal) := by
      filter_upwards [h_ne_top] with ω hω
      exact (EReal.coe_toReal hω (extendedCanonicalLoss_ne_bot Φ (ρ₀ (W (X ω))) (Y ω))).symm
    let p : EuclideanSpace ℝ (Fin d) → Simplex K := fun x => ρ (W x)
    have h_exp_can : expectedCanonicalLoss μ X Y Φ p = ((∫ ω, f_can ω ∂μ : ℝ) : EReal) := by
      unfold expectedCanonicalLoss
      change erealExpectation μ (fun ω => extendedCanonicalLoss Φ (ρ₀ (W (X ω))) (Y ω)) = _
      rw [erealExpectation_congr_ae μ h_ae_coe, erealExpectation_coe_eq_integral μ h_int_can]
    have h_mat_each : ∀ V ∈ 𝒲,
        expectedMatchingLoss μ X Y Φ V.toLinearMap =
          ((∫ ω, matchingLoss Φ (V (X ω)) (Y ω) ∂μ : ℝ) : EReal) ∧
        ∫ ω, f_can ω ∂μ ≤ ∫ ω, matchingLoss Φ (V (X ω)) (Y ω) ∂μ := by
      intro V hV
      have h_int_V₁ := h_int_mat₁ V hV
      have h_int_V : Integrable (fun ω => matchingLoss Φ (V (X ω)) (Y ω)) μ :=
        (integrable_map_measure h_int_V₁.aestronglyMeasurable hf₁_aem).mp h_int_V₁
      have h_eq_V_int : ∫ z, matchingLoss Φ (V (lawX.{u₁} z)) (lawY.{u₁} z) ∂μ₁ =
          ∫ ω, matchingLoss Φ (V (X ω)) (Y ω) ∂μ := by
        change ∫ z, _ ∂(μ.map (lawMap.{u₁, u₂} X Y)) = _
        rw [integral_map hf₁_aem h_int_V₁.aestronglyMeasurable]
        rfl
      have h_exp_V : expectedMatchingLoss μ X Y Φ V.toLinearMap =
          ((∫ ω, matchingLoss Φ (V (X ω)) (Y ω) ∂μ : ℝ) : EReal) := by
        unfold expectedMatchingLoss
        exact erealExpectation_coe_eq_integral μ h_int_V
      have h_le_V : ∫ ω, f_can ω ∂μ ≤ ∫ ω, matchingLoss Φ (V (X ω)) (Y ω) ∂μ := by
        rw [← h_eq_can_int, ← h_eq_V_int]
        exact h_le₁.trans (csInf_le h_bdd₁ ⟨V, hV, rfl⟩)
      exact ⟨h_exp_V, h_le_V⟩
    have h_omni_le : expectedCanonicalLoss μ X Y Φ p ≤
        ⨅ V ∈ 𝒲, expectedMatchingLoss μ X Y Φ V.toLinearMap := by
      rw [h_exp_can]
      refine le_iInf₂ fun V hV => ?_
      rw [(h_mat_each V hV).1]
      exact EReal.coe_le_coe_iff.mpr (h_mat_each V hV).2
    have h_inf_ne_bot : (⨅ V ∈ 𝒲, expectedMatchingLoss μ X Y Φ V.toLinearMap) ≠ ⊥ := by
      intro h_bot
      rw [h_exp_can, h_bot] at h_omni_le
      exact not_le_of_gt (EReal.bot_lt_coe _) h_omni_le
    have h_inf_ne_top : (⨅ V ∈ 𝒲, expectedMatchingLoss μ X Y Φ V.toLinearMap) ≠ ⊤ := by
      obtain ⟨V₀, hV₀⟩ := h𝒲_ne
      intro h_top
      have h_le_V₀ : (⨅ V ∈ 𝒲, expectedMatchingLoss μ X Y Φ V.toLinearMap) ≤
          expectedMatchingLoss μ X Y Φ V₀.toLinearMap := iInf₂_le V₀ hV₀
      rw [h_top, (h_mat_each V₀ hV₀).1] at h_le_V₀
      exact not_le_of_gt (EReal.coe_lt_top _) h_le_V₀
    refine ⟨h_omni_le, ?_, ?_, ?_, h_inf_ne_bot, h_inf_ne_top⟩
    · rw [h_exp_can]; exact EReal.coe_ne_bot _
    · rw [h_exp_can]; exact EReal.coe_ne_top _
    · intro V hV
      rw [(h_mat_each V hV).1]
      exact ⟨EReal.coe_ne_bot _, EReal.coe_ne_top _⟩
  · intro j
    have hmeas_imp : MeasurableSet
        {z : LawSpace.{u₁} d K | ρ₀ (W (lawX.{u₁} z)) j = 0 → lawY.{u₁} z ≠ j} := by
      have heq_set : {z : LawSpace.{u₁} d K | ρ₀ (W (lawX.{u₁} z)) j = 0 → lawY.{u₁} z ≠ j} =
          {z : LawSpace.{u₁} d K | ρ₀ (W (lawX.{u₁} z)) j = 0}ᶜ ∪
            {z : LawSpace.{u₁} d K | lawY.{u₁} z = j}ᶜ := by
        ext z
        simp [imp_iff_not_or]
      rw [heq_set]
      have hS₁ : Measurable (fun z : LawSpace.{u₁} d K => W (lawX.{u₁} z)) :=
        W.continuous.measurable.comp hX₁
      have hm1 : MeasurableSet {z : LawSpace.{u₁} d K | ρ₀ (W (lawX.{u₁} z)) j = 0} :=
        measurableSet_eq_fun
          ((EuclideanSpace.proj j).continuous.measurable.comp
            (hρ₀_mem.2.1.continuous.measurable.comp hS₁))
          measurable_const
      have hm2 : MeasurableSet {z : LawSpace.{u₁} d K | lawY.{u₁} z = j} :=
        measurableSet_eq_fun hY₁ measurable_const
      exact hm1.compl.union hm2.compl
    exact (ae_map_iff hf₁_aem hmeas_imp).mp (h_supp₁ j)

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_thm_3_1 (h_thm_A_7 : S_thm_A_7) : S_thm_3_1 := by
  unfold S_thm_3_1
  intro Ω _ μ _ d K hK X Y hX hY hX_int
  have h_conj2 : ∀ (β : ℝ), 0 < β →
      ∀ (𝒲 : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)),
        𝒲.Nonempty → IsCompact 𝒲 → Convex ℝ 𝒲 →
        ∃ W ∈ 𝒲, ∃ (ρ : ZeroSumSubspace K → Simplex K),
          LipschitzWith (Real.toNNReal β) ρ ∧
          let p : EuclideanSpace ℝ (Fin d) → Simplex K := fun x => ρ (W x)
          (∀ Φ ∈ EntropyFamily K β,
            expectedCanonicalLoss μ X Y Φ p ≤
              ⨅ V ∈ 𝒲, expectedMatchingLoss μ X Y Φ V.toLinearMap ∧
            expectedCanonicalLoss μ X Y Φ p ≠ ⊥ ∧
            expectedCanonicalLoss μ X Y Φ p ≠ ⊤ ∧
            (∀ V ∈ 𝒲,
              expectedMatchingLoss μ X Y Φ V.toLinearMap ≠ ⊥ ∧
              expectedMatchingLoss μ X Y Φ V.toLinearMap ≠ ⊤) ∧
            (⨅ V ∈ 𝒲, expectedMatchingLoss μ X Y Φ V.toLinearMap) ≠ ⊥ ∧
            (⨅ V ∈ 𝒲, expectedMatchingLoss μ X Y Φ V.toLinearMap) ≠ ⊤) ∧
          (∀ j : Fin K, ∀ᵐ ω ∂μ, (p (X ω) : EuclideanSpace ℝ (Fin K)) j = 0 → Y ω ≠ j) := by
    intro β hβ 𝒲 h𝒲_ne h𝒲_comp h𝒲_conv
    exact conj2_from_thm_A_7 h_thm_A_7 μ hK hX hY hX_int hβ h𝒲_ne h𝒲_comp h𝒲_conv
  have h_conj3 := fun (R : ℝ) (hR : 0 ≤ R) =>
    conj3_balls_and_constraints_gen d (ZeroSumSubspace K) R hR
  refine ⟨?_, h_conj2, h_conj3⟩
  intro R β hR hβ
  let frobBall : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K) :=
    {V | frobeniusNorm V.toLinearMap ≤ R}
  obtain ⟨_, _, _, hfrob_ne, hfrob_comp, hfrob_conv, _, _⟩ := h_conj3 R hR.le
  obtain ⟨W_clm, hW_clm, ρ, hρ_lip, h_omni_frob, h_supp⟩ :=
    h_conj2 β hβ frobBall hfrob_ne hfrob_comp hfrob_conv
  refine ⟨W_clm.toLinearMap, ρ, hW_clm, hρ_lip, ?_⟩
  dsimp only
  have h_inf_eq : ∀ Φ : Simplex K → ℝ,
      (⨅ V ∈ ComparatorBall d K R, expectedMatchingLoss μ X Y Φ V) =
        ⨅ V_clm ∈ frobBall, expectedMatchingLoss μ X Y Φ V_clm.toLinearMap := by
    intro Φ
    refine le_antisymm ?_ ?_
    · refine le_iInf₂ fun V_clm hV_clm => ?_
      exact iInf₂_le V_clm.toLinearMap hV_clm
    · refine le_iInf₂ fun V hV => ?_
      have hV_eq : V.toContinuousLinearMap.toLinearMap = V := by
        ext x
        rfl
      have hV_mem : V.toContinuousLinearMap ∈ frobBall := by
        change frobeniusNorm V.toContinuousLinearMap.toLinearMap ≤ R
        rwa [hV_eq]
      calc (⨅ V_clm ∈ frobBall, expectedMatchingLoss μ X Y Φ V_clm.toLinearMap)
          ≤ expectedMatchingLoss μ X Y Φ V.toContinuousLinearMap.toLinearMap :=
            iInf₂_le V.toContinuousLinearMap hV_mem
        _ = expectedMatchingLoss μ X Y Φ V := by rw [hV_eq]
  have hp_eq : (ρ ∘ W_clm.toLinearMap) = (fun x => ρ (W_clm x)) := rfl
  refine ⟨?_, ?_, h_supp⟩
  · intro Φ hΦ
    rw [h_inf_eq Φ, hp_eq]
    exact (h_omni_frob Φ hΦ).1
  · intro Φ hΦ
    obtain ⟨_, h_can_bot, h_can_top, h_mat_frob, h_inf_bot, h_inf_top⟩ := h_omni_frob Φ hΦ
    rw [hp_eq, h_inf_eq Φ]
    refine ⟨h_can_bot, h_can_top, ?_, h_inf_bot, h_inf_top⟩
    intro V hV
    have hV_eq : V.toContinuousLinearMap.toLinearMap = V := by
      ext x
      rfl
    have hV_mem : V.toContinuousLinearMap ∈ frobBall := by
      change frobeniusNorm V.toContinuousLinearMap.toLinearMap ≤ R
      rwa [hV_eq]
    have h_both := h_mat_frob V.toContinuousLinearMap hV_mem
    rwa [hV_eq] at h_both

end UL

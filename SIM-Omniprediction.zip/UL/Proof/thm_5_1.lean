import UL.Stmt.lem_C_3
import UL.Stmt.thm_5_1
import UL.Stmt.thm_C_1
import UL.Proof.thm_5_1.H3_LiftAndTransfer
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_thm_5_1 (h_thm_C_1 : S_thm_C_1) (h_lem_C_3 : S_lem_C_3) : S_thm_5_1 := by
  unfold S_thm_5_1
  unfold S_thm_C_1 at h_thm_C_1
  unfold S_lem_C_3 at h_lem_C_3
  intro K hK
  obtain ⟨C₁, hC₁, hc1_main⟩ := h_thm_C_1 K hK
  obtain ⟨C₃, hC₃, hc3_main⟩ := h_lem_C_3 K hK
  refine ⟨Proof_thm_5_1.chooseCK K C₁ C₃, Proof_thm_5_1.one_le_chooseCK K C₁ C₃, ?_⟩
  intro d L R β lam M ε δ hL hR hβ hlam hM
  dsimp only
  intro hε_pos hε_le hδ_pos hδ_lt n hn_bound
  have hn1 : 1 ≤ n :=
    Proof_thm_5_1.sample_ge_one hK (Proof_thm_5_1.eight_le_chooseCK K C₁ C₃)
      hε_pos hε_le hδ_pos hδ_lt hn_bound
  by_cases hSmooth : (SmoothEntropyFamily K β lam M).Nonempty
  · let η : ℝ := ε / (24 * lam)
    have hη : 0 < η := by dsimp [η]; positivity
    obtain ⟨H_cand, hH_ne, hH_cand, hH_net⟩ :=
      Proof_thm_5_1.exists_finite_cand_net (d := d) hK L hR hβ hη
    obtain ⟨learner, hlearn_mem, hlearn_meas, hlearn_opt⟩ :=
      Proof_thm_5_1.exists_measurable_erm_learner hK hn1 hL hR hβ hlam hSmooth
        H_cand hH_ne hH_cand
    refine ⟨H_cand, learner, hH_cand, hlearn_mem, hlearn_meas, ?_⟩
    intro μ hμ_prob hL_ae
    haveI : MeasureTheory.IsProbabilityMeasure μ := hμ_prob
    have hn_c1 :=
      Proof_thm_5_1.sample_implies_thm_C_1 hK hC₁ hε_pos hε_le hδ_pos hδ_lt hn_bound
    obtain ⟨E_C1, hEC1_meas, hEC1_compl, hEC1_good⟩ :=
      Proof_thm_5_1.exists_c1_event (C₃ := C₃) hK hn1 hC₁ hL hR hβ hlam hM
        hε_pos hε_le hδ_pos hδ_lt hn_c1 hc1_main μ hL_ae
    obtain ⟨E_uc, hEuc_meas, hEuc_compl, hEuc_good⟩ :=
      Proof_thm_5_1.exists_uc_event hK hn1 hC₃ hL hR hβ hlam hM
        hε_pos hε_le hδ_pos hδ_lt hn_bound hc3_main μ hL_ae
    let μ_pi := MeasureTheory.Measure.pi (fun _ : Fin n => μ)
    let E_good := E_C1 ∩ E_uc
    have hEg_meas : MeasurableSet E_good := hEC1_meas.inter hEuc_meas
    have hEg_compl : μ_pi (E_goodᶜ) ≤ ENNReal.ofReal δ := by
      have hsub : E_goodᶜ ⊆ E_C1ᶜ ∪ E_ucᶜ := by
        intro S hS
        simp only [E_good, Set.mem_compl_iff, Set.mem_inter_iff, Set.mem_union] at hS ⊢
        tauto
      calc μ_pi (E_goodᶜ)
          ≤ μ_pi (E_C1ᶜ ∪ E_ucᶜ) := MeasureTheory.measure_mono hsub
        _ ≤ μ_pi (E_C1ᶜ) + μ_pi (E_ucᶜ) := MeasureTheory.measure_union_le _ _
        _ ≤ ENNReal.ofReal (δ / 2) + ENNReal.ofReal (δ / 2) :=
            add_le_add hEC1_compl hEuc_compl
        _ = ENNReal.ofReal δ := by
            rw [← ENNReal.ofReal_add (by positivity) (by positivity)]
            congr 1; ring
    have hEg_prob : ENNReal.ofReal (1 - δ) ≤ μ_pi E_good := by
      have h1 : ENNReal.ofReal (1 - δ) + ENNReal.ofReal δ = 1 := by
        rw [← ENNReal.ofReal_add (by linarith) hδ_pos.le, sub_add_cancel, ENNReal.ofReal_one]
      have h2 : μ_pi E_good + μ_pi (E_goodᶜ) = 1 := by
        rw [MeasureTheory.measure_add_measure_compl hEg_meas, MeasureTheory.measure_univ]
      have hineq : ENNReal.ofReal (1 - δ) + ENNReal.ofReal δ ≤
          μ_pi E_good + ENNReal.ofReal δ := by
        calc ENNReal.ofReal (1 - δ) + ENNReal.ofReal δ
            = μ_pi E_good + μ_pi (E_goodᶜ) := by rw [h1, h2]
          _ ≤ μ_pi E_good + ENNReal.ofReal δ := add_le_add le_rfl hEg_compl
      exact (ENNReal.add_le_add_iff_right ENNReal.ofReal_ne_top).mp hineq
    refine le_trans hEg_prob (MeasureTheory.measure_mono ?_)
    rintro S ⟨hS_c1, hS_uc⟩ Φ hΦ
    obtain ⟨h_S, hh_S, hpop_S⟩ := hEC1_good S hS_c1
    obtain ⟨h_tilde, hh_tilde_mem, hh_tilde_dist⟩ := hH_net h_S hh_S
    have hh_tilde : Proof_thm_5_1.IsCand R β h_tilde := hH_cand h_tilde hh_tilde_mem
    have hscore_tilde : Proof_thm_5_1.empScore L R β lam M h_tilde S ≤ ε / 2 := by
      refine Proof_thm_5_1.empScore_le_of_forall hSmooth h_tilde S fun Ψ hΨ => ?_
      have hpert := Proof_thm_5_1.popExcess_perturbation hK hβ hlam hη hL_ae
        hΨ hh_S hh_tilde hh_tilde_dist
      have h3lam : (3 * lam) * η = ε / 8 := by
        dsimp [η]; field_simp [hlam.ne']; ring
      have hpop_tilde : Proof_thm_5_1.popExcess μ R Ψ h_tilde ≤ 3 * ε / 8 := by
        linarith [hpop_S Ψ hΨ, hpert, h3lam]
      have huc_tilde := (abs_le.mp (hEuc_good S hS_uc h_tilde hh_tilde Ψ hΨ)).2
      linarith
    have hscore_lrn : Proof_thm_5_1.empScore L R β lam M (learner S) S ≤ ε / 2 :=
      le_trans (hlearn_opt S h_tilde hh_tilde_mem) hscore_tilde
    have hh_lrn : Proof_thm_5_1.IsCand R β (learner S) :=
      hH_cand (learner S) (hlearn_mem S)
    have hemp_lrn : Proof_thm_5_1.empExcessClamped L R Φ (learner S) S ≤ ε / 2 :=
      le_trans (Proof_thm_5_1.le_empScore hK hn1 hL hR hh_lrn hΦ S) hscore_lrn
    have huc_lrn := (abs_le.mp (hEuc_good S hS_uc (learner S) hh_lrn Φ hΦ)).1
    have hpop_lrn : Proof_thm_5_1.popExcess μ R Φ (learner S) ≤ ε := by
      linarith
    unfold Proof_thm_5_1.popExcess Proof_thm_5_1.popForeObj Proof_thm_5_1.popCompObj at hpop_lrn
    linarith
  · classical
    let h₀ := Proof_thm_5_1.defaultCand d K
    have hh₀ : Proof_thm_5_1.IsCand R β h₀ := Proof_thm_5_1.isCand_default hK hR hβ
    refine ⟨{h₀}, fun _ => h₀, ?_, fun _ => Finset.mem_singleton_self h₀, ?_, ?_⟩
    · intro h hh
      rw [Finset.mem_singleton.mp hh]
      exact hh₀
    · intro h _
      exact MeasurableSet.const (h₀ = h)
    · intro μ hμ_prob _
      haveI : MeasureTheory.IsProbabilityMeasure μ := hμ_prob
      have huniv : {S : Fin n → EuclideanSpace ℝ (Fin d) × Fin K |
          ∀ Φ ∈ SmoothEntropyFamily K β lam M,
            ∫ z, matchingLoss Φ (finiteCanonicalAction Φ (h₀.2 (h₀.1 z.1))) z.2 ∂μ ≤
              (⨅ V : {V : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K //
                  hilbertSchmidtNorm V ≤ R},
                ∫ z, matchingLoss Φ
                  ((V.1 z.1 : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) z.2 ∂μ) + ε} =
          Set.univ := by
        ext S
        simp only [Set.mem_setOf_eq, Set.mem_univ, iff_true]
        intro Φ hΦ
        exact (hSmooth ⟨Φ, hΦ⟩).elim
      rw [huniv, MeasureTheory.measure_univ]
      calc ENNReal.ofReal (1 - δ) ≤ ENNReal.ofReal 1 := ENNReal.ofReal_le_ofReal (by linarith)
        _ = 1 := ENNReal.ofReal_one

end UL

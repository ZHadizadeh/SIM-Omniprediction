import UL.Stmt.prop_C_5
import UL.Proof.prop_C_5.Race2.H1_QuadEntropy
import UL.Proof.prop_C_5.Race2.H2_Sphere
import UL.Proof.prop_C_5.Race2.H3_ChiSqProduct
import UL.Proof.prop_C_5.Race2.H4_Assouad
set_option autoImplicit false

namespace UL

/-- The minimax quadratic sample lower bound for a fixed feature marginal.
The guarantee quantifies over measurable, possibly randomized predictors. -/
def QuadraticSampleLower (K d : ℕ)
    (μ_X : MeasureTheory.Measure (EuclideanSpace ℝ (Fin d))) (ε : ℝ) : Prop :=
  let Φ_quad := UL.Proof_prop_C_5_Race2.quadEntropy K
  ∀ (n : ℕ)
    (Ξ : Type) [MeasurableSpace Ξ] (ν : MeasureTheory.Measure Ξ)
    [MeasureTheory.IsProbabilityMeasure ν]
    (p_hat : Ξ → (Fin n → EuclideanSpace ℝ (Fin d) × Fin K) →
      EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin K)),
    Measurable (fun q : Ξ × (Fin n → EuclideanSpace ℝ (Fin d) × Fin K) ×
        EuclideanSpace ℝ (Fin d) => p_hat q.1 q.2.1 q.2.2) →
    (∀ (ξ : Ξ) (S : Fin n → EuclideanSpace ℝ (Fin d) × Fin K)
        (x : EuclideanSpace ℝ (Fin d)),
      p_hat ξ S x ∈ Simplex K) →
    (∀ (μ : MeasureTheory.Measure (EuclideanSpace ℝ (Fin d) × Fin K)),
      MeasureTheory.IsProbabilityMeasure μ →
      μ.fst = μ_X →
      ENNReal.ofReal ((5 : ℝ) / 7) <
        (ν.prod (MeasureTheory.Measure.pi (fun _ : Fin n => μ)))
          { q : Ξ × (Fin n → EuclideanSpace ℝ (Fin d) × Fin K) |
            ∫ z, finiteCanonicalLoss Φ_quad (p_hat q.1 q.2 z.1) z.2 ∂μ ≤
              (⨅ V : {V : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K //
                  hilbertSchmidtNorm V ≤ 1},
                ∫ z, matchingLoss Φ_quad
                  ((V.1 z.1 : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) z.2 ∂μ) + ε }) →
    (1 / (1048576 * (K : ℝ) ^ 3)) / ε ^ 2 ≤ (n : ℝ)

/-- Only the norm and second moments of the features enter the testing argument. -/
theorem quadraticSampleLower_of_isotropic {K d : ℕ} (hK : 2 ≤ K)
    {ε : ℝ} (hε_pos : 0 < ε) (hε_le : ε ≤ 1 / (256 * (K : ℝ) ^ 2))
    (hd : d = Nat.floor (1 / (128 * (K : ℝ) ^ 2 * ε)))
    (μ_X : MeasureTheory.Measure (EuclideanSpace ℝ (Fin d)))
    [MeasureTheory.IsProbabilityMeasure μ_X] (hnorm : ∀ᵐ x ∂μ_X, ‖x‖ = 1)
    (hcov : ∀ i j : Fin d, ∫ x, x i * x j ∂μ_X = if i = j then 1 / (d : ℝ) else 0) :
    QuadraticSampleLower K d μ_X ε := by
  subst d
  obtain ⟨hd1, _, _, hn_bound, hregret_gt⟩ :=
    UL.Proof_prop_C_5_Race2.dim_and_sample_arithmetic hK hε_pos hε_le
  let d := Nat.floor (1 / (128 * (K : ℝ) ^ 2 * ε))
  intro n Ξ _instΞ ν _instν p_hat hp_meas hp_simp h_guar
  by_contra hn_not_ge
  have hn_lt : (n : ℝ) < (1 / (1048576 * (K : ℝ) ^ 3)) / ε ^ 2 :=
    lt_of_not_ge hn_not_ge
  have hn_le : (n : ℝ) ≤ (K : ℝ) * (d : ℝ) ^ 2 / 16 := hn_bound n hn_lt
  let P : (Fin d → Bool) →
      MeasureTheory.Measure (Ξ × (Fin n → EuclideanSpace ℝ (Fin d) × Fin K)) :=
    fun s => ν.prod
      (MeasureTheory.Measure.pi (fun _ : Fin n =>
        UL.Proof_prop_C_5_Race2.jointLaw K hK μ_X s))
  have hP_prob : ∀ s : Fin d → Bool, MeasureTheory.IsProbabilityMeasure (P s) := by
    intro s
    haveI := UL.Proof_prop_C_5_Race2.jointLaw_isProb hK μ_X s
    dsimp [P]
    infer_instance
  obtain ⟨s_star, hs_star⟩ := UL.Proof_prop_C_5_Race2.assouad_reverse_markov hd1 P hP_prob
    (fun q i => UL.Proof_prop_C_5_Race2.estCoord K hK μ_X p_hat q i)
    (fun i => UL.Proof_prop_C_5_Race2.measurable_estCoord hK μ_X hp_meas i)
    (fun s i => UL.Proof_prop_C_5_Race2.prod_jointLaw_tv_le_quarter
      hK hd1 hn_le μ_X hnorm hcov Ξ ν s i)
  let μ_star := UL.Proof_prop_C_5_Race2.jointLaw K hK μ_X s_star
  have hμ_prob : MeasureTheory.IsProbabilityMeasure μ_star :=
    UL.Proof_prop_C_5_Race2.jointLaw_isProb hK μ_X s_star
  have hμ_fst : μ_star.fst = μ_X :=
    UL.Proof_prop_C_5_Race2.jointLaw_fst_eq hK μ_X s_star
  have h_gt := h_guar μ_star hμ_prob hμ_fst
  have hsub :
      { q : Ξ × (Fin n → EuclideanSpace ℝ (Fin d) × Fin K) |
        ∫ z, finiteCanonicalLoss (UL.Proof_prop_C_5_Race2.quadEntropy K)
            (p_hat q.1 q.2 z.1) z.2 ∂μ_star ≤
          (⨅ V : {V : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K //
              hilbertSchmidtNorm V ≤ 1},
            ∫ z, matchingLoss (UL.Proof_prop_C_5_Race2.quadEntropy K)
              ((V.1 z.1 : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) z.2 ∂μ_star) + ε } ⊆
      { q : Ξ × (Fin n → EuclideanSpace ℝ (Fin d) × Fin K) |
        (d : ℝ) / 8 ≤
          ((Finset.univ.filter (fun i : Fin d =>
            decide (0 ≤ UL.Proof_prop_C_5_Race2.estCoord K hK μ_X p_hat q i) ≠
              s_star i)).card : ℝ) }ᶜ := by
    intro q hq hbad
    have hexcess := UL.Proof_prop_C_5_Race2.predictor_excess_risk_lower hK hd1 μ_X hnorm
      (fun hg C hgb w =>
        UL.Proof_prop_C_5_Race2.isotropic_bessel_bound hd1 μ_X hnorm hcov hg C hgb w)
      (fun hp y => UL.Proof_prop_C_5_Race2.finiteCanonicalLoss_quadEntropy_eq hK hp y)
      (fun hp y => UL.Proof_prop_C_5_Race2.finiteCanonicalLoss_quadEntropy_abs_le hK hp y)
      (fun hp hη => UL.Proof_prop_C_5_Race2.cond_regret_quadEntropy hK hp hη)
      (UL.Proof_prop_C_5_Race2.matchingLoss_quadEntropy_ge_neg_two hK)
      (fun hη y =>
        UL.Proof_prop_C_5_Race2.matchingLoss_quadEntropy_eq_finiteCanonicalLoss hK hη y)
      (UL.Proof_prop_C_5_Race2.hilbertSchmidtNorm_scoreOp_le_one hK hd1)
      (UL.Proof_prop_C_5_Race2.condProb_mem_simplex hK)
      (UL.Proof_prop_C_5_Race2.continuous_condProb hK)
      (fun s => UL.Proof_prop_C_5_Race2.condProb_sub_uniform_of_norm_le_one hK hd1 s)
      (UL.Proof_prop_C_5_Race2.jointLaw_isProb hK μ_X)
      (UL.Proof_prop_C_5_Race2.jointLaw_fst_eq hK μ_X)
      (fun s => UL.Proof_prop_C_5_Race2.integral_jointLaw_eq hK μ_X s)
      hp_meas hp_simp s_star q
    have hgt_ε : ε < ((UL.Proof_prop_C_5_Race2.scaleA K) ^ 2 / (2 * (d : ℝ) ^ 2)) *
        (UL.Proof_prop_C_5_Race2.hammingErr K hK μ_X p_hat s_star q : ℝ) :=
      hregret_gt _ hbad
    have hq' :
        (∫ z, finiteCanonicalLoss (UL.Proof_prop_C_5_Race2.quadEntropy K)
            (p_hat q.1 q.2 z.1) z.2 ∂μ_star) -
          (⨅ V : {V : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K //
              hilbertSchmidtNorm V ≤ 1},
            ∫ z, matchingLoss (UL.Proof_prop_C_5_Race2.quadEntropy K)
              ((V.1 z.1 : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) z.2 ∂μ_star) ≤ ε :=
      sub_le_iff_le_add'.mpr hq
    exact lt_irrefl ε (lt_of_lt_of_le hgt_ε (hexcess.trans hq'))
  have hle := (MeasureTheory.measure_mono hsub).trans hs_star
  exact not_lt_of_ge hle h_gt

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_prop_C_5 : S_prop_C_5 := by
  unfold S_prop_C_5
  intro K hK
  have hK_pos : (0 : ℝ) < (K : ℝ) := Nat.cast_pos.mpr (by omega)
  refine ⟨1, 1, 1, 1, 1,
    1 / (256 * (K : ℝ) ^ 2),
    1 / (256 * (K : ℝ) ^ 2),
    1 / (128 * (K : ℝ) ^ 2),
    1 / (1048576 * (K : ℝ) ^ 3),
    zero_lt_one, zero_lt_one, zero_lt_one, zero_lt_one, zero_lt_one,
    by positivity, by positivity, ?_, by positivity,
    UL.Proof_prop_C_5_Race2.quadEntropy_mem_smoothEntropyFamily hK, ?_⟩
  · exact one_div_le_one_div_of_le (by positivity) (by nlinarith)
  · intro ε hε_pos hε_le
    obtain ⟨hd1, hc1_le_d, hd_le_c2, hn_bound, hregret_gt⟩ :=
      UL.Proof_prop_C_5_Race2.dim_and_sample_arithmetic hK hε_pos hε_le
    set d := Nat.floor (1 / (128 * (K : ℝ) ^ 2 * ε))
    let μ_X := UL.Proof_prop_C_5_Race2.sphereProb d
    haveI : MeasureTheory.IsProbabilityMeasure μ_X :=
      UL.Proof_prop_C_5_Race2.sphereProb_isProb hd1
    have hnorm : ∀ᵐ x ∂μ_X, ‖x‖ = 1 :=
      UL.Proof_prop_C_5_Race2.sphereProb_norm_eq_one_ae hd1
    have hsym : HasSphericalFeatureSymmetry μ_X :=
      UL.Proof_prop_C_5_Race2.sphereProb_hasSphericalFeatureSymmetry hd1
    refine ⟨d, μ_X, hd1, hc1_le_d, hd_le_c2, inferInstance, hnorm,
      hnorm.mono (fun _ hx => hx.le), hsym, ?_⟩
    exact quadraticSampleLower_of_isotropic hK hε_pos hε_le rfl μ_X hnorm
      (UL.Proof_prop_C_5_Race2.spherical_coord_cov hd1 μ_X hnorm hsym)

end UL

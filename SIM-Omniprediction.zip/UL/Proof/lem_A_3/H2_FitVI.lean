import UL.Proof.lem_A_3.H1_SimplexProj
set_option autoImplicit false

namespace UL.Proof_lem_A_3

lemma integrable_of_aesm_bounded {Ω E : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ]
    [NormedAddCommGroup E] {f : Ω → E}
    (hf_aesm : MeasureTheory.AEStronglyMeasurable f μ)
    {C : ℝ} (hf_bdd : ∀ ω, ‖f ω‖ ≤ C) :
    MeasureTheory.Integrable f μ :=
  MeasureTheory.Integrable.of_bound hf_aesm C
    (Filter.Eventually.of_forall hf_bdd)

/-- Least-squares variational inequality along any 1-Lipschitz map `T` into `Simplex K`. -/
lemma fit_vi {Ω : Type*} [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    {K : ℕ} {B : ℝ} (hB : 0 < B)
    {S : Ω → ZeroSumSubspace K} {Y : Ω → Fin K}
    (hS_meas : Measurable S) (hY_meas : Measurable Y)
    {P : Ω → EuclideanSpace ℝ (Fin K)}
    (hFit : IsLipschitzLSFit μ B S Y P)
    (T : EuclideanSpace ℝ (Fin K) → EuclideanSpace ℝ (Fin K))
    (hT_simp : ∀ x, T x ∈ Simplex K)
    (hT_nonexp : ∀ x₁ x₂, ‖T x₁ - T x₂‖ ≤ ‖x₁ - x₂‖) :
    0 ≤ ∫ ω, inner ℝ (fitResidual P Y ω) (T (P ω) - P ω) ∂μ := by
  obtain ⟨ρ, ⟨_, ⟨hB0, hρ_lip, hρ_simp⟩, hρ_min⟩, hP_eq⟩ := hFit
  have hT_cont : Continuous T := by
    rw [Metric.continuous_iff]
    intro x ε hε
    refine ⟨ε, hε, fun y hy => ?_⟩
    rw [dist_eq_norm] at hy ⊢
    exact lt_of_le_of_lt (hT_nonexp y x) hy
  have hP_meas : Measurable P := by
    rw [hP_eq]
    exact hρ_lip.continuous.measurable.comp hS_meas
  have hZ_meas : Measurable (oneHotLabel Y) :=
    Measurable.of_discrete.comp hY_meas
  have hr_meas : Measurable (fitResidual P Y) := hP_meas.sub hZ_meas
  have hQ_meas : Measurable (fun ω => T (P ω)) := hT_cont.measurable.comp hP_meas
  have hP_simp : ∀ ω, P ω ∈ Simplex K := fun ω => by rw [hP_eq]; exact hρ_simp (S ω)
  have hZ_simp : ∀ ω, oneHotLabel Y ω ∈ Simplex K := fun ω => oneHotVec_mem_simplex (Y ω)
  have hr_bdd : ∀ ω, ‖fitResidual P Y ω‖ ≤ 2 := by
    intro ω
    calc ‖P ω - oneHotLabel Y ω‖
        ≤ ‖P ω‖ + ‖oneHotLabel Y ω‖ := norm_sub_le _ _
      _ ≤ 1 + 1 := add_le_add (norm_le_one_of_mem_simplex (hP_simp ω))
                     (norm_le_one_of_mem_simplex (hZ_simp ω))
      _ = 2 := by norm_num
  have hdiff_bdd : ∀ ω, ‖T (P ω) - P ω‖ ≤ 2 := by
    intro ω
    calc ‖T (P ω) - P ω‖
        ≤ ‖T (P ω)‖ + ‖P ω‖ := norm_sub_le _ _
      _ ≤ 1 + 1 := add_le_add (norm_le_one_of_mem_simplex (hT_simp (P ω)))
                     (norm_le_one_of_mem_simplex (hP_simp ω))
      _ = 2 := by norm_num
  have hr_aesm : MeasureTheory.AEStronglyMeasurable (fitResidual P Y) μ :=
    hr_meas.aestronglyMeasurable
  have hdiff_aesm : MeasureTheory.AEStronglyMeasurable (fun ω => T (P ω) - P ω) μ :=
    (hQ_meas.sub hP_meas).aestronglyMeasurable
  have hint_r2 : MeasureTheory.Integrable (fun ω => ‖fitResidual P Y ω‖ ^ 2) μ := by
    refine integrable_of_aesm_bounded μ
      ((continuous_pow 2).comp_aestronglyMeasurable hr_aesm.norm)
      (C := 4) (fun ω => ?_)
    rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
    nlinarith [hr_bdd ω, norm_nonneg (fitResidual P Y ω)]
  have hint_inner : MeasureTheory.Integrable
      (fun ω => inner ℝ (fitResidual P Y ω) (T (P ω) - P ω)) μ := by
    refine integrable_of_aesm_bounded μ
      ((continuous_inner (𝕜 := ℝ)).comp_aestronglyMeasurable (hr_aesm.prodMk hdiff_aesm))
      (C := 4) (fun ω => ?_)
    rw [Real.norm_eq_abs]
    calc |inner ℝ (fitResidual P Y ω) (T (P ω) - P ω)|
        ≤ ‖fitResidual P Y ω‖ * ‖T (P ω) - P ω‖ := abs_real_inner_le_norm _ _
      _ ≤ 2 * 2 := mul_le_mul (hr_bdd ω) (hdiff_bdd ω) (norm_nonneg _) (by norm_num)
      _ = 4 := by norm_num
  have hint_d2 : MeasureTheory.Integrable (fun ω => ‖T (P ω) - P ω‖ ^ 2) μ := by
    refine integrable_of_aesm_bounded μ
      ((continuous_pow 2).comp_aestronglyMeasurable hdiff_aesm.norm)
      (C := 4) (fun ω => ?_)
    rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
    nlinarith [hdiff_bdd ω, norm_nonneg (T (P ω) - P ω)]
  by_contra hneg
  push_neg at hneg
  let I : ℝ := ∫ ω, inner ℝ (fitResidual P Y ω) (T (P ω) - P ω) ∂μ
  let D : ℝ := ∫ ω, ‖T (P ω) - P ω‖ ^ 2 ∂μ
  have hI_neg : I < 0 := hneg
  have hD_nonneg : 0 ≤ D := MeasureTheory.integral_nonneg (fun ω => sq_nonneg _)
  let t : ℝ := min (1 / 2) ((-I) / (D + 1))
  have ht_pos : 0 < t := lt_min (by norm_num) (div_pos (by linarith) (by positivity))
  have ht_lt1 : t < 1 := lt_of_le_of_lt (min_le_left _ _) (by norm_num)
  have ht_le : t ≤ (-I) / (D + 1) := min_le_right _ _
  let ρ_t : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) :=
    fun s => (1 - t) • ρ s + t • T (ρ s)
  have hρt_mem : ρ_t ∈ LipschitzSimplexMaps K B := by
    refine ⟨hB0, ?_, ?_⟩
    · rw [lipschitzWith_iff_dist_le_mul]
      intro s₁ s₂
      have hρ_d : ‖ρ s₁ - ρ s₂‖ ≤ (Real.toNNReal B : ℝ) * ‖s₁ - s₂‖ := by
        simpa [dist_eq_norm] using lipschitzWith_iff_dist_le_mul.mp hρ_lip s₁ s₂
      have hT_d : ‖T (ρ s₁) - T (ρ s₂)‖ ≤ (Real.toNNReal B : ℝ) * ‖s₁ - s₂‖ :=
        le_trans (hT_nonexp (ρ s₁) (ρ s₂)) hρ_d
      rw [dist_eq_norm, dist_eq_norm]
      have hsub : ρ_t s₁ - ρ_t s₂ = (1 - t) • (ρ s₁ - ρ s₂) + t • (T (ρ s₁) - T (ρ s₂)) := by
        dsimp [ρ_t]
        ext j
        simp only [PiLp.sub_apply, PiLp.add_apply, PiLp.smul_apply, smul_eq_mul]
        ring
      rw [hsub]
      calc ‖(1 - t) • (ρ s₁ - ρ s₂) + t • (T (ρ s₁) - T (ρ s₂))‖
          ≤ ‖(1 - t) • (ρ s₁ - ρ s₂)‖ + ‖t • (T (ρ s₁) - T (ρ s₂))‖ := norm_add_le _ _
        _ = (1 - t) * ‖ρ s₁ - ρ s₂‖ + t * ‖T (ρ s₁) - T (ρ s₂)‖ := by
            rw [norm_smul, norm_smul, Real.norm_eq_abs, Real.norm_eq_abs,
              abs_of_pos (by linarith), abs_of_pos ht_pos]
        _ ≤ (1 - t) * ((Real.toNNReal B : ℝ) * ‖s₁ - s₂‖) +
              t * ((Real.toNNReal B : ℝ) * ‖s₁ - s₂‖) :=
            add_le_add (mul_le_mul_of_nonneg_left hρ_d (by linarith))
              (mul_le_mul_of_nonneg_left hT_d (le_of_lt ht_pos))
        _ = (Real.toNNReal B : ℝ) * ‖s₁ - s₂‖ := by ring
    · intro s
      exact simplex_convex K (hρ_simp s) (hT_simp (ρ s)) (by linarith) (le_of_lt ht_pos) (by ring)
  have hmin_le : lsFitRisk μ S Y ρ ≤ lsFitRisk μ S Y ρ_t := hρ_min hρt_mem
  have hpt : ∀ ω, ‖ρ_t (S ω) - oneHotLabel Y ω‖ ^ 2 =
      ‖fitResidual P Y ω‖ ^ 2 +
        (2 * t * inner ℝ (fitResidual P Y ω) (T (P ω) - P ω) +
          t ^ 2 * ‖T (P ω) - P ω‖ ^ 2) := by
    intro ω
    have hvec : ρ_t (S ω) - oneHotLabel Y ω =
        fitResidual P Y ω + t • (T (P ω) - P ω) := by
      dsimp [ρ_t, fitResidual]
      rw [hP_eq]
      ext j
      simp only [PiLp.sub_apply, PiLp.add_apply, PiLp.smul_apply, smul_eq_mul]
      ring
    rw [hvec, norm_add_smul_sq]
    ring
  have hrisk_t : lsFitRisk μ S Y ρ_t = lsFitRisk μ S Y ρ + (2 * t * I + t ^ 2 * D) := by
    unfold lsFitRisk
    simp_rw [hpt]
    have h1 : MeasureTheory.Integrable
        (fun ω => 2 * t * inner ℝ (fitResidual P Y ω) (T (P ω) - P ω)) μ :=
      hint_inner.const_mul (2 * t)
    have h2 : MeasureTheory.Integrable
        (fun ω => t ^ 2 * ‖T (P ω) - P ω‖ ^ 2) μ :=
      hint_d2.const_mul (t ^ 2)
    have h12 : MeasureTheory.Integrable
        (fun ω => 2 * t * inner ℝ (fitResidual P Y ω) (T (P ω) - P ω) +
          t ^ 2 * ‖T (P ω) - P ω‖ ^ 2) μ :=
      h1.add h2
    rw [MeasureTheory.integral_add hint_r2 h12, MeasureTheory.integral_add h1 h2,
      MeasureTheory.integral_const_mul, MeasureTheory.integral_const_mul]
    have hr_eq : (∫ ω, ‖ρ (S ω) - oneHotLabel Y ω‖ ^ 2 ∂μ) =
        ∫ ω, ‖fitResidual P Y ω‖ ^ 2 ∂μ := by
      congr 1
      ext ω
      rw [fitResidual, hP_eq]
    rw [hr_eq]
  have hineq1 : 0 ≤ 2 * t * I + t ^ 2 * D := by linarith
  have hineq2 : 2 * (-I) ≤ t * D := by nlinarith
  have hineq3 : t * (D + 1) ≤ -I := (le_div_iff₀ (by positivity)).mp ht_le
  have hineq4 : t * D < t * (D + 1) := by nlinarith
  linarith

/-- Lemma B.3 gives `P ω j = 0 → oneHotLabel Y ω j = 0` almost surely. -/
lemma support_ae {Ω : Type*} [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    {K : ℕ} (hK : 2 ≤ K) {B : ℝ} (hB : 0 < B)
    {S : Ω → ZeroSumSubspace K} {Y : Ω → Fin K}
    (hS_meas : Measurable S) (hY_meas : Measurable Y)
    {P : Ω → EuclideanSpace ℝ (Fin K)}
    (hFit : IsLipschitzLSFit μ B S Y P) :
    ∀ j : Fin K, ∀ᵐ ω ∂μ, P ω j = 0 → oneHotLabel Y ω j = 0 := by
  obtain ⟨ρ, ⟨_, ⟨_, hρ_lip, hρ_simp⟩, _⟩, hP_eq⟩ := id hFit
  have hP_meas : Measurable P := by
    rw [hP_eq]
    exact hρ_lip.continuous.measurable.comp hS_meas
  have hZ_meas : Measurable (oneHotLabel Y) := Measurable.of_discrete.comp hY_meas
  have hr_meas : Measurable (fitResidual P Y) := hP_meas.sub hZ_meas
  have hP_simp : ∀ ω, P ω ∈ Simplex K := fun ω => by rw [hP_eq]; exact hρ_simp (S ω)
  have hZ_simp : ∀ ω, oneHotLabel Y ω ∈ Simplex K := fun ω => oneHotVec_mem_simplex (Y ω)
  have hr_bdd : ∀ ω, ‖fitResidual P Y ω‖ ≤ 2 := by
    intro ω
    calc ‖P ω - oneHotLabel Y ω‖
        ≤ ‖P ω‖ + ‖oneHotLabel Y ω‖ := norm_sub_le _ _
      _ ≤ 1 + 1 := add_le_add (norm_le_one_of_mem_simplex (hP_simp ω))
                     (norm_le_one_of_mem_simplex (hZ_simp ω))
      _ = 2 := by norm_num
  have hK_pos : (0 : ℝ) < (K : ℝ) := by exact_mod_cast (by omega : 0 < K)
  let ε : ℕ → ℝ := fun n => 1 / (((n : ℝ) + 2) * (K : ℝ))
  have hε_pos : ∀ n : ℕ, 0 < ε n := fun n => by dsimp [ε]; positivity
  have hε_lt : ∀ n : ℕ, (K : ℝ) * ε n < 1 := by
    intro n
    have h1 : (K : ℝ) * ε n = 1 / ((n : ℝ) + 2) := by
      dsimp [ε]
      field_simp
    rw [h1, div_lt_one (by positivity)]
    linarith [Nat.cast_nonneg (α := ℝ) n]
  let f : ℕ → Ω → ℝ := fun n ω =>
    inner ℝ (fitResidual P Y ω) ((1 / ε n) • (T_eps K (ε n) (P ω) - P ω))
  let g : Ω → ℝ := fun ω =>
    -((K : ℝ) / ((Finset.univ.filter (fun i : Fin K => 0 < P ω i)).card : ℝ)) *
      ∑ j ∈ Finset.univ.filter (fun i : Fin K => P ω i = 0), oneHotLabel Y ω j
  have hf_aesm : ∀ n : ℕ, MeasureTheory.AEStronglyMeasurable (f n) μ := by
    intro n
    have hTn_cont : Continuous (T_eps K (ε n)) := by
      rw [Metric.continuous_iff]
      intro x δ hδ
      refine ⟨δ, hδ, fun y hy => ?_⟩
      rw [dist_eq_norm] at hy ⊢
      exact lt_of_le_of_lt (T_eps_nonexpansive hK (hε_lt n) y x) hy
    have hdiff_aesm : MeasureTheory.AEStronglyMeasurable
        (fun ω => (1 / ε n) • (T_eps K (ε n) (P ω) - P ω)) μ :=
      (((hTn_cont.measurable.comp hP_meas).sub hP_meas).const_smul (1 / ε n)).aestronglyMeasurable
    exact (continuous_inner (𝕜 := ℝ)).comp_aestronglyMeasurable
      (hr_meas.aestronglyMeasurable.prodMk hdiff_aesm)
  have hf_bdd : ∀ (n : ℕ) (ω : Ω), ‖f n ω‖ ≤ 4 * (K : ℝ) := by
    intro n ω
    rw [Real.norm_eq_abs]
    have hT_bdd := T_eps_sub_self_norm_le hK (hε_pos n) (hε_lt n) (hP_simp ω)
    have hε_ne : ε n ≠ 0 := ne_of_gt (hε_pos n)
    calc |inner ℝ (fitResidual P Y ω) ((1 / ε n) • (T_eps K (ε n) (P ω) - P ω))|
        ≤ ‖fitResidual P Y ω‖ * ‖(1 / ε n) • (T_eps K (ε n) (P ω) - P ω)‖ :=
          abs_real_inner_le_norm _ _
      _ = ‖fitResidual P Y ω‖ * ((1 / ε n) * ‖T_eps K (ε n) (P ω) - P ω‖) := by
          rw [norm_smul, Real.norm_eq_abs, abs_of_pos (one_div_pos.mpr (hε_pos n))]
      _ ≤ 2 * ((1 / ε n) * (2 * (K : ℝ) * ε n)) := by
          refine mul_le_mul (hr_bdd ω) ?_ (by positivity) (by norm_num)
          exact mul_le_mul_of_nonneg_left hT_bdd (le_of_lt (one_div_pos.mpr (hε_pos n)))
      _ = 4 * (K : ℝ) := by field_simp; ring
  have hf_int_nonneg : ∀ n : ℕ, 0 ≤ ∫ ω, f n ω ∂μ := by
    intro n
    have hvi := fit_vi μ hB hS_meas hY_meas hFit (T_eps K (ε n))
      (T_eps_mem_simplex hK (hε_pos n) (hε_lt n))
      (T_eps_nonexpansive hK (hε_lt n))
    have heq : (∫ ω, f n ω ∂μ) =
        (1 / ε n) * ∫ ω, inner ℝ (fitResidual P Y ω) (T_eps K (ε n) (P ω) - P ω) ∂μ := by
      rw [← MeasureTheory.integral_const_mul]
      congr 1
      ext ω
      dsimp [f]
      rw [inner_smul_right]
    rw [heq]
    exact mul_nonneg (le_of_lt (one_div_pos.mpr (hε_pos n))) hvi
  have hf_tendsto : ∀ ω : Ω, Filter.Tendsto (fun n => f n ω) Filter.atTop (nhds (g ω)) := by
    intro ω
    let J := Finset.univ.filter (fun i : Fin K => 0 < P ω i)
    let s : ℝ := (J.card : ℝ)
    have hJ_ne : J.Nonempty := posSupport_nonempty (hP_simp ω)
    have hs_pos : 0 < s := by dsimp [s]; exact_mod_cast Finset.card_pos.mpr hJ_ne
    let m : ℝ := J.inf' hJ_ne (fun j => P ω j)
    have hm_pos : 0 < m := by
      rw [Finset.lt_inf'_iff]
      intro j hj
      exact (Finset.mem_filter.mp hj).2
    obtain ⟨N, hN⟩ := exists_nat_ge (1 / (s * m))
    refine tendsto_atTop_of_eventually_const (i₀ := N) (fun n hn => ?_)
    have hsmall : ∀ j ∈ J, ((K : ℝ) / s) * ε n ≤ P ω j := by
      intro j hj
      have hm_le : m ≤ P ω j := Finset.inf'_le (fun i => P ω i) hj
      have hKe : ((K : ℝ) / s) * ε n = 1 / (s * ((n : ℝ) + 2)) := by
        dsimp [ε]
        field_simp
      rw [hKe]
      have hNle : (1 : ℝ) / (s * m) ≤ (n : ℝ) + 2 := by
        have hn_cast : (N : ℝ) ≤ (n : ℝ) := Nat.cast_le.mpr hn
        linarith
      have hsm_le : 1 ≤ (s * m) * ((n : ℝ) + 2) := by
        have h1 := (div_le_iff₀ (mul_pos hs_pos hm_pos)).mp hNle
        linarith
      have hle_m : 1 / (s * ((n : ℝ) + 2)) ≤ m := by
        rw [div_le_iff₀ (by positivity)]
        linarith
      exact le_trans hle_m hm_le
    exact T_eps_inner_eq_of_small hK (hP_simp ω) (hZ_simp ω) (hε_pos n) (hε_lt n) hsmall
  have hdct : Filter.Tendsto (fun n => ∫ ω, f n ω ∂μ) Filter.atTop (nhds (∫ ω, g ω ∂μ)) := by
    refine MeasureTheory.tendsto_integral_of_dominated_convergence
      (fun _ : Ω => 4 * (K : ℝ))
      hf_aesm
      (MeasureTheory.integrable_const _)
      (fun n => Filter.Eventually.of_forall (hf_bdd n))
      (Filter.Eventually.of_forall hf_tendsto)
  have hg_int_nonneg : 0 ≤ ∫ ω, g ω ∂μ := ge_of_tendsto' hdct hf_int_nonneg
  have hg_aesm : MeasureTheory.AEStronglyMeasurable g μ :=
    aestronglyMeasurable_of_tendsto_ae Filter.atTop
      hf_aesm
      (Filter.Eventually.of_forall hf_tendsto)
  have hg_bdd : ∀ ω : Ω, ‖g ω‖ ≤ 4 * (K : ℝ) := by
    intro ω
    exact le_of_tendsto (continuous_norm.continuousAt.tendsto.comp (hf_tendsto ω))
      (Filter.Eventually.of_forall (fun n => hf_bdd n ω))
  have hnegg_int : MeasureTheory.Integrable (fun ω => -g ω) μ :=
    (MeasureTheory.Integrable.of_bound hg_aesm (4 * (K : ℝ))
      (Filter.Eventually.of_forall hg_bdd)).neg
  have hnegg_nonneg : ∀ ω : Ω, 0 ≤ -g ω := by
    intro ω
    dsimp [g]
    rw [neg_mul, neg_neg]
    refine mul_nonneg (by positivity) (Finset.sum_nonneg (fun j _ => (hZ_simp ω).1 j))
  have hnegg_int_zero : ∫ ω, (-g ω) ∂μ = 0 := by
    have hle : ∫ ω, (-g ω) ∂μ ≤ 0 := by
      rw [MeasureTheory.integral_neg]
      linarith
    have hge : 0 ≤ ∫ ω, (-g ω) ∂μ := MeasureTheory.integral_nonneg hnegg_nonneg
    linarith
  have hae_zero : (fun ω => -g ω) =ᵐ[μ] 0 :=
    (MeasureTheory.integral_eq_zero_iff_of_nonneg_ae
      (Filter.Eventually.of_forall hnegg_nonneg) hnegg_int).mp hnegg_int_zero
  intro j
  filter_upwards [hae_zero] with ω hω hpj0
  change -g ω = 0 at hω
  dsimp [g] at hω
  rw [neg_mul, neg_neg] at hω
  have hs_pos : 0 < ((Finset.univ.filter (fun i : Fin K => 0 < P ω i)).card : ℝ) := by
    exact_mod_cast Finset.card_pos.mpr (posSupport_nonempty (hP_simp ω))
  have hcoeff_ne : (K : ℝ) / ((Finset.univ.filter (fun i : Fin K => 0 < P ω i)).card : ℝ) ≠ 0 :=
    div_ne_zero (ne_of_gt hK_pos) (ne_of_gt hs_pos)
  have hsum0 : ∑ i ∈ Finset.univ.filter (fun i : Fin K => P ω i = 0), oneHotLabel Y ω i = 0 := by
    rcases mul_eq_zero.mp hω with h1 | h2
    · exact absurd h1 hcoeff_ne
    · exact h2
  have hj_mem : j ∈ Finset.univ.filter (fun i : Fin K => P ω i = 0) :=
    Finset.mem_filter.mpr ⟨Finset.mem_univ j, hpj0⟩
  exact (Finset.sum_eq_zero_iff_of_nonneg (fun i _ => (hZ_simp ω).1 i)).mp hsum0 j hj_mem

/-- Part 2 of Lemma A.3: affine span membership and directional derivative limit. -/
lemma face_derivative {Ω : Type*} [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    {K : ℕ} (hK : 2 ≤ K) {B : ℝ} (hB : 0 < B)
    {S : Ω → ZeroSumSubspace K} {Y : Ω → Fin K}
    (hS_meas : Measurable S) (hY_meas : Measurable Y)
    {P : Ω → EuclideanSpace ℝ (Fin K)}
    (hFit : IsLipschitzLSFit μ B S Y P)
    (v : Ω → ZeroSumSubspace K)
    (hv : MeasureTheory.Integrable v μ) :
    (∀ (ω : Ω) (t : ℝ),
      P ω + t • (v ω : EuclideanSpace ℝ (Fin K)) ∈ affineSpan ℝ (Simplex K)) ∧
    Filter.Tendsto
      (fun t : ℝ =>
        ∫ ω, inner ℝ (fitResidual P Y ω)
          (((1 : ℝ) / t) •
            (projSimplexDef K (P ω + t • (v ω : EuclideanSpace ℝ (Fin K))) - P ω)) ∂μ)
      (nhdsWithin (0 : ℝ) (Set.Ioi 0))
      (nhds (∫ ω, inner ℝ (fitResidual P Y ω) (v ω : EuclideanSpace ℝ (Fin K)) ∂μ)) := by
  obtain ⟨ρ, ⟨_, ⟨_, hρ_lip, hρ_simp⟩, _⟩, hP_eq⟩ := id hFit
  have hP_simp : ∀ ω, P ω ∈ Simplex K := fun ω => by rw [hP_eq]; exact hρ_simp (S ω)
  have hZ_simp : ∀ ω, oneHotLabel Y ω ∈ Simplex K := fun ω => oneHotVec_mem_simplex (Y ω)
  refine ⟨fun ω t => affineSpan_simplex_mem hK (hP_simp ω) (v ω).2 t, ?_⟩
  have hP_meas : Measurable P := by
    rw [hP_eq]
    exact hρ_lip.continuous.measurable.comp hS_meas
  have hZ_meas : Measurable (oneHotLabel Y) := Measurable.of_discrete.comp hY_meas
  have hr_aesm : MeasureTheory.AEStronglyMeasurable (fitResidual P Y) μ :=
    (hP_meas.sub hZ_meas).aestronglyMeasurable
  have hP_aesm : MeasureTheory.AEStronglyMeasurable P μ := hP_meas.aestronglyMeasurable
  have hv_aesm : MeasureTheory.AEStronglyMeasurable
      (fun ω => (v ω : EuclideanSpace ℝ (Fin K))) μ :=
    continuous_subtype_val.comp_aestronglyMeasurable hv.aestronglyMeasurable
  have hr_bdd : ∀ ω, ‖fitResidual P Y ω‖ ≤ 2 := by
    intro ω
    calc ‖P ω - oneHotLabel Y ω‖
        ≤ ‖P ω‖ + ‖oneHotLabel Y ω‖ := norm_sub_le _ _
      _ ≤ 1 + 1 := add_le_add (norm_le_one_of_mem_simplex (hP_simp ω))
                     (norm_le_one_of_mem_simplex (hZ_simp ω))
      _ = 2 := by norm_num
  let F : ℝ → Ω → ℝ := fun t ω =>
    inner ℝ (fitResidual P Y ω)
      (((1 : ℝ) / t) • (projSimplexDef K (P ω + t • (v ω : EuclideanSpace ℝ (Fin K))) - P ω))
  let f : Ω → ℝ := fun ω => inner ℝ (fitResidual P Y ω) (v ω : EuclideanSpace ℝ (Fin K))
  have hF_aesm : ∀ t : ℝ, MeasureTheory.AEStronglyMeasurable (F t) μ := by
    intro t
    have hpt : MeasureTheory.AEStronglyMeasurable
        (fun ω => P ω + t • (v ω : EuclideanSpace ℝ (Fin K))) μ :=
      hP_aesm.add (hv_aesm.const_smul t)
    have hproj : MeasureTheory.AEStronglyMeasurable
        (fun ω => projSimplexDef K (P ω + t • (v ω : EuclideanSpace ℝ (Fin K)))) μ :=
      (projSimplex_continuous hK).comp_aestronglyMeasurable hpt
    have hdiff : MeasureTheory.AEStronglyMeasurable
        (fun ω => ((1 : ℝ) / t) •
          (projSimplexDef K (P ω + t • (v ω : EuclideanSpace ℝ (Fin K))) - P ω)) μ :=
      (hproj.sub hP_aesm).const_smul ((1 : ℝ) / t)
    exact continuous_inner.comp_aestronglyMeasurable (hr_aesm.prodMk hdiff)
  have hF_bdd : ∀ᶠ t : ℝ in nhdsWithin 0 (Set.Ioi 0), ∀ᵐ ω ∂μ, ‖F t ω‖ ≤ 2 * ‖v ω‖ := by
    filter_upwards [self_mem_nhdsWithin] with t ht_pos
    change 0 < t at ht_pos
    refine Filter.Eventually.of_forall (fun ω => ?_)
    rw [Real.norm_eq_abs]
    have hp_id : projSimplexDef K (P ω) = P ω := projSimplex_eq_self hK (hP_simp ω)
    have hproj_le : ‖projSimplexDef K (P ω + t • (v ω : EuclideanSpace ℝ (Fin K))) - P ω‖ ≤
        t * ‖v ω‖ := by
      calc ‖projSimplexDef K (P ω + t • (v ω : EuclideanSpace ℝ (Fin K))) - P ω‖
          = ‖projSimplexDef K (P ω + t • (v ω : EuclideanSpace ℝ (Fin K))) -
              projSimplexDef K (P ω)‖ := by rw [hp_id]
        _ ≤ ‖(P ω + t • (v ω : EuclideanSpace ℝ (Fin K))) - P ω‖ :=
            projSimplex_nonexpansive hK _ _
        _ = ‖t • (v ω : EuclideanSpace ℝ (Fin K))‖ := by simp
        _ = t * ‖v ω‖ := by
            rw [norm_smul, Real.norm_eq_abs, abs_of_pos ht_pos]
            rfl
    have ht_ne : t ≠ 0 := ne_of_gt ht_pos
    calc |F t ω|
        ≤ ‖fitResidual P Y ω‖ *
            ‖((1 : ℝ) / t) •
              (projSimplexDef K (P ω + t • (v ω : EuclideanSpace ℝ (Fin K))) - P ω)‖ :=
          abs_real_inner_le_norm _ _
      _ = ‖fitResidual P Y ω‖ *
            ((1 / t) * ‖projSimplexDef K (P ω + t • (v ω : EuclideanSpace ℝ (Fin K))) - P ω‖) := by
          rw [norm_smul, Real.norm_eq_abs, abs_of_pos (one_div_pos.mpr ht_pos)]
      _ ≤ 2 * ((1 / t) * (t * ‖v ω‖)) := by
          refine mul_le_mul (hr_bdd ω) ?_ (by positivity) (by norm_num)
          exact mul_le_mul_of_nonneg_left hproj_le (le_of_lt (one_div_pos.mpr ht_pos))
      _ = 2 * ‖v ω‖ := by field_simp
  have hsupp_all : ∀ᵐ ω ∂μ, ∀ j : Fin K, P ω j = 0 → oneHotLabel Y ω j = 0 :=
    Filter.eventually_all.mpr (support_ae μ hK hB hS_meas hY_meas hFit)
  have hF_tendsto : ∀ᵐ ω ∂μ, Filter.Tendsto (fun t => F t ω)
      (nhdsWithin (0 : ℝ) (Set.Ioi 0)) (nhds (f ω)) := by
    filter_upwards [hsupp_all] with ω hω
    obtain ⟨δ, hδ_pos, hδ_eq⟩ := projSimplex_inner_eq_of_small_t hK
      (w := (v ω : EuclideanSpace ℝ (Fin K))) (hP_simp ω) (hZ_simp ω) hω
    have hev : (fun t : ℝ => f ω) =ᶠ[nhdsWithin (0 : ℝ) (Set.Ioi 0)] (fun t : ℝ => F t ω) := by
      filter_upwards [Ioo_mem_nhdsGT hδ_pos] with t ht
      exact (hδ_eq t ht.1 ht.2).symm
    exact tendsto_const_nhds.congr' hev
  exact MeasureTheory.tendsto_integral_filter_of_dominated_convergence
    (fun ω => 2 * ‖v ω‖)
    (Filter.Eventually.of_forall hF_aesm)
    hF_bdd
    (hv.norm.const_mul 2)
    hF_tendsto

end UL.Proof_lem_A_3

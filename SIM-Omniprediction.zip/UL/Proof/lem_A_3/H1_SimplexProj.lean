import UL.Stmt.lem_A_3
set_option autoImplicit false

namespace UL.Proof_lem_A_3

lemma sum_apply {K : ℕ} {α : Type*} (s : Finset α)
    (f : α → EuclideanSpace ℝ (Fin K)) (j : Fin K) :
    (∑ a ∈ s, f a) j = ∑ a ∈ s, f a j := by
  classical
  induction s using Finset.induction_on with
  | empty => rfl
  | @insert a s ha ih => simp [Finset.sum_insert ha, ih]

lemma inner_eq_sum {K : ℕ} (x y : EuclideanSpace ℝ (Fin K)) :
    inner ℝ x y = ∑ i : Fin K, x i * y i := by
  rw [PiLp.inner_apply]
  refine Finset.sum_congr rfl (fun i _ => ?_)
  simp [mul_comm]

lemma norm_sq_eq_sum {K : ℕ} (x : EuclideanSpace ℝ (Fin K)) :
    ‖x‖ ^ 2 = ∑ i : Fin K, (x i) ^ 2 := by
  rw [← real_inner_self_eq_norm_sq, inner_eq_sum]
  refine Finset.sum_congr rfl (fun i _ => ?_)
  ring

lemma coord_abs_le_norm {K : ℕ} (x : EuclideanSpace ℝ (Fin K)) (j : Fin K) :
    |x j| ≤ ‖x‖ := by
  have hsq : (x j) ^ 2 ≤ ‖x‖ ^ 2 := by
    rw [norm_sq_eq_sum]
    exact Finset.single_le_sum (fun i _ => sq_nonneg (x i)) (Finset.mem_univ j)
  have habs : |x j| ^ 2 ≤ ‖x‖ ^ 2 := by rwa [sq_abs]
  nlinarith [abs_nonneg (x j), norm_nonneg x]

lemma onesVec_apply {K : ℕ} (j : Fin K) : onesVec K j = 1 := rfl

lemma oneHotVec_apply {K : ℕ} (y j : Fin K) :
    oneHotVec y j = if j = y then 1 else 0 := by
  simp [oneHotVec, EuclideanSpace.single_apply]

lemma oneHotVec_mem_simplex {K : ℕ} (y : Fin K) : oneHotVec y ∈ Simplex K := by
  refine ⟨fun j => ?_, ?_⟩
  · rw [oneHotVec_apply]
    split_ifs <;> norm_num
  · simp [oneHotVec_apply]

lemma zeroSumSubspace_iff {K : ℕ} (w : EuclideanSpace ℝ (Fin K)) :
    w ∈ ZeroSumSubspace K ↔ ∑ j : Fin K, w j = 0 := by
  simp only [ZeroSumSubspace, LinearMap.mem_ker, ContinuousLinearMap.coe_coe, innerSL_apply_apply]
  rw [inner_eq_sum]
  simp [onesVec_apply]

lemma simplex_convex (K : ℕ) : Convex ℝ (Simplex K) := by
  intro x hx y hy a b ha hb hab
  refine ⟨fun j => ?_, ?_⟩
  · change 0 ≤ a * x j + b * y j
    exact add_nonneg (mul_nonneg ha (hx.1 j)) (mul_nonneg hb (hy.1 j))
  · have h : ∑ j : Fin K, (a • x + b • y) j = a * (∑ j : Fin K, x j) + b * (∑ j : Fin K, y j) := by
      calc ∑ j : Fin K, (a • x + b • y) j
          = ∑ j : Fin K, (a * x j + b * y j) := rfl
        _ = (∑ j : Fin K, a * x j) + ∑ j : Fin K, b * y j := Finset.sum_add_distrib
        _ = a * (∑ j : Fin K, x j) + b * (∑ j : Fin K, y j) := by
              rw [← Finset.mul_sum, ← Finset.mul_sum]
    rw [h, hx.2, hy.2]
    linarith

lemma coord_le_one_of_mem_simplex {K : ℕ} {q : EuclideanSpace ℝ (Fin K)}
    (hq : q ∈ Simplex K) (j : Fin K) : q j ≤ 1 := by
  have hsub : q j ≤ ∑ i : Fin K, q i :=
    Finset.single_le_sum (fun i _ => hq.1 i) (Finset.mem_univ j)
  linarith [hq.2]

lemma norm_le_one_of_mem_simplex {K : ℕ} {q : EuclideanSpace ℝ (Fin K)}
    (hq : q ∈ Simplex K) : ‖q‖ ≤ 1 := by
  have hsq : ‖q‖ ^ 2 ≤ 1 := by
    rw [norm_sq_eq_sum]
    calc ∑ i : Fin K, (q i) ^ 2
        ≤ ∑ i : Fin K, q i := by
          refine Finset.sum_le_sum (fun i _ => ?_)
          have h0 := hq.1 i
          have h1 := coord_le_one_of_mem_simplex hq i
          nlinarith
      _ = 1 := hq.2
  nlinarith [norm_nonneg q]

lemma simplex_isCompact (K : ℕ) : IsCompact (Simplex K) := by
  rw [Metric.isCompact_iff_isClosed_bounded]
  constructor
  · have hEq : Simplex K = (⋂ j : Fin K, {q : EuclideanSpace ℝ (Fin K) | 0 ≤ q j}) ∩
        {q : EuclideanSpace ℝ (Fin K) | ∑ j : Fin K, q j = 1} := by
      ext q
      simp [Simplex]
    rw [hEq]
    have hcont : ∀ j : Fin K, Continuous (fun q : EuclideanSpace ℝ (Fin K) => q j) :=
      fun j => PiLp.continuous_apply 2 (fun _ : Fin K => ℝ) j
    refine IsClosed.inter ?_ ?_
    · exact isClosed_iInter (fun j => isClosed_le continuous_const (hcont j))
    · exact isClosed_eq (continuous_finset_sum Finset.univ (fun j _ => hcont j)) continuous_const
  · rw [Metric.isBounded_iff_subset_closedBall 0]
    refine ⟨1, fun q hq => ?_⟩
    rw [Metric.mem_closedBall, dist_zero_right]
    exact norm_le_one_of_mem_simplex hq

lemma simplex_nonempty {K : ℕ} (hK : 2 ≤ K) : (Simplex K).Nonempty :=
  ⟨oneHotVec ⟨0, by omega⟩, oneHotVec_mem_simplex _⟩

/-- Point + zero-sum perturbation lies in `affineSpan ℝ (Simplex K)`. -/
lemma affineSpan_simplex_mem {K : ℕ} (hK : 2 ≤ K)
    {p w : EuclideanSpace ℝ (Fin K)} (hp : p ∈ Simplex K)
    (hw : w ∈ ZeroSumSubspace K) (t : ℝ) :
    p + t • w ∈ affineSpan ℝ (Simplex K) := by
  let j₀ : Fin K := ⟨0, by omega⟩
  have hw0 : ∑ j : Fin K, w j = 0 := (zeroSumSubspace_iff w).mp hw
  have htw_eq : t • w = ∑ j : Fin K, (t * w j) • (oneHotVec j - oneHotVec j₀) := by
    ext i
    rw [sum_apply]
    simp only [PiLp.smul_apply, smul_eq_mul, PiLp.sub_apply, oneHotVec_apply]
    have hsplit :
        ∑ j : Fin K, t * w j * ((if i = j then (1 : ℝ) else 0) - if i = j₀ then 1 else 0) =
          (∑ j : Fin K, if i = j then t * w j else 0) -
            (if i = j₀ then (1 : ℝ) else 0) * (t * ∑ j : Fin K, w j) := by
      rw [Finset.mul_sum, Finset.mul_sum, ← Finset.sum_sub_distrib]
      refine Finset.sum_congr rfl (fun j _ => ?_)
      split_ifs <;> ring
    rw [hsplit, hw0]
    simp
  have hp_mem : p ∈ affineSpan ℝ (Simplex K) := subset_affineSpan ℝ (Simplex K) hp
  have hdir : t • w ∈ (affineSpan ℝ (Simplex K)).direction := by
    rw [htw_eq]
    refine Submodule.sum_mem _ (fun j _ => Submodule.smul_mem _ _ ?_)
    exact AffineSubspace.vsub_mem_direction
      (subset_affineSpan ℝ (Simplex K) (oneHotVec_mem_simplex j))
      (subset_affineSpan ℝ (Simplex K) (oneHotVec_mem_simplex j₀))
  have hvadd := AffineSubspace.vadd_mem_of_mem_direction hdir hp_mem
  simpa [vadd_eq_add, add_comm] using hvadd

lemma norm_add_smul_sq {E : Type*} [SeminormedAddCommGroup E] [InnerProductSpace ℝ E]
    (u v : E) (t : ℝ) :
    ‖u + t • v‖ ^ 2 = ‖u‖ ^ 2 + 2 * t * inner ℝ u v + t ^ 2 * ‖v‖ ^ 2 := by
  rw [norm_add_sq_real, inner_smul_right, norm_smul, Real.norm_eq_abs]
  have h : |t| ^ 2 = t ^ 2 := sq_abs t
  calc ‖u‖ ^ 2 + 2 * (t * inner ℝ u v) + (|t| * ‖v‖) ^ 2
      = ‖u‖ ^ 2 + 2 * t * inner ℝ u v + |t| ^ 2 * ‖v‖ ^ 2 := by ring
    _ = ‖u‖ ^ 2 + 2 * t * inner ℝ u v + t ^ 2 * ‖v‖ ^ 2 := by rw [h]

/-- Variational inequality characterization of minimizing distance to `Simplex K`. -/
lemma isMinOn_simplex_iff_inner_le_zero {K : ℕ}
    (x : EuclideanSpace ℝ (Fin K)) {q : EuclideanSpace ℝ (Fin K)} (hq : q ∈ Simplex K) :
    IsMinOn (fun q' => ‖x - q'‖) (Simplex K) q ↔
      ∀ y ∈ Simplex K, inner ℝ (x - q) (y - q) ≤ 0 := by
  constructor
  · intro hmin y hy
    by_contra hpos
    push_neg at hpos
    let α : ℝ := inner ℝ (x - q) (y - q)
    have hα : 0 < α := hpos
    let M : ℝ := ‖y - q‖ ^ 2 + 1
    have hM : 0 < M := by positivity
    let s : ℝ := min (1 / 2) (α / M)
    have hs_pos : 0 < s := lt_min (by norm_num) (div_pos hα hM)
    have hs_lt1 : s < 1 := lt_of_le_of_lt (min_le_left _ _) (by norm_num)
    have hs_le : s ≤ α / M := min_le_right _ _
    let qt : EuclideanSpace ℝ (Fin K) := (1 - s) • q + s • y
    have hqt_mem : qt ∈ Simplex K :=
      simplex_convex K hq hy (by linarith) (le_of_lt hs_pos) (by ring)
    have hle : ‖x - q‖ ≤ ‖x - qt‖ := hmin hqt_mem
    have hsq : ‖x - q‖ ^ 2 ≤ ‖x - qt‖ ^ 2 := by
      nlinarith [norm_nonneg (x - q), norm_nonneg (x - qt)]
    have hdiff : x - qt = (x - q) + (-s) • (y - q) := by
      ext j
      simp [qt]
      ring
    rw [hdiff, norm_add_smul_sq] at hsq
    have h1 : 2 * s * α ≤ s ^ 2 * ‖y - q‖ ^ 2 := by
      change 2 * s * inner ℝ (x - q) (y - q) ≤ s ^ 2 * ‖y - q‖ ^ 2
      linarith
    have h2 : 2 * α ≤ s * ‖y - q‖ ^ 2 := by nlinarith
    have h3 : s * M ≤ α := (le_div_iff₀ hM).mp hs_le
    have h4 : s * ‖y - q‖ ^ 2 < s * M := by
      dsimp [M]
      nlinarith
    linarith
  · intro hvi y hy
    show ‖x - q‖ ≤ ‖x - y‖
    have hdiff : x - y = (x - q) + (-1 : ℝ) • (y - q) := by
      ext j
      simp
    have hsq : ‖x - y‖ ^ 2 = ‖x - q‖ ^ 2 - 2 * inner ℝ (x - q) (y - q) + ‖y - q‖ ^ 2 := by
      rw [hdiff, norm_add_smul_sq]
      ring
    have hle := hvi y hy
    have hnn : 0 ≤ ‖y - q‖ ^ 2 := sq_nonneg _
    have hsq_le : ‖x - q‖ ^ 2 ≤ ‖x - y‖ ^ 2 := by linarith
    nlinarith [norm_nonneg (x - q), norm_nonneg (x - y)]

noncomputable def projSimplexDef (K : ℕ) :
    EuclideanSpace ℝ (Fin K) → EuclideanSpace ℝ (Fin K) :=
  fun x =>
    open Classical in
    if h : ∃ q : EuclideanSpace ℝ (Fin K),
        q ∈ Simplex K ∧ IsMinOn (fun q' => ‖x - q'‖) (Simplex K) q then
      Classical.choose h
    else
      0

lemma exists_simplex_isMinOn {K : ℕ} (hK : 2 ≤ K) (x : EuclideanSpace ℝ (Fin K)) :
    ∃ q : EuclideanSpace ℝ (Fin K),
      q ∈ Simplex K ∧ IsMinOn (fun q' => ‖x - q'‖) (Simplex K) q := by
  have hcont : ContinuousOn (fun q' : EuclideanSpace ℝ (Fin K) => ‖x - q'‖) (Simplex K) :=
    (continuous_norm.comp (continuous_const.sub continuous_id)).continuousOn
  obtain ⟨q, hq_mem, hq_min⟩ :=
    (simplex_isCompact K).exists_isMinOn (simplex_nonempty hK) hcont
  exact ⟨q, hq_mem, hq_min⟩

lemma projSimplex_mem {K : ℕ} (hK : 2 ≤ K) (x : EuclideanSpace ℝ (Fin K)) :
    projSimplexDef K x ∈ Simplex K := by
  dsimp [projSimplexDef]
  rw [dif_pos (exists_simplex_isMinOn hK x)]
  exact (Classical.choose_spec (exists_simplex_isMinOn hK x)).1

lemma projSimplex_isMinOn {K : ℕ} (hK : 2 ≤ K) (x : EuclideanSpace ℝ (Fin K)) :
    IsMinOn (fun q' => ‖x - q'‖) (Simplex K) (projSimplexDef K x) := by
  dsimp [projSimplexDef]
  rw [dif_pos (exists_simplex_isMinOn hK x)]
  exact (Classical.choose_spec (exists_simplex_isMinOn hK x)).2

lemma projSimplex_inner_le_zero {K : ℕ} (hK : 2 ≤ K) (x : EuclideanSpace ℝ (Fin K))
    {y : EuclideanSpace ℝ (Fin K)} (hy : y ∈ Simplex K) :
    inner ℝ (x - projSimplexDef K x) (y - projSimplexDef K x) ≤ 0 :=
  (isMinOn_simplex_iff_inner_le_zero x (projSimplex_mem hK x)).mp
    (projSimplex_isMinOn hK x) y hy

lemma eq_projSimplex_of_inner_le_zero {K : ℕ} (hK : 2 ≤ K)
    (x : EuclideanSpace ℝ (Fin K)) {q : EuclideanSpace ℝ (Fin K)}
    (hq : q ∈ Simplex K)
    (hvi : ∀ y ∈ Simplex K, inner ℝ (x - q) (y - q) ≤ 0) :
    projSimplexDef K x = q := by
  let p := projSimplexDef K x
  have hp_mem : p ∈ Simplex K := projSimplex_mem hK x
  have h1 : inner ℝ (x - p) (q - p) ≤ 0 := projSimplex_inner_le_zero hK x hq
  have h2 : inner ℝ (x - q) (p - q) ≤ 0 := hvi p hp_mem
  have hsum : ‖p - q‖ ^ 2 = inner ℝ (x - q) (p - q) + inner ℝ (x - p) (q - p) := by
    have hsub : p - q = (x - q) - (x - p) := by abel
    have hneg : q - p = -(p - q) := by abel
    rw [← real_inner_self_eq_norm_sq, hneg, inner_neg_right]
    nth_rw 1 [hsub]
    rw [inner_sub_left]
    ring
  have hle0 : ‖p - q‖ ^ 2 ≤ 0 := by linarith
  have heq0 : ‖p - q‖ = 0 := by nlinarith [norm_nonneg (p - q)]
  exact sub_eq_zero.mp (norm_eq_zero.mp heq0)

lemma projSimplex_eq_self {K : ℕ} (hK : 2 ≤ K) {p : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ Simplex K) : projSimplexDef K p = p := by
  apply eq_projSimplex_of_inner_le_zero hK p hp
  intro y _
  simp

lemma projSimplex_nonexpansive {K : ℕ} (hK : 2 ≤ K)
    (x₁ x₂ : EuclideanSpace ℝ (Fin K)) :
    ‖projSimplexDef K x₁ - projSimplexDef K x₂‖ ≤ ‖x₁ - x₂‖ := by
  let q₁ := projSimplexDef K x₁
  let q₂ := projSimplexDef K x₂
  have h1 : inner ℝ (x₁ - q₁) (q₂ - q₁) ≤ 0 :=
    projSimplex_inner_le_zero hK x₁ (projSimplex_mem hK x₂)
  have h2 : inner ℝ (x₂ - q₂) (q₁ - q₂) ≤ 0 :=
    projSimplex_inner_le_zero hK x₂ (projSimplex_mem hK x₁)
  have h1' : 0 ≤ inner ℝ (x₁ - q₁) (q₁ - q₂) := by
    have hneg : q₁ - q₂ = -(q₂ - q₁) := by abel
    rw [hneg, inner_neg_right] at *
    linarith
  have hdiff : 0 ≤ inner ℝ ((x₁ - x₂) - (q₁ - q₂)) (q₁ - q₂) := by
    have heq : (x₁ - x₂) - (q₁ - q₂) = (x₁ - q₁) - (x₂ - q₂) := by abel
    rw [heq, inner_sub_left]
    linarith
  rw [inner_sub_left, real_inner_self_eq_norm_sq] at hdiff
  have hcs : inner ℝ (x₁ - x₂) (q₁ - q₂) ≤ ‖x₁ - x₂‖ * ‖q₁ - q₂‖ :=
    real_inner_le_norm _ _
  have hsq : ‖q₁ - q₂‖ ^ 2 ≤ ‖x₁ - x₂‖ * ‖q₁ - q₂‖ := by linarith
  by_cases h0 : ‖q₁ - q₂‖ = 0
  · change ‖q₁ - q₂‖ ≤ ‖x₁ - x₂‖
    rw [h0]
    exact norm_nonneg _
  · have hpos : 0 < ‖q₁ - q₂‖ := lt_of_le_of_ne (norm_nonneg _) (Ne.symm h0)
    change ‖q₁ - q₂‖ ≤ ‖x₁ - x₂‖
    nlinarith

lemma projSimplex_continuous {K : ℕ} (hK : 2 ≤ K) :
    Continuous (projSimplexDef K) := by
  rw [Metric.continuous_iff]
  intro x ε hε
  refine ⟨ε, hε, fun y hy => ?_⟩
  rw [dist_eq_norm] at hy ⊢
  exact lt_of_le_of_lt (projSimplex_nonexpansive hK y x) hy

/-- Support of any `p ∈ Simplex K` is nonempty. -/
lemma posSupport_nonempty {K : ℕ} {p : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ Simplex K) :
    (Finset.univ.filter (fun j : Fin K => 0 < p j)).Nonempty := by
  by_contra hemp
  rw [Finset.not_nonempty_iff_eq_empty] at hemp
  have hall0 : ∀ j : Fin K, p j = 0 := by
    intro j
    have hnot : ¬ (0 < p j) := by
      intro hpos
      have : j ∈ Finset.univ.filter (fun i : Fin K => 0 < p i) :=
        Finset.mem_filter.mpr ⟨Finset.mem_univ j, hpos⟩
      rw [hemp] at this
      simp at this
    linarith [hp.1 j]
  have hsum0 : ∑ j : Fin K, p j = 0 := by simp [hall0]
  linarith [hp.2]

/-- Shrunk simplex projection `T_eps K ε x`. -/
noncomputable def T_eps (K : ℕ) (ε : ℝ) (x : EuclideanSpace ℝ (Fin K)) :
    EuclideanSpace ℝ (Fin K) :=
  ε • onesVec K +
    (1 - (K : ℝ) * ε) • projSimplexDef K ((1 / (1 - (K : ℝ) * ε)) • (x - ε • onesVec K))

lemma T_eps_mem_simplex {K : ℕ} (hK : 2 ≤ K) {ε : ℝ}
    (hε_pos : 0 < ε) (hε_lt : (K : ℝ) * ε < 1) (x : EuclideanSpace ℝ (Fin K)) :
    T_eps K ε x ∈ Simplex K := by
  let q := projSimplexDef K ((1 / (1 - (K : ℝ) * ε)) • (x - ε • onesVec K))
  have hq : q ∈ Simplex K := projSimplex_mem hK _
  refine ⟨fun j => ?_, ?_⟩
  · change 0 ≤ ε * onesVec K j + (1 - (K : ℝ) * ε) * q j
    rw [onesVec_apply]
    have h1 : 0 ≤ 1 - (K : ℝ) * ε := by linarith
    exact add_nonneg (by linarith) (mul_nonneg h1 (hq.1 j))
  · have hsum : ∑ j : Fin K, (T_eps K ε x) j =
        (K : ℝ) * ε + (1 - (K : ℝ) * ε) * ∑ j : Fin K, q j := by
      calc ∑ j : Fin K, (T_eps K ε x) j
          = ∑ j : Fin K, (ε + (1 - (K : ℝ) * ε) * q j) := by
              refine Finset.sum_congr rfl (fun j _ => ?_)
              change ε * onesVec K j + (1 - (K : ℝ) * ε) * q j = ε + (1 - (K : ℝ) * ε) * q j
              rw [onesVec_apply, mul_one]
        _ = (∑ _j : Fin K, ε) + ∑ j : Fin K, (1 - (K : ℝ) * ε) * q j := Finset.sum_add_distrib
        _ = (K : ℝ) * ε + (1 - (K : ℝ) * ε) * ∑ j : Fin K, q j := by
              rw [← Finset.mul_sum]
              simp [mul_comm]
    rw [hsum, hq.2]
    ring

lemma T_eps_nonexpansive {K : ℕ} (hK : 2 ≤ K) {ε : ℝ}
    (hε_lt : (K : ℝ) * ε < 1) (x₁ x₂ : EuclideanSpace ℝ (Fin K)) :
    ‖T_eps K ε x₁ - T_eps K ε x₂‖ ≤ ‖x₁ - x₂‖ := by
  let α : ℝ := 1 - (K : ℝ) * ε
  have hα_pos : 0 < α := by dsimp [α]; linarith
  have hα_ne : α ≠ 0 := ne_of_gt hα_pos
  let u₁ := (1 / α) • (x₁ - ε • onesVec K)
  let u₂ := (1 / α) • (x₂ - ε • onesVec K)
  have hdiff : T_eps K ε x₁ - T_eps K ε x₂ =
      α • (projSimplexDef K u₁ - projSimplexDef K u₂) := by
    dsimp [T_eps, α, u₁, u₂]
    ext j
    simp only [PiLp.sub_apply, PiLp.add_apply, PiLp.smul_apply, smul_eq_mul]
    ring
  rw [hdiff, norm_smul, Real.norm_eq_abs, abs_of_pos hα_pos]
  have hu : u₁ - u₂ = (1 / α) • (x₁ - x₂) := by
    dsimp [u₁, u₂]
    ext j
    simp only [PiLp.sub_apply, PiLp.smul_apply, smul_eq_mul]
    ring
  have hproj := projSimplex_nonexpansive hK u₁ u₂
  rw [hu, norm_smul, Real.norm_eq_abs, abs_of_pos (one_div_pos.mpr hα_pos)] at hproj
  calc α * ‖projSimplexDef K u₁ - projSimplexDef K u₂‖
      ≤ α * ((1 / α) * ‖x₁ - x₂‖) := mul_le_mul_of_nonneg_left hproj (le_of_lt hα_pos)
    _ = ‖x₁ - x₂‖ := by field_simp

lemma T_eps_sub_self_norm_le {K : ℕ} (hK : 2 ≤ K) {ε : ℝ}
    (hε_pos : 0 < ε) (hε_lt : (K : ℝ) * ε < 1)
    {p : EuclideanSpace ℝ (Fin K)} (hp : p ∈ Simplex K) :
    ‖T_eps K ε p - p‖ ≤ 2 * (K : ℝ) * ε := by
  let α : ℝ := 1 - (K : ℝ) * ε
  have hα_pos : 0 < α := by dsimp [α]; linarith
  have hα_ne : α ≠ 0 := ne_of_gt hα_pos
  have h1m_ne : 1 - (K : ℝ) * ε ≠ 0 := hα_ne
  let u := (1 / α) • (p - ε • onesVec K)
  have hmin : ‖u - projSimplexDef K u‖ ≤ ‖u - p‖ :=
    projSimplex_isMinOn hK u hp
  have hlhs : p - T_eps K ε p = α • (u - projSimplexDef K u) := by
    have hT : T_eps K ε p = ε • onesVec K + α • projSimplexDef K u := rfl
    rw [hT]
    ext j
    simp only [u, PiLp.sub_apply, PiLp.add_apply, PiLp.smul_apply, smul_eq_mul]
    field_simp [hα_ne]
    ring
  have hrhs : α • (u - p) = ε • ((K : ℝ) • p - onesVec K) := by
    ext j
    simp only [u, α, PiLp.sub_apply, PiLp.smul_apply, smul_eq_mul]
    field_simp [h1m_ne]
    ring
  have h1 : ‖T_eps K ε p - p‖ ≤ ‖ε • ((K : ℝ) • p - onesVec K)‖ := by
    rw [norm_sub_rev, hlhs, ← hrhs, norm_smul, norm_smul]
    exact mul_le_mul_of_nonneg_left hmin (norm_nonneg α)
  rw [norm_smul, Real.norm_eq_abs, abs_of_pos hε_pos] at h1
  have hones : ‖onesVec K‖ ≤ (K : ℝ) := by
    have hsq : ‖onesVec K‖ ^ 2 = (K : ℝ) := by
      rw [norm_sq_eq_sum]
      simp [onesVec_apply]
    have hKge1 : (1 : ℝ) ≤ (K : ℝ) := by exact_mod_cast (by omega : 1 ≤ K)
    nlinarith [norm_nonneg (onesVec K)]
  have hpnorm : ‖(K : ℝ) • p - onesVec K‖ ≤ 2 * (K : ℝ) := by
    calc ‖(K : ℝ) • p - onesVec K‖
        ≤ ‖(K : ℝ) • p‖ + ‖onesVec K‖ := norm_sub_le _ _
      _ = (K : ℝ) * ‖p‖ + ‖onesVec K‖ := by
          rw [norm_smul, Real.norm_eq_abs, abs_of_nonneg (Nat.cast_nonneg K)]
      _ ≤ (K : ℝ) * 1 + (K : ℝ) :=
          add_le_add (mul_le_mul_of_nonneg_left (norm_le_one_of_mem_simplex hp) (Nat.cast_nonneg K)) hones
      _ = 2 * (K : ℝ) := by ring
  nlinarith

/-- Inner product of `p - z` with the scaled projection displacement for small ε.
Taking z = e_y gives the residual ξ used in Lemma B.3. -/
lemma T_eps_inner_eq_of_small {K : ℕ} (hK : 2 ≤ K)
    {p z : EuclideanSpace ℝ (Fin K)} (hp : p ∈ Simplex K) (hz : z ∈ Simplex K)
    {ε : ℝ} (hε_pos : 0 < ε) (hε_lt : (K : ℝ) * ε < 1)
    (hε_small : ∀ j ∈ Finset.univ.filter (fun i : Fin K => 0 < p i),
      ((K : ℝ) / ((Finset.univ.filter (fun i : Fin K => 0 < p i)).card : ℝ)) * ε ≤ p j) :
    inner ℝ (p - z) ((1 / ε) • (T_eps K ε p - p)) =
      -((K : ℝ) / ((Finset.univ.filter (fun i : Fin K => 0 < p i)).card : ℝ)) *
        ∑ j ∈ Finset.univ.filter (fun i : Fin K => p i = 0), z j := by
  let J := Finset.univ.filter (fun i : Fin K => 0 < p i)
  let s : ℝ := (J.card : ℝ)
  have hJ_ne : J.Nonempty := posSupport_nonempty hp
  have hs_pos : 0 < s := by
    dsimp [s]
    exact_mod_cast Finset.card_pos.mpr hJ_ne
  have hs_ne : s ≠ 0 := ne_of_gt hs_pos
  let α : ℝ := 1 - (K : ℝ) * ε
  have hα_pos : 0 < α := by dsimp [α]; linarith
  have hα_ne : α ≠ 0 := ne_of_gt hα_pos
  have h1m_ne : 1 - (K : ℝ) * ε ≠ 0 := hα_ne
  have hε_ne : ε ≠ 0 := ne_of_gt hε_pos
  have hp_zero_outside : ∀ j : Fin K, j ∉ J → p j = 0 := by
    intro j hj
    have hnot : ¬ (0 < p j) := fun hpos => hj (Finset.mem_filter.mpr ⟨Finset.mem_univ j, hpos⟩)
    linarith [hp.1 j]
  let qtilde : EuclideanSpace ℝ (Fin K) :=
    (WithLp.equiv 2 (Fin K → ℝ)).symm
      (fun j => if j ∈ J then (p j - ((K : ℝ) / s) * ε) / α else 0)
  have hqtilde_apply : ∀ j : Fin K,
      qtilde j = if j ∈ J then (p j - ((K : ℝ) / s) * ε) / α else 0 := fun _ => rfl
  have hqtilde_mem : qtilde ∈ Simplex K := by
    refine ⟨fun j => ?_, ?_⟩
    · rw [hqtilde_apply]
      split_ifs with hj
      · exact div_nonneg (sub_nonneg.mpr (hε_small j hj)) (le_of_lt hα_pos)
      · norm_num
    · have hsumJ : ∑ j : Fin K, qtilde j =
          ∑ j ∈ J, (p j - ((K : ℝ) / s) * ε) / α := by
        simp_rw [hqtilde_apply]
        rw [← Finset.sum_filter]
        refine Finset.sum_congr ?_ (fun _ _ => rfl)
        ext j
        simp
      have hp_sumJ : ∑ j ∈ J, p j = 1 := by
        have hsplit := (Finset.sum_filter_add_sum_filter_not Finset.univ (fun i : Fin K => 0 < p i)
          (fun i => p i)).symm
        have hnot0 : ∑ x ∈ Finset.univ.filter (fun i : Fin K => ¬ 0 < p i), p x = 0 := by
          refine Finset.sum_eq_zero (fun j hj => ?_)
          have hnot : ¬ (0 < p j) := (Finset.mem_filter.mp hj).2
          linarith [hp.1 j]
        change (∑ j ∈ J, p j) = 1
        linarith [hp.2]
      rw [hsumJ, ← Finset.sum_div, Finset.sum_sub_distrib, hp_sumJ, Finset.sum_const, nsmul_eq_mul]
      change (1 - s * ((K : ℝ) / s * ε)) / α = 1
      have hsc : s * ((K : ℝ) / s * ε) = (K : ℝ) * ε := by field_simp [hs_ne]
      rw [hsc]
      dsimp [α]
      field_simp [h1m_ne]
  let u := (1 / α) • (p - ε • onesVec K)
  have hproj_eq : projSimplexDef K u = qtilde := by
    apply eq_projSimplex_of_inner_le_zero hK u hqtilde_mem
    intro y hy
    let c : ℝ := (((K : ℝ) / s - 1) * ε) / α
    have hcoord : ∀ j : Fin K, (u - qtilde) j =
        c - if j ∈ J then 0 else ((K : ℝ) / s * ε) / α := by
      intro j
      dsimp [u, c]
      simp only [PiLp.sub_apply, PiLp.smul_apply, smul_eq_mul, onesVec_apply, hqtilde_apply]
      split_ifs with hj
      · field_simp [hα_ne, hs_ne]
        ring
      · have hp0 := hp_zero_outside j hj
        rw [hp0]
        field_simp [hα_ne, hs_ne]
        ring
    have hsum_yq : ∑ j : Fin K, (y j - qtilde j) = 0 := by
      rw [Finset.sum_sub_distrib, hy.2, hqtilde_mem.2, sub_self]
    rw [inner_eq_sum]
    have hrewrite :
        ∑ j : Fin K, (u - qtilde) j * (y - qtilde) j =
          c * (∑ j : Fin K, (y j - qtilde j)) -
            ∑ j : Fin K, (if j ∈ J then 0 else ((K : ℝ) / s * ε) / α) * (y j - qtilde j) := by
      rw [Finset.mul_sum, ← Finset.sum_sub_distrib]
      refine Finset.sum_congr rfl (fun j _ => ?_)
      rw [hcoord j, PiLp.sub_apply]
      ring
    rw [hrewrite, hsum_yq, mul_zero, zero_sub, neg_nonpos]
    refine Finset.sum_nonneg (fun j _ => ?_)
    split_ifs with hj
    · simp
    · rw [hqtilde_apply, if_neg hj, sub_zero]
      have hcoeff : 0 ≤ ((K : ℝ) / s * ε) / α := by positivity
      exact mul_nonneg hcoeff (hy.1 j)
  have hdiff_coord : ∀ j : Fin K,
      ((1 / ε) • (T_eps K ε p - p)) j =
        (1 - (K : ℝ) / s) + if j ∈ J then 0 else (K : ℝ) / s := by
    intro j
    have hT : T_eps K ε p = ε • onesVec K + α • qtilde := by
      dsimp [T_eps, α, u]
      rw [hproj_eq]
    rw [hT]
    simp only [PiLp.smul_apply, smul_eq_mul, PiLp.sub_apply, PiLp.add_apply,
      onesVec_apply, hqtilde_apply]
    split_ifs with hj
    · field_simp
      ring
    · rw [hp_zero_outside j hj]
      field_simp
      ring
  have hr_sum : ∑ j : Fin K, (p - z) j = 0 := by
    change ∑ j : Fin K, (p j - z j) = 0
    rw [Finset.sum_sub_distrib, hp.2, hz.2, sub_self]
  rw [inner_eq_sum]
  have hinner_split :
      ∑ j : Fin K, (p - z) j * ((1 / ε) • (T_eps K ε p - p)) j =
        (1 - (K : ℝ) / s) * (∑ j : Fin K, (p - z) j) +
          ((K : ℝ) / s) * ∑ j : Fin K, if j ∈ J then 0 else (p - z) j := by
    rw [Finset.mul_sum, Finset.mul_sum, ← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl (fun j _ => ?_)
    rw [hdiff_coord j]
    split_ifs <;> ring
  rw [hinner_split, hr_sum, mul_zero, zero_add]
  have hfilter_eq :
      (∑ j : Fin K, if j ∈ J then (0 : ℝ) else (p - z) j) =
        -∑ j ∈ Finset.univ.filter (fun i : Fin K => p i = 0), z j := by
    rw [← Finset.sum_neg_distrib]
    have h1 : (∑ j ∈ Finset.univ.filter (fun i : Fin K => p i = 0), -z j) =
        ∑ j : Fin K, if p j = 0 then -z j else 0 := by
      rw [Finset.sum_filter]
    rw [h1]
    refine Finset.sum_congr rfl (fun j _ => ?_)
    by_cases hj : j ∈ J
    · have hpos : 0 < p j := (Finset.mem_filter.mp hj).2
      have hne : p j ≠ 0 := ne_of_gt hpos
      simp [hj, hne]
    · have hp0 : p j = 0 := hp_zero_outside j hj
      simp [hj, hp0]
  rw [hfilter_eq]
  ring

/-- Two positive coordinates of `projSimplexDef K x` share the same Lagrange shift `x i - q i`. -/
lemma projSimplex_shift_eq_of_pos {K : ℕ} (hK : 2 ≤ K)
    (x : EuclideanSpace ℝ (Fin K)) {i k : Fin K}
    (hi : 0 < projSimplexDef K x i) (hk : 0 < projSimplexDef K x k) :
    x i - projSimplexDef K x i = x k - projSimplexDef K x k := by
  by_cases hik : i = k
  · subst hik; rfl
  · let q := projSimplexDef K x
    have hq_mem : q ∈ Simplex K := projSimplex_mem hK x
    let δ : ℝ := min (q i) (q k) / 2
    have hδ_pos : 0 < δ := half_pos (lt_min hi hk)
    have hδ_le_i : δ ≤ q i := le_trans (half_le_self (le_of_lt (lt_min hi hk))) (min_le_left _ _)
    have hδ_le_k : δ ≤ q k := le_trans (half_le_self (le_of_lt (lt_min hi hk))) (min_le_right _ _)
    have hpert : ∀ (a b : Fin K), a ≠ b → δ ≤ q b →
        q + δ • (oneHotVec a - oneHotVec b) ∈ Simplex K := by
      intro a b hab hδb
      refine ⟨fun j => ?_, ?_⟩
      · simp only [PiLp.add_apply, PiLp.smul_apply, smul_eq_mul, PiLp.sub_apply, oneHotVec_apply]
        by_cases hja : j = a
        · subst hja
          rw [if_pos rfl, if_neg hab]
          linarith [hq_mem.1 j]
        · by_cases hjb : j = b
          · subst hjb
            rw [if_neg hja, if_pos rfl]
            linarith
          · rw [if_neg hja, if_neg hjb]
            linarith [hq_mem.1 j]
      · have hsum : ∑ j : Fin K, (q + δ • (oneHotVec a - oneHotVec b)) j =
            (∑ j : Fin K, q j) + δ * ((∑ j : Fin K, oneHotVec a j) - ∑ j : Fin K, oneHotVec b j) := by
          calc ∑ j : Fin K, (q + δ • (oneHotVec a - oneHotVec b)) j
              = ∑ j : Fin K, (q j + δ * (oneHotVec a j - oneHotVec b j)) := rfl
            _ = (∑ j : Fin K, q j) + ∑ j : Fin K, δ * (oneHotVec a j - oneHotVec b j) :=
                Finset.sum_add_distrib
            _ = (∑ j : Fin K, q j) + δ * ((∑ j : Fin K, oneHotVec a j) - ∑ j : Fin K, oneHotVec b j) := by
                rw [← Finset.mul_sum, Finset.sum_sub_distrib]
        rw [hsum, hq_mem.2, (oneHotVec_mem_simplex a).2, (oneHotVec_mem_simplex b).2]
        ring
    have hle1 : x i - q i ≤ x k - q k := by
      have hvi := projSimplex_inner_le_zero hK x (hpert i k hik hδ_le_k)
      have hsub : (q + δ • (oneHotVec i - oneHotVec k)) - q = δ • (oneHotVec i - oneHotVec k) :=
        add_sub_cancel_left _ _
      rw [hsub, inner_smul_right, inner_sub_right] at hvi
      have hei : inner ℝ (x - q) (oneHotVec i) = x i - q i := by
        rw [inner_eq_sum]
        simp [oneHotVec_apply]
      have hek : inner ℝ (x - q) (oneHotVec k) = x k - q k := by
        rw [inner_eq_sum]
        simp [oneHotVec_apply]
      rw [hei, hek] at hvi
      nlinarith
    have hle2 : x k - q k ≤ x i - q i := by
      have hvi := projSimplex_inner_le_zero hK x (hpert k i (Ne.symm hik) hδ_le_i)
      have hsub : (q + δ • (oneHotVec k - oneHotVec i)) - q = δ • (oneHotVec k - oneHotVec i) :=
        add_sub_cancel_left _ _
      rw [hsub, inner_smul_right, inner_sub_right] at hvi
      have hei : inner ℝ (x - q) (oneHotVec i) = x i - q i := by
        rw [inner_eq_sum]
        simp [oneHotVec_apply]
      have hek : inner ℝ (x - q) (oneHotVec k) = x k - q k := by
        rw [inner_eq_sum]
        simp [oneHotVec_apply]
      rw [hei, hek] at hvi
      nlinarith
    linarith

/-- Directional derivative identity along any `w` for small `t > 0` when `p_j = 0 → z_j = 0`. -/
lemma projSimplex_inner_eq_of_small_t {K : ℕ} (hK : 2 ≤ K)
    {p z w : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ Simplex K) (hz : z ∈ Simplex K)
    (hsupp : ∀ j : Fin K, p j = 0 → z j = 0) :
    ∃ δ : ℝ, 0 < δ ∧ ∀ t : ℝ, 0 < t → t < δ →
      inner ℝ (p - z) (((1 : ℝ) / t) • (projSimplexDef K (p + t • w) - p)) =
        inner ℝ (p - z) w := by
  let J := Finset.univ.filter (fun i : Fin K => 0 < p i)
  have hJ_ne : J.Nonempty := posSupport_nonempty hp
  obtain ⟨j₀, hj₀⟩ := hJ_ne
  let m : ℝ := J.inf' ⟨j₀, hj₀⟩ (fun j => p j)
  have hm_pos : 0 < m := by
    rw [Finset.lt_inf'_iff]
    intro j hj
    exact (Finset.mem_filter.mp hj).2
  let δ : ℝ := m / (‖w‖ + 1)
  have hδ_pos : 0 < δ := div_pos hm_pos (by positivity)
  refine ⟨δ, hδ_pos, fun t ht_pos ht_lt => ?_⟩
  have htw_lt : t * ‖w‖ < m := by
    have h1 : t * (‖w‖ + 1) < m := (lt_div_iff₀ (by positivity)).mp ht_lt
    nlinarith [norm_nonneg w]
  let q := projSimplexDef K (p + t • w)
  have hq_pos : ∀ j ∈ J, 0 < q j := by
    intro j hj
    have hnorm : ‖q - p‖ ≤ t * ‖w‖ := by
      have hp_id : projSimplexDef K p = p := projSimplex_eq_self hK hp
      calc ‖q - p‖
          = ‖projSimplexDef K (p + t • w) - projSimplexDef K p‖ := by rw [hp_id]
        _ ≤ ‖(p + t • w) - p‖ := projSimplex_nonexpansive hK _ _
        _ = ‖t • w‖ := by simp
        _ = t * ‖w‖ := by rw [norm_smul, Real.norm_eq_abs, abs_of_pos ht_pos]
    have hcoord : |q j - p j| ≤ t * ‖w‖ := le_trans (coord_abs_le_norm (q - p) j) hnorm
    have hm_le : m ≤ p j := Finset.inf'_le (fun i => p i) hj
    have hlo : -(t * ‖w‖) ≤ q j - p j := (abs_le.mp hcoord).1
    linarith
  let lam : ℝ := q j₀ - (p j₀ + t * w j₀)
  have hq_shift : ∀ j ∈ J, q j - p j = t * w j + lam := by
    intro j hj
    have heq := projSimplex_shift_eq_of_pos hK (p + t • w) (hq_pos j hj) (hq_pos j₀ hj₀)
    change (p j + t * w j) - q j = (p j₀ + t * w j₀) - q j₀ at heq
    dsimp [lam]
    linarith
  have hr_zero_outside : ∀ j : Fin K, j ∉ J → (p - z) j = 0 := by
    intro j hj
    have hnot : ¬ (0 < p j) := fun hpos => hj (Finset.mem_filter.mpr ⟨Finset.mem_univ j, hpos⟩)
    have hp0 : p j = 0 := by linarith [hp.1 j]
    have hz0 : z j = 0 := hsupp j hp0
    simp [hp0, hz0]
  have hr_sum : ∑ j ∈ J, (p - z) j = 0 := by
    have htot : ∑ j : Fin K, (p - z) j = 0 := by
      change ∑ j : Fin K, (p j - z j) = 0
      rw [Finset.sum_sub_distrib, hp.2, hz.2, sub_self]
    have hsplit := (Finset.sum_filter_add_sum_filter_not Finset.univ (fun i : Fin K => 0 < p i)
      (fun i => (p - z) i)).symm
    have hnot0 : ∑ j ∈ Finset.univ.filter (fun i : Fin K => ¬ 0 < p i), (p - z) j = 0 := by
      refine Finset.sum_eq_zero (fun j hj => ?_)
      refine hr_zero_outside j ?_
      intro hjJ
      exact (Finset.mem_filter.mp hj).2 (Finset.mem_filter.mp hjJ).2
    change ∑ j ∈ J, (p - z) j = 0
    linarith
  have hinner_q : inner ℝ (p - z) (q - p) = t * inner ℝ (p - z) w := by
    rw [inner_eq_sum, inner_eq_sum]
    have h1 : ∑ j : Fin K, (p - z) j * (q - p) j = ∑ j ∈ J, (p - z) j * (q j - p j) := by
      have hsplit := (Finset.sum_filter_add_sum_filter_not Finset.univ (fun i : Fin K => 0 < p i)
        (fun i => (p - z) i * (q - p) i)).symm
      have hnot0 : ∑ j ∈ Finset.univ.filter (fun i : Fin K => ¬ 0 < p i), (p - z) j * (q - p) j = 0 := by
        refine Finset.sum_eq_zero (fun j hj => ?_)
        have hr0 : (p - z) j = 0 :=
          hr_zero_outside j (fun hjJ => (Finset.mem_filter.mp hj).2 (Finset.mem_filter.mp hjJ).2)
        rw [hr0, zero_mul]
      change (∑ j : Fin K, (p - z) j * (q - p) j) = ∑ j ∈ J, (p - z) j * (q j - p j)
      rw [hsplit, hnot0, add_zero]
      rfl
    have h2 : ∑ j : Fin K, (p - z) j * w j = ∑ j ∈ J, (p - z) j * w j := by
      have hsplit := (Finset.sum_filter_add_sum_filter_not Finset.univ (fun i : Fin K => 0 < p i)
        (fun i => (p - z) i * w i)).symm
      have hnot0 : ∑ j ∈ Finset.univ.filter (fun i : Fin K => ¬ 0 < p i), (p - z) j * w j = 0 := by
        refine Finset.sum_eq_zero (fun j hj => ?_)
        have hr0 : (p - z) j = 0 :=
          hr_zero_outside j (fun hjJ => (Finset.mem_filter.mp hj).2 (Finset.mem_filter.mp hjJ).2)
        rw [hr0, zero_mul]
      change (∑ j : Fin K, (p - z) j * w j) = ∑ j ∈ J, (p - z) j * w j
      rw [hsplit, hnot0, add_zero]
    rw [h1, h2]
    calc ∑ j ∈ J, (p - z) j * (q j - p j)
        = ∑ j ∈ J, (p - z) j * (t * w j + lam) := by
            refine Finset.sum_congr rfl (fun j hj => by rw [hq_shift j hj])
      _ = t * (∑ j ∈ J, (p - z) j * w j) + lam * (∑ j ∈ J, (p - z) j) := by
            rw [Finset.mul_sum, Finset.mul_sum, ← Finset.sum_add_distrib]
            refine Finset.sum_congr rfl (fun j _ => by ring)
      _ = t * ∑ j ∈ J, (p - z) j * w j := by rw [hr_sum, mul_zero, add_zero]
  rw [inner_smul_right, hinner_q]
  have ht_ne : t ≠ 0 := ne_of_gt ht_pos
  field_simp

end UL.Proof_lem_A_3

import UL.Stmt.lem_A_2
import UL.Proof.lem_A_2.H2_ExistenceUniqueness
import UL.Proof.lem_A_2.H3_ContinuityAndMatrix
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_lem_A_2 : S_lem_A_2 := by
  unfold S_lem_A_2
  intro Ω _ μ _ d K B hB X Y hX hY
  refine ⟨?_, ?_, ?_⟩
  · intro W
    refine ⟨Proof_lem_A_2.exists_isLipschitzLSFit μ hB
      (Proof_lem_A_2.linearScore_measurable W hX) hY, ?_⟩
    intro P₁ P₂ h₁ h₂
    exact Proof_lem_A_2.isLipschitzLSFit_ae_eq μ
      (Proof_lem_A_2.linearScore_measurable W hX) hY h₁ h₂
  · intro W_seq W hW
    exact Proof_lem_A_2.tendsto_eLpNorm_linearFittedPrediction μ hB hX hY hW
  · intro hX_int
    refine ⟨?_, ?_, ?_⟩
    · intro W
      exact Proof_lem_A_2.matIntegrand_integrable μ hB W hX hX_int hY
    · intro W x
      exact Proof_lem_A_2.matIntegral_apply_mem_zeroSumSubspace μ hB W hX hX_int hY x
    · exact Proof_lem_A_2.matIntegral_continuous μ hB hX hX_int hY

end UL

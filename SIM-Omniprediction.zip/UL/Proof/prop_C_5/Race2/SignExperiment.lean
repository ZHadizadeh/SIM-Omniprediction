import Mathlib
import UL.Stmt.prop_C_5
import UL.Proof.lem_C_2.H1_HilbertSchmidt
import UL.Proof.lem_A_4.H1_SimplexFit
import UL.Proof.lem_A_5.H1_Simplex
import UL.Proof.prop_C_5.Race2.H0_Defs

set_option autoImplicit false

namespace UL.Proof_prop_C_5_Race2

open MeasureTheory


namespace SignExperiment

structure Design (K d : ℕ) where
  prob : (Fin d → Bool) → EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin K)
  cont : ∀ s, Continuous (prob s)
  mem : ∀ s x, prob s x ∈ UL.Simplex K
  floor : ∀ s x y, 1/(2*(K:ℝ)) ≤ prob s x y
  flip : 1 ≤ d → ∀ s i x, ‖x‖ ≤ 1 →
    ‖prob s x - prob (Function.update s i (!s i)) x‖^2 ≤ (1/((K:ℝ)^2*(d:ℝ)))*(x i)^2

variable {K d : ℕ} (exp : Design K d)

noncomputable def law (μ : Measure (EuclideanSpace ℝ (Fin d))) (s : Fin d → Bool) :=
  (baseJointMeasure (K := K) μ).withDensity (fun z => ENNReal.ofReal (exp.prob s z.1 z.2))

private lemma measurable_condProb_uncurry  (hK : 2 ≤ K) (s : Fin d → Bool) :
    Measurable (fun z : EuclideanSpace ℝ (Fin d) × Fin K => exp.prob s z.1 z.2) := by
  have heq : (fun z : EuclideanSpace ℝ (Fin d) × Fin K => exp.prob s z.1 z.2) =
      fun z => ∑ y : Fin K, if z.2 = y then exp.prob s z.1 y else 0 := by
    ext z
    simp
  rw [heq]
  refine Finset.measurable_sum Finset.univ fun y _ => ?_
  have hy_set : MeasurableSet {z : EuclideanSpace ℝ (Fin d) × Fin K | z.2 = y} :=
    measurable_snd (measurableSet_singleton y)
  have hy_coord : Measurable (fun z : EuclideanSpace ℝ (Fin d) × Fin K => exp.prob s z.1 y) :=
    ((PiLp.continuous_apply 2 _ y).comp (exp.cont s)).measurable.comp measurable_fst
  exact Measurable.ite hy_set hy_coord measurable_const

private lemma condProb_le_one  (hK : 2 ≤ K) (s : Fin d → Bool)
    (x : EuclideanSpace ℝ (Fin d)) (y : Fin K) :
    exp.prob s x y ≤ 1 :=
  UL.Proof_lem_A_4.simplex_coord_le_one (exp.mem s x) y

private lemma condProb_nonneg  (hK : 2 ≤ K) (s : Fin d → Bool)
    (x : EuclideanSpace ℝ (Fin d)) (y : Fin K) :
    0 ≤ exp.prob s x y :=
  (exp.mem s x).1 y

private lemma integrable_of_measurable_bdd_finite {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsFiniteMeasure μ] {g : Ω → ℝ}
    (hg_meas : Measurable g) (C : ℝ) (hg_bdd : ∀ ω, |g ω| ≤ C) :
    Integrable g μ := by
  refine (memLp_top_of_bound hg_meas.aestronglyMeasurable C
    (Filter.Eventually.of_forall fun ω => ?_)).integrable le_top
  rw [Real.norm_eq_abs]
  exact hg_bdd ω

private lemma jointLaw_preimage_fst  (hK : 2 ≤ K)
    (μ_X : Measure (EuclideanSpace ℝ (Fin d))) [IsProbabilityMeasure μ_X]
    (s : Fin d → Bool) {B : Set (EuclideanSpace ℝ (Fin d))} (hB : MeasurableSet B) :
    law exp μ_X s (Prod.fst ⁻¹' B) = μ_X B := by
  unfold law baseJointMeasure
  rw [withDensity_apply _ (measurable_fst hB)]
  have hpre : (Prod.fst ⁻¹' B : Set (EuclideanSpace ℝ (Fin d) × Fin K)) = B ×ˢ Set.univ := by
    ext z; simp
  rw [hpre, ← Measure.prod_restrict, Measure.restrict_univ]
  have hw_meas : Measurable (fun z : EuclideanSpace ℝ (Fin d) × Fin K =>
      ENNReal.ofReal (exp.prob s z.1 z.2)) :=
    (measurable_condProb_uncurry exp hK s).ennreal_ofReal
  rw [lintegral_prod _ hw_meas.aemeasurable]
  have hinner : ∀ x : EuclideanSpace ℝ (Fin d),
      (∫⁻ y : Fin K, ENNReal.ofReal (exp.prob s x y) ∂Measure.count) = 1 := by
    intro x
    rw [lintegral_fintype]
    simp only [Measure.count_singleton, mul_one]
    rw [← ENNReal.ofReal_sum_of_nonneg (fun y _ => condProb_nonneg exp hK s x y),
      (exp.mem s x).2, ENNReal.ofReal_one]
  simp_rw [hinner]
  rw [lintegral_one, Measure.restrict_apply_univ]

lemma jointLaw_isProb  (hK : 2 ≤ K)
    (μ_X : Measure (EuclideanSpace ℝ (Fin d))) [IsProbabilityMeasure μ_X]
    (s : Fin d → Bool) :
    IsProbabilityMeasure (law exp μ_X s) := by
  refine ⟨?_⟩
  have huniv : (Set.univ : Set (EuclideanSpace ℝ (Fin d) × Fin K)) = Prod.fst ⁻¹' Set.univ := rfl
  rw [huniv, jointLaw_preimage_fst exp hK μ_X s MeasurableSet.univ, measure_univ]

lemma jointLaw_fst_eq  (hK : 2 ≤ K)
    (μ_X : Measure (EuclideanSpace ℝ (Fin d))) [IsProbabilityMeasure μ_X]
    (s : Fin d → Bool) :
    (law exp μ_X s).fst = μ_X := by
  ext B hB
  rw [Measure.fst_apply hB, jointLaw_preimage_fst exp hK μ_X s hB]

lemma integral_jointLaw_eq  (hK : 2 ≤ K)
    (μ_X : Measure (EuclideanSpace ℝ (Fin d))) [IsProbabilityMeasure μ_X]
    (s : Fin d → Bool)
    {f : EuclideanSpace ℝ (Fin d) × Fin K → ℝ} (hf_meas : Measurable f)
    (C : ℝ) (hf_bdd : ∀ z, |f z| ≤ C) :
    ∫ z, f z ∂(law exp μ_X s) =
      ∫ x, (∑ y : Fin K, exp.prob s x y * f (x, y)) ∂μ_X := by
  unfold law baseJointMeasure
  have hw_meas : Measurable (fun z : EuclideanSpace ℝ (Fin d) × Fin K =>
      ENNReal.ofReal (exp.prob s z.1 z.2)) :=
    (measurable_condProb_uncurry exp hK s).ennreal_ofReal
  have hw_lt_top : ∀ᵐ z ∂(μ_X.prod Measure.count),
      ENNReal.ofReal (exp.prob s z.1 z.2) < ⊤ :=
    Filter.Eventually.of_forall fun _ => ENNReal.ofReal_lt_top
  rw [integral_withDensity_eq_integral_toReal_smul hw_meas hw_lt_top]
  have hsimp : (fun z : EuclideanSpace ℝ (Fin d) × Fin K =>
      (ENNReal.ofReal (exp.prob s z.1 z.2)).toReal • f z) =
      fun z => exp.prob s z.1 z.2 * f z := by
    ext z
    rw [ENNReal.toReal_ofReal (condProb_nonneg exp hK s z.1 z.2), smul_eq_mul]
  rw [hsimp]
  have hprod_int : Integrable (fun z : EuclideanSpace ℝ (Fin d) × Fin K =>
      exp.prob s z.1 z.2 * f z) (μ_X.prod Measure.count) := by
    refine integrable_of_measurable_bdd_finite
      ((measurable_condProb_uncurry exp hK s).mul hf_meas) (max C 0) fun z => ?_
    rw [abs_mul, abs_of_nonneg (condProb_nonneg exp hK s z.1 z.2)]
    calc exp.prob s z.1 z.2 * |f z|
        ≤ 1 * max C 0 := mul_le_mul (condProb_le_one exp hK s z.1 z.2)
          (le_trans (hf_bdd z) (le_max_left C 0)) (abs_nonneg _) zero_le_one
      _ = max C 0 := one_mul _
  rw [integral_prod _ hprod_int]
  refine integral_congr_ae (Filter.Eventually.of_forall fun x => ?_)
  exact integral_count (fun y : Fin K => exp.prob s x y * f (x, y))

/-! ### Product density and TV bound via chi-square -/

private lemma pi_jointLaw_eq_withDensity {n : ℕ} (hK : 2 ≤ K)
    (μ_X : Measure (EuclideanSpace ℝ (Fin d))) [IsProbabilityMeasure μ_X]
    (s : Fin d → Bool) :
    Measure.pi (fun _ : Fin n => law exp μ_X s) =
      (Measure.pi (fun _ : Fin n => baseJointMeasure (K := K) μ_X)).withDensity
        (fun S => ENNReal.ofReal (∏ t : Fin n, exp.prob s (S t).1 (S t).2)) := by
  haveI : IsProbabilityMeasure (law exp μ_X s) := jointLaw_isProb exp hK μ_X s
  let W := EuclideanSpace ℝ (Fin d) × Fin K
  let lam1 : Measure W := baseJointMeasure (K := K) μ_X
  haveI : IsFiniteMeasure lam1 := by unfold lam1 baseJointMeasure; infer_instance
  let lamN : Measure (Fin n → W) := Measure.pi (fun _ : Fin n => lam1)
  let w : W → ℝ := fun z => exp.prob s z.1 z.2
  have hw_meas : Measurable w := measurable_condProb_uncurry exp hK s
  have hw_nn : ∀ z, 0 ≤ w z := fun z => condProb_nonneg exp hK s z.1 z.2
  have hw_le1 : ∀ z, w z ≤ 1 := fun z => condProb_le_one exp hK s z.1 z.2
  refine Measure.pi_eq fun B hB => ?_
  let R : Set (Fin n → W) := Set.pi Set.univ B
  have hR : MeasurableSet R := MeasurableSet.pi Set.countable_univ fun t _ => hB t
  change lamN.withDensity (fun S => ENNReal.ofReal (∏ t : Fin n, w (S t))) R =
    ∏ t : Fin n, law exp μ_X s (B t)
  rw [withDensity_apply _ hR, ← lintegral_indicator hR]
  let g : Fin n → W → ℝ := fun t => (B t).indicator w
  have hg_nn : ∀ t z, 0 ≤ g t z := fun t z => Set.indicator_nonneg (fun u _ => hw_nn u) z
  have hg_int : ∀ t : Fin n, Integrable (g t) lam1 := by
    intro t
    refine integrable_of_measurable_bdd_finite (hw_meas.indicator (hB t)) 1 fun z => ?_
    rw [abs_of_nonneg (hg_nn t z)]
    by_cases hz : z ∈ B t <;> simp [g, hz, hw_le1 z]
  have hind_eq : ∀ S : Fin n → W,
      R.indicator (fun S => ENNReal.ofReal (∏ t : Fin n, w (S t))) S =
        ENNReal.ofReal (∏ t : Fin n, g t (S t)) := by
    intro S
    by_cases hS : S ∈ R
    · have hall : ∀ t : Fin n, S t ∈ B t := fun t => hS t (Set.mem_univ t)
      have hprod : (∏ t : Fin n, g t (S t)) = ∏ t : Fin n, w (S t) :=
        Finset.prod_congr rfl fun t _ => Set.indicator_of_mem (hall t) w
      rw [Set.indicator_of_mem hS, hprod]
    · have hex : ∃ t : Fin n, S t ∉ B t := by
        by_contra hnot
        push_neg at hnot
        exact hS fun t _ => hnot t
      obtain ⟨t₀, ht₀⟩ := hex
      have hzero : (∏ t : Fin n, g t (S t)) = 0 :=
        Finset.prod_eq_zero (Finset.mem_univ t₀) (Set.indicator_of_notMem ht₀ w)
      rw [Set.indicator_of_notMem hS, hzero, ENNReal.ofReal_zero]
  simp_rw [hind_eq]
  have hprod_int : Integrable (fun S : Fin n → W => ∏ t : Fin n, g t (S t)) lamN :=
    MeasureTheory.Integrable.fintype_prod hg_int
  have hprod_nn : 0 ≤ᵐ[lamN] (fun S : Fin n → W => ∏ t : Fin n, g t (S t)) :=
    Filter.Eventually.of_forall fun S => Finset.prod_nonneg fun t _ => hg_nn t (S t)
  rw [← ofReal_integral_eq_lintegral_ofReal hprod_int hprod_nn,
    MeasureTheory.integral_fintype_prod_eq_prod,
    ENNReal.ofReal_prod_of_nonneg (fun t _ => integral_nonneg (hg_nn t))]
  refine Finset.prod_congr rfl fun t _ => ?_
  rw [ofReal_integral_eq_lintegral_ofReal (hg_int t) (Filter.Eventually.of_forall (hg_nn t))]
  have hind_t : (fun z : W => ENNReal.ofReal (g t z)) =
      (B t).indicator (fun z => ENNReal.ofReal (w z)) := by
    ext z
    by_cases hz : z ∈ B t <;> simp [g, hz]
  rw [hind_t, lintegral_indicator (hB t)]
  exact (withDensity_apply _ (hB t)).symm

private lemma simplex_chiSq_sum_le {K : ℕ} (hK : 2 ≤ K)
    {p q : EuclideanSpace ℝ (Fin K)} (hp : p ∈ UL.Simplex K) (hq : q ∈ UL.Simplex K)
    (hq_floor : ∀ y : Fin K, 1 / (2 * (K : ℝ)) ≤ q y) :
    ∑ y : Fin K, (p y) ^ 2 / (q y) ≤ 1 + 2 * (K : ℝ) * ‖p - q‖ ^ 2 := by
  have hfloor_pos : 0 < 1 / (2 * (K : ℝ)) := by
    have hKpos : (0 : ℝ) < (K : ℝ) := Nat.cast_pos.mpr (by omega)
    positivity
  have hq_pos : ∀ y : Fin K, 0 < q y := fun y => lt_of_lt_of_le hfloor_pos (hq_floor y)
  have hdecomp : ∀ y : Fin K,
      (p y) ^ 2 / (q y) = (p y - q y) ^ 2 / (q y) + 2 * (p y - q y) + q y := by
    intro y
    have hne : q y ≠ 0 := (hq_pos y).ne'
    field_simp [hne]
    ring
  have hsum_eq : ∑ y : Fin K, (p y) ^ 2 / (q y) =
      1 + ∑ y : Fin K, (p y - q y) ^ 2 / (q y) := by
    simp_rw [hdecomp]
    rw [Finset.sum_add_distrib, Finset.sum_add_distrib, ← Finset.mul_sum,
      Finset.sum_sub_distrib, hp.2, hq.2, sub_self, mul_zero, add_zero, add_comm]
  rw [hsum_eq, UL.Proof_lem_A_4.norm_sq_eq_sum, Finset.mul_sum]
  refine add_le_add le_rfl (Finset.sum_le_sum fun y _ => ?_)
  simp only [PiLp.sub_apply]
  have hdiv : (p y - q y) ^ 2 / (q y) ≤ (p y - q y) ^ 2 / (1 / (2 * (K : ℝ))) :=
    div_le_div_of_nonneg_left (sq_nonneg _) hfloor_pos (hq_floor y)
  have heq : (p y - q y) ^ 2 / (1 / (2 * (K : ℝ))) = 2 * (K : ℝ) * (p y - q y) ^ 2 := by
    have hK0 : (K : ℝ) ≠ 0 := by exact_mod_cast (by omega : K ≠ 0)
    field_simp [hK0]
  linarith

private lemma one_sample_ratio_integral_le  (hK : 2 ≤ K) (hd : 1 ≤ d)
    (μ_X : Measure (EuclideanSpace ℝ (Fin d))) [IsProbabilityMeasure μ_X]
    (hnorm : ∀ᵐ x ∂μ_X, ‖x‖ = 1)
    (hcov : ∀ i j : Fin d, ∫ x, x i * x j ∂μ_X = if i = j then 1 / (d : ℝ) else 0)
    (s : Fin d → Bool) (i : Fin d) :
    let s' := Function.update s i (!s i)
    ∫ z, (exp.prob s z.1 z.2) ^ 2 / (exp.prob s' z.1 z.2)
      ∂(baseJointMeasure (K := K) μ_X) ≤ 1 + 2 / ((K : ℝ) * (d : ℝ) ^ 2) := by
  intro s'
  unfold baseJointMeasure
  have hK_pos : (0 : ℝ) < (K : ℝ) := Nat.cast_pos.mpr (by omega)
  have hd_pos : (0 : ℝ) < (d : ℝ) := Nat.cast_pos.mpr (by omega)
  have hfloor_pos : 0 < 1 / (2 * (K : ℝ)) := by positivity
  let r : EuclideanSpace ℝ (Fin d) × Fin K → ℝ :=
    fun z => (exp.prob s z.1 z.2) ^ 2 / (exp.prob s' z.1 z.2)
  have hr_meas : Measurable r :=
    ((measurable_condProb_uncurry exp hK s).pow_const 2).div (measurable_condProb_uncurry exp hK s')
  have hr_nn : ∀ z, 0 ≤ r z := fun z =>
    div_nonneg (sq_nonneg _) (le_trans hfloor_pos.le (exp.floor s' z.1 z.2))
  have hr_le : ∀ z, r z ≤ 2 * (K : ℝ) := by
    intro z
    have hp1 : (exp.prob s z.1 z.2) ^ 2 ≤ 1 := by
      have h0 := condProb_nonneg exp hK s z.1 z.2
      have h1 := condProb_le_one exp hK s z.1 z.2
      nlinarith
    calc (exp.prob s z.1 z.2) ^ 2 / (exp.prob s' z.1 z.2)
        ≤ 1 / (1 / (2 * (K : ℝ))) :=
          div_le_div₀ zero_le_one hp1 hfloor_pos (exp.floor s' z.1 z.2)
      _ = 2 * (K : ℝ) := by field_simp [hK_pos.ne']
  have hr_int : Integrable r (μ_X.prod Measure.count) :=
    integrable_of_measurable_bdd_finite hr_meas (2 * (K : ℝ)) fun z => by
      rw [abs_of_nonneg (hr_nn z)]; exact hr_le z
  rw [integral_prod _ hr_int]
  have hcount : ∀ x : EuclideanSpace ℝ (Fin d),
      (∫ y : Fin K, r (x, y) ∂Measure.count) =
        ∑ y : Fin K, (exp.prob s x y) ^ 2 / (exp.prob s' x y) :=
    fun x => integral_count (fun y : Fin K => r (x, y))
  simp_rw [hcount]
  let lhsX : EuclideanSpace ℝ (Fin d) → ℝ :=
    fun x => ∑ y : Fin K, (exp.prob s x y) ^ 2 / (exp.prob s' x y)
  let rhsX : EuclideanSpace ℝ (Fin d) → ℝ :=
    fun x => 1 + (2 / ((K : ℝ) * (d : ℝ))) * (x i) ^ 2
  have hlhs_int : Integrable lhsX μ_X := by
    have hlhs_meas : Measurable lhsX := Finset.measurable_sum Finset.univ fun y _ =>
      ((((PiLp.continuous_apply 2 _ y).comp (exp.cont s)).measurable.pow_const 2).div
        (((PiLp.continuous_apply 2 _ y).comp (exp.cont s')).measurable))
    refine integrable_of_measurable_bdd_finite hlhs_meas ((K : ℝ) * (2 * (K : ℝ))) fun x => ?_
    have hnn : 0 ≤ lhsX x := Finset.sum_nonneg fun y _ => hr_nn (x, y)
    rw [abs_of_nonneg hnn]
    calc ∑ y : Fin K, r (x, y)
        ≤ ∑ _y : Fin K, 2 * (K : ℝ) := Finset.sum_le_sum fun y _ => hr_le (x, y)
      _ = (K : ℝ) * (2 * (K : ℝ)) := by
          rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
  have hxi2_int : Integrable (fun x : EuclideanSpace ℝ (Fin d) => (x i) ^ 2) μ_X := by
    have hmeas : Measurable (fun x : EuclideanSpace ℝ (Fin d) => (x i) ^ 2) :=
      ((PiLp.continuous_apply 2 _ i).pow 2).measurable
    refine (memLp_top_of_bound hmeas.aestronglyMeasurable 1 ?_).integrable le_top
    filter_upwards [hnorm] with x hx
    rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
    have hxi : |x i| ≤ 1 := by
      have h := PiLp.norm_apply_le x i
      rwa [Real.norm_eq_abs, hx] at h
    nlinarith [abs_nonneg (x i), sq_abs (x i)]
  have hrhs_int : Integrable rhsX μ_X :=
    (integrable_const 1).add (hxi2_int.const_mul (2 / ((K : ℝ) * (d : ℝ))))
  have hae_le : lhsX ≤ᵐ[μ_X] rhsX := by
    filter_upwards [hnorm] with x hx
    have hx1 : ‖x‖ ≤ 1 := hx.le
    calc lhsX x
        ≤ 1 + 2 * (K : ℝ) * ‖exp.prob s x - exp.prob s' x‖ ^ 2 :=
          simplex_chiSq_sum_le hK (exp.mem s x) (exp.mem s' x)
            (exp.floor s' x)
      _ ≤ 1 + 2 * (K : ℝ) * ((1 / ((K : ℝ) ^ 2 * (d : ℝ))) * (x i) ^ 2) := by
          gcongr
          exact exp.flip hd s i x hx1
      _ = rhsX x := by
          dsimp [rhsX]
          field_simp [hK_pos.ne', hd_pos.ne']
  calc ∫ x, lhsX x ∂μ_X
      ≤ ∫ x, rhsX x ∂μ_X := integral_mono_ae hlhs_int hrhs_int hae_le
    _ = (∫ _x, (1 : ℝ) ∂μ_X) +
          (2 / ((K : ℝ) * (d : ℝ))) * ∫ x, (x i) ^ 2 ∂μ_X := by
        rw [integral_add (integrable_const 1) (hxi2_int.const_mul _), integral_const_mul]
    _ = 1 + (2 / ((K : ℝ) * (d : ℝ))) * (1 / (d : ℝ)) := by
        have h1 : (∫ _x, (1 : ℝ) ∂μ_X) = 1 := by simp
        have h2 : (∫ x, (x i) ^ 2 ∂μ_X) = 1 / (d : ℝ) := by
          simp_rw [sq]
          simpa using hcov i i
        rw [h1, h2]
    _ = 1 + 2 / ((K : ℝ) * (d : ℝ) ^ 2) := by
        field_simp [hK_pos.ne', hd_pos.ne']

private lemma exp_one_eighth_le : Real.exp (1 / 8 : ℝ) ≤ 8 / 7 := by
  have h1 : (7 : ℝ) / 8 ≤ Real.exp (-(1 / 8 : ℝ)) := by
    have h := Real.add_one_le_exp (-(1 / 8 : ℝ))
    linarith
  rw [Real.exp_neg] at h1
  have hexp_pos : 0 < Real.exp (1 / 8 : ℝ) := Real.exp_pos _
  have hmul : ((7 : ℝ) / 8) * Real.exp (1 / 8 : ℝ) ≤
      (Real.exp (1 / 8 : ℝ))⁻¹ * Real.exp (1 / 8 : ℝ) :=
    mul_le_mul_of_nonneg_right h1 hexp_pos.le
  rw [inv_mul_cancel₀ hexp_pos.ne'] at hmul
  linarith

private lemma abs_sub_le_chiSq_add_quarter {a b : ℝ} (hb : 0 < b) :
    |a - b| ≤ (a - b) ^ 2 / b + (1 / 4) * b := by
  have hsq : 0 ≤ (2 * |a - b| - b) ^ 2 := sq_nonneg _
  have hab : |a - b| ^ 2 = (a - b) ^ 2 := sq_abs (a - b)
  have hquad : |a - b| * (4 * b) ≤ 4 * (a - b) ^ 2 + b ^ 2 := by nlinarith
  have hrhs : (a - b) ^ 2 / b + (1 / 4) * b = (4 * (a - b) ^ 2 + b ^ 2) / (4 * b) := by
    field_simp [hb.ne']
  rw [hrhs, le_div_iff₀ (by positivity : 0 < 4 * b)]
  exact hquad

private lemma pi_jointLaw_tv_le_quarter {n : ℕ} (hK : 2 ≤ K) (hd : 1 ≤ d)
    (hn : (n : ℝ) ≤ (K : ℝ) * (d : ℝ) ^ 2 / 16)
    (μ_X : Measure (EuclideanSpace ℝ (Fin d))) [IsProbabilityMeasure μ_X]
    (hnorm : ∀ᵐ x ∂μ_X, ‖x‖ = 1)
    (hcov : ∀ i j : Fin d, ∫ x, x i * x j ∂μ_X = if i = j then 1 / (d : ℝ) else 0)
    (s : Fin d → Bool) (i : Fin d)
    {B : Set (Fin n → EuclideanSpace ℝ (Fin d) × Fin K)} (hB : MeasurableSet B) :
    |((Measure.pi (fun _ : Fin n => law exp μ_X s)) B).toReal -
      ((Measure.pi (fun _ : Fin n =>
        law exp μ_X (Function.update s i (!s i)))) B).toReal| ≤ 1 / 4 := by
  let s' := Function.update s i (!s i)
  let W := EuclideanSpace ℝ (Fin d) × Fin K
  let lam1 : Measure W := baseJointMeasure (K := K) μ_X
  haveI : IsFiniteMeasure lam1 := by unfold lam1 baseJointMeasure; infer_instance
  let lamN : Measure (Fin n → W) := Measure.pi (fun _ : Fin n => lam1)
  have hK_pos : (0 : ℝ) < (K : ℝ) := Nat.cast_pos.mpr (by omega)
  have hd_pos : (0 : ℝ) < (d : ℝ) := Nat.cast_pos.mpr (by omega)
  have hfloor_pos : 0 < 1 / (2 * (K : ℝ)) := by positivity
  let p : W → ℝ := fun z => exp.prob s z.1 z.2
  let q : W → ℝ := fun z => exp.prob s' z.1 z.2
  let F : (Fin n → W) → ℝ := fun S => ∏ t : Fin n, p (S t)
  let G : (Fin n → W) → ℝ := fun S => ∏ t : Fin n, q (S t)
  have hp_int : Integrable p lam1 :=
    integrable_of_measurable_bdd_finite (measurable_condProb_uncurry exp hK s) 1 fun z => by
      rw [abs_of_nonneg (condProb_nonneg exp hK s z.1 z.2)]; exact condProb_le_one exp hK s z.1 z.2
  have hq_int : Integrable q lam1 :=
    integrable_of_measurable_bdd_finite (measurable_condProb_uncurry exp hK s') 1 fun z => by
      rw [abs_of_nonneg (condProb_nonneg exp hK s' z.1 z.2)]; exact condProb_le_one exp hK s' z.1 z.2
  have hF_int : Integrable F lamN := MeasureTheory.Integrable.fintype_prod fun _ => hp_int
  have hG_int : Integrable G lamN := MeasureTheory.Integrable.fintype_prod fun _ => hq_int
  have hF_nn : ∀ S, 0 ≤ F S := fun S =>
    Finset.prod_nonneg fun t _ => condProb_nonneg exp hK s (S t).1 (S t).2
  have hG_pos : ∀ S, 0 < G S := fun S =>
    Finset.prod_pos fun t _ => lt_of_lt_of_le hfloor_pos (exp.floor s' (S t).1 (S t).2)
  have hp_int1 : ∫ z, p z ∂lam1 = 1 := by
    unfold lam1 baseJointMeasure
    rw [integral_prod _ hp_int]
    have hinner : ∀ x : EuclideanSpace ℝ (Fin d),
        (∫ y : Fin K, p (x, y) ∂Measure.count) = 1 := by
      intro x
      rw [integral_count]
      exact (exp.mem s x).2
    simp_rw [hinner]
    simp
  have hq_int1 : ∫ z, q z ∂lam1 = 1 := by
    unfold lam1 baseJointMeasure
    rw [integral_prod _ hq_int]
    have hinner : ∀ x : EuclideanSpace ℝ (Fin d),
        (∫ y : Fin K, q (x, y) ∂Measure.count) = 1 := by
      intro x
      rw [integral_count]
      exact (exp.mem s' x).2
    simp_rw [hinner]
    simp
  have hF_int1 : ∫ S, F S ∂lamN = 1 := by
    dsimp [F]
    rw [MeasureTheory.integral_fintype_prod_eq_pow, hp_int1, one_pow]
  have hG_int1 : ∫ S, G S ∂lamN = 1 := by
    dsimp [G]
    rw [MeasureTheory.integral_fintype_prod_eq_pow, hq_int1, one_pow]
  let r : W → ℝ := fun z => (p z) ^ 2 / (q z)
  have hr_int : Integrable r lam1 := by
    refine integrable_of_measurable_bdd_finite
      (((measurable_condProb_uncurry exp hK s).pow_const 2).div (measurable_condProb_uncurry exp hK s'))
      (2 * (K : ℝ)) fun z => ?_
    have hr_nn : 0 ≤ r z :=
      div_nonneg (sq_nonneg _) (le_trans hfloor_pos.le (exp.floor s' z.1 z.2))
    rw [abs_of_nonneg hr_nn]
    have hp1 : (p z) ^ 2 ≤ 1 := by
      have h0 := condProb_nonneg exp hK s z.1 z.2
      have h1 := condProb_le_one exp hK s z.1 z.2
      nlinarith
    calc (p z) ^ 2 / (q z)
        ≤ 1 / (1 / (2 * (K : ℝ))) :=
          div_le_div₀ zero_le_one hp1 hfloor_pos (exp.floor s' z.1 z.2)
      _ = 2 * (K : ℝ) := by field_simp [hK_pos.ne']
  have hFG_eq : (fun S : Fin n → W => (F S) ^ 2 / (G S)) = fun S => ∏ t : Fin n, r (S t) := by
    ext S
    dsimp [F, G, r]
    rw [← Finset.prod_pow, Finset.prod_div_distrib]
  have hFG_int : Integrable (fun S : Fin n → W => (F S) ^ 2 / (G S)) lamN := by
    rw [hFG_eq]
    exact MeasureTheory.Integrable.fintype_prod fun _ => hr_int
  have hFG_le : ∫ S, (F S) ^ 2 / (G S) ∂lamN ≤ 8 / 7 := by
    rw [hFG_eq, MeasureTheory.integral_fintype_prod_eq_pow, Fintype.card_fin]
    have hr_int_nn : 0 ≤ ∫ z, r z ∂lam1 :=
      integral_nonneg fun z =>
        div_nonneg (sq_nonneg _) (le_trans hfloor_pos.le (exp.floor s' z.1 z.2))
    have hr_le1 : ∫ z, r z ∂lam1 ≤ 1 + 2 / ((K : ℝ) * (d : ℝ) ^ 2) :=
      one_sample_ratio_integral_le exp hK hd μ_X hnorm hcov s i
    let u : ℝ := 2 / ((K : ℝ) * (d : ℝ) ^ 2)
    have hu_nn : 0 ≤ u := by positivity
    have h1u_exp : 1 + u ≤ Real.exp u := by
      have h := Real.add_one_le_exp u
      linarith
    have hnu : (n : ℝ) * u ≤ 1 / 8 := by
      calc (n : ℝ) * u
          ≤ ((K : ℝ) * (d : ℝ) ^ 2 / 16) * (2 / ((K : ℝ) * (d : ℝ) ^ 2)) :=
            mul_le_mul_of_nonneg_right hn hu_nn
        _ = 1 / 8 := by field_simp [hK_pos.ne', hd_pos.ne']; ring
    calc (∫ z, r z ∂lam1) ^ n
        ≤ (1 + u) ^ n := pow_le_pow_left₀ hr_int_nn hr_le1 n
      _ ≤ (Real.exp u) ^ n := pow_le_pow_left₀ (by positivity) h1u_exp n
      _ = Real.exp ((n : ℝ) * u) := (Real.exp_nat_mul u n).symm
      _ ≤ Real.exp (1 / 8 : ℝ) := Real.exp_le_exp.mpr hnu
      _ ≤ 8 / 7 := exp_one_eighth_le
  have hchi_eq : (fun S : Fin n → W => (F S - G S) ^ 2 / (G S)) =
      fun S => (F S) ^ 2 / (G S) - 2 * F S + G S := by
    ext S
    have hne : G S ≠ 0 := (hG_pos S).ne'
    field_simp [hne]
    ring
  have hsub_int : Integrable (fun S : Fin n → W => (F S) ^ 2 / (G S) - 2 * F S) lamN :=
    hFG_int.sub (hF_int.const_mul 2)
  have hchi_int : Integrable (fun S : Fin n → W => (F S - G S) ^ 2 / (G S)) lamN := by
    rw [hchi_eq]
    exact hsub_int.add hG_int
  have hchi_le : ∫ S, (F S - G S) ^ 2 / (G S) ∂lamN ≤ 1 / 7 := by
    rw [hchi_eq, integral_add hsub_int hG_int,
      integral_sub hFG_int (hF_int.const_mul 2), integral_const_mul, hF_int1, hG_int1]
    linarith
  have hFG_sub_int : Integrable (fun S : Fin n → W => F S - G S) lamN := hF_int.sub hG_int
  have hFG_abs_int : Integrable (fun S : Fin n → W => |F S - G S|) lamN := hFG_sub_int.abs
  have hl1_le : ∫ S, |F S - G S| ∂lamN ≤ 1 / 2 := by
    have hpt : ∀ S : Fin n → W, |F S - G S| ≤ (F S - G S) ^ 2 / (G S) + (1 / 4) * G S :=
      fun S => abs_sub_le_chiSq_add_quarter (hG_pos S)
    have hrhs_int : Integrable (fun S : Fin n → W =>
        (F S - G S) ^ 2 / (G S) + (1 / 4) * G S) lamN :=
      hchi_int.add (hG_int.const_mul (1 / 4))
    calc ∫ S, |F S - G S| ∂lamN
        ≤ ∫ S, ((F S - G S) ^ 2 / (G S) + (1 / 4) * G S) ∂lamN :=
          integral_mono hFG_abs_int hrhs_int hpt
      _ = (∫ S, (F S - G S) ^ 2 / (G S) ∂lamN) + (1 / 4) * (∫ S, G S ∂lamN) := by
          rw [integral_add hchi_int (hG_int.const_mul (1 / 4)), integral_const_mul]
      _ ≤ 1 / 7 + (1 / 4) * 1 := by rw [hG_int1]; linarith
      _ ≤ 1 / 2 := by norm_num
  have hPs_B : ((Measure.pi (fun _ : Fin n => law exp μ_X s)) B).toReal =
      ∫ S in B, F S ∂lamN := by
    rw [pi_jointLaw_eq_withDensity exp hK μ_X s, withDensity_apply _ hB,
      ← ofReal_integral_eq_lintegral_ofReal hF_int.integrableOn
        (Filter.Eventually.of_forall hF_nn),
      ENNReal.toReal_ofReal (setIntegral_nonneg hB fun S _ => hF_nn S)]
  have hPs'_B : ((Measure.pi (fun _ : Fin n => law exp μ_X s')) B).toReal =
      ∫ S in B, G S ∂lamN := by
    have hG_nn : ∀ S, 0 ≤ G S := fun S => (hG_pos S).le
    rw [pi_jointLaw_eq_withDensity exp hK μ_X s', withDensity_apply _ hB,
      ← ofReal_integral_eq_lintegral_ofReal hG_int.integrableOn
        (Filter.Eventually.of_forall hG_nn),
      ENNReal.toReal_ofReal (setIntegral_nonneg hB fun S _ => hG_nn S)]
  rw [hPs_B, hPs'_B, ← integral_sub hF_int.integrableOn hG_int.integrableOn]
  have hsum_zero : (∫ S in B, (F S - G S) ∂lamN) + (∫ S in Bᶜ, (F S - G S) ∂lamN) = 0 := by
    rw [integral_add_compl hB hFG_sub_int, integral_sub hF_int hG_int,
      hF_int1, hG_int1, sub_self]
  have hcompl_abs : |∫ S in Bᶜ, (F S - G S) ∂lamN| = |∫ S in B, (F S - G S) ∂lamN| := by
    have hneg : (∫ S in Bᶜ, (F S - G S) ∂lamN) = -(∫ S in B, (F S - G S) ∂lamN) := by
      linarith
    rw [hneg, abs_neg]
  have h2abs : 2 * |∫ S in B, (F S - G S) ∂lamN| ≤ ∫ S, |F S - G S| ∂lamN := by
    calc 2 * |∫ S in B, (F S - G S) ∂lamN|
        = |∫ S in B, (F S - G S) ∂lamN| + |∫ S in Bᶜ, (F S - G S) ∂lamN| := by
          rw [hcompl_abs]; ring
      _ ≤ (∫ S in B, |F S - G S| ∂lamN) + (∫ S in Bᶜ, |F S - G S| ∂lamN) :=
          add_le_add abs_integral_le_integral_abs abs_integral_le_integral_abs
      _ = ∫ S, |F S - G S| ∂lamN :=
          integral_add_compl hB hFG_abs_int
  linarith

lemma prod_jointLaw_tv_le_quarter {n : ℕ} (hK : 2 ≤ K) (hd : 1 ≤ d)
    (hn : (n : ℝ) ≤ (K : ℝ) * (d : ℝ) ^ 2 / 16)
    (μ_X : Measure (EuclideanSpace ℝ (Fin d))) [IsProbabilityMeasure μ_X]
    (hnorm : ∀ᵐ x ∂μ_X, ‖x‖ = 1)
    (hcov : ∀ i j : Fin d, ∫ x, x i * x j ∂μ_X = if i = j then 1 / (d : ℝ) else 0)
    (Ξ : Type*) [MeasurableSpace Ξ] (ν : Measure Ξ) [IsProbabilityMeasure ν]
    (s : Fin d → Bool) (i : Fin d)
    {A : Set (Ξ × (Fin n → EuclideanSpace ℝ (Fin d) × Fin K))} (hA : MeasurableSet A) :
    |((ν.prod (Measure.pi (fun _ : Fin n => law exp μ_X s))) A).toReal -
      ((ν.prod (Measure.pi (fun _ : Fin n =>
        law exp μ_X (Function.update s i (!s i))))) A).toReal| ≤ 1 / 4 := by
  let s' := Function.update s i (!s i)
  haveI : IsProbabilityMeasure (law exp μ_X s) := jointLaw_isProb exp hK μ_X s
  haveI : IsProbabilityMeasure (law exp μ_X s') := jointLaw_isProb exp hK μ_X s'
  let Ps := Measure.pi (fun _ : Fin n => law exp μ_X s)
  let Ps' := Measure.pi (fun _ : Fin n => law exp μ_X s')
  have hslice_s : ((ν.prod Ps) A).toReal = ∫ ξ, (Ps (Prod.mk ξ ⁻¹' A)).toReal ∂ν := by
    rw [Measure.prod_apply hA, ← integral_toReal
      (measurable_measure_prodMk_left hA).aemeasurable
      (Filter.Eventually.of_forall fun _ => measure_lt_top Ps _)]
  have hslice_s' : ((ν.prod Ps') A).toReal = ∫ ξ, (Ps' (Prod.mk ξ ⁻¹' A)).toReal ∂ν := by
    rw [Measure.prod_apply hA, ← integral_toReal
      (measurable_measure_prodMk_left hA).aemeasurable
      (Filter.Eventually.of_forall fun _ => measure_lt_top Ps' _)]
  have hg_int : Integrable (fun ξ : Ξ => (Ps (Prod.mk ξ ⁻¹' A)).toReal) ν := by
    refine integrable_of_measurable_bdd_finite
      (measurable_measure_prodMk_left hA).ennreal_toReal 1 fun ξ => ?_
    rw [abs_of_nonneg ENNReal.toReal_nonneg]
    calc (Ps (Prod.mk ξ ⁻¹' A)).toReal
        ≤ (Ps Set.univ).toReal := ENNReal.toReal_mono (measure_ne_top Ps _)
          (measure_mono (Set.subset_univ _))
      _ = 1 := by simp
  have hg'_int : Integrable (fun ξ : Ξ => (Ps' (Prod.mk ξ ⁻¹' A)).toReal) ν := by
    refine integrable_of_measurable_bdd_finite
      (measurable_measure_prodMk_left hA).ennreal_toReal 1 fun ξ => ?_
    rw [abs_of_nonneg ENNReal.toReal_nonneg]
    calc (Ps' (Prod.mk ξ ⁻¹' A)).toReal
        ≤ (Ps' Set.univ).toReal := ENNReal.toReal_mono (measure_ne_top Ps' _)
          (measure_mono (Set.subset_univ _))
      _ = 1 := by simp
  rw [hslice_s, hslice_s', ← integral_sub hg_int hg'_int]
  calc |∫ ξ, ((Ps (Prod.mk ξ ⁻¹' A)).toReal - (Ps' (Prod.mk ξ ⁻¹' A)).toReal) ∂ν|
      ≤ ∫ ξ, |(Ps (Prod.mk ξ ⁻¹' A)).toReal - (Ps' (Prod.mk ξ ⁻¹' A)).toReal| ∂ν :=
        abs_integral_le_integral_abs
    _ ≤ ∫ _ξ, (1 / 4 : ℝ) ∂ν := by
        refine integral_mono (hg_int.sub hg'_int).abs (integrable_const (1 / 4 : ℝ)) fun ξ => ?_
        exact pi_jointLaw_tv_le_quarter exp hK hd hn μ_X hnorm hcov s i (measurable_prodMk_left hA)
    _ = 1 / 4 := by simp

end SignExperiment
end UL.Proof_prop_C_5_Race2

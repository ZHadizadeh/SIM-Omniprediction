import Mathlib
import UL.Stmt.prop_C_5
import UL.Proof.lem_A_5.H1_Simplex

set_option autoImplicit false

namespace UL.Proof_prop_C_5_Race2

/-- Quadratic entropy `Φ(q) = (1/2) ‖q - u‖^2` on `Simplex K`, matching `S_prop_C_5`. -/
noncomputable def quadEntropy (K : ℕ) : UL.Simplex K → ℝ :=
  fun q => ((1 : ℝ) / 2) * ‖(q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K‖ ^ 2

/-- Unit zero-sum vector `v = (1 / √2) • (e_0 - e_1) ∈ ZeroSumSubspace K` for `2 ≤ K`. -/
noncomputable def dirVec (K : ℕ) (hK : 2 ≤ K) : EuclideanSpace ℝ (Fin K) :=
  (1 / Real.sqrt 2) •
    (EuclideanSpace.single ⟨0, by omega⟩ (1 : ℝ) -
      EuclideanSpace.single ⟨1, by omega⟩ (1 : ℝ))

lemma dirVec_mem_zeroSumSubspace {K : ℕ} (hK : 2 ≤ K) :
    dirVec K hK ∈ UL.ZeroSumSubspace K := by
  rw [UL.Proof_lem_A_5.mem_zeroSumSubspace_iff]
  unfold dirVec
  have h01 : (⟨0, by omega⟩ : Fin K) ≠ ⟨1, by omega⟩ := by simp
  simp [PiLp.smul_apply, PiLp.sub_apply, EuclideanSpace.single_apply, Finset.sum_sub_distrib,
    ← Finset.mul_sum]

lemma norm_dirVec_sq {K : ℕ} (hK : 2 ≤ K) : ‖dirVec K hK‖ ^ 2 = 1 := by
  unfold dirVec
  set e0 : EuclideanSpace ℝ (Fin K) := EuclideanSpace.single ⟨0, by omega⟩ (1 : ℝ)
  set e1 : EuclideanSpace ℝ (Fin K) := EuclideanSpace.single ⟨1, by omega⟩ (1 : ℝ)
  have h01 : (⟨0, by omega⟩ : Fin K) ≠ ⟨1, by omega⟩ := by simp
  have horth : inner ℝ e0 e1 = 0 := by
    simp [e0, e1, PiLp.inner_apply, EuclideanSpace.single_apply, h01]
  have he0 : ‖e0‖ = 1 := by simp [e0, EuclideanSpace.norm_single]
  have he1 : ‖e1‖ = 1 := by simp [e1, EuclideanSpace.norm_single]
  have hdiff : ‖e0 - e1‖ ^ 2 = 2 := by
    rw [norm_sub_sq_real, he0, he1, horth]
    norm_num
  have hsqrt_pos : 0 < 1 / Real.sqrt 2 := by positivity
  rw [norm_smul, Real.norm_eq_abs, abs_of_pos hsqrt_pos, mul_pow, hdiff, one_div, inv_pow,
    Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)]
  norm_num

lemma norm_dirVec {K : ℕ} (hK : 2 ≤ K) : ‖dirVec K hK‖ = 1 := by
  have hsq := norm_dirVec_sq hK
  have hnn := norm_nonneg (dirVec K hK)
  nlinarith

/-- Scale parameter `a = 1 / (2 * K)`. -/
noncomputable def scaleA (K : ℕ) : ℝ := 1 / (2 * (K : ℝ))

/-- Sign weight vector `w_s ∈ ℝ^d` with coordinates `± a / √d`. -/
noncomputable def signWeight (K d : ℕ) (s : Fin d → Bool) : EuclideanSpace ℝ (Fin d) :=
  (WithLp.equiv 2 (Fin d → ℝ)).symm fun i =>
    (scaleA K / Real.sqrt (d : ℝ)) * (if s i then (1 : ℝ) else -1)

@[simp]
lemma signWeight_apply (K d : ℕ) (s : Fin d → Bool) (i : Fin d) :
    signWeight K d s i = (scaleA K / Real.sqrt (d : ℝ)) * (if s i then (1 : ℝ) else -1) := rfl

/-- Rank-1 linear score operator `V_s(x) = ⟪w_s, x⟫ • v` into `ZeroSumSubspace K`. -/
noncomputable def scoreOp (K : ℕ) (hK : 2 ≤ K) (d : ℕ) (s : Fin d → Bool) :
    EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K :=
  (innerSL ℝ (signWeight K d s)).smulRight ⟨dirVec K hK, dirVec_mem_zeroSumSubspace hK⟩

lemma scoreOp_coe_apply (K : ℕ) (hK : 2 ≤ K) (d : ℕ) (s : Fin d → Bool)
    (x : EuclideanSpace ℝ (Fin d)) :
    ((scoreOp K hK d s x : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) =
      inner ℝ (signWeight K d s) x • dirVec K hK := rfl

/-- Clamped scalar score `max (-a) (min a ⟪w_s, x⟫)` so `condProb` stays in `Simplex K` for all `x`. -/
noncomputable def clampedScore (K d : ℕ) (s : Fin d → Bool) (x : EuclideanSpace ℝ (Fin d)) : ℝ :=
  max (-scaleA K) (min (scaleA K) (inner ℝ (signWeight K d s) x))

/-- Conditional label distribution `η_s(x) = u + clampedScore(x) • v ∈ Simplex K`. -/
noncomputable def condProb (K : ℕ) (hK : 2 ≤ K) (d : ℕ) (s : Fin d → Bool)
    (x : EuclideanSpace ℝ (Fin d)) : EuclideanSpace ℝ (Fin K) :=
  UL.uniformVec K + clampedScore K d s x • dirVec K hK

/-- Reference product measure `μ_X × count` on `ℝ^d × Fin K`. -/
noncomputable def baseJointMeasure {d K : ℕ}
    (μ_X : MeasureTheory.Measure (EuclideanSpace ℝ (Fin d))) :
    MeasureTheory.Measure (EuclideanSpace ℝ (Fin d) × Fin K) :=
  μ_X.prod MeasureTheory.Measure.count

/-- Joint feature-label law `μ_s` with feature marginal `μ_X` and conditional law `condProb`. -/
noncomputable def jointLaw (K : ℕ) (hK : 2 ≤ K) {d : ℕ}
    (μ_X : MeasureTheory.Measure (EuclideanSpace ℝ (Fin d))) (s : Fin d → Bool) :
    MeasureTheory.Measure (EuclideanSpace ℝ (Fin d) × Fin K) :=
  (baseJointMeasure (K := K) μ_X).withDensity
    (fun z => ENNReal.ofReal (condProb K hK d s z.1 z.2))

end UL.Proof_prop_C_5_Race2

import UL.Proof.prop_C_5.Race2.SignExperiment
import Mathlib
import UL.Stmt.prop_C_5
import UL.Proof.lem_C_2.H1_HilbertSchmidt
import UL.Proof.lem_A_4.H1_SimplexFit
import UL.Proof.lem_A_5.H1_Simplex
import UL.Proof.prop_C_5.Race2.H0_Defs

set_option autoImplicit false

namespace UL.Proof_prop_C_5_Race2

open MeasureTheory

private lemma scaleA_pos {K : ℕ} (hK : 2 ≤ K) : 0 < scaleA K := by
  unfold scaleA
  have hKpos : (0 : ℝ) < (K : ℝ) := Nat.cast_pos.mpr (by omega)
  positivity

private lemma scaleA_nonneg (K : ℕ) : 0 ≤ scaleA K := by
  unfold scaleA
  positivity

private lemma scaleA_le_quarter {K : ℕ} (hK : 2 ≤ K) : scaleA K ≤ 1 / 4 := by
  unfold scaleA
  have hK2 : (2 : ℝ) ≤ (K : ℝ) := by exact_mod_cast hK
  have hpos : (0 : ℝ) < 2 * (K : ℝ) := by linarith
  rw [div_le_div_iff₀ hpos (by norm_num : (0 : ℝ) < 4)]
  linarith

private lemma norm_signWeight_sq {K d : ℕ} (hd : 1 ≤ d) (s : Fin d → Bool) :
    ‖signWeight K d s‖ ^ 2 = (scaleA K) ^ 2 := by
  rw [EuclideanSpace.norm_sq_eq]
  have hd_pos : (0 : ℝ) < (d : ℝ) := Nat.cast_pos.mpr (by omega)
  have hterm : ∀ i : Fin d, ‖signWeight K d s i‖ ^ 2 = (scaleA K) ^ 2 / (d : ℝ) := by
    intro i
    rw [signWeight_apply, Real.norm_eq_abs, sq_abs, mul_pow, div_pow,
      Real.sq_sqrt hd_pos.le]
    cases s i <;> simp
  simp_rw [hterm]
  rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
  field_simp [hd_pos.ne']

private lemma norm_signWeight {K d : ℕ} (hd : 1 ≤ d) (s : Fin d → Bool) :
    ‖signWeight K d s‖ = scaleA K := by
  have hsq := norm_signWeight_sq (K := K) hd s
  have h1 := norm_nonneg (signWeight K d s)
  have h2 := scaleA_nonneg K
  nlinarith

lemma hilbertSchmidtNorm_scoreOp_le_one {K d : ℕ} (hK : 2 ≤ K) (hd : 1 ≤ d)
    (s : Fin d → Bool) :
    UL.hilbertSchmidtNorm (scoreOp K hK d s) ≤ 1 := by
  let vSub : UL.ZeroSumSubspace K := ⟨dirVec K hK, dirVec_mem_zeroSumSubspace hK⟩
  have hadj : ∀ h : UL.ZeroSumSubspace K,
      UL.Proof_lem_C_2.adjVec (scoreOp K hK d s) h =
        inner ℝ h vSub • signWeight K d s := by
    intro h
    refine ext_inner_right ℝ fun x => ?_
    rw [UL.Proof_lem_C_2.inner_adjVec_left, inner_smul_left, conj_trivial]
    change inner ℝ h (inner ℝ (signWeight K d s) x • vSub) =
      inner ℝ h vSub * inner ℝ (signWeight K d s) x
    rw [inner_smul_right, mul_comm]
  have hsq : UL.hilbertSchmidtNorm (scoreOp K hK d s) ^ 2 = (scaleA K) ^ 2 := by
    rw [UL.Proof_lem_C_2.hilbertSchmidtNorm_sq]
    dsimp only
    simp_rw [hadj]
    have hterm : ∀ j : Fin (Module.finrank ℝ (UL.ZeroSumSubspace K)),
        ‖inner ℝ (stdOrthonormalBasis ℝ (UL.ZeroSumSubspace K) j) vSub • signWeight K d s‖ ^ 2 =
          (inner ℝ vSub (stdOrthonormalBasis ℝ (UL.ZeroSumSubspace K) j) *
            inner ℝ (stdOrthonormalBasis ℝ (UL.ZeroSumSubspace K) j) vSub) * (scaleA K) ^ 2 := by
      intro j
      rw [norm_smul, Real.norm_eq_abs, mul_pow, sq_abs, norm_signWeight_sq hd s,
        real_inner_comm vSub _, sq]
    simp_rw [hterm]
    rw [← Finset.sum_mul,
      (stdOrthonormalBasis ℝ (UL.ZeroSumSubspace K)).sum_inner_mul_inner vSub vSub]
    have hv_norm : inner ℝ vSub vSub = 1 := by
      rw [real_inner_self_eq_norm_sq]
      exact norm_dirVec_sq hK
    rw [hv_norm, one_mul]
  have ha_le : scaleA K ≤ 1 := le_trans (scaleA_le_quarter hK) (by norm_num)
  have ha_nn : 0 ≤ scaleA K := scaleA_nonneg K
  have hhs_nn : 0 ≤ UL.hilbertSchmidtNorm (scoreOp K hK d s) :=
    UL.Proof_lem_C_2.hilbertSchmidtNorm_nonneg _
  nlinarith

private lemma abs_clampedScore_le_scaleA (K : ℕ) {d : ℕ} (s : Fin d → Bool)
    (x : EuclideanSpace ℝ (Fin d)) :
    |clampedScore K d s x| ≤ scaleA K := by
  have ha : 0 ≤ scaleA K := scaleA_nonneg K
  unfold clampedScore
  rw [abs_le]
  exact ⟨le_max_left _ _, max_le (by linarith) (min_le_left _ _)⟩

private lemma abs_dirVec_apply_le_one {K : ℕ} (hK : 2 ≤ K) (y : Fin K) :
    |dirVec K hK y| ≤ 1 := by
  have h := PiLp.norm_apply_le (dirVec K hK) y
  rwa [Real.norm_eq_abs, norm_dirVec hK] at h

lemma condProb_ge_floor {K d : ℕ} (hK : 2 ≤ K) (s : Fin d → Bool)
    (x : EuclideanSpace ℝ (Fin d)) (y : Fin K) :
    1 / (2 * (K : ℝ)) ≤ condProb K hK d s x y := by
  have hK0 : (K : ℝ) ≠ 0 := by exact_mod_cast (by omega : K ≠ 0)
  have hc := abs_clampedScore_le_scaleA K s x
  have hv := abs_dirVec_apply_le_one hK y
  have hprod : |clampedScore K d s x * dirVec K hK y| ≤ scaleA K := by
    calc |clampedScore K d s x * dirVec K hK y|
        = |clampedScore K d s x| * |dirVec K hK y| := abs_mul _ _
      _ ≤ scaleA K * 1 := mul_le_mul hc hv (abs_nonneg _) (scaleA_nonneg K)
      _ = scaleA K := mul_one _
  have hlow : -scaleA K ≤ clampedScore K d s x * dirVec K hK y := (abs_le.mp hprod).1
  unfold condProb
  simp only [PiLp.add_apply, PiLp.smul_apply, smul_eq_mul, UL.Proof_lem_A_5.uniformVec_apply]
  have halg : 1 / (K : ℝ) - scaleA K = 1 / (2 * (K : ℝ)) := by
    unfold scaleA
    field_simp [hK0]
    ring
  linarith

lemma condProb_mem_simplex {K d : ℕ} (hK : 2 ≤ K) (s : Fin d → Bool)
    (x : EuclideanSpace ℝ (Fin d)) :
    condProb K hK d s x ∈ UL.Simplex K := by
  refine ⟨fun y => ?_, ?_⟩
  · exact le_trans (by positivity : (0 : ℝ) ≤ 1 / (2 * (K : ℝ))) (condProb_ge_floor hK s x y)
  · unfold condProb
    simp only [PiLp.add_apply, PiLp.smul_apply, smul_eq_mul, Finset.sum_add_distrib,
      ← Finset.mul_sum]
    have hu := UL.Proof_lem_A_5.sum_uniformVec hK
    have hv := (UL.Proof_lem_A_5.mem_zeroSumSubspace_iff K (dirVec K hK)).mp
      (dirVec_mem_zeroSumSubspace hK)
    rw [hu, hv, mul_zero, add_zero]

lemma continuous_condProb {K d : ℕ} (hK : 2 ≤ K) (s : Fin d → Bool) :
    Continuous (condProb K hK d s) := by
  unfold condProb clampedScore
  exact continuous_const.add
    ((continuous_const.max (continuous_const.min
      (continuous_const.inner continuous_id))).smul continuous_const)

lemma condProb_sub_uniform_of_norm_le_one {K d : ℕ} (hK : 2 ≤ K) (hd : 1 ≤ d)
    (s : Fin d → Bool) {x : EuclideanSpace ℝ (Fin d)} (hx : ‖x‖ ≤ 1) :
    condProb K hK d s x - UL.uniformVec K =
      ((scoreOp K hK d s x : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) := by
  have hcs : |inner ℝ (signWeight K d s) x| ≤ scaleA K := by
    calc |inner ℝ (signWeight K d s) x|
        ≤ ‖signWeight K d s‖ * ‖x‖ := abs_real_inner_le_norm _ _
      _ = scaleA K * ‖x‖ := by rw [norm_signWeight hd s]
      _ ≤ scaleA K * 1 := mul_le_mul_of_nonneg_left hx (scaleA_nonneg K)
      _ = scaleA K := mul_one _
  obtain ⟨hlow, hhigh⟩ := abs_le.mp hcs
  have hclamp : clampedScore K d s x = inner ℝ (signWeight K d s) x := by
    unfold clampedScore
    rw [min_eq_right hhigh, max_eq_right hlow]
  unfold condProb
  rw [add_sub_cancel_left, hclamp, scoreOp_coe_apply]

/-! ### Joint law basic properties -/

private lemma norm_condProb_sub_update_sq {K d : ℕ} (hK : 2 ≤ K) (hd : 1 ≤ d)
    (s : Fin d → Bool) (i : Fin d) {x : EuclideanSpace ℝ (Fin d)} (hx : ‖x‖ ≤ 1) :
    let s' := Function.update s i (!s i)
    ‖condProb K hK d s x - condProb K hK d s' x‖ ^ 2 =
      (1 / ((K : ℝ) ^ 2 * (d : ℝ))) * (x i) ^ 2 := by
  intro s'
  have h1 := condProb_sub_uniform_of_norm_le_one hK hd s hx
  have h2 := condProb_sub_uniform_of_norm_le_one hK hd s' hx
  have hdiff : condProb K hK d s x - condProb K hK d s' x =
      inner ℝ (signWeight K d s - signWeight K d s') x • dirVec K hK := by
    calc condProb K hK d s x - condProb K hK d s' x
        = (condProb K hK d s x - UL.uniformVec K) -
            (condProb K hK d s' x - UL.uniformVec K) := by abel
      _ = inner ℝ (signWeight K d s) x • dirVec K hK -
            inner ℝ (signWeight K d s') x • dirVec K hK := by
          rw [h1, h2, scoreOp_coe_apply, scoreOp_coe_apply]
      _ = inner ℝ (signWeight K d s - signWeight K d s') x • dirVec K hK := by
          rw [inner_sub_left, sub_smul]
  have hinner : inner ℝ (signWeight K d s - signWeight K d s') x =
      (signWeight K d s i - signWeight K d s' i) * x i := by
    rw [UL.Proof_lem_A_4.inner_eq_sum]
    refine Finset.sum_eq_single i (fun j _ hj => ?_) (fun hi => False.elim (hi (Finset.mem_univ i)))
    simp only [PiLp.sub_apply, signWeight_apply, s', Function.update_of_ne hj, sub_self, zero_mul]
  have hcoord_sq : (signWeight K d s i - signWeight K d s' i) ^ 2 =
      1 / ((K : ℝ) ^ 2 * (d : ℝ)) := by
    have hd_pos : (0 : ℝ) < (d : ℝ) := Nat.cast_pos.mpr (by omega)
    have hK_pos : (0 : ℝ) < (K : ℝ) := Nat.cast_pos.mpr (by omega)
    let c : ℝ := scaleA K / Real.sqrt (d : ℝ)
    have hc_sq : (signWeight K d s i - signWeight K d s' i) ^ 2 = 4 * c ^ 2 := by
      dsimp [c, s']
      simp only [Function.update_self]
      cases s i <;> simp <;> ring
    rw [hc_sq]
    dsimp [c, scaleA]
    rw [div_pow, Real.sq_sqrt hd_pos.le]
    field_simp [hK_pos.ne', hd_pos.ne']
    ring
  rw [hdiff, norm_smul, Real.norm_eq_abs, mul_pow, sq_abs, norm_dirVec_sq hK, mul_one,
    hinner, mul_pow, hcoord_sq]


private noncomputable def linearDesign {K d : ℕ} (hK : 2 ≤ K) : SignExperiment.Design K d where
  prob := condProb K hK d
  cont := continuous_condProb hK
  mem := condProb_mem_simplex hK
  floor := condProb_ge_floor hK
  flip hd s i x hx := (norm_condProb_sub_update_sq hK hd s i hx).le

lemma jointLaw_isProb {K d : ℕ} (hK : 2 ≤ K)
    (μ_X : Measure (EuclideanSpace ℝ (Fin d))) [IsProbabilityMeasure μ_X]
    (s : Fin d → Bool) :
    IsProbabilityMeasure (jointLaw K hK μ_X s) :=
  SignExperiment.jointLaw_isProb (linearDesign hK) hK μ_X s

lemma jointLaw_fst_eq {K d : ℕ} (hK : 2 ≤ K)
    (μ_X : Measure (EuclideanSpace ℝ (Fin d))) [IsProbabilityMeasure μ_X]
    (s : Fin d → Bool) :
    (jointLaw K hK μ_X s).fst = μ_X :=
  SignExperiment.jointLaw_fst_eq (linearDesign hK) hK μ_X s

lemma prod_jointLaw_tv_le_quarter {K d n : ℕ} (hK : 2 ≤ K) (hd : 1 ≤ d)
    (hn : (n : ℝ) ≤ (K : ℝ) * (d : ℝ) ^ 2 / 16)
    (μ_X : Measure (EuclideanSpace ℝ (Fin d))) [IsProbabilityMeasure μ_X]
    (hnorm : ∀ᵐ x ∂μ_X, ‖x‖ = 1)
    (hcov : ∀ i j : Fin d, ∫ x, x i * x j ∂μ_X = if i = j then 1 / (d : ℝ) else 0)
    (Ξ : Type*) [MeasurableSpace Ξ] (ν : Measure Ξ) [IsProbabilityMeasure ν]
    (s : Fin d → Bool) (i : Fin d)
    {A : Set (Ξ × (Fin n → EuclideanSpace ℝ (Fin d) × Fin K))} (hA : MeasurableSet A) :
    |((ν.prod (Measure.pi (fun _ : Fin n => jointLaw K hK μ_X s))) A).toReal -
      ((ν.prod (Measure.pi (fun _ : Fin n =>
        jointLaw K hK μ_X (Function.update s i (!s i))))) A).toReal| ≤ 1 / 4 :=
  SignExperiment.prod_jointLaw_tv_le_quarter (linearDesign hK) hK hd hn μ_X hnorm hcov Ξ ν s i hA

lemma integral_jointLaw_eq {K d : ℕ} (hK : 2 ≤ K)
    (μ_X : Measure (EuclideanSpace ℝ (Fin d))) [IsProbabilityMeasure μ_X]
    (s : Fin d → Bool)
    {f : EuclideanSpace ℝ (Fin d) × Fin K → ℝ} (hf_meas : Measurable f)
    (C : ℝ) (hf_bdd : ∀ z, |f z| ≤ C) :
    ∫ z, f z ∂(jointLaw K hK μ_X s) =
      ∫ x, (∑ y : Fin K, condProb K hK d s x y * f (x, y)) ∂μ_X := by
  apply SignExperiment.integral_jointLaw_eq (linearDesign hK) hK <;> assumption

end UL.Proof_prop_C_5_Race2

import Mathlib
import UL.Stmt.prop_C_5
import UL.Proof.lem_A_4.H1_SimplexFit
import UL.Proof.prop_C_5.Race2.H0_Defs

set_option autoImplicit false

namespace UL.Proof_prop_C_5_Race2

open MeasureTheory

/-- Uniform probability measure on the unit sphere in `ℝ^d`, obtained by normalizing the uniform
probability measure on the open unit ball. -/
noncomputable def sphereProb (d : ℕ) : Measure (EuclideanSpace ℝ (Fin d)) :=
  let B := Metric.ball (0 : EuclideanSpace ℝ (Fin d)) 1
  ((volume B)⁻¹ • volume.restrict B).map (fun x => ‖x‖⁻¹ • x)

private lemma measurable_normalize (d : ℕ) :
    Measurable (fun x : EuclideanSpace ℝ (Fin d) => ‖x‖⁻¹ • x) :=
  (continuous_norm.measurable.inv).smul measurable_id

private lemma ballProb_isProb (d : ℕ) :
    let B := Metric.ball (0 : EuclideanSpace ℝ (Fin d)) 1
    IsProbabilityMeasure ((volume B)⁻¹ • volume.restrict B) := by
  intro B
  rw [isProbabilityMeasure_iff]
  have hpos : 0 < volume B := Metric.measure_ball_pos volume 0 zero_lt_one
  have htop : volume B ≠ ⊤ := measure_ball_lt_top.ne
  simp [ENNReal.inv_mul_cancel hpos.ne' htop]

lemma sphereProb_isProb {d : ℕ} (hd : 1 ≤ d) : IsProbabilityMeasure (sphereProb d) := by
  let _ := hd
  dsimp [sphereProb]
  haveI : IsProbabilityMeasure
      ((volume (Metric.ball (0 : EuclideanSpace ℝ (Fin d)) 1))⁻¹ •
        volume.restrict (Metric.ball (0 : EuclideanSpace ℝ (Fin d)) 1)) :=
    ballProb_isProb d
  exact Measure.isProbabilityMeasure_map (measurable_normalize d).aemeasurable

lemma sphereProb_norm_eq_one_ae {d : ℕ} (hd : 1 ≤ d) :
    ∀ᵐ x ∂(sphereProb d), ‖x‖ = 1 := by
  dsimp [sphereProb]
  set B := Metric.ball (0 : EuclideanSpace ℝ (Fin d)) 1
  set ν_B : Measure (EuclideanSpace ℝ (Fin d)) := (volume B)⁻¹ • volume.restrict B
  haveI : Nontrivial (EuclideanSpace ℝ (Fin d)) :=
    ⟨⟨0, EuclideanSpace.single ⟨0, by omega⟩ (1 : ℝ), fun h => by
      simpa using congr_arg (fun v : EuclideanSpace ℝ (Fin d) => v ⟨0, by omega⟩) h⟩⟩
  have hne : ∀ᵐ x ∂ν_B, x ≠ 0 := by
    rw [ae_iff]
    have hset : {x : EuclideanSpace ℝ (Fin d) | ¬ x ≠ 0} = {0} := by
      ext x
      simp
    rw [hset]
    simp [ν_B]
  rw [ae_map_iff (measurable_normalize d).aemeasurable
    (measurableSet_eq_fun continuous_norm.measurable measurable_const)]
  filter_upwards [hne] with x hx
  have hx_norm : ‖x‖ ≠ 0 := norm_ne_zero_iff.mpr hx
  rw [norm_smul, Real.norm_eq_abs, abs_inv, abs_norm, inv_mul_cancel₀ hx_norm]

lemma sphereProb_hasSphericalFeatureSymmetry {d : ℕ} (hd : 1 ≤ d) :
    UL.HasSphericalFeatureSymmetry (sphereProb d) := by
  let _ := hd
  intro Q hQ
  set L : EuclideanSpace ℝ (Fin d) →ₗ[ℝ] EuclideanSpace ℝ (Fin d) := Matrix.toEuclideanLin Q
  have hcomp : L.adjoint.comp L = LinearMap.id := by
    have h_adj : Matrix.toEuclideanLin Q.transpose = L.adjoint := by
      simpa [L] using Matrix.toEuclideanLin_conjTranspose_eq_adjoint Q
    have h_mul : Matrix.toEuclideanLin (Q.transpose * Q) =
        (Matrix.toEuclideanLin Q.transpose).comp L := by
      ext v i
      simp [L, Matrix.mulVec_mulVec]
    have h_one : Matrix.toEuclideanLin (1 : Matrix (Fin d) (Fin d) ℝ) = LinearMap.id := by
      ext v i
      simp
    rw [← h_adj, ← h_mul, hQ.1, h_one]
  have hnorm_L : ∀ x : EuclideanSpace ℝ (Fin d), ‖L x‖ = ‖x‖ := by
    intro x
    have hsq : ‖L x‖ ^ 2 = ‖x‖ ^ 2 := by
      rw [← real_inner_self_eq_norm_sq, ← LinearMap.adjoint_inner_right, ← LinearMap.comp_apply,
        hcomp, LinearMap.id_apply, real_inner_self_eq_norm_sq]
    have h1 := norm_nonneg (L x)
    have h2 := norm_nonneg x
    nlinarith
  let li : EuclideanSpace ℝ (Fin d) →ₗᵢ[ℝ] EuclideanSpace ℝ (Fin d) :=
    { toLinearMap := L
      norm_map' := hnorm_L }
  have hsurj : Function.Surjective li :=
    LinearMap.injective_iff_surjective.mp li.injective
  let e : EuclideanSpace ℝ (Fin d) ≃ₗᵢ[ℝ] EuclideanSpace ℝ (Fin d) :=
    LinearIsometryEquiv.ofSurjective li hsurj
  have hL_eq_e : (L : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d)) = e := rfl
  set B := Metric.ball (0 : EuclideanSpace ℝ (Fin d)) 1
  set ν_B : Measure (EuclideanSpace ℝ (Fin d)) := (volume B)⁻¹ • volume.restrict B
  set f : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d) := fun x => ‖x‖⁻¹ • x
  have hf_meas : Measurable f := measurable_normalize d
  have he_meas : Measurable (e : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d)) :=
    e.continuous.measurable
  have he_pre : e ⁻¹' B = B := by
    ext x
    simp [B, Metric.mem_ball, dist_zero_right, e.norm_map]
  have h_restrict_map : (volume.restrict B).map e = volume.restrict B := by
    calc (volume.restrict B).map e
      _ = (volume.restrict (e ⁻¹' B)).map e := by rw [he_pre]
      _ = (volume.map e).restrict B :=
          (Measure.restrict_map he_meas Metric.isOpen_ball.measurableSet).symm
      _ = volume.restrict B := by rw [e.measurePreserving.map_eq]
  have hν_map : ν_B.map e = ν_B := by
    simp only [ν_B, Measure.map_smul, h_restrict_map]
  have hcomm : (e : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d)) ∘ f = f ∘ e := by
    funext x
    simp [f, map_smul, e.norm_map]
  change (ν_B.map f).map L = ν_B.map f
  rw [hL_eq_e, Measure.map_map he_meas hf_meas, hcomm, ← Measure.map_map hf_meas he_meas, hν_map]

private def BddAE {α : Type*} [MeasurableSpace α] (μ : Measure α) (f : α → ℝ) : Prop :=
  Measurable f ∧ ∃ M : ℝ, ∀ᵐ x ∂μ, |f x| ≤ M

private lemma BddAE.integrable {α : Type*} [MeasurableSpace α] {μ : Measure α} [IsFiniteMeasure μ]
    {f : α → ℝ} (hf : BddAE μ f) : Integrable f μ := by
  rcases hf with ⟨hmeas, M, hM⟩
  refine (integrable_const M).mono' hmeas.aestronglyMeasurable ?_
  filter_upwards [hM] with x hx
  rwa [Real.norm_eq_abs]

private lemma BddAE.const {α : Type*} [MeasurableSpace α] (μ : Measure α) (c : ℝ) :
    BddAE μ (fun _ => c) :=
  ⟨measurable_const, |c|, Filter.Eventually.of_forall fun _ => le_rfl⟩

private lemma BddAE.const_mul {α : Type*} [MeasurableSpace α] {μ : Measure α}
    {f : α → ℝ} (hf : BddAE μ f) (c : ℝ) : BddAE μ (fun x => c * f x) := by
  rcases hf with ⟨hmeas, M, hM⟩
  refine ⟨hmeas.const_mul c, |c| * max M 0, ?_⟩
  filter_upwards [hM] with x hx
  rw [abs_mul]
  exact mul_le_mul_of_nonneg_left (hx.trans (le_max_left M 0)) (abs_nonneg c)

private lemma BddAE.add {α : Type*} [MeasurableSpace α] {μ : Measure α}
    {f₁ f₂ : α → ℝ} (h₁ : BddAE μ f₁) (h₂ : BddAE μ f₂) : BddAE μ (fun x => f₁ x + f₂ x) := by
  rcases h₁ with ⟨hm₁, M₁, hM₁⟩
  rcases h₂ with ⟨hm₂, M₂, hM₂⟩
  refine ⟨hm₁.add hm₂, M₁ + M₂, ?_⟩
  filter_upwards [hM₁, hM₂] with x hx₁ hx₂
  exact (abs_add_le _ _).trans (add_le_add hx₁ hx₂)

private lemma BddAE.sub {α : Type*} [MeasurableSpace α] {μ : Measure α}
    {f₁ f₂ : α → ℝ} (h₁ : BddAE μ f₁) (h₂ : BddAE μ f₂) : BddAE μ (fun x => f₁ x - f₂ x) := by
  rcases h₁ with ⟨hm₁, M₁, hM₁⟩
  rcases h₂ with ⟨hm₂, M₂, hM₂⟩
  refine ⟨hm₁.sub hm₂, M₁ + M₂, ?_⟩
  filter_upwards [hM₁, hM₂] with x hx₁ hx₂
  exact (abs_sub _ _).trans (add_le_add hx₁ hx₂)

private lemma BddAE.mul {α : Type*} [MeasurableSpace α] {μ : Measure α}
    {f₁ f₂ : α → ℝ} (h₁ : BddAE μ f₁) (h₂ : BddAE μ f₂) : BddAE μ (fun x => f₁ x * f₂ x) := by
  rcases h₁ with ⟨hm₁, M₁, hM₁⟩
  rcases h₂ with ⟨hm₂, M₂, hM₂⟩
  refine ⟨hm₁.mul hm₂, max M₁ 0 * max M₂ 0, ?_⟩
  filter_upwards [hM₁, hM₂] with x hx₁ hx₂
  rw [abs_mul]
  exact mul_le_mul (hx₁.trans (le_max_left M₁ 0)) (hx₂.trans (le_max_left M₂ 0))
    (abs_nonneg _) (le_max_right M₁ 0)

private lemma BddAE.sq {α : Type*} [MeasurableSpace α] {μ : Measure α}
    {f : α → ℝ} (hf : BddAE μ f) : BddAE μ (fun x => (f x) ^ 2) := by
  simpa only [pow_two] using hf.mul hf

private lemma BddAE.sum {α ι : Type*} [MeasurableSpace α] {μ : Measure α}
    (s : Finset ι) {f : ι → α → ℝ} (hf : ∀ i ∈ s, BddAE μ (f i)) :
    BddAE μ (fun x => ∑ i ∈ s, f i x) := by
  classical
  induction s using Finset.induction_on with
  | empty => simpa using BddAE.const μ 0
  | insert a s ha ih =>
      have ha_bdd : BddAE μ (f a) := hf a (Finset.mem_insert_self a s)
      have hs_bdd : BddAE μ (fun x => ∑ i ∈ s, f i x) :=
        ih (fun i hi => hf i (Finset.mem_insert_of_mem hi))
      simpa [Finset.sum_insert ha] using ha_bdd.add hs_bdd

private lemma norm_coord_le {d : ℕ} (x : EuclideanSpace ℝ (Fin d)) (i : Fin d) :
    |x i| ≤ ‖x‖ := by
  have h_sq : ‖x i‖ ^ 2 ≤ ‖x‖ ^ 2 := by
    rw [EuclideanSpace.norm_sq_eq]
    exact Finset.single_le_sum (f := fun k : Fin d => ‖x k‖ ^ 2)
      (fun k _ => sq_nonneg _) (Finset.mem_univ i)
  have h1 := Real.sqrt_le_sqrt h_sq
  rw [Real.sqrt_sq (norm_nonneg _), Real.sqrt_sq (norm_nonneg _), Real.norm_eq_abs] at h1
  exact h1

private lemma BddAE.coord {d : ℕ} {μ_X : Measure (EuclideanSpace ℝ (Fin d))}
    (hnorm : ∀ᵐ x ∂μ_X, ‖x‖ = 1) (i : Fin d) :
    BddAE μ_X (fun x => x i) := by
  refine ⟨(EuclideanSpace.proj i).continuous.measurable, 1, ?_⟩
  filter_upwards [hnorm] with x hx
  exact (norm_coord_le x i).trans_eq hx

private lemma integral_comp_orthogonal {d : ℕ}
    (μ_X : Measure (EuclideanSpace ℝ (Fin d)))
    (hsym : UL.HasSphericalFeatureSymmetry μ_X)
    {Q : Matrix (Fin d) (Fin d) ℝ} (hQ : Q.transpose * Q = 1)
    {f : EuclideanSpace ℝ (Fin d) → ℝ} (hf : Measurable f) :
    ∫ x, f (Matrix.toEuclideanLin Q x) ∂μ_X = ∫ x, f x ∂μ_X := by
  have hQ_mem : Q ∈ UL.orthogonalFixing ⊥ := by
    refine ⟨hQ, fun x hx => ?_⟩
    simp at hx
    simp [hx]
  have hmap : μ_X.map (Matrix.toEuclideanLin Q) = μ_X := hsym Q hQ_mem
  have hL_meas : Measurable (Matrix.toEuclideanLin Q) :=
    (Matrix.toEuclideanLin Q).continuous_of_finiteDimensional.measurable
  rw [← integral_map hL_meas.aemeasurable hf.aestronglyMeasurable, hmap]

lemma spherical_coord_cov {d : ℕ} (hd : 1 ≤ d)
    (μ_X : Measure (EuclideanSpace ℝ (Fin d))) [IsProbabilityMeasure μ_X]
    (hnorm : ∀ᵐ x ∂μ_X, ‖x‖ = 1)
    (hsym : UL.HasSphericalFeatureSymmetry μ_X) (i j : Fin d) :
    ∫ x, x i * x j ∂μ_X = if i = j then 1 / (d : ℝ) else 0 := by
  by_cases hij : i = j
  · subst hij
    rw [if_pos rfl]
    let i₀ : Fin d := ⟨0, by omega⟩
    have h_eq_i0 : ∀ k : Fin d, ∫ x, (x k) ^ 2 ∂μ_X = ∫ x, (x i₀) ^ 2 ∂μ_X := by
      intro k
      let σ : Equiv.Perm (Fin d) := Equiv.swap k i₀
      let Q : Matrix (Fin d) (Fin d) ℝ := σ.permMatrix ℝ
      have hQ : Q.transpose * Q = 1 := by
        simp [Q, ← Matrix.permMatrix_mul]
      have hf_meas : Measurable (fun x : EuclideanSpace ℝ (Fin d) => (x k) ^ 2) :=
        ((EuclideanSpace.proj k).continuous.pow 2).measurable
      have h_inv := integral_comp_orthogonal μ_X hsym hQ hf_meas
      have h_eval : ∀ x : EuclideanSpace ℝ (Fin d),
          (Matrix.toEuclideanLin Q x k) ^ 2 = (x i₀) ^ 2 := by
        intro x
        have hcoord : (Matrix.toEuclideanLin Q x).ofLp k = x.ofLp (σ k) := by
          rw [Matrix.ofLp_toEuclideanLin_apply, Matrix.permMatrix_mulVec]
          rfl
        change ((Matrix.toEuclideanLin Q x).ofLp k) ^ 2 = (x.ofLp i₀) ^ 2
        rw [hcoord]
        simp [σ]
      simpa only [h_eval] using h_inv.symm
    have h_sum_int :
        ∑ k : Fin d, ∫ x, (x k) ^ 2 ∂μ_X = 1 := by
      rw [← integral_finset_sum Finset.univ fun k _ => (BddAE.coord hnorm k).sq.integrable]
      have hae : ∀ᵐ x ∂μ_X, (∑ k : Fin d, (x k) ^ 2) = (1 : ℝ) := by
        filter_upwards [hnorm] with x hx
        have hnsq : ‖x‖ ^ 2 = ∑ k : Fin d, (x k) ^ 2 := by
          rw [EuclideanSpace.norm_sq_eq]
          refine Finset.sum_congr rfl fun k _ => ?_
          rw [Real.norm_eq_abs, sq_abs]
        rw [← hnsq, hx, one_pow]
      rw [integral_congr_ae hae]
      simp
    have h_const_sum :
        ∑ k : Fin d, ∫ x, (x k) ^ 2 ∂μ_X = (d : ℝ) * ∫ x, (x i₀) ^ 2 ∂μ_X := by
      simp_rw [h_eq_i0]
      simp
    have hd_ne : (d : ℝ) ≠ 0 := by positivity
    have hi0_val : ∫ x, (x i₀) ^ 2 ∂μ_X = 1 / (d : ℝ) := by
      rw [h_const_sum] at h_sum_int
      exact eq_div_of_mul_eq hd_ne (by linarith)
    calc ∫ x, x i * x i ∂μ_X
      _ = ∫ x, (x i) ^ 2 ∂μ_X := by simp_rw [pow_two]
      _ = ∫ x, (x i₀) ^ 2 ∂μ_X := h_eq_i0 i
      _ = 1 / (d : ℝ) := hi0_val
  · rw [if_neg hij]
    let dvec : Fin d → ℝ := fun k => if k = i then -1 else 1
    let Q : Matrix (Fin d) (Fin d) ℝ := Matrix.diagonal dvec
    have hQ : Q.transpose * Q = 1 := by
      rw [Matrix.diagonal_transpose, Matrix.diagonal_mul_diagonal]
      have hdvec_sq : (fun k : Fin d => dvec k * dvec k) = fun _ => (1 : ℝ) := by
        funext k
        dsimp [dvec]
        split_ifs <;> norm_num
      rw [hdvec_sq, Matrix.diagonal_one]
    have hf_meas : Measurable (fun x : EuclideanSpace ℝ (Fin d) => x i * x j) :=
      ((EuclideanSpace.proj i).continuous.mul (EuclideanSpace.proj j).continuous).measurable
    have h_inv := integral_comp_orthogonal μ_X hsym hQ hf_meas
    have h_eval : ∀ x : EuclideanSpace ℝ (Fin d),
        Matrix.toEuclideanLin Q x i * Matrix.toEuclideanLin Q x j = -(x i * x j) := by
      intro x
      have hcoord : ∀ k : Fin d, Matrix.toEuclideanLin Q x k = dvec k * x k := by
        intro k
        change (Matrix.toEuclideanLin Q x).ofLp k = dvec k * x.ofLp k
        rw [Matrix.ofLp_toEuclideanLin_apply, Matrix.mulVec_diagonal]
      rw [hcoord i, hcoord j]
      simp [dvec, Ne.symm hij]
    simp_rw [h_eval, integral_neg] at h_inv
    linarith

lemma isotropic_bessel_bound {d : ℕ} (hd : 1 ≤ d)
    (μ_X : Measure (EuclideanSpace ℝ (Fin d))) [IsProbabilityMeasure μ_X]
    (hnorm : ∀ᵐ x ∂μ_X, ‖x‖ = 1)
    (hcov : ∀ i j : Fin d, ∫ x, x i * x j ∂μ_X = if i = j then 1 / (d : ℝ) else 0)
    {g : EuclideanSpace ℝ (Fin d) → ℝ} (hg_meas : Measurable g) (C : ℝ) (hg_bdd : ∀ x, |g x| ≤ C)
    (w : EuclideanSpace ℝ (Fin d)) :
    (1 / (2 * (d : ℝ))) * (∑ i : Fin d, ((d : ℝ) * (∫ x, x i * g x ∂μ_X) - w i) ^ 2) ≤
      (1 / 2 : ℝ) * ∫ x, (g x - inner ℝ w x) ^ 2 ∂μ_X := by
  have hd_pos : (0 : ℝ) < d := by positivity
  have hd_ne : (d : ℝ) ≠ 0 := hd_pos.ne'
  have hg_bddAE : BddAE μ_X g := ⟨hg_meas, C, Filter.Eventually.of_forall hg_bdd⟩
  let b : Fin d → ℝ := fun i => (d : ℝ) * ∫ x, x i * g x ∂μ_X
  let c : Fin d → ℝ := fun i => b i - w i
  let Lc : EuclideanSpace ℝ (Fin d) → ℝ := fun x => ∑ i : Fin d, c i * x i
  let r : EuclideanSpace ℝ (Fin d) → ℝ := fun x => g x - ∑ i : Fin d, b i * x i
  have hLc_bdd : BddAE μ_X Lc :=
    BddAE.sum Finset.univ fun i _ => (BddAE.coord hnorm i).const_mul (c i)
  have hr_bdd : BddAE μ_X r :=
    hg_bddAE.sub (BddAE.sum Finset.univ fun i _ => (BddAE.coord hnorm i).const_mul (b i))
  have hr_orth : ∀ j : Fin d, ∫ x, r x * x j ∂μ_X = 0 := by
    intro j
    have h_expand : (fun x => r x * x j) =
        fun x => x j * g x - ∑ i : Fin d, b i * (x i * x j) := by
      funext x
      simp only [r, sub_mul, Finset.sum_mul]
      rw [mul_comm (g x) (x j)]
      congr 1
      refine Finset.sum_congr rfl fun i _ => ?_
      ring
    have hInt_g : Integrable (fun x => x j * g x) μ_X :=
      ((BddAE.coord hnorm j).mul hg_bddAE).integrable
    have hInt_ij : ∀ i : Fin d, Integrable (fun x => b i * (x i * x j)) μ_X :=
      fun i => (((BddAE.coord hnorm i).mul (BddAE.coord hnorm j)).const_mul (b i)).integrable
    have hInt_sum : Integrable (fun x => ∑ i : Fin d, b i * (x i * x j)) μ_X :=
      integrable_finset_sum Finset.univ fun i _ => hInt_ij i
    rw [h_expand, integral_sub hInt_g hInt_sum,
      integral_finset_sum Finset.univ fun i _ => hInt_ij i]
    have h_sum_eval :
        (∑ i : Fin d, ∫ x, b i * (x i * x j) ∂μ_X) = ∫ x, x j * g x ∂μ_X := by
      calc ∑ i : Fin d, ∫ x, b i * (x i * x j) ∂μ_X
        _ = ∑ i : Fin d, b i * ∫ x, x i * x j ∂μ_X := by
            refine Finset.sum_congr rfl fun i _ => ?_
            exact integral_const_mul (b i) _
        _ = ∑ i : Fin d, b i * (if i = j then 1 / (d : ℝ) else 0) := by
            refine Finset.sum_congr rfl fun i _ => ?_
            rw [hcov i j]
        _ = b j * (1 / (d : ℝ)) := by simp
        _ = ((d : ℝ) * ∫ x, x j * g x ∂μ_X) * (1 / (d : ℝ)) := rfl
        _ = ∫ x, x j * g x ∂μ_X := by field_simp [hd_ne]
    rw [h_sum_eval, sub_self]
  have hcross : ∫ x, r x * Lc x ∂μ_X = 0 := by
    have h_expand : (fun x => r x * Lc x) =
        fun x => ∑ j : Fin d, c j * (r x * x j) := by
      funext x
      simp only [Lc, Finset.mul_sum]
      refine Finset.sum_congr rfl fun j _ => ?_
      ring
    have hInt_j : ∀ j : Fin d, Integrable (fun x => c j * (r x * x j)) μ_X :=
      fun j => ((hr_bdd.mul (BddAE.coord hnorm j)).const_mul (c j)).integrable
    rw [h_expand, integral_finset_sum Finset.univ fun j _ => hInt_j j]
    refine Finset.sum_eq_zero fun j _ => ?_
    rw [integral_const_mul, hr_orth j, mul_zero]
  have hLc_sq : ∫ x, (Lc x) ^ 2 ∂μ_X = (1 / (d : ℝ)) * ∑ i : Fin d, (c i) ^ 2 := by
    have h_expand : (fun x => (Lc x) ^ 2) =
        fun x => ∑ i : Fin d, ∑ j : Fin d, (c i * c j) * (x i * x j) := by
      funext x
      simp only [Lc, pow_two, Finset.sum_mul, Finset.mul_sum]
      refine Finset.sum_congr rfl fun i _ => ?_
      refine Finset.sum_congr rfl fun j _ => ?_
      ring
    have hInt_ij : ∀ i j : Fin d, Integrable (fun x => (c i * c j) * (x i * x j)) μ_X :=
      fun i j =>
        (((BddAE.coord hnorm i).mul (BddAE.coord hnorm j)).const_mul (c i * c j)).integrable
    have hInt_i : ∀ i : Fin d,
        Integrable (fun x => ∑ j : Fin d, (c i * c j) * (x i * x j)) μ_X :=
      fun i => integrable_finset_sum Finset.univ fun j _ => hInt_ij i j
    rw [h_expand, integral_finset_sum Finset.univ fun i _ => hInt_i i]
    calc ∑ i : Fin d, ∫ x, (∑ j : Fin d, (c i * c j) * (x i * x j)) ∂μ_X
      _ = ∑ i : Fin d, ∑ j : Fin d, (c i * c j) * ∫ x, x i * x j ∂μ_X := by
          refine Finset.sum_congr rfl fun i _ => ?_
          rw [integral_finset_sum Finset.univ fun j _ => hInt_ij i j]
          refine Finset.sum_congr rfl fun j _ => ?_
          exact integral_const_mul (c i * c j) _
      _ = ∑ i : Fin d, ∑ j : Fin d, (c i * c j) * (if i = j then 1 / (d : ℝ) else 0) := by
          refine Finset.sum_congr rfl fun i _ => ?_
          refine Finset.sum_congr rfl fun j _ => ?_
          rw [hcov i j]
      _ = ∑ i : Fin d, (c i * c i) * (1 / (d : ℝ)) := by simp
      _ = (1 / (d : ℝ)) * ∑ i : Fin d, (c i) ^ 2 := by
          rw [Finset.mul_sum]
          refine Finset.sum_congr rfl fun i _ => ?_
          ring
  have h_decomp_sq :
      (fun x => (g x - inner ℝ w x) ^ 2) =
        fun x => (r x) ^ 2 + (2 * (r x * Lc x) + (Lc x) ^ 2) := by
    funext x
    have hinner : inner ℝ w x = ∑ i : Fin d, w i * x i := by
      rw [PiLp.inner_apply]
      refine Finset.sum_congr rfl fun i _ => ?_
      simp [mul_comm]
    have hlin : g x - inner ℝ w x = r x + Lc x := by
      rw [hinner]
      simp only [r, Lc, c]
      have hsum : (∑ i : Fin d, b i * x i) - (∑ i : Fin d, (b i - w i) * x i) =
          ∑ i : Fin d, w i * x i := by
        rw [← Finset.sum_sub_distrib]
        refine Finset.sum_congr rfl fun i _ => ?_
        ring
      linarith
    rw [hlin]
    ring
  have hInt_rsq : Integrable (fun x => (r x) ^ 2) μ_X := hr_bdd.sq.integrable
  have hInt_cross2 : Integrable (fun x => 2 * (r x * Lc x)) μ_X :=
    ((hr_bdd.mul hLc_bdd).const_mul 2).integrable
  have hInt_Lcsq : Integrable (fun x => (Lc x) ^ 2) μ_X := hLc_bdd.sq.integrable
  have hInt_rhs2 : Integrable (fun x => 2 * (r x * Lc x) + (Lc x) ^ 2) μ_X :=
    (((hr_bdd.mul hLc_bdd).const_mul 2).add hLc_bdd.sq).integrable
  have h_total :
      ∫ x, (g x - inner ℝ w x) ^ 2 ∂μ_X =
        (∫ x, (r x) ^ 2 ∂μ_X) + (1 / (d : ℝ)) * ∑ i : Fin d, (c i) ^ 2 := by
    rw [h_decomp_sq, integral_add hInt_rsq hInt_rhs2,
      integral_add hInt_cross2 hInt_Lcsq, integral_const_mul, hcross, mul_zero, zero_add, hLc_sq]
  have hr_nonneg : 0 ≤ ∫ x, (r x) ^ 2 ∂μ_X :=
    integral_nonneg fun x => sq_nonneg (r x)
  rw [h_total]
  have hcoeff : (1 / (2 * (d : ℝ))) * (∑ i : Fin d, (c i) ^ 2) =
      (1 / 2 : ℝ) * ((1 / (d : ℝ)) * ∑ i : Fin d, (c i) ^ 2) := by
    ring
  change (1 / (2 * (d : ℝ))) * (∑ i : Fin d, (c i) ^ 2) ≤ _
  linarith

lemma spherical_bessel_bound {d : ℕ} (hd : 1 ≤ d)
    (μ_X : Measure (EuclideanSpace ℝ (Fin d))) [IsProbabilityMeasure μ_X]
    (hnorm : ∀ᵐ x ∂μ_X, ‖x‖ = 1)
    (hsym : UL.HasSphericalFeatureSymmetry μ_X)
    {g : EuclideanSpace ℝ (Fin d) → ℝ} (hg_meas : Measurable g) (C : ℝ) (hg_bdd : ∀ x, |g x| ≤ C)
    (w : EuclideanSpace ℝ (Fin d)) :
    (1 / (2 * (d : ℝ))) * (∑ i : Fin d, ((d : ℝ) * (∫ x, x i * g x ∂μ_X) - w i) ^ 2) ≤
      (1 / 2 : ℝ) * ∫ x, (g x - inner ℝ w x) ^ 2 ∂μ_X :=
  isotropic_bessel_bound hd μ_X hnorm (spherical_coord_cov hd μ_X hnorm hsym) hg_meas C hg_bdd w

end UL.Proof_prop_C_5_Race2

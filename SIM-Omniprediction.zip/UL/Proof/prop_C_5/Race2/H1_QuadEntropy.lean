import Mathlib
import UL.Stmt.prop_C_5
import UL.Proof.cor_A_8.H1_SimplexGrad
import UL.Proof.lem_C_2.H2_SmoothEntropy
import UL.Proof.lem_A_1.H1_FaceSubgrad
import UL.Proof.lem_A_4.H1_SimplexFit
import UL.Proof.lem_A_5.H1_Simplex
import UL.Proof.prop_C_5.Race2.H0_Defs

set_option autoImplicit false

namespace UL.Proof_prop_C_5_Race2

private lemma hasFDerivAt_quadEntropy_ext {K : ℕ} (q : EuclideanSpace ℝ (Fin K)) :
    HasFDerivAt (fun x : EuclideanSpace ℝ (Fin K) => ((1 : ℝ) / 2) * ‖x - UL.uniformVec K‖ ^ 2)
      (innerSL ℝ (q - UL.uniformVec K)) q := by
  have h := UL.Proof_cor_A_8.hasFDerivAt_quad_term 1 q
  simpa [mul_one, one_smul] using h

private lemma extendSimplex_quadEntropy_eq {K : ℕ} {q : EuclideanSpace ℝ (Fin K)}
    (hq : q ∈ UL.Simplex K) :
    UL.extendSimplex (quadEntropy K) q = ((1 : ℝ) / 2) * ‖q - UL.uniformVec K‖ ^ 2 := by
  rw [UL.Proof_lem_A_5.extendSimplex_eq_of_mem (quadEntropy K) hq]
  rfl

private lemma continuous_quadEntropy (K : ℕ) : Continuous (quadEntropy K) := by
  unfold quadEntropy
  exact continuous_const.mul (((continuous_subtype_val.sub continuous_const).norm).pow 2)

private lemma norm_sub_uniformVec_le_one {K : ℕ} (hK : 2 ≤ K) {q : EuclideanSpace ℝ (Fin K)}
    (hq : q ∈ UL.Simplex K) :
    ‖q - UL.uniformVec K‖ ≤ 1 := by
  have hu : UL.uniformVec K ∈ UL.Simplex K := UL.Proof_lem_A_5.uniformVec_mem_simplex hK
  have hzero : q - UL.uniformVec K ∈ UL.ZeroSumSubspace K :=
    UL.Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex hq hu
  have horth : inner ℝ (q - UL.uniformVec K) (UL.uniformVec K) = 0 := by
    rw [real_inner_comm]
    exact UL.Proof_lem_C_2.inner_uniformVec_zero_of_mem_zeroSum hzero
  have hpyth : ‖q‖ ^ 2 = ‖q - UL.uniformVec K‖ ^ 2 + ‖UL.uniformVec K‖ ^ 2 := by
    have hadd : (q - UL.uniformVec K) + UL.uniformVec K = q := sub_add_cancel _ _
    have hsq := norm_add_sq_real (q - UL.uniformVec K) (UL.uniformVec K)
    rw [hadd, horth] at hsq
    linarith
  have hq_norm : ‖q‖ ≤ 1 := UL.Proof_lem_A_5.norm_le_one_of_mem_simplex hq
  have hq_sq : ‖q‖ ^ 2 ≤ 1 := by nlinarith [norm_nonneg q]
  have hu_sq : 0 ≤ ‖UL.uniformVec K‖ ^ 2 := sq_nonneg _
  nlinarith [norm_nonneg (q - UL.uniformVec K)]

private lemma tendsto_slope_extendSimplex {K : ℕ} {Φ : UL.Simplex K → ℝ}
    {q p g : EuclideanSpace ℝ (Fin K)}
    (hq : q ∈ UL.Simplex K) (hp : p ∈ UL.Simplex K)
    (hf : HasFDerivWithinAt (UL.extendSimplex Φ) (innerSL ℝ g) (UL.Simplex K) q) :
    Filter.Tendsto
      (fun t : ℝ => (UL.extendSimplex Φ (q + t • (p - q)) - UL.extendSimplex Φ q) / t)
      (nhdsWithin (0 : ℝ) (Set.Ioi 0))
      (nhds (inner ℝ g (p - q))) := by
  let γ : ℝ → EuclideanSpace ℝ (Fin K) := fun t => q + t • (p - q)
  have hγ0 : γ 0 = q := by simp [γ]
  have hγ_deriv : HasDerivAt γ (p - q) 0 := by
    have h1 : HasDerivAt (fun t : ℝ => t • (p - q)) ((1 : ℝ) • (p - q)) 0 :=
      (hasDerivAt_id (0 : ℝ)).smul_const (p - q)
    simpa [γ] using h1.const_add q
  have hγ_maps : Set.MapsTo γ (Set.Ioo (0 : ℝ) 1) (UL.Simplex K) := by
    intro t ht
    have hγt : γ t = (1 - t) • q + t • p := by
      simp [γ, sub_smul, smul_sub]
      abel
    rw [hγt]
    exact UL.Proof_lem_A_5.convex_simplex K hq hp (by linarith [ht.2]) ht.1.le (by ring)
  have hcomp : HasDerivWithinAt (fun t : ℝ => UL.extendSimplex Φ (γ t))
      ((innerSL ℝ g) (p - q)) (Set.Ioo (0 : ℝ) 1) 0 := by
    have hf' : HasFDerivWithinAt (UL.extendSimplex Φ) (innerSL ℝ g) (UL.Simplex K) (γ 0) := by
      rw [hγ0]
      exact hf
    exact hf'.comp_hasDerivWithinAt 0 hγ_deriv.hasDerivWithinAt hγ_maps
  have hdiff : Set.Ioo (0 : ℝ) 1 \ {0} = Set.Ioo (0 : ℝ) 1 := by
    ext x
    simp only [Set.mem_diff, Set.mem_Ioo, Set.mem_singleton_iff, and_iff_left_iff_imp]
    intro hx
    linarith [hx.1]
  have hnhds : nhdsWithin (0 : ℝ) (Set.Ioo (0 : ℝ) 1) = nhdsWithin (0 : ℝ) (Set.Ioi 0) :=
    nhdsWithin_Ioo_eq_nhdsGT zero_lt_one
  rw [hasDerivWithinAt_iff_tendsto_slope, hdiff, hnhds] at hcomp
  have hcongr : (fun t : ℝ => (UL.extendSimplex Φ (γ t) - UL.extendSimplex Φ q) / t) =ᶠ[nhdsWithin (0 : ℝ) (Set.Ioi 0)]
      slope (fun t : ℝ => UL.extendSimplex Φ (γ t)) 0 := by
    filter_upwards [self_mem_nhdsWithin] with t _
    simp [slope_def_field, hγ0]
  simpa [γ, innerSL_apply_apply] using hcomp.congr' hcongr.symm

private lemma hasFaceGradAt_univ_unique {K : ℕ} (hK : 2 ≤ K) {Φ : UL.Simplex K → ℝ}
    {q g₁ g₂ : EuclideanSpace ℝ (Fin K)} (hq : q ∈ UL.Simplex K)
    (hg₁ : UL.HasFaceGradAt Φ Finset.univ q g₁)
    (hg₂ : UL.HasFaceGradAt Φ Finset.univ q g₂) :
    g₁ = g₂ := by
  have hf₁ : HasFDerivWithinAt (UL.extendSimplex Φ) (innerSL ℝ g₁) (UL.Simplex K) q := by
    have h := hg₁.2
    rwa [UL.Proof_lem_A_5.simplexFace_univ K] at h
  have hf₂ : HasFDerivWithinAt (UL.extendSimplex Φ) (innerSL ℝ g₂) (UL.Simplex K) q := by
    have h := hg₂.2
    rwa [UL.Proof_lem_A_5.simplexFace_univ K] at h
  have hz₁ : g₁ ∈ UL.ZeroSumSubspace K := by
    have h := hg₁.1
    rwa [UL.Proof_lem_A_5.faceTangentSpace_univ K] at h
  have hz₂ : g₂ ∈ UL.ZeroSumSubspace K := by
    have h := hg₂.1
    rwa [UL.Proof_lem_A_5.faceTangentSpace_univ K] at h
  have h_inner_eq : ∀ p ∈ UL.Simplex K, inner ℝ g₁ (p - q) = inner ℝ g₂ (p - q) := fun p hp =>
    tendsto_nhds_unique (tendsto_slope_extendSimplex hq hp hf₁)
      (tendsto_slope_extendSimplex hq hp hf₂)
  let d : EuclideanSpace ℝ (Fin K) := g₁ - g₂
  have hd_zero : d ∈ UL.ZeroSumSubspace K := Submodule.sub_mem _ hz₁ hz₂
  have hd_sum : ∑ j : Fin K, d j = 0 :=
    (UL.Proof_lem_A_5.mem_zeroSumSubspace_iff K d).mp hd_zero
  have hd_const : ∀ j : Fin K, d j = inner ℝ d q := by
    intro j
    have hej : EuclideanSpace.single j (1 : ℝ) ∈ UL.Simplex K :=
      UL.Proof_lem_A_1.single_mem_simplex j
    have h0 : inner ℝ d (EuclideanSpace.single j (1 : ℝ) - q) = 0 := by
      dsimp [d]
      rw [inner_sub_left, h_inner_eq _ hej, sub_self]
    rw [inner_sub_right, UL.Proof_lem_A_1.inner_single_right] at h0
    linarith
  have hc_sum : (K : ℝ) * inner ℝ d q = 0 := by
    have h1 : ∑ j : Fin K, d j = ∑ _ : Fin K, inner ℝ d q :=
      Finset.sum_congr rfl fun j _ => hd_const j
    rw [hd_sum, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul] at h1
    exact h1.symm
  have hK_ne : (K : ℝ) ≠ 0 := by exact_mod_cast (by omega : K ≠ 0)
  have hc : inner ℝ d q = 0 := (mul_eq_zero.mp hc_sum).resolve_left hK_ne
  ext j
  have hj := hd_const j
  rw [hc] at hj
  simpa [d, sub_eq_zero] using hj

private lemma hasFaceGradAt_univ_quadEntropy {K : ℕ} (hK : 2 ≤ K) {q : EuclideanSpace ℝ (Fin K)}
    (hq : q ∈ UL.Simplex K) :
    UL.HasFaceGradAt (quadEntropy K) Finset.univ q (q - UL.uniformVec K) := by
  refine ⟨?_, ?_⟩
  · rw [UL.Proof_lem_A_5.faceTangentSpace_univ K]
    exact UL.Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex hq
      (UL.Proof_lem_A_5.uniformVec_mem_simplex hK)
  · rw [UL.Proof_lem_A_5.simplexFace_univ K]
    exact (hasFDerivAt_quadEntropy_ext q).hasFDerivWithinAt.congr
      (fun x hx => extendSimplex_quadEntropy_eq hx)
      (extendSimplex_quadEntropy_eq hq)

lemma simplexGrad_quadEntropy {K : ℕ} (hK : 2 ≤ K) {q : EuclideanSpace ℝ (Fin K)}
    (hq : q ∈ UL.Simplex K) :
    UL.simplexGrad (quadEntropy K) q = q - UL.uniformVec K := by
  have hg : UL.HasFaceGradAt (quadEntropy K) Finset.univ q (q - UL.uniformVec K) :=
    hasFaceGradAt_univ_quadEntropy hK hq
  have hspec : UL.HasFaceGradAt (quadEntropy K) Finset.univ q
      (UL.simplexGrad (quadEntropy K) q) :=
    UL.Proof_lem_A_5.faceGrad_spec ⟨q - UL.uniformVec K, hg⟩
  exact hasFaceGradAt_univ_unique hK hq hspec hg

private lemma convex_simplexAffineHull (K : ℕ) : Convex ℝ (UL.SimplexAffineHull K) := by
  intro x hx y hy a b _ha _hb hab
  show ∑ j : Fin K, (a • x + b • y) j = 1
  have hx' : ∑ j : Fin K, x j = 1 := hx
  have hy' : ∑ j : Fin K, y j = 1 := hy
  simp only [PiLp.add_apply, PiLp.smul_apply, smul_eq_mul,
    Finset.sum_add_distrib, ← Finset.mul_sum, hx', hy', mul_one]
  exact hab

private lemma convexOn_quadEntropy_ext (K : ℕ) :
    ConvexOn ℝ (UL.SimplexAffineHull K)
      (fun q : EuclideanSpace ℝ (Fin K) => ((1 : ℝ) / 2) * ‖q - UL.uniformVec K‖ ^ 2) := by
  refine ⟨convex_simplexAffineHull K, fun x _ y _ a b ha hb hab => ?_⟩
  dsimp only
  simp only [smul_eq_mul]
  let u := UL.uniformVec K
  have hcomb : (a • x + b • y) - u = a • (x - u) + b • (y - u) := by
    calc (a • x + b • y) - u = a • x + b • y - (a + b) • u := by rw [hab, one_smul]
      _ = a • (x - u) + b • (y - u) := by rw [add_smul, smul_sub, smul_sub]; abel
  change (1 / 2 : ℝ) * ‖(a • x + b • y) - u‖ ^ 2 ≤
    a * ((1 / 2 : ℝ) * ‖x - u‖ ^ 2) + b * ((1 / 2 : ℝ) * ‖y - u‖ ^ 2)
  rw [hcomb]
  have hdiff : a * ‖x - u‖ ^ 2 + b * ‖y - u‖ ^ 2 - ‖a • (x - u) + b • (y - u)‖ ^ 2 =
      a * b * ‖(x - u) - (y - u)‖ ^ 2 := by
    set dx := x - u
    set dy := y - u
    have ha_sq : ‖a • dx‖ ^ 2 = a ^ 2 * ‖dx‖ ^ 2 := by
      rw [norm_smul, Real.norm_eq_abs, mul_pow, sq_abs]
    have hb_sq : ‖b • dy‖ ^ 2 = b ^ 2 * ‖dy‖ ^ 2 := by
      rw [norm_smul, Real.norm_eq_abs, mul_pow, sq_abs]
    rw [norm_add_sq_real (a • dx) (b • dy), norm_sub_sq_real dx dy, ha_sq, hb_sq,
      inner_smul_left, inner_smul_right, conj_trivial]
    have hb_eq : b = 1 - a := by linarith
    rw [hb_eq]
    ring
  have hnn : 0 ≤ a * b * ‖(x - u) - (y - u)‖ ^ 2 :=
    mul_nonneg (mul_nonneg ha hb) (sq_nonneg _)
  linarith

lemma quadEntropy_mem_smoothEntropyFamily {K : ℕ} (hK : 2 ≤ K) :
    quadEntropy K ∈ UL.SmoothEntropyFamily K 1 1 1 := by
  refine ⟨?_, zero_lt_one, zero_lt_one, ?_, ?_, ?_⟩
  · refine ⟨zero_lt_one, continuous_quadEntropy K, ?_, ?_⟩
    · intro J _hJ p hp
      let g₀ : EuclideanSpace ℝ (Fin K) := p - UL.uniformVec K
      let g_J : EuclideanSpace ℝ (Fin K) :=
        ((UL.FaceTangentSpace K J).orthogonalProjection g₀ : EuclideanSpace ℝ (Fin K))
      refine ⟨g_J, Submodule.coe_mem _, ?_⟩
      have hfderiv_g₀ : HasFDerivWithinAt (UL.extendSimplex (quadEntropy K))
          (innerSL ℝ g₀) (UL.SimplexFace K J) p :=
        (hasFDerivAt_quadEntropy_ext p).hasFDerivWithinAt.congr
          (fun x hx => extendSimplex_quadEntropy_eq hx.1)
          (extendSimplex_quadEntropy_eq hp.1.1)
      refine HasFDerivAtFilter.of_isLittleO ?_
      refine hfderiv_g₀.isLittleO.congr' ?_ (Filter.Eventually.of_forall fun _ => rfl)
      filter_upwards [self_mem_nhdsWithin] with q hq
      have hqp : q - p ∈ UL.FaceTangentSpace K J :=
        UL.Proof_cor_A_8.sub_mem_faceTangentSpace hp.1 hq
      have hinn : inner ℝ g_J (q - p) = inner ℝ g₀ (q - p) :=
        UL.Proof_cor_A_8.inner_orthProj_eq_of_mem (UL.FaceTangentSpace K J) g₀ (q - p) hqp
      simp only [innerSL_apply_apply, hinn]
    · refine (convexOn_const 0 (UL.Proof_lem_A_5.convex_simplex K)).congr fun q hq => ?_
      dsimp only
      rw [extendSimplex_quadEntropy_eq hq]
      ring
  · refine ⟨UL.SimplexAffineHull K,
      fun q => ((1 : ℝ) / 2) * ‖q - UL.uniformVec K‖ ^ 2,
      fun q => q - UL.uniformVec K,
      ⟨Set.univ, isOpen_univ, (Set.univ_inter _).symm⟩,
      fun q hq => hq.2,
      fun _ => rfl,
      convexOn_quadEntropy_ext K,
      ?_,
      (continuous_id.sub continuous_const).continuousOn⟩
    intro q hq
    refine ⟨?_, (hasFDerivAt_quadEntropy_ext q).hasFDerivWithinAt⟩
    rw [UL.Proof_lem_A_5.mem_zeroSumSubspace_iff]
    have hq_sum : ∑ j : Fin K, q j = 1 := hq
    have hu_sum : ∑ j : Fin K, UL.uniformVec K j = 1 := UL.Proof_lem_A_5.sum_uniformVec hK
    simp only [PiLp.sub_apply, Finset.sum_sub_distrib, hq_sum, hu_sum, sub_self]
  · intro q hq q' hq'
    rw [simplexGrad_quadEntropy hK hq, simplexGrad_quadEntropy hK hq', one_mul]
    have hsub : (q - UL.uniformVec K) - (q' - UL.uniformVec K) = q - q' := by abel
    rw [hsub]
  · intro q hq
    rw [simplexGrad_quadEntropy hK hq]
    exact norm_sub_uniformVec_le_one hK hq

lemma finiteCanonicalLoss_quadEntropy_eq {K : ℕ} (hK : 2 ≤ K) {p : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ UL.Simplex K) (y : Fin K) :
    UL.finiteCanonicalLoss (quadEntropy K) p y =
      (1 / 2 : ℝ) * ‖p - UL.uniformVec K‖ ^ 2 - (p y - UL.uniformVec K y) := by
  rw [UL.Proof_lem_C_2.finiteCanonicalLoss_eq (quadEntropy_mem_smoothEntropyFamily hK) hp y,
    extendSimplex_quadEntropy_eq hp, simplexGrad_quadEntropy hK hp]
  let u := UL.uniformVec K
  let ey : EuclideanSpace ℝ (Fin K) := EuclideanSpace.single y (1 : ℝ)
  have hu : u ∈ UL.Simplex K := UL.Proof_lem_A_5.uniformVec_mem_simplex hK
  have hzero : p - u ∈ UL.ZeroSumSubspace K :=
    UL.Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex hp hu
  have hu_orth : inner ℝ u (p - u) = 0 :=
    UL.Proof_lem_C_2.inner_uniformVec_zero_of_mem_zeroSum hzero
  have hey_inn : inner ℝ ey (p - u) = p y - u y := by
    rw [real_inner_comm, UL.Proof_lem_A_1.inner_single_right]
    rfl
  have hsplit : p - ey = (p - u) + (u - ey) := by abel
  change -(((1 : ℝ) / 2) * ‖p - u‖ ^ 2) + inner ℝ (p - ey) (p - u) =
    (1 / 2 : ℝ) * ‖p - u‖ ^ 2 - (p y - u y)
  rw [hsplit, inner_add_left, real_inner_self_eq_norm_sq, inner_sub_left, hu_orth, hey_inn]
  ring

lemma finiteCanonicalLoss_quadEntropy_abs_le {K : ℕ} (hK : 2 ≤ K) {p : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ UL.Simplex K) (y : Fin K) :
    |UL.finiteCanonicalLoss (quadEntropy K) p y| ≤ 4 := by
  rw [finiteCanonicalLoss_quadEntropy_eq hK hp y]
  have hnorm : ‖p - UL.uniformVec K‖ ≤ 1 := norm_sub_uniformVec_le_one hK hp
  have hsq_le : ‖p - UL.uniformVec K‖ ^ 2 ≤ 1 := by
    nlinarith [norm_nonneg (p - UL.uniformVec K)]
  have hsq_nn : 0 ≤ ‖p - UL.uniformVec K‖ ^ 2 := sq_nonneg _
  have hcoord : |p y - UL.uniformVec K y| ≤ 1 := by
    have h1 : |p y - UL.uniformVec K y| ≤ ‖p - UL.uniformVec K‖ := by
      simpa [Real.norm_eq_abs] using PiLp.norm_apply_le (p - UL.uniformVec K) y
    exact h1.trans hnorm
  rcases abs_le.mp hcoord with ⟨hc1, hc2⟩
  rw [abs_le]
  constructor <;> linarith

lemma cond_regret_quadEntropy {K : ℕ} (hK : 2 ≤ K) {p η : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ UL.Simplex K) (hη : η ∈ UL.Simplex K) :
    ∑ y : Fin K, η y * (UL.finiteCanonicalLoss (quadEntropy K) p y -
      UL.finiteCanonicalLoss (quadEntropy K) η y) = (1 / 2 : ℝ) * ‖p - η‖ ^ 2 := by
  let u := UL.uniformVec K
  let c : ℝ := (1 / 2 : ℝ) * ‖p - u‖ ^ 2 - (1 / 2 : ℝ) * ‖η - u‖ ^ 2
  have hterm : ∀ y : Fin K,
      η y * (UL.finiteCanonicalLoss (quadEntropy K) p y -
        UL.finiteCanonicalLoss (quadEntropy K) η y) =
      η y * c - η y * (p y - η y) := by
    intro y
    rw [finiteCanonicalLoss_quadEntropy_eq hK hp y, finiteCanonicalLoss_quadEntropy_eq hK hη y]
    dsimp [c, u]
    ring
  simp_rw [hterm]
  rw [Finset.sum_sub_distrib, ← Finset.sum_mul, hη.2, one_mul]
  have hinn_sum : ∑ y : Fin K, η y * (p y - η y) = inner ℝ η (p - η) := by
    rw [UL.Proof_lem_A_1.inner_eq_sum]
    rfl
  rw [hinn_sum]
  have hzero : p - η ∈ UL.ZeroSumSubspace K :=
    UL.Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex hp hη
  have hu_orth : inner ℝ u (p - η) = 0 :=
    UL.Proof_lem_C_2.inner_uniformVec_zero_of_mem_zeroSum hzero
  have hsplit : p - u = (η - u) + (p - η) := by abel
  have hsq : ‖p - u‖ ^ 2 = ‖η - u‖ ^ 2 + 2 * inner ℝ η (p - η) + ‖p - η‖ ^ 2 := by
    calc ‖p - u‖ ^ 2
        = ‖(η - u) + (p - η)‖ ^ 2 := by rw [hsplit]
      _ = ‖η - u‖ ^ 2 + 2 * inner ℝ (η - u) (p - η) + ‖p - η‖ ^ 2 :=
          norm_add_sq_real (η - u) (p - η)
      _ = ‖η - u‖ ^ 2 + 2 * inner ℝ η (p - η) + ‖p - η‖ ^ 2 := by
          rw [inner_sub_left, hu_orth, sub_zero]
  dsimp [c]
  rw [hsq]
  ring

lemma matchingLoss_quadEntropy_ge_neg_two {K : ℕ} (hK : 2 ≤ K)
    (v : UL.ZeroSumSubspace K) (y : Fin K) :
    -2 ≤ UL.matchingLoss (quadEntropy K) (v : EuclideanSpace ℝ (Fin K)) y := by
  let ey : EuclideanSpace ℝ (Fin K) := EuclideanSpace.single y (1 : ℝ)
  have hey : ey ∈ UL.Simplex K := UL.Proof_lem_A_1.single_mem_simplex y
  have hlb := UL.Proof_lem_C_2.matchingLoss_lower_bound (continuous_quadEntropy K) hey v y
  rw [extendSimplex_quadEntropy_eq hey, sub_self, inner_zero_left, add_zero] at hlb
  have hnorm : ‖ey - UL.uniformVec K‖ ≤ 1 := norm_sub_uniformVec_le_one hK hey
  have hsq : ‖ey - UL.uniformVec K‖ ^ 2 ≤ 1 := by
    nlinarith [norm_nonneg (ey - UL.uniformVec K)]
  linarith

lemma matchingLoss_quadEntropy_eq_finiteCanonicalLoss {K : ℕ} (hK : 2 ≤ K)
    {η : EuclideanSpace ℝ (Fin K)} (hη : η ∈ UL.Simplex K) (y : Fin K) :
    UL.matchingLoss (quadEntropy K) (η - UL.uniformVec K) y =
      UL.finiteCanonicalLoss (quadEntropy K) η y := by
  unfold UL.finiteCanonicalLoss UL.finiteCanonicalAction
  rw [simplexGrad_quadEntropy hK hη]

end UL.Proof_prop_C_5_Race2

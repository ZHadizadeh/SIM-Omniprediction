import Mathlib
import UL.Stmt.prop_C_5
import UL.Proof.lem_A_4.H1_SimplexFit
import UL.Proof.lem_A_5.H1_Simplex
import UL.Proof.prop_C_5.Race2.H0_Defs

set_option autoImplicit false

namespace UL.Proof_prop_C_5_Race2

open MeasureTheory

/-! ### Predictor coordinate projection and Hamming error -/

noncomputable def estCoord {d : ℕ} (K : ℕ) (hK : 2 ≤ K) {n : ℕ} {Ξ : Type*}
    (μ_X : Measure (EuclideanSpace ℝ (Fin d)))
    (p_hat : Ξ → (Fin n → EuclideanSpace ℝ (Fin d) × Fin K) →
      EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin K))
    (q : Ξ × (Fin n → EuclideanSpace ℝ (Fin d) × Fin K)) (i : Fin d) : ℝ :=
  (d : ℝ) * ∫ x, x i * inner ℝ (p_hat q.1 q.2 x - UL.uniformVec K) (dirVec K hK) ∂μ_X

noncomputable def hammingErr {d : ℕ} (K : ℕ) (hK : 2 ≤ K) {n : ℕ} {Ξ : Type*}
    (μ_X : Measure (EuclideanSpace ℝ (Fin d)))
    (p_hat : Ξ → (Fin n → EuclideanSpace ℝ (Fin d) × Fin K) →
      EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin K))
    (s : Fin d → Bool)
    (q : Ξ × (Fin n → EuclideanSpace ℝ (Fin d) × Fin K)) : ℕ :=
  (Finset.univ.filter (fun i : Fin d =>
    decide (0 ≤ estCoord K hK μ_X p_hat q i) ≠ s i)).card

lemma measurable_p_hat_slice {d K n : ℕ} {Ξ : Type*} [MeasurableSpace Ξ]
    {p_hat : Ξ → (Fin n → EuclideanSpace ℝ (Fin d) × Fin K) →
      EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin K)}
    (hp_meas : Measurable (fun r : Ξ × (Fin n → EuclideanSpace ℝ (Fin d) × Fin K) ×
      EuclideanSpace ℝ (Fin d) => p_hat r.1 r.2.1 r.2.2))
    (q : Ξ × (Fin n → EuclideanSpace ℝ (Fin d) × Fin K)) :
    Measurable (p_hat q.1 q.2) := by
  have hinj : Measurable (fun x : EuclideanSpace ℝ (Fin d) => (q.1, (q.2, x))) :=
    measurable_const.prodMk (measurable_const.prodMk measurable_id)
  exact hp_meas.comp hinj

lemma measurable_estCoord {d K n : ℕ} (hK : 2 ≤ K) {Ξ : Type*} [MeasurableSpace Ξ]
    (μ_X : Measure (EuclideanSpace ℝ (Fin d))) [IsProbabilityMeasure μ_X]
    {p_hat : Ξ → (Fin n → EuclideanSpace ℝ (Fin d) × Fin K) →
      EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin K)}
    (hp_meas : Measurable (fun r : Ξ × (Fin n → EuclideanSpace ℝ (Fin d) × Fin K) ×
      EuclideanSpace ℝ (Fin d) => p_hat r.1 r.2.1 r.2.2))
    (i : Fin d) :
    Measurable (fun q => estCoord K hK μ_X p_hat q i) := by
  let α := Ξ × (Fin n → EuclideanSpace ℝ (Fin d) × Fin K)
  have hreassoc : Measurable (fun qx : α × EuclideanSpace ℝ (Fin d) =>
      (qx.1.1, (qx.1.2, qx.2))) :=
    (measurable_fst.comp measurable_fst).prodMk
      ((measurable_snd.comp measurable_fst).prodMk measurable_snd)
  have hp_joint : Measurable (fun qx : α × EuclideanSpace ℝ (Fin d) =>
      p_hat qx.1.1 qx.1.2 qx.2) :=
    hp_meas.comp hreassoc
  have hxi : Measurable (fun qx : α × EuclideanSpace ℝ (Fin d) => qx.2 i) :=
    (EuclideanSpace.proj i).continuous.measurable.comp measurable_snd
  have hinn : Measurable (fun qx : α × EuclideanSpace ℝ (Fin d) =>
      inner ℝ (p_hat qx.1.1 qx.1.2 qx.2 - UL.uniformVec K) (dirVec K hK)) :=
    (hp_joint.sub measurable_const).inner measurable_const
  have hF : StronglyMeasurable (fun qx : α × EuclideanSpace ℝ (Fin d) =>
      qx.2 i * inner ℝ (p_hat qx.1.1 qx.1.2 qx.2 - UL.uniformVec K) (dirVec K hK)) :=
    (hxi.mul hinn).stronglyMeasurable
  have hint : Measurable (fun q : α =>
      ∫ x, x i * inner ℝ (p_hat q.1 q.2 x - UL.uniformVec K) (dirVec K hK) ∂μ_X) :=
    (hF.integral_prod_right' (ν := μ_X)).measurable
  exact measurable_const.mul hint

/-! ### Vector-to-Hamming & Excess Risk Lower Bound -/

lemma sign_mismatch_sq_ge {K d : ℕ} (hd : 1 ≤ d) {b : Fin d → ℝ} {s : Fin d → Bool} {i : Fin d}
    (hmis : decide (0 ≤ b i) ≠ s i) :
    (scaleA K) ^ 2 / (d : ℝ) ≤ (b i - signWeight K d s i) ^ 2 := by
  have hd_pos : (0 : ℝ) < (d : ℝ) := Nat.cast_pos.mpr (by omega)
  have hsqrt_pos : 0 < Real.sqrt (d : ℝ) := Real.sqrt_pos.mpr hd_pos
  have ha_nonneg : 0 ≤ scaleA K := by unfold scaleA; positivity
  set c : ℝ := scaleA K / Real.sqrt (d : ℝ)
  have hc_nonneg : 0 ≤ c := div_nonneg ha_nonneg hsqrt_pos.le
  have hc_sq : c ^ 2 = (scaleA K) ^ 2 / (d : ℝ) := by
    dsimp [c]
    rw [div_pow, Real.sq_sqrt hd_pos.le]
  rw [← hc_sq]
  cases hs : s i
  · rw [hs] at hmis
    have hb_nn : 0 ≤ b i := by
      by_contra hlt
      exact hmis (decide_eq_false hlt)
    have hw : signWeight K d s i = -c := by simp [signWeight_apply, hs, c]
    rw [hw]
    nlinarith
  · rw [hs] at hmis
    have hb_neg : b i < 0 := by
      by_contra hge
      push_neg at hge
      exact hmis (decide_eq_true hge)
    have hw : signWeight K d s i = c := by simp [signWeight_apply, hs, c]
    rw [hw]
    nlinarith

lemma hamming_le_sum_sq_diff {K d : ℕ} (hd : 1 ≤ d) (b : Fin d → ℝ) (s : Fin d → Bool) :
    ((scaleA K) ^ 2 / (2 * (d : ℝ) ^ 2)) *
        ((Finset.univ.filter (fun i : Fin d => decide (0 ≤ b i) ≠ s i)).card : ℝ) ≤
      (1 / (2 * (d : ℝ))) * ∑ i : Fin d, (b i - signWeight K d s i) ^ 2 := by
  have hd_pos : (0 : ℝ) < (d : ℝ) := Nat.cast_pos.mpr (by omega)
  set S_bad := Finset.univ.filter (fun i : Fin d => decide (0 ≤ b i) ≠ s i)
  have hsum : (S_bad.card : ℝ) * ((scaleA K) ^ 2 / (d : ℝ)) ≤
      ∑ i : Fin d, (b i - signWeight K d s i) ^ 2 := by
    calc (S_bad.card : ℝ) * ((scaleA K) ^ 2 / (d : ℝ))
        = ∑ _i ∈ S_bad, ((scaleA K) ^ 2 / (d : ℝ)) := by
            rw [Finset.sum_const, nsmul_eq_mul]
      _ ≤ ∑ i ∈ S_bad, (b i - signWeight K d s i) ^ 2 :=
            Finset.sum_le_sum fun i hi => sign_mismatch_sq_ge hd (Finset.mem_filter.mp hi).2
      _ ≤ ∑ i ∈ Finset.univ, (b i - signWeight K d s i) ^ 2 :=
            Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _) (fun _ _ _ => sq_nonneg _)
  have hmul := mul_le_mul_of_nonneg_left hsum (by positivity : (0 : ℝ) ≤ 1 / (2 * (d : ℝ)))
  calc ((scaleA K) ^ 2 / (2 * (d : ℝ) ^ 2)) * (S_bad.card : ℝ)
      = (1 / (2 * (d : ℝ))) * ((S_bad.card : ℝ) * ((scaleA K) ^ 2 / (d : ℝ))) := by
          field_simp [hd_pos.ne']
    _ ≤ (1 / (2 * (d : ℝ))) * ∑ i : Fin d, (b i - signWeight K d s i) ^ 2 := hmul

lemma bddBelow_comparator_risk {K d : ℕ} {R : ℝ}
    (μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K)) [IsProbabilityMeasure μ]
    (hge : ∀ (v : UL.ZeroSumSubspace K) (y : Fin K),
      -2 ≤ UL.matchingLoss (quadEntropy K) (v : EuclideanSpace ℝ (Fin K)) y) :
    BddBelow (Set.range (fun V : {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K //
        UL.hilbertSchmidtNorm V ≤ R} =>
      ∫ z, UL.matchingLoss (quadEntropy K)
        ((V.1 z.1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) z.2 ∂μ)) := by
  refine ⟨-2, Set.forall_mem_range.mpr fun V => ?_⟩
  set f : EuclideanSpace ℝ (Fin d) × Fin K → ℝ := fun z =>
    UL.matchingLoss (quadEntropy K)
      ((V.1 z.1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) z.2
  by_cases hf : Integrable f μ
  · have hmono : ∫ _z, (-2 : ℝ) ∂μ ≤ ∫ z, f z ∂μ :=
      integral_mono (integrable_const (-2)) hf (fun z => hge (V.1 z.1) z.2)
    simpa using hmono
  · rw [integral_undef hf]
    norm_num

lemma measurable_loss_of_formula {K d : ℕ}
    (hform : ∀ {p : EuclideanSpace ℝ (Fin K)}, p ∈ UL.Simplex K → ∀ y : Fin K,
      UL.finiteCanonicalLoss (quadEntropy K) p y =
        (1 / 2 : ℝ) * ‖p - UL.uniformVec K‖ ^ 2 - (p y - UL.uniformVec K y))
    {f : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin K)}
    (hf_meas : Measurable f) (hf_simp : ∀ x, f x ∈ UL.Simplex K) :
    Measurable (fun z : EuclideanSpace ℝ (Fin d) × Fin K =>
      UL.finiteCanonicalLoss (quadEntropy K) (f z.1) z.2) := by
  let G : EuclideanSpace ℝ (Fin K) × Fin K → ℝ := fun qy =>
    (1 / 2 : ℝ) * ‖qy.1 - UL.uniformVec K‖ ^ 2 - (qy.1 qy.2 - UL.uniformVec K qy.2)
  have hG_cont : Continuous G := by
    rw [continuous_prod_of_discrete_right]
    intro y
    dsimp [G]
    exact (continuous_const.mul (((continuous_id.sub continuous_const).norm).pow 2)).sub
      ((EuclideanSpace.proj y).continuous.sub continuous_const)
  have hcomp : Measurable (fun z : EuclideanSpace ℝ (Fin d) × Fin K => G (f z.1, z.2)) :=
    hG_cont.measurable.comp ((hf_meas.comp measurable_fst).prodMk measurable_snd)
  have heq : (fun z : EuclideanSpace ℝ (Fin d) × Fin K =>
      UL.finiteCanonicalLoss (quadEntropy K) (f z.1) z.2) =
      (fun z => G (f z.1, z.2)) := by
    funext z
    exact hform (hf_simp z.1) z.2
  rw [heq]
  exact hcomp

lemma predictor_excess_risk_lower {K d n : ℕ} (hK : 2 ≤ K) (hd : 1 ≤ d)
    {Ξ : Type*} [MeasurableSpace Ξ]
    (μ_X : Measure (EuclideanSpace ℝ (Fin d))) [IsProbabilityMeasure μ_X]
    (hnorm : ∀ᵐ x ∂μ_X, ‖x‖ = 1)
    (hbessel : ∀ {g : EuclideanSpace ℝ (Fin d) → ℝ}, Measurable g → ∀ C, (∀ x, |g x| ≤ C) →
      ∀ w : EuclideanSpace ℝ (Fin d),
        (1 / (2 * (d : ℝ))) * (∑ i : Fin d, ((d : ℝ) * (∫ x, x i * g x ∂μ_X) - w i) ^ 2) ≤
          (1 / 2 : ℝ) * ∫ x, (g x - inner ℝ w x) ^ 2 ∂μ_X)
    (hform : ∀ {p : EuclideanSpace ℝ (Fin K)}, p ∈ UL.Simplex K → ∀ y : Fin K,
      UL.finiteCanonicalLoss (quadEntropy K) p y =
        (1 / 2 : ℝ) * ‖p - UL.uniformVec K‖ ^ 2 - (p y - UL.uniformVec K y))
    (hloss_bdd : ∀ {p : EuclideanSpace ℝ (Fin K)}, p ∈ UL.Simplex K → ∀ y : Fin K,
      |UL.finiteCanonicalLoss (quadEntropy K) p y| ≤ 4)
    (hregret : ∀ {p η : EuclideanSpace ℝ (Fin K)}, p ∈ UL.Simplex K → η ∈ UL.Simplex K →
      ∑ y : Fin K, η y * (UL.finiteCanonicalLoss (quadEntropy K) p y -
        UL.finiteCanonicalLoss (quadEntropy K) η y) = (1 / 2 : ℝ) * ‖p - η‖ ^ 2)
    (hmatch_lb : ∀ (v : UL.ZeroSumSubspace K) (y : Fin K),
      -2 ≤ UL.matchingLoss (quadEntropy K) (v : EuclideanSpace ℝ (Fin K)) y)
    (hmatch_eq : ∀ {η : EuclideanSpace ℝ (Fin K)}, η ∈ UL.Simplex K → ∀ y : Fin K,
      UL.matchingLoss (quadEntropy K) (η - UL.uniformVec K) y =
        UL.finiteCanonicalLoss (quadEntropy K) η y)
    (hs_hs : ∀ s : Fin d → Bool, UL.hilbertSchmidtNorm (scoreOp K hK d s) ≤ 1)
    (hη_simp : ∀ (s : Fin d → Bool) (x : EuclideanSpace ℝ (Fin d)),
      condProb K hK d s x ∈ UL.Simplex K)
    (hη_cont : ∀ s : Fin d → Bool, Continuous (condProb K hK d s))
    (hη_sub : ∀ (s : Fin d → Bool) {x : EuclideanSpace ℝ (Fin d)}, ‖x‖ ≤ 1 →
      condProb K hK d s x - UL.uniformVec K =
        ((scoreOp K hK d s x : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)))
    (hμ_prob : ∀ s : Fin d → Bool, IsProbabilityMeasure (jointLaw K hK μ_X s))
    (hμ_fst : ∀ s : Fin d → Bool, (jointLaw K hK μ_X s).fst = μ_X)
    (hμ_int : ∀ (s : Fin d → Bool) {f : EuclideanSpace ℝ (Fin d) × Fin K → ℝ},
      Measurable f → ∀ C, (∀ z, |f z| ≤ C) →
      ∫ z, f z ∂(jointLaw K hK μ_X s) =
        ∫ x, (∑ y : Fin K, condProb K hK d s x y * f (x, y)) ∂μ_X)
    {p_hat : Ξ → (Fin n → EuclideanSpace ℝ (Fin d) × Fin K) →
      EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin K)}
    (hp_meas : Measurable (fun r : Ξ × (Fin n → EuclideanSpace ℝ (Fin d) × Fin K) ×
      EuclideanSpace ℝ (Fin d) => p_hat r.1 r.2.1 r.2.2))
    (hp_simp : ∀ ξ S x, p_hat ξ S x ∈ UL.Simplex K)
    (s : Fin d → Bool) (q : Ξ × (Fin n → EuclideanSpace ℝ (Fin d) × Fin K)) :
    ((scaleA K) ^ 2 / (2 * (d : ℝ) ^ 2)) * (hammingErr K hK μ_X p_hat s q : ℝ) ≤
      (∫ z, UL.finiteCanonicalLoss (quadEntropy K) (p_hat q.1 q.2 z.1) z.2
          ∂(jointLaw K hK μ_X s)) -
        (⨅ V : {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K //
            UL.hilbertSchmidtNorm V ≤ 1},
          ∫ z, UL.matchingLoss (quadEntropy K)
            ((V.1 z.1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) z.2
            ∂(jointLaw K hK μ_X s)) := by
  haveI : IsProbabilityMeasure (jointLaw K hK μ_X s) := hμ_prob s
  set p := p_hat q.1 q.2
  set η := condProb K hK d s
  set μ_s := jointLaw K hK μ_X s
  have hp_m : Measurable p := measurable_p_hat_slice hp_meas q
  have hLp_m : Measurable (fun z : EuclideanSpace ℝ (Fin d) × Fin K =>
      UL.finiteCanonicalLoss (quadEntropy K) (p z.1) z.2) :=
    measurable_loss_of_formula hform hp_m (hp_simp q.1 q.2)
  have hLη_m : Measurable (fun z : EuclideanSpace ℝ (Fin d) × Fin K =>
      UL.finiteCanonicalLoss (quadEntropy K) (η z.1) z.2) :=
    measurable_loss_of_formula hform (hη_cont s).measurable (hη_simp s)
  have h_int_p : ∫ z, UL.finiteCanonicalLoss (quadEntropy K) (p z.1) z.2 ∂μ_s =
      ∫ x, (∑ y : Fin K, η x y * UL.finiteCanonicalLoss (quadEntropy K) (p x) y) ∂μ_X :=
    hμ_int s hLp_m 4 (fun z => hloss_bdd (hp_simp q.1 q.2 z.1) z.2)
  have h_int_η : ∫ z, UL.finiteCanonicalLoss (quadEntropy K) (η z.1) z.2 ∂μ_s =
      ∫ x, (∑ y : Fin K, η x y * UL.finiteCanonicalLoss (quadEntropy K) (η x) y) ∂μ_X :=
    hμ_int s hLη_m 4 (fun z => hloss_bdd (hη_simp s z.1) z.2)
  -- Comparator upper bound at V_s
  let V_s : {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K //
      UL.hilbertSchmidtNorm V ≤ 1} := ⟨scoreOp K hK d s, hs_hs s⟩
  have h_inf_le :
      (⨅ V : {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K //
          UL.hilbertSchmidtNorm V ≤ 1},
        ∫ z, UL.matchingLoss (quadEntropy K)
          ((V.1 z.1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) z.2 ∂μ_s) ≤
      ∫ z, UL.matchingLoss (quadEntropy K)
        ((V_s.1 z.1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) z.2 ∂μ_s :=
    ciInf_le (bddBelow_comparator_risk μ_s hmatch_lb) V_s
  -- On ‖z.1‖ = 1 (which holds μ_s-a.e.), matchingLoss V_s = finiteCanonicalLoss η
  have hnorm_μs : ∀ᵐ z ∂μ_s, ‖z.1‖ = 1 := by
    have hset : MeasurableSet {x : EuclideanSpace ℝ (Fin d) | ‖x‖ = 1} :=
      measurableSet_eq_fun continuous_norm.measurable measurable_const
    rw [ae_iff]
    have hpre : {z : EuclideanSpace ℝ (Fin d) × Fin K | ¬ ‖z.1‖ = 1} =
        Prod.fst ⁻¹' {x : EuclideanSpace ℝ (Fin d) | ‖x‖ = 1}ᶜ := rfl
    rw [hpre, ← Measure.fst_apply hset.compl, hμ_fst s]
    exact ae_iff.mp hnorm
  have h_match_int :
      ∫ z, UL.matchingLoss (quadEntropy K)
        ((V_s.1 z.1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) z.2 ∂μ_s =
      ∫ z, UL.finiteCanonicalLoss (quadEntropy K) (η z.1) z.2 ∂μ_s := by
    refine integral_congr_ae ?_
    filter_upwards [hnorm_μs] with z hz
    dsimp [V_s]
    rw [← hη_sub s hz.le, hmatch_eq (hη_simp s z.1) z.2]
  -- Combine risk difference into (1/2) ∫ ‖p x - η x‖^2 ∂μ_X
  have hInt_sum_p : Integrable
      (fun x => ∑ y : Fin K, η x y * UL.finiteCanonicalLoss (quadEntropy K) (p x) y) μ_X := by
    refine integrable_finset_sum Finset.univ fun y _ => ?_
    have hm1 : Measurable (fun x => η x y) :=
      (EuclideanSpace.proj y).continuous.measurable.comp (hη_cont s).measurable
    have hm2 : Measurable (fun x => UL.finiteCanonicalLoss (quadEntropy K) (p x) y) := by
      have heq : (fun x => UL.finiteCanonicalLoss (quadEntropy K) (p x) y) =
          (fun x => (1 / 2 : ℝ) * ‖p x - UL.uniformVec K‖ ^ 2 - (p x y - UL.uniformVec K y)) :=
        funext fun x => hform (hp_simp q.1 q.2 x) y
      rw [heq]
      exact (measurable_const.mul (((hp_m.sub measurable_const).norm).pow_const 2)).sub
        (((EuclideanSpace.proj y).continuous.measurable.comp hp_m).sub measurable_const)
    refine UL.Proof_lem_A_4.integrable_of_measurable_bounded (hm1.mul hm2) 4 (fun x => ?_)
    rw [Real.norm_eq_abs, abs_mul]
    have h1 : |η x y| ≤ 1 := by
      rw [abs_of_nonneg ((hη_simp s x).1 y)]
      exact UL.Proof_lem_A_4.simplex_coord_le_one (hη_simp s x) y
    have h2 : |UL.finiteCanonicalLoss (quadEntropy K) (p x) y| ≤ 4 :=
      hloss_bdd (hp_simp q.1 q.2 x) y
    nlinarith [abs_nonneg (UL.finiteCanonicalLoss (quadEntropy K) (p x) y)]
  have hInt_sum_η : Integrable
      (fun x => ∑ y : Fin K, η x y * UL.finiteCanonicalLoss (quadEntropy K) (η x) y) μ_X := by
    refine integrable_finset_sum Finset.univ fun y _ => ?_
    have hm1 : Measurable (fun x => η x y) :=
      (EuclideanSpace.proj y).continuous.measurable.comp (hη_cont s).measurable
    have hm2 : Measurable (fun x => UL.finiteCanonicalLoss (quadEntropy K) (η x) y) := by
      have heq : (fun x => UL.finiteCanonicalLoss (quadEntropy K) (η x) y) =
          (fun x => (1 / 2 : ℝ) * ‖η x - UL.uniformVec K‖ ^ 2 - (η x y - UL.uniformVec K y)) :=
        funext fun x => hform (hη_simp s x) y
      rw [heq]
      exact (measurable_const.mul (((((hη_cont s).measurable).sub measurable_const).norm).pow_const 2)).sub
        (((EuclideanSpace.proj y).continuous.measurable.comp (hη_cont s).measurable).sub measurable_const)
    refine UL.Proof_lem_A_4.integrable_of_measurable_bounded (hm1.mul hm2) 4 (fun x => ?_)
    rw [Real.norm_eq_abs, abs_mul]
    have h1 : |η x y| ≤ 1 := by
      rw [abs_of_nonneg ((hη_simp s x).1 y)]
      exact UL.Proof_lem_A_4.simplex_coord_le_one (hη_simp s x) y
    have h2 : |UL.finiteCanonicalLoss (quadEntropy K) (η x) y| ≤ 4 :=
      hloss_bdd (hη_simp s x) y
    nlinarith [abs_nonneg (UL.finiteCanonicalLoss (quadEntropy K) (η x) y)]
  have h_diff_eq :
      (∫ z, UL.finiteCanonicalLoss (quadEntropy K) (p z.1) z.2 ∂μ_s) -
        (∫ z, UL.finiteCanonicalLoss (quadEntropy K) (η z.1) z.2 ∂μ_s) =
      ∫ x, (1 / 2 : ℝ) * ‖p x - η x‖ ^ 2 ∂μ_X := by
    rw [h_int_p, h_int_η, ← integral_sub hInt_sum_p hInt_sum_η]
    refine integral_congr_ae (Filter.Eventually.of_forall fun x => ?_)
    dsimp only
    rw [← Finset.sum_sub_distrib]
    have hmul_sub : (∑ y : Fin K, (η x y * UL.finiteCanonicalLoss (quadEntropy K) (p x) y -
        η x y * UL.finiteCanonicalLoss (quadEntropy K) (η x) y)) =
        ∑ y : Fin K, η x y * (UL.finiteCanonicalLoss (quadEntropy K) (p x) y -
          UL.finiteCanonicalLoss (quadEntropy K) (η x) y) :=
      Finset.sum_congr rfl fun y _ => (mul_sub _ _ _).symm
    rw [hmul_sub, hregret (hp_simp q.1 q.2 x) (hη_simp s x)]
  -- Project onto dirVec K hK
  let g : EuclideanSpace ℝ (Fin d) → ℝ := fun x =>
    inner ℝ (p x - UL.uniformVec K) (dirVec K hK)
  have hg_meas : Measurable g :=
    (hp_m.sub measurable_const).inner measurable_const
  have hg_bdd : ∀ x, |g x| ≤ 2 := by
    intro x
    have hpu : ‖p x - UL.uniformVec K‖ ≤ 2 := by
      calc ‖p x - UL.uniformVec K‖ ≤ ‖p x‖ + ‖UL.uniformVec K‖ := norm_sub_le _ _
        _ ≤ 1 + 1 := add_le_add (UL.Proof_lem_A_5.norm_le_one_of_mem_simplex (hp_simp q.1 q.2 x))
            (UL.Proof_lem_A_5.norm_le_one_of_mem_simplex (UL.Proof_lem_A_5.uniformVec_mem_simplex hK))
        _ = 2 := by norm_num
    calc |inner ℝ (p x - UL.uniformVec K) (dirVec K hK)|
        ≤ ‖p x - UL.uniformVec K‖ * ‖dirVec K hK‖ := abs_real_inner_le_norm _ _
      _ = ‖p x - UL.uniformVec K‖ := by rw [norm_dirVec hK, mul_one]
      _ ≤ 2 := hpu
  have hInt_proj : Integrable (fun x => (1 / 2 : ℝ) * (g x - inner ℝ (signWeight K d s) x) ^ 2) μ_X := by
    have hm : Measurable (fun x => (1 / 2 : ℝ) * (g x - inner ℝ (signWeight K d s) x) ^ 2) :=
      measurable_const.mul ((hg_meas.sub (measurable_const.inner measurable_id)).pow_const 2)
    have h_ae : ∀ᵐ x ∂μ_X, ‖(1 / 2 : ℝ) * (g x - inner ℝ (signWeight K d s) x) ^ 2‖ ≤
        (1 / 2 : ℝ) * (2 + ‖signWeight K d s‖) ^ 2 := by
      filter_upwards [hnorm] with x hx
      rw [Real.norm_eq_abs, abs_of_nonneg (mul_nonneg (by norm_num) (sq_nonneg _))]
      have hwx : |inner ℝ (signWeight K d s) x| ≤ ‖signWeight K d s‖ := by
        calc |inner ℝ (signWeight K d s) x| ≤ ‖signWeight K d s‖ * ‖x‖ := abs_real_inner_le_norm _ _
          _ = ‖signWeight K d s‖ := by rw [hx, mul_one]
      have hdiff_abs : |g x - inner ℝ (signWeight K d s) x| ≤ 2 + ‖signWeight K d s‖ := by
        calc |g x - inner ℝ (signWeight K d s) x|
            ≤ |g x| + |inner ℝ (signWeight K d s) x| := abs_sub _ _
          _ ≤ 2 + ‖signWeight K d s‖ := add_le_add (hg_bdd x) hwx
      have hsq : (g x - inner ℝ (signWeight K d s) x) ^ 2 ≤ (2 + ‖signWeight K d s‖) ^ 2 := by
        rw [← sq_abs (g x - inner ℝ (signWeight K d s) x)]
        exact pow_le_pow_left₀ (abs_nonneg _) hdiff_abs 2
      exact mul_le_mul_of_nonneg_left hsq (by norm_num)
    exact (memLp_top_of_bound hm.aestronglyMeasurable _ h_ae).integrable le_top
  have hInt_full : Integrable (fun x => (1 / 2 : ℝ) * ‖p x - η x‖ ^ 2) μ_X := by
    have hm : Measurable (fun x => (1 / 2 : ℝ) * ‖p x - η x‖ ^ 2) :=
      measurable_const.mul (((hp_m.sub (hη_cont s).measurable).norm).pow_const 2)
    refine UL.Proof_lem_A_4.integrable_of_measurable_bounded hm 2 (fun x => ?_)
    rw [Real.norm_eq_abs, abs_of_nonneg (mul_nonneg (by norm_num) (sq_nonneg _))]
    have hpn : ‖p x - η x‖ ≤ 2 := by
      calc ‖p x - η x‖ ≤ ‖p x‖ + ‖η x‖ := norm_sub_le _ _
        _ ≤ 1 + 1 := add_le_add (UL.Proof_lem_A_5.norm_le_one_of_mem_simplex (hp_simp q.1 q.2 x))
            (UL.Proof_lem_A_5.norm_le_one_of_mem_simplex (hη_simp s x))
        _ = 2 := by norm_num
    nlinarith [norm_nonneg (p x - η x)]
  have h_proj_le :
      (1 / 2 : ℝ) * (∫ x, (g x - inner ℝ (signWeight K d s) x) ^ 2 ∂μ_X) ≤
        ∫ x, (1 / 2 : ℝ) * ‖p x - η x‖ ^ 2 ∂μ_X := by
    rw [← integral_const_mul]
    refine integral_mono_ae hInt_proj hInt_full ?_
    filter_upwards [hnorm] with x hx
    have hη_eq : η x - UL.uniformVec K = inner ℝ (signWeight K d s) x • dirVec K hK := by
      rw [hη_sub s hx.le, scoreOp_coe_apply]
    have hpη_sub : p x - η x = (p x - UL.uniformVec K) - (η x - UL.uniformVec K) := by abel
    have hinn_eq : inner ℝ (p x - η x) (dirVec K hK) = g x - inner ℝ (signWeight K d s) x := by
      rw [hpη_sub, inner_sub_left, hη_eq, inner_smul_left, conj_trivial,
        real_inner_self_eq_norm_sq, norm_dirVec_sq hK, mul_one]
    have hcs : |inner ℝ (p x - η x) (dirVec K hK)| ≤ ‖p x - η x‖ := by
      calc |inner ℝ (p x - η x) (dirVec K hK)|
          ≤ ‖p x - η x‖ * ‖dirVec K hK‖ := abs_real_inner_le_norm _ _
        _ = ‖p x - η x‖ := by rw [norm_dirVec hK, mul_one]
    have hsq : (g x - inner ℝ (signWeight K d s) x) ^ 2 ≤ ‖p x - η x‖ ^ 2 := by
      rw [← hinn_eq, ← sq_abs (inner ℝ (p x - η x) (dirVec K hK))]
      exact pow_le_pow_left₀ (abs_nonneg _) hcs 2
    exact mul_le_mul_of_nonneg_left hsq (by norm_num)
  have h_bessel := hbessel hg_meas 2 hg_bdd (signWeight K d s)
  have h_ham : ((scaleA K) ^ 2 / (2 * (d : ℝ) ^ 2)) * (hammingErr K hK μ_X p_hat s q : ℝ) ≤
      (1 / (2 * (d : ℝ))) * ∑ i : Fin d,
        ((d : ℝ) * (∫ x, x i * g x ∂μ_X) - signWeight K d s i) ^ 2 :=
    hamming_le_sum_sq_diff (K := K) hd (estCoord K hK μ_X p_hat q) s
  calc ((scaleA K) ^ 2 / (2 * (d : ℝ) ^ 2)) * (hammingErr K hK μ_X p_hat s q : ℝ)
      ≤ (1 / (2 * (d : ℝ))) * ∑ i : Fin d,
          ((d : ℝ) * (∫ x, x i * g x ∂μ_X) - signWeight K d s i) ^ 2 := h_ham
    _ ≤ (1 / 2 : ℝ) * ∫ x, (g x - inner ℝ (signWeight K d s) x) ^ 2 ∂μ_X := h_bessel
    _ ≤ ∫ x, (1 / 2 : ℝ) * ‖p x - η x‖ ^ 2 ∂μ_X := h_proj_le
    _ = (∫ z, UL.finiteCanonicalLoss (quadEntropy K) (p z.1) z.2 ∂μ_s) -
          (∫ z, UL.finiteCanonicalLoss (quadEntropy K) (η z.1) z.2 ∂μ_s) := h_diff_eq.symm
    _ = (∫ z, UL.finiteCanonicalLoss (quadEntropy K) (p z.1) z.2 ∂μ_s) -
          (∫ z, UL.matchingLoss (quadEntropy K)
            ((V_s.1 z.1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) z.2 ∂μ_s) := by
          rw [h_match_int]
    _ ≤ (∫ z, UL.finiteCanonicalLoss (quadEntropy K) (p z.1) z.2 ∂μ_s) -
          (⨅ V : {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K //
              UL.hilbertSchmidtNorm V ≤ 1},
            ∫ z, UL.matchingLoss (quadEntropy K)
              ((V.1 z.1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) z.2 ∂μ_s) :=
          sub_le_sub_left h_inf_le _

/-! ### Abstract Assouad + Reverse Markov -/

/-- Sign-flip involution at coordinate `i` on `{false, true}^d`. -/
def flipSignEquiv {d : ℕ} (i : Fin d) : (Fin d → Bool) ≃ (Fin d → Bool) where
  toFun s := Function.update s i (!s i)
  invFun s := Function.update s i (!s i)
  left_inv s := by
    ext j
    by_cases hj : j = i
    · subst hj; simp
    · simp [hj]
  right_inv s := by
    ext j
    by_cases hj : j = i
    · subst hj; simp
    · simp [hj]

lemma assouad_reverse_markov {d : ℕ} (hd : 1 ≤ d) {α : Type*} [MeasurableSpace α]
    (P : (Fin d → Bool) → Measure α) (hP : ∀ s, IsProbabilityMeasure (P s))
    (b : α → Fin d → ℝ) (hb : ∀ i, Measurable (fun q => b q i))
    (htv : ∀ (s : Fin d → Bool) (i : Fin d) {A : Set α}, MeasurableSet A →
      |((P s) A).toReal - ((P (Function.update s i (!s i))) A).toReal| ≤ 1 / 4) :
    ∃ s : Fin d → Bool,
      (P s { q : α | (d : ℝ) / 8 ≤
        ((Finset.univ.filter (fun i : Fin d => decide (0 ≤ b q i) ≠ s i)).card : ℝ) }ᶜ) ≤
        ENNReal.ofReal ((5 : ℝ) / 7) := by
  have hd_pos : (0 : ℝ) < (d : ℝ) := Nat.cast_pos.mpr (by omega)
  let errBit : (Fin d → Bool) → Fin d → α → ℝ := fun s i q =>
    if decide (0 ≤ b q i) ≠ s i then (1 : ℝ) else 0
  let A_set : Fin d → Set α := fun i => {q : α | 0 ≤ b q i}
  have hA_meas : ∀ i : Fin d, MeasurableSet (A_set i) := fun i =>
    measurableSet_le measurable_const (hb i)
  have herr_eq_ind : ∀ (s : Fin d → Bool) (i : Fin d),
      errBit s i = if s i then (A_set i)ᶜ.indicator (fun _ => (1 : ℝ))
                   else (A_set i).indicator (fun _ => (1 : ℝ)) := by
    intro s i
    funext q
    cases hs : s i
    · simp only [errBit, A_set, hs, Bool.false_eq_true, ↓reduceIte, Set.indicator_apply,
        Set.mem_setOf_eq]
      by_cases h0 : 0 ≤ b q i <;> simp [h0]
    · simp only [errBit, A_set, hs, ↓reduceIte, Set.indicator_apply, Set.mem_compl_iff,
        Set.mem_setOf_eq]
      by_cases h0 : 0 ≤ b q i <;> simp [h0]
  have herr_int : ∀ (s : Fin d → Bool) (i : Fin d), Integrable (errBit s i) (P s) := by
    intro s i
    haveI := hP s
    rw [herr_eq_ind s i]
    split_ifs
    · exact (integrable_const (1 : ℝ)).indicator (hA_meas i).compl
    · exact (integrable_const (1 : ℝ)).indicator (hA_meas i)
  have herr_integral : ∀ (s : Fin d → Bool) (i : Fin d),
      ∫ q, errBit s i q ∂(P s) =
        if s i then 1 - ((P s) (A_set i)).toReal else ((P s) (A_set i)).toReal := by
    intro s i
    haveI := hP s
    rw [herr_eq_ind s i]
    split_ifs with hs
    · rw [integral_indicator_const _ (hA_meas i).compl, smul_eq_mul, mul_one,
        measureReal_def, prob_compl_eq_one_sub (hA_meas i),
        ENNReal.toReal_sub_of_le (prob_le_one) ENNReal.one_ne_top, ENNReal.toReal_one]
    · rw [integral_indicator_const _ (hA_meas i), smul_eq_mul, mul_one, measureReal_def]
  have hpair : ∀ (s : Fin d → Bool) (i : Fin d),
      (3 / 4 : ℝ) ≤ (∫ q, errBit s i q ∂(P s)) +
        (∫ q, errBit (flipSignEquiv i s) i q ∂(P (flipSignEquiv i s))) := by
    intro s i
    rw [herr_integral s i, herr_integral (flipSignEquiv i s) i]
    have hflip_i : (flipSignEquiv i s) i = !(s i) := by simp [flipSignEquiv]
    rw [hflip_i]
    have hdiff := abs_le.mp (htv s i (hA_meas i))
    change -(1 / 4) ≤ ((P s) (A_set i)).toReal - ((P (flipSignEquiv i s)) (A_set i)).toReal ∧
      ((P s) (A_set i)).toReal - ((P (flipSignEquiv i s)) (A_set i)).toReal ≤ 1 / 4 at hdiff
    cases hs : s i <;> simp only [Bool.not_true, Bool.not_false, Bool.false_eq_true, ↓reduceIte]
    · linarith [hdiff.1]
    · linarith [hdiff.2]
  have hsum_i : ∀ i : Fin d,
      ((Fintype.card (Fin d → Bool) : ℝ) * (3 / 8)) ≤
        ∑ s : (Fin d → Bool), ∫ q, errBit s i q ∂(P s) := by
    intro i
    have h2 : ∑ s : (Fin d → Bool), (3 / 4 : ℝ) ≤
        ∑ s : (Fin d → Bool), ((∫ q, errBit s i q ∂(P s)) +
          (∫ q, errBit (flipSignEquiv i s) i q ∂(P (flipSignEquiv i s)))) :=
      Finset.sum_le_sum fun s _ => hpair s i
    rw [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, Finset.sum_add_distrib] at h2
    have hbij : (∑ s : (Fin d → Bool),
        ∫ q, errBit (flipSignEquiv i s) i q ∂(P (flipSignEquiv i s))) =
        ∑ s : (Fin d → Bool), ∫ q, errBit s i q ∂(P s) :=
      (flipSignEquiv i).sum_comp (fun s => ∫ q, errBit s i q ∂(P s))
    rw [hbij] at h2
    linarith
  let N_fn : (Fin d → Bool) → α → ℝ := fun s q =>
    ((Finset.univ.filter (fun i : Fin d => decide (0 ≤ b q i) ≠ s i)).card : ℝ)
  have hN_eq_sum : ∀ (s : Fin d → Bool) (q : α),
      N_fn s q = ∑ i : Fin d, errBit s i q := by
    intro s q
    dsimp [N_fn, errBit]
    rw [Finset.card_filter, Nat.cast_sum]
    refine Finset.sum_congr rfl fun i _ => ?_
    split_ifs <;> simp
  have hN_int : ∀ s : Fin d → Bool, Integrable (N_fn s) (P s) := by
    intro s
    have heq : N_fn s = fun q => ∑ i : Fin d, errBit s i q := funext (hN_eq_sum s)
    rw [heq]
    exact integrable_finset_sum Finset.univ fun i _ => herr_int s i
  have hsum_all : (Fintype.card (Fin d → Bool) : ℝ) * (3 * (d : ℝ) / 8) ≤
      ∑ s : (Fin d → Bool), ∫ q, N_fn s q ∂(P s) := by
    have h1 : ∀ s : Fin d → Bool,
        ∫ q, N_fn s q ∂(P s) = ∑ i : Fin d, ∫ q, errBit s i q ∂(P s) := by
      intro s
      have heq : N_fn s = fun q => ∑ i : Fin d, errBit s i q := funext (hN_eq_sum s)
      rw [heq]
      exact integral_finset_sum Finset.univ fun i _ => herr_int s i
    simp_rw [h1]
    rw [Finset.sum_comm]
    calc (Fintype.card (Fin d → Bool) : ℝ) * (3 * (d : ℝ) / 8)
        = ∑ _i : Fin d, ((Fintype.card (Fin d → Bool) : ℝ) * (3 / 8)) := by
            rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
            ring
      _ ≤ ∑ i : Fin d, ∑ s : (Fin d → Bool), ∫ q, errBit s i q ∂(P s) :=
            Finset.sum_le_sum fun i _ => hsum_i i
  -- Pick s* achieving average ≥ 3d/8
  have hne_univ : (Finset.univ : Finset (Fin d → Bool)).Nonempty :=
    ⟨fun _ => false, Finset.mem_univ _⟩
  obtain ⟨s_star, _, hs_star⟩ : ∃ s ∈ (Finset.univ : Finset (Fin d → Bool)),
      3 * (d : ℝ) / 8 ≤ ∫ q, N_fn s q ∂(P s) := by
    by_contra! hlt
    have hstrict : ∑ s ∈ (Finset.univ : Finset (Fin d → Bool)), ∫ q, N_fn s q ∂(P s) <
        ∑ _s ∈ (Finset.univ : Finset (Fin d → Bool)), (3 * (d : ℝ) / 8) :=
      Finset.sum_lt_sum_of_nonempty hne_univ fun s hs => hlt s hs
    rw [Finset.sum_const, Finset.card_univ, nsmul_eq_mul] at hstrict
    linarith
  refine ⟨s_star, ?_⟩
  haveI := hP s_star
  set Bad : Set α := {q : α | (d : ℝ) / 8 ≤ N_fn s_star q}
  have hN_meas : Measurable (N_fn s_star) := by
    have heq : N_fn s_star = fun q => ∑ i : Fin d, errBit s_star i q := funext (hN_eq_sum s_star)
    rw [heq]
    refine Finset.induction_on Finset.univ measurable_const fun i S hi ih => ?_
    simp only [Finset.sum_insert hi]
    refine Measurable.add ?_ ih
    rw [herr_eq_ind s_star i]
    split_ifs
    · exact measurable_const.indicator (hA_meas i).compl
    · exact measurable_const.indicator (hA_meas i)
  have hBad_meas : MeasurableSet Bad := measurableSet_le measurable_const hN_meas
  have hN_le_d : ∀ q : α, N_fn s_star q ≤ (d : ℝ) := by
    intro q
    dsimp [N_fn]
    exact_mod_cast (Finset.card_le_univ _).trans_eq (Fintype.card_fin d)
  have h_ptwise : ∀ q : α,
      N_fn s_star q ≤ (d : ℝ) / 8 + (7 * (d : ℝ) / 8) * Bad.indicator (fun _ => (1 : ℝ)) q := by
    intro q
    by_cases hq : q ∈ Bad
    · rw [Set.indicator_of_mem hq]
      linarith [hN_le_d q]
    · rw [Set.indicator_of_notMem hq]
      have hlt : N_fn s_star q < (d : ℝ) / 8 := not_le.mp hq
      linarith
  have hInt_rhs : Integrable
      (fun q => (d : ℝ) / 8 + (7 * (d : ℝ) / 8) * Bad.indicator (fun _ => (1 : ℝ)) q) (P s_star) :=
    (integrable_const _).add (((integrable_const (1 : ℝ)).indicator hBad_meas).const_mul _)
  have h_int_ineq : ∫ q, N_fn s_star q ∂(P s_star) ≤
      (d : ℝ) / 8 + (7 * (d : ℝ) / 8) * ((P s_star) Bad).toReal := by
    have hm := integral_mono (hN_int s_star) hInt_rhs h_ptwise
    rw [integral_add (integrable_const _) (((integrable_const (1 : ℝ)).indicator hBad_meas).const_mul _),
      integral_const_mul, integral_indicator_const _ hBad_meas] at hm
    simpa [measureReal_def] using hm
  have h_prob_bad : (2 : ℝ) / 7 ≤ ((P s_star) Bad).toReal := by
    have h1 : 2 * (d : ℝ) / 8 ≤ (7 * (d : ℝ) / 8) * ((P s_star) Bad).toReal := by
      linarith [hs_star, h_int_ineq]
    nlinarith
  have h_prob_compl_real : ((P s_star) Badᶜ).toReal ≤ (5 : ℝ) / 7 := by
    rw [prob_compl_eq_one_sub hBad_meas,
      ENNReal.toReal_sub_of_le prob_le_one ENNReal.one_ne_top, ENNReal.toReal_one]
    linarith
  have h_ne_top : (P s_star) Badᶜ ≠ ⊤ := measure_ne_top (P s_star) Badᶜ
  rw [← ENNReal.ofReal_toReal h_ne_top]
  exact ENNReal.ofReal_le_ofReal h_prob_compl_real

/-! ### Dimension and Constant Arithmetic -/

lemma dim_and_sample_arithmetic {K : ℕ} (hK : 2 ≤ K) {ε : ℝ} (hε_pos : 0 < ε)
    (hε_le : ε ≤ 1 / (256 * (K : ℝ) ^ 2)) :
    let c₁ := 1 / (256 * (K : ℝ) ^ 2)
    let c₂ := 1 / (128 * (K : ℝ) ^ 2)
    let c₃ := 1 / (1048576 * (K : ℝ) ^ 3)
    let d := Nat.floor (1 / (128 * (K : ℝ) ^ 2 * ε))
    1 ≤ d ∧
    c₁ / ε ≤ (d : ℝ) ∧
    (d : ℝ) ≤ c₂ / ε ∧
    (∀ n : ℕ, (n : ℝ) < c₃ / ε ^ 2 → (n : ℝ) ≤ (K : ℝ) * (d : ℝ) ^ 2 / 16) ∧
    (∀ N : ℝ, (d : ℝ) / 8 ≤ N → ε < ((scaleA K) ^ 2 / (2 * (d : ℝ) ^ 2)) * N) := by
  intro c₁ c₂ c₃ d
  have hK_pos : (0 : ℝ) < (K : ℝ) := Nat.cast_pos.mpr (by omega)
  have hK2_pos : 0 < (K : ℝ) ^ 2 := by positivity
  set t : ℝ := 1 / (128 * (K : ℝ) ^ 2 * ε)
  have ht_pos : 0 < t := by dsimp [t]; positivity
  have ht_ge_two : 2 ≤ t := by
    dsimp [t]
    rw [le_div_iff₀ (by positivity)]
    have h1 : 256 * (K : ℝ) ^ 2 * ε ≤ 1 := by
      have := (le_div_iff₀ (by positivity : (0 : ℝ) < 256 * (K : ℝ) ^ 2)).mp hε_le
      linarith
    linarith
  have hd_ge_two : 2 ≤ d := Nat.le_floor ht_ge_two
  have hd_ge_one : 1 ≤ d := by omega
  have hd_le_t : (d : ℝ) ≤ t := Nat.floor_le ht_pos.le
  have ht_sub_lt : t - 1 < (d : ℝ) := Nat.sub_one_lt_floor t
  have hc1_le_d : c₁ / ε ≤ (d : ℝ) := by
    have hc1_eq : c₁ / ε = t / 2 := by
      dsimp [c₁, t]
      field_simp [hK_pos.ne', hε_pos.ne']
      ring
    rw [hc1_eq]
    linarith
  have hd_le_c2 : (d : ℝ) ≤ c₂ / ε := by
    have hc2_eq : c₂ / ε = t := by
      dsimp [c₂, t]
      field_simp [hK_pos.ne', hε_pos.ne']
    rwa [hc2_eq]
  refine ⟨hd_ge_one, hc1_le_d, hd_le_c2, ?_, ?_⟩
  · intro n hn
    have hc1_pos : 0 < c₁ / ε := by dsimp [c₁]; positivity
    have hsq : (c₁ / ε) ^ 2 ≤ (d : ℝ) ^ 2 := pow_le_pow_left₀ hc1_pos.le hc1_le_d 2
    have hc3_eq : c₃ / ε ^ 2 = (K : ℝ) * (c₁ / ε) ^ 2 / 16 := by
      dsimp [c₃, c₁]
      field_simp [hK_pos.ne', hε_pos.ne']
      ring
    have hle : c₃ / ε ^ 2 ≤ (K : ℝ) * (d : ℝ) ^ 2 / 16 := by
      rw [hc3_eq]
      exact div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left hsq hK_pos.le) (by norm_num)
    linarith
  · intro N hN
    have hd_pos : (0 : ℝ) < (d : ℝ) := Nat.cast_pos.mpr (by omega)
    have hcoef_pos : 0 < (scaleA K) ^ 2 / (2 * (d : ℝ) ^ 2) := by
      unfold scaleA; positivity
    have h1 : 1 / (64 * (K : ℝ) ^ 2 * (d : ℝ)) ≤ ((scaleA K) ^ 2 / (2 * (d : ℝ) ^ 2)) * N := by
      calc 1 / (64 * (K : ℝ) ^ 2 * (d : ℝ))
          = ((scaleA K) ^ 2 / (2 * (d : ℝ) ^ 2)) * ((d : ℝ) / 8) := by
              unfold scaleA
              field_simp [hK_pos.ne', hd_pos.ne']
              ring
        _ ≤ ((scaleA K) ^ 2 / (2 * (d : ℝ) ^ 2)) * N :=
              mul_le_mul_of_nonneg_left hN hcoef_pos.le
    have h2 : 2 * ε ≤ 1 / (64 * (K : ℝ) ^ 2 * (d : ℝ)) := by
      rw [le_div_iff₀ (by positivity)]
      have hdt : (d : ℝ) * (128 * (K : ℝ) ^ 2 * ε) ≤ 1 :=
        (le_div_iff₀ (by positivity)).mp hd_le_t
      linarith
    linarith

end UL.Proof_prop_C_5_Race2

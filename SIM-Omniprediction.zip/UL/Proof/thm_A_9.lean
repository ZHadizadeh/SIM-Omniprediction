import UL.Stmt.thm_A_9
import UL.Proof.thm_A_9.H3_LowerAndAttain
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_thm_A_9 : S_thm_A_9 := by
  unfold S_thm_A_9
  intro K hK R β L hR hβ hL hcond
  dsimp only
  let m : ℕ := K - 1
  let η := Proof_thm_A_9.etaMap K hK R β L
  have hη_cont : Continuous η := Proof_thm_A_9.continuous_etaMap K hK R β hL
  have hη_simp : ∀ x, η x ∈ Simplex K := Proof_thm_A_9.etaMap_mem_simplex hK hR hβ hL hcond
  refine ⟨Proof_thm_A_9.jointMeasureP m K L η, Proof_thm_A_9.phiBeta K β,
    ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · exact Proof_thm_A_9.jointMeasureP_isProb m K hL hη_cont hη_simp
  · exact Proof_thm_A_9.jointMeasureP_isUniform m K L hη_cont hη_simp
  · exact Proof_thm_A_9.phiBeta_mem_entropyFamily hβ
  · exact Proof_thm_A_9.phiBeta_exists_quad_repr K β
  · rw [Proof_thm_A_9.bench_eq_coe K hK hR hβ hL hcond]
    exact EReal.coe_ne_bot _
  · rw [Proof_thm_A_9.bench_eq_coe K hK hR hβ hL hcond]
    exact EReal.coe_ne_top _
  · intro r hr1 hrm B hB
    exact Proof_thm_A_9.joint_tradeoff_pos_rank hK hR hβ hL hcond hr1 hrm hB
  · intro B hB
    exact Proof_thm_A_9.joint_tradeoff_zero_rank hK hR hβ hL hcond hB

end UL

import Mathlib
set_option autoImplicit false

namespace UL.Proof_thm_A_9

open MeasureTheory

noncomputable def ballUniformMeasure (m : ℕ) (L : ℝ) :
    Measure (EuclideanSpace ℝ (Fin m)) :=
  ProbabilityTheory.cond volume (Metric.ball (0 : EuclideanSpace ℝ (Fin m)) L)

lemma ballUniformMeasure_isProb (m : ℕ) {L : ℝ} (hL : 0 < L) :
    IsProbabilityMeasure (ballUniformMeasure m L) := by
  unfold ballUniformMeasure
  exact ProbabilityTheory.cond_isProbabilityMeasure_of_finite
    (Metric.measure_ball_pos volume (0 : EuclideanSpace ℝ (Fin m)) hL).ne'
    measure_ball_lt_top.ne

lemma ae_mem_ball_ballUniformMeasure (m : ℕ) (L : ℝ) :
    ∀ᵐ x ∂(ballUniformMeasure m L), x ∈ Metric.ball (0 : EuclideanSpace ℝ (Fin m)) L :=
  ProbabilityTheory.ae_cond_mem measurableSet_ball

lemma integrable_of_continuous_ballUniformMeasure {m : ℕ} {L : ℝ} (hL : 0 < L)
    {g : EuclideanSpace ℝ (Fin m) → ℝ} (hg : Continuous g) :
    Integrable g (ballUniformMeasure m L) := by
  haveI : IsProbabilityMeasure (ballUniformMeasure m L) := ballUniformMeasure_isProb m hL
  obtain ⟨C, hC⟩ :=
    (isCompact_closedBall (0 : EuclideanSpace ℝ (Fin m)) L).exists_bound_of_continuousOn
      hg.continuousOn
  have h_bdd : ∀ᵐ x ∂(ballUniformMeasure m L), ‖g x‖ ≤ C := by
    filter_upwards [ae_mem_ball_ballUniformMeasure m L] with x hx
    exact hC x (Metric.ball_subset_closedBall hx)
  exact (memLp_top_of_bound hg.aestronglyMeasurable C h_bdd).integrable le_top

lemma ballUniformMeasure_map_iso {m : ℕ} (L : ℝ)
    (Q : EuclideanSpace ℝ (Fin m) ≃ₗᵢ[ℝ] EuclideanSpace ℝ (Fin m)) :
    (ballUniformMeasure m L).map Q = ballUniformMeasure m L := by
  let B : Set (EuclideanSpace ℝ (Fin m)) := Metric.ball 0 L
  ext s hs
  rw [Measure.map_apply Q.continuous.measurable hs]
  unfold ballUniformMeasure
  rw [ProbabilityTheory.cond_apply measurableSet_ball,
    ProbabilityTheory.cond_apply measurableSet_ball]
  congr 1
  have hpre : B ∩ Q ⁻¹' s = Q ⁻¹' (B ∩ s) := by
    ext x
    simp [B, Metric.mem_ball, dist_zero_right, Q.norm_map]
  rw [hpre, ← Measure.map_apply Q.continuous.measurable (measurableSet_ball.inter hs),
    Q.measurePreserving.map_eq]

lemma integral_comp_iso_ballUniformMeasure {m : ℕ} (L : ℝ)
    (Q : EuclideanSpace ℝ (Fin m) ≃ₗᵢ[ℝ] EuclideanSpace ℝ (Fin m))
    {g : EuclideanSpace ℝ (Fin m) → ℝ} (hg : Measurable g) :
    ∫ x, g (Q x) ∂(ballUniformMeasure m L) = ∫ x, g x ∂(ballUniformMeasure m L) := by
  rw [← integral_map Q.continuous.measurable.aemeasurable hg.aestronglyMeasurable,
    ballUniformMeasure_map_iso L Q]

private lemma lintegral_Ioo_two_mul {a b : ℝ} (ha : 0 ≤ a) (hab : a ≤ b) :
    (∫⁻ t in Set.Ioo a b, ENNReal.ofReal (2 * t) ∂volume) =
      ENNReal.ofReal (b ^ 2 - a ^ 2) := by
  have hint_on : IntegrableOn (fun t : ℝ => 2 * t) (Set.Ioc a b) volume :=
    (continuous_const.mul continuous_id).integrableOn_Ioc
  have hnn : ∀ᵐ t ∂(volume.restrict (Set.Ioc a b)), 0 ≤ 2 * t := by
    filter_upwards [ae_restrict_mem measurableSet_Ioc] with t ht
    have ht0 : 0 ≤ t := ha.trans ht.1.le
    linarith
  have hftc : ∫ t in a..b, (2 * t) = b ^ 2 - a ^ 2 := by
    have hc : Continuous (fun t : ℝ => 2 * t) := continuous_const.mul continuous_id
    exact intervalIntegral.integral_eq_sub_of_hasDerivAt
      (f := fun t : ℝ => t ^ 2)
      (fun t _ => by simpa [pow_one] using hasDerivAt_pow 2 t)
      (hc.intervalIntegrable a b)
  rw [Measure.restrict_congr_set Ioo_ae_eq_Ioc,
    ← ofReal_integral_eq_lintegral_ofReal hint_on hnn,
    ← intervalIntegral.integral_of_le hab, hftc]

private lemma lintegral_Ioo_two_pow {m : ℕ} {L : ℝ} (hL : 0 < L) :
    (∫⁻ t in Set.Ioo (0 : ℝ) L, ENNReal.ofReal (2 * t ^ (m + 1)) ∂volume) =
      ENNReal.ofReal (2 * L ^ (m + 2) / ((m : ℝ) + 2)) := by
  have hm2_pos : (0 : ℝ) < (m : ℝ) + 2 := by positivity
  have hcont : Continuous (fun t : ℝ => 2 * t ^ (m + 1)) :=
    continuous_const.mul (continuous_pow (m + 1))
  have hint_on : IntegrableOn (fun t : ℝ => 2 * t ^ (m + 1)) (Set.Ioc 0 L) volume :=
    hcont.integrableOn_Ioc
  have hnn : ∀ᵐ t ∂(volume.restrict (Set.Ioc (0 : ℝ) L)), 0 ≤ 2 * t ^ (m + 1) := by
    filter_upwards [ae_restrict_mem measurableSet_Ioc] with t ht
    exact mul_nonneg zero_le_two (pow_nonneg ht.1.le _)
  have hderiv : ∀ t : ℝ,
      HasDerivAt (fun s : ℝ => 2 * s ^ (m + 2) / ((m : ℝ) + 2)) (2 * t ^ (m + 1)) t := by
    intro t
    have hd := ((hasDerivAt_pow (m + 2) t).const_mul 2).div_const ((m : ℝ) + 2)
    convert hd using 1
    have hcast : ((m + 2 : ℕ) : ℝ) = (m : ℝ) + 2 := by push_cast; ring
    have hsub : m + 2 - 1 = m + 1 := by omega
    rw [hsub, hcast]
    field_simp [hm2_pos.ne']
  have hftc : ∫ t in (0 : ℝ)..L, (2 * t ^ (m + 1)) = 2 * L ^ (m + 2) / ((m : ℝ) + 2) := by
    rw [intervalIntegral.integral_eq_sub_of_hasDerivAt
      (fun t _ => hderiv t) (hcont.intervalIntegrable 0 L)]
    simp
  rw [Measure.restrict_congr_set Ioo_ae_eq_Ioc,
    ← ofReal_integral_eq_lintegral_ofReal hint_on hnn,
    ← intervalIntegral.integral_of_le hL.le, hftc]

theorem integral_norm_sq_ballUniformMeasure (m : ℕ) {L : ℝ} (hL : 0 < L) :
    ∫ x, ‖x‖ ^ 2 ∂(ballUniformMeasure m L) = (m : ℝ) * L ^ 2 / ((m : ℝ) + 2) := by
  let B : Set (EuclideanSpace ℝ (Fin m)) := Metric.ball 0 L
  let V1 : ENNReal := volume (Metric.ball (0 : EuclideanSpace ℝ (Fin m)) 1)
  have hV1_pos : V1 ≠ 0 :=
    (Metric.measure_ball_pos volume (0 : EuclideanSpace ℝ (Fin m)) zero_lt_one).ne'
  have hV1_top : V1 ≠ ⊤ := measure_ball_lt_top.ne
  let F : EuclideanSpace ℝ (Fin m) → ℝ → ENNReal :=
    fun x t => if ‖x‖ < t ∧ t < L then ENNReal.ofReal (2 * t) else 0
  have hF_meas : Measurable (Function.uncurry F) := by
    have hset : MeasurableSet {p : EuclideanSpace ℝ (Fin m) × ℝ | ‖p.1‖ < p.2 ∧ p.2 < L} :=
      (measurableSet_lt (continuous_norm.comp continuous_fst).measurable measurable_snd).inter
        (measurableSet_lt measurable_snd measurable_const)
    exact Measurable.ite hset
      (ENNReal.measurable_ofReal.comp (measurable_const.mul measurable_snd)) measurable_const
  have hswap :
      (∫⁻ x, ∫⁻ t, F x t ∂(volume : Measure ℝ)
          ∂(volume : Measure (EuclideanSpace ℝ (Fin m)))) =
        ∫⁻ t, ∫⁻ x, F x t ∂(volume : Measure (EuclideanSpace ℝ (Fin m)))
          ∂(volume : Measure ℝ) :=
    lintegral_lintegral_swap hF_meas.aemeasurable
  have hlhs_inner : ∀ x : EuclideanSpace ℝ (Fin m),
      (∫⁻ t, F x t ∂volume) =
        B.indicator (fun y => ENNReal.ofReal (L ^ 2 - ‖y‖ ^ 2)) x := by
    intro x
    by_cases hx : x ∈ B
    · have hxlt : ‖x‖ < L := by simpa [B, Metric.mem_ball, dist_zero_right] using hx
      rw [Set.indicator_of_mem hx]
      have hcongr : (fun t : ℝ => F x t) =
          (Set.Ioo ‖x‖ L).indicator (fun t => ENNReal.ofReal (2 * t)) := by
        ext t
        by_cases ht : t ∈ Set.Ioo ‖x‖ L
        · rw [Set.indicator_of_mem ht]
          simp [F, ht.1, ht.2]
        · have hnot : ¬ (‖x‖ < t ∧ t < L) := ht
          simp [F, hnot, Set.indicator_of_notMem ht]
      rw [hcongr, lintegral_indicator measurableSet_Ioo,
        lintegral_Ioo_two_mul (norm_nonneg x) hxlt.le]
    · have hxge : L ≤ ‖x‖ := le_of_not_gt (by simpa [B, Metric.mem_ball, dist_zero_right] using hx)
      rw [Set.indicator_of_notMem hx]
      have hzero : (fun t : ℝ => F x t) = 0 := by
        ext t
        have hnot : ¬ (‖x‖ < t ∧ t < L) := fun ⟨h1, h2⟩ => not_lt_of_ge hxge (h1.trans h2)
        simp [F, hnot]
      simp [hzero]
  have hrhs_inner : ∀ t : ℝ,
      (∫⁻ x, F x t ∂volume) =
        (Set.Ioo (0 : ℝ) L).indicator
          (fun s => ENNReal.ofReal (2 * s ^ (m + 1)) * V1) t := by
    intro t
    by_cases ht : t ∈ Set.Ioo (0 : ℝ) L
    · rw [Set.indicator_of_mem ht]
      have hcongr : (fun x : EuclideanSpace ℝ (Fin m) => F x t) =
          (Metric.ball (0 : EuclideanSpace ℝ (Fin m)) t).indicator
            (fun _ => ENNReal.ofReal (2 * t)) := by
        ext x
        by_cases hx : x ∈ Metric.ball (0 : EuclideanSpace ℝ (Fin m)) t
        · have hxlt : ‖x‖ < t := by simpa [Metric.mem_ball, dist_zero_right] using hx
          simp [F, hxlt, ht.2, Set.indicator_of_mem hx]
        · have hxnot : ¬ ‖x‖ < t := by simpa [Metric.mem_ball, dist_zero_right] using hx
          simp [F, hxnot, Set.indicator_of_notMem hx]
      rw [hcongr, lintegral_indicator measurableSet_ball, setLIntegral_const,
        volume.addHaar_ball_of_pos 0 ht.1, finrank_euclideanSpace_fin,
        ← mul_assoc, ← ENNReal.ofReal_mul (by linarith [ht.1] : 0 ≤ 2 * t)]
      congr 2
      ring
    · rw [Set.indicator_of_notMem ht]
      have hzero : ∀ x : EuclideanSpace ℝ (Fin m), F x t = 0 := by
        intro x
        have hnot : ¬ (‖x‖ < t ∧ t < L) := fun ⟨h1, h2⟩ =>
          ht ⟨lt_of_le_of_lt (norm_nonneg x) h1, h2⟩
        simp [F, hnot]
      simp [hzero]
  simp_rw [hlhs_inner, hrhs_inner] at hswap
  have hmeas_pow : Measurable (fun a : ℝ => ENNReal.ofReal (2 * a ^ (m + 1))) :=
    ENNReal.measurable_ofReal.comp ((continuous_const.mul (continuous_pow (m + 1))).measurable)
  rw [lintegral_indicator measurableSet_ball, lintegral_indicator measurableSet_Ioo,
    lintegral_mul_const V1 hmeas_pow, lintegral_Ioo_two_pow hL] at hswap
  haveI : IsProbabilityMeasure (ballUniformMeasure m L) := ballUniformMeasure_isProb m hL
  have hsub_int : Integrable (fun x : EuclideanSpace ℝ (Fin m) => L ^ 2 - ‖x‖ ^ 2)
      (ballUniformMeasure m L) :=
    integrable_of_continuous_ballUniformMeasure hL
      (continuous_const.sub (continuous_norm.pow 2))
  have hsub_nn : ∀ᵐ x ∂(ballUniformMeasure m L), 0 ≤ L ^ 2 - ‖x‖ ^ 2 := by
    filter_upwards [ae_mem_ball_ballUniformMeasure m L] with x hx
    have hxlt : ‖x‖ < L := by simpa [Metric.mem_ball, dist_zero_right] using hx
    nlinarith [norm_nonneg x]
  have hVB : volume B = ENNReal.ofReal (L ^ m) * V1 := by
    simpa [B, V1, finrank_euclideanSpace_fin] using
      volume.addHaar_ball_of_pos (0 : EuclideanSpace ℝ (Fin m)) hL
  have hVB_pos : volume B ≠ 0 := (Metric.measure_ball_pos volume 0 hL).ne'
  have hVB_top : volume B ≠ ⊤ := measure_ball_lt_top.ne
  have hcond_lint :
      (∫⁻ x, ENNReal.ofReal (L ^ 2 - ‖x‖ ^ 2) ∂(ballUniformMeasure m L)) =
        ENNReal.ofReal (2 * L ^ 2 / ((m : ℝ) + 2)) := by
    unfold ballUniformMeasure ProbabilityTheory.cond
    rw [lintegral_smul_measure, smul_eq_mul, hswap, hVB]
    have hLm_pos : 0 < L ^ m := pow_pos hL m
    have hm2_pos : (0 : ℝ) < (m : ℝ) + 2 := by positivity
    have h_alg : 2 * L ^ (m + 2) / ((m : ℝ) + 2) =
        L ^ m * (2 * L ^ 2 / ((m : ℝ) + 2)) := by
      rw [pow_add]
      ring
    rw [h_alg, ENNReal.ofReal_mul hLm_pos.le, mul_right_comm (ENNReal.ofReal (L ^ m))]
    set A := ENNReal.ofReal (L ^ m) * V1
    have hA_pos : A ≠ 0 := by rwa [← hVB]
    have hA_top : A ≠ ⊤ := by rwa [← hVB]
    rw [← mul_assoc, ENNReal.inv_mul_cancel hA_pos hA_top, one_mul]
  rw [← ofReal_integral_eq_lintegral_ofReal hsub_int hsub_nn] at hcond_lint
  have hint_sub_val :
      ∫ x, (L ^ 2 - ‖x‖ ^ 2) ∂(ballUniformMeasure m L) = 2 * L ^ 2 / ((m : ℝ) + 2) := by
    have h1 := congrArg ENNReal.toReal hcond_lint
    have hnn1 : 0 ≤ ∫ x, (L ^ 2 - ‖x‖ ^ 2) ∂(ballUniformMeasure m L) :=
      integral_nonneg_of_ae hsub_nn
    have hnn2 : 0 ≤ 2 * L ^ 2 / ((m : ℝ) + 2) := by positivity
    rwa [ENNReal.toReal_ofReal hnn1, ENNReal.toReal_ofReal hnn2] at h1
  have hnorm_int : Integrable (fun x : EuclideanSpace ℝ (Fin m) => ‖x‖ ^ 2)
      (ballUniformMeasure m L) :=
    integrable_of_continuous_ballUniformMeasure hL (continuous_norm.pow 2)
  rw [integral_sub (integrable_const _) hnorm_int, integral_const, probReal_univ, one_smul]
    at hint_sub_val
  have hm2_ne : ((m : ℝ) + 2) ≠ 0 := by positivity
  have hgoal_alg : L ^ 2 - 2 * L ^ 2 / ((m : ℝ) + 2) = (m : ℝ) * L ^ 2 / ((m : ℝ) + 2) := by
    field_simp [hm2_ne]
    ring
  linarith

noncomputable def coordSwapIso {m : ℕ} (i k : Fin m) :
    EuclideanSpace ℝ (Fin m) ≃ₗᵢ[ℝ] EuclideanSpace ℝ (Fin m) :=
  LinearIsometryEquiv.piLpCongrLeft 2 ℝ ℝ (Equiv.swap i k)

noncomputable def reflectWhere {m : ℕ} (flip : Fin m → Prop) [DecidablePred flip] :
    EuclideanSpace ℝ (Fin m) ≃ₗᵢ[ℝ] EuclideanSpace ℝ (Fin m) :=
  { toLinearEquiv :=
      LinearEquiv.ofInvolutive
        { toFun := fun x => (WithLp.equiv 2 (Fin m → ℝ)).symm
            (fun k => if flip k then -x k else x k)
          map_add' := fun x y => by
            ext k
            change (if flip k then -(x k + y k) else x k + y k) =
              (if flip k then -x k else x k) + (if flip k then -y k else y k)
            split_ifs <;> ring
          map_smul' := fun c x => by
            ext k
            change (if flip k then -(c * x k) else c * x k) =
              c * (if flip k then -x k else x k)
            split_ifs <;> ring }
        (fun x => by
          ext k
          change (if flip k then -(if flip k then -x k else x k) else (if flip k then -x k else x k)) = x k
          split_ifs <;> ring)
    norm_map' := fun x => by
      change ‖(WithLp.equiv 2 (Fin m → ℝ)).symm
        (fun k => if flip k then -x k else x k)‖ = ‖x‖
      have hsq : ‖(WithLp.equiv 2 (Fin m → ℝ)).symm
          (fun k => if flip k then -x k else x k)‖ ^ 2 = ‖x‖ ^ 2 := by
        rw [EuclideanSpace.norm_sq_eq, EuclideanSpace.norm_sq_eq]
        refine Finset.sum_congr rfl fun k _ => ?_
        change ‖if flip k then -x k else x k‖ ^ 2 = ‖x k‖ ^ 2
        split_ifs <;> simp
      nlinarith [norm_nonneg x,
        norm_nonneg ((WithLp.equiv 2 (Fin m → ℝ)).symm (fun k => if flip k then -x k else x k))] }

noncomputable def coordReflect {m : ℕ} (j : Fin m) :
    EuclideanSpace ℝ (Fin m) ≃ₗᵢ[ℝ] EuclideanSpace ℝ (Fin m) :=
  reflectWhere (fun k => k = j)

@[simp]
lemma coordReflect_apply {m : ℕ} (j : Fin m) (x : EuclideanSpace ℝ (Fin m)) (k : Fin m) :
    coordReflect j x k = if k = j then -x k else x k :=
  rfl

lemma coordReflect_involutive {m : ℕ} (j : Fin m) (x : EuclideanSpace ℝ (Fin m)) :
    coordReflect j (coordReflect j x) = x := by
  ext k
  simp only [coordReflect_apply]
  split_ifs <;> ring

lemma sub_coordReflect_eq {m : ℕ} (j : Fin m) (x : EuclideanSpace ℝ (Fin m)) :
    x - coordReflect j x = (2 * x j) • EuclideanSpace.single j (1 : ℝ) := by
  ext k
  simp only [PiLp.sub_apply, coordReflect_apply, PiLp.smul_apply, smul_eq_mul,
    EuclideanSpace.single_apply]
  split_ifs with hkj
  · subst hkj; ring
  · ring

theorem integral_coord_sq_ballUniformMeasure {m : ℕ} (hm : 1 ≤ m) {L : ℝ} (hL : 0 < L)
    (j : Fin m) :
    ∫ x, (x j) ^ 2 ∂(ballUniformMeasure m L) = L ^ 2 / ((m : ℝ) + 2) := by
  let μ₀ := ballUniformMeasure m L
  haveI : IsProbabilityMeasure μ₀ := ballUniformMeasure_isProb m hL
  have hswap : ∀ k : Fin m, ∫ x, (x k) ^ 2 ∂μ₀ = ∫ x, (x j) ^ 2 ∂μ₀ := by
    intro k
    have hf : Measurable (fun x : EuclideanSpace ℝ (Fin m) => (x j) ^ 2) :=
      ((EuclideanSpace.proj j).continuous.measurable).pow_const 2
    have heq := integral_comp_iso_ballUniformMeasure L (coordSwapIso j k) hf
    have happly : (fun x : EuclideanSpace ℝ (Fin m) => (coordSwapIso j k x j) ^ 2) =
        fun x => (x k) ^ 2 := by
      funext x
      have hx : coordSwapIso j k x j = x k := by
        simp [coordSwapIso, LinearIsometryEquiv.piLpCongrLeft_apply]
      rw [hx]
    rwa [happly] at heq
  have hint : ∀ k : Fin m, Integrable (fun x : EuclideanSpace ℝ (Fin m) => (x k) ^ 2) μ₀ :=
    fun k => integrable_of_continuous_ballUniformMeasure hL
      (((EuclideanSpace.proj k).continuous).pow 2)
  have hsum_eq : (∑ k : Fin m, ∫ x, (x k) ^ 2 ∂μ₀) = (m : ℝ) * ∫ x, (x j) ^ 2 ∂μ₀ := by
    calc (∑ k : Fin m, ∫ x, (x k) ^ 2 ∂μ₀)
        = ∑ _k : Fin m, ∫ x, (x j) ^ 2 ∂μ₀ := Finset.sum_congr rfl fun k _ => hswap k
      _ = (m : ℝ) * ∫ x, (x j) ^ 2 ∂μ₀ := by simp
  have hsum_norm : (∑ k : Fin m, ∫ x, (x k) ^ 2 ∂μ₀) = ∫ x, ‖x‖ ^ 2 ∂μ₀ := by
    rw [← integral_finset_sum Finset.univ (fun k _ => hint k)]
    refine integral_congr_ae (Filter.Eventually.of_forall fun x => ?_)
    dsimp only
    rw [EuclideanSpace.norm_sq_eq]
    refine Finset.sum_congr rfl fun k _ => ?_
    rw [Real.norm_eq_abs, sq_abs]
  have hm_pos : (0 : ℝ) < (m : ℝ) := by exact_mod_cast hm
  have hmul : (m : ℝ) * ∫ x, (x j) ^ 2 ∂μ₀ = (m : ℝ) * L ^ 2 / ((m : ℝ) + 2) := by
    rw [← hsum_eq, hsum_norm, integral_norm_sq_ballUniformMeasure m hL]
  have hmul' : (m : ℝ) * ∫ x, (x j) ^ 2 ∂μ₀ = (m : ℝ) * (L ^ 2 / ((m : ℝ) + 2)) := by
    linarith [show (m : ℝ) * L ^ 2 / ((m : ℝ) + 2) = (m : ℝ) * (L ^ 2 / ((m : ℝ) + 2)) by ring]
  exact mul_left_cancel₀ hm_pos.ne' hmul'

theorem integral_coord_mul_eq_half_sub {m : ℕ} {L : ℝ} (hL : 0 < L)
    (j : Fin m) {g : EuclideanSpace ℝ (Fin m) → ℝ} (hg : Continuous g) :
    ∫ t, t j * g t ∂(ballUniformMeasure m L) =
      (1 / 2 : ℝ) * ∫ t, t j * (g t - g (coordReflect j t)) ∂(ballUniformMeasure m L) := by
  let μ₀ := ballUniformMeasure m L
  let Rj := coordReflect j
  have h_meas : Measurable (fun t : EuclideanSpace ℝ (Fin m) => t j * g t) :=
    ((EuclideanSpace.proj j).continuous.mul hg).measurable
  have h_refl := integral_comp_iso_ballUniformMeasure L Rj h_meas
  have h_comp : (fun t : EuclideanSpace ℝ (Fin m) => (Rj t) j * g (Rj t)) =
      fun t => -(t j * g (Rj t)) := by
    funext t
    simp [Rj]
  rw [h_comp, integral_neg] at h_refl
  have hint1 : Integrable (fun t : EuclideanSpace ℝ (Fin m) => t j * g t) μ₀ :=
    integrable_of_continuous_ballUniformMeasure hL ((EuclideanSpace.proj j).continuous.mul hg)
  have hint2 : Integrable (fun t : EuclideanSpace ℝ (Fin m) => t j * g (Rj t)) μ₀ :=
    integrable_of_continuous_ballUniformMeasure hL
      ((EuclideanSpace.proj j).continuous.mul (hg.comp Rj.continuous))
  have h_sub : (fun t : EuclideanSpace ℝ (Fin m) => t j * (g t - g (Rj t))) =
      fun t => t j * g t - t j * g (Rj t) := by
    funext t; ring
  rw [h_sub, integral_sub hint1 hint2]
  linarith

end UL.Proof_thm_A_9

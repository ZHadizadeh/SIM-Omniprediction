import Mathlib
import UL.Stmt.thm_A_9
import UL.Proof.lem_A_3.H1_SimplexProj
import UL.Proof.lem_A_5.H1_Simplex
import UL.Proof.cor_A_8.H1_SimplexGrad
import UL.Proof.thm_A_9.H1_BallMeasure
set_option autoImplicit false

namespace UL.Proof_thm_A_9

open MeasureTheory

/-! ### Orthonormal isomorphism `ℝ^{K-1} ≃ₗᵢ ZeroSumSubspace K` -/

theorem finrank_zeroSumSubspace (K : ℕ) (hK : 2 ≤ K) :
    Module.finrank ℝ (UL.ZeroSumSubspace K) = K - 1 := by
  unfold UL.ZeroSumSubspace
  set f : EuclideanSpace ℝ (Fin K) →ₗ[ℝ] ℝ := (innerSL ℝ (UL.onesVec K)).toLinearMap
  have hf_surj : Function.Surjective f := by
    intro c
    refine ⟨EuclideanSpace.single ⟨0, by omega⟩ c, ?_⟩
    simp [f, UL.onesVec, EuclideanSpace.inner_single_right]
  have h_rk := LinearMap.finrank_range_add_finrank_ker f
  rw [LinearMap.range_eq_top.mpr hf_surj, finrank_top, Module.finrank_self,
    finrank_euclideanSpace_fin] at h_rk
  omega

noncomputable def zeroSumBasis (K : ℕ) (hK : 2 ≤ K) :
    OrthonormalBasis (Fin (K - 1)) ℝ (UL.ZeroSumSubspace K) :=
  (stdOrthonormalBasis ℝ (UL.ZeroSumSubspace K)).reindex
    (finCongr (finrank_zeroSumSubspace K hK))

noncomputable def zeroSumIso (K : ℕ) (hK : 2 ≤ K) :
    EuclideanSpace ℝ (Fin (K - 1)) ≃ₗᵢ[ℝ] UL.ZeroSumSubspace K :=
  (zeroSumBasis K hK).repr.symm

/-! ### Quadratic entropy `Φ(q) = ‖q - u‖² / (2β)` -/

noncomputable def phiBeta (K : ℕ) (β : ℝ) (q : UL.Simplex K) : ℝ :=
  (1 / (2 * β)) * ‖(q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K‖ ^ 2

private noncomputable def phiBetaExt (K : ℕ) (β : ℝ) (q : EuclideanSpace ℝ (Fin K)) : ℝ :=
  (1 / (2 * β)) * ‖q - UL.uniformVec K‖ ^ 2

private lemma hasFDerivAt_phiBetaExt (K : ℕ) (β : ℝ) (p : EuclideanSpace ℝ (Fin K)) :
    HasFDerivAt (phiBetaExt K β) (innerSL ℝ ((1 / β) • (p - UL.uniformVec K))) p := by
  rw [hasFDerivAt_iff_tendsto]
  have h_tendsto : Filter.Tendsto
      (fun x : EuclideanSpace ℝ (Fin K) => |1 / (2 * β)| * ‖x - p‖)
      (nhds p) (nhds 0) := by
    have hc : Continuous (fun x : EuclideanSpace ℝ (Fin K) => ‖x - p‖) :=
      (continuous_id.sub continuous_const).norm
    have h0 : Filter.Tendsto (fun x : EuclideanSpace ℝ (Fin K) => ‖x - p‖) (nhds p) (nhds 0) := by
      simpa using hc.tendsto p
    simpa using h0.const_mul |1 / (2 * β)|
  refine squeeze_zero (fun _ => by positivity) (fun x => ?_) h_tendsto
  have hid : phiBetaExt K β x - phiBetaExt K β p -
      (innerSL ℝ ((1 / β) • (p - UL.uniformVec K))) (x - p) =
      (1 / (2 * β)) * ‖x - p‖ ^ 2 := by
    dsimp [phiBetaExt]
    have hsplit : x - UL.uniformVec K = (p - UL.uniformVec K) + (x - p) := by abel
    rw [hsplit, norm_add_sq_real, real_inner_smul_left]
    ring
  rw [hid]
  by_cases hxp : x = p
  · subst hxp; simp
  · have hpos : 0 < ‖x - p‖ := norm_pos_iff.mpr (sub_ne_zero.mpr hxp)
    rw [norm_mul, Real.norm_eq_abs, norm_pow, norm_norm]
    exact le_of_eq (by field_simp [hpos.ne'])

noncomputable def faceGradCand (K : ℕ) (β : ℝ) (J : Finset (Fin K))
    (p : EuclideanSpace ℝ (Fin K)) : EuclideanSpace ℝ (Fin K) :=
  (WithLp.equiv 2 (Fin K → ℝ)).symm
    (fun j => if j ∈ J then (1 / β) * (p j - 1 / (J.card : ℝ)) else 0)

@[simp]
lemma faceGradCand_apply (K : ℕ) (β : ℝ) (J : Finset (Fin K))
    (p : EuclideanSpace ℝ (Fin K)) (j : Fin K) :
    faceGradCand K β J p j = if j ∈ J then (1 / β) * (p j - 1 / (J.card : ℝ)) else 0 :=
  rfl

lemma hasFaceGradAt_phiBeta {K : ℕ} (β : ℝ) {J : Finset (Fin K)} (hJ : J.Nonempty)
    {p : EuclideanSpace ℝ (Fin K)} (hp : p ∈ UL.SimplexFace K J) :
    UL.HasFaceGradAt (phiBeta K β) J p (faceGradCand K β J p) := by
  classical
  have hJ_pos : (0 : ℝ) < J.card := by exact_mod_cast hJ.card_pos
  have hp_sum_J : ∑ j ∈ J, p j = 1 := by
    have hsub : ∑ j ∈ J, p j = ∑ j : Fin K, p j :=
      Finset.sum_subset (Finset.subset_univ J) (fun j _ hj => hp.2 j hj)
    rw [hsub, hp.1.2]
  have hg_mem : faceGradCand K β J p ∈ UL.FaceTangentSpace K J := by
    rw [UL.Proof_lem_A_5.mem_faceTangentSpace_iff]
    refine ⟨?_, fun j hj => by simp [hj]⟩
    have hsum_J : ∑ j : Fin K, faceGradCand K β J p j =
        ∑ j ∈ J, (1 / β) * (p j - 1 / (J.card : ℝ)) := by
      calc ∑ j : Fin K, faceGradCand K β J p j
          = ∑ j ∈ J, faceGradCand K β J p j :=
              (Finset.sum_subset (Finset.subset_univ J) (fun j _ hj => by simp [hj])).symm
        _ = ∑ j ∈ J, (1 / β) * (p j - 1 / (J.card : ℝ)) :=
              Finset.sum_congr rfl fun j hj => by simp [hj]
    rw [hsum_J, ← Finset.mul_sum, Finset.sum_sub_distrib, hp_sum_J,
      Finset.sum_const, nsmul_eq_mul, mul_one_div_cancel hJ_pos.ne', sub_self, mul_zero]
  refine ⟨hg_mem, ?_⟩
  have hf_ext : HasFDerivWithinAt (phiBetaExt K β)
      (innerSL ℝ ((1 / β) • (p - UL.uniformVec K))) (UL.SimplexFace K J) p :=
    (hasFDerivAt_phiBetaExt K β p).hasFDerivWithinAt
  rw [hasFDerivWithinAt_iff_tendsto] at hf_ext ⊢
  refine hf_ext.congr' ?_
  filter_upwards [self_mem_nhdsWithin] with x hx
  have hx_sum_J : ∑ j ∈ J, x j = 1 := by
    have hsub : ∑ j ∈ J, x j = ∑ j : Fin K, x j :=
      Finset.sum_subset (Finset.subset_univ J) (fun j _ hj => hx.2 j hj)
    rw [hsub, hx.1.2]
  have hinn : inner ℝ (faceGradCand K β J p) (x - p) =
      inner ℝ ((1 / β) • (p - UL.uniformVec K)) (x - p) := by
    rw [UL.Proof_lem_A_3.inner_eq_sum, UL.Proof_lem_A_3.inner_eq_sum]
    have h1 : ∑ j : Fin K, faceGradCand K β J p j * (x - p) j =
        ∑ j ∈ J, (1 / β) * (p j - 1 / (J.card : ℝ)) * (x - p) j := by
      calc ∑ j : Fin K, faceGradCand K β J p j * (x - p) j
          = ∑ j ∈ J, faceGradCand K β J p j * (x - p) j :=
              (Finset.sum_subset (Finset.subset_univ J)
                (fun j _ hj => by simp [hj, hx.2 j hj, hp.2 j hj])).symm
        _ = ∑ j ∈ J, (1 / β) * (p j - 1 / (J.card : ℝ)) * (x - p) j :=
              Finset.sum_congr rfl fun j hj => by simp [hj]
    have h2 : ∑ j : Fin K, ((1 / β) • (p - UL.uniformVec K)) j * (x - p) j =
        ∑ j ∈ J, (1 / β) * (p j - 1 / (K : ℝ)) * (x - p) j := by
      calc ∑ j : Fin K, ((1 / β) • (p - UL.uniformVec K)) j * (x - p) j
          = ∑ j ∈ J, ((1 / β) • (p - UL.uniformVec K)) j * (x - p) j :=
              (Finset.sum_subset (Finset.subset_univ J)
                (fun j _ hj => by simp [hx.2 j hj, hp.2 j hj])).symm
        _ = ∑ j ∈ J, (1 / β) * (p j - 1 / (K : ℝ)) * (x - p) j :=
              Finset.sum_congr rfl fun j _ => by simp [UL.Proof_lem_A_5.uniformVec_apply]
    rw [h1, h2]
    have hdiff :
        (∑ j ∈ J, (1 / β) * (p j - 1 / (J.card : ℝ)) * (x - p) j) -
          (∑ j ∈ J, (1 / β) * (p j - 1 / (K : ℝ)) * (x - p) j) =
        (1 / β) * (1 / (K : ℝ) - 1 / (J.card : ℝ)) * ∑ j ∈ J, (x - p) j := by
      rw [← Finset.sum_sub_distrib, Finset.mul_sum]
      refine Finset.sum_congr rfl fun _ _ => by ring
    have hsum0 : ∑ j ∈ J, (x - p) j = 0 := by
      simp [Finset.sum_sub_distrib, hx_sum_J, hp_sum_J]
    rw [hsum0, mul_zero] at hdiff
    linarith
  have hex_x : UL.extendSimplex (phiBeta K β) x = phiBetaExt K β x := by
    rw [UL.Proof_lem_A_5.extendSimplex_eq_of_mem (phiBeta K β) hx.1]; rfl
  have hex_p : UL.extendSimplex (phiBeta K β) p = phiBetaExt K β p := by
    rw [UL.Proof_lem_A_5.extendSimplex_eq_of_mem (phiBeta K β) hp.1]; rfl
  simp only [hex_x, hex_p, innerSL_apply_apply, hinn]

theorem phiBeta_mem_entropyFamily {K : ℕ} {β : ℝ} (hβ : 0 < β) :
    phiBeta K β ∈ UL.EntropyFamily K β := by
  have hcont : Continuous (phiBeta K β) :=
    continuous_const.mul (((continuous_subtype_val.sub continuous_const).norm).pow 2)
  refine ⟨hβ, hcont, ?_, ?_⟩
  · intro J hJ p hp
    exact ⟨faceGradCand K β J p, hasFaceGradAt_phiBeta β hJ hp.1⟩
  · refine (convexOn_const 0 (UL.Proof_lem_A_5.convex_simplex K)).congr fun q hq => ?_
    rw [UL.Proof_lem_A_5.extendSimplex_eq_of_mem (phiBeta K β) hq]
    dsimp [phiBeta]
    ring

theorem phiBeta_exists_quad_repr (K : ℕ) (β : ℝ) :
    ∃ (M : EuclideanSpace ℝ (Fin K) →ₗ[ℝ] EuclideanSpace ℝ (Fin K))
      (b : EuclideanSpace ℝ (Fin K)) (c₀ : ℝ),
      ∀ q : UL.Simplex K,
        phiBeta K β q =
          inner ℝ (q : EuclideanSpace ℝ (Fin K)) (M (q : EuclideanSpace ℝ (Fin K))) +
            inner ℝ b (q : EuclideanSpace ℝ (Fin K)) + c₀ := by
  refine ⟨(1 / (2 * β)) • LinearMap.id,
    -(1 / β) • UL.uniformVec K,
    (1 / (2 * β)) * ‖UL.uniformVec K‖ ^ 2, fun q => ?_⟩
  dsimp [phiBeta]
  rw [norm_sub_sq_real, real_inner_smul_right, real_inner_self_eq_norm_sq,
    real_inner_smul_left, real_inner_comm (UL.uniformVec K)]
  ring

lemma faceGrad_phiBeta_posSupport {K : ℕ} (β : ℝ)
    {q : EuclideanSpace ℝ (Fin K)} (hq : q ∈ UL.Simplex K) :
    UL.faceGrad (phiBeta K β) (UL.posSupport q) q =
      faceGradCand K β (UL.posSupport q) q := by
  have hsupp := UL.Proof_lem_A_5.support_nonempty_and_mem_relint hq
  have hJ_eq : (open Classical in Finset.univ.filter (fun j : Fin K => 0 < q j)) =
      UL.posSupport q := rfl
  rw [hJ_eq] at hsupp
  exact UL.Proof_cor_A_8.faceGrad_eq_of_hasFaceGradAt hsupp.1 hsupp.2
    (hasFaceGradAt_phiBeta β hsupp.1 hsupp.2.1)

noncomputable def finiteQuadLoss (K : ℕ) (β : ℝ)
    (q : EuclideanSpace ℝ (Fin K)) (y : Fin K) : ℝ :=
  (1 / (2 * β)) * ‖q - UL.uniformVec K‖ ^ 2 - (1 / β) * (q y - UL.uniformVec K y)

lemma extendedCanonicalLoss_phiBeta_of_pos {K : ℕ} (hK : 2 ≤ K) (β : ℝ)
    {q : EuclideanSpace ℝ (Fin K)} (hq : q ∈ UL.Simplex K)
    (hpos : ∀ j : Fin K, 0 < q j) (y : Fin K) :
    UL.extendedCanonicalLoss (phiBeta K β) q y = ((finiteQuadLoss K β q y : ℝ) : EReal) := by
  have hsupp_univ : UL.posSupport q = Finset.univ := by
    classical
    ext j
    simp [UL.posSupport, hpos j]
  have hy_mem : y ∈ UL.posSupport q := by rw [hsupp_univ]; exact Finset.mem_univ y
  unfold UL.extendedCanonicalLoss
  rw [if_pos hy_mem, faceGrad_phiBeta_posSupport β hq, hsupp_univ,
    UL.Proof_lem_A_5.extendSimplex_eq_of_mem (phiBeta K β) hq]
  congr 1
  have hcand : faceGradCand K β Finset.univ q = (1 / β) • (q - UL.uniformVec K) := by
    ext j
    simp [faceGradCand, UL.Proof_lem_A_5.uniformVec_apply]
  rw [hcand]
  dsimp [phiBeta, finiteQuadLoss]
  have hzero_sum : ∑ j : Fin K, (q - UL.uniformVec K) j = 0 :=
    (UL.Proof_lem_A_5.mem_zeroSumSubspace_iff K _).mp
      (UL.Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex hq
        (UL.Proof_lem_A_5.uniformVec_mem_simplex hK))
  have hu_orth : inner ℝ (q - UL.uniformVec K) (UL.uniformVec K) = 0 := by
    rw [UL.Proof_lem_A_3.inner_eq_sum]
    simp_rw [UL.Proof_lem_A_5.uniformVec_apply]
    rw [← Finset.sum_mul, hzero_sum, zero_mul]
  have hsplit : q - EuclideanSpace.single y (1 : ℝ) =
      (q - UL.uniformVec K) - (EuclideanSpace.single y (1 : ℝ) - UL.uniformVec K) := by abel
  have hey : inner ℝ (q - UL.uniformVec K) (EuclideanSpace.single y (1 : ℝ)) =
      q y - UL.uniformVec K y := by
    rw [real_inner_comm, EuclideanSpace.inner_single_left]
    simp
  rw [hsplit, real_inner_smul_left, inner_sub_right, real_inner_self_eq_norm_sq,
    inner_sub_right, hey, hu_orth, sub_zero]
  ring

noncomputable def lossLowerBound (K : ℕ) (β : ℝ) : ℝ :=
  2 / β + 2 * (K : ℝ) / β

lemma neg_extendedCanonicalLoss_toENNReal_le {K : ℕ} (hK : 2 ≤ K) {β : ℝ} (hβ : 0 < β)
    {q : EuclideanSpace ℝ (Fin K)} (hq : q ∈ UL.Simplex K) (y : Fin K) :
    (-UL.extendedCanonicalLoss (phiBeta K β) q y).toENNReal ≤
      ENNReal.ofReal (lossLowerBound K β) := by
  classical
  unfold UL.extendedCanonicalLoss
  split_ifs with hy
  · rw [← EReal.coe_neg, EReal.real_coe_toENNReal]
    refine ENNReal.ofReal_le_ofReal ?_
    rw [faceGrad_phiBeta_posSupport β hq,
      UL.Proof_lem_A_5.extendSimplex_eq_of_mem (phiBeta K β) hq]
    have hqu : ‖q - UL.uniformVec K‖ ≤ 2 := by
      calc ‖q - UL.uniformVec K‖
          ≤ ‖q‖ + ‖UL.uniformVec K‖ := norm_sub_le _ _
        _ ≤ 1 + 1 := add_le_add (UL.Proof_lem_A_5.norm_le_one_of_mem_simplex hq)
            (UL.Proof_lem_A_5.norm_le_one_of_mem_simplex
              (UL.Proof_lem_A_5.uniformVec_mem_simplex hK))
        _ = 2 := by norm_num
    have hphi_le : phiBeta K β ⟨q, hq⟩ ≤ 2 / β := by
      dsimp [phiBeta]
      have hsq : ‖q - UL.uniformVec K‖ ^ 2 ≤ 4 := by nlinarith [norm_nonneg (q - UL.uniformVec K)]
      have h1 : (1 / (2 * β)) * ‖q - UL.uniformVec K‖ ^ 2 ≤ (1 / (2 * β)) * 4 :=
        mul_le_mul_of_nonneg_left hsq (by positivity)
      linarith [show (1 / (2 * β)) * 4 = 2 / β by field_simp [hβ.ne']; ring]
    have hinn_abs :
        |inner ℝ (faceGradCand K β (UL.posSupport q) q) (q - EuclideanSpace.single y (1 : ℝ))| ≤
          2 * (K : ℝ) / β := by
      rw [UL.Proof_lem_A_3.inner_eq_sum]
      calc |∑ j : Fin K, faceGradCand K β (UL.posSupport q) q j *
              (q - EuclideanSpace.single y (1 : ℝ)) j|
          ≤ ∑ j : Fin K, |faceGradCand K β (UL.posSupport q) q j *
              (q - EuclideanSpace.single y (1 : ℝ)) j| := Finset.abs_sum_le_sum_abs _ _
        _ ≤ ∑ _j : Fin K, (1 / β) * 2 := by
            refine Finset.sum_le_sum fun j _ => ?_
            rw [abs_mul]
            have hg_le : |faceGradCand K β (UL.posSupport q) q j| ≤ 1 / β := by
              rw [faceGradCand_apply]
              split_ifs with hj
              · rw [abs_mul, abs_of_pos (one_div_pos.mpr hβ)]
                have hqj0 : 0 ≤ q j := hq.1 j
                have hqj1 : q j ≤ 1 := UL.Proof_lem_A_3.coord_le_one_of_mem_simplex hq j
                have hcard1 : (1 : ℝ) ≤ ((UL.posSupport q).card : ℝ) := by
                  exact_mod_cast (Finset.card_pos.mpr ⟨j, hj⟩)
                have hinv0 : 0 ≤ 1 / ((UL.posSupport q).card : ℝ) := by positivity
                have hinv1 : 1 / ((UL.posSupport q).card : ℝ) ≤ 1 :=
                  div_le_one_of_le₀ hcard1 (by positivity)
                have hsub1 : |q j - 1 / ((UL.posSupport q).card : ℝ)| ≤ 1 :=
                  abs_le.mpr ⟨by linarith, by linarith⟩
                calc 1 / β * |q j - 1 / ((UL.posSupport q).card : ℝ)|
                    ≤ 1 / β * 1 := mul_le_mul_of_nonneg_left hsub1 (by positivity)
                  _ = 1 / β := mul_one _
              · rw [abs_zero]; positivity
            have hqe_le : |(q - EuclideanSpace.single y (1 : ℝ)) j| ≤ 2 := by
              rw [PiLp.sub_apply]
              have hqj0 : 0 ≤ q j := hq.1 j
              have hqj1 : q j ≤ 1 := UL.Proof_lem_A_3.coord_le_one_of_mem_simplex hq j
              have hej : EuclideanSpace.single y (1 : ℝ) j ∈ Set.Icc (0 : ℝ) 1 := by
                simp only [EuclideanSpace.single_apply]
                split_ifs <;> constructor <;> norm_num
              exact abs_le.mpr ⟨by linarith [hej.2], by linarith [hej.1]⟩
            exact mul_le_mul hg_le hqe_le (abs_nonneg _) (by positivity)
        _ = 2 * (K : ℝ) / β := by
            rw [Finset.sum_const, Finset.card_fin, nsmul_eq_mul]
            ring
    have hinn_lo := (abs_le.mp hinn_abs).1
    unfold lossLowerBound
    linarith
  · simp [lossLowerBound]

/-! ### Feature-label model `(X, Y) ~ P` and conditional Bayes comparator `V₀` -/

noncomputable def radialClamp {m : ℕ} (L : ℝ) (x : EuclideanSpace ℝ (Fin m)) :
    EuclideanSpace ℝ (Fin m) :=
  (L / max L ‖x‖) • x

lemma continuous_radialClamp {m : ℕ} {L : ℝ} (hL : 0 < L) :
    Continuous (radialClamp L : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin m)) := by
  unfold radialClamp
  refine (continuous_const.div (continuous_const.max continuous_norm) ?_).smul continuous_id
  intro x
  exact ne_of_gt (lt_of_lt_of_le hL (le_max_left L ‖x‖))

lemma radialClamp_eq_self {m : ℕ} {L : ℝ} (hL : 0 < L)
    {x : EuclideanSpace ℝ (Fin m)} (hx : ‖x‖ ≤ L) :
    radialClamp L x = x := by
  unfold radialClamp
  rw [max_eq_left hx, div_self hL.ne', one_smul]

lemma norm_radialClamp_le {m : ℕ} {L : ℝ} (hL : 0 < L) (x : EuclideanSpace ℝ (Fin m)) :
    ‖radialClamp L x‖ ≤ L := by
  unfold radialClamp
  by_cases hx : ‖x‖ ≤ L
  · rw [max_eq_left hx, div_self hL.ne', one_smul]
    exact hx
  · push_neg at hx
    have hx_pos : 0 < ‖x‖ := lt_trans hL hx
    rw [max_eq_right hx.le, norm_smul, Real.norm_eq_abs,
      abs_of_pos (div_pos hL hx_pos), div_mul_cancel₀ L hx_pos.ne']

noncomputable def slopeParam (K : ℕ) (R β : ℝ) : ℝ :=
  β * R / Real.sqrt (((K - 1 : ℕ) : ℝ))

lemma slopeParam_pos {K : ℕ} (hK : 2 ≤ K) {R β : ℝ} (hR : 0 < R) (hβ : 0 < β) :
    0 < slopeParam K R β := by
  unfold slopeParam
  have hm : (0 : ℝ) < ((K - 1 : ℕ) : ℝ) := by exact_mod_cast (by omega : 0 < K - 1)
  positivity

noncomputable def etaMap (K : ℕ) (hK : 2 ≤ K) (R β L : ℝ)
    (x : EuclideanSpace ℝ (Fin (K - 1))) : EuclideanSpace ℝ (Fin K) :=
  UL.uniformVec K +
    slopeParam K R β • ((zeroSumIso K hK (radialClamp L x) : UL.ZeroSumSubspace K) :
      EuclideanSpace ℝ (Fin K))

lemma continuous_etaMap (K : ℕ) (hK : 2 ≤ K) (R β : ℝ) {L : ℝ} (hL : 0 < L) :
    Continuous (etaMap K hK R β L) := by
  unfold etaMap
  exact continuous_const.add
    (continuous_const.smul
      (continuous_subtype_val.comp ((zeroSumIso K hK).continuous.comp (continuous_radialClamp hL))))

lemma etaMap_eq_on_closedBall (K : ℕ) (hK : 2 ≤ K) (R β : ℝ) {L : ℝ} (hL : 0 < L)
    {x : EuclideanSpace ℝ (Fin (K - 1))}
    (hx : x ∈ Metric.closedBall (0 : EuclideanSpace ℝ (Fin (K - 1))) L) :
    etaMap K hK R β L x =
      UL.uniformVec K +
        slopeParam K R β • ((zeroSumIso K hK x : UL.ZeroSumSubspace K) :
          EuclideanSpace ℝ (Fin K)) := by
  have hx_norm : ‖x‖ ≤ L := by simpa [Metric.mem_closedBall, dist_zero_right] using hx
  unfold etaMap
  rw [radialClamp_eq_self hL hx_norm]

noncomputable def etaFloor (K : ℕ) (R β L : ℝ) : ℝ :=
  1 / (K : ℝ) - slopeParam K R β * L

lemma etaFloor_pos {K : ℕ} (hK : 2 ≤ K) {R β L : ℝ}
    (hcond : β * R * L / Real.sqrt ((K : ℝ) - 1) < 1 / (K : ℝ)) :
    0 < etaFloor K R β L := by
  unfold etaFloor slopeParam
  have hcast : (((K - 1 : ℕ) : ℝ)) = (K : ℝ) - 1 := by
    rw [Nat.cast_sub (by omega : 1 ≤ K), Nat.cast_one]
  rw [hcast]
  linarith [show (β * R / Real.sqrt ((K : ℝ) - 1)) * L =
    β * R * L / Real.sqrt ((K : ℝ) - 1) by ring]

lemma etaFloor_le_etaMap {K : ℕ} (hK : 2 ≤ K) {R β L : ℝ}
    (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    (x : EuclideanSpace ℝ (Fin (K - 1))) (j : Fin K) :
    etaFloor K R β L ≤ etaMap K hK R β L x j := by
  have hc_pos : 0 < slopeParam K R β := slopeParam_pos hK hR hβ
  set v : EuclideanSpace ℝ (Fin K) :=
    ((zeroSumIso K hK (radialClamp L x) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
  have hv_norm : ‖v‖ ≤ L := by
    change ‖zeroSumIso K hK (radialClamp L x)‖ ≤ L
    rw [(zeroSumIso K hK).norm_map]
    exact norm_radialClamp_le hL x
  have hvj : |v j| ≤ L := (UL.Proof_lem_A_3.coord_abs_le_norm v j).trans hv_norm
  have hcvj : -(slopeParam K R β * L) ≤ slopeParam K R β * v j := by
    have h1 : |slopeParam K R β * v j| ≤ slopeParam K R β * L := by
      rw [abs_mul, abs_of_pos hc_pos]
      exact mul_le_mul_of_nonneg_left hvj hc_pos.le
    exact (abs_le.mp h1).1
  change 1 / (K : ℝ) - slopeParam K R β * L ≤
    UL.uniformVec K j + slopeParam K R β * v j
  rw [UL.Proof_lem_A_5.uniformVec_apply]
  linarith

lemma etaMap_pos {K : ℕ} (hK : 2 ≤ K) {R β L : ℝ}
    (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    (hcond : β * R * L / Real.sqrt ((K : ℝ) - 1) < 1 / (K : ℝ))
    (x : EuclideanSpace ℝ (Fin (K - 1))) (j : Fin K) :
    0 < etaMap K hK R β L x j :=
  lt_of_lt_of_le (etaFloor_pos hK hcond) (etaFloor_le_etaMap hK hR hβ hL x j)

lemma etaMap_mem_simplex {K : ℕ} (hK : 2 ≤ K) {R β L : ℝ}
    (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    (hcond : β * R * L / Real.sqrt ((K : ℝ) - 1) < 1 / (K : ℝ))
    (x : EuclideanSpace ℝ (Fin (K - 1))) :
    etaMap K hK R β L x ∈ UL.Simplex K := by
  refine ⟨fun j => (etaMap_pos hK hR hβ hL hcond x j).le, ?_⟩
  unfold etaMap
  set z := zeroSumIso K hK (radialClamp L x)
  have hz_sum : ∑ j : Fin K, (z : EuclideanSpace ℝ (Fin K)) j = 0 :=
    (UL.Proof_lem_A_5.mem_zeroSumSubspace_iff K _).mp z.2
  simp only [PiLp.add_apply, PiLp.smul_apply, smul_eq_mul, Finset.sum_add_distrib,
    ← Finset.mul_sum, UL.Proof_lem_A_5.sum_uniformVec hK, hz_sum, mul_zero, add_zero]

noncomputable def jointMeasureP (m K : ℕ) (L : ℝ)
    (η : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin K)) :
    Measure (EuclideanSpace ℝ (Fin m) × Fin K) :=
  ∑ y : Fin K,
    ((ballUniformMeasure m L).withDensity (fun x => ENNReal.ofReal (η x y))).map (fun x => (x, y))

lemma measurable_eta_ofReal {m K : ℕ}
    {η : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin K)}
    (hη_cont : Continuous η) (y : Fin K) :
    Measurable (fun x => ENNReal.ofReal (η x y)) :=
  ENNReal.measurable_ofReal.comp (((EuclideanSpace.proj y).continuous.comp hη_cont).measurable)

theorem jointMeasureP_fst_eq (m K : ℕ) (L : ℝ)
    {η : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin K)}
    (hη_cont : Continuous η) (hη_simp : ∀ x, η x ∈ UL.Simplex K) :
    (jointMeasureP m K L η).fst = ballUniformMeasure m L := by
  ext A hA
  rw [Measure.fst_apply hA]
  unfold jointMeasureP
  rw [Measure.coe_finset_sum, Finset.sum_apply]
  have hterm : ∀ y : Fin K,
      (((ballUniformMeasure m L).withDensity (fun x => ENNReal.ofReal (η x y))).map
        (fun x => (x, y))) (Prod.fst ⁻¹' A) =
        ∫⁻ x in A, ENNReal.ofReal (η x y) ∂(ballUniformMeasure m L) := by
    intro y
    have hmap : Measurable (fun x : EuclideanSpace ℝ (Fin m) => (x, y)) :=
      measurable_id.prodMk measurable_const
    rw [Measure.map_apply hmap (measurable_fst hA)]
    have hpre : (fun x : EuclideanSpace ℝ (Fin m) => (x, y)) ⁻¹' (Prod.fst ⁻¹' A) = A := rfl
    rw [hpre, withDensity_apply _ hA]
  simp_rw [hterm]
  rw [← lintegral_finset_sum Finset.univ (fun y _ => measurable_eta_ofReal hη_cont y)]
  have hsum_one : ∀ x : EuclideanSpace ℝ (Fin m),
      ∑ y : Fin K, ENNReal.ofReal (η x y) = 1 := by
    intro x
    rw [← ENNReal.ofReal_sum_of_nonneg (fun y _ => (hη_simp x).1 y), (hη_simp x).2,
      ENNReal.ofReal_one]
  simp_rw [hsum_one]
  exact setLIntegral_one A

theorem jointMeasureP_isProb (m K : ℕ) {L : ℝ} (hL : 0 < L)
    {η : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin K)}
    (hη_cont : Continuous η) (hη_simp : ∀ x, η x ∈ UL.Simplex K) :
    IsProbabilityMeasure (jointMeasureP m K L η) := by
  haveI : IsProbabilityMeasure (ballUniformMeasure m L) := ballUniformMeasure_isProb m hL
  refine ⟨?_⟩
  rw [← Measure.fst_univ, jointMeasureP_fst_eq m K L hη_cont hη_simp]
  exact measure_univ

theorem jointMeasureP_isUniform (m K : ℕ) (L : ℝ)
    {η : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin K)}
    (hη_cont : Continuous η) (hη_simp : ∀ x, η x ∈ UL.Simplex K) :
    MeasureTheory.pdf.IsUniform Prod.fst (Metric.ball (0 : EuclideanSpace ℝ (Fin m)) L)
      (jointMeasureP m K L η) MeasureTheory.volume :=
  jointMeasureP_fst_eq m K L hη_cont hη_simp

theorem jointMeasureP_prod_singleton (m K : ℕ) (L : ℝ)
    (η : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin K))
    {A : Set (EuclideanSpace ℝ (Fin m))} (hA : MeasurableSet A) (y : Fin K) :
    jointMeasureP m K L η (A ×ˢ {y}) =
      ∫⁻ x in A, ENNReal.ofReal (η x y) ∂(ballUniformMeasure m L) := by
  unfold jointMeasureP
  rw [Measure.coe_finset_sum, Finset.sum_apply]
  have hmeas_prod : MeasurableSet (A ×ˢ ({y} : Set (Fin K))) :=
    hA.prod (measurableSet_singleton y)
  rw [Finset.sum_eq_single y]
  · have hmap : Measurable (fun x : EuclideanSpace ℝ (Fin m) => (x, y)) :=
      measurable_id.prodMk measurable_const
    rw [Measure.map_apply hmap hmeas_prod]
    have hpre : (fun x : EuclideanSpace ℝ (Fin m) => (x, y)) ⁻¹' (A ×ˢ {y}) = A := by
      ext x; simp
    rw [hpre, withDensity_apply _ hA]
  · intro y' _ hy'
    have hmap : Measurable (fun x : EuclideanSpace ℝ (Fin m) => (x, y')) :=
      measurable_id.prodMk measurable_const
    rw [Measure.map_apply hmap hmeas_prod]
    have hpre : (fun x : EuclideanSpace ℝ (Fin m) => (x, y')) ⁻¹' (A ×ˢ {y}) = ∅ := by
      ext x; simp [hy']
    rw [hpre, measure_empty]
  · intro hy_abs
    exact False.elim (hy_abs (Finset.mem_univ y))

lemma integral_joint_of_sections {m K : ℕ} {L : ℝ}
    {η : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin K)}
    (hη_cont : Continuous η) (hη_simp : ∀ x, η x ∈ UL.Simplex K)
    {G : EuclideanSpace ℝ (Fin m) × Fin K → ℝ} (hG : Measurable G)
    (hsec : ∀ y : Fin K, Integrable (fun x => η x y * G (x,y)) (ballUniformMeasure m L)) :
    Integrable G (jointMeasureP m K L η) ∧
      ∫ z, G z ∂(jointMeasureP m K L η) =
        ∫ x, (∑ y : Fin K, η x y * G (x, y)) ∂(ballUniformMeasure m L) := by
  let μ₀ := ballUniformMeasure m L
  have h_wd_int : ∀ y : Fin K,
      Integrable (fun x => G (x, y)) (μ₀.withDensity (fun x => ENNReal.ofReal (η x y))) := by
    intro y
    rw [integrable_withDensity_iff (measurable_eta_ofReal hη_cont y)
      (Filter.Eventually.of_forall fun _ => ENNReal.ofReal_lt_top)]
    refine (hsec y).congr (Filter.Eventually.of_forall fun x => ?_)
    dsimp only
    rw [ENNReal.toReal_ofReal ((hη_simp x).1 y), mul_comm]
  have h_map_int : ∀ y : Fin K,
      Integrable G ((μ₀.withDensity (fun x => ENNReal.ofReal (η x y))).map (fun x => (x, y))) := by
    intro y
    have hmap : Measurable (fun x : EuclideanSpace ℝ (Fin m) => (x, y)) :=
      measurable_id.prodMk measurable_const
    exact (integrable_map_measure hG.aestronglyMeasurable hmap.aemeasurable).mpr (h_wd_int y)
  have hG_int : Integrable G (jointMeasureP m K L η) := by
    unfold jointMeasureP
    exact integrable_finset_sum_measure.mpr (fun y _ => h_map_int y)
  refine ⟨hG_int, ?_⟩
  unfold jointMeasureP
  rw [integral_finset_sum_measure (fun y _ => h_map_int y)]
  have hterm : ∀ y : Fin K,
      ∫ z, G z ∂((μ₀.withDensity (fun x => ENNReal.ofReal (η x y))).map (fun x => (x, y))) =
        ∫ x, η x y * G (x, y) ∂μ₀ := by
    intro y
    have hmap : Measurable (fun x : EuclideanSpace ℝ (Fin m) => (x, y)) :=
      measurable_id.prodMk measurable_const
    rw [integral_map hmap.aemeasurable hG.aestronglyMeasurable,
      integral_withDensity_eq_integral_toReal_smul (measurable_eta_ofReal hη_cont y)
        (Filter.Eventually.of_forall fun _ => ENNReal.ofReal_lt_top)]
    refine integral_congr_ae (Filter.Eventually.of_forall fun x => ?_)
    dsimp only [smul_eq_mul]
    rw [ENNReal.toReal_ofReal ((hη_simp x).1 y)]
  simp_rw [hterm]
  rw [← integral_finset_sum Finset.univ (fun y _ => hsec y)]

lemma integrable_and_integral_jointMeasureP_of_continuous {m K : ℕ} {L : ℝ} (hL : 0 < L)
    {η : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin K)}
    (hη_cont : Continuous η) (hη_simp : ∀ x, η x ∈ UL.Simplex K)
    {G : EuclideanSpace ℝ (Fin m) × Fin K → ℝ} (hG_cont : Continuous G) :
    Integrable G (jointMeasureP m K L η) ∧
      ∫ z, G z ∂(jointMeasureP m K L η) =
        ∫ x, (∑ y : Fin K, η x y * G (x, y)) ∂(ballUniformMeasure m L) := by
  let μ₀ := ballUniformMeasure m L
  have h_comp_int : ∀ y : Fin K, Integrable (fun x => η x y * G (x, y)) μ₀ := by
    intro y
    refine integrable_of_continuous_ballUniformMeasure hL ?_
    exact ((EuclideanSpace.proj y).continuous.comp hη_cont).mul
      (hG_cont.comp (continuous_id.prodMk continuous_const))
  exact integral_joint_of_sections hη_cont hη_simp hG_cont.measurable h_comp_int

/-! ### `EReal` expectation helper -/

lemma erealExpectation_coe_of_integrable {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) {f : Ω → ℝ} (hf : Integrable f μ) :
    UL.erealExpectation μ (fun ω => (f ω : EReal)) = ((∫ ω, f ω ∂μ : ℝ) : EReal) := by
  have hlt : ∀ {g : Ω → ℝ}, Integrable g μ → (∫⁻ ω, ENNReal.ofReal (g ω) ∂μ) ≠ ⊤ := by
    intro g hg
    refine ne_of_lt (lt_of_le_of_lt ?_ hg.hasFiniteIntegral)
    refine lintegral_mono fun ω => ?_
    calc ENNReal.ofReal (g ω)
        ≤ ENNReal.ofReal ‖g ω‖ := ENNReal.ofReal_le_ofReal (Real.le_norm_self (g ω))
      _ = ‖g ω‖ₑ := ofReal_norm_eq_enorm (g ω)
  have h_enn : ∀ {a : ENNReal}, a ≠ ⊤ → a.toEReal = ((a.toReal : ℝ) : EReal) := by
    intro a ha
    lift a to NNReal using ha
    rfl
  unfold UL.erealExpectation
  have hc1 : ∀ ω, ((f ω : EReal)).toENNReal = ENNReal.ofReal (f ω) := fun _ => by simp
  have hc2 : ∀ ω, (-(f ω : EReal)).toENNReal = ENNReal.ofReal (-f ω) := fun ω => by
    rw [← EReal.coe_neg]; simp
  simp_rw [hc1, hc2]
  have hpos_ne : (∫⁻ ω, ENNReal.ofReal (f ω) ∂μ) ≠ ⊤ := hlt hf
  have hneg_ne : (∫⁻ ω, ENNReal.ofReal (-f ω) ∂μ) ≠ ⊤ := hlt hf.neg
  rw [h_enn hpos_ne, h_enn hneg_ne, ← EReal.coe_sub,
    integral_eq_lintegral_pos_part_sub_lintegral_neg_part hf]

/-! ### Comparator `V₀`, benchmark `bench`, and fundamental regret bound -/

noncomputable def compV0 (K : ℕ) (hK : 2 ≤ K) (R : ℝ) :
    EuclideanSpace ℝ (Fin (K - 1)) →ₗ[ℝ] UL.ZeroSumSubspace K :=
  (R / Real.sqrt (((K - 1 : ℕ) : ℝ))) • (zeroSumIso K hK).toLinearIsometry.toLinearMap

lemma compV0_mem_comparatorBall (K : ℕ) (hK : 2 ≤ K) {R : ℝ} (hR : 0 < R) :
    compV0 K hK R ∈ UL.ComparatorBall (K - 1) K R := by
  unfold UL.ComparatorBall UL.frobeniusNorm compV0
  rw [Set.mem_setOf_eq]
  have hm : (0 : ℝ) < ((K - 1 : ℕ) : ℝ) := by exact_mod_cast (by omega : 0 < K - 1)
  have hscale_pos : 0 < R / Real.sqrt (((K - 1 : ℕ) : ℝ)) := by positivity
  have hterm : ∀ i : Fin (K - 1),
      ‖((R / Real.sqrt (((K - 1 : ℕ) : ℝ))) • (zeroSumIso K hK).toLinearIsometry.toLinearMap)
        (EuclideanSpace.single i (1 : ℝ))‖ ^ 2 =
        (R / Real.sqrt (((K - 1 : ℕ) : ℝ))) ^ 2 := by
    intro i
    rw [LinearMap.smul_apply, norm_smul, Real.norm_eq_abs, abs_of_pos hscale_pos]
    change (R / Real.sqrt (((K - 1 : ℕ) : ℝ)) *
      ‖zeroSumIso K hK (EuclideanSpace.single i (1 : ℝ))‖) ^ 2 = _
    rw [(zeroSumIso K hK).norm_map, EuclideanSpace.norm_single, norm_one, mul_one]
  simp_rw [hterm]
  rw [Finset.sum_const, Finset.card_fin, nsmul_eq_mul, div_pow, Real.sq_sqrt hm.le,
    mul_div_cancel₀ _ hm.ne', Real.sqrt_sq hR.le]

lemma matchingPotential_phiBeta_bddAbove {K : ℕ} {β : ℝ} (hβ : 0 < β)
    (a : EuclideanSpace ℝ (Fin K)) :
    BddAbove (Set.range (fun q : UL.Simplex K =>
      inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) a - phiBeta K β q)) := by
  refine ⟨2 * ‖a‖, Set.forall_mem_range.mpr fun q => ?_⟩
  have hqu : ‖(q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K‖ ≤ 2 := by
    calc ‖(q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K‖
        ≤ ‖(q : EuclideanSpace ℝ (Fin K))‖ + ‖UL.uniformVec K‖ := norm_sub_le _ _
      _ ≤ 1 + 1 := by
          refine add_le_add (UL.Proof_lem_A_5.norm_le_one_of_mem_simplex q.2) ?_
          by_cases hK0 : K = 0
          · subst hK0; exact False.elim (by have h := q.2.2; simp at h)
          · by_cases hK1 : K = 1
            · subst hK1
              rw [EuclideanSpace.norm_eq]
              simp [UL.Proof_lem_A_5.uniformVec_apply]
            · exact UL.Proof_lem_A_5.norm_le_one_of_mem_simplex
                (UL.Proof_lem_A_5.uniformVec_mem_simplex (by omega))
      _ = 2 := by norm_num
  have hinn : inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) a ≤ 2 * ‖a‖ :=
    (real_inner_le_norm _ _).trans (mul_le_mul_of_nonneg_right hqu (norm_nonneg a))
  have hphi_nn : 0 ≤ phiBeta K β q := by dsimp [phiBeta]; positivity
  linarith

lemma continuous_matchingLoss_phiBeta {K : ℕ} (hK : 2 ≤ K) {β : ℝ} (hβ : 0 < β)
    (y : Fin K) :
    Continuous (fun a : EuclideanSpace ℝ (Fin K) => UL.matchingLoss (phiBeta K β) a y) := by
  haveI : Nonempty (UL.Simplex K) := ⟨⟨UL.uniformVec K, UL.Proof_lem_A_5.uniformVec_mem_simplex hK⟩⟩
  have hpot_le : ∀ b₁ b₂ : EuclideanSpace ℝ (Fin K),
      UL.matchingPotential (phiBeta K β) b₁ - UL.matchingPotential (phiBeta K β) b₂ ≤
        2 * ‖b₁ - b₂‖ := by
    intro b₁ b₂
    have h_each : ∀ q : UL.Simplex K,
        inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) b₁ - phiBeta K β q ≤
          UL.matchingPotential (phiBeta K β) b₂ + 2 * ‖b₁ - b₂‖ := by
      intro q
      have hqu : ‖(q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K‖ ≤ 2 := by
        calc ‖(q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K‖
            ≤ ‖(q : EuclideanSpace ℝ (Fin K))‖ + ‖UL.uniformVec K‖ := norm_sub_le _ _
          _ ≤ 1 + 1 := add_le_add (UL.Proof_lem_A_5.norm_le_one_of_mem_simplex q.2)
              (UL.Proof_lem_A_5.norm_le_one_of_mem_simplex
                (UL.Proof_lem_A_5.uniformVec_mem_simplex hK))
          _ = 2 := by norm_num
      have hdiff :
          (inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) b₁ - phiBeta K β q) -
            (inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) b₂ - phiBeta K β q) ≤
              2 * ‖b₁ - b₂‖ := by
        have hid :
            (inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) b₁ - phiBeta K β q) -
              (inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) b₂ - phiBeta K β q) =
                inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) (b₁ - b₂) := by
          rw [inner_sub_right]; ring
        rw [hid]
        exact (real_inner_le_norm _ _).trans (mul_le_mul_of_nonneg_right hqu (norm_nonneg _))
      have hsup2 :
          inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) b₂ - phiBeta K β q ≤
            UL.matchingPotential (phiBeta K β) b₂ :=
        le_ciSup (matchingPotential_phiBeta_bddAbove hβ b₂) q
      linarith
    have hsup1 : UL.matchingPotential (phiBeta K β) b₁ ≤
        UL.matchingPotential (phiBeta K β) b₂ + 2 * ‖b₁ - b₂‖ :=
      ciSup_le h_each
    linarith
  rw [Metric.continuous_iff]
  intro a ε hε
  refine ⟨ε / 4, by positivity, fun b hab => ?_⟩
  rw [Real.dist_eq]
  rw [dist_eq_norm] at hab
  have hpot_abs : |UL.matchingPotential (phiBeta K β) b - UL.matchingPotential (phiBeta K β) a| ≤
      2 * ‖b - a‖ :=
    abs_sub_le_iff.mpr ⟨hpot_le b a, by simpa [norm_sub_rev] using hpot_le a b⟩
  have hay_abs : |b y - a y| ≤ ‖b - a‖ := UL.Proof_lem_A_3.coord_abs_le_norm (b - a) y
  unfold UL.matchingLoss
  have htri : |(UL.matchingPotential (phiBeta K β) b - b y) -
      (UL.matchingPotential (phiBeta K β) a - a y)| ≤ 3 * ‖b - a‖ := by
    calc |(UL.matchingPotential (phiBeta K β) b - b y) -
            (UL.matchingPotential (phiBeta K β) a - a y)|
        = |(UL.matchingPotential (phiBeta K β) b - UL.matchingPotential (phiBeta K β) a) -
            (b y - a y)| := by ring_nf
      _ ≤ |UL.matchingPotential (phiBeta K β) b - UL.matchingPotential (phiBeta K β) a| +
            |b y - a y| := abs_sub _ _
      _ ≤ 2 * ‖b - a‖ + ‖b - a‖ := add_le_add hpot_abs hay_abs
      _ = 3 * ‖b - a‖ := by ring
  linarith [norm_nonneg (b - a)]

lemma sum_eta_matchingLoss_ge {K : ℕ} (_hK : 2 ≤ K) {β : ℝ} (hβ : 0 < β)
    {ηx : EuclideanSpace ℝ (Fin K)} (hηx : ηx ∈ UL.Simplex K)
    (a : UL.ZeroSumSubspace K) :
    -phiBeta K β ⟨ηx, hηx⟩ ≤
      ∑ y : Fin K, ηx y * UL.matchingLoss (phiBeta K β) (a : EuclideanSpace ℝ (Fin K)) y := by
  have hsum_eq :
      ∑ y : Fin K, ηx y * UL.matchingLoss (phiBeta K β) (a : EuclideanSpace ℝ (Fin K)) y =
        UL.matchingPotential (phiBeta K β) (a : EuclideanSpace ℝ (Fin K)) -
          inner ℝ (ηx - UL.uniformVec K) (a : EuclideanSpace ℝ (Fin K)) := by
    unfold UL.matchingLoss
    have h1 : ∑ y : Fin K, ηx y *
        (UL.matchingPotential (phiBeta K β) (a : EuclideanSpace ℝ (Fin K)) -
          (a : EuclideanSpace ℝ (Fin K)) y) =
        (∑ y : Fin K, ηx y) * UL.matchingPotential (phiBeta K β) (a : EuclideanSpace ℝ (Fin K)) -
          ∑ y : Fin K, ηx y * (a : EuclideanSpace ℝ (Fin K)) y := by
      simp_rw [mul_sub, Finset.sum_sub_distrib, ← Finset.sum_mul]
    rw [h1, hηx.2, one_mul, ← UL.Proof_lem_A_3.inner_eq_sum]
    have hu_orth : inner ℝ (UL.uniformVec K) (a : EuclideanSpace ℝ (Fin K)) = 0 := by
      rw [UL.Proof_lem_A_3.inner_eq_sum]
      simp_rw [UL.Proof_lem_A_5.uniformVec_apply]
      rw [← Finset.mul_sum, (UL.Proof_lem_A_5.mem_zeroSumSubspace_iff K _).mp a.2, mul_zero]
    rw [inner_sub_left, hu_orth, sub_zero]
  rw [hsum_eq]
  have hsup :
      inner ℝ (ηx - UL.uniformVec K) (a : EuclideanSpace ℝ (Fin K)) -
        phiBeta K β ⟨ηx, hηx⟩ ≤
      UL.matchingPotential (phiBeta K β) (a : EuclideanSpace ℝ (Fin K)) :=
    le_ciSup (matchingPotential_phiBeta_bddAbove hβ (a : EuclideanSpace ℝ (Fin K))) ⟨ηx, hηx⟩
  linarith

private lemma sum_eta_matchingLoss_compV0_eq {K : ℕ} (hK : 2 ≤ K) {R β L : ℝ}
    (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    (hcond : β * R * L / Real.sqrt ((K : ℝ) - 1) < 1 / (K : ℝ))
    {x : EuclideanSpace ℝ (Fin (K - 1))}
    (hx : x ∈ Metric.ball (0 : EuclideanSpace ℝ (Fin (K - 1))) L) :
    let ηx := etaMap K hK R β L x
    ∑ y : Fin K, ηx y * UL.matchingLoss (phiBeta K β) (compV0 K hK R x) y =
      -phiBeta K β ⟨ηx, etaMap_mem_simplex hK hR hβ hL hcond x⟩ := by
  intro ηx
  have hηx_mem : ηx ∈ UL.Simplex K := etaMap_mem_simplex hK hR hβ hL hcond x
  have hx_closed : x ∈ Metric.closedBall (0 : EuclideanSpace ℝ (Fin (K - 1))) L :=
    Metric.ball_subset_closedBall hx
  have hV0_eq : (compV0 K hK R x : EuclideanSpace ℝ (Fin K)) =
      (1 / β) • (ηx - UL.uniformVec K) := by
    dsimp [ηx]
    rw [etaMap_eq_on_closedBall K hK R β hL hx_closed]
    unfold compV0 slopeParam
    ext j
    change (R / Real.sqrt (((K - 1 : ℕ) : ℝ))) *
        ((zeroSumIso K hK x : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) j =
      (1 / β) * ((UL.uniformVec K j +
        (β * R / Real.sqrt (((K - 1 : ℕ) : ℝ))) *
          ((zeroSumIso K hK x : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) j) -
        UL.uniformVec K j)
    field_simp [hβ.ne']
    ring
  haveI : Nonempty (UL.Simplex K) := ⟨⟨ηx, hηx_mem⟩⟩
  have hpot : UL.matchingPotential (phiBeta K β) (compV0 K hK R x) =
      phiBeta K β ⟨ηx, hηx_mem⟩ := by
    rw [hV0_eq]
    have h_id : ∀ q : UL.Simplex K,
        inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K)
            ((1 / β) • (ηx - UL.uniformVec K)) - phiBeta K β q =
          phiBeta K β ⟨ηx, hηx_mem⟩ -
            (1 / (2 * β)) * ‖(q : EuclideanSpace ℝ (Fin K)) - ηx‖ ^ 2 := by
      intro q
      dsimp [phiBeta]
      have hsub : (q : EuclideanSpace ℝ (Fin K)) - ηx =
          ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) - (ηx - UL.uniformVec K) := by abel
      rw [hsub, norm_sub_sq_real ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K)
        (ηx - UL.uniformVec K), real_inner_smul_right]
      field_simp [hβ.ne']
      ring
    have h_le : ∀ q : UL.Simplex K,
        inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K)
            ((1 / β) • (ηx - UL.uniformVec K)) - phiBeta K β q ≤
          phiBeta K β ⟨ηx, hηx_mem⟩ := by
      intro q
      rw [h_id q]
      have hnn : 0 ≤ (1 / (2 * β)) * ‖(q : EuclideanSpace ℝ (Fin K)) - ηx‖ ^ 2 := by positivity
      linarith
    unfold UL.matchingPotential
    refine le_antisymm (ciSup_le h_le) ?_
    have h_self :
        inner ℝ (((⟨ηx, hηx_mem⟩ : UL.Simplex K) : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K)
            ((1 / β) • (ηx - UL.uniformVec K)) - phiBeta K β ⟨ηx, hηx_mem⟩ =
          phiBeta K β ⟨ηx, hηx_mem⟩ := by
      rw [h_id ⟨ηx, hηx_mem⟩]
      simp
    rw [← h_self]
    exact le_ciSup (matchingPotential_phiBeta_bddAbove hβ _) ⟨ηx, hηx_mem⟩
  have hsum_eq :
      ∑ y : Fin K, ηx y * UL.matchingLoss (phiBeta K β) (compV0 K hK R x) y =
        UL.matchingPotential (phiBeta K β) (compV0 K hK R x) -
          inner ℝ (ηx - UL.uniformVec K) (compV0 K hK R x) := by
    unfold UL.matchingLoss
    have h1 : ∑ y : Fin K, ηx y *
        (UL.matchingPotential (phiBeta K β) (compV0 K hK R x) -
          (compV0 K hK R x : EuclideanSpace ℝ (Fin K)) y) =
        (∑ y : Fin K, ηx y) * UL.matchingPotential (phiBeta K β) (compV0 K hK R x) -
          ∑ y : Fin K, ηx y * (compV0 K hK R x : EuclideanSpace ℝ (Fin K)) y := by
      simp_rw [mul_sub, Finset.sum_sub_distrib, ← Finset.sum_mul]
    rw [h1, hηx_mem.2, one_mul, ← UL.Proof_lem_A_3.inner_eq_sum]
    have hu_orth : inner ℝ (UL.uniformVec K) (compV0 K hK R x : EuclideanSpace ℝ (Fin K)) = 0 := by
      rw [UL.Proof_lem_A_3.inner_eq_sum]
      simp_rw [UL.Proof_lem_A_5.uniformVec_apply]
      rw [← Finset.mul_sum, (UL.Proof_lem_A_5.mem_zeroSumSubspace_iff K _).mp (compV0 K hK R x).2,
        mul_zero]
    rw [inner_sub_left, hu_orth, sub_zero]
  rw [hsum_eq, hpot, hV0_eq, real_inner_smul_right, real_inner_self_eq_norm_sq]
  dsimp [phiBeta]
  field_simp [hβ.ne']
  ring

noncomputable def benchReal (K : ℕ) (hK : 2 ≤ K) (R β L : ℝ)
    (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    (hcond : β * R * L / Real.sqrt ((K : ℝ) - 1) < 1 / (K : ℝ)) : ℝ :=
  ∫ x, (-phiBeta K β ⟨etaMap K hK R β L x, etaMap_mem_simplex hK hR hβ hL hcond x⟩)
    ∂(ballUniformMeasure (K - 1) L)

theorem bench_eq_coe (K : ℕ) (hK : 2 ≤ K) {R β L : ℝ}
    (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    (hcond : β * R * L / Real.sqrt ((K : ℝ) - 1) < 1 / (K : ℝ)) :
    let m := K - 1
    let P := jointMeasureP m K L (etaMap K hK R β L)
    (⨅ V ∈ UL.ComparatorBall m K R,
      UL.expectedMatchingLoss P Prod.fst Prod.snd (phiBeta K β) V) =
      ((benchReal K hK R β L hR hβ hL hcond : ℝ) : EReal) := by
  intro m P
  let η := etaMap K hK R β L
  have hη_cont : Continuous η := continuous_etaMap K hK R β hL
  have hη_simp : ∀ x, η x ∈ UL.Simplex K := etaMap_mem_simplex hK hR hβ hL hcond
  let μ₀ := ballUniformMeasure m L
  have h_eml : ∀ V : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] UL.ZeroSumSubspace K,
      UL.expectedMatchingLoss P Prod.fst Prod.snd (phiBeta K β) V =
        ((∫ x, (∑ y : Fin K, η x y * UL.matchingLoss (phiBeta K β) (V x) y) ∂μ₀ : ℝ) : EReal) := by
    intro V
    have hV_cont : Continuous (fun x : EuclideanSpace ℝ (Fin m) => (V x : EuclideanSpace ℝ (Fin K))) :=
      continuous_subtype_val.comp V.continuous_of_finiteDimensional
    have hG_cont : Continuous (fun z : EuclideanSpace ℝ (Fin m) × Fin K =>
        UL.matchingLoss (phiBeta K β) (V z.1) z.2) := by
      rw [continuous_prod_of_discrete_right]
      exact fun y => (continuous_matchingLoss_phiBeta hK hβ y).comp hV_cont
    obtain ⟨hG_int, hG_eq⟩ :=
      integrable_and_integral_jointMeasureP_of_continuous hL hη_cont hη_simp hG_cont
    unfold UL.expectedMatchingLoss
    rw [erealExpectation_coe_of_integrable P hG_int, hG_eq]
  have hneg_cont : Continuous (fun x : EuclideanSpace ℝ (Fin m) =>
      -phiBeta K β ⟨η x, hη_simp x⟩) := by
    have h_eq : (fun x : EuclideanSpace ℝ (Fin m) => -phiBeta K β ⟨η x, hη_simp x⟩) =
        fun x => -((1 / (2 * β)) * ‖η x - UL.uniformVec K‖ ^ 2) := rfl
    rw [h_eq]
    exact (continuous_const.mul (((hη_cont.sub continuous_const).norm).pow 2)).neg
  have hneg_int : Integrable (fun x => -phiBeta K β ⟨η x, hη_simp x⟩) μ₀ :=
    integrable_of_continuous_ballUniformMeasure hL hneg_cont
  have hV_ge : ∀ V : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] UL.ZeroSumSubspace K,
      ((benchReal K hK R β L hR hβ hL hcond : ℝ) : EReal) ≤
        UL.expectedMatchingLoss P Prod.fst Prod.snd (phiBeta K β) V := by
    intro V
    rw [h_eml V, EReal.coe_le_coe_iff]
    unfold benchReal
    have hsum_cont : Continuous (fun x : EuclideanSpace ℝ (Fin m) =>
        ∑ y : Fin K, η x y * UL.matchingLoss (phiBeta K β) (V x) y) := by
      have hV_cont : Continuous (fun x : EuclideanSpace ℝ (Fin m) =>
          (V x : EuclideanSpace ℝ (Fin K))) :=
        continuous_subtype_val.comp V.continuous_of_finiteDimensional
      exact continuous_finset_sum Finset.univ fun y _ =>
        ((EuclideanSpace.proj y).continuous.comp hη_cont).mul
          ((continuous_matchingLoss_phiBeta hK hβ y).comp hV_cont)
    exact integral_mono hneg_int (integrable_of_continuous_ballUniformMeasure hL hsum_cont)
      (fun x => sum_eta_matchingLoss_ge hK hβ (hη_simp x) (V x))
  have hV0_eq : UL.expectedMatchingLoss P Prod.fst Prod.snd (phiBeta K β) (compV0 K hK R) =
      ((benchReal K hK R β L hR hβ hL hcond : ℝ) : EReal) := by
    rw [h_eml (compV0 K hK R)]
    congr 1
    unfold benchReal
    refine integral_congr_ae ?_
    filter_upwards [ae_mem_ball_ballUniformMeasure m L] with x hx
    exact sum_eta_matchingLoss_compV0_eq hK hR hβ hL hcond hx
  refine le_antisymm ?_ (le_iInf₂ fun V _ => hV_ge V)
  rw [← hV0_eq]
  exact iInf₂_le (compV0 K hK R) (compV0_mem_comparatorBall K hK hR)

lemma sum_eta_finiteQuadLoss_eq {K : ℕ} (hK : 2 ≤ K) {β : ℝ} (hβ : 0 < β)
    {q ηx : EuclideanSpace ℝ (Fin K)} (hq : q ∈ UL.Simplex K) (hηx : ηx ∈ UL.Simplex K) :
    ∑ y : Fin K, ηx y * finiteQuadLoss K β q y =
      -phiBeta K β ⟨ηx, hηx⟩ + (1 / (2 * β)) * ‖q - ηx‖ ^ 2 := by
  unfold finiteQuadLoss phiBeta
  have h1 : ∑ y : Fin K, ηx y *
      ((1 / (2 * β)) * ‖q - UL.uniformVec K‖ ^ 2 - (1 / β) * (q y - UL.uniformVec K y)) =
      (∑ y : Fin K, ηx y) * ((1 / (2 * β)) * ‖q - UL.uniformVec K‖ ^ 2) -
        (1 / β) * ∑ y : Fin K, ηx y * (q - UL.uniformVec K) y := by
    calc ∑ y : Fin K, ηx y *
          ((1 / (2 * β)) * ‖q - UL.uniformVec K‖ ^ 2 - (1 / β) * (q y - UL.uniformVec K y))
        = ∑ y : Fin K, (ηx y * ((1 / (2 * β)) * ‖q - UL.uniformVec K‖ ^ 2) -
            (1 / β) * (ηx y * (q - UL.uniformVec K) y)) := by
          refine Finset.sum_congr rfl fun _ _ => ?_
          rw [PiLp.sub_apply]; ring
      _ = (∑ y : Fin K, ηx y * ((1 / (2 * β)) * ‖q - UL.uniformVec K‖ ^ 2)) -
            ∑ y : Fin K, (1 / β) * (ηx y * (q - UL.uniformVec K) y) := Finset.sum_sub_distrib _ _
      _ = (∑ y : Fin K, ηx y) * ((1 / (2 * β)) * ‖q - UL.uniformVec K‖ ^ 2) -
            (1 / β) * ∑ y : Fin K, ηx y * (q - UL.uniformVec K) y := by
          rw [← Finset.sum_mul, ← Finset.mul_sum]
  rw [h1, hηx.2, one_mul, ← UL.Proof_lem_A_3.inner_eq_sum]
  have hu_orth : inner ℝ (UL.uniformVec K) (q - UL.uniformVec K) = 0 := by
    rw [UL.Proof_lem_A_3.inner_eq_sum]
    simp_rw [UL.Proof_lem_A_5.uniformVec_apply]
    rw [← Finset.mul_sum,
      (UL.Proof_lem_A_5.mem_zeroSumSubspace_iff K _).mp
        (UL.Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex hq
          (UL.Proof_lem_A_5.uniformVec_mem_simplex hK)), mul_zero]
  have hinn : inner ℝ ηx (q - UL.uniformVec K) =
      inner ℝ (ηx - UL.uniformVec K) (q - UL.uniformVec K) := by
    rw [inner_sub_left, hu_orth, sub_zero]
  have hsub : q - ηx = (q - UL.uniformVec K) - (ηx - UL.uniformVec K) := by abel
  rw [hinn, hsub, norm_sub_sq_real (q - UL.uniformVec K) (ηx - UL.uniformVec K),
    real_inner_comm (q - UL.uniformVec K) (ηx - UL.uniformVec K)]
  field_simp [hβ.ne']
  ring

theorem regret_eq_l2_of_ae_pos {K : ℕ} (hK : 2 ≤ K) {R β L : ℝ}
    (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    (hcond : β * R * L / Real.sqrt ((K : ℝ) - 1) < 1 / (K : ℝ))
    {p : EuclideanSpace ℝ (Fin (K - 1)) → UL.Simplex K} (hp_cont : Continuous p)
    (h_ae_pos : ∀ᵐ x ∂(ballUniformMeasure (K - 1) L),
      ∀ y : Fin K, 0 < (p x : EuclideanSpace ℝ (Fin K)) y) :
    let m := K - 1
    let P := jointMeasureP m K L (etaMap K hK R β L)
    let bench := ⨅ V ∈ UL.ComparatorBall m K R,
      UL.expectedMatchingLoss P Prod.fst Prod.snd (phiBeta K β) V
    UL.expectedCanonicalLoss P Prod.fst Prod.snd (phiBeta K β) p - bench =
      (((1 / (2 * β)) * ∫ x, ‖(p x : EuclideanSpace ℝ (Fin K)) - etaMap K hK R β L x‖ ^ 2
        ∂(ballUniformMeasure m L) : ℝ) : EReal) := by
  intro m P bench
  let η := etaMap K hK R β L
  let μ₀ := ballUniformMeasure m L
  have hη_cont : Continuous η := continuous_etaMap K hK R β hL
  have hη_simp : ∀ x, η x ∈ UL.Simplex K := etaMap_mem_simplex hK hR hβ hL hcond
  have hq_cont : Continuous (fun x => (p x : EuclideanSpace ℝ (Fin K))) :=
    continuous_subtype_val.comp hp_cont
  have h_ae_P : ∀ᵐ z ∂P, ∀ y : Fin K, 0 < (p z.1 : EuclideanSpace ℝ (Fin K)) y := by
    have hP_fst : P.fst = ballUniformMeasure (K - 1) L :=
      jointMeasureP_fst_eq m K L hη_cont hη_simp
    rw [← hP_fst] at h_ae_pos
    exact ae_of_ae_map measurable_fst.aemeasurable h_ae_pos
  let F_fin : EuclideanSpace ℝ (Fin m) × Fin K → ℝ :=
    fun z => finiteQuadLoss K β (p z.1 : EuclideanSpace ℝ (Fin K)) z.2
  have hF_cont : Continuous F_fin := by
    rw [continuous_prod_of_discrete_right]
    intro y
    dsimp only [F_fin, finiteQuadLoss]
    exact (continuous_const.mul (((hq_cont.sub continuous_const).norm).pow 2)).sub
      (continuous_const.mul (((EuclideanSpace.proj y).continuous.comp hq_cont).sub continuous_const))
  obtain ⟨hF_int, hF_eq⟩ :=
    integrable_and_integral_jointMeasureP_of_continuous hL hη_cont hη_simp hF_cont
  have hZ_ae : (fun z : EuclideanSpace ℝ (Fin m) × Fin K =>
      UL.extendedCanonicalLoss (phiBeta K β) (p z.1 : EuclideanSpace ℝ (Fin K)) z.2) =ᵐ[P]
      fun z => ((F_fin z : ℝ) : EReal) := by
    filter_upwards [h_ae_P] with z hz
    exact extendedCanonicalLoss_phiBeta_of_pos hK β (p z.1).2 hz z.2
  have hecl_eq : UL.expectedCanonicalLoss P Prod.fst Prod.snd (phiBeta K β) p =
      ((∫ z, F_fin z ∂P : ℝ) : EReal) := by
    unfold UL.expectedCanonicalLoss UL.erealExpectation
    have h1 : (∫⁻ z, (UL.extendedCanonicalLoss (phiBeta K β)
          (p z.1 : EuclideanSpace ℝ (Fin K)) z.2).toENNReal ∂P) =
        ∫⁻ z, ((F_fin z : EReal)).toENNReal ∂P :=
      lintegral_congr_ae (hZ_ae.mono fun _ hz => congrArg EReal.toENNReal hz)
    have h2 : (∫⁻ z, (-UL.extendedCanonicalLoss (phiBeta K β)
          (p z.1 : EuclideanSpace ℝ (Fin K)) z.2).toENNReal ∂P) =
        ∫⁻ z, (-(F_fin z : EReal)).toENNReal ∂P :=
      lintegral_congr_ae (hZ_ae.mono fun _ hz => congrArg (fun u : EReal => (-u).toENNReal) hz)
    rw [h1, h2]
    exact erealExpectation_coe_of_integrable P hF_int
  have hbench : bench = ((benchReal K hK R β L hR hβ hL hcond : ℝ) : EReal) :=
    bench_eq_coe K hK hR hβ hL hcond
  rw [hecl_eq, hbench, ← EReal.coe_sub, hF_eq]
  congr 1
  have hsum_eq : (fun x : EuclideanSpace ℝ (Fin m) => ∑ y : Fin K, η x y * F_fin (x, y)) =
      fun x => -phiBeta K β ⟨η x, hη_simp x⟩ +
        (1 / (2 * β)) * ‖(p x : EuclideanSpace ℝ (Fin K)) - η x‖ ^ 2 := by
    funext x
    exact sum_eta_finiteQuadLoss_eq hK hβ (p x).2 (hη_simp x)
  have hneg_int : Integrable (fun x => -phiBeta K β ⟨η x, hη_simp x⟩) μ₀ := by
    have h_eq : (fun x : EuclideanSpace ℝ (Fin m) => -phiBeta K β ⟨η x, hη_simp x⟩) =
        fun x => -((1 / (2 * β)) * ‖η x - UL.uniformVec K‖ ^ 2) := rfl
    rw [h_eq]
    exact integrable_of_continuous_ballUniformMeasure hL
      ((continuous_const.mul (((hη_cont.sub continuous_const).norm).pow 2)).neg)
  have hl2_int : Integrable (fun x =>
      (1 / (2 * β)) * ‖(p x : EuclideanSpace ℝ (Fin K)) - η x‖ ^ 2) μ₀ :=
    integrable_of_continuous_ballUniformMeasure hL
      (continuous_const.mul (((hq_cont.sub hη_cont).norm).pow 2))
  rw [hsum_eq, integral_add hneg_int hl2_int, integral_const_mul]
  unfold benchReal
  ring

theorem l2_le_regret {K : ℕ} (hK : 2 ≤ K) {R β L : ℝ}
    (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    (hcond : β * R * L / Real.sqrt ((K : ℝ) - 1) < 1 / (K : ℝ))
    {p : EuclideanSpace ℝ (Fin (K - 1)) → UL.Simplex K} (hp_cont : Continuous p) :
    let m := K - 1
    let P := jointMeasureP m K L (etaMap K hK R β L)
    let bench := ⨅ V ∈ UL.ComparatorBall m K R,
      UL.expectedMatchingLoss P Prod.fst Prod.snd (phiBeta K β) V
    (((1 / (2 * β)) * ∫ x, ‖(p x : EuclideanSpace ℝ (Fin K)) - etaMap K hK R β L x‖ ^ 2
      ∂(ballUniformMeasure m L) : ℝ) : EReal) ≤
      UL.expectedCanonicalLoss P Prod.fst Prod.snd (phiBeta K β) p - bench := by
  intro m P bench
  let μ₀ := ballUniformMeasure m L
  let S_bad : Set (EuclideanSpace ℝ (Fin m)) :=
    {x | ¬ ∀ y : Fin K, 0 < (p x : EuclideanSpace ℝ (Fin K)) y}
  by_cases h_zero : μ₀ S_bad = 0
  · have h_ae_pos : ∀ᵐ x ∂μ₀, ∀ y : Fin K, 0 < (p x : EuclideanSpace ℝ (Fin K)) y :=
      ae_iff.mpr h_zero
    rw [regret_eq_l2_of_ae_pos hK hR hβ hL hcond hp_cont h_ae_pos]
  · let η := etaMap K hK R β L
    have hη_cont : Continuous η := continuous_etaMap K hK R β hL
    have hη_simp : ∀ x, η x ∈ UL.Simplex K := etaMap_mem_simplex hK hR hβ hL hcond
    haveI : IsProbabilityMeasure P := jointMeasureP_isProb m K hL hη_cont hη_simp
    have hq_cont : Continuous (fun x => (p x : EuclideanSpace ℝ (Fin K))) :=
      continuous_subtype_val.comp hp_cont
    let E : Fin K → Set (EuclideanSpace ℝ (Fin m)) :=
      fun y => {x | (p x : EuclideanSpace ℝ (Fin K)) y ≤ 0}
    have hE_meas : ∀ y : Fin K, MeasurableSet (E y) := fun y =>
      (isClosed_le ((EuclideanSpace.proj y).continuous.comp hq_cont) continuous_const).measurableSet
    have hS_eq : S_bad = ⋃ y : Fin K, E y := by
      ext x
      simp only [S_bad, E, Set.mem_setOf_eq, Set.mem_iUnion, not_forall, not_lt]
    have h_exists_y : ∃ y₀ : Fin K, μ₀ (E y₀) ≠ 0 := by
      by_contra h_all_zero
      push_neg at h_all_zero
      apply h_zero
      rw [hS_eq]
      exact measure_iUnion_null h_all_zero
    rcases h_exists_y with ⟨y₀, hy₀_ne⟩
    have hP_pos : P (E y₀ ×ˢ {y₀}) ≠ 0 := by
      rw [jointMeasureP_prod_singleton m K L η (hE_meas y₀) y₀]
      have hfloor_pos : 0 < etaFloor K R β L := etaFloor_pos hK hcond
      have h_ge : ENNReal.ofReal (etaFloor K R β L) * μ₀ (E y₀) ≤
          ∫⁻ x in E y₀, ENNReal.ofReal (η x y₀) ∂μ₀ := by
        rw [← setLIntegral_const]
        exact setLIntegral_mono (measurable_eta_ofReal hη_cont y₀) fun x _ =>
          ENNReal.ofReal_le_ofReal (etaFloor_le_etaMap hK hR hβ hL x y₀)
      have h_lhs_ne : ENNReal.ofReal (etaFloor K R β L) * μ₀ (E y₀) ≠ 0 :=
        mul_ne_zero (ENNReal.ofReal_pos.mpr hfloor_pos).ne' hy₀_ne
      exact fun h0 => h_lhs_ne (le_antisymm (h0 ▸ h_ge) (zero_le _))
    have hpos_top :
        (∫⁻ z, (UL.extendedCanonicalLoss (phiBeta K β)
          (p z.1 : EuclideanSpace ℝ (Fin K)) z.2).toENNReal ∂P) = ⊤ := by
      have h_ind_le : ∀ z : EuclideanSpace ℝ (Fin m) × Fin K,
          (E y₀ ×ˢ ({y₀} : Set (Fin K))).indicator (fun _ => (⊤ : ENNReal)) z ≤
            (UL.extendedCanonicalLoss (phiBeta K β)
              (p z.1 : EuclideanSpace ℝ (Fin K)) z.2).toENNReal := by
        intro z
        by_cases hz : z ∈ E y₀ ×ˢ ({y₀} : Set (Fin K))
        · rw [Set.indicator_of_mem hz]
          rcases hz with ⟨hxE, rfl⟩
          have hnot_supp : z.2 ∉ UL.posSupport (p z.1 : EuclideanSpace ℝ (Fin K)) := by
            intro hmem
            have hgt : 0 < (p z.1 : EuclideanSpace ℝ (Fin K)) z.2 :=
              (Finset.mem_filter.mp hmem).2
            exact not_lt_of_ge hxE hgt
          unfold UL.extendedCanonicalLoss
          rw [if_neg hnot_supp]
          simp
        · simp [Set.indicator_of_notMem hz]
      have h_ge :
          (∫⁻ z, (E y₀ ×ˢ ({y₀} : Set (Fin K))).indicator (fun _ => (⊤ : ENNReal)) z ∂P) ≤
            ∫⁻ z, (UL.extendedCanonicalLoss (phiBeta K β)
              (p z.1 : EuclideanSpace ℝ (Fin K)) z.2).toENNReal ∂P :=
        lintegral_mono h_ind_le
      rw [lintegral_indicator ((hE_meas y₀).prod (measurableSet_singleton y₀)),
        setLIntegral_const, ENNReal.top_mul hP_pos] at h_ge
      exact top_unique h_ge
    have hneg_lt_top :
        (∫⁻ z, (-UL.extendedCanonicalLoss (phiBeta K β)
          (p z.1 : EuclideanSpace ℝ (Fin K)) z.2).toENNReal ∂P) ≠ ⊤ := by
      have h_le : (∫⁻ z, (-UL.extendedCanonicalLoss (phiBeta K β)
            (p z.1 : EuclideanSpace ℝ (Fin K)) z.2).toENNReal ∂P) ≤
          ENNReal.ofReal (lossLowerBound K β) := by
        calc (∫⁻ z, (-UL.extendedCanonicalLoss (phiBeta K β)
              (p z.1 : EuclideanSpace ℝ (Fin K)) z.2).toENNReal ∂P)
            ≤ ∫⁻ _z, ENNReal.ofReal (lossLowerBound K β) ∂P :=
                lintegral_mono fun z => neg_extendedCanonicalLoss_toENNReal_le hK hβ (p z.1).2 z.2
          _ = ENNReal.ofReal (lossLowerBound K β) := by simp
      exact ne_of_lt (lt_of_le_of_lt h_le ENNReal.ofReal_lt_top)
    have h_enn_coe : ∀ {a : ENNReal}, a ≠ ⊤ → a.toEReal = ((a.toReal : ℝ) : EReal) := by
      intro a ha
      lift a to NNReal using ha
      rfl
    have hecl_top : UL.expectedCanonicalLoss P Prod.fst Prod.snd (phiBeta K β) p = ⊤ := by
      unfold UL.expectedCanonicalLoss UL.erealExpectation
      rw [hpos_top, h_enn_coe hneg_lt_top, EReal.coe_ennreal_top]
      exact EReal.top_sub_coe _
    have hbench : bench = ((benchReal K hK R β L hR hβ hL hcond : ℝ) : EReal) :=
      bench_eq_coe K hK hR hβ hL hcond
    rw [hecl_top, hbench, EReal.top_sub_coe]
    exact le_top

end UL.Proof_thm_A_9

import Mathlib
import UL.Proof.thm_A_9.H2_QuadRisk
set_option autoImplicit false

namespace UL.Proof_thm_A_9

open MeasureTheory

/-! ### Orthonormal basis adapted to `ker W` and Frobenius invariance -/

private lemma norm_sq_sum_orthogonal {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    {ι : Type*} [DecidableEq ι] (s : Finset ι) (w : ι → E)
    (hw : ∀ i ∈ s, ∀ j ∈ s, i ≠ j → inner ℝ (w i) (w j) = 0) :
    ‖∑ i ∈ s, w i‖ ^ 2 = ∑ i ∈ s, ‖w i‖ ^ 2 := by
  induction s using Finset.induction_on with
  | empty => simp
  | @insert a s ha ih =>
      rw [Finset.sum_insert ha, Finset.sum_insert ha, norm_add_sq_real]
      have h_orth : inner ℝ (w a) (∑ i ∈ s, w i) = 0 := by
        rw [inner_sum]
        refine Finset.sum_eq_zero fun i hi => ?_
        have hne : a ≠ i := fun h => ha (h ▸ hi)
        exact hw a (Finset.mem_insert_self a s) i (Finset.mem_insert_of_mem hi) hne
      have h_sub : ∀ i ∈ s, ∀ j ∈ s, i ≠ j → inner ℝ (w i) (w j) = 0 :=
        fun i hi j hj hij =>
          hw i (Finset.mem_insert_of_mem hi) j (Finset.mem_insert_of_mem hj) hij
      rw [h_orth, ih h_sub]
      ring

private lemma euclideanSpace_eq_sum_single {m : ℕ} (v : EuclideanSpace ℝ (Fin m)) :
    v = ∑ i : Fin m, v i • EuclideanSpace.single i (1 : ℝ) := by
  ext k
  rw [UL.Proof_lem_A_3.sum_apply]
  simp [EuclideanSpace.single_apply]

lemma sum_sq_linear_functional_iso {m : ℕ}
    (ℓ : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] ℝ)
    (Q : EuclideanSpace ℝ (Fin m) ≃ₗᵢ[ℝ] EuclideanSpace ℝ (Fin m)) :
    ∑ j : Fin m, (ℓ (Q (EuclideanSpace.single j (1 : ℝ)))) ^ 2 =
      ∑ i : Fin m, (ℓ (EuclideanSpace.single i (1 : ℝ))) ^ 2 := by
  let w : EuclideanSpace ℝ (Fin m) :=
    (WithLp.equiv 2 (Fin m → ℝ)).symm (fun i => ℓ (EuclideanSpace.single i (1 : ℝ)))
  have hw_inner : ∀ v : EuclideanSpace ℝ (Fin m), ℓ v = inner ℝ w v := by
    intro v
    conv_lhs => rw [euclideanSpace_eq_sum_single v, map_sum]
    rw [UL.Proof_lem_A_3.inner_eq_sum]
    refine Finset.sum_congr rfl fun i _ => ?_
    rw [map_smul, smul_eq_mul]
    change v i * ℓ (EuclideanSpace.single i (1 : ℝ)) = w i * v i
    exact mul_comm _ _
  have hQ_term : ∀ j : Fin m, ℓ (Q (EuclideanSpace.single j (1 : ℝ))) = (Q.symm w) j := by
    intro j
    rw [hw_inner]
    have hw_eq : w = Q (Q.symm w) := (Q.apply_symm_apply w).symm
    conv_lhs => rw [hw_eq]
    rw [Q.inner_map_map, EuclideanSpace.inner_single_right]
    simp
  simp_rw [hQ_term]
  have h1 : ∑ j : Fin m, ((Q.symm w) j) ^ 2 = ‖Q.symm w‖ ^ 2 :=
    (UL.Proof_lem_A_3.norm_sq_eq_sum (Q.symm w)).symm
  have h2 : ∑ i : Fin m, (ℓ (EuclideanSpace.single i (1 : ℝ))) ^ 2 = ‖w‖ ^ 2 :=
    (UL.Proof_lem_A_3.norm_sq_eq_sum w).symm
  rw [h1, h2, Q.symm.norm_map]

private lemma sum_norm_sq_comp_iso {K : ℕ} (hK : 2 ≤ K)
    (W : EuclideanSpace ℝ (Fin (K - 1)) →ₗ[ℝ] UL.ZeroSumSubspace K)
    (Q : EuclideanSpace ℝ (Fin (K - 1)) ≃ₗᵢ[ℝ] EuclideanSpace ℝ (Fin (K - 1))) :
    ∑ j : Fin (K - 1), ‖W (Q (EuclideanSpace.single j (1 : ℝ)))‖ ^ 2 =
      (UL.frobeniusNorm W) ^ 2 := by
  let m := K - 1
  let U := zeroSumIso K hK
  let ℓ : Fin m → (EuclideanSpace ℝ (Fin m) →ₗ[ℝ] ℝ) := fun k =>
    (EuclideanSpace.proj k).toLinearMap.comp (U.symm.toLinearIsometry.toLinearMap.comp W)
  have hnorm_W : ∀ v : EuclideanSpace ℝ (Fin m), ‖W v‖ ^ 2 = ∑ k : Fin m, (ℓ k v) ^ 2 := by
    intro v
    rw [← U.symm.norm_map (W v), UL.Proof_lem_A_3.norm_sq_eq_sum]
    rfl
  have hlhs : ∑ j : Fin m, ‖W (Q (EuclideanSpace.single j (1 : ℝ)))‖ ^ 2 =
      ∑ i : Fin m, ‖W (EuclideanSpace.single i (1 : ℝ))‖ ^ 2 := by
    simp_rw [hnorm_W]
    rw [Finset.sum_comm]
    conv_rhs => rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun k _ => sum_sq_linear_functional_iso (ℓ k) Q
  rw [hlhs]
  unfold UL.frobeniusNorm
  exact (Real.sq_sqrt (Finset.sum_nonneg fun _ _ => sq_nonneg _)).symm

lemma exists_iso_of_orthonormal {m : ℕ} {v : Fin m → EuclideanSpace ℝ (Fin m)}
    (hv_orth : Orthonormal ℝ v) :
    ∃ Q : EuclideanSpace ℝ (Fin m) ≃ₗᵢ[ℝ] EuclideanSpace ℝ (Fin m),
      ∀ j : Fin m, Q (EuclideanSpace.single j (1 : ℝ)) = v j := by
  let Q_lin : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] EuclideanSpace ℝ (Fin m) :=
    ∑ j : Fin m, (EuclideanSpace.proj j).toLinearMap.smulRight (v j)
  have hQ_norm : ∀ x : EuclideanSpace ℝ (Fin m), ‖Q_lin x‖ = ‖x‖ := by
    intro x
    have hQ_app : Q_lin x = ∑ j : Fin m, x j • v j := by
      dsimp [Q_lin]
      rw [LinearMap.sum_apply]
      rfl
    have h_orth_smul : ∀ i ∈ (Finset.univ : Finset (Fin m)),
        ∀ j ∈ (Finset.univ : Finset (Fin m)), i ≠ j →
          inner ℝ (x i • v i) (x j • v j) = 0 := by
      intro i _ j _ hij
      rw [real_inner_smul_left, real_inner_smul_right]
      have h0 : inner ℝ (v i) (v j) = 0 := by
        have h := orthonormal_iff_ite.mp hv_orth i j
        rwa [if_neg hij] at h
      rw [h0]; ring
    have hsq : ‖Q_lin x‖ ^ 2 = ‖x‖ ^ 2 := by
      rw [hQ_app, norm_sq_sum_orthogonal _ _ h_orth_smul, UL.Proof_lem_A_3.norm_sq_eq_sum]
      refine Finset.sum_congr rfl fun j _ => ?_
      have hv1 : ‖v j‖ = 1 := hv_orth.1 j
      rw [norm_smul, Real.norm_eq_abs, hv1, mul_one, sq_abs]
    nlinarith [norm_nonneg (Q_lin x), norm_nonneg x]
  let li : EuclideanSpace ℝ (Fin m) →ₗᵢ[ℝ] EuclideanSpace ℝ (Fin m) :=
    { toLinearMap := Q_lin, norm_map' := hQ_norm }
  refine ⟨li.toLinearIsometryEquiv rfl, fun j => ?_⟩
  have h_coe : (li.toLinearIsometryEquiv rfl) (EuclideanSpace.single j (1 : ℝ)) =
      Q_lin (EuclideanSpace.single j (1 : ℝ)) := by simp [li]
  rw [h_coe]
  dsimp only [Q_lin]
  rw [LinearMap.sum_apply]
  change ∑ i : Fin m, (EuclideanSpace.single j (1 : ℝ) i) • v i = v j
  rw [Finset.sum_eq_single j]
  · simp [EuclideanSpace.single_apply]
  · intro i _ hij
    simp [EuclideanSpace.single_apply, hij]
  · intro hj_abs
    exact False.elim (hj_abs (Finset.mem_univ j))

lemma exists_iso_ker_tail {K : ℕ} (hK : 2 ≤ K) {r : ℕ}
    (W : EuclideanSpace ℝ (Fin (K - 1)) →ₗ[ℝ] UL.ZeroSumSubspace K)
    (hr_rank : Module.finrank ℝ (LinearMap.range W) ≤ r) :
    ∃ Q : EuclideanSpace ℝ (Fin (K - 1)) ≃ₗᵢ[ℝ] EuclideanSpace ℝ (Fin (K - 1)),
      (∀ j : Fin (K - 1), r ≤ j.val → W (Q (EuclideanSpace.single j (1 : ℝ))) = 0) ∧
      (∑ j : Fin (K - 1), ‖W (Q (EuclideanSpace.single j (1 : ℝ)))‖ ^ 2 =
        (UL.frobeniusNorm W) ^ 2) := by
  let m := K - 1
  let S : Submodule ℝ (EuclideanSpace ℝ (Fin m)) := LinearMap.ker W
  have h_rn := LinearMap.finrank_range_add_finrank_ker W
  rw [finrank_euclideanSpace_fin] at h_rn
  have h_orth_dim := Submodule.finrank_add_finrank_orthogonal S
  rw [finrank_euclideanSpace_fin] at h_orth_dim
  let k : ℕ := Module.finrank ℝ (Sᗮ)
  have hk_eq : k = Module.finrank ℝ (LinearMap.range W) := by
    change Module.finrank ℝ (Sᗮ) = Module.finrank ℝ (LinearMap.range W)
    change Module.finrank ℝ (LinearMap.range W) + Module.finrank ℝ S = m at h_rn
    omega
  have hk_le_r : k ≤ r := hk_eq ▸ hr_rank
  have hS_dim : Module.finrank ℝ S = m - k := by
    change Module.finrank ℝ S + k = m at h_orth_dim
    omega
  let b₁ : OrthonormalBasis (Fin k) ℝ (Sᗮ) := stdOrthonormalBasis ℝ (Sᗮ)
  let b₂ : OrthonormalBasis (Fin (m - k)) ℝ S :=
    (stdOrthonormalBasis ℝ S).reindex (finCongr hS_dim)
  let v : Fin m → EuclideanSpace ℝ (Fin m) := fun j =>
    if hj : j.val < k then
      (b₁ ⟨j.val, hj⟩ : EuclideanSpace ℝ (Fin m))
    else
      (b₂ ⟨j.val - k, by omega⟩ : EuclideanSpace ℝ (Fin m))
  have hv_orth : Orthonormal ℝ v := by
    rw [orthonormal_iff_ite]
    intro i j
    by_cases hi : i.val < k <;> by_cases hj : j.val < k
    · simp only [v, dif_pos hi, dif_pos hj]
      have hite := orthonormal_iff_ite.mp b₁.orthonormal ⟨i.val, hi⟩ ⟨j.val, hj⟩
      change inner ℝ (b₁ ⟨i.val, hi⟩) (b₁ ⟨j.val, hj⟩) = if i = j then 1 else 0
      rw [hite]
      by_cases hij : i = j
      · subst hij; simp
      · have hne : (⟨i.val, hi⟩ : Fin k) ≠ ⟨j.val, hj⟩ := fun h =>
          hij (Fin.ext (Fin.mk.inj h))
        simp [hij, hne]
    · simp only [v, dif_pos hi, dif_neg hj]
      have hij : i ≠ j := fun h => hj (h ▸ hi)
      rw [if_neg hij, real_inner_comm]
      exact S.inner_right_of_mem_orthogonal (b₂ _).2 (b₁ _).2
    · simp only [v, dif_neg hi, dif_pos hj]
      have hij : i ≠ j := fun h => hi (h.symm ▸ hj)
      rw [if_neg hij]
      exact S.inner_right_of_mem_orthogonal (b₂ _).2 (b₁ _).2
    · simp only [v, dif_neg hi, dif_neg hj]
      have hite := orthonormal_iff_ite.mp b₂.orthonormal
        ⟨i.val - k, by omega⟩ ⟨j.val - k, by omega⟩
      change inner ℝ (b₂ ⟨i.val - k, _⟩) (b₂ ⟨j.val - k, _⟩) = if i = j then 1 else 0
      rw [hite]
      by_cases hij : i = j
      · subst hij; simp
      · have hne : (⟨i.val - k, by omega⟩ : Fin (m - k)) ≠ ⟨j.val - k, by omega⟩ := by
          intro h
          have hv_eq : i.val - k = j.val - k := congrArg Fin.val h
          exact hij (Fin.ext (by omega))
        simp [hij, hne]
  obtain ⟨Q, hQ_single⟩ := exists_iso_of_orthonormal hv_orth
  refine ⟨Q, ?_, sum_norm_sq_comp_iso hK W Q⟩
  intro j hj_ge
  rw [hQ_single j]
  have hnot_lt : ¬ (j.val < k) := by omega
  dsimp only [v]
  rw [dif_neg hnot_lt]
  exact LinearMap.mem_ker.mp (b₂ ⟨j.val - k, by omega⟩).2

/-! ### Coordinatewise lower bound and algebraic Cauchy-Schwarz slope tradeoff -/

lemma sum_fin_split_lt {m r : ℕ} (hr_m : r ≤ m) (g : Fin m → ℝ) :
    ∑ j : Fin m, g j =
      (∑ i : Fin r, g ⟨i.val, by omega⟩) +
        ∑ i : Fin (m - r), g ⟨r + i.val, by omega⟩ := by
  let e_lt : Fin r ↪ Fin m :=
    ⟨fun i => ⟨i.val, by omega⟩,
      fun i₁ i₂ h => Fin.ext (by simpa using congrArg Fin.val h)⟩
  let e_ge : Fin (m - r) ↪ Fin m :=
    ⟨fun i => ⟨r + i.val, by omega⟩,
      fun i₁ i₂ h => Fin.ext (by
        have hv := congrArg Fin.val h
        dsimp at hv
        omega)⟩
  have hsplit :=
    (Finset.sum_filter_add_sum_filter_not Finset.univ (fun j : Fin m => j.val < r) g).symm
  have h1 : Finset.univ.filter (fun j : Fin m => j.val < r) = Finset.univ.map e_lt := by
    ext j
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_map, e_lt,
      Function.Embedding.coeFn_mk]
    constructor
    · intro hj
      exact ⟨⟨j.val, hj⟩, rfl⟩
    · rintro ⟨i, rfl⟩
      exact i.isLt
  have h2 : Finset.univ.filter (fun j : Fin m => ¬ j.val < r) = Finset.univ.map e_ge := by
    ext j
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_map, e_ge,
      Function.Embedding.coeFn_mk]
    constructor
    · intro hj
      refine ⟨⟨j.val - r, by omega⟩, Fin.ext ?_⟩
      dsimp
      omega
    · rintro ⟨i, rfl⟩
      dsimp
      omega
  rw [hsplit, h1, h2, Finset.sum_map, Finset.sum_map]
  rfl

private lemma finset_sum_sq_ge_sq_sum {r : ℕ} (hr : 1 ≤ r) (x : Fin r → ℝ) :
    (∑ i : Fin r, x i) ^ 2 ≤ (r : ℝ) * ∑ i : Fin r, (x i) ^ 2 := by
  have hr_pos : (0 : ℝ) < (r : ℝ) := by exact_mod_cast hr
  let avg : ℝ := (∑ i : Fin r, x i) / (r : ℝ)
  have h_nonneg : 0 ≤ ∑ i : Fin r, (x i - avg) ^ 2 :=
    Finset.sum_nonneg fun i _ => sq_nonneg _
  have h_expand : ∑ i : Fin r, (x i - avg) ^ 2 =
      (∑ i : Fin r, (x i) ^ 2) - (∑ i : Fin r, x i) ^ 2 / (r : ℝ) := by
    have h1 : ∑ i : Fin r, (x i - avg) ^ 2 =
        (∑ i : Fin r, (x i) ^ 2) - 2 * avg * (∑ i : Fin r, x i) + (r : ℝ) * avg ^ 2 := by
      calc ∑ i : Fin r, (x i - avg) ^ 2
          = ∑ i : Fin r, ((x i) ^ 2 - 2 * avg * x i + avg ^ 2) :=
              Finset.sum_congr rfl fun _ _ => by ring
        _ = (∑ i : Fin r, ((x i) ^ 2 - 2 * avg * x i)) + ∑ _i : Fin r, avg ^ 2 :=
              Finset.sum_add_distrib
        _ = (∑ i : Fin r, (x i) ^ 2) - (∑ i : Fin r, 2 * avg * x i) + (r : ℝ) * avg ^ 2 := by
              rw [Finset.sum_sub_distrib, Finset.sum_const, Finset.card_fin, nsmul_eq_mul]
        _ = (∑ i : Fin r, (x i) ^ 2) - 2 * avg * (∑ i : Fin r, x i) + (r : ℝ) * avg ^ 2 := by
              rw [← Finset.mul_sum]
    rw [h1]
    dsimp [avg]
    field_simp [hr_pos.ne']
    ring
  rw [h_expand] at h_nonneg
  have h_div : (∑ i : Fin r, x i) ^ 2 / (r : ℝ) ≤ ∑ i : Fin r, (x i) ^ 2 := by linarith
  have h_mul := mul_le_mul_of_nonneg_left h_div hr_pos.le
  rwa [mul_div_cancel₀ _ hr_pos.ne'] at h_mul

lemma algebraic_slope_jensen {r : ℕ} (hr : 1 ≤ r) {B R c : ℝ}
    (hB : 0 ≤ B) (hR : 0 ≤ R) {σ : Fin r → ℝ}
    (hσ_nn : ∀ i : Fin r, 0 ≤ σ i) (hσ_sum : ∑ i : Fin r, (σ i) ^ 2 ≤ R ^ 2) :
    (r : ℝ) * (max (c - B * R / Real.sqrt (r : ℝ)) 0) ^ 2 ≤
      ∑ i : Fin r, (max (c - B * σ i) 0) ^ 2 := by
  by_cases h_pos : c - B * R / Real.sqrt (r : ℝ) ≤ 0
  · rw [max_eq_right h_pos, zero_pow (by norm_num), mul_zero]
    exact Finset.sum_nonneg fun _ _ => sq_nonneg _
  · push_neg at h_pos
    have hr_pos : (0 : ℝ) < (r : ℝ) := by exact_mod_cast hr
    have hsr_pos : 0 < Real.sqrt (r : ℝ) := Real.sqrt_pos.mpr hr_pos
    rw [max_eq_left h_pos.le]
    let u : Fin r → ℝ := fun i => max (c - B * σ i) 0
    have h_sigma_cs : (∑ i : Fin r, σ i) ^ 2 ≤ (Real.sqrt (r : ℝ) * R) ^ 2 := by
      calc (∑ i : Fin r, σ i) ^ 2
          ≤ (r : ℝ) * ∑ i : Fin r, (σ i) ^ 2 := finset_sum_sq_ge_sq_sum hr σ
        _ ≤ (r : ℝ) * R ^ 2 := mul_le_mul_of_nonneg_left hσ_sum hr_pos.le
        _ = (Real.sqrt (r : ℝ) * R) ^ 2 := by rw [mul_pow, Real.sq_sqrt hr_pos.le]
    have h_sum_sigma_nn : 0 ≤ ∑ i : Fin r, σ i := Finset.sum_nonneg fun i _ => hσ_nn i
    have h_srR_nn : 0 ≤ Real.sqrt (r : ℝ) * R := mul_nonneg hsr_pos.le hR
    have h_sum_sigma_le : ∑ i : Fin r, σ i ≤ Real.sqrt (r : ℝ) * R := by
      nlinarith
    have h_sum_u_ge : (r : ℝ) * (c - B * R / Real.sqrt (r : ℝ)) ≤ ∑ i : Fin r, u i := by
      have h1 : (∑ i : Fin r, (c - B * σ i)) ≤ ∑ i : Fin r, u i :=
        Finset.sum_le_sum fun i _ => le_max_left _ _
      have h2 : ∑ i : Fin r, (c - B * σ i) = (r : ℝ) * c - B * ∑ i : Fin r, σ i := by
        rw [Finset.sum_sub_distrib, Finset.sum_const, Finset.card_fin, nsmul_eq_mul,
          ← Finset.mul_sum]
      have h3 : B * ∑ i : Fin r, σ i ≤ B * (Real.sqrt (r : ℝ) * R) :=
        mul_le_mul_of_nonneg_left h_sum_sigma_le hB
      have h4 : (r : ℝ) * (c - B * R / Real.sqrt (r : ℝ)) =
          (r : ℝ) * c - B * (Real.sqrt (r : ℝ) * R) := by
        have hdiv : (r : ℝ) * (B * R / Real.sqrt (r : ℝ)) = B * (Real.sqrt (r : ℝ) * R) := by
          rw [mul_div_assoc', div_eq_iff hsr_pos.ne']
          have hsr2 : Real.sqrt (r : ℝ) * Real.sqrt (r : ℝ) = (r : ℝ) :=
            Real.mul_self_sqrt hr_pos.le
          calc (r : ℝ) * (B * R)
              = B * R * (r : ℝ) := by ring
            _ = B * R * (Real.sqrt (r : ℝ) * Real.sqrt (r : ℝ)) := by rw [hsr2]
            _ = B * (Real.sqrt (r : ℝ) * R) * Real.sqrt (r : ℝ) := by ring
        rw [mul_sub, hdiv]
      linarith
    have h_lhs_nn : 0 ≤ (r : ℝ) * (c - B * R / Real.sqrt (r : ℝ)) :=
      mul_nonneg hr_pos.le h_pos.le
    have h_sq_u : ((r : ℝ) * (c - B * R / Real.sqrt (r : ℝ))) ^ 2 ≤
        (r : ℝ) * ∑ i : Fin r, (u i) ^ 2 :=
      (pow_le_pow_left₀ h_lhs_nn h_sum_u_ge 2).trans (finset_sum_sq_ge_sq_sum hr u)
    have h_mul : (r : ℝ) * ((r : ℝ) * (c - B * R / Real.sqrt (r : ℝ)) ^ 2) ≤
        (r : ℝ) * ∑ i : Fin r, (u i) ^ 2 := by
      linarith [show ((r : ℝ) * (c - B * R / Real.sqrt (r : ℝ))) ^ 2 =
        (r : ℝ) * ((r : ℝ) * (c - B * R / Real.sqrt (r : ℝ)) ^ 2) by ring]
    exact le_of_mul_le_mul_left h_mul hr_pos

theorem pre_jensen_l2_lower_bound {K : ℕ} (hK : 2 ≤ K) {R β L : ℝ}
    (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    {r : ℕ} (hr_m : r ≤ K - 1) {B : ℝ} (hB : 0 ≤ B)
    (W : EuclideanSpace ℝ (Fin (K - 1)) →ₗ[ℝ] UL.ZeroSumSubspace K)
    (ρ : UL.ZeroSumSubspace K → UL.Simplex K)
    (hr_rank : Module.finrank ℝ (LinearMap.range W) ≤ r)
    (hW_frob : UL.frobeniusNorm W ≤ R)
    (hρ_lip : LipschitzWith (Real.toNNReal B) ρ) :
    let m := K - 1
    let c := slopeParam K R β
    ∃ σ : Fin r → ℝ,
      (∀ i : Fin r, 0 ≤ σ i) ∧
      (∑ i : Fin r, (σ i) ^ 2 ≤ R ^ 2) ∧
      (L ^ 2 / ((m : ℝ) + 2)) *
          (((m : ℝ) - (r : ℝ)) * c ^ 2 + ∑ i : Fin r, (max (c - B * σ i) 0) ^ 2) ≤
        ∫ x, ‖(ρ (W x) : EuclideanSpace ℝ (Fin K)) - etaMap K hK R β L x‖ ^ 2
          ∂(ballUniformMeasure m L) := by
  intro m c
  have hm1 : 1 ≤ m := by omega
  let μ₀ := ballUniformMeasure m L
  haveI : IsProbabilityMeasure μ₀ := ballUniformMeasure_isProb m hL
  let U := zeroSumIso K hK
  obtain ⟨Q, hQ_ker, hQ_frob⟩ := exists_iso_ker_tail hK W hr_rank
  let b : Fin m → EuclideanSpace ℝ (Fin m) := fun j => Q (EuclideanSpace.single j (1 : ℝ))
  let σ_all : Fin m → ℝ := fun j => ‖W (b j)‖
  let v : ℝ := L ^ 2 / ((m : ℝ) + 2)
  have hv_pos : 0 < v := by dsimp [v]; positivity
  let f : Fin m → EuclideanSpace ℝ (Fin m) → ℝ := fun j t =>
    inner ℝ ((U (b j) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
      ((ρ (W (Q t)) : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K)
  have hρW_cont : Continuous (fun x : EuclideanSpace ℝ (Fin m) =>
      (ρ (W x) : EuclideanSpace ℝ (Fin K))) :=
    continuous_subtype_val.comp (hρ_lip.continuous.comp W.continuous_of_finiteDimensional)
  have hf_cont : ∀ j : Fin m, Continuous (f j) := fun j =>
    continuous_const.inner ((hρW_cont.comp Q.continuous).sub continuous_const)
  have h_rot_l2 :
      ∫ x, ‖(ρ (W x) : EuclideanSpace ℝ (Fin K)) - etaMap K hK R β L x‖ ^ 2 ∂μ₀ =
        ∑ j : Fin m, ∫ t, (f j t - c * t j) ^ 2 ∂μ₀ := by
    let g_err : EuclideanSpace ℝ (Fin m) → ℝ :=
      fun x => ‖(ρ (W x) : EuclideanSpace ℝ (Fin K)) - etaMap K hK R β L x‖ ^ 2
    have hg_cont : Continuous g_err :=
      ((hρW_cont.sub (continuous_etaMap K hK R β hL)).norm).pow 2
    rw [← integral_comp_iso_ballUniformMeasure L Q hg_cont.measurable]
    let E_iso : EuclideanSpace ℝ (Fin m) ≃ₗᵢ[ℝ] UL.ZeroSumSubspace K := Q.trans U
    have h_ae_parseval :
        (fun t : EuclideanSpace ℝ (Fin m) => g_err (Q t)) =ᵐ[μ₀]
          fun t => ∑ j : Fin m, (f j t - c * t j) ^ 2 := by
      filter_upwards [ae_mem_ball_ballUniformMeasure m L] with t ht
      have hQt_closed : Q t ∈ Metric.closedBall (0 : EuclideanSpace ℝ (Fin m)) L := by
        rw [Metric.mem_closedBall, dist_zero_right, Q.norm_map]
        exact ( by simpa [Metric.mem_ball, dist_zero_right] using ht : ‖t‖ < L ).le
      dsimp only [g_err]
      rw [etaMap_eq_on_closedBall K hK R β hL hQt_closed]
      have hw1_mem : (ρ (W (Q t)) : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K ∈
          UL.ZeroSumSubspace K :=
        UL.Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex (ρ (W (Q t))).2
          (UL.Proof_lem_A_5.uniformVec_mem_simplex hK)
      let d_sub : UL.ZeroSumSubspace K := ⟨_, hw1_mem⟩ - c • U (Q t)
      have hd_coe : (d_sub : EuclideanSpace ℝ (Fin K)) =
          (ρ (W (Q t)) : EuclideanSpace ℝ (Fin K)) -
            (UL.uniformVec K + c • ((U (Q t) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))) := by
        dsimp [d_sub]
        abel
      rw [← hd_coe, Submodule.norm_coe, ← E_iso.symm.norm_map d_sub,
        UL.Proof_lem_A_3.norm_sq_eq_sum]
      refine Finset.sum_congr rfl fun j _ => ?_
      congr 1
      have hcoord : (E_iso.symm d_sub) j = inner ℝ (E_iso (EuclideanSpace.single j (1 : ℝ))) d_sub := by
        have h1 : (E_iso.symm d_sub) j =
            inner ℝ (EuclideanSpace.single j (1 : ℝ)) (E_iso.symm d_sub) := by
          rw [EuclideanSpace.inner_single_left]; simp
        rw [h1, ← E_iso.inner_map_map, E_iso.apply_symm_apply]
      rw [hcoord, inner_sub_right, inner_smul_right]
      have h_eiso_t : E_iso t = U (Q t) := rfl
      have h_eiso_j : E_iso (EuclideanSpace.single j (1 : ℝ)) = U (b j) := rfl
      rw [← h_eiso_t, E_iso.inner_map_map, EuclideanSpace.inner_single_left]
      simp only [one_mul, RCLike.conj_to_real]
      rw [h_eiso_j]
      rfl
    have hint_parseval_term : ∀ j : Fin m,
        Integrable (fun a : EuclideanSpace ℝ (Fin m) => (f j a - c * a j) ^ 2) μ₀ := fun j =>
      integrable_of_continuous_ballUniformMeasure hL
        (((hf_cont j).sub (continuous_const.mul (EuclideanSpace.proj j).continuous)).pow 2)
    rw [integral_congr_ae h_ae_parseval,
      integral_finset_sum Finset.univ fun j _ => hint_parseval_term j]
  have h_coord_lb : ∀ j : Fin m,
      v * (max (c - B * σ_all j) 0) ^ 2 ≤ ∫ t, (f j t - c * t j) ^ 2 ∂μ₀ := by
    intro j
    have h_refl := integral_coord_mul_eq_half_sub hL j (hf_cont j)
    have h_ptwise : ∀ t : EuclideanSpace ℝ (Fin m),
        t j * (f j t - f j (coordReflect j t)) ≤ 2 * B * σ_all j * (t j) ^ 2 := by
      intro t
      have hf_diff : |f j t - f j (coordReflect j t)| ≤ 2 * B * σ_all j * |t j| := by
        have hid : f j t - f j (coordReflect j t) =
            inner ℝ ((U (b j) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
              ((ρ (W (Q t)) : EuclideanSpace ℝ (Fin K)) -
                (ρ (W (Q (coordReflect j t))) : EuclideanSpace ℝ (Fin K))) := by
          dsimp [f]
          rw [← inner_sub_right]
          congr 1; abel
        have hU_norm : ‖((U (b j) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))‖ = 1 := by
          rw [Submodule.norm_coe, U.norm_map, Q.norm_map, EuclideanSpace.norm_single, norm_one]
        have h_lip_bound :
            ‖(ρ (W (Q t)) : EuclideanSpace ℝ (Fin K)) -
                (ρ (W (Q (coordReflect j t))) : EuclideanSpace ℝ (Fin K))‖ ≤
              B * ‖W (Q t) - W (Q (coordReflect j t))‖ := by
          have hd := hρ_lip.dist_le_mul (W (Q t)) (W (Q (coordReflect j t)))
          rwa [Subtype.dist_eq, dist_eq_norm, dist_eq_norm, Real.coe_toNNReal B hB] at hd
        have hW_diff : ‖W (Q t) - W (Q (coordReflect j t))‖ = 2 * |t j| * σ_all j := by
          have hsub_Q : W (Q t) - W (Q (coordReflect j t)) =
              (2 * t j) • W (b j) := by
            rw [← map_sub, ← Q.map_sub, sub_coordReflect_eq, Q.map_smul, map_smul]
          rw [hsub_Q, norm_smul, Real.norm_eq_abs, abs_mul, abs_of_pos zero_lt_two]
        rw [hid]
        calc |inner ℝ ((U (b j) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
                ((ρ (W (Q t)) : EuclideanSpace ℝ (Fin K)) -
                  (ρ (W (Q (coordReflect j t))) : EuclideanSpace ℝ (Fin K)))|
            ≤ ‖((U (b j) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))‖ *
                ‖(ρ (W (Q t)) : EuclideanSpace ℝ (Fin K)) -
                  (ρ (W (Q (coordReflect j t))) : EuclideanSpace ℝ (Fin K))‖ :=
              abs_real_inner_le_norm _ _
          _ = ‖(ρ (W (Q t)) : EuclideanSpace ℝ (Fin K)) -
                (ρ (W (Q (coordReflect j t))) : EuclideanSpace ℝ (Fin K))‖ := by
              rw [hU_norm, one_mul]
          _ ≤ B * ‖W (Q t) - W (Q (coordReflect j t))‖ := h_lip_bound
          _ = 2 * B * σ_all j * |t j| := by rw [hW_diff]; ring
      calc t j * (f j t - f j (coordReflect j t))
          ≤ |t j * (f j t - f j (coordReflect j t))| := le_abs_self _
        _ = |t j| * |f j t - f j (coordReflect j t)| := abs_mul _ _
        _ ≤ |t j| * (2 * B * σ_all j * |t j|) :=
            mul_le_mul_of_nonneg_left hf_diff (abs_nonneg _)
        _ = 2 * B * σ_all j * (t j) ^ 2 := by
            have hsq : |t j| * |t j| = (t j) ^ 2 := by rw [← sq, sq_abs]
            calc |t j| * (2 * B * σ_all j * |t j|)
                = 2 * B * σ_all j * (|t j| * |t j|) := by ring
              _ = 2 * B * σ_all j * (t j) ^ 2 := by rw [hsq]
    have hint_lhs : Integrable (fun t => t j * (f j t - f j (coordReflect j t))) μ₀ :=
      integrable_of_continuous_ballUniformMeasure hL
        ((EuclideanSpace.proj j).continuous.mul
          ((hf_cont j).sub ((hf_cont j).comp (coordReflect j).continuous)))
    have hint_tsq : Integrable (fun t : EuclideanSpace ℝ (Fin m) => (t j) ^ 2) μ₀ :=
      integrable_of_continuous_ballUniformMeasure hL (((EuclideanSpace.proj j).continuous).pow 2)
    have h_int_le := integral_mono hint_lhs (hint_tsq.const_mul (2 * B * σ_all j)) h_ptwise
    rw [integral_const_mul, integral_coord_sq_ballUniformMeasure hm1 hL j] at h_int_le
    have h_tf_le : ∫ t, t j * f j t ∂μ₀ ≤ B * σ_all j * v := by
      dsimp [v] at *
      linarith
    let a_j : ℝ := (∫ t, t j * f j t ∂μ₀) / v
    have ha_le : a_j ≤ B * σ_all j := (div_le_iff₀ hv_pos).mpr h_tf_le
    have ha_mul : a_j * v = ∫ t, t j * f j t ∂μ₀ := div_mul_cancel₀ _ hv_pos.ne'
    have hint_fsq : Integrable (fun t => (f j t) ^ 2) μ₀ :=
      integrable_of_continuous_ballUniformMeasure hL ((hf_cont j).pow 2)
    have hint_tf : Integrable (fun t => t j * f j t) μ₀ :=
      integrable_of_continuous_ballUniformMeasure hL
        ((EuclideanSpace.proj j).continuous.mul (hf_cont j))
    have h_cs : v * a_j ^ 2 ≤ ∫ t, (f j t) ^ 2 ∂μ₀ := by
      have h_nn : 0 ≤ ∫ t, (f j t - a_j * t j) ^ 2 ∂μ₀ :=
        integral_nonneg fun _ => sq_nonneg _
      have hexp : (fun t : EuclideanSpace ℝ (Fin m) => (f j t - a_j * t j) ^ 2) =
          fun t => ((f j t) ^ 2 - (2 * a_j) * (t j * f j t)) + a_j ^ 2 * (t j) ^ 2 := by
        funext t; ring
      have h2_int : Integrable (fun t => (2 * a_j) * (t j * f j t)) μ₀ :=
        hint_tf.const_mul (2 * a_j)
      have h12_int : Integrable (fun t => (f j t) ^ 2 - (2 * a_j) * (t j * f j t)) μ₀ :=
        hint_fsq.sub h2_int
      have h3_int : Integrable (fun t => a_j ^ 2 * (t j) ^ 2) μ₀ :=
        hint_tsq.const_mul (a_j ^ 2)
      rw [hexp, integral_add h12_int h3_int, integral_sub hint_fsq h2_int,
        integral_const_mul, integral_const_mul,
        integral_coord_sq_ballUniformMeasure hm1 hL j, ← ha_mul] at h_nn
      dsimp [v] at *
      nlinarith
    have h_quad_eq : ∫ t, (f j t - c * t j) ^ 2 ∂μ₀ =
        (∫ t, (f j t) ^ 2 ∂μ₀) - 2 * c * a_j * v + c ^ 2 * v := by
      have hexp : (fun t : EuclideanSpace ℝ (Fin m) => (f j t - c * t j) ^ 2) =
          fun t => ((f j t) ^ 2 - (2 * c) * (t j * f j t)) + c ^ 2 * (t j) ^ 2 := by
        funext t; ring
      have h2_int : Integrable (fun t => (2 * c) * (t j * f j t)) μ₀ :=
        hint_tf.const_mul (2 * c)
      have h12_int : Integrable (fun t => (f j t) ^ 2 - (2 * c) * (t j * f j t)) μ₀ :=
        hint_fsq.sub h2_int
      have h3_int : Integrable (fun t => c ^ 2 * (t j) ^ 2) μ₀ :=
        hint_tsq.const_mul (c ^ 2)
      rw [hexp, integral_add h12_int h3_int, integral_sub hint_fsq h2_int,
        integral_const_mul, integral_const_mul,
        integral_coord_sq_ballUniformMeasure hm1 hL j, ← ha_mul]
      dsimp [v]
      ring
    have h_ge_ac : v * (a_j - c) ^ 2 ≤ ∫ t, (f j t - c * t j) ^ 2 ∂μ₀ := by
      rw [h_quad_eq]
      nlinarith
    have h_max_le : (max (c - B * σ_all j) 0) ^ 2 ≤ (a_j - c) ^ 2 := by
      by_cases h0 : c - B * σ_all j ≤ 0
      · rw [max_eq_right h0, zero_pow (by norm_num)]
        exact sq_nonneg _
      · push_neg at h0
        rw [max_eq_left h0.le]
        have h_ca : c - B * σ_all j ≤ c - a_j := by linarith
        nlinarith
    exact (mul_le_mul_of_nonneg_left h_max_le hv_pos.le).trans h_ge_ac
  let σ : Fin r → ℝ := fun i => σ_all ⟨i.val, by omega⟩
  refine ⟨σ, fun i => norm_nonneg _, ?_, ?_⟩
  · have h_split := sum_fin_split_lt hr_m (fun j => (σ_all j) ^ 2)
    have h_tail_nn : 0 ≤ ∑ i : Fin (m - r), (σ_all ⟨r + i.val, by omega⟩) ^ 2 :=
      Finset.sum_nonneg fun _ _ => sq_nonneg _
    have h_frob_sq : (UL.frobeniusNorm W) ^ 2 ≤ R ^ 2 :=
      pow_le_pow_left₀ (Real.sqrt_nonneg _) hW_frob 2
    change ∑ i : Fin r, (σ_all ⟨i.val, _⟩) ^ 2 ≤ R ^ 2
    have h_all_eq : ∑ j : Fin m, (σ_all j) ^ 2 = (UL.frobeniusNorm W) ^ 2 := hQ_frob
    linarith
  · rw [h_rot_l2]
    have h_sum_ge :
        ∑ j : Fin m, v * (max (c - B * σ_all j) 0) ^ 2 ≤
          ∑ j : Fin m, ∫ t, (f j t - c * t j) ^ 2 ∂μ₀ :=
      Finset.sum_le_sum fun j _ => h_coord_lb j
    refine le_trans ?_ h_sum_ge
    rw [← Finset.mul_sum, sum_fin_split_lt hr_m (fun j => (max (c - B * σ_all j) 0) ^ 2)]
    have h_tail_eq : ∑ i : Fin (m - r), (max (c - B * σ_all ⟨r + i.val, by omega⟩) 0) ^ 2 =
        ((m : ℝ) - (r : ℝ)) * c ^ 2 := by
      have hc_nn : 0 ≤ c := (slopeParam_pos hK hR hβ).le
      have hterm : ∀ i : Fin (m - r),
          (max (c - B * σ_all ⟨r + i.val, by omega⟩) 0) ^ 2 = c ^ 2 := by
        intro i
        have hker0 : σ_all ⟨r + i.val, by omega⟩ = 0 := by
          simp [σ_all, b, hQ_ker ⟨r + i.val, by omega⟩ (by dsimp; omega)]
        rw [hker0, mul_zero, sub_zero, max_eq_left hc_nn]
      simp_rw [hterm]
      rw [Finset.sum_const, Finset.card_fin, nsmul_eq_mul, Nat.cast_sub hr_m]
    rw [h_tail_eq]
    dsimp [v, σ]
    linarith

/-! ### Attainment constructions for `1 ≤ r ≤ m` and `r = 0` -/

noncomputable def coordProj (m r : ℕ) :
    EuclideanSpace ℝ (Fin m) →ₗ[ℝ] EuclideanSpace ℝ (Fin m) :=
  { toFun := fun x => (WithLp.equiv 2 (Fin m → ℝ)).symm
      (fun j => if j.val < r then x j else 0)
    map_add' := fun x y => by
      ext j
      change (if j.val < r then x j + y j else 0) =
        (if j.val < r then x j else 0) + (if j.val < r then y j else 0)
      split_ifs <;> ring
    map_smul' := fun c x => by
      ext j
      change (if j.val < r then c * x j else 0) =
        c * (if j.val < r then x j else 0)
      split_ifs <;> ring }

@[simp]
lemma coordProj_apply (m r : ℕ) (x : EuclideanSpace ℝ (Fin m)) (j : Fin m) :
    coordProj m r x j = if j.val < r then x j else 0 :=
  rfl

lemma norm_coordProj_le (m r : ℕ) (x : EuclideanSpace ℝ (Fin m)) :
    ‖coordProj m r x‖ ≤ ‖x‖ := by
  have hsq : ‖coordProj m r x‖ ^ 2 ≤ ‖x‖ ^ 2 := by
    rw [UL.Proof_lem_A_3.norm_sq_eq_sum, UL.Proof_lem_A_3.norm_sq_eq_sum]
    refine Finset.sum_le_sum fun j _ => ?_
    rw [coordProj_apply]
    split_ifs
    · exact le_rfl
    · simp [sq_nonneg]
  nlinarith [norm_nonneg (coordProj m r x), norm_nonneg x]

lemma finrank_range_comp_coordProj_le {m : ℕ} {E : Type*}
    [AddCommGroup E] [Module ℝ E] [FiniteDimensional ℝ E]
    {r : ℕ} (hr_m : r ≤ m)
    (L_map : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] E) :
    Module.finrank ℝ (LinearMap.range (L_map.comp (coordProj m r))) ≤ r := by
  classical
  let g : Fin r → E := fun i => L_map (EuclideanSpace.single ⟨i.val, by omega⟩ (1 : ℝ))
  let S_img : Finset E := Finset.univ.image g
  have h_sub : LinearMap.range (L_map.comp (coordProj m r)) ≤ Submodule.span ℝ (S_img : Set E) := by
    rintro _ ⟨x, rfl⟩
    have hx_eq : coordProj m r x =
        ∑ i : Fin r, x ⟨i.val, by omega⟩ • EuclideanSpace.single ⟨i.val, by omega⟩ (1 : ℝ) := by
      ext k
      rw [coordProj_apply, UL.Proof_lem_A_3.sum_apply]
      simp only [PiLp.smul_apply, smul_eq_mul, EuclideanSpace.single_apply, mul_ite,
        mul_one, mul_zero]
      by_cases hk : k.val < r
      · rw [if_pos hk, Finset.sum_eq_single ⟨k.val, hk⟩]
        · simp
        · intro i _ hne
          have hne_k : k ≠ ⟨i.val, by omega⟩ := fun h =>
            hne (Fin.ext (by simpa using (congrArg Fin.val h).symm))
          simp [hne_k]
        · intro habs
          exact False.elim (habs (Finset.mem_univ _))
      · rw [if_neg hk]
        refine (Finset.sum_eq_zero fun i _ => ?_).symm
        have hne_k : k ≠ ⟨i.val, by omega⟩ := fun h => hk (by rw [h]; exact i.isLt)
        simp [hne_k]
    change L_map (coordProj m r x) ∈ Submodule.span ℝ (S_img : Set E)
    rw [hx_eq, map_sum]
    refine Submodule.sum_mem _ fun i _ => ?_
    rw [map_smul]
    exact Submodule.smul_mem _ _
      (Submodule.subset_span (Finset.mem_coe.mpr (Finset.mem_image_of_mem g (Finset.mem_univ i))))
  calc Module.finrank ℝ (LinearMap.range (L_map.comp (coordProj m r)))
      ≤ Module.finrank ℝ (Submodule.span ℝ (S_img : Set E)) := Submodule.finrank_mono h_sub
    _ ≤ S_img.card := finrank_span_finset_le_card S_img
    _ ≤ (Finset.univ : Finset (Fin r)).card := Finset.card_image_le
    _ = r := Finset.card_fin r

private lemma frobeniusNorm_scale_iso_coordProj {K m r : ℕ} (hr1 : 1 ≤ r) (hr_m : r ≤ m)
    {R : ℝ} (hR : 0 < R) (U : EuclideanSpace ℝ (Fin m) ≃ₗᵢ[ℝ] UL.ZeroSumSubspace K) :
    UL.frobeniusNorm (((R / Real.sqrt (r : ℝ)) • U.toLinearIsometry.toLinearMap).comp
      (coordProj m r)) ≤ R := by
  have hr_pos : (0 : ℝ) < (r : ℝ) := by exact_mod_cast hr1
  have hsr_pos : 0 < Real.sqrt (r : ℝ) := Real.sqrt_pos.mpr hr_pos
  have hscale_pos : 0 < R / Real.sqrt (r : ℝ) := div_pos hR hsr_pos
  set W := ((R / Real.sqrt (r : ℝ)) • U.toLinearIsometry.toLinearMap).comp (coordProj m r)
  unfold UL.frobeniusNorm
  have hterm : ∀ i : Fin m,
      ‖W (EuclideanSpace.single i (1 : ℝ))‖ ^ 2 =
        if i.val < r then (R / Real.sqrt (r : ℝ)) ^ 2 else 0 := by
    intro i
    have hPr : coordProj m r (EuclideanSpace.single i (1 : ℝ)) =
        if i.val < r then EuclideanSpace.single i (1 : ℝ) else 0 := by
      ext k
      rw [coordProj_apply]
      by_cases hi : i.val < r
      · rw [if_pos hi]
        by_cases hki : k = i
        · subst hki; rw [if_pos hi]
        · simp [EuclideanSpace.single_apply, hki]
      · rw [if_neg hi]
        by_cases hki : k = i
        · subst hki; rw [if_neg hi]; simp
        · simp [EuclideanSpace.single_apply, hki]
    have hW_app : W (EuclideanSpace.single i (1 : ℝ)) =
        (R / Real.sqrt (r : ℝ)) • U (coordProj m r (EuclideanSpace.single i (1 : ℝ))) := rfl
    rw [hW_app, hPr]
    split_ifs with hi
    · rw [norm_smul, Real.norm_eq_abs, abs_of_pos hscale_pos,
        U.norm_map, EuclideanSpace.norm_single, norm_one, mul_one]
    · simp
  simp_rw [hterm]
  rw [sum_fin_split_lt hr_m]
  have h1 : ∑ i : Fin r, (if (⟨i.val, by omega⟩ : Fin m).val < r then
      (R / Real.sqrt (r : ℝ)) ^ 2 else 0) = R ^ 2 := by
    have hall : ∀ i : Fin r, (if (⟨i.val, by omega⟩ : Fin m).val < r then
        (R / Real.sqrt (r : ℝ)) ^ 2 else 0) = (R / Real.sqrt (r : ℝ)) ^ 2 :=
      fun i => if_pos i.isLt
    simp_rw [hall]
    rw [Finset.sum_const, Finset.card_fin, nsmul_eq_mul, div_pow,
      Real.sq_sqrt hr_pos.le, mul_div_cancel₀ _ hr_pos.ne']
  have h2 : ∑ i : Fin (m - r), (if (⟨r + i.val, by omega⟩ : Fin m).val < r then
      (R / Real.sqrt (r : ℝ)) ^ 2 else 0) = 0 := by
    refine Finset.sum_eq_zero fun i _ => if_neg ?_
    dsimp; omega
  rw [h1, h2, add_zero, Real.sqrt_sq hR.le]

private lemma attainment_l2_of_iso {K m r : ℕ} (hK : 2 ≤ K) (hm1 : 1 ≤ m)
    (hr1 : 1 ≤ r) (hr_m : r ≤ m)
    {R L B c : ℝ} (hR : 0 < R) (hL : 0 < L) (hB : 0 ≤ B) (hc_pos : 0 < c)
    (hfloor : 0 < 1 / (K : ℝ) - c * L)
    (U : EuclideanSpace ℝ (Fin m) ≃ₗᵢ[ℝ] UL.ZeroSumSubspace K)
    (eta : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin K))
    (h_eta : ∀ x ∈ Metric.closedBall (0 : EuclideanSpace ℝ (Fin m)) L,
      eta x = UL.uniformVec K + c • ((U x : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))) :
    ∃ (W : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] UL.ZeroSumSubspace K)
      (ρ : UL.ZeroSumSubspace K → UL.Simplex K)
      (A_aff : EuclideanSpace ℝ (Fin m) →ᵃ[ℝ] EuclideanSpace ℝ (Fin K))
      (K_lip : NNReal),
      Module.finrank ℝ (LinearMap.range W) ≤ r ∧
      UL.frobeniusNorm W ≤ R ∧
      LipschitzWith (Real.toNNReal B) ρ ∧
      LipschitzWith K_lip (ρ ∘ W) ∧
      (∀ x ∈ Metric.closedBall (0 : EuclideanSpace ℝ (Fin m)) L,
        (∀ j : Fin K, 0 < ((ρ ∘ W) x : EuclideanSpace ℝ (Fin K)) j) ∧
        (ρ (W x) : EuclideanSpace ℝ (Fin K)) = A_aff x) ∧
      ∫ x, ‖((ρ ∘ W) x : EuclideanSpace ℝ (Fin K)) - eta x‖ ^ 2
        ∂(ballUniformMeasure m L) =
        (L ^ 2 / ((m : ℝ) + 2)) *
          (((m : ℝ) - (r : ℝ)) * c ^ 2 +
            (r : ℝ) * (max (c - B * R / Real.sqrt (r : ℝ)) 0) ^ 2) := by
  have hr_pos : (0 : ℝ) < (r : ℝ) := by exact_mod_cast hr1
  have hsr_pos : 0 < Real.sqrt (r : ℝ) := Real.sqrt_pos.mpr hr_pos
  let Pr := coordProj m r
  let W : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] UL.ZeroSumSubspace K :=
    ((R / Real.sqrt (r : ℝ)) • U.toLinearIsometry.toLinearMap).comp Pr
  have hW_rk : Module.finrank ℝ (LinearMap.range W) ≤ r :=
    finrank_range_comp_coordProj_le hr_m _
  have hW_fr : UL.frobeniusNorm W ≤ R :=
    frobeniusNorm_scale_iso_coordProj hr1 hr_m hR U
  let a : ℝ := min c (B * R / Real.sqrt (r : ℝ))
  have ha_nn : 0 ≤ a := le_min hc_pos.le (by positivity)
  have ha_le_c : a ≤ c := min_le_left _ _
  have ha_le_BR : a ≤ B * R / Real.sqrt (r : ℝ) := min_le_right _ _
  let κ : ℝ := a * Real.sqrt (r : ℝ) / R
  have hκ_nn : 0 ≤ κ := by dsimp [κ]; positivity
  have hκ_le_B : κ ≤ B := by
    dsimp [κ]
    rw [div_le_iff₀ hR]
    have hmul := (le_div_iff₀ hsr_pos).mp ha_le_BR
    linarith
  let ρ : UL.ZeroSumSubspace K → UL.Simplex K := fun s =>
    ⟨UL.Proof_lem_A_3.projSimplexDef K
        (UL.uniformVec K + κ • (s : EuclideanSpace ℝ (Fin K))),
      UL.Proof_lem_A_3.projSimplex_mem hK _⟩
  have hρ_lip : LipschitzWith (Real.toNNReal B) ρ := by
    rw [lipschitzWith_iff_dist_le_mul]
    intro s₁ s₂
    rw [Subtype.dist_eq, dist_eq_norm, dist_eq_norm, Real.coe_toNNReal B hB]
    calc ‖UL.Proof_lem_A_3.projSimplexDef K
            (UL.uniformVec K + κ • (s₁ : EuclideanSpace ℝ (Fin K))) -
          UL.Proof_lem_A_3.projSimplexDef K
            (UL.uniformVec K + κ • (s₂ : EuclideanSpace ℝ (Fin K)))‖
        ≤ ‖(UL.uniformVec K + κ • (s₁ : EuclideanSpace ℝ (Fin K))) -
            (UL.uniformVec K + κ • (s₂ : EuclideanSpace ℝ (Fin K)))‖ :=
          UL.Proof_lem_A_3.projSimplex_nonexpansive hK _ _
      _ = ‖κ • ((s₁ - s₂ : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))‖ := by
          congr 1; ext j; simp [smul_sub]
      _ = κ * ‖s₁ - s₂‖ := by
          rw [norm_smul, Real.norm_eq_abs, abs_of_nonneg hκ_nn, Submodule.norm_coe]
      _ ≤ B * ‖s₁ - s₂‖ := mul_le_mul_of_nonneg_right hκ_le_B (norm_nonneg _)
  have hW_lip : LipschitzWith (Real.toNNReal (R / Real.sqrt (r : ℝ))) W := by
    rw [lipschitzWith_iff_dist_le_mul]
    intro x₁ x₂
    have hsc_pos : 0 < R / Real.sqrt (r : ℝ) := div_pos hR hsr_pos
    rw [dist_eq_norm, dist_eq_norm, Real.coe_toNNReal _ hsc_pos.le, ← map_sub]
    have hW_sub : W (x₁ - x₂) = (R / Real.sqrt (r : ℝ)) • U (Pr (x₁ - x₂)) := rfl
    rw [hW_sub, norm_smul, Real.norm_eq_abs, abs_of_pos hsc_pos, U.norm_map]
    exact mul_le_mul_of_nonneg_left (norm_coordProj_le m r (x₁ - x₂)) hsc_pos.le
  let K_lip : NNReal := Real.toNNReal B * Real.toNNReal (R / Real.sqrt (r : ℝ))
  have hcomp_lip : LipschitzWith K_lip (ρ ∘ W) := hρ_lip.comp hW_lip
  let L_aff : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] EuclideanSpace ℝ (Fin K) :=
    a • ((UL.ZeroSumSubspace K).subtype.comp (U.toLinearIsometry.toLinearMap.comp Pr))
  let A_aff : EuclideanSpace ℝ (Fin m) →ᵃ[ℝ] EuclideanSpace ℝ (Fin K) :=
    { toFun := fun x => UL.uniformVec K + L_aff x
      linear := L_aff
      map_vadd' := fun p v => by
        simp only [vadd_eq_add, map_add]
        abel }
  have hρ_coe : ∀ s : UL.ZeroSumSubspace K,
      (ρ s : EuclideanSpace ℝ (Fin K)) =
        UL.Proof_lem_A_3.projSimplexDef K
          (UL.uniformVec K + κ • (s : EuclideanSpace ℝ (Fin K))) :=
    fun _ => rfl
  have hL_aff_eq : ∀ y : EuclideanSpace ℝ (Fin m),
      L_aff y = a • ((U (Pr y) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) :=
    fun _ => rfl
  have hA_aff_eq : ∀ y : EuclideanSpace ℝ (Fin m),
      A_aff y = UL.uniformVec K +
        a • ((U (Pr y) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) :=
    fun _ => rfl
  have hW_coe_eq : ∀ y : EuclideanSpace ℝ (Fin m),
      (W y : EuclideanSpace ℝ (Fin K)) =
        (R / Real.sqrt (r : ℝ)) •
          ((U (Pr y) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) :=
    fun y => Submodule.coe_smul_of_tower (R / Real.sqrt (r : ℝ)) (U (Pr y))
  have h_ball_pos_and_aff :
      ∀ x ∈ Metric.closedBall (0 : EuclideanSpace ℝ (Fin m)) L,
        (∀ j : Fin K, 0 < ((ρ ∘ W) x : EuclideanSpace ℝ (Fin K)) j) ∧
        (ρ (W x) : EuclideanSpace ℝ (Fin K)) = A_aff x := by
    intro x hx
    have hx_norm : ‖x‖ ≤ L := by simpa [Metric.mem_closedBall, dist_zero_right] using hx
    have hL_norm : ‖L_aff x‖ ≤ c * L := by
      rw [hL_aff_eq x, norm_smul, Real.norm_eq_abs, abs_of_nonneg ha_nn,
        Submodule.norm_coe, U.norm_map]
      exact mul_le_mul ha_le_c ((norm_coordProj_le m r x).trans hx_norm) (norm_nonneg _) hc_pos.le
    have hpos : ∀ j : Fin K, 0 < A_aff x j := by
      intro j
      have hj_abs : |L_aff x j| ≤ c * L :=
        (UL.Proof_lem_A_3.coord_abs_le_norm (L_aff x) j).trans hL_norm
      have hAj : A_aff x j = UL.uniformVec K j + L_aff x j := rfl
      rw [hAj, UL.Proof_lem_A_5.uniformVec_apply]
      linarith [(abs_le.mp hj_abs).1]
    have hmem : A_aff x ∈ UL.Simplex K := by
      refine ⟨fun j => (hpos j).le, ?_⟩
      rw [hA_aff_eq x]
      have hz : ∑ j : Fin K, ((U (Pr x) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) j = 0 :=
        (UL.Proof_lem_A_5.mem_zeroSumSubspace_iff K _).mp (U (Pr x)).2
      simp only [PiLp.add_apply, PiLp.smul_apply, smul_eq_mul, Finset.sum_add_distrib,
        ← Finset.mul_sum, UL.Proof_lem_A_5.sum_uniformVec hK, hz, mul_zero, add_zero]
    have hκR : κ * (R / Real.sqrt (r : ℝ)) = a := by
      dsimp [κ]
      field_simp [hR.ne', hsr_pos.ne']
    have hκW : UL.uniformVec K + κ • (W x : EuclideanSpace ℝ (Fin K)) = A_aff x := by
      rw [hW_coe_eq x, hA_aff_eq x, smul_smul, hκR]
    have heq : (ρ (W x) : EuclideanSpace ℝ (Fin K)) = A_aff x :=
      (hρ_coe (W x)).trans
        ((congrArg (UL.Proof_lem_A_3.projSimplexDef K) hκW).trans
          (UL.Proof_lem_A_3.projSimplex_eq_self hK hmem))
    refine ⟨fun j => ?_, heq⟩
    dsimp only [Function.comp_apply]
    rw [heq]
    exact hpos j
  have h_int_eq :
      ∫ x, ‖((ρ ∘ W) x : EuclideanSpace ℝ (Fin K)) - eta x‖ ^ 2
        ∂(ballUniformMeasure m L) =
      (L ^ 2 / ((m : ℝ) + 2)) *
        (((m : ℝ) - (r : ℝ)) * c ^ 2 +
          (r : ℝ) * (max (c - B * R / Real.sqrt (r : ℝ)) 0) ^ 2) := by
    have h_ae_norm :
        (fun x : EuclideanSpace ℝ (Fin m) =>
          ‖((ρ ∘ W) x : EuclideanSpace ℝ (Fin K)) - eta x‖ ^ 2) =ᵐ[ballUniformMeasure m L]
        fun x => ∑ j : Fin m, (if j.val < r then (c - a) ^ 2 else c ^ 2) * (x j) ^ 2 := by
      filter_upwards [ae_mem_ball_ballUniformMeasure m L] with x hx
      have hx_cl := Metric.ball_subset_closedBall hx
      dsimp only [Function.comp_apply]
      rw [(h_ball_pos_and_aff x hx_cl).2, h_eta x hx_cl]
      have hU_lin :
          ((U (a • Pr x - c • x) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) =
          a • ((U (Pr x) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) -
            c • ((U x : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) := by
        rw [U.map_sub, U.map_smul, U.map_smul, Submodule.coe_sub]
        exact congrArg₂ HSub.hSub
          (Submodule.coe_smul_of_tower a (U (Pr x)))
          (Submodule.coe_smul_of_tower c (U x))
      have hdiff_coe : A_aff x -
          (UL.uniformVec K + c • ((U x : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))) =
          ((U (a • Pr x - c • x) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) := by
        rw [hA_aff_eq x, hU_lin]
        exact add_sub_add_left_eq_sub _ _ _
      rw [hdiff_coe, Submodule.norm_coe, U.norm_map, UL.Proof_lem_A_3.norm_sq_eq_sum]
      refine Finset.sum_congr rfl fun j _ => ?_
      simp only [Pr, PiLp.sub_apply, PiLp.smul_apply, smul_eq_mul, coordProj_apply]
      split_ifs <;> ring
    have hint_xsq : ∀ j : Fin m,
        Integrable (fun x : EuclideanSpace ℝ (Fin m) =>
          (if j.val < r then (c - a) ^ 2 else c ^ 2) * (x j) ^ 2)
          (ballUniformMeasure m L) := fun j =>
      (integrable_of_continuous_ballUniformMeasure hL
        (g := fun x : EuclideanSpace ℝ (Fin m) => (x j) ^ 2)
        (((EuclideanSpace.proj j).continuous).pow 2)).const_mul _
    rw [integral_congr_ae h_ae_norm, integral_finset_sum Finset.univ fun j _ => hint_xsq j]
    have hterm : ∀ j : Fin m,
        ∫ x, (if j.val < r then (c - a) ^ 2 else c ^ 2) * (x j) ^ 2
          ∂(ballUniformMeasure m L) =
        (if j.val < r then (c - a) ^ 2 else c ^ 2) * (L ^ 2 / ((m : ℝ) + 2)) := by
      intro j
      rw [integral_const_mul, integral_coord_sq_ballUniformMeasure hm1 hL j]
    simp_rw [hterm, ← Finset.sum_mul,
      sum_fin_split_lt hr_m (fun j => if j.val < r then (c - a) ^ 2 else c ^ 2)]
    have hs1 : ∑ i : Fin r, (if (⟨i.val, by omega⟩ : Fin m).val < r then
        (c - a) ^ 2 else c ^ 2) = (r : ℝ) * (c - a) ^ 2 := by
      have hall : ∀ i : Fin r, (if (⟨i.val, by omega⟩ : Fin m).val < r then
          (c - a) ^ 2 else c ^ 2) = (c - a) ^ 2 := fun i => if_pos i.isLt
      simp_rw [hall]
      rw [Finset.sum_const, Finset.card_fin, nsmul_eq_mul]
    have hs2 : ∑ i : Fin (m - r), (if (⟨r + i.val, by omega⟩ : Fin m).val < r then
        (c - a) ^ 2 else c ^ 2) = ((m : ℝ) - (r : ℝ)) * c ^ 2 := by
      have hall : ∀ i : Fin (m - r), (if (⟨r + i.val, by omega⟩ : Fin m).val < r then
          (c - a) ^ 2 else c ^ 2) = c ^ 2 :=
        fun i => if_neg (by dsimp; omega)
      simp_rw [hall]
      rw [Finset.sum_const, Finset.card_fin, nsmul_eq_mul, Nat.cast_sub hr_m]
    have h_ca : c - a = max (c - B * R / Real.sqrt (r : ℝ)) 0 := by
      dsimp [a]
      by_cases hle : c ≤ B * R / Real.sqrt (r : ℝ)
      · rw [min_eq_left hle, sub_self, max_eq_right (by linarith)]
      · push_neg at hle
        rw [min_eq_right hle.le, max_eq_left (by linarith)]
    rw [hs1, hs2, h_ca]
    ring
  exact ⟨W, ρ, A_aff, K_lip, hW_rk, hW_fr, hρ_lip, hcomp_lip, h_ball_pos_and_aff, h_int_eq⟩

theorem joint_tradeoff_pos_rank {K : ℕ} (hK : 2 ≤ K) {R β L : ℝ}
    (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    (hcond : β * R * L / Real.sqrt ((K : ℝ) - 1) < 1 / (K : ℝ))
    {r : ℕ} (hr1 : 1 ≤ r) (hr_m : r ≤ K - 1) {B : ℝ} (hB : 0 ≤ B) :
    let m : ℕ := K - 1
    let P := jointMeasureP m K L (etaMap K hK R β L)
    let Φ := phiBeta K β
    let bench : EReal := ⨅ V ∈ UL.ComparatorBall m K R,
      UL.expectedMatchingLoss P Prod.fst Prod.snd Φ V
    let regret : (EuclideanSpace ℝ (Fin m) → UL.Simplex K) → EReal :=
      fun p => UL.expectedCanonicalLoss P Prod.fst Prod.snd Φ p - bench
    let c : ℝ := β * R / Real.sqrt (m : ℝ)
    let val : ℝ :=
      (L ^ 2 / (2 * β * ((m : ℝ) + 2))) *
        (((m : ℝ) - (r : ℝ)) * c ^ 2 +
          (r : ℝ) * (max (c - B * R / Real.sqrt (r : ℝ)) 0) ^ 2)
    (∀ (W : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] UL.ZeroSumSubspace K)
       (ρ : UL.ZeroSumSubspace K → UL.Simplex K),
      Module.finrank ℝ (LinearMap.range W) ≤ r →
      UL.frobeniusNorm W ≤ R →
      LipschitzWith (Real.toNNReal B) ρ →
      (val : EReal) ≤ regret (ρ ∘ W)) ∧
    (⨅ (W : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] UL.ZeroSumSubspace K)
       (_ : Module.finrank ℝ (LinearMap.range W) ≤ r)
       (_ : UL.frobeniusNorm W ≤ R)
       (ρ : UL.ZeroSumSubspace K → UL.Simplex K)
       (_ : LipschitzWith (Real.toNNReal B) ρ),
      regret (ρ ∘ W)) = (val : EReal) ∧
    (∃ (W : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] UL.ZeroSumSubspace K)
       (ρ : UL.ZeroSumSubspace K → UL.Simplex K)
       (A_aff : EuclideanSpace ℝ (Fin m) →ᵃ[ℝ] EuclideanSpace ℝ (Fin K))
       (K_lip : NNReal),
      Module.finrank ℝ (LinearMap.range W) ≤ r ∧
      UL.frobeniusNorm W ≤ R ∧
      LipschitzWith (Real.toNNReal B) ρ ∧
      LipschitzWith K_lip (ρ ∘ W) ∧
      (∀ x ∈ Metric.closedBall (0 : EuclideanSpace ℝ (Fin m)) L,
        (ρ (W x) : EuclideanSpace ℝ (Fin K)) = A_aff x) ∧
      regret (ρ ∘ W) = (val : EReal)) := by
  intro m P Φ bench regret c val
  have hlb : ∀ (W : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] UL.ZeroSumSubspace K)
      (ρ : UL.ZeroSumSubspace K → UL.Simplex K),
      Module.finrank ℝ (LinearMap.range W) ≤ r →
      UL.frobeniusNorm W ≤ R →
      LipschitzWith (Real.toNNReal B) ρ →
      (val : EReal) ≤ regret (ρ ∘ W) := by
    intro W ρ hr_rk hW_fr hρ_lip
    have hp_cont : Continuous (ρ ∘ W) :=
      hρ_lip.continuous.comp W.continuous_of_finiteDimensional
    have h_l2_reg := l2_le_regret hK hR hβ hL hcond hp_cont
    obtain ⟨σ, hσ_nn, hσ_sum, h_pre⟩ :=
      pre_jensen_l2_lower_bound hK hR hβ hL hr_m hB W ρ hr_rk hW_fr hρ_lip
    have h_jen := algebraic_slope_jensen hr1 hB hR.le (c := c) hσ_nn hσ_sum
    have h_real_le : val ≤ (1 / (2 * β)) *
        ∫ x, ‖((ρ ∘ W) x : EuclideanSpace ℝ (Fin K)) - etaMap K hK R β L x‖ ^ 2
          ∂(ballUniformMeasure m L) := by
      have hv_nn : 0 ≤ L ^ 2 / ((m : ℝ) + 2) := by positivity
      have h1 : (L ^ 2 / ((m : ℝ) + 2)) *
          (((m : ℝ) - (r : ℝ)) * c ^ 2 +
            (r : ℝ) * (max (c - B * R / Real.sqrt (r : ℝ)) 0) ^ 2) ≤
          ∫ x, ‖((ρ ∘ W) x : EuclideanSpace ℝ (Fin K)) - etaMap K hK R β L x‖ ^ 2
            ∂(ballUniformMeasure m L) := by
        have hc_eq : slopeParam K R β = c := rfl
        rw [hc_eq] at h_pre
        exact (mul_le_mul_of_nonneg_left (add_le_add le_rfl h_jen) hv_nn).trans h_pre
      calc val
          = (1 / (2 * β)) * ((L ^ 2 / ((m : ℝ) + 2)) *
              (((m : ℝ) - (r : ℝ)) * c ^ 2 +
                (r : ℝ) * (max (c - B * R / Real.sqrt (r : ℝ)) 0) ^ 2)) := by
            have hm2_ne : ((m : ℝ) + 2) ≠ 0 := by positivity
            dsimp only [val]
            field_simp [hβ.ne', hm2_ne]
        _ ≤ (1 / (2 * β)) *
              ∫ x, ‖((ρ ∘ W) x : EuclideanSpace ℝ (Fin K)) - etaMap K hK R β L x‖ ^ 2
                ∂(ballUniformMeasure m L) :=
            mul_le_mul_of_nonneg_left h1 (by positivity)
    exact (EReal.coe_le_coe_iff.mpr h_real_le).trans h_l2_reg
  have hatt : ∃ (W : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] UL.ZeroSumSubspace K)
      (ρ : UL.ZeroSumSubspace K → UL.Simplex K)
      (A_aff : EuclideanSpace ℝ (Fin m) →ᵃ[ℝ] EuclideanSpace ℝ (Fin K))
      (K_lip : NNReal),
      Module.finrank ℝ (LinearMap.range W) ≤ r ∧
      UL.frobeniusNorm W ≤ R ∧
      LipschitzWith (Real.toNNReal B) ρ ∧
      LipschitzWith K_lip (ρ ∘ W) ∧
      (∀ x ∈ Metric.closedBall (0 : EuclideanSpace ℝ (Fin m)) L,
        (ρ (W x) : EuclideanSpace ℝ (Fin K)) = A_aff x) ∧
      regret (ρ ∘ W) = (val : EReal) := by
    have hm1 : 1 ≤ m := by omega
    have hc_pos : 0 < c := slopeParam_pos hK hR hβ
    have hfloor : 0 < 1 / (K : ℝ) - c * L := etaFloor_pos hK hcond
    have h_eta : ∀ x ∈ Metric.closedBall (0 : EuclideanSpace ℝ (Fin m)) L,
        etaMap K hK R β L x = UL.uniformVec K +
          c • ((zeroSumIso K hK x : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) :=
      fun x hx => etaMap_eq_on_closedBall K hK R β hL hx
    obtain ⟨W, ρ, A_aff, K_lip, hW_rk, hW_fr, hρ_lip, hcomp_lip, hball, h_int_eq⟩ :=
      attainment_l2_of_iso hK hm1 hr1 hr_m hR hL hB hc_pos hfloor
        (zeroSumIso K hK) (etaMap K hK R β L) h_eta
    have hp_cont : Continuous (ρ ∘ W) := hcomp_lip.continuous
    have h_ae_pos : ∀ᵐ x ∂(ballUniformMeasure m L),
        ∀ y : Fin K, 0 < ((ρ ∘ W) x : EuclideanSpace ℝ (Fin K)) y := by
      filter_upwards [ae_mem_ball_ballUniformMeasure m L] with x hx
      exact (hball x (Metric.ball_subset_closedBall hx)).1
    have h_reg : regret (ρ ∘ W) = (val : EReal) := by
      have h_l2_val :
          (((1 / (2 * β)) *
            ∫ x, ‖((ρ ∘ W) x : EuclideanSpace ℝ (Fin K)) - etaMap K hK R β L x‖ ^ 2
              ∂(ballUniformMeasure m L) : ℝ) : EReal) = (val : EReal) := by
        rw [EReal.coe_eq_coe_iff, h_int_eq]
        have hm2_ne : ((m : ℝ) + 2) ≠ 0 := by positivity
        dsimp only [val]
        field_simp [hβ.ne', hm2_ne]
      exact (regret_eq_l2_of_ae_pos hK hR hβ hL hcond hp_cont h_ae_pos).trans h_l2_val
    exact ⟨W, ρ, A_aff, K_lip, hW_rk, hW_fr, hρ_lip, hcomp_lip,
      fun x hx => (hball x hx).2, h_reg⟩
  refine ⟨hlb, ?_, hatt⟩
  rcases hatt with ⟨W₀, ρ₀, _, _, hW₀_rk, hW₀_fr, hρ₀_lip, _, _, hreg₀⟩
  refine le_antisymm ?_ ?_
  · rw [← hreg₀]
    exact iInf_le_of_le W₀ (iInf_le_of_le hW₀_rk
      (iInf_le_of_le hW₀_fr (iInf_le_of_le ρ₀ (iInf_le _ hρ₀_lip))))
  · exact le_iInf fun W => le_iInf fun hrk => le_iInf fun hfr =>
      le_iInf fun ρ => le_iInf fun hlip => hlb W ρ hrk hfr hlip

theorem joint_tradeoff_zero_rank {K : ℕ} (hK : 2 ≤ K) {R β L : ℝ}
    (hR : 0 < R) (hβ : 0 < β) (hL : 0 < L)
    (hcond : β * R * L / Real.sqrt ((K : ℝ) - 1) < 1 / (K : ℝ))
    {B : ℝ} (hB : 0 ≤ B) :
    let m : ℕ := K - 1
    let P := jointMeasureP m K L (etaMap K hK R β L)
    let Φ := phiBeta K β
    let bench : EReal := ⨅ V ∈ UL.ComparatorBall m K R,
      UL.expectedMatchingLoss P Prod.fst Prod.snd Φ V
    let regret : (EuclideanSpace ℝ (Fin m) → UL.Simplex K) → EReal :=
      fun p => UL.expectedCanonicalLoss P Prod.fst Prod.snd Φ p - bench
    let c : ℝ := β * R / Real.sqrt (m : ℝ)
    let val₀ : ℝ := L ^ 2 * (m : ℝ) * c ^ 2 / (2 * β * ((m : ℝ) + 2))
    (∀ (W : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] UL.ZeroSumSubspace K)
       (ρ : UL.ZeroSumSubspace K → UL.Simplex K),
      Module.finrank ℝ (LinearMap.range W) ≤ 0 →
      UL.frobeniusNorm W ≤ R →
      LipschitzWith (Real.toNNReal B) ρ →
      (val₀ : EReal) ≤ regret (ρ ∘ W)) ∧
    (⨅ (W : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] UL.ZeroSumSubspace K)
       (_ : Module.finrank ℝ (LinearMap.range W) ≤ 0)
       (_ : UL.frobeniusNorm W ≤ R)
       (ρ : UL.ZeroSumSubspace K → UL.Simplex K)
       (_ : LipschitzWith (Real.toNNReal B) ρ),
      regret (ρ ∘ W)) = (val₀ : EReal) ∧
    (∃ (W : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] UL.ZeroSumSubspace K)
       (ρ : UL.ZeroSumSubspace K → UL.Simplex K)
       (A_aff : EuclideanSpace ℝ (Fin m) →ᵃ[ℝ] EuclideanSpace ℝ (Fin K))
       (K_lip : NNReal),
      Module.finrank ℝ (LinearMap.range W) ≤ 0 ∧
      UL.frobeniusNorm W ≤ R ∧
      LipschitzWith (Real.toNNReal B) ρ ∧
      LipschitzWith K_lip (ρ ∘ W) ∧
      (∀ x ∈ Metric.closedBall (0 : EuclideanSpace ℝ (Fin m)) L,
        (ρ (W x) : EuclideanSpace ℝ (Fin K)) = A_aff x) ∧
      regret (ρ ∘ W) = (val₀ : EReal)) := by
  intro m P Φ bench regret c val₀
  have hlb : ∀ (W : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] UL.ZeroSumSubspace K)
      (ρ : UL.ZeroSumSubspace K → UL.Simplex K),
      Module.finrank ℝ (LinearMap.range W) ≤ 0 →
      UL.frobeniusNorm W ≤ R →
      LipschitzWith (Real.toNNReal B) ρ →
      (val₀ : EReal) ≤ regret (ρ ∘ W) := by
    intro W ρ hr_rk hW_fr hρ_lip
    have hp_cont : Continuous (ρ ∘ W) :=
      hρ_lip.continuous.comp W.continuous_of_finiteDimensional
    have h_l2_reg := l2_le_regret hK hR hβ hL hcond hp_cont
    obtain ⟨σ, _, _, h_pre⟩ :=
      pre_jensen_l2_lower_bound hK hR hβ hL (Nat.zero_le m) hB W ρ hr_rk hW_fr hρ_lip
    have hc_eq : slopeParam K R β = c := rfl
    rw [hc_eq] at h_pre
    simp only [Nat.cast_zero, sub_zero, Finset.univ_eq_empty, Finset.sum_empty, add_zero] at h_pre
    have h_real_le : val₀ ≤ (1 / (2 * β)) *
        ∫ x, ‖((ρ ∘ W) x : EuclideanSpace ℝ (Fin K)) - etaMap K hK R β L x‖ ^ 2
          ∂(ballUniformMeasure m L) := by
      calc val₀
          = (1 / (2 * β)) * ((L ^ 2 / (((K - 1 : ℕ) : ℝ) + 2)) *
              (((K - 1 : ℕ) : ℝ) * c ^ 2)) := by
            have hm2_ne : (((K - 1 : ℕ) : ℝ) + 2) ≠ 0 := by positivity
            dsimp only [val₀, m]
            field_simp [hβ.ne', hm2_ne]
        _ ≤ (1 / (2 * β)) *
              ∫ x, ‖((ρ ∘ W) x : EuclideanSpace ℝ (Fin K)) - etaMap K hK R β L x‖ ^ 2
                ∂(ballUniformMeasure m L) :=
            mul_le_mul_of_nonneg_left h_pre (by positivity)
    exact (EReal.coe_le_coe_iff.mpr h_real_le).trans h_l2_reg
  have hatt : ∃ (W : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] UL.ZeroSumSubspace K)
      (ρ : UL.ZeroSumSubspace K → UL.Simplex K)
      (A_aff : EuclideanSpace ℝ (Fin m) →ᵃ[ℝ] EuclideanSpace ℝ (Fin K))
      (K_lip : NNReal),
      Module.finrank ℝ (LinearMap.range W) ≤ 0 ∧
      UL.frobeniusNorm W ≤ R ∧
      LipschitzWith (Real.toNNReal B) ρ ∧
      LipschitzWith K_lip (ρ ∘ W) ∧
      (∀ x ∈ Metric.closedBall (0 : EuclideanSpace ℝ (Fin m)) L,
        (ρ (W x) : EuclideanSpace ℝ (Fin K)) = A_aff x) ∧
      regret (ρ ∘ W) = (val₀ : EReal) := by
    let W₀ : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] UL.ZeroSumSubspace K := 0
    let u_simp : UL.Simplex K := ⟨UL.uniformVec K, UL.Proof_lem_A_5.uniformVec_mem_simplex hK⟩
    let ρ₀ : UL.ZeroSumSubspace K → UL.Simplex K := fun _ => u_simp
    let A_aff : EuclideanSpace ℝ (Fin m) →ᵃ[ℝ] EuclideanSpace ℝ (Fin K) :=
      { toFun := fun _ => UL.uniformVec K
        linear := 0
        map_vadd' := fun _ _ => by simp }
    have hW₀_rk : Module.finrank ℝ (LinearMap.range W₀) ≤ 0 := by simp [W₀]
    have hW₀_fr : UL.frobeniusNorm W₀ ≤ R := by
      unfold UL.frobeniusNorm
      simp [W₀, hR.le]
    have hρ₀_lip : LipschitzWith (Real.toNNReal B) ρ₀ :=
      (LipschitzWith.const u_simp).weaken (zero_le _)
    have hcomp_lip : LipschitzWith 0 (ρ₀ ∘ W₀) := LipschitzWith.const u_simp
    have h_reg : regret (ρ₀ ∘ W₀) = (val₀ : EReal) := by
      have hp_cont : Continuous (ρ₀ ∘ W₀) := continuous_const
      have hK_pos : (0 : ℝ) < (K : ℝ) := by exact_mod_cast (by omega : 0 < K)
      have h_ae_pos : ∀ᵐ x ∂(ballUniformMeasure m L),
          ∀ y : Fin K, 0 < ((ρ₀ ∘ W₀) x : EuclideanSpace ℝ (Fin K)) y :=
        Filter.Eventually.of_forall fun _ y => by
          change 0 < UL.uniformVec K y
          rw [UL.Proof_lem_A_5.uniformVec_apply]
          positivity
      dsimp only [regret, bench, P, Φ]
      rw [regret_eq_l2_of_ae_pos hK hR hβ hL hcond hp_cont h_ae_pos, EReal.coe_eq_coe_iff]
      have h_ae_norm :
          (fun x : EuclideanSpace ℝ (Fin m) =>
            ‖((ρ₀ ∘ W₀) x : EuclideanSpace ℝ (Fin K)) - etaMap K hK R β L x‖ ^ 2) =ᵐ[ballUniformMeasure m L]
          fun x => c ^ 2 * ‖x‖ ^ 2 := by
        filter_upwards [ae_mem_ball_ballUniformMeasure m L] with x hx
        have hx_cl := Metric.ball_subset_closedBall hx
        change ‖UL.uniformVec K - etaMap K hK R β L x‖ ^ 2 = c ^ 2 * ‖x‖ ^ 2
        rw [etaMap_eq_on_closedBall K hK R β hL hx_cl]
        have hc_eq : slopeParam K R β = c := rfl
        rw [hc_eq]
        have hsub : UL.uniformVec K -
            (UL.uniformVec K + c • ((zeroSumIso K hK x : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))) =
            (-c) • ((zeroSumIso K hK x : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) := by
          ext j; simp
        rw [hsub, norm_smul, Real.norm_eq_abs, Submodule.norm_coe, (zeroSumIso K hK).norm_map,
          mul_pow, abs_neg, sq_abs]
      rw [integral_congr_ae h_ae_norm, integral_const_mul,
        integral_norm_sq_ballUniformMeasure (K - 1) hL]
      have hm2_ne : (((K - 1 : ℕ) : ℝ) + 2) ≠ 0 := by positivity
      dsimp only [val₀, m]
      field_simp [hβ.ne', hm2_ne]
    exact ⟨W₀, ρ₀, A_aff, 0, hW₀_rk, hW₀_fr, hρ₀_lip, hcomp_lip, fun _ _ => rfl, h_reg⟩
  refine ⟨hlb, ?_, hatt⟩
  rcases hatt with ⟨W₀, ρ₀, _, _, hW₀_rk, hW₀_fr, hρ₀_lip, _, _, hreg₀⟩
  refine le_antisymm ?_ ?_
  · rw [← hreg₀]
    exact iInf_le_of_le W₀ (iInf_le_of_le hW₀_rk
      (iInf_le_of_le hW₀_fr (iInf_le_of_le ρ₀ (iInf_le _ hρ₀_lip))))
  · exact le_iInf fun W => le_iInf fun hrk => le_iInf fun hfr =>
      le_iInf fun ρ => le_iInf fun hlip => hlb W ρ hrk hfr hlip

end UL.Proof_thm_A_9

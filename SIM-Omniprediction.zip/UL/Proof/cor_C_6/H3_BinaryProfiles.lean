import Mathlib
import UL.Def.def_2_1
import UL.Def.def_3_binary
import UL.Def.def_5_smooth
import UL.Def.def_C_profiles
import UL.Proof.lem_C_2.H1_HilbertSchmidt
set_option autoImplicit false

namespace UL.Proof_cor_C_6

/-! ### Convex subgradient and binary entropy helpers -/

private lemma convexOn_subderiv_le
    {g : ℝ → ℝ} (hg_conv : ConvexOn ℝ (Set.Icc (0 : ℝ) 1) g)
    {p d : ℝ} (hp : p ∈ Set.Icc (0 : ℝ) 1) (hd : HasDerivAt g d p)
    {q : ℝ} (hq : q ∈ Set.Icc (0 : ℝ) 1) :
    d * (q - p) ≤ g q - g p := by
  let t : ℕ → ℝ := fun k => 1 / ((k : ℝ) + 2)
  have ht_pos : ∀ k : ℕ, 0 < t k := fun k => by dsimp [t]; positivity
  have ht_lt_one : ∀ k : ℕ, t k < 1 := by
    intro k
    dsimp [t]
    rw [div_lt_one (by positivity)]
    linarith [Nat.cast_nonneg (α := ℝ) k]
  have h_quot_le : ∀ k : ℕ, (t k)⁻¹ * (g (p + t k * (q - p)) - g p) ≤ g q - g p := by
    intro k
    have hk0 : 0 ≤ t k := (ht_pos k).le
    have hk1 : 0 ≤ 1 - t k := by linarith [ht_lt_one k]
    have hconv := hg_conv.2 hp hq hk1 hk0 (by ring)
    simp only [smul_eq_mul] at hconv
    have hpt : (1 - t k) * p + t k * q = p + t k * (q - p) := by ring
    rw [hpt] at hconv
    have hsub : g (p + t k * (q - p)) - g p ≤ t k * (g q - g p) := by linarith
    have hdiv : (g (p + t k * (q - p)) - g p) / t k ≤ g q - g p :=
      (div_le_iff₀ (ht_pos k)).mpr (by linarith)
    simpa [div_eq_inv_mul] using hdiv
  have h_aff : HasDerivAt (fun u : ℝ => p + u * (q - p)) (q - p) 0 := by
    simpa using ((hasDerivAt_id (0 : ℝ)).mul_const (q - p)).const_add p
  have h_comp : HasDerivAt (fun u : ℝ => g (p + u * (q - p))) (d * (q - p)) 0 := by
    have hp0 : p + (0 : ℝ) * (q - p) = p := by ring
    exact HasDerivAt.comp (0 : ℝ) (hp0.symm ▸ hd) h_aff
  have h_slope := hasDerivAt_iff_tendsto_slope_zero.mp h_comp
  have ht_lim : Filter.Tendsto t Filter.atTop (nhds 0) :=
    (tendsto_const_nhds (x := (1 : ℝ))).div_atTop
      (Filter.tendsto_atTop_add_const_right Filter.atTop 2 tendsto_natCast_atTop_atTop)
  have ht_nhds : Filter.Tendsto t Filter.atTop (nhdsWithin 0 ({0}ᶜ)) :=
    tendsto_nhdsWithin_of_tendsto_nhds_of_eventually_within t ht_lim
      (Filter.Eventually.of_forall fun k => (ht_pos k).ne')
  have h_seq := h_slope.comp ht_nhds
  have h_seq' : Filter.Tendsto (fun k : ℕ => (t k)⁻¹ * (g (p + t k * (q - p)) - g p))
      Filter.atTop (nhds (d * (q - p))) := by
    refine h_seq.congr fun k => ?_
    simp [Function.comp, smul_eq_mul]
  exact le_of_tendsto' h_seq' h_quot_le

private lemma hasDerivAt_phi_ext
    {U : Set ℝ} {φ_ext : ℝ → ℝ}
    (hU_open : IsOpen U) (hU_sub : Set.Icc (0 : ℝ) 1 ⊆ U)
    (hφ_diff : DifferentiableOn ℝ φ_ext U)
    {q : ℝ} (hq : q ∈ Set.Icc (0 : ℝ) 1) :
    HasDerivAt φ_ext (deriv φ_ext q) q :=
  ((hφ_diff q (hU_sub hq)).differentiableAt (hU_open.mem_nhds (hU_sub hq))).hasDerivAt

private lemma convexOn_strong_part
    {β : ℝ} {φ : Set.Icc (0 : ℝ) 1 → ℝ} {φ_ext : ℝ → ℝ}
    (hφ : φ ∈ UL.BinaryEntropyFamily β)
    (hφ_ext : ∀ q : Set.Icc (0 : ℝ) 1, φ_ext q = φ q) :
    ConvexOn ℝ (Set.Icc (0 : ℝ) 1) (fun q => φ_ext q - (1 / (2 * β)) * q ^ 2) := by
  have hconv := hφ.2.2.2
  have heq : ∀ z ∈ Set.Icc (0 : ℝ) 1,
      UL.extendUnitInterval φ z = φ_ext z := by
    intro z hz
    unfold UL.extendUnitInterval
    rw [dif_pos hz, ← hφ_ext ⟨z, hz⟩]
  refine ⟨convex_Icc 0 1, fun x hx y hy a b ha hb hab => ?_⟩
  have hxy : a • x + b • y ∈ Set.Icc (0 : ℝ) 1 := (convex_Icc 0 1) hx hy ha hb hab
  have h0 := hconv.2 hx hy ha hb hab
  dsimp only at h0 ⊢
  rwa [heq _ hxy, heq _ hx, heq _ hy] at h0

private lemma convexOn_phi_ext
    {β : ℝ} (hβ : 0 < β) {φ : Set.Icc (0 : ℝ) 1 → ℝ} {φ_ext : ℝ → ℝ}
    (hφ : φ ∈ UL.BinaryEntropyFamily β)
    (hφ_ext : ∀ q : Set.Icc (0 : ℝ) 1, φ_ext q = φ q) :
    ConvexOn ℝ (Set.Icc (0 : ℝ) 1) φ_ext := by
  have hF := convexOn_strong_part hφ hφ_ext
  refine ⟨convex_Icc 0 1, fun x hx y hy a b ha hb hab => ?_⟩
  have h0 := hF.2 hx hy ha hb hab
  simp only [smul_eq_mul] at h0 ⊢
  have hquad_diff : a * x ^ 2 + b * y ^ 2 - (a * x + b * y) ^ 2 = a * b * (x - y) ^ 2 := by
    have hb_eq : b = 1 - a := by linarith
    rw [hb_eq]
    ring
  have hquad_nn : 0 ≤ (1 / (2 * β)) * (a * x ^ 2 + b * y ^ 2 - (a * x + b * y) ^ 2) := by
    rw [hquad_diff]
    exact mul_nonneg (by positivity) (mul_nonneg (mul_nonneg ha hb) (sq_nonneg (x - y)))
  linarith

/-- Any `(1/β)`-strongly convex function on `[0, 1]` whose derivative on an open neighborhood `U`
is `lam`-Lipschitz on `[0, 1]` must satisfy `1 ≤ β * lam`. -/
theorem one_le_beta_mul_lam
    {β lam : ℝ} (_hβ : 0 < β) (_hlam : 0 < lam)
    {φ : Set.Icc (0 : ℝ) 1 → ℝ} {U : Set ℝ} {φ_ext : ℝ → ℝ}
    (_hφ : φ ∈ UL.BinaryEntropyFamily β)
    (_hU_open : IsOpen U)
    (_hU_sub : Set.Icc (0 : ℝ) 1 ⊆ U)
    (_hφ_ext : ∀ q : Set.Icc (0 : ℝ) 1, φ_ext q = φ q)
    (_hφ_diff : DifferentiableOn ℝ φ_ext U)
    (_hφ_lip : ∀ q ∈ Set.Icc (0 : ℝ) 1, ∀ q' ∈ Set.Icc (0 : ℝ) 1,
      |deriv φ_ext q - deriv φ_ext q'| ≤ lam * |q - q'|) :
    1 ≤ β * lam := by
  have hF_conv := convexOn_strong_part _hφ _hφ_ext
  let F : ℝ → ℝ := fun q => φ_ext q - (1 / (2 * β)) * q ^ 2
  have hF_deriv : ∀ q ∈ Set.Icc (0 : ℝ) 1,
      HasDerivAt F (deriv φ_ext q - q / β) q := by
    intro q hq
    have hquad : HasDerivAt (fun x : ℝ => (1 / (2 * β)) * x ^ 2) (q / β) q := by
      have hmul := (hasDerivAt_pow 2 q).const_mul (1 / (2 * β))
      convert hmul using 1
      field_simp [_hβ.ne']
      ring
    exact (hasDerivAt_phi_ext _hU_open _hU_sub _hφ_diff hq).sub hquad
  have h0 : (0 : ℝ) ∈ Set.Icc (0 : ℝ) 1 := ⟨le_rfl, zero_le_one⟩
  have h1 : (1 : ℝ) ∈ Set.Icc (0 : ℝ) 1 := ⟨zero_le_one, le_rfl⟩
  have hsub01 := convexOn_subderiv_le hF_conv h0 (hF_deriv 0 h0) h1
  have hsub10 := convexOn_subderiv_le hF_conv h1 (hF_deriv 1 h1) h0
  rw [zero_div] at hsub01
  have hdiff_ge : 1 / β ≤ deriv φ_ext 1 - deriv φ_ext 0 := by linarith
  have hlip10 := _hφ_lip 1 h1 0 h0
  have habs : deriv φ_ext 1 - deriv φ_ext 0 ≤ |deriv φ_ext 1 - deriv φ_ext 0| := le_abs_self _
  have h10_abs : |(1 : ℝ) - 0| = 1 := by norm_num
  rw [h10_abs, mul_one] at hlip10
  have h1b_le_lam : 1 / β ≤ lam := by linarith
  have hmul := mul_le_mul_of_nonneg_left h1b_le_lam _hβ.le
  have hcancel : β * (1 / β) = 1 := mul_one_div_cancel _hβ.ne'
  linarith

/-! ### Rank-one embedding into `ScoreProfileClass X 2` -/

private noncomputable def unitZeroSum2 : UL.ZeroSumSubspace 2 :=
  let c : ℝ := 1 / Real.sqrt 2
  let v₀ : EuclideanSpace ℝ (Fin 2) := (WithLp.equiv 2 (Fin 2 → ℝ)).symm ![c, -c]
  ⟨v₀, by
    change inner ℝ (UL.onesVec 2) v₀ = 0
    rw [PiLp.inner_apply, Fin.sum_univ_two]
    simp [UL.onesVec, v₀]⟩

private lemma norm_unitZeroSum2 : ‖unitZeroSum2‖ = 1 := by
  rw [← Submodule.norm_coe]
  have hsq : ‖(unitZeroSum2 : EuclideanSpace ℝ (Fin 2))‖ ^ 2 = 1 := by
    rw [EuclideanSpace.norm_sq_eq, Fin.sum_univ_two]
    simp [unitZeroSum2, Real.norm_eq_abs, div_pow, Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)]
    norm_num
  nlinarith [norm_nonneg (unitZeroSum2 : EuclideanSpace ℝ (Fin 2))]

private lemma rankOne_mem_scoreProfileClass
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {L R C_lip M₀ : ℝ}
    (hL : 0 < L) (hR : 0 < R) (hC : 0 < C_lip) (hM₀ : 0 < M₀)
    {u : X} (hu : ‖u‖ ≤ R)
    {g : Fin 2 → ℝ → ℝ}
    (hg_lip : ∀ y : Fin 2, ∀ t₁ ∈ Set.Icc (-(L * R)) (L * R),
      ∀ t₂ ∈ Set.Icc (-(L * R)) (L * R), |g y t₁ - g y t₂| ≤ C_lip * |t₁ - t₂|)
    (hg_bdd : ∀ y : Fin 2, ∀ t ∈ Set.Icc (-(L * R)) (L * R), |g y t| ≤ M₀) :
    (fun xy : Metric.closedBall (0 : X) L × Fin 2 => g xy.2 (inner ℝ u xy.1.1)) ∈
      UL.ScoreProfileClass X 2 L R C_lip M₀ := by
  let e₀ : UL.ZeroSumSubspace 2 := unitZeroSum2
  have he₀ : ‖e₀‖ = 1 := norm_unitZeroSum2
  let W_u : X →L[ℝ] UL.ZeroSumSubspace 2 := (innerSL ℝ u).smulRight e₀
  let π₀ : UL.ZeroSumSubspace 2 → ℝ := fun s => inner ℝ e₀ s
  have hadj : ∀ y : UL.ZeroSumSubspace 2,
      UL.Proof_lem_C_2.adjVec W_u y = inner ℝ e₀ y • u := by
    intro y
    refine ext_inner_right ℝ fun x => ?_
    rw [UL.Proof_lem_C_2.inner_adjVec_left]
    change inner ℝ y (inner ℝ u x • e₀) = inner ℝ (inner ℝ e₀ y • u) x
    rw [inner_smul_right, inner_smul_left, conj_trivial, real_inner_comm y e₀]
    ring
  have hW_sq : UL.hilbertSchmidtNorm W_u ^ 2 = ‖u‖ ^ 2 := by
    let bY := stdOrthonormalBasis ℝ (UL.ZeroSumSubspace 2)
    rw [UL.Proof_lem_C_2.hilbertSchmidtNorm_sq W_u]
    simp_rw [hadj, norm_smul, Real.norm_eq_abs, mul_pow, sq_abs]
    rw [← Finset.sum_mul]
    have hsum1 : ∑ j : Fin (Module.finrank ℝ (UL.ZeroSumSubspace 2)),
        (inner ℝ e₀ (bY j)) ^ 2 = 1 := by
      have hparseval := bY.sum_inner_mul_inner e₀ e₀
      have hself : inner ℝ e₀ e₀ = 1 := by
        rw [real_inner_self_eq_norm_sq, he₀, one_pow]
      rw [hself] at hparseval
      rw [← hparseval]
      refine Finset.sum_congr rfl fun j _ => ?_
      rw [real_inner_comm (bY j) e₀, sq]
    rw [hsum1, one_mul]
  have hW_norm : UL.hilbertSchmidtNorm W_u ≤ R := by
    have hnn := UL.Proof_lem_C_2.hilbertSchmidtNorm_nonneg W_u
    have hu_eq : UL.hilbertSchmidtNorm W_u = ‖u‖ := by nlinarith [norm_nonneg u]
    linarith
  have hπ_mem : ∀ s ∈ Metric.closedBall (0 : UL.ZeroSumSubspace 2) (L * R),
      π₀ s ∈ Set.Icc (-(L * R)) (L * R) := by
    intro s hs
    rw [Metric.mem_closedBall, dist_zero_right] at hs
    rw [Set.mem_Icc, ← abs_le]
    calc |π₀ s| = |inner ℝ e₀ s| := rfl
      _ ≤ ‖e₀‖ * ‖s‖ := abs_real_inner_le_norm e₀ s
      _ = ‖s‖ := by rw [he₀, one_mul]
      _ ≤ L * R := hs
  have hπ_lip : ∀ s₁ s₂ : UL.ZeroSumSubspace 2, |π₀ s₁ - π₀ s₂| ≤ ‖s₁ - s₂‖ := by
    intro s₁ s₂
    dsimp [π₀]
    rw [← inner_sub_right]
    calc |inner ℝ e₀ (s₁ - s₂)| ≤ ‖e₀‖ * ‖s₁ - s₂‖ := abs_real_inner_le_norm e₀ (s₁ - s₂)
      _ = ‖s₁ - s₂‖ := by rw [he₀, one_mul]
  have hπW : ∀ x : X, π₀ (W_u x) = inner ℝ u x := by
    intro x
    change inner ℝ e₀ (inner ℝ u x • e₀) = inner ℝ u x
    rw [inner_smul_right, real_inner_self_eq_norm_sq, he₀, one_pow, mul_one]
  let a : Fin 2 → UL.ZeroSumSubspace 2 → ℝ := fun y s => g y (π₀ s)
  refine ⟨le_rfl, hL, hR, hC, hM₀, W_u, a, hW_norm, fun y => ⟨?_, ?_⟩, ?_⟩
  · rw [lipschitzOnWith_iff_dist_le_mul]
    intro s₁ hs₁ s₂ hs₂
    rw [Real.coe_toNNReal C_lip hC.le, Real.dist_eq, dist_eq_norm]
    calc |a y s₁ - a y s₂|
        ≤ C_lip * |π₀ s₁ - π₀ s₂| := hg_lip y (π₀ s₁) (hπ_mem s₁ hs₁) (π₀ s₂) (hπ_mem s₂ hs₂)
      _ ≤ C_lip * ‖s₁ - s₂‖ := mul_le_mul_of_nonneg_left (hπ_lip s₁ s₂) hC.le
  · intro s hs
    rw [Set.mem_Icc, ← abs_le]
    exact hg_bdd y (π₀ s) (hπ_mem s hs)
  · intro x y
    dsimp [a]
    rw [hπW x.1]

/-! ### Binary matching potential, canonical loss, and measurability helpers -/

private lemma yVal_mem_Icc (y : Fin 2) : (y.val : ℝ) ∈ Set.Icc (0 : ℝ) 1 := by
  fin_cases y <;> simp

private lemma abs_sub_le_one_of_mem_Icc {a b : ℝ}
    (ha : a ∈ Set.Icc (0 : ℝ) 1) (hb : b ∈ Set.Icc (0 : ℝ) 1) :
    |a - b| ≤ 1 := by
  rw [abs_le]
  exact ⟨by linarith [ha.1, hb.2], by linarith [ha.2, hb.1]⟩

private lemma bddAbove_potential_range
    {φ : Set.Icc (0 : ℝ) 1 → ℝ} (hφ : Continuous φ) (a : ℝ) :
    BddAbove (Set.range (fun q : Set.Icc (0 : ℝ) 1 => (q : ℝ) * a - φ q)) :=
  (isCompact_range ((continuous_subtype_val.mul continuous_const).sub hφ)).bddAbove

private lemma binaryMatchingLoss_deriv_eq
    {β : ℝ} (hβ : 0 < β)
    {φ : Set.Icc (0 : ℝ) 1 → ℝ} {U : Set ℝ} {φ_ext : ℝ → ℝ}
    (hφ : φ ∈ UL.BinaryEntropyFamily β)
    (hU_open : IsOpen U) (hU_sub : Set.Icc (0 : ℝ) 1 ⊆ U)
    (hφ_ext : ∀ q : Set.Icc (0 : ℝ) 1, φ_ext q = φ q)
    (hφ_diff : DifferentiableOn ℝ φ_ext U)
    {p : ℝ} (hp : p ∈ Set.Icc (0 : ℝ) 1) (y : Fin 2) :
    UL.binaryMatchingLoss φ (deriv φ_ext p) y =
      -φ_ext p + (p - (y.val : ℝ)) * deriv φ_ext p := by
  have hφ_cont : Continuous φ := hφ.2.1
  have hconv := convexOn_phi_ext hβ hφ hφ_ext
  haveI : Nonempty (Set.Icc (0 : ℝ) 1) := ⟨⟨0, ⟨le_rfl, zero_le_one⟩⟩⟩
  have hpot : UL.binaryMatchingPotential φ (deriv φ_ext p) = p * deriv φ_ext p - φ_ext p := by
    refine le_antisymm ?_ ?_
    · unfold UL.binaryMatchingPotential
      refine ciSup_le fun q => ?_
      have hsub := convexOn_subderiv_le hconv hp
        (hasDerivAt_phi_ext hU_open hU_sub hφ_diff hp) q.2
      have hq_eq : φ q = φ_ext (q : ℝ) := (hφ_ext q).symm
      linarith
    · have hle : p * deriv φ_ext p - φ ⟨p, hp⟩ ≤ UL.binaryMatchingPotential φ (deriv φ_ext p) :=
        le_ciSup (bddAbove_potential_range hφ_cont (deriv φ_ext p)) ⟨p, hp⟩
      rw [hφ_ext ⟨p, hp⟩]
      exact hle
  unfold UL.binaryMatchingLoss
  rw [hpot]
  ring

lemma abs_binaryMatchingLoss_sub_le
    {φ : Set.Icc (0 : ℝ) 1 → ℝ} (hφ : Continuous φ)
    (t₁ t₂ : ℝ) (y : Fin 2) :
    |UL.binaryMatchingLoss φ t₁ y - UL.binaryMatchingLoss φ t₂ y| ≤ |t₁ - t₂| := by
  haveI : Nonempty (Set.Icc (0 : ℝ) 1) := ⟨⟨0, ⟨le_rfl, zero_le_one⟩⟩⟩
  have hdir : ∀ a₁ a₂ : ℝ,
      UL.binaryMatchingLoss φ a₁ y ≤ UL.binaryMatchingLoss φ a₂ y + |a₁ - a₂| := by
    intro a₁ a₂
    suffices hpot : UL.binaryMatchingPotential φ a₁ ≤
        UL.binaryMatchingPotential φ a₂ + (y.val : ℝ) * (a₁ - a₂) + |a₁ - a₂| by
      unfold UL.binaryMatchingLoss
      linarith
    unfold UL.binaryMatchingPotential
    refine ciSup_le fun q => ?_
    have hq2 : (q : ℝ) * a₂ - φ q ≤ ⨆ q' : Set.Icc (0 : ℝ) 1, ((q' : ℝ) * a₂ - φ q') :=
      le_ciSup (bddAbove_potential_range hφ a₂) q
    have hqy : |(q : ℝ) - (y.val : ℝ)| ≤ 1 :=
      abs_sub_le_one_of_mem_Icc q.2 (yVal_mem_Icc y)
    have hprod : ((q : ℝ) - (y.val : ℝ)) * (a₁ - a₂) ≤ |a₁ - a₂| := by
      calc ((q : ℝ) - (y.val : ℝ)) * (a₁ - a₂)
          ≤ |((q : ℝ) - (y.val : ℝ)) * (a₁ - a₂)| := le_abs_self _
        _ = |(q : ℝ) - (y.val : ℝ)| * |a₁ - a₂| := abs_mul _ _
        _ ≤ 1 * |a₁ - a₂| := mul_le_mul_of_nonneg_right hqy (abs_nonneg _)
        _ = |a₁ - a₂| := one_mul _
    linarith
  have h1 := hdir t₁ t₂
  have h2 := hdir t₂ t₁
  rw [abs_sub_comm t₂ t₁] at h2
  rw [abs_le]
  exact ⟨by linarith, by linarith⟩

private lemma continuous_binaryMatchingLoss
    {φ : Set.Icc (0 : ℝ) 1 → ℝ} (hφ : Continuous φ) (y : Fin 2) :
    Continuous (fun a : ℝ => UL.binaryMatchingLoss φ a y) := by
  have hlip : LipschitzWith 1 (fun a : ℝ => UL.binaryMatchingLoss φ a y) := by
    rw [lipschitzWith_iff_dist_le_mul]
    intro a₁ a₂
    simpa [Real.dist_eq] using abs_binaryMatchingLoss_sub_le hφ a₁ a₂ y
  exact hlip.continuous

private lemma measurable_of_fin2_snd {α β : Type*} [MeasurableSpace α] [MeasurableSpace β]
    {g : α × Fin 2 → β}
    (hg : ∀ y : Fin 2, Measurable (fun x : α => g (x, y))) :
    Measurable g := by
  intro B hB
  have heq : g ⁻¹' B = ⋃ y : Fin 2, ((fun x : α => g (x, y)) ⁻¹' B) ×ˢ ({y} : Set (Fin 2)) := by
    ext ⟨x, y₀⟩
    simp only [Set.mem_preimage, Set.mem_iUnion, Set.mem_prod, Set.mem_singleton_iff]
    exact ⟨fun h => ⟨y₀, h, rfl⟩, fun ⟨_, hx, rfl⟩ => hx⟩
  rw [heq]
  exact MeasurableSet.iUnion fun y => (hg y hB).prod (measurableSet_singleton y)

/-- Transfers an empirical binary loss inequality to a population binary loss inequality
within `2 * bound` using `ScoreProfileClass X 2 L R (B * lam) (2 * M + L * R)`. -/
theorem population_comparison_of_uniform_dev
    (X : Type*) [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    [MeasurableSpace X] [BorelSpace X]
    {L R β lam M B : ℝ}
    (_hL : 0 < L) (_hR : 0 < R) (_hβ : 0 < β) (_hlam : 0 < lam) (_hM : 0 < M)
    (_hB : β ≤ B) (_hBlam : 1 ≤ B * lam)
    {n : ℕ} (_hn : 1 ≤ n)
    (ν : MeasureTheory.Measure (X × Fin 2)) [MeasureTheory.IsProbabilityMeasure ν]
    (_hX_bound : ∀ᵐ xy ∂ν, ‖xy.1‖ ≤ L)
    (x_s : Fin n → X) (y_s : Fin n → Fin 2)
    (_hx_s : ∀ i : Fin n, ‖x_s i‖ ≤ L)
    {bound : ℝ}
    (_h_sup :
      let evalProfile : (Metric.closedBall (0 : X) L × Fin 2 → ℝ) → X → Fin 2 → ℝ :=
        open Classical in
        fun f x y => if hx : x ∈ Metric.closedBall (0 : X) L then f (⟨x, hx⟩, y) else 0
      sSup ((fun f : Metric.closedBall (0 : X) L × Fin 2 → ℝ =>
        |(∫ xy, evalProfile f xy.1 xy.2 ∂ν) -
          ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalProfile f (x_s i) (y_s i)|) ''
        UL.ScoreProfileClass X 2 L R (B * lam) (2 * M + L * R)) ≤ bound)
    {w : X} (_hw : ‖w‖ ≤ R)
    {ρ : ℝ → ℝ} (_hρ_lip : LipschitzWith (Real.toNNReal B) ρ)
    (_hρ_mem : ∀ t : ℝ, ρ t ∈ Set.Icc (0 : ℝ) 1)
    {φ : Set.Icc (0 : ℝ) 1 → ℝ} {U : Set ℝ} {φ_ext : ℝ → ℝ}
    (_hφ : φ ∈ UL.BinaryEntropyFamily β)
    (_hU_open : IsOpen U)
    (_hU_sub : Set.Icc (0 : ℝ) 1 ⊆ U)
    (_hφ_ext : ∀ q : Set.Icc (0 : ℝ) 1, φ_ext q = φ q)
    (_hφ_diff : DifferentiableOn ℝ φ_ext U)
    (_hφ_cont_deriv : ContinuousOn (deriv φ_ext) U)
    (_hφ_M : ∀ q ∈ Set.Icc (0 : ℝ) 1, |deriv φ_ext q| ≤ M)
    (_hφ_lip : ∀ q ∈ Set.Icc (0 : ℝ) 1, ∀ q' ∈ Set.Icc (0 : ℝ) 1,
      |deriv φ_ext q - deriv φ_ext q'| ≤ lam * |q - q'|)
    {v : X} (_hv : ‖v‖ ≤ R)
    {slack : ℝ}
    (_h_emp :
      ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
          UL.binaryMatchingLoss φ (deriv φ_ext (ρ (inner ℝ w (x_s i)))) (y_s i) ≤
        ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
          UL.binaryMatchingLoss φ (inner ℝ v (x_s i)) (y_s i) + slack) :
    (∫ xy, UL.binaryMatchingLoss φ (deriv φ_ext (ρ (inner ℝ w xy.1))) xy.2 ∂ν) ≤
      (∫ xy, UL.binaryMatchingLoss φ (inner ℝ v xy.1) xy.2 ∂ν) + 2 * bound + slack := by
  let evalProfile : (Metric.closedBall (0 : X) L × Fin 2 → ℝ) → X → Fin 2 → ℝ :=
    open Classical in
    fun f x y => if hx : x ∈ Metric.closedBall (0 : X) L then f (⟨x, hx⟩, y) else 0
  let C_lip : ℝ := B * lam
  let M₀ : ℝ := 2 * M + L * R
  let devFn : (Metric.closedBall (0 : X) L × Fin 2 → ℝ) → ℝ :=
    fun f => |(∫ xy, evalProfile f xy.1 xy.2 ∂ν) -
      ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalProfile f (x_s i) (y_s i)|
  change sSup (devFn '' UL.ScoreProfileClass X 2 L R C_lip M₀) ≤ bound at _h_sup
  have hB_pos : 0 < B := lt_of_lt_of_le _hβ _hB
  have hC_pos : 0 < C_lip := mul_pos hB_pos _hlam
  have hM₀_pos : 0 < M₀ := by dsimp [M₀]; positivity
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  have hφ_cont : Continuous φ := _hφ.2.1
  have hφ_conv : ConvexOn ℝ (Set.Icc (0 : ℝ) 1) φ_ext := convexOn_phi_ext _hβ _hφ _hφ_ext
  -- Step 4: `BddAbove` of the deviation image on `ScoreProfileClass`
  have heval_abs : ∀ {f : Metric.closedBall (0 : X) L × Fin 2 → ℝ},
      f ∈ UL.ScoreProfileClass X 2 L R C_lip M₀ → ∀ x y, |evalProfile f x y| ≤ M₀ := by
    intro f hf x y
    classical
    obtain ⟨_, _, _, _, _, W, a, hW, ha, hfeq⟩ := hf
    dsimp only [evalProfile]
    split_ifs with hx
    · rw [hfeq ⟨x, hx⟩ y]
      rw [Metric.mem_closedBall, dist_zero_right] at hx
      have hWx : W x ∈ Metric.closedBall (0 : UL.ZeroSumSubspace 2) (L * R) := by
        rw [Metric.mem_closedBall, dist_zero_right]
        calc ‖W x‖ ≤ UL.hilbertSchmidtNorm W * ‖x‖ :=
              UL.Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm W x
          _ ≤ R * L := mul_le_mul hW hx (norm_nonneg _) _hR.le
          _ = L * R := mul_comm R L
      exact abs_le.mpr ((ha y).2 hWx)
    · rw [abs_zero]
      exact hM₀_pos.le
  have h_bdd : BddAbove (devFn '' UL.ScoreProfileClass X 2 L R C_lip M₀) := by
    refine ⟨2 * M₀, ?_⟩
    rintro _ ⟨f, hf, rfl⟩
    dsimp only [devFn]
    have hint_le : |∫ xy, evalProfile f xy.1 xy.2 ∂ν| ≤ M₀ := by
      have h1 := MeasureTheory.norm_integral_le_of_norm_le_const (μ := ν)
        (f := fun xy : X × Fin 2 => evalProfile f xy.1 xy.2) (C := M₀)
        (Filter.Eventually.of_forall fun xy => by
          rw [Real.norm_eq_abs]
          exact heval_abs hf xy.1 xy.2)
      simpa [Real.norm_eq_abs] using h1
    have hsum_le : |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalProfile f (x_s i) (y_s i)| ≤ M₀ := by
      rw [abs_mul, abs_of_pos (one_div_pos.mpr hn_pos)]
      calc (1 / (n : ℝ)) * |∑ i : Fin n, evalProfile f (x_s i) (y_s i)|
          ≤ (1 / (n : ℝ)) * ∑ i : Fin n, |evalProfile f (x_s i) (y_s i)| :=
            mul_le_mul_of_nonneg_left (Finset.abs_sum_le_sum_abs _ _) (by positivity)
        _ ≤ (1 / (n : ℝ)) * ∑ _i : Fin n, M₀ :=
            mul_le_mul_of_nonneg_left (Finset.sum_le_sum fun i _ => heval_abs hf _ _)
              (by positivity)
        _ = M₀ := by
            rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
            field_simp [hn_pos.ne']
    calc |(∫ xy, evalProfile f xy.1 xy.2 ∂ν) -
            ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalProfile f (x_s i) (y_s i)|
        ≤ |∫ xy, evalProfile f xy.1 xy.2 ∂ν| +
            |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalProfile f (x_s i) (y_s i)| := abs_sub _ _
      _ ≤ M₀ + M₀ := add_le_add hint_le hsum_le
      _ = 2 * M₀ := by ring
  -- Step 5: Normalized learned and comparator profiles (`G₀ := binaryMatchingPotential φ 0`)
  let G₀ : ℝ := UL.binaryMatchingPotential φ 0
  haveI : Nonempty (Set.Icc (0 : ℝ) 1) := ⟨⟨0, ⟨le_rfl, zero_le_one⟩⟩⟩
  obtain ⟨q_min, _, hq_min_max⟩ :=
    isCompact_univ.exists_isMaxOn Set.univ_nonempty hφ_cont.neg.continuousOn
  have hG₀_eq : G₀ = -φ_ext (q_min : ℝ) := by
    have hmax : ∀ q : Set.Icc (0 : ℝ) 1, -φ q ≤ -φ q_min :=
      fun q => hq_min_max (Set.mem_univ q)
    have hpot0 : G₀ = -φ q_min := by
      refine le_antisymm ?_ ?_
      · refine ciSup_le fun q => ?_
        simpa using hmax q
      · have hle : (q_min : ℝ) * 0 - φ q_min ≤ G₀ :=
          le_ciSup (bddAbove_potential_range hφ_cont 0) q_min
        simpa using hle
    rw [hpot0, ← _hφ_ext q_min]
  have hφ_diff_le_M : ∀ p₁ ∈ Set.Icc (0 : ℝ) 1, ∀ p₂ ∈ Set.Icc (0 : ℝ) 1,
      |φ_ext p₁ - φ_ext p₂| ≤ M := by
    intro p₁ hp₁ p₂ hp₂
    have hdir : ∀ a ∈ Set.Icc (0 : ℝ) 1, ∀ b ∈ Set.Icc (0 : ℝ) 1,
        φ_ext a - φ_ext b ≤ M := by
      intro a ha b hb
      have hsub := convexOn_subderiv_le hφ_conv ha
        (hasDerivAt_phi_ext _hU_open _hU_sub _hφ_diff ha) hb
      have hprod : deriv φ_ext a * (a - b) ≤ M := by
        calc deriv φ_ext a * (a - b)
            ≤ |deriv φ_ext a * (a - b)| := le_abs_self _
          _ = |deriv φ_ext a| * |a - b| := abs_mul _ _
          _ ≤ M * 1 := mul_le_mul (_hφ_M a ha) (abs_sub_le_one_of_mem_Icc ha hb)
              (abs_nonneg _) _hM.le
          _ = M := mul_one M
      linarith
    rw [abs_le]
    exact ⟨by linarith [hdir p₂ hp₂ p₁ hp₁], hdir p₁ hp₁ p₂ hp₂⟩
  let b_fn : Fin 2 → ℝ → ℝ :=
    fun y q => -φ_ext q + (q - (y.val : ℝ)) * deriv φ_ext q - G₀
  have hb_eq_loss : ∀ y : Fin 2, ∀ q ∈ Set.Icc (0 : ℝ) 1,
      UL.binaryMatchingLoss φ (deriv φ_ext q) y - G₀ = b_fn y q := by
    intro y q hq
    rw [binaryMatchingLoss_deriv_eq _hβ _hφ _hU_open _hU_sub _hφ_ext _hφ_diff hq y]
  have hb_bdd : ∀ y : Fin 2, ∀ q ∈ Set.Icc (0 : ℝ) 1, |b_fn y q| ≤ 2 * M := by
    intro y q hq
    have h1 : |-φ_ext q - G₀| ≤ M := by
      rw [hG₀_eq, show -φ_ext q - -φ_ext (q_min : ℝ) = φ_ext (q_min : ℝ) - φ_ext q by ring]
      exact hφ_diff_le_M (q_min : ℝ) q_min.2 q hq
    have h2 : |(q - (y.val : ℝ)) * deriv φ_ext q| ≤ M := by
      rw [abs_mul]
      calc |q - (y.val : ℝ)| * |deriv φ_ext q|
          ≤ 1 * M := mul_le_mul (abs_sub_le_one_of_mem_Icc hq (yVal_mem_Icc y)) (_hφ_M q hq)
              (abs_nonneg _) zero_le_one
        _ = M := one_mul M
    have hsplit : b_fn y q = (-φ_ext q - G₀) + (q - (y.val : ℝ)) * deriv φ_ext q := by
      dsimp [b_fn]; ring
    rw [hsplit]
    exact (abs_add_le _ _).trans (by linarith)
  have hb_lip : ∀ y : Fin 2, ∀ q₁ ∈ Set.Icc (0 : ℝ) 1, ∀ q₂ ∈ Set.Icc (0 : ℝ) 1,
      |b_fn y q₁ - b_fn y q₂| ≤ lam * |q₁ - q₂| := by
    intro y q₁ hq₁ q₂ hq₂
    have hdir : ∀ a ∈ Set.Icc (0 : ℝ) 1, ∀ b ∈ Set.Icc (0 : ℝ) 1,
        b_fn y b - b_fn y a ≤ lam * |b - a| := by
      intro a ha b hb
      have hid : b_fn y b - b_fn y a =
          (deriv φ_ext a * (b - a) - (φ_ext b - φ_ext a)) +
            (b - (y.val : ℝ)) * (deriv φ_ext b - deriv φ_ext a) := by
        dsimp [b_fn]; ring
      have hconv_le := convexOn_subderiv_le hφ_conv ha
        (hasDerivAt_phi_ext _hU_open _hU_sub _hφ_diff ha) hb
      have hterm2 : (b - (y.val : ℝ)) * (deriv φ_ext b - deriv φ_ext a) ≤ lam * |b - a| := by
        calc (b - (y.val : ℝ)) * (deriv φ_ext b - deriv φ_ext a)
            ≤ |(b - (y.val : ℝ)) * (deriv φ_ext b - deriv φ_ext a)| := le_abs_self _
          _ = |b - (y.val : ℝ)| * |deriv φ_ext b - deriv φ_ext a| := abs_mul _ _
          _ ≤ 1 * (lam * |b - a|) := mul_le_mul (abs_sub_le_one_of_mem_Icc hb (yVal_mem_Icc y))
              (_hφ_lip b hb a ha) (abs_nonneg _) zero_le_one
          _ = lam * |b - a| := one_mul _
      linarith
    have h12 := hdir q₂ hq₂ q₁ hq₁
    have h21 := hdir q₁ hq₁ q₂ hq₂
    rw [abs_sub_comm q₂ q₁] at h21
    rw [abs_le]
    exact ⟨by linarith, h12⟩
  have hρ_dist : ∀ t₁ t₂ : ℝ, |ρ t₁ - ρ t₂| ≤ B * |t₁ - t₂| := by
    intro t₁ t₂
    have h := _hρ_lip.dist_le_mul t₁ t₂
    rwa [Real.coe_toNNReal B hB_pos.le, Real.dist_eq, Real.dist_eq] at h
  let g_learn : Fin 2 → ℝ → ℝ :=
    fun y t => UL.binaryMatchingLoss φ (deriv φ_ext (ρ t)) y - G₀
  let f_learn : Metric.closedBall (0 : X) L × Fin 2 → ℝ :=
    fun xy => g_learn xy.2 (inner ℝ w xy.1.1)
  have hf_learn_mem : f_learn ∈ UL.ScoreProfileClass X 2 L R C_lip M₀ := by
    refine rankOne_mem_scoreProfileClass _hL _hR hC_pos hM₀_pos _hw ?_ ?_
    · intro y t₁ _ t₂ _
      dsimp [g_learn]
      rw [hb_eq_loss y (ρ t₁) (_hρ_mem t₁), hb_eq_loss y (ρ t₂) (_hρ_mem t₂)]
      calc |b_fn y (ρ t₁) - b_fn y (ρ t₂)|
          ≤ lam * |ρ t₁ - ρ t₂| := hb_lip y (ρ t₁) (_hρ_mem t₁) (ρ t₂) (_hρ_mem t₂)
        _ ≤ lam * (B * |t₁ - t₂|) := mul_le_mul_of_nonneg_left (hρ_dist t₁ t₂) _hlam.le
        _ = C_lip * |t₁ - t₂| := by dsimp [C_lip]; ring
    · intro y t _
      dsimp [g_learn]
      rw [hb_eq_loss y (ρ t) (_hρ_mem t)]
      have hb := hb_bdd y (ρ t) (_hρ_mem t)
      have hLR : 0 < L * R := mul_pos _hL _hR
      dsimp [M₀]
      linarith
  let g_comp : Fin 2 → ℝ → ℝ := fun y t => UL.binaryMatchingLoss φ t y - G₀
  let f_comp : Metric.closedBall (0 : X) L × Fin 2 → ℝ :=
    fun xy => g_comp xy.2 (inner ℝ v xy.1.1)
  have hloss_zero : ∀ y : Fin 2, UL.binaryMatchingLoss φ 0 y = G₀ := by
    intro y
    simp [UL.binaryMatchingLoss, G₀]
  have hf_comp_mem : f_comp ∈ UL.ScoreProfileClass X 2 L R C_lip M₀ := by
    refine rankOne_mem_scoreProfileClass _hL _hR hC_pos hM₀_pos _hv ?_ ?_
    · intro y t₁ _ t₂ _
      have hsub : g_comp y t₁ - g_comp y t₂ =
          UL.binaryMatchingLoss φ t₁ y - UL.binaryMatchingLoss φ t₂ y := by
        dsimp [g_comp]; ring
      rw [hsub]
      calc |UL.binaryMatchingLoss φ t₁ y - UL.binaryMatchingLoss φ t₂ y|
          ≤ 1 * |t₁ - t₂| := by simpa using abs_binaryMatchingLoss_sub_le hφ_cont t₁ t₂ y
        _ ≤ C_lip * |t₁ - t₂| := mul_le_mul_of_nonneg_right _hBlam (abs_nonneg _)
    · intro y t ht
      have ht_abs : |t| ≤ L * R := abs_le.mpr ht
      dsimp [g_comp]
      rw [← hloss_zero y]
      calc |UL.binaryMatchingLoss φ t y - UL.binaryMatchingLoss φ 0 y|
          ≤ |t - 0| := abs_binaryMatchingLoss_sub_le hφ_cont t 0 y
        _ = |t| := by rw [sub_zero]
        _ ≤ L * R := ht_abs
        _ ≤ M₀ := by dsimp [M₀]; linarith
  -- Step 6: Measurability, integrability, cancellation of `G₀`, and conclusion
  let learnedLoss : X × Fin 2 → ℝ :=
    fun xy => UL.binaryMatchingLoss φ (deriv φ_ext (ρ (inner ℝ w xy.1))) xy.2
  let compLoss : X × Fin 2 → ℝ :=
    fun xy => UL.binaryMatchingLoss φ (inner ℝ v xy.1) xy.2
  have hlearn_meas : Measurable learnedLoss := by
    refine measurable_of_fin2_snd fun y => ?_
    have hq_cont : Continuous (fun x : X => ρ (inner ℝ w x)) :=
      _hρ_lip.continuous.comp (continuous_const.inner continuous_id)
    have hderiv_cont : Continuous (fun x : X => deriv φ_ext (ρ (inner ℝ w x))) :=
      _hφ_cont_deriv.comp_continuous hq_cont (fun x => _hU_sub (_hρ_mem (inner ℝ w x)))
    exact ((continuous_binaryMatchingLoss hφ_cont y).comp hderiv_cont).measurable
  have hcomp_meas : Measurable compLoss := by
    refine measurable_of_fin2_snd fun y => ?_
    exact ((continuous_binaryMatchingLoss hφ_cont y).comp
      (continuous_const.inner continuous_id)).measurable
  have hlearn_int : MeasureTheory.Integrable learnedLoss ν := by
    refine (MeasureTheory.integrable_const (2 * M + |G₀|)).mono'
      hlearn_meas.aestronglyMeasurable (Filter.Eventually.of_forall fun xy => ?_)
    rw [Real.norm_eq_abs]
    have h1 : |learnedLoss xy - G₀| ≤ 2 * M := by
      dsimp [learnedLoss]
      rw [hb_eq_loss xy.2 (ρ (inner ℝ w xy.1)) (_hρ_mem _)]
      exact hb_bdd xy.2 _ (_hρ_mem _)
    have htri : |learnedLoss xy| ≤ |learnedLoss xy - G₀| + |G₀| := by
      simpa using abs_add_le (learnedLoss xy - G₀) G₀
    linarith
  have hcomp_int : MeasureTheory.Integrable compLoss ν := by
    refine (MeasureTheory.integrable_const (L * R + |G₀|)).mono'
      hcomp_meas.aestronglyMeasurable ?_
    filter_upwards [_hX_bound] with xy hxy
    rw [Real.norm_eq_abs]
    have h1 : |compLoss xy - G₀| ≤ L * R := by
      dsimp [compLoss]
      rw [← hloss_zero xy.2]
      calc |UL.binaryMatchingLoss φ (inner ℝ v xy.1) xy.2 - UL.binaryMatchingLoss φ 0 xy.2|
          ≤ |inner ℝ v xy.1 - 0| := abs_binaryMatchingLoss_sub_le hφ_cont _ 0 xy.2
        _ = |inner ℝ v xy.1| := by rw [sub_zero]
        _ ≤ ‖v‖ * ‖xy.1‖ := abs_real_inner_le_norm v xy.1
        _ ≤ R * L := mul_le_mul _hv hxy (norm_nonneg _) _hR.le
        _ = L * R := mul_comm R L
    have htri : |compLoss xy| ≤ |compLoss xy - G₀| + |G₀| := by
      simpa using abs_add_le (compLoss xy - G₀) G₀
    linarith
  have hdev_eq : ∀ (h : X × Fin 2 → ℝ), MeasureTheory.Integrable h ν →
      let f_h : Metric.closedBall (0 : X) L × Fin 2 → ℝ := fun xy => h (xy.1.1, xy.2) - G₀
      (∫ xy, evalProfile f_h xy.1 xy.2 ∂ν) -
          ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalProfile f_h (x_s i) (y_s i) =
        (∫ xy, h xy ∂ν) - ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, h (x_s i, y_s i) := by
    intro h hh_int f_h
    have hae : (fun xy : X × Fin 2 => evalProfile f_h xy.1 xy.2) =ᵐ[ν]
        (fun xy : X × Fin 2 => h xy - G₀) := by
      filter_upwards [_hX_bound] with xy hxy
      have hmem : xy.1 ∈ Metric.closedBall (0 : X) L := by
        rwa [Metric.mem_closedBall, dist_zero_right]
      dsimp only [evalProfile]
      rw [dif_pos hmem]
    have hint_eq : (∫ xy, evalProfile f_h xy.1 xy.2 ∂ν) = (∫ xy, h xy ∂ν) - G₀ := by
      rw [MeasureTheory.integral_congr_ae hae,
        MeasureTheory.integral_sub hh_int (MeasureTheory.integrable_const G₀)]
      simp
    have hsum_eq :
        ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalProfile f_h (x_s i) (y_s i) =
          ((1 : ℝ) / (n : ℝ)) * (∑ i : Fin n, h (x_s i, y_s i)) - G₀ := by
      have hpt : ∀ i : Fin n, evalProfile f_h (x_s i) (y_s i) = h (x_s i, y_s i) - G₀ := by
        intro i
        have hmem : x_s i ∈ Metric.closedBall (0 : X) L := by
          rw [Metric.mem_closedBall, dist_zero_right]
          exact _hx_s i
        dsimp only [evalProfile]
        rw [dif_pos hmem]
      simp_rw [hpt, Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
        nsmul_eq_mul]
      field_simp [hn_pos.ne']
    rw [hint_eq, hsum_eq]
    ring
  have hdev_learn : devFn f_learn ≤ bound :=
    (le_csSup h_bdd ⟨f_learn, hf_learn_mem, rfl⟩).trans _h_sup
  have hdev_comp : devFn f_comp ≤ bound :=
    (le_csSup h_bdd ⟨f_comp, hf_comp_mem, rfl⟩).trans _h_sup
  dsimp only [devFn] at hdev_learn hdev_comp
  rw [hdev_eq learnedLoss hlearn_int] at hdev_learn
  rw [hdev_eq compLoss hcomp_int] at hdev_comp
  have h1 := (abs_le.mp hdev_learn).2
  have h2 := (abs_le.mp hdev_comp).1
  dsimp only [learnedLoss, compLoss] at h1 h2
  linarith

end UL.Proof_cor_C_6

import Mathlib
import UL.Stmt.lem_C_3
set_option autoImplicit false

namespace UL.Proof_cor_C_6

universe u₁ u₂ v₁ v₂

section Helpers

private noncomputable def reindexHilbertEquiv {E : Type*} [NormedAddCommGroup E]
    [InnerProductSpace ℝ E] [CompleteSpace E] {ι ι' : Type*}
    (b : HilbertBasis ι ℝ E) (e : ι ≃ ι') : E ≃ₗᵢ[ℝ] lp (fun _ : ι' => ℝ) 2 :=
  (HilbertBasis.mk (b.orthonormal.comp e.symm e.symm.injective) (by
    have hr : Set.range (b ∘ e.symm) = Set.range b := by
      ext x
      constructor
      · rintro ⟨i', rfl⟩
        exact ⟨e.symm i', rfl⟩
      · rintro ⟨i, rfl⟩
        exact ⟨e i, by simp⟩
    rw [hr, b.dense_span])).repr

private lemma countable_of_hilbertBasis {E : Type*} [NormedAddCommGroup E]
    [InnerProductSpace ℝ E] [TopologicalSpace.SeparableSpace E] {ι : Type*}
    (b : HilbertBasis ι ℝ E) : Countable ι := by
  refine Pairwise.countable_of_isOpen_disjoint
    (s := fun i : ι => Metric.ball (b i) (1 / 2)) ?_
    (fun _ => Metric.isOpen_ball)
    (fun _ => Metric.nonempty_ball.mpr (by norm_num))
  intro i j hij
  rw [Function.onFun, Set.disjoint_left]
  intro z hzi hzj
  rw [Metric.mem_ball] at hzi hzj
  have hdist : dist (b i) (b j) < 1 := by
    calc dist (b i) (b j)
        ≤ dist (b i) z + dist z (b j) := dist_triangle (b i) z (b j)
      _ = dist z (b i) + dist z (b j) := by rw [dist_comm (b i) z]
      _ < 1 / 2 + 1 / 2 := add_lt_add hzi hzj
      _ = 1 := by norm_num
  rw [dist_eq_norm] at hdist
  have hsq_lt : ‖b i - b j‖ ^ 2 < 1 := by
    have hnn : 0 ≤ ‖b i - b j‖ := norm_nonneg _
    nlinarith
  have hsq_eq : ‖b i - b j‖ ^ 2 = 2 := by
    rw [norm_sub_sq_real, b.orthonormal.norm_eq_one i, b.orthonormal.norm_eq_one j,
      b.orthonormal.inner_eq_zero hij]
    norm_num
  linarith

private lemma ortho_finset_map {E₁ E₂ : Type*}
    [NormedAddCommGroup E₁] [InnerProductSpace ℝ E₁]
    [NormedAddCommGroup E₂] [InnerProductSpace ℝ E₂]
    (e : E₁ ≃ₗᵢ[ℝ] E₂) {s : Finset E₁}
    (hs : Orthonormal ℝ (Subtype.val : s → E₁)) :
    Orthonormal ℝ (Subtype.val : (s.map e.toEquiv.toEmbedding) → E₂) := by
  classical
  rw [orthonormal_iff_ite] at hs ⊢
  intro a b
  rcases Finset.mem_map.mp a.2 with ⟨x, hx, hxa⟩
  rcases Finset.mem_map.mp b.2 with ⟨y, hy, hyb⟩
  change inner ℝ a.1 b.1 = if a = b then 1 else 0
  rw [← hxa, ← hyb]
  change inner ℝ (e x) (e y) = if a = b then 1 else 0
  rw [e.inner_map_map]
  have hxy := hs ⟨x, hx⟩ ⟨y, hy⟩
  change inner ℝ x y = if (⟨x, hx⟩ : s) = ⟨y, hy⟩ then 1 else 0 at hxy
  rw [hxy]
  by_cases h : x = y
  · subst h
    have hab : a = b := Subtype.ext (hxa.symm.trans hyb)
    simp [hab]
  · have hsub : (⟨x, hx⟩ : s) ≠ ⟨y, hy⟩ := fun h' => h (congrArg Subtype.val h')
    have hab : a ≠ b := fun h' =>
      h (e.injective (hxa.trans ((congrArg Subtype.val h').trans hyb.symm)))
    simp [hsub, hab]

private lemma hilbertSchmidtNorm_comp_lie {E₁ E₂ Y : Type*}
    [NormedAddCommGroup E₁] [InnerProductSpace ℝ E₁]
    [NormedAddCommGroup E₂] [InnerProductSpace ℝ E₂]
    [NormedAddCommGroup Y] [InnerProductSpace ℝ Y] [FiniteDimensional ℝ Y]
    (W : E₁ →L[ℝ] Y) (e : E₂ ≃ₗᵢ[ℝ] E₁) :
    UL.hilbertSchmidtNorm (W.comp e.toContinuousLinearEquiv.toContinuousLinearMap) =
      UL.hilbertSchmidtNorm W := by
  unfold UL.hilbertSchmidtNorm
  congr 1
  simp only [iSup]
  congr 1
  ext r
  constructor
  · rintro ⟨s₂, rfl⟩
    refine ⟨⟨s₂.1.map e.toEquiv.toEmbedding, ortho_finset_map e s₂.2⟩, ?_⟩
    dsimp only
    rw [Finset.sum_map]
    rfl
  · rintro ⟨s₁, rfl⟩
    refine ⟨⟨s₁.1.map e.symm.toEquiv.toEmbedding, ortho_finset_map e.symm s₁.2⟩, ?_⟩
    dsimp only
    rw [Finset.sum_map]
    refine Finset.sum_congr rfl fun x _ => ?_
    change ‖W (e (e.symm x))‖ ^ 2 = ‖W x‖ ^ 2
    rw [e.apply_symm_apply]

private lemma norm_apply_le_hs {E Y : Type*}
    [NormedAddCommGroup E] [InnerProductSpace ℝ E] [CompleteSpace E]
    [NormedAddCommGroup Y] [InnerProductSpace ℝ Y] [FiniteDimensional ℝ Y]
    (W : E →L[ℝ] Y) (x : E) :
    ‖W x‖ ≤ UL.hilbertSchmidtNorm W * ‖x‖ := by
  let bY := stdOrthonormalBasis ℝ Y
  let u : Fin (Module.finrank ℝ Y) → E := fun j =>
    (InnerProductSpace.toDual ℝ E).symm ((innerSL ℝ (bY j)).comp W)
  have hu_inner : ∀ (v : E) (j : Fin (Module.finrank ℝ Y)),
      inner ℝ v (u j) = inner ℝ (bY j) (W v) := by
    intro v j
    rw [real_inner_comm, InnerProductSpace.toDual_symm_apply]
    rfl
  have hnorm_sq : ∀ v : E,
      ‖W v‖ ^ 2 = ∑ j : Fin (Module.finrank ℝ Y), ‖inner ℝ v (u j)‖ ^ 2 := by
    intro v
    rw [← real_inner_self_eq_norm_sq, ← bY.sum_inner_mul_inner (W v) (W v)]
    refine Finset.sum_congr rfl fun j _ => ?_
    rw [hu_inner v j, real_inner_comm (W v) (bY j), Real.norm_eq_abs, sq_abs, sq]
  let S : ℝ := ∑ j : Fin (Module.finrank ℝ Y), ‖u j‖ ^ 2
  have h_bdd : BddAbove
      (Set.range fun s : {s : Finset E // Orthonormal ℝ (Subtype.val : s → E)} =>
        ∑ v ∈ s.1, ‖W v‖ ^ 2) := by
    refine ⟨S, Set.forall_mem_range.mpr fun s => ?_⟩
    rw [← Finset.sum_coe_sort s.1 (fun v => ‖W v‖ ^ 2)]
    simp_rw [hnorm_sq]
    rw [Finset.sum_comm]
    exact Finset.sum_le_sum fun j _ => s.2.sum_inner_products_le (u j)
  let s₀ : {s : Finset E // Orthonormal ℝ (Subtype.val : s → E)} :=
    ⟨∅, ⟨fun i => False.elim (Finset.notMem_empty i.1 i.2),
         fun i => False.elim (Finset.notMem_empty i.1 i.2)⟩⟩
  have h_sup_nn : 0 ≤ ⨆ s : {s : Finset E // Orthonormal ℝ (Subtype.val : s → E)},
      ∑ v ∈ s.1, ‖W v‖ ^ 2 := by
    have h0 : (0 : ℝ) = ∑ v ∈ s₀.1, ‖W v‖ ^ 2 := by simp [s₀]
    rw [h0]
    exact le_ciSup h_bdd s₀
  by_cases hx : x = 0
  · subst hx
    simp
  · have hx_pos : 0 < ‖x‖ := norm_pos_iff.mpr hx
    let v₀ : E := (‖x‖⁻¹ : ℝ) • x
    have hv₀_norm : ‖v₀‖ = 1 := by
      dsimp [v₀]
      rw [norm_smul, Real.norm_eq_abs, abs_inv, abs_norm, inv_mul_cancel₀ hx_pos.ne']
    let s₁ : {s : Finset E // Orthonormal ℝ (Subtype.val : s → E)} :=
      ⟨{v₀}, ⟨fun i => by rw [Finset.mem_singleton.mp i.2]; exact hv₀_norm,
        fun i j hne => False.elim (hne (Subtype.ext
          ((Finset.mem_singleton.mp i.2).trans (Finset.mem_singleton.mp j.2).symm)))⟩⟩
    have h1 : ‖W v₀‖ ^ 2 ≤ UL.hilbertSchmidtNorm W ^ 2 := by
      unfold UL.hilbertSchmidtNorm
      rw [Real.sq_sqrt h_sup_nn]
      have hsum1 : ‖W v₀‖ ^ 2 = ∑ v ∈ s₁.1, ‖W v‖ ^ 2 := by simp [s₁]
      rw [hsum1]
      exact le_ciSup h_bdd s₁
    have hWv₀ : ‖W v₀‖ = ‖x‖⁻¹ * ‖W x‖ := by
      dsimp [v₀]
      rw [map_smul, norm_smul, Real.norm_eq_abs, abs_inv, abs_norm]
    have hhs_nn : 0 ≤ UL.hilbertSchmidtNorm W := by
      unfold UL.hilbertSchmidtNorm
      exact Real.sqrt_nonneg _
    have hle_v₀ : ‖W v₀‖ ≤ UL.hilbertSchmidtNorm W := by
      have hnn1 : 0 ≤ ‖W v₀‖ := norm_nonneg _
      nlinarith
    rw [hWv₀, inv_mul_le_iff₀ hx_pos] at hle_v₀
    linarith [mul_comm ‖x‖ (UL.hilbertSchmidtNorm W)]

open Classical in
private noncomputable def evalProf {E : Type*} [NormedAddCommGroup E] {K : ℕ} (L : ℝ)
    (f : Metric.closedBall (0 : E) L × Fin K → ℝ) (x : E) (y : Fin K) : ℝ :=
  if hx : x ∈ Metric.closedBall (0 : E) L then f (⟨x, hx⟩, y) else 0

private lemma measurable_evalProf {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    [CompleteSpace E] [TopologicalSpace.SeparableSpace E]
    [MeasurableSpace E] [BorelSpace E]
    {K : ℕ} {L R C M₀ : ℝ} {f : Metric.closedBall (0 : E) L × Fin K → ℝ}
    (hf : f ∈ UL.ScoreProfileClass E K L R C M₀) :
    Measurable (fun xy : E × Fin K => evalProf L f xy.1 xy.2) := by
  rcases hf with ⟨_, _, hR, _, _, W, a, hW, ha, hfa⟩
  have hex : ∀ y : Fin K, ∃ g : UL.ZeroSumSubspace K → ℝ,
      LipschitzWith (Real.toNNReal C) g ∧
      Set.EqOn (a y) g (Metric.closedBall (0 : UL.ZeroSumSubspace K) (L * R)) :=
    fun y => (ha y).1.extend_real
  choose g hg_lip hg_eq using hex
  have hWx : ∀ {x : E}, x ∈ Metric.closedBall (0 : E) L →
      W x ∈ Metric.closedBall (0 : UL.ZeroSumSubspace K) (L * R) := by
    intro x hx
    rw [Metric.mem_closedBall, dist_zero_right] at hx ⊢
    calc ‖W x‖
        ≤ UL.hilbertSchmidtNorm W * ‖x‖ := norm_apply_le_hs W x
      _ ≤ R * L := mul_le_mul hW hx (norm_nonneg x) hR.le
      _ = L * R := mul_comm R L
  have h_eq : (fun xy : E × Fin K => evalProf L f xy.1 xy.2) =
      fun xy : E × Fin K =>
        ∑ y₀ : Fin K,
          (if xy.2 = y₀ then (1 : ℝ) else 0) *
            Set.indicator (Metric.closedBall (0 : E) L) (fun x => g y₀ (W x)) xy.1 := by
    ext ⟨x, y⟩
    have hsum : ∑ y₀ : Fin K,
        (if y = y₀ then (1 : ℝ) else 0) *
          Set.indicator (Metric.closedBall (0 : E) L) (fun x => g y₀ (W x)) x =
        Set.indicator (Metric.closedBall (0 : E) L) (fun x => g y (W x)) x := by
      simp
    rw [hsum]
    unfold evalProf
    by_cases hx : x ∈ Metric.closedBall (0 : E) L
    · rw [dif_pos hx, Set.indicator_of_mem hx, hfa ⟨x, hx⟩ y]
      exact hg_eq y (hWx hx)
    · rw [dif_neg hx, Set.indicator_of_notMem hx]
  rw [h_eq]
  refine Finset.measurable_sum Finset.univ fun y₀ _ => ?_
  refine Measurable.mul ?_ ?_
  · exact Measurable.ite (measurable_snd (measurableSet_singleton y₀))
      measurable_const measurable_const
  · refine (Measurable.indicator ?_ Metric.isClosed_closedBall.measurableSet).comp measurable_fst
    exact ((hg_lip y₀).continuous.comp W.continuous).measurable

private noncomputable def pushProfile {E₁ E₂ : Type*}
    [NormedAddCommGroup E₁] [InnerProductSpace ℝ E₁]
    [NormedAddCommGroup E₂] [InnerProductSpace ℝ E₂]
    (e : E₁ ≃ₗᵢ[ℝ] E₂) {K : ℕ} {L : ℝ}
    (f : Metric.closedBall (0 : E₁) L × Fin K → ℝ) :
    Metric.closedBall (0 : E₂) L × Fin K → ℝ :=
  fun p => f (⟨e.symm p.1.1, by
    have hp := p.1.2
    rw [Metric.mem_closedBall, dist_zero_right] at hp ⊢
    rwa [e.symm.norm_map]⟩, p.2)

private lemma pushProfile_mem {E₁ E₂ : Type*}
    [NormedAddCommGroup E₁] [InnerProductSpace ℝ E₁] [CompleteSpace E₁]
    [TopologicalSpace.SeparableSpace E₁]
    [NormedAddCommGroup E₂] [InnerProductSpace ℝ E₂] [CompleteSpace E₂]
    [TopologicalSpace.SeparableSpace E₂]
    (e : E₁ ≃ₗᵢ[ℝ] E₂) {K : ℕ} {L R C M₀ : ℝ}
    {f : Metric.closedBall (0 : E₁) L × Fin K → ℝ}
    (hf : f ∈ UL.ScoreProfileClass E₁ K L R C M₀) :
    pushProfile e f ∈ UL.ScoreProfileClass E₂ K L R C M₀ := by
  rcases hf with ⟨hK, hL, hR, hC, hM₀, W, a, hW, ha, hfa⟩
  refine ⟨hK, hL, hR, hC, hM₀,
    W.comp e.symm.toContinuousLinearEquiv.toContinuousLinearMap, a, ?_, ha, ?_⟩
  · rwa [hilbertSchmidtNorm_comp_lie W e.symm]
  · intro x₂ y
    unfold pushProfile
    rw [hfa]
    rfl

private lemma pushProfile_symm_cancel {E₁ E₂ : Type*}
    [NormedAddCommGroup E₁] [InnerProductSpace ℝ E₁]
    [NormedAddCommGroup E₂] [InnerProductSpace ℝ E₂]
    (e : E₁ ≃ₗᵢ[ℝ] E₂) {K : ℕ} {L : ℝ}
    (f : Metric.closedBall (0 : E₂) L × Fin K → ℝ) :
    pushProfile e (pushProfile e.symm f) = f := by
  funext ⟨⟨x, hx⟩, y⟩
  unfold pushProfile
  dsimp only
  congr 1
  ext1
  · exact Subtype.ext (e.apply_symm_apply x)
  · rfl

private lemma evalProf_pushProfile {E₁ E₂ : Type*}
    [NormedAddCommGroup E₁] [InnerProductSpace ℝ E₁]
    [NormedAddCommGroup E₂] [InnerProductSpace ℝ E₂]
    (e : E₁ ≃ₗᵢ[ℝ] E₂) {K : ℕ} {L : ℝ}
    (f : Metric.closedBall (0 : E₁) L × Fin K → ℝ) (x : E₁) (y : Fin K) :
    evalProf L (pushProfile e f) (e x) y = evalProf L f x y := by
  unfold evalProf
  have hmem_iff : e x ∈ Metric.closedBall (0 : E₂) L ↔ x ∈ Metric.closedBall (0 : E₁) L := by
    simp [Metric.mem_closedBall, dist_zero_right, e.norm_map]
  by_cases hx : x ∈ Metric.closedBall (0 : E₁) L
  · have hex : e x ∈ Metric.closedBall (0 : E₂) L := hmem_iff.mpr hx
    rw [dif_pos hex, dif_pos hx]
    unfold pushProfile
    dsimp only
    congr 1
    ext1
    · exact Subtype.ext (e.symm_apply_apply x)
    · rfl
  · have hex : e x ∉ Metric.closedBall (0 : E₂) L := fun h => hx (hmem_iff.mp h)
    rw [dif_neg hex, dif_neg hx]

end Helpers

/-- Universe-polymorphic binary (`K = 2`) specialization of `S_lem_C_3`, intersected with the
full-measure sample-norm event `∀ i : Fin n, ‖X_samp i ω‖ ≤ L`. -/
theorem lem_C_3_binary_transfer (h_lem_C_3 : UL.S_lem_C_3.{u₁, u₂}) :
    ∃ C_2 : ℝ, 0 < C_2 ∧
      ∀ (X : Type v₁) [NormedAddCommGroup X] [InnerProductSpace ℝ X]
        [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
        [MeasurableSpace X] [BorelSpace X]
        (L R C M₀ : ℝ)
        (_hL : 0 < L) (_hR : 0 < R) (_hC : 0 < C) (_hM₀ : 0 < M₀)
        (n : ℕ) (_hn : 1 ≤ n)
        (δ : ℝ) (_hδ0 : 0 < δ) (_hδ1 : δ < 1)
        (ν : MeasureTheory.Measure (X × Fin 2)) [MeasureTheory.IsProbabilityMeasure ν]
        (_hX_bound : ∀ᵐ xy ∂ν, ‖xy.1‖ ≤ L)
        (Ω : Type v₂) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
        [MeasureTheory.IsProbabilityMeasure μ]
        (X_samp : Fin n → Ω → X) (Y_samp : Fin n → Ω → Fin 2)
        (_hX_meas : ∀ i : Fin n, Measurable (X_samp i))
        (_hY_meas : ∀ i : Fin n, Measurable (Y_samp i))
        (_hindep : ProbabilityTheory.iIndepFun (fun i ω => (X_samp i ω, Y_samp i ω)) μ)
        (_hident : ∀ i : Fin n,
          MeasureTheory.Measure.map (fun ω => (X_samp i ω, Y_samp i ω)) μ = ν),
        let D₀ : ℝ := M₀ + C * (L * R)
        let evalProfile : (Metric.closedBall (0 : X) L × Fin 2 → ℝ) → X → Fin 2 → ℝ :=
          open Classical in
          fun f x y => if hx : x ∈ Metric.closedBall (0 : X) L then f (⟨x, hx⟩, y) else 0
        let bound : ℝ :=
          C_2 * (D₀ * Real.log (2 * (n : ℝ)) + M₀ * Real.sqrt (Real.log (2 / δ))) /
            Real.sqrt (n : ℝ)
        ∃ E : Set Ω, MeasurableSet E ∧ (μ E).toReal ≥ 1 - δ ∧
          ∀ ω ∈ E,
            (∀ i : Fin n, ‖X_samp i ω‖ ≤ L) ∧
            sSup ((fun f : Metric.closedBall (0 : X) L × Fin 2 → ℝ =>
              |(∫ xy, evalProfile f xy.1 xy.2 ∂ν) -
                ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalProfile f (X_samp i ω) (Y_samp i ω)|) ''
              UL.ScoreProfileClass X 2 L R C M₀) ≤ bound := by
  obtain ⟨C_2, hC2_pos, hC2⟩ := h_lem_C_3 2 (by decide)
  refine ⟨C_2, hC2_pos, ?_⟩
  intro X _ _ _ _ _ _ L R C M₀ hL hR hC hM₀ n hn δ hδ0 hδ1
    ν _ hX_bound Ω _ μ _ X_samp Y_samp hX_meas hY_meas hindep hident D₀ evalProfile bound
  obtain ⟨w, b, _⟩ := exists_hilbertBasis ℝ X
  haveI : Countable w := countable_of_hilbertBasis b
  let ι₀ : Type 0 := Shrink.{0} w
  let e₀ : w ≃ ι₀ := equivShrink.{0} w
  let X₀ : Type 0 := lp (fun _ : ι₀ => ℝ) 2
  let X' : Type u₁ := lp (fun _ : ULift.{u₁} ι₀ => ℝ) 2
  let Φ₀ : X ≃ₗᵢ[ℝ] X₀ := reindexHilbertEquiv b e₀
  let b₀ : HilbertBasis ι₀ ℝ X₀ := HilbertBasis.ofRepr (LinearIsometryEquiv.refl ℝ X₀)
  let ξ : X₀ ≃ₗᵢ[ℝ] X' := reindexHilbertEquiv b₀ Equiv.ulift.symm
  let Φ : X ≃ₗᵢ[ℝ] X' := Φ₀.trans ξ
  haveI : TopologicalSpace.SeparableSpace X' :=
    Φ.surjective.denseRange.separableSpace Φ.continuous
  letI : MeasurableSpace X₀ := borel X₀
  haveI : BorelSpace X₀ := ⟨rfl⟩
  letI : MeasurableSpace X' := borel X'
  haveI : BorelSpace X' := ⟨rfl⟩
  have hΦ₀_meas : Measurable Φ₀ := Φ₀.continuous.measurable
  have hξ_meas : Measurable ξ := ξ.continuous.measurable
  have hΦ_meas : Measurable Φ := Φ.continuous.measurable
  let mapXY : X × Fin 2 → X' × Fin 2 := Prod.map Φ id
  have hmapXY_meas : Measurable mapXY := hΦ_meas.prodMap measurable_id
  let ν' : MeasureTheory.Measure (X' × Fin 2) := MeasureTheory.Measure.map mapXY ν
  haveI : MeasureTheory.IsProbabilityMeasure ν' :=
    ⟨by rw [MeasureTheory.Measure.map_apply hmapXY_meas MeasurableSet.univ, Set.preimage_univ,
      MeasureTheory.measure_univ]⟩
  have hX'_bound : ∀ᵐ xy' ∂ν', ‖xy'.1‖ ≤ L := by
    have hm : MeasurableSet {xy' : X' × Fin 2 | ‖xy'.1‖ ≤ L} :=
      measurableSet_le (continuous_norm.measurable.comp measurable_fst) measurable_const
    rw [MeasureTheory.ae_map_iff hmapXY_meas.aemeasurable hm]
    refine hX_bound.mono fun xy hxy => ?_
    simpa [mapXY, Φ.norm_map] using hxy
  let Ω₀ : Type 0 := Fin n → X₀ × Fin 2
  let Ω' : Type u₂ := ULift.{u₂} Ω₀
  have h_up_meas : Measurable (ULift.up : Ω₀ → Ω') := fun _ => id
  have h_down_meas : Measurable (ULift.down : Ω' → Ω₀) := fun _ => id
  let Ψ : Ω → Ω' := fun ω => ULift.up (fun i => (Φ₀ (X_samp i ω), Y_samp i ω))
  have hΨ_meas : Measurable Ψ :=
    h_up_meas.comp
      (measurable_pi_lambda _ fun i => (hΦ₀_meas.comp (hX_meas i)).prodMk (hY_meas i))
  let μ' : MeasureTheory.Measure Ω' := MeasureTheory.Measure.map Ψ μ
  haveI : MeasureTheory.IsProbabilityMeasure μ' :=
    ⟨by rw [MeasureTheory.Measure.map_apply hΨ_meas MeasurableSet.univ, Set.preimage_univ,
      MeasureTheory.measure_univ]⟩
  let X'_samp : Fin n → Ω' → X' := fun i ω' => ξ (ω'.down i).1
  let Y'_samp : Fin n → Ω' → Fin 2 := fun i ω' => (ω'.down i).2
  have hX'_meas : ∀ i : Fin n, Measurable (X'_samp i) := fun i =>
    hξ_meas.comp (measurable_fst.comp ((measurable_pi_apply i).comp h_down_meas))
  have hY'_meas : ∀ i : Fin n, Measurable (Y'_samp i) := fun i =>
    measurable_snd.comp ((measurable_pi_apply i).comp h_down_meas)
  have hZ'_comp : ∀ i : Fin n,
      (fun ω' : Ω' => (X'_samp i ω', Y'_samp i ω')) ∘ Ψ =
        fun ω : Ω => mapXY (X_samp i ω, Y_samp i ω) := by
    intro i
    funext ω
    rfl
  have hident' : ∀ i : Fin n,
      MeasureTheory.Measure.map (fun ω' => (X'_samp i ω', Y'_samp i ω')) μ' = ν' := by
    intro i
    rw [MeasureTheory.Measure.map_map ((hX'_meas i).prodMk (hY'_meas i)) hΨ_meas, hZ'_comp i]
    have hcomp_eq :
        (fun ω : Ω => mapXY (X_samp i ω, Y_samp i ω)) =
          mapXY ∘ (fun ω : Ω => (X_samp i ω, Y_samp i ω)) := rfl
    rw [hcomp_eq, ← MeasureTheory.Measure.map_map hmapXY_meas ((hX_meas i).prodMk (hY_meas i)),
      hident i]
  have hindep' : ProbabilityTheory.iIndepFun (fun i ω' => (X'_samp i ω', Y'_samp i ω')) μ' := by
    have hindep_comp : ProbabilityTheory.iIndepFun
        (fun i ω => mapXY (X_samp i ω, Y_samp i ω)) μ :=
      hindep.comp (fun _ => mapXY) (fun _ => hmapXY_meas)
    rw [ProbabilityTheory.iIndepFun_iff_measure_inter_preimage_eq_mul]
    intro S sets hsets
    have hmeas_inter :
        MeasurableSet (⋂ i ∈ S, (fun ω' : Ω' => (X'_samp i ω', Y'_samp i ω')) ⁻¹' sets i) :=
      MeasurableSet.biInter S.countable_toSet fun i hi =>
        ((hX'_meas i).prodMk (hY'_meas i)) (hsets i hi)
    rw [MeasureTheory.Measure.map_apply hΨ_meas hmeas_inter]
    have hpre_inter :
        Ψ ⁻¹' (⋂ i ∈ S, (fun ω' : Ω' => (X'_samp i ω', Y'_samp i ω')) ⁻¹' sets i) =
          ⋂ i ∈ S, (fun ω : Ω => mapXY (X_samp i ω, Y_samp i ω)) ⁻¹' sets i := by
      ext ω
      simp only [Set.mem_preimage, Set.mem_iInter]
      rfl
    rw [hpre_inter, hindep_comp.measure_inter_preimage_eq_mul S hsets]
    refine Finset.prod_congr rfl fun i hi => ?_
    rw [MeasureTheory.Measure.map_apply hΨ_meas (((hX'_meas i).prodMk (hY'_meas i)) (hsets i hi))]
    rfl
  obtain ⟨E', hE'_meas, hE'_prob, hE'_sup⟩ :=
    hC2 X' L R C M₀ hL hR hC hM₀ n hn δ hδ0 hδ1 ν' hX'_bound Ω' μ' X'_samp Y'_samp
      hX'_meas hY'_meas hindep' hident'
  have hdev_eq : ∀ ω : Ω,
      ((fun f : Metric.closedBall (0 : X) L × Fin 2 → ℝ =>
        |(∫ xy, evalProfile f xy.1 xy.2 ∂ν) -
          ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalProfile f (X_samp i ω) (Y_samp i ω)|) ''
        UL.ScoreProfileClass X 2 L R C M₀) =
      ((fun f' : Metric.closedBall (0 : X') L × Fin 2 → ℝ =>
        |(∫ xy', evalProf L f' xy'.1 xy'.2 ∂ν') -
          ((1 : ℝ) / (n : ℝ)) *
            ∑ i : Fin n, evalProf L f' (X'_samp i (Ψ ω)) (Y'_samp i (Ψ ω))|) ''
        UL.ScoreProfileClass X' 2 L R C M₀) := by
    intro ω
    have heval_eq : evalProfile = evalProf (E := X) (K := 2) L := rfl
    rw [heval_eq]
    have hpoint : ∀ f : Metric.closedBall (0 : X) L × Fin 2 → ℝ,
        f ∈ UL.ScoreProfileClass X 2 L R C M₀ →
        |(∫ xy', evalProf L (pushProfile Φ f) xy'.1 xy'.2 ∂ν') -
          ((1 : ℝ) / (n : ℝ)) *
            ∑ i : Fin n, evalProf L (pushProfile Φ f) (X'_samp i (Ψ ω)) (Y'_samp i (Ψ ω))| =
        |(∫ xy, evalProf L f xy.1 xy.2 ∂ν) -
          ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalProf L f (X_samp i ω) (Y_samp i ω)| := by
      intro f hf
      have hf' : pushProfile Φ f ∈ UL.ScoreProfileClass X' 2 L R C M₀ := pushProfile_mem Φ hf
      have hint :
          ∫ xy', evalProf L (pushProfile Φ f) xy'.1 xy'.2 ∂ν' =
            ∫ xy, evalProf L f xy.1 xy.2 ∂ν := by
        dsimp [ν']
        rw [MeasureTheory.integral_map hmapXY_meas.aemeasurable
          (measurable_evalProf hf').aestronglyMeasurable]
        refine MeasureTheory.integral_congr_ae (Filter.Eventually.of_forall fun xy => ?_)
        exact evalProf_pushProfile Φ f xy.1 xy.2
      have hsum :
          (∑ i : Fin n, evalProf L (pushProfile Φ f) (X'_samp i (Ψ ω)) (Y'_samp i (Ψ ω))) =
            ∑ i : Fin n, evalProf L f (X_samp i ω) (Y_samp i ω) := by
        refine Finset.sum_congr rfl fun i _ => ?_
        exact evalProf_pushProfile Φ f (X_samp i ω) (Y_samp i ω)
      rw [hint, hsum]
    ext r
    constructor
    · rintro ⟨f, hf, rfl⟩
      exact ⟨pushProfile Φ f, pushProfile_mem Φ hf, hpoint f hf⟩
    · rintro ⟨f', hf', rfl⟩
      let f : Metric.closedBall (0 : X) L × Fin 2 → ℝ := pushProfile Φ.symm f'
      have hf : f ∈ UL.ScoreProfileClass X 2 L R C M₀ := pushProfile_mem Φ.symm hf'
      have hpush_f : pushProfile Φ f = f' := pushProfile_symm_cancel Φ f'
      refine ⟨f, hf, ?_⟩
      dsimp only
      rw [← hpoint f hf, hpush_f]
  let E_norm : Set Ω := ⋂ i : Fin n, {ω : Ω | ‖X_samp i ω‖ ≤ L}
  have hEnorm_meas : MeasurableSet E_norm :=
    MeasurableSet.iInter fun i =>
      measurableSet_le (continuous_norm.measurable.comp (hX_meas i)) measurable_const
  have hEnorm_compl : μ E_normᶜ = 0 := by
    have hcompl_eq : E_normᶜ = ⋃ i : Fin n, {ω : Ω | L < ‖X_samp i ω‖} := by
      ext ω
      simp [E_norm, not_le]
    rw [hcompl_eq, MeasureTheory.measure_iUnion_null_iff]
    intro i
    have hB_meas : MeasurableSet {xy : X × Fin 2 | L < ‖xy.1‖} :=
      measurableSet_lt measurable_const (continuous_norm.measurable.comp measurable_fst)
    have hB_null : ν {xy : X × Fin 2 | L < ‖xy.1‖} = 0 := by
      have hae : ν {xy : X × Fin 2 | ¬ ‖xy.1‖ ≤ L} = 0 := MeasureTheory.ae_iff.mp hX_bound
      simpa [not_le] using hae
    have hpre :
        {ω : Ω | L < ‖X_samp i ω‖} =
          (fun ω : Ω => (X_samp i ω, Y_samp i ω)) ⁻¹' {xy : X × Fin 2 | L < ‖xy.1‖} := rfl
    rw [hpre, ← MeasureTheory.Measure.map_apply ((hX_meas i).prodMk (hY_meas i)) hB_meas,
      hident i, hB_null]
  let E : Set Ω := (Ψ ⁻¹' E') ∩ E_norm
  have hE_meas : MeasurableSet E := (hΨ_meas hE'_meas).inter hEnorm_meas
  have hE_mu : μ E = μ' E' := by
    have hdiff_null : μ ((Ψ ⁻¹' E') \ E_norm) = 0 := by
      refine le_antisymm ?_ (zero_le _)
      calc μ ((Ψ ⁻¹' E') \ E_norm)
          ≤ μ E_normᶜ := MeasureTheory.measure_mono fun _ h => h.2
        _ = 0 := hEnorm_compl
    have hadd := MeasureTheory.measure_inter_add_diff (μ := μ) (Ψ ⁻¹' E') hEnorm_meas
    rw [hdiff_null, add_zero] at hadd
    dsimp [E, μ']
    rw [hadd, MeasureTheory.Measure.map_apply hΨ_meas hE'_meas]
  refine ⟨E, hE_meas, ?_, ?_⟩
  · rw [hE_mu]
    exact hE'_prob
  · intro ω hω
    refine ⟨fun i => Set.mem_iInter.mp hω.2 i, ?_⟩
    rw [hdev_eq ω]
    have hraw := hE'_sup (Ψ ω) hω.1
    have hbound_eq :
        (if (2 - 1 : ℕ) ≤ 2 then
          C_2 * ((M₀ + C * (L * R)) * Real.log (2 * (n : ℝ)) +
            M₀ * Real.sqrt (Real.log (2 / δ))) / Real.sqrt (n : ℝ)
        else
          C_2 * (M₀ + C * (L * R)) * ((n : ℝ) ^ (-(1 : ℝ) / ((2 - 1 : ℕ) : ℝ))) +
            C_2 * M₀ * Real.sqrt (Real.log (2 / δ) / (n : ℝ))) = bound :=
      if_pos (by decide)
    exact le_trans hraw (le_of_eq hbound_eq)

end UL.Proof_cor_C_6

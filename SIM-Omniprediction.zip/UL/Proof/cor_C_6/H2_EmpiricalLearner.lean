import Mathlib
import UL.Def.def_3_binary
import UL.Proof.thm_3_2.H1_Fit
import UL.Proof.thm_3_2.H2_Perturb
import UL.Proof.thm_3_2.H3_LossFixedPoint
set_option autoImplicit false

namespace UL.Proof_cor_C_6

private noncomputable def empMeasure (n : ℕ) : MeasureTheory.Measure (Fin n) :=
  ENNReal.ofReal ((1 : ℝ) / (n : ℝ)) • ∑ i : Fin n, MeasureTheory.Measure.dirac i

private lemma isProbabilityMeasure_empMeasure {n : ℕ} (hn : 1 ≤ n) :
    MeasureTheory.IsProbabilityMeasure (empMeasure n) := by
  refine ⟨?_⟩
  unfold empMeasure
  rw [MeasureTheory.Measure.smul_apply, smul_eq_mul, MeasureTheory.Measure.finset_sum_apply]
  have hdirac : ∀ i : Fin n, MeasureTheory.Measure.dirac i Set.univ = 1 := by
    intro i
    simp [MeasureTheory.Measure.dirac_apply' i MeasurableSet.univ]
  simp_rw [hdirac]
  rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, mul_one]
  have hn_pos : (0 : ℝ) < (n : ℝ) := by exact_mod_cast lt_of_lt_of_le Nat.zero_lt_one hn
  rw [← ENNReal.ofReal_natCast n, ← ENNReal.ofReal_mul (by positivity),
    one_div_mul_cancel hn_pos.ne', ENNReal.ofReal_one]

private lemma integral_empMeasure {n : ℕ} (g : Fin n → ℝ) :
    ∫ i, g i ∂(empMeasure n) = ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, g i := by
  unfold empMeasure
  rw [MeasureTheory.integral_smul_measure, smul_eq_mul]
  have htoReal : (ENNReal.ofReal ((1 : ℝ) / (n : ℝ))).toReal = (1 : ℝ) / (n : ℝ) :=
    ENNReal.toReal_ofReal (by positivity)
  rw [htoReal]
  congr 1
  rw [MeasureTheory.integral_finset_sum_measure]
  · refine Finset.sum_congr rfl fun i _ => ?_
    exact MeasureTheory.integral_dirac g i
  · intro i _
    exact MeasureTheory.integrable_dirac (by simp)

private lemma forall_of_ae_empMeasure {n : ℕ} (hn : 1 ≤ n) {Q : Fin n → Prop}
    (hQ : ∀ᵐ i ∂(empMeasure n), Q i) : ∀ i : Fin n, Q i := by
  intro i₀
  by_contra hi₀
  have hzero : empMeasure n {i : Fin n | ¬ Q i} = 0 := MeasureTheory.ae_iff.mp hQ
  have hsub : ({i₀} : Set (Fin n)) ⊆ {i : Fin n | ¬ Q i} := by
    intro j hj
    rw [Set.mem_singleton_iff.mp hj]
    exact hi₀
  have hmeas0 : empMeasure n {i₀} = 0 := MeasureTheory.measure_mono_null hsub hzero
  have hpos : 0 < empMeasure n {i₀} := by
    unfold empMeasure
    rw [MeasureTheory.Measure.smul_apply, smul_eq_mul, MeasureTheory.Measure.finset_sum_apply]
    have h1 : (1 : ENNReal) ≤ ∑ j : Fin n, MeasureTheory.Measure.dirac j {i₀} := by
      calc
        (1 : ENNReal) = MeasureTheory.Measure.dirac i₀ {i₀} := by simp
        _ ≤ ∑ j : Fin n, MeasureTheory.Measure.dirac j {i₀} :=
          Finset.single_le_sum
            (f := fun j : Fin n => MeasureTheory.Measure.dirac j {i₀})
            (fun _ _ => zero_le _) (Finset.mem_univ i₀)
    have hn_pos : (0 : ℝ) < (1 : ℝ) / (n : ℝ) := by
      have : (0 : ℝ) < (n : ℝ) := by exact_mod_cast lt_of_lt_of_le Nat.zero_lt_one hn
      positivity
    have hc_pos : (0 : ENNReal) < ENNReal.ofReal ((1 : ℝ) / (n : ℝ)) :=
      ENNReal.ofReal_pos.mpr hn_pos
    calc
      (0 : ENNReal) < ENNReal.ofReal ((1 : ℝ) / (n : ℝ)) * 1 := by
        simpa only [mul_one] using hc_pos
      _ ≤ ENNReal.ofReal ((1 : ℝ) / (n : ℝ)) *
            ∑ j : Fin n, MeasureTheory.Measure.dirac j {i₀} := by
          gcongr
  exact hpos.ne' hmeas0

private lemma integrable_empMeasure {n : ℕ} (hn : 1 ≤ n) (g : Fin n → ℝ) :
    MeasureTheory.Integrable g (empMeasure n) := by
  haveI : MeasureTheory.IsProbabilityMeasure (empMeasure n) := isProbabilityMeasure_empMeasure hn
  refine MeasureTheory.Integrable.of_bound (measurable_of_finite g).aestronglyMeasurable
    (∑ j : Fin n, ‖g j‖) ?_
  refine Filter.Eventually.of_forall fun i => ?_
  exact Finset.single_le_sum (fun j _ => norm_nonneg (g j)) (Finset.mem_univ i)

private lemma convexOn_sq_Icc :
    ConvexOn ℝ (Set.Icc (0 : ℝ) 1) (fun q : ℝ => q ^ 2) := by
  refine ⟨convex_Icc 0 1, ?_⟩
  intro x _ y _ a b ha hb hab
  simp only [smul_eq_mul]
  have hdiff : a * x ^ 2 + b * y ^ 2 - (a * x + b * y) ^ 2 = a * b * (x - y) ^ 2 := by
    calc
      a * x ^ 2 + b * y ^ 2 - (a * x + b * y) ^ 2
        = (a * x ^ 2 + b * y ^ 2) * (a + b) - (a * x + b * y) ^ 2 := by rw [hab, mul_one]
      _ = a * b * (x - y) ^ 2 := by ring
  have hnonneg : 0 ≤ a * b * (x - y) ^ 2 :=
    mul_nonneg (mul_nonneg ha hb) (sq_nonneg (x - y))
  linarith

private lemma binaryEntropyFamily_mono {β B : ℝ} (hB : β ≤ B)
    {φ : Set.Icc (0 : ℝ) 1 → ℝ} (hφ : φ ∈ UL.BinaryEntropyFamily β) :
    φ ∈ UL.BinaryEntropyFamily B := by
  obtain ⟨hβ, hcont, hdiff, hconv⟩ := hφ
  have hB_pos : 0 < B := lt_of_lt_of_le hβ hB
  refine ⟨hB_pos, hcont, hdiff, ?_⟩
  have hc_nonneg : 0 ≤ 1 / (2 * β) - 1 / (2 * B) := by
    rw [sub_nonneg]
    exact one_div_le_one_div_of_le (by positivity) (by linarith)
  have hquad : ConvexOn ℝ (Set.Icc (0 : ℝ) 1)
      (fun q : ℝ => (1 / (2 * β) - 1 / (2 * B)) * q ^ 2) := by
    simpa [smul_eq_mul] using convexOn_sq_Icc.smul hc_nonneg
  have hsum := hconv.add hquad
  refine hsum.congr fun q _ => ?_
  dsimp only [Pi.add_apply]
  ring

private lemma convexOn_ext_of_mem_family {β : ℝ}
    {φ : Set.Icc (0 : ℝ) 1 → ℝ} (hφ : φ ∈ UL.BinaryEntropyFamily β)
    {φ_ext : ℝ → ℝ} (hφ_ext : ∀ q : Set.Icc (0 : ℝ) 1, φ_ext q = φ q) :
    ConvexOn ℝ (Set.Icc (0 : ℝ) 1) φ_ext := by
  obtain ⟨hβ, _, _, hconv⟩ := hφ
  have hc_nonneg : 0 ≤ 1 / (2 * β) := by positivity
  have hquad : ConvexOn ℝ (Set.Icc (0 : ℝ) 1) (fun q : ℝ => (1 / (2 * β)) * q ^ 2) := by
    simpa [smul_eq_mul] using convexOn_sq_Icc.smul hc_nonneg
  have hsum := hconv.add hquad
  refine hsum.congr fun q hq => ?_
  dsimp only [Pi.add_apply]
  have hext : UL.extendUnitInterval φ q = φ_ext q := by
    unfold UL.extendUnitInterval
    rw [dif_pos hq, ← hφ_ext ⟨q, hq⟩]
  linarith

private lemma deriv_mul_sub_le_of_convexOn_Icc
    {φ_ext : ℝ → ℝ} (hconv : ConvexOn ℝ (Set.Icc (0 : ℝ) 1) φ_ext)
    {p q : ℝ} (hp : p ∈ Set.Icc (0 : ℝ) 1) (hq : q ∈ Set.Icc (0 : ℝ) 1)
    (hderiv : HasDerivAt φ_ext (deriv φ_ext p) p) :
    deriv φ_ext p * (q - p) ≤ φ_ext q - φ_ext p := by
  let t : ℕ → ℝ := fun k => 1 / ((k : ℝ) + 2)
  have ht_pos : ∀ k : ℕ, 0 < t k := fun k => by dsimp [t]; positivity
  have ht_ne : ∀ k : ℕ, t k ≠ 0 := fun k => (ht_pos k).ne'
  have ht_le_one : ∀ k : ℕ, t k ≤ 1 := by
    intro k
    have hk : (1 : ℝ) ≤ (k : ℝ) + 2 := by linarith [Nat.cast_nonneg (α := ℝ) k]
    dsimp [t]
    exact div_le_one_of_le₀ hk (by positivity)
  have ht_lim : Filter.Tendsto t Filter.atTop (nhds 0) :=
    (tendsto_const_nhds (x := (1 : ℝ))).div_atTop
      (Filter.tendsto_atTop_add_const_right Filter.atTop 2 tendsto_natCast_atTop_atTop)
  have ht_nhds : Filter.Tendsto t Filter.atTop (nhdsWithin 0 {(0 : ℝ)}ᶜ) :=
    tendsto_nhdsWithin_iff.mpr ⟨ht_lim, Filter.Eventually.of_forall ht_ne⟩
  let g : ℝ → ℝ := fun s => φ_ext (p + s * (q - p))
  have h_aff : HasDerivAt (fun s : ℝ => p + s * (q - p)) (q - p) 0 := by
    simpa using ((hasDerivAt_id (0 : ℝ)).mul_const (q - p)).const_add p
  have hg_deriv : HasDerivAt g (deriv φ_ext p * (q - p)) 0 := by
    have hp0 : p + (0 : ℝ) * (q - p) = p := by ring
    have hderiv' : HasDerivAt φ_ext (deriv φ_ext p) (p + (0 : ℝ) * (q - p)) := by
      rwa [hp0]
    exact hderiv'.comp (0 : ℝ) h_aff
  have hg_slope := (hasDerivAt_iff_tendsto_slope_zero.mp hg_deriv).comp ht_nhds
  have h_le : ∀ k : ℕ, (t k)⁻¹ • (g (0 + t k) - g 0) ≤ φ_ext q - φ_ext p := by
    intro k
    have h1t : 0 ≤ 1 - t k := sub_nonneg.mpr (ht_le_one k)
    have htk : 0 ≤ t k := (ht_pos k).le
    have hsum1 : (1 - t k) + t k = 1 := by ring
    have h_cvx := hconv.2 hp hq h1t htk hsum1
    simp only [smul_eq_mul] at h_cvx ⊢
    have harg : (1 - t k) * p + t k * q = p + t k * (q - p) := by ring
    rw [harg] at h_cvx
    have hg0 : g 0 = φ_ext p := by simp [g]
    have hgk : g (0 + t k) = φ_ext (p + t k * (q - p)) := by simp [g]
    rw [hg0, hgk, inv_mul_le_iff₀ (ht_pos k)]
    linarith
  exact le_of_tendsto hg_slope (Filter.Eventually.of_forall h_le)

private lemma matchingLoss_deriv_eq_canonicalLoss
    {β : ℝ} {φ : Set.Icc (0 : ℝ) 1 → ℝ} (hφ : φ ∈ UL.BinaryEntropyFamily β)
    {U : Set ℝ} {φ_ext : ℝ → ℝ}
    (hU_open : IsOpen U) (hU_sub : Set.Icc (0 : ℝ) 1 ⊆ U)
    (hφ_ext : ∀ q : Set.Icc (0 : ℝ) 1, φ_ext q = φ q)
    (hφ_diff : DifferentiableOn ℝ φ_ext U)
    {p : ℝ} (hp : p ∈ Set.Icc (0 : ℝ) 1) {y : Fin 2}
    (hend : (p = 0 → y = 0) ∧ (p = 1 → y = 1)) :
    UL.binaryMatchingLoss φ (deriv φ_ext p) y =
      (UL.binaryExtendedCanonicalLoss φ p y).toReal := by
  have hconv : ConvexOn ℝ (Set.Icc (0 : ℝ) 1) φ_ext :=
    convexOn_ext_of_mem_family hφ hφ_ext
  have hdiff_p : DifferentiableAt ℝ φ_ext p :=
    (hφ_diff p (hU_sub hp)).differentiableAt (hU_open.mem_nhds (hU_sub hp))
  have hderiv_p : HasDerivAt φ_ext (deriv φ_ext p) p := hdiff_p.hasDerivAt
  let a : ℝ := deriv φ_ext p
  haveI : Nonempty (Set.Icc (0 : ℝ) 1) := ⟨⟨0, Set.left_mem_Icc.mpr zero_le_one⟩⟩
  have hbdd : BddAbove (Set.range (fun q : Set.Icc (0 : ℝ) 1 => (q : ℝ) * a - φ q)) := by
    have hc : Continuous (fun q : Set.Icc (0 : ℝ) 1 => (q : ℝ) * a - φ q) :=
      (continuous_subtype_val.mul continuous_const).sub hφ.2.1
    exact (isCompact_range hc).bddAbove
  have hpot : UL.binaryMatchingPotential φ a = p * a - φ ⟨p, hp⟩ := by
    apply le_antisymm
    · unfold UL.binaryMatchingPotential
      refine ciSup_le fun q => ?_
      have h_sup := deriv_mul_sub_le_of_convexOn_Icc hconv hp q.2 hderiv_p
      rw [hφ_ext q, hφ_ext ⟨p, hp⟩] at h_sup
      dsimp [a]
      linarith
    · exact le_ciSup hbdd ⟨p, hp⟩
  have hmatch : UL.binaryMatchingLoss φ a y = -φ ⟨p, hp⟩ + a * (p - (y.val : ℝ)) := by
    unfold UL.binaryMatchingLoss
    rw [hpot]
    ring
  rw [hmatch]
  rcases eq_or_lt_of_le hp.1 with hp0 | hp0
  · have hp0' : p = 0 := hp0.symm
    have hy0 : y = 0 := hend.1 hp0'
    have hnot_ioo : p ∉ Set.Ioo (0 : ℝ) 1 := by simp [hp0']
    unfold UL.binaryExtendedCanonicalLoss
    rw [dif_neg hnot_ioo, if_pos ⟨hp0', hy0⟩, EReal.toReal_coe]
    have hsub : (⟨p, hp⟩ : Set.Icc (0 : ℝ) 1) = ⟨0, Set.left_mem_Icc.mpr zero_le_one⟩ := by
      ext; exact hp0'
    simp [hsub, hp0', hy0]
  · rcases lt_or_eq_of_le hp.2 with hp1 | hp1
    · have hioo : p ∈ Set.Ioo (0 : ℝ) 1 := ⟨hp0, hp1⟩
      unfold UL.binaryExtendedCanonicalLoss
      rw [dif_pos hioo, EReal.toReal_coe]
      have hev : UL.extendUnitInterval φ =ᶠ[nhds p] φ_ext := by
        refine Filter.eventuallyEq_of_mem (isOpen_Ioo.mem_nhds hioo) fun z hz => ?_
        have hz_icc : z ∈ Set.Icc (0 : ℝ) 1 := Set.Ioo_subset_Icc_self hz
        unfold UL.extendUnitInterval
        rw [dif_pos hz_icc, ← hφ_ext ⟨z, hz_icc⟩]
      rw [hev.deriv_eq]
    · have hy1 : y = 1 := hend.2 hp1
      have hnot_ioo : p ∉ Set.Ioo (0 : ℝ) 1 := by simp [hp1]
      have hnot_0 : ¬(p = 0 ∧ y = 0) := by rw [hp1]; norm_num
      unfold UL.binaryExtendedCanonicalLoss
      rw [dif_neg hnot_ioo, if_neg hnot_0, if_pos ⟨hp1, hy1⟩, EReal.toReal_coe]
      have hsub : (⟨p, hp⟩ : Set.Icc (0 : ℝ) 1) = ⟨1, Set.right_mem_Icc.mpr zero_le_one⟩ := by
        ext; exact hp1
      simp [hsub, hp1, hy1]

private lemma exists_learner_for_sample
    (X : Type*) [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    (R B : ℝ) (hR : 0 < R) (hB_pos : 0 < B)
    (n : ℕ) (hn : 1 ≤ n) (sample : Fin n → X × Fin 2) :
    ∃ (w : X) (ρ : ℝ → ℝ),
      (‖w‖ ≤ R ∧
        Monotone ρ ∧
        LipschitzWith (Real.toNNReal B) ρ ∧
        (∀ t : ℝ, ρ t ∈ Set.Icc (0 : ℝ) 1)) ∧
      (∀ i : Fin n,
        (ρ (inner ℝ w (sample i).1) = 0 → (sample i).2 = 0) ∧
        (ρ (inner ℝ w (sample i).1) = 1 → (sample i).2 = 1)) ∧
      (∀ φ ∈ UL.BinaryEntropyFamily B, ∀ v : X, ‖v‖ ≤ R →
        ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
            (UL.binaryExtendedCanonicalLoss φ (ρ (inner ℝ w (sample i).1)) (sample i).2).toReal ≤
          ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
            UL.binaryMatchingLoss φ (inner ℝ v (sample i).1) (sample i).2) := by
  let E_n : Submodule ℝ X := Submodule.span ℝ (Set.range (fun i : Fin n => (sample i).1))
  haveI : FiniteDimensional ℝ E_n := FiniteDimensional.span_of_finite ℝ (Set.finite_range _)
  let d : ℕ := Module.finrank ℝ E_n
  let bE : OrthonormalBasis (Fin d) ℝ E_n := stdOrthonormalBasis ℝ E_n
  let ι : EuclideanSpace ℝ (Fin d) →ₗᵢ[ℝ] X :=
    E_n.subtypeₗᵢ.comp bE.repr.symm.toLinearIsometry
  let x_sub : Fin n → E_n := fun i => ⟨(sample i).1, Submodule.subset_span ⟨i, rfl⟩⟩
  let x_coord : Fin n → EuclideanSpace ℝ (Fin d) := fun i => bE.repr (x_sub i)
  let y_emp : Fin n → Fin 2 := fun i => (sample i).2
  have hι_x : ∀ i : Fin n, ι (x_coord i) = (sample i).1 := by
    intro i
    dsimp [ι, x_coord, x_sub]
    simp
  haveI : MeasureTheory.IsProbabilityMeasure (empMeasure n) := isProbabilityMeasure_empMeasure hn
  have hX_meas : Measurable x_coord := measurable_of_finite x_coord
  have hY_meas : Measurable y_emp := measurable_of_finite y_emp
  have hX_int : MeasureTheory.Integrable (fun i => ‖x_coord i‖) (empMeasure n) :=
    integrable_empMeasure hn (fun i => ‖x_coord i‖)
  obtain ⟨ρ_fam, h_opt, h_vi, _, h_cont_g⟩ :=
    UL.Proof_thm_3_2.exists_optProfile_and_continuous_drift
      d (Fin n) (empMeasure n) x_coord y_emp hX_meas hY_meas B hB_pos hX_int
  let g : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d) :=
    fun w₀ => ∫ i, (ρ_fam w₀ (inner ℝ w₀ (x_coord i)) - UL.Proof_thm_3_2.yReal (y_emp i)) •
      x_coord i ∂(empMeasure n)
  obtain ⟨w₀, hw₀_norm, hw₀_fp⟩ :=
    UL.Proof_thm_3_2.exists_fixed_point_score d R hR g h_cont_g
  let ρ : ℝ → ℝ := ρ_fam w₀
  have hρ : UL.Proof_thm_3_2.IsProfile B ρ := (h_opt w₀).1
  let P : Fin n → ℝ := fun i => ρ (inner ℝ w₀ (x_coord i))
  have hP_meas : Measurable P := measurable_of_finite P
  have hP_mem : ∀ i : Fin n, P i ∈ Set.Icc (0 : ℝ) 1 := fun i => hρ.2.2 _
  have h_end_ae := UL.Proof_thm_3_2.ae_endpoint_support
    d (Fin n) (empMeasure n) x_coord y_emp hX_meas hY_meas B hB_pos w₀ ρ hρ (h_vi w₀)
  have h_own := UL.Proof_thm_3_2.own_score_ineq
    d (Fin n) (empMeasure n) x_coord y_emp hX_meas hY_meas B hB_pos hX_int w₀ ρ hρ (h_vi w₀)
  have h_conv := fun F hFc hFcv hFd =>
    UL.Proof_thm_3_2.convex_test_ineq
      d (Fin n) (empMeasure n) x_coord y_emp hX_meas hY_meas B hB_pos w₀ ρ hρ (h_vi w₀)
      F hFc hFcv hFd
  have h_fp_int : ∀ v₀ : EuclideanSpace ℝ (Fin d), ‖v₀‖ ≤ R →
      ∫ i, UL.Proof_thm_3_2.fitRes P y_emp i * inner ℝ w₀ (x_coord i) ∂(empMeasure n) ≤
        ∫ i, UL.Proof_thm_3_2.fitRes P y_emp i * inner ℝ v₀ (x_coord i) ∂(empMeasure n) := by
    intro v₀ hv₀
    have h_le := hw₀_fp v₀ hv₀
    have heq_v := UL.Proof_thm_3_2.inner_drift_eq
      d (Fin n) (empMeasure n) x_coord y_emp hX_meas hY_meas hX_int P hP_meas hP_mem v₀
    have heq_w := UL.Proof_thm_3_2.inner_drift_eq
      d (Fin n) (empMeasure n) x_coord y_emp hX_meas hY_meas hX_int P hP_meas hP_mem w₀
    change inner ℝ w₀ (g w₀) ≤ inner ℝ v₀ (g w₀) at h_le
    dsimp [g] at h_le
    linarith
  have h_loss_cmp := UL.Proof_thm_3_2.entropy_loss_comparison
    d (Fin n) (empMeasure n) x_coord y_emp hX_meas hY_meas R B hR hB_pos hX_int
    w₀ P hP_meas hP_mem h_end_ae h_own h_fp_int h_conv
  let w : X := ι w₀
  have hw_norm : ‖w‖ ≤ R := by
    rw [ι.norm_map]
    exact hw₀_norm
  have hw_inner : ∀ i : Fin n, inner ℝ w (sample i).1 = inner ℝ w₀ (x_coord i) := by
    intro i
    dsimp [w]
    rw [← hι_x i, ι.inner_map_map]
  have h_end : ∀ i : Fin n,
      (ρ (inner ℝ w (sample i).1) = 0 → (sample i).2 = 0) ∧
      (ρ (inner ℝ w (sample i).1) = 1 → (sample i).2 = 1) := by
    have h_all := forall_of_ae_empMeasure hn h_end_ae
    intro i
    rw [hw_inner i]
    exact h_all i
  refine ⟨w, ρ, ⟨hw_norm, hρ.1, hρ.2.1, hρ.2.2⟩, h_end, ?_⟩
  intro φ hφ v hv
  let v_sub : E_n := ∑ k : Fin d, inner ℝ (bE k : X) v • bE k
  let v_coord : EuclideanSpace ℝ (Fin d) := bE.repr v_sub
  have hι_v : ι v_coord = (v_sub : X) := by
    dsimp [ι, v_coord]
    simp
  have h_orth_basis : ∀ j : Fin d, inner ℝ (v - (v_sub : X)) (bE j : X) = 0 := by
    intro j
    rw [inner_sub_left]
    have hv_coe : (v_sub : X) = ∑ k : Fin d, inner ℝ (bE k : X) v • (bE k : X) := by
      dsimp [v_sub]
      simp
    rw [hv_coe, sum_inner]
    have hsum : (∑ k : Fin d, inner ℝ (inner ℝ (bE k : X) v • (bE k : X)) (bE j : X)) =
        inner ℝ v (bE j : X) := by
      have hterm : ∀ k : Fin d,
          inner ℝ (inner ℝ (bE k : X) v • (bE k : X)) (bE j : X) =
            if k = j then inner ℝ (bE k : X) v else 0 := by
        intro k
        have hinner_kj : inner ℝ (bE k : X) (bE j : X) = inner ℝ (bE k) (bE j) :=
          E_n.subtypeₗᵢ.inner_map_map (bE k) (bE j)
        rw [real_inner_smul_left, hinner_kj, orthonormal_iff_ite.mp bE.orthonormal k j]
        split_ifs <;> ring
      simp_rw [hterm]
      simp [real_inner_comm]
    rw [hsum, sub_self]
  have h_orth_sub : ∀ u : E_n, inner ℝ (v - (v_sub : X)) (u : X) = 0 := by
    intro u
    have hu_sum : u = ∑ j : Fin d, (bE.repr u j) • bE j := (bE.sum_repr u).symm
    have hu_coe : (u : X) = ∑ j : Fin d, (bE.repr u j) • (bE j : X) := by
      conv_lhs => rw [hu_sum]
      simp
    rw [hu_coe, inner_sum]
    refine Finset.sum_eq_zero fun j _ => ?_
    rw [real_inner_smul_right, h_orth_basis j, mul_zero]
  have hv_coord_norm : ‖v_coord‖ ≤ R := by
    have h0 : inner ℝ (v - (v_sub : X)) (v_sub : X) = 0 := h_orth_sub v_sub
    have hv_decomp : (v - (v_sub : X)) + (v_sub : X) = v := sub_add_cancel v (v_sub : X)
    have hpyth := norm_add_sq_real (v - (v_sub : X)) (v_sub : X)
    rw [hv_decomp, h0, mul_zero, add_zero] at hpyth
    have hnorm_eq : ‖v_coord‖ = ‖(v_sub : X)‖ := by
      dsimp [v_coord]
      rw [bE.repr.norm_map, Submodule.norm_coe]
    have hsq : ‖v_coord‖ ^ 2 ≤ ‖v‖ ^ 2 := by
      rw [hnorm_eq, hpyth]
      linarith [sq_nonneg ‖v - (v_sub : X)‖]
    have habs : |‖v_coord‖| ≤ |‖v‖| := sq_le_sq.mp hsq
    rw [abs_of_nonneg (norm_nonneg _), abs_of_nonneg (norm_nonneg _)] at habs
    exact le_trans habs hv
  have hv_inner : ∀ i : Fin n, inner ℝ v (sample i).1 = inner ℝ v_coord (x_coord i) := by
    intro i
    have h0 : inner ℝ (v - (v_sub : X)) (x_sub i : X) = 0 := h_orth_sub (x_sub i)
    rw [inner_sub_left] at h0
    have heq : inner ℝ v (sample i).1 = inner ℝ (v_sub : X) (sample i).1 :=
      sub_eq_zero.mp h0
    rw [heq, ← hι_v, ← hι_x i, ι.inner_map_map]
  have h_cmp_φ := (h_loss_cmp φ hφ).2.2.2
  have hbdd_below : BddBelow
      ((fun v₀ : EuclideanSpace ℝ (Fin d) =>
        ∫ i, UL.binaryMatchingLoss φ (inner ℝ v₀ (x_coord i)) (y_emp i) ∂(empMeasure n)) ''
        {v₀ | ‖v₀‖ ≤ R}) := by
    let q0 : Set.Icc (0 : ℝ) 1 := ⟨0, Set.left_mem_Icc.mpr zero_le_one⟩
    refine ⟨((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (-φ q0 - R * ‖x_coord i‖), ?_⟩
    rintro _ ⟨v₀, hv₀, rfl⟩
    have hv₀_norm : ‖v₀‖ ≤ R := hv₀
    dsimp only
    rw [integral_empMeasure]
    refine mul_le_mul_of_nonneg_left (Finset.sum_le_sum fun i _ => ?_) (by positivity)
    have hq0_le : (q0 : ℝ) * inner ℝ v₀ (x_coord i) - φ q0 ≤
        UL.binaryMatchingPotential φ (inner ℝ v₀ (x_coord i)) := by
      have hc : Continuous (fun q : Set.Icc (0 : ℝ) 1 =>
          (q : ℝ) * inner ℝ v₀ (x_coord i) - φ q) :=
        (continuous_subtype_val.mul continuous_const).sub hφ.2.1
      exact le_ciSup (isCompact_range hc).bddAbove q0
    have hq0_val : (q0 : ℝ) = 0 := rfl
    rw [hq0_val, zero_mul, zero_sub] at hq0_le
    have hy_le : ((y_emp i).val : ℝ) * inner ℝ v₀ (x_coord i) ≤ R * ‖x_coord i‖ := by
      have hy_icc := UL.Proof_thm_3_2.yReal_mem_Icc (y_emp i)
      change UL.Proof_thm_3_2.yReal (y_emp i) * inner ℝ v₀ (x_coord i) ≤ R * ‖x_coord i‖
      calc
        UL.Proof_thm_3_2.yReal (y_emp i) * inner ℝ v₀ (x_coord i)
          ≤ |UL.Proof_thm_3_2.yReal (y_emp i) * inner ℝ v₀ (x_coord i)| := le_abs_self _
        _ = UL.Proof_thm_3_2.yReal (y_emp i) * |inner ℝ v₀ (x_coord i)| := by
          rw [abs_mul, abs_of_nonneg hy_icc.1]
        _ ≤ 1 * (‖v₀‖ * ‖x_coord i‖) := by
          gcongr
          · exact hy_icc.2
          · exact abs_real_inner_le_norm v₀ (x_coord i)
        _ ≤ 1 * (R * ‖x_coord i‖) := by gcongr
        _ = R * ‖x_coord i‖ := one_mul _
    unfold UL.binaryMatchingLoss
    linarith
  have h_le_int :
      (∫ i, (UL.binaryExtendedCanonicalLoss φ (P i) (y_emp i)).toReal ∂(empMeasure n)) ≤
        ∫ i, UL.binaryMatchingLoss φ (inner ℝ v_coord (x_coord i)) (y_emp i) ∂(empMeasure n) :=
    le_trans h_cmp_φ (csInf_le hbdd_below ⟨v_coord, hv_coord_norm, rfl⟩)
  rw [integral_empMeasure, integral_empMeasure] at h_le_int
  have h_lhs : (∑ i : Fin n,
      (UL.binaryExtendedCanonicalLoss φ (ρ (inner ℝ w (sample i).1)) (sample i).2).toReal) =
      ∑ i : Fin n, (UL.binaryExtendedCanonicalLoss φ (P i) (y_emp i)).toReal := by
    refine Finset.sum_congr rfl fun i _ => ?_
    rw [hw_inner i]
  have h_rhs : (∑ i : Fin n, UL.binaryMatchingLoss φ (inner ℝ v (sample i).1) (sample i).2) =
      ∑ i : Fin n, UL.binaryMatchingLoss φ (inner ℝ v_coord (x_coord i)) (y_emp i) := by
    refine Finset.sum_congr rfl fun i _ => ?_
    rw [hv_inner i]
  rw [h_lhs, h_rhs]
  exact h_le_int

/-- Empirical monotone `B`-Lipschitz single-index learner on any sample of size `n ≥ 1`,
achieving exact simultaneous empirical comparison across all smooth `φ ∈ BinaryEntropyFamily β`
when `0 < β ≤ B`. -/
theorem exists_empirical_monotone_learner
    (X : Type*) [NormedAddCommGroup X] [InnerProductSpace ℝ X] [CompleteSpace X]
    (R β B : ℝ) (hR : 0 < R) (hβ : 0 < β) (hB : β ≤ B)
    (n : ℕ) (hn : 1 ≤ n) :
    ∃ (learnerW : (Fin n → X × Fin 2) → X)
      (learnerRho : (Fin n → X × Fin 2) → (ℝ → ℝ)),
      (∀ sample : Fin n → X × Fin 2,
        ‖learnerW sample‖ ≤ R ∧
        Monotone (learnerRho sample) ∧
        LipschitzWith (Real.toNNReal B) (learnerRho sample) ∧
        (∀ t : ℝ, learnerRho sample t ∈ Set.Icc (0 : ℝ) 1)) ∧
      (∀ (sample : Fin n → X × Fin 2)
        (φ : Set.Icc (0 : ℝ) 1 → ℝ) (U : Set ℝ) (φ_ext : ℝ → ℝ),
        φ ∈ UL.BinaryEntropyFamily β →
        IsOpen U →
        Set.Icc (0 : ℝ) 1 ⊆ U →
        (∀ q : Set.Icc (0 : ℝ) 1, φ_ext q = φ q) →
        DifferentiableOn ℝ φ_ext U →
        ∀ v : X, ‖v‖ ≤ R →
          ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
              UL.binaryMatchingLoss φ
                (deriv φ_ext (learnerRho sample (inner ℝ (learnerW sample) (sample i).1)))
                (sample i).2 ≤
            ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
              UL.binaryMatchingLoss φ (inner ℝ v (sample i).1) (sample i).2) := by
  let _ := ‹CompleteSpace X›
  have hB_pos : 0 < B := lt_of_lt_of_le hβ hB
  choose learnerW learnerRho h_spec using
    fun sample : Fin n → X × Fin 2 => exists_learner_for_sample X R B hR hB_pos n hn sample
  refine ⟨learnerW, learnerRho, fun sample => (h_spec sample).1, ?_⟩
  intro sample φ U φ_ext hφ hU_open hU_sub hφ_ext hφ_diff v hv
  have hφ_B : φ ∈ UL.BinaryEntropyFamily B := binaryEntropyFamily_mono hB hφ
  have h_emp := (h_spec sample).2.2 φ hφ_B v hv
  have h_eq : (∑ i : Fin n,
      UL.binaryMatchingLoss φ
        (deriv φ_ext (learnerRho sample (inner ℝ (learnerW sample) (sample i).1)))
        (sample i).2) =
      ∑ i : Fin n,
        (UL.binaryExtendedCanonicalLoss φ
          (learnerRho sample (inner ℝ (learnerW sample) (sample i).1))
          (sample i).2).toReal := by
    refine Finset.sum_congr rfl fun i _ => ?_
    exact matchingLoss_deriv_eq_canonicalLoss hφ hU_open hU_sub hφ_ext hφ_diff
      ((h_spec sample).1.2.2.2 _) ((h_spec sample).2.1 i)
  rw [h_eq]
  exact h_emp

end UL.Proof_cor_C_6

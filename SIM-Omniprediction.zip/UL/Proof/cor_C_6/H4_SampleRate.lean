import Mathlib
set_option autoImplicit false

namespace UL.Proof_cor_C_6

private lemma k0_bounds {K₀ : ℝ} (hK : 1 ≤ K₀) :
    64 ≤ 64 * K₀ ^ 2 ∧ 16 * K₀ ≤ 64 * K₀ ^ 2 := by
  constructor <;> nlinarith

private lemma sqrt_log_two_div_le {δ : ℝ} (hδ0 : 0 < δ) (hδ1 : δ < (1 : ℝ) / 2) :
    0 < Real.log (2 / δ) ∧ Real.sqrt (Real.log (2 / δ)) ≤ Real.log (2 / δ) := by
  have h2_div_δ_gt4 : 4 < 2 / δ := by
    rw [lt_div_iff₀ hδ0]
    linarith
  have hexp1_lt4 : Real.exp 1 < 4 := lt_trans Real.exp_one_lt_d9 (by norm_num)
  have h1_lt : 1 < Real.log (2 / δ) := by
    have h := Real.log_lt_log (Real.exp_pos 1) (lt_trans hexp1_lt4 h2_div_δ_gt4)
    rwa [Real.log_exp] at h
  have hpos : 0 < Real.log (2 / δ) := lt_trans zero_lt_one h1_lt
  refine ⟨hpos, ?_⟩
  have hsq : Real.log (2 / δ) ≤ (Real.log (2 / δ)) ^ 2 := by
    rw [sq]
    exact le_mul_of_one_le_right hpos.le h1_lt.le
  calc Real.sqrt (Real.log (2 / δ))
      ≤ Real.sqrt ((Real.log (2 / δ)) ^ 2) := Real.sqrt_le_sqrt hsq
    _ = Real.log (2 / δ) := Real.sqrt_sq hpos.le

private lemma log_two_mul_le_sqrt
    {K₀ R₀ : ℝ} (hK₀ : 0 < K₀) (hR₀ : 0 < R₀) {x : ℝ} (hx : 1 ≤ x) :
    K₀ * R₀ * Real.log (2 * x) ≤
      2 * K₀ * R₀ * Real.log (16 * K₀ * R₀) + (1 / 4 : ℝ) * Real.sqrt x := by
  have hx_pos : 0 < x := lt_of_lt_of_le zero_lt_one hx
  have h2x_pos : 0 < 2 * x := mul_pos zero_lt_two hx_pos
  let a : ℝ := 16 * K₀ * R₀
  let s : ℝ := Real.sqrt (2 * x)
  have ha_pos : 0 < a := mul_pos (mul_pos (by norm_num) hK₀) hR₀
  have hs_pos : 0 < s := Real.sqrt_pos.mpr h2x_pos
  have hs_le : s ≤ 2 * Real.sqrt x := by
    have h1 : 2 * x ≤ (2 * Real.sqrt x) ^ 2 := by
      rw [mul_pow, Real.sq_sqrt hx_pos.le]
      linarith
    calc s ≤ Real.sqrt ((2 * Real.sqrt x) ^ 2) := Real.sqrt_le_sqrt h1
      _ = 2 * Real.sqrt x := Real.sqrt_sq (mul_nonneg zero_le_two (Real.sqrt_nonneg x))
  have h2x_eq : 2 * x = (a * (s / a)) ^ 2 := by
    rw [mul_div_cancel₀ s ha_pos.ne']
    exact (Real.sq_sqrt h2x_pos.le).symm
  have hlog_2x : Real.log (2 * x) = 2 * Real.log a + 2 * Real.log (s / a) := by
    rw [h2x_eq, Real.log_pow, Real.log_mul ha_pos.ne' (div_pos hs_pos ha_pos).ne']
    ring
  have hlog_sa : Real.log (s / a) ≤ 2 * Real.sqrt x / a := by
    have h1 : Real.log (s / a) ≤ s / a - 1 :=
      Real.log_le_sub_one_of_pos (div_pos hs_pos ha_pos)
    have h2 : s / a ≤ 2 * Real.sqrt x / a :=
      div_le_div_of_nonneg_right hs_le ha_pos.le
    linarith
  have hKR_pos : 0 < K₀ * R₀ := mul_pos hK₀ hR₀
  have hcancel : K₀ * R₀ * (2 * (2 * Real.sqrt x / a)) = (1 / 4 : ℝ) * Real.sqrt x := by
    dsimp [a]
    field_simp [hK₀.ne', hR₀.ne']
    ring
  rw [hlog_2x]
  have hm : K₀ * R₀ * (2 * Real.log (s / a)) ≤ K₀ * R₀ * (2 * (2 * Real.sqrt x / a)) :=
    mul_le_mul_of_nonneg_left (by linarith) hKR_pos.le
  dsimp [a] at hm hcancel ⊢
  linarith

private lemma core_rate_bound
    {C_2 K₀ C R₀ D_bin D₀ M₀ ε δ x : ℝ}
    (hC2 : 0 < C_2) (hK₀_ge1 : 1 ≤ K₀) (h4C2_le : 4 * C_2 ≤ K₀)
    (hC_eq : C = 64 * K₀ ^ 2) (hR₀_eq : R₀ = D_bin / ε)
    (hD_bin : 0 < D_bin) (hD₀ : D₀ ≤ 2 * D_bin) (hM₀ : M₀ ≤ 2 * D_bin)
    (hε0 : 0 < ε) (hεD : ε ≤ D_bin)
    (hδ0 : 0 < δ) (hδ1 : δ < (1 : ℝ) / 2)
    (hx_ge1 : 1 ≤ x)
    (hx_large : C * R₀ ^ 2 * (Real.log (C * R₀ / δ)) ^ 2 ≤ x) :
    2 * (C_2 * (D₀ * Real.log (2 * x) + M₀ * Real.sqrt (Real.log (2 / δ))) /
      Real.sqrt x) ≤ ε := by
  have hK₀_pos : 0 < K₀ := lt_of_lt_of_le zero_lt_one hK₀_ge1
  have hR₀_ge1 : 1 ≤ R₀ := by
    rw [hR₀_eq]
    exact (one_le_div hε0).mpr hεD
  have hR₀_pos : 0 < R₀ := lt_of_lt_of_le zero_lt_one hR₀_ge1
  obtain ⟨hC_ge64, h16K_le_C⟩ := k0_bounds hK₀_ge1
  rw [← hC_eq] at hC_ge64 h16K_le_C
  have hC_pos : 0 < C := lt_of_lt_of_le (by norm_num) hC_ge64
  have hx_pos : 0 < x := lt_of_lt_of_le zero_lt_one hx_ge1
  have hsqrt_x_pos : 0 < Real.sqrt x := Real.sqrt_pos.mpr hx_pos
  obtain ⟨hlog2δ_pos, hsqrt_log2δ_le⟩ := sqrt_log_two_div_le hδ0 hδ1
  have hCR₀_ge64 : 64 ≤ C * R₀ := le_trans hC_ge64 (le_mul_of_one_le_right hC_pos.le hR₀_ge1)
  have h2δ_le_CR₀δ : 2 / δ ≤ C * R₀ / δ :=
    div_le_div_of_nonneg_right (by linarith) hδ0.le
  have h_one_le_inv_δ : 1 ≤ 1 / δ := by
    rw [one_le_div hδ0]
    linarith
  have h16_le_CR₀δ : 16 * K₀ * R₀ ≤ C * R₀ / δ := by
    have h1 : 16 * K₀ * R₀ ≤ C * R₀ := mul_le_mul_of_nonneg_right h16K_le_C hR₀_pos.le
    have hCR₀_pos : 0 < C * R₀ := mul_pos hC_pos hR₀_pos
    have h2 : C * R₀ ≤ C * R₀ * (1 / δ) := le_mul_of_one_le_right hCR₀_pos.le h_one_le_inv_δ
    have h3 : C * R₀ * (1 / δ) = C * R₀ / δ := by ring
    linarith
  have hlog2δ_le_logC : Real.log (2 / δ) ≤ Real.log (C * R₀ / δ) :=
    Real.log_le_log (div_pos zero_lt_two hδ0) h2δ_le_CR₀δ
  have hlog16_le_logC : Real.log (16 * K₀ * R₀) ≤ Real.log (C * R₀ / δ) :=
    Real.log_le_log (mul_pos (mul_pos (by norm_num) hK₀_pos) hR₀_pos) h16_le_CR₀δ
  have hlogC_pos : 0 < Real.log (C * R₀ / δ) :=
    lt_of_lt_of_le hlog2δ_pos hlog2δ_le_logC
  have hx_sq : (8 * K₀ * R₀ * Real.log (C * R₀ / δ)) ^ 2 ≤ x := by
    have hrew : (8 * K₀ * R₀ * Real.log (C * R₀ / δ)) ^ 2 =
        C * R₀ ^ 2 * (Real.log (C * R₀ / δ)) ^ 2 := by
      rw [hC_eq]
      ring
    linarith
  have h8_le_sqrtx : 8 * K₀ * R₀ * Real.log (C * R₀ / δ) ≤ Real.sqrt x := by
    have hnn : 0 ≤ 8 * K₀ * R₀ * Real.log (C * R₀ / δ) :=
      mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) hK₀_pos.le) hR₀_pos.le) hlogC_pos.le
    calc 8 * K₀ * R₀ * Real.log (C * R₀ / δ)
        = Real.sqrt ((8 * K₀ * R₀ * Real.log (C * R₀ / δ)) ^ 2) := (Real.sqrt_sq hnn).symm
      _ ≤ Real.sqrt x := Real.sqrt_le_sqrt hx_sq
  have hKR_pos : 0 < K₀ * R₀ := mul_pos hK₀_pos hR₀_pos
  have h_term1 : K₀ * R₀ * Real.log (2 * x) ≤ (1 / 2 : ℝ) * Real.sqrt x := by
    have hstep1 := log_two_mul_le_sqrt hK₀_pos hR₀_pos hx_ge1
    have h2KR_nn : 0 ≤ 2 * K₀ * R₀ := by linarith
    have hstep2 : (2 * K₀ * R₀) * Real.log (16 * K₀ * R₀) ≤
        (2 * K₀ * R₀) * Real.log (C * R₀ / δ) :=
      mul_le_mul_of_nonneg_left hlog16_le_logC h2KR_nn
    linarith
  have h_term2 : K₀ * R₀ * Real.sqrt (Real.log (2 / δ)) ≤ (1 / 2 : ℝ) * Real.sqrt x := by
    have h1 : K₀ * R₀ * Real.sqrt (Real.log (2 / δ)) ≤ K₀ * R₀ * Real.log (C * R₀ / δ) :=
      mul_le_mul_of_nonneg_left (le_trans hsqrt_log2δ_le hlog2δ_le_logC) hKR_pos.le
    linarith
  have hlog2x_pos : 0 < Real.log (2 * x) := Real.log_pos (by linarith)
  have hsqrt_nn : 0 ≤ Real.sqrt (Real.log (2 / δ)) := Real.sqrt_nonneg _
  have h_num1 : D₀ * Real.log (2 * x) + M₀ * Real.sqrt (Real.log (2 / δ)) ≤
      2 * D_bin * (Real.log (2 * x) + Real.sqrt (Real.log (2 / δ))) := by
    have hd : D₀ * Real.log (2 * x) ≤ (2 * D_bin) * Real.log (2 * x) :=
      mul_le_mul_of_nonneg_right hD₀ hlog2x_pos.le
    have hm : M₀ * Real.sqrt (Real.log (2 / δ)) ≤ (2 * D_bin) * Real.sqrt (Real.log (2 / δ)) :=
      mul_le_mul_of_nonneg_right hM₀ hsqrt_nn
    linarith
  have hD_eq : D_bin = R₀ * ε := by
    rw [hR₀_eq]
    exact (div_mul_cancel₀ D_bin hε0.ne').symm
  let Lsum : ℝ := Real.log (2 * x) + Real.sqrt (Real.log (2 / δ))
  have hLsum_pos : 0 < Lsum := add_pos_of_pos_of_nonneg hlog2x_pos hsqrt_nn
  have hsum_le : K₀ * R₀ * Lsum ≤ Real.sqrt x := by
    change K₀ * R₀ * (Real.log (2 * x) + Real.sqrt (Real.log (2 / δ))) ≤ Real.sqrt x
    linarith
  have h_num2 :
      2 * (C_2 * (D₀ * Real.log (2 * x) + M₀ * Real.sqrt (Real.log (2 / δ)))) ≤
        ε * Real.sqrt x := by
    calc 2 * (C_2 * (D₀ * Real.log (2 * x) + M₀ * Real.sqrt (Real.log (2 / δ))))
        ≤ 2 * (C_2 * (2 * D_bin * Lsum)) :=
          mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left h_num1 hC2.le) zero_le_two
      _ = (4 * C_2) * (D_bin * Lsum) := by ring
      _ ≤ K₀ * (D_bin * Lsum) :=
          mul_le_mul_of_nonneg_right h4C2_le (mul_pos hD_bin hLsum_pos).le
      _ = ε * (K₀ * R₀ * Lsum) := by
          rw [hD_eq]
          ring
      _ ≤ ε * Real.sqrt x :=
          mul_le_mul_of_nonneg_left hsum_le hε0.le
  have h_rew :
      2 * (C_2 * (D₀ * Real.log (2 * x) + M₀ * Real.sqrt (Real.log (2 / δ))) /
        Real.sqrt x) =
      (2 * (C_2 * (D₀ * Real.log (2 * x) + M₀ * Real.sqrt (Real.log (2 / δ))))) /
        Real.sqrt x := by ring
  rw [h_rew, div_le_iff₀ hsqrt_x_pos]
  exact h_num2

/-- Sample-size arithmetic: with `K₀ = max (4 * C_2) 1` and `C = 64 * K₀ ^ 2`,
the sample condition `n ≥ C * (D_bin / ε) ^ 2 * (log (C * D_bin / (ε * δ))) ^ 2`
implies `2 * bound ≤ ε`. -/
theorem two_mul_bound_le_eps
    (C_2 D_bin D₀ M₀ ε δ : ℝ) (n : ℕ)
    (hC2 : 0 < C_2) (hD_bin : 0 < D_bin)
    (hD₀ : D₀ ≤ 2 * D_bin) (hM₀ : M₀ ≤ 2 * D_bin)
    (hε0 : 0 < ε) (hεD : ε ≤ D_bin)
    (hδ0 : 0 < δ) (hδ1 : δ < (1 : ℝ) / 2)
    (hn : 1 ≤ n)
    (hn_large :
      let C : ℝ := 64 * (max (4 * C_2) 1) ^ 2
      (n : ℝ) ≥ C * (D_bin / ε) ^ 2 * (Real.log (C * D_bin / (ε * δ))) ^ 2) :
    2 * (C_2 * (D₀ * Real.log (2 * (n : ℝ)) + M₀ * Real.sqrt (Real.log (2 / δ))) /
      Real.sqrt (n : ℝ)) ≤ ε := by
  let K₀ : ℝ := max (4 * C_2) 1
  let C : ℝ := 64 * K₀ ^ 2
  let R₀ : ℝ := D_bin / ε
  have hn_ge1 : (1 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
  have h_arg : C * D_bin / (ε * δ) = C * R₀ / δ := by
    dsimp [R₀]
    ring
  have hn_large' : C * R₀ ^ 2 * (Real.log (C * R₀ / δ)) ^ 2 ≤ (n : ℝ) := by
    change (n : ℝ) ≥ C * R₀ ^ 2 * (Real.log (C * D_bin / (ε * δ))) ^ 2 at hn_large
    rwa [h_arg] at hn_large
  exact core_rate_bound hC2 (le_max_right _ _) (le_max_left _ _) rfl rfl
    hD_bin hD₀ hM₀ hε0 hεD hδ0 hδ1 hn_ge1 hn_large'

end UL.Proof_cor_C_6

import UL.Stmt.lem_A_5
import UL.Stmt.lem_A_3
import UL.Stmt.lem_A_4
import UL.Proof.lem_A_5.H1_Simplex
import UL.Proof.lem_A_5.H2_Moreau
import UL.Proof.lem_A_5.H3_FaceLimit
set_option autoImplicit false

namespace UL

open Set Filter Topology MeasureTheory
open scoped ENNReal

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_lem_A_5 (h_lem_A_3 : S_lem_A_3) (h_lem_A_4 : S_lem_A_4) : S_lem_A_5 := by
  have _ : S_lem_A_3 ∧ S_lem_A_4 := ⟨h_lem_A_3, h_lem_A_4⟩
  unfold S_lem_A_5
  intro Ω _ μ _ K hK P Y hP_meas hY_meas hP hsupp hsmooth F hF_cont hF_conv hF_diff
  dsimp only
  set prod : Ω → ℝ := fun ω =>
    inner ℝ (fitResidual P Y ω)
      (faceGrad F (open Classical in Finset.univ.filter (fun j : Fin K => 0 < P ω j)) (P ω))
  obtain ⟨oscBound, hOsc_nonneg, hOsc⟩ := Proof_lem_A_5.exists_oscillation_bound hK hF_cont
  -- Concrete sequence ε_n = 1 / (n + 2) ∈ (0, 1/2], tending to 0⁺
  let ε_seq : ℕ → ℝ := fun n => 1 / ((n : ℝ) + 2)
  have hε_pos : ∀ n : ℕ, 0 < ε_seq n := fun n => by
    dsimp [ε_seq]; positivity
  have hε_half : ∀ n : ℕ, ε_seq n ≤ 1 / 2 := fun n => by
    dsimp [ε_seq]
    have hn : (0 : ℝ) ≤ n := Nat.cast_nonneg n
    rw [div_le_div_iff₀ (by linarith) (by norm_num)]
    linarith
  have hε_lt1 : ∀ n : ℕ, ε_seq n < 1 := fun n => by linarith [hε_half n]
  have hε_tendsto : Tendsto ε_seq atTop (𝓝[>] (0 : ℝ)) := by
    refine tendsto_nhdsWithin_of_tendsto_nhds_of_eventually_within _ ?_
      (Eventually.of_forall hε_pos)
    exact tendsto_const_nhds.div_atTop
      (tendsto_natCast_atTop_atTop.atTop_add tendsto_const_nhds)
  -- Sequence of ε-trimmed inner products
  let fn : ℕ → Ω → ℝ := fun n ω =>
    inner ℝ (fitResidual P Y ω)
      (faceGrad F Finset.univ ((1 - ε_seq n) • P ω + ε_seq n • uniformVec K))
  have hfn_main : ∀ n : ℕ, (∫ ω, fn n ω ∂μ ≤ 0) ∧ Integrable (fn n) μ := fun n =>
    Proof_lem_A_5.trimmed_test_nonpos μ hK hP_meas hY_meas hP hsmooth
      hF_cont hF_conv hF_diff (hε_pos n) (hε_lt1 n)
  have hfn_int_le : ∀ n : ℕ, ∫ ω, fn n ω ∂μ ≤ 0 := fun n => (hfn_main n).1
  have hfn_int : ∀ n : ℕ, Integrable (fn n) μ := fun n => (hfn_main n).2
  have hfn_lb : ∀ (n : ℕ) (ω : Ω), -2 * oscBound ≤ fn n ω := fun n ω =>
    Proof_lem_A_5.trimmed_inner_lower_bound hK hF_conv hF_diff hOsc_nonneg hOsc
      (hP ω) (Proof_lem_A_5.oneHotLabel_mem_simplex Y ω) (hε_pos n) (hε_half n)
  -- Almost everywhere pointwise convergence fn n ω → prod ω
  have hr_ae := Proof_lem_A_5.fitResidual_mem_faceTangentSpace_ae hP hsupp
  have h_tendsto_ae : ∀ᵐ ω ∂μ, Tendsto (fun n => fn n ω) atTop (𝓝 (prod ω)) := by
    filter_upwards [hr_ae] with ω hrω
    obtain ⟨hJ_ne, hp_relint⟩ := Proof_lem_A_5.support_nonempty_and_mem_relint (hP ω)
    exact (Proof_lem_A_5.face_inner_tendsto hK hF_cont hF_conv hF_diff
      hJ_ne hp_relint hrω).comp hε_tendsto
  have h_prod_lb_ae : ∀ᵐ ω ∂μ, -2 * oscBound ≤ prod ω := by
    filter_upwards [h_tendsto_ae] with ω hω
    exact ge_of_tendsto hω (Eventually.of_forall fun n => hfn_lb n ω)
  have h_prod_meas : AEStronglyMeasurable prod μ :=
    aestronglyMeasurable_of_tendsto_ae atTop
      (fun n => (hfn_int n).aestronglyMeasurable) h_tendsto_ae
  -- Shift by + 2 * oscBound to obtain nonnegative functions for Fatou's lemma
  let gn : ℕ → Ω → ℝ := fun n ω => fn n ω + 2 * oscBound
  let g : Ω → ℝ := fun ω => prod ω + 2 * oscBound
  have hgn_nonneg : ∀ (n : ℕ) (ω : Ω), 0 ≤ gn n ω := fun n ω => by
    dsimp [gn]; linarith [hfn_lb n ω]
  have hg_nonneg_ae : 0 ≤ᵐ[μ] g := by
    filter_upwards [h_prod_lb_ae] with ω hω
    dsimp [g]; linarith
  have hgn_int : ∀ n : ℕ, Integrable (gn n) μ := fun n =>
    (hfn_int n).add (integrable_const (2 * oscBound))
  have h_lintegral_gn_le : ∀ n : ℕ,
      (∫⁻ ω, ENNReal.ofReal (gn n ω) ∂μ) ≤ ENNReal.ofReal (2 * oscBound) := by
    intro n
    rw [← ofReal_integral_eq_lintegral_ofReal (hgn_int n)
      (Eventually.of_forall (hgn_nonneg n))]
    refine ENNReal.ofReal_le_ofReal ?_
    have hint_eq : ∫ ω, gn n ω ∂μ = (∫ ω, fn n ω ∂μ) + 2 * oscBound := by
      change ∫ ω, (fn n ω + 2 * oscBound) ∂μ = (∫ ω, fn n ω ∂μ) + 2 * oscBound
      rw [integral_add (hfn_int n) (integrable_const (2 * oscBound)), integral_const]
      simp
    linarith [hfn_int_le n]
  have h_liminf_ae : (fun ω => ENNReal.ofReal (g ω)) =ᵐ[μ]
      fun ω => liminf (fun n => ENNReal.ofReal (gn n ω)) atTop := by
    filter_upwards [h_tendsto_ae] with ω hω
    have h1 : Tendsto (fun n => ENNReal.ofReal (gn n ω)) atTop (𝓝 (ENNReal.ofReal (g ω))) :=
      (ENNReal.continuous_ofReal.tendsto (g ω)).comp (hω.add_const (2 * oscBound))
    exact h1.liminf_eq.symm
  have h_lintegral_g_le :
      (∫⁻ ω, ENNReal.ofReal (g ω) ∂μ) ≤ ENNReal.ofReal (2 * oscBound) := by
    calc
      (∫⁻ ω, ENNReal.ofReal (g ω) ∂μ)
        = ∫⁻ ω, liminf (fun n => ENNReal.ofReal (gn n ω)) atTop ∂μ :=
          lintegral_congr_ae h_liminf_ae
      _ ≤ liminf (fun n => ∫⁻ ω, ENNReal.ofReal (gn n ω) ∂μ) atTop :=
          lintegral_liminf_le' (fun n => (hgn_int n).aemeasurable.ennreal_ofReal)
      _ ≤ ENNReal.ofReal (2 * oscBound) :=
          liminf_le_of_frequently_le' (Eventually.of_forall h_lintegral_gn_le).frequently
  -- Deduce Integrable g μ, hence Integrable prod μ and ∫ prod ∂μ ≤ 0
  have hg_meas : AEStronglyMeasurable g μ :=
    h_prod_meas.add aestronglyMeasurable_const
  have hg_fin : HasFiniteIntegral g μ := by
    rw [hasFiniteIntegral_iff_ofReal hg_nonneg_ae]
    exact lt_of_le_of_lt h_lintegral_g_le ENNReal.ofReal_lt_top
  have hg_int : Integrable g μ := ⟨hg_meas, hg_fin⟩
  have hprod_int : Integrable prod μ := by
    have heq : prod = fun ω => g ω - 2 * oscBound := by ext ω; dsimp [g]; ring
    rw [heq]
    exact hg_int.sub (integrable_const (2 * oscBound))
  have hint_g_le : ∫ ω, g ω ∂μ ≤ 2 * oscBound := by
    have hofReal : ENNReal.ofReal (∫ ω, g ω ∂μ) ≤ ENNReal.ofReal (2 * oscBound) := by
      rw [ofReal_integral_eq_lintegral_ofReal hg_int hg_nonneg_ae]
      exact h_lintegral_g_le
    exact (ENNReal.ofReal_le_ofReal_iff (by positivity : 0 ≤ 2 * oscBound)).mp hofReal
  have hint_g_eq : ∫ ω, g ω ∂μ = (∫ ω, prod ω ∂μ) + 2 * oscBound := by
    change ∫ ω, (prod ω + 2 * oscBound) ∂μ = (∫ ω, prod ω ∂μ) + 2 * oscBound
    rw [integral_add hprod_int (integrable_const (2 * oscBound)), integral_const]
    simp
  exact ⟨by linarith, hprod_int⟩

end UL

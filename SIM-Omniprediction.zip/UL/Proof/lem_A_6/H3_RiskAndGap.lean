import Mathlib
import UL.Stmt.lem_A_6
import UL.Proof.lem_A_6.H1_FitAndTransfer
import UL.Proof.lem_A_6.H2_DanskinStrongConv

set_option autoImplicit false

namespace UL.Proof_lem_A_6

open MeasureTheory

universe u

private lemma nonempty_of_prob {Ω : Type u} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ] : Nonempty Ω := by
  by_contra h
  rw [not_nonempty_iff] at h
  have huniv : (Set.univ : Set Ω) = ∅ := Set.eq_empty_of_isEmpty Set.univ
  have h1 : μ Set.univ = 1 := measure_univ
  rw [huniv, measure_empty] at h1
  exact zero_ne_one h1

private lemma integrable_of_aestronglyMeasurable_bounded {Ω E : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] [NormedAddCommGroup E]
    {g : Ω → E} (hg_meas : AEStronglyMeasurable g μ) (C : ℝ) (hg_bound : ∀ ω, ‖g ω‖ ≤ C) :
    Integrable g μ :=
  (memLp_top_of_bound hg_meas C (Filter.Eventually.of_forall hg_bound)).integrable le_top

private lemma norm_sub_le_two_of_simplex {K : ℕ} {p q : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ Simplex K) (hq : q ∈ Simplex K) : ‖p - q‖ ≤ 2 := by
  calc ‖p - q‖
      ≤ ‖p‖ + ‖q‖ := norm_sub_le p q
    _ ≤ 1 + 1 := add_le_add (norm_le_one_of_mem_simplex hp) (norm_le_one_of_mem_simplex hq)
    _ = 2 := by norm_num

private lemma inner_oneHotVec_left {K : ℕ} (y : Fin K) (a : EuclideanSpace ℝ (Fin K)) :
    inner ℝ (oneHotVec y) a = a y := by
  rw [PiLp.inner_apply]
  simp [oneHotVec, EuclideanSpace.single_apply]

private lemma extendSimplex_integrable {Ω : Type u} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ]
    {K : ℕ} {Φ : Simplex K → ℝ} (hΦ_cont : Continuous Φ)
    {P : Ω → EuclideanSpace ℝ (Fin K)} (hP_meas : Measurable P)
    (hP_simp : ∀ ω, P ω ∈ Simplex K) :
    Integrable (fun ω => extendSimplex Φ (P ω)) μ := by
  have h_eq : (fun ω => extendSimplex Φ (P ω)) = fun ω => Φ ⟨P ω, hP_simp ω⟩ := by
    ext ω
    simp [extendSimplex, hP_simp ω]
  rw [h_eq]
  have h_meas : Measurable (fun ω => Φ ⟨P ω, hP_simp ω⟩) :=
    hΦ_cont.measurable.comp hP_meas.subtype_mk
  have hcontOn : ContinuousOn (extendSimplex Φ) (Simplex K) := by
    rw [continuousOn_iff_continuous_restrict]
    convert hΦ_cont using 1
    ext ⟨q, hq⟩
    simp [extendSimplex, hq]
  obtain ⟨C, hC⟩ := (simplex_isCompact K).exists_bound_of_continuousOn hcontOn
  refine integrable_of_aestronglyMeasurable_bounded h_meas.aestronglyMeasurable C (fun ω => ?_)
  have h := hC (P ω) (hP_simp ω)
  simpa [extendSimplex, hP_simp ω] using h

private lemma integrable_inner_score {Ω : Type u} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ]
    {d K : ℕ} {G : Ω → EuclideanSpace ℝ (Fin K)}
    (hG_meas : Measurable G) {C : ℝ} (hC : 0 ≤ C) (hG_bound : ∀ ω, ‖G ω‖ ≤ C)
    {X : Ω → EuclideanSpace ℝ (Fin d)} (hX_meas : Measurable X)
    (hX_int : Integrable (fun ω => ‖X ω‖) μ)
    (U : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K) :
    Integrable (fun ω => inner ℝ (G ω) (U (X ω) : EuclideanSpace ℝ (Fin K))) μ := by
  have hUX_meas : Measurable (fun ω => (U (X ω) : EuclideanSpace ℝ (Fin K))) :=
    continuous_subtype_val.measurable.comp (U.continuous.measurable.comp hX_meas)
  have h_meas : Measurable (fun ω => inner ℝ (G ω) (U (X ω) : EuclideanSpace ℝ (Fin K))) :=
    hG_meas.inner hUX_meas
  refine (hX_int.const_mul (C * ‖U‖)).mono' h_meas.aestronglyMeasurable ?_
  refine Filter.Eventually.of_forall (fun ω => ?_)
  calc ‖inner ℝ (G ω) (U (X ω) : EuclideanSpace ℝ (Fin K))‖
      = |inner ℝ (G ω) (U (X ω) : EuclideanSpace ℝ (Fin K))| := Real.norm_eq_abs _
    _ ≤ ‖G ω‖ * ‖(U (X ω) : EuclideanSpace ℝ (Fin K))‖ := abs_real_inner_le_norm _ _
    _ = ‖G ω‖ * ‖U (X ω)‖ := by rfl
    _ ≤ C * (‖U‖ * ‖X ω‖) :=
        mul_le_mul (hG_bound ω) (U.le_opNorm (X ω)) (norm_nonneg _) hC
    _ = (C * ‖U‖) * ‖X ω‖ := by ring

lemma case_K_eq_one
    (Ω : Type u) [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    (d : ℕ) (β B : ℝ) (hβ : 0 < β) (hB : β ≤ B)
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin 1)
    (hX : Measurable X) (hY : Measurable Y)
    (𝒲 : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace 1))
    (h𝒲 : IsCompactConvexScoreSet 𝒲)
    (W V : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace 1)
    (Φ : Simplex 1 → ℝ) :
    let P_W : Ω → EuclideanSpace ℝ (Fin 1) := linearFittedPrediction μ B W X Y
    let qΦ : ZeroSumSubspace 1 → EuclideanSpace ℝ (Fin 1) :=
      fun a => uniformVec 1 +
        ((gradient (fun s : ZeroSumSubspace 1 => matchingPotential Φ s) a :
          ZeroSumSubspace 1) : EuclideanSpace ℝ (Fin 1))
    (∀ᵐ ω ∂μ, extendedCanonicalLoss Φ (P_W ω) (Y ω) ≠ ⊤) ∧
    Integrable (fun ω => (extendedCanonicalLoss Φ (P_W ω) (Y ω)).toReal) μ ∧
    Integrable (fun ω => matchingLoss Φ (V (X ω)) (Y ω)) μ ∧
    (∫ ω, (extendedCanonicalLoss Φ (P_W ω) (Y ω)).toReal ∂μ) -
        (∫ ω, matchingLoss Φ (V (X ω)) (Y ω) ∂μ) ≤
      certificateGap μ B 𝒲 X Y W -
        ∫ ω, (extendSimplex Φ (P_W ω) + matchingPotential Φ (V (X ω)) -
          inner ℝ (P_W ω - uniformVec 1) (V (X ω) : EuclideanSpace ℝ (Fin 1))) ∂μ ∧
    certificateGap μ B 𝒲 X Y W -
        ∫ ω, (extendSimplex Φ (P_W ω) + matchingPotential Φ (V (X ω)) -
          inner ℝ (P_W ω - uniformVec 1) (V (X ω) : EuclideanSpace ℝ (Fin 1))) ∂μ ≤
      certificateGap μ B 𝒲 X Y W -
        (1 / (2 * β)) * ∫ ω, ‖P_W ω - qΦ (V (X ω))‖ ^ 2 ∂μ := by
  dsimp only
  set P_W : Ω → EuclideanSpace ℝ (Fin 1) := linearFittedPrediction μ B W X Y
  have hB_pos : 0 < B := lt_of_lt_of_le hβ hB
  obtain ⟨ρ, hProf, hPW_eq⟩ := linearFittedPrediction_spec μ (le_rfl : 1 ≤ 1) hB_pos W hX hY
  have hPW_u : ∀ ω : Ω, P_W ω = uniformVec 1 := by
    intro ω
    have hmem : P_W ω ∈ Simplex 1 := by
      rw [show P_W ω = ρ (W (X ω)) from congr_fun hPW_eq ω]
      exact hProf.2.1.2.2 (W (X ω))
    exact eq_uniformVec_of_mem_simplex_one hmem
  have hZ_u : ∀ ω : Ω, oneHotLabel Y ω = uniformVec 1 :=
    fun ω => eq_uniformVec_of_mem_simplex_one (oneHotLabel_mem_simplex Y ω)
  have hu_mem : uniformVec 1 ∈ Simplex 1 := uniformVec_mem_simplex le_rfl
  let u1 : Simplex 1 := ⟨uniformVec 1, hu_mem⟩
  have h_ecl_eq : ∀ ω : Ω,
      extendedCanonicalLoss Φ (P_W ω) (Y ω) = ((-extendSimplex Φ (uniformVec 1) : ℝ) : EReal) := by
    intro ω
    rw [hPW_u ω]
    have hy0 : Y ω = 0 := Subsingleton.elim _ _
    have hy_pos : Y ω ∈ posSupport (uniformVec 1) := by
      simp [posSupport, hy0, uniformVec, onesVec]
    unfold extendedCanonicalLoss
    rw [if_pos hy_pos]
    have hsingle : EuclideanSpace.single (Y ω) (1 : ℝ) = uniformVec 1 :=
      eq_uniformVec_of_mem_simplex_one (oneHotVec_mem_simplex (Y ω))
    rw [hsingle, sub_self, inner_zero_right, add_zero]
  have h_mp_eq : ∀ s : ZeroSumSubspace 1,
      matchingPotential Φ s = -extendSimplex Φ (uniformVec 1) := by
    intro s
    have hs0 : (s : EuclideanSpace ℝ (Fin 1)) = 0 := zeroSumSubspace_one_coe_eq_zero s
    rw [hs0]
    unfold matchingPotential
    haveI : Nonempty (Simplex 1) := ⟨u1⟩
    have hq_const : ∀ q : Simplex 1,
        inner ℝ ((q : EuclideanSpace ℝ (Fin 1)) - uniformVec 1) 0 - Φ q =
          -extendSimplex Φ (uniformVec 1) := by
      intro q
      have hq1 : (q : EuclideanSpace ℝ (Fin 1)) = uniformVec 1 :=
        eq_uniformVec_of_mem_simplex_one q.2
      have hq_eq : q = u1 := Subtype.ext hq1
      rw [inner_zero_right, zero_sub, hq_eq]
      simp [extendSimplex, u1, hu_mem]
    simp_rw [hq_const]
    exact ciSup_const
  have h_ml_eq : ∀ ω : Ω,
      matchingLoss Φ (V (X ω)) (Y ω) = -extendSimplex Φ (uniformVec 1) := by
    intro ω
    unfold matchingLoss
    rw [h_mp_eq (V (X ω)), zeroSumSubspace_one_coe_eq_zero (V (X ω))]
    simp
  have h_gap_zero : certificateGap μ B 𝒲 X Y W = 0 := by
    unfold certificateGap predictionCertificateGap
    have h_fn_zero : ∀ V' : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace 1,
        (∫ ω, inner ℝ (linearFittedPrediction μ B W X Y ω - oneHotLabel Y ω)
          ((W - V') (X ω) : EuclideanSpace ℝ (Fin 1)) ∂μ) = 0 := by
      intro V'
      have h0 : ∀ ω : Ω, inner ℝ (linearFittedPrediction μ B W X Y ω - oneHotLabel Y ω)
          ((W - V') (X ω) : EuclideanSpace ℝ (Fin 1)) = 0 := by
        intro ω
        change inner ℝ (P_W ω - oneHotLabel Y ω) ((W - V') (X ω) : EuclideanSpace ℝ (Fin 1)) = 0
        rw [hPW_u ω, hZ_u ω, sub_self, inner_zero_left]
      simp_rw [h0]
      simp
    have himg : ((fun V' => ∫ ω, inner ℝ (linearFittedPrediction μ B W X Y ω - oneHotLabel Y ω)
        ((W - V') (X ω) : EuclideanSpace ℝ (Fin 1)) ∂μ) '' 𝒲) = {(0 : ℝ)} := by
      calc ((fun V' => ∫ ω, inner ℝ (linearFittedPrediction μ B W X Y ω - oneHotLabel Y ω)
              ((W - V') (X ω) : EuclideanSpace ℝ (Fin 1)) ∂μ) '' 𝒲)
          = ((fun _ => (0 : ℝ)) '' 𝒲) := by
              refine Set.image_congr (fun V' _ => h_fn_zero V')
        _ = {(0 : ℝ)} := h𝒲.1.image_const 0
    rw [himg, csSup_singleton]
  have h_D_zero : ∀ ω : Ω,
      extendSimplex Φ (P_W ω) + matchingPotential Φ (V (X ω)) -
        inner ℝ (P_W ω - uniformVec 1) (V (X ω) : EuclideanSpace ℝ (Fin 1)) = 0 := by
    intro ω
    rw [hPW_u ω, h_mp_eq (V (X ω)), sub_self, inner_zero_left]
    ring
  have h_sq_zero : ∀ ω : Ω,
      ‖P_W ω - (uniformVec 1 +
        ((gradient (fun s : ZeroSumSubspace 1 => matchingPotential Φ s) (V (X ω)) :
          ZeroSumSubspace 1) : EuclideanSpace ℝ (Fin 1)))‖ ^ 2 = 0 := by
    intro ω
    rw [hPW_u ω, zeroSumSubspace_one_coe_eq_zero]
    simp
  refine ⟨?_, ?_, ?_, ?_, ?_⟩
  · exact Filter.Eventually.of_forall (fun ω => by rw [h_ecl_eq ω]; exact EReal.coe_ne_top _)
  · simp_rw [h_ecl_eq, EReal.toReal_coe]
    exact integrable_const _
  · simp_rw [h_ml_eq]
    exact integrable_const _
  · simp_rw [h_ecl_eq, EReal.toReal_coe, h_ml_eq, h_D_zero, h_gap_zero]
    simp
  · simp_rw [h_D_zero, h_sq_zero, h_gap_zero]
    simp

lemma forecast_loss_ae_and_bound
    {Ω : Type u} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    {K : ℕ} {β B : ℝ} {Φ : Simplex K → ℝ} (hΦ : Φ ∈ EntropyFamily K β) (hB : 0 < B)
    {P : Ω → EuclideanSpace ℝ (Fin K)} {Y : Ω → Fin K}
    (hP_meas : Measurable P) (hY_meas : Measurable Y)
    (hP_simp : ∀ ω, P ω ∈ Simplex K)
    (hsupp : ∀ j : Fin K, ∀ᵐ ω ∂μ, P ω j = 0 → oneHotLabel Y ω j = 0)
    (hprod_le : ∫ ω, inner ℝ (fitResidual P Y ω)
      (faceGrad (shiftedEntropy Φ B) (posSupport (P ω)) (P ω)) ∂μ ≤ 0)
    (hprod_int : Integrable (fun ω => inner ℝ (fitResidual P Y ω)
      (faceGrad (shiftedEntropy Φ B) (posSupport (P ω)) (P ω))) μ) :
    (∀ᵐ ω ∂μ, extendedCanonicalLoss Φ (P ω) (Y ω) ≠ ⊤) ∧
    Integrable (fun ω => (extendedCanonicalLoss Φ (P ω) (Y ω)).toReal) μ ∧
    (∫ ω, (extendedCanonicalLoss Φ (P ω) (Y ω)).toReal ∂μ ≤
      -(∫ ω, extendSimplex Φ (P ω) ∂μ) +
        (1 / B) * ∫ ω, inner ℝ (fitResidual P Y ω) (P ω - uniformVec K) ∂μ) := by
  have ⟨ω₀⟩ := nonempty_of_prob μ
  have hK1 : 1 ≤ K := Nat.succ_le_of_lt (Fin.pos (Y ω₀))
  have hall : ∀ᵐ ω ∂μ, ∀ j : Fin K, P ω j = 0 → oneHotLabel Y ω j = 0 :=
    ae_all_iff.mpr hsupp
  have h_pos_of_supp : ∀ ω : Ω, (∀ j : Fin K, P ω j = 0 → oneHotLabel Y ω j = 0) →
      Y ω ∈ posSupport (P ω) := by
    intro ω hω
    simp only [posSupport, Finset.mem_filter, Finset.mem_univ, true_and]
    by_contra hnotpos
    have hp0 : P ω (Y ω) = 0 := le_antisymm (not_lt.mp hnotpos) ((hP_simp ω).1 (Y ω))
    have hz0 : oneHotLabel Y ω (Y ω) = 0 := hω (Y ω) hp0
    have hz1 : oneHotLabel Y ω (Y ω) = 1 := by
      simp [oneHotLabel, oneHotVec, EuclideanSpace.single_apply]
    linarith
  have h_ae_fin : ∀ᵐ ω ∂μ, extendedCanonicalLoss Φ (P ω) (Y ω) ≠ ⊤ := by
    filter_upwards [hall] with ω hω
    unfold extendedCanonicalLoss
    rw [if_pos (h_pos_of_supp ω hω)]
    exact EReal.coe_ne_top _
  let prod : Ω → ℝ := fun ω =>
    inner ℝ (fitResidual P Y ω) (faceGrad (shiftedEntropy Φ B) (posSupport (P ω)) (P ω))
  let ownTerm : Ω → ℝ := fun ω => inner ℝ (fitResidual P Y ω) (P ω - uniformVec K)
  let rhsFn : Ω → ℝ := fun ω => -extendSimplex Φ (P ω) + (1 / B) * ownTerm ω + prod ω
  have h_ae_eq : (fun ω => (extendedCanonicalLoss Φ (P ω) (Y ω)).toReal) =ᵐ[μ] rhsFn := by
    filter_upwards [hall] with ω hω
    have hy : Y ω ∈ posSupport (P ω) := h_pos_of_supp ω hω
    have hr_mem : fitResidual P Y ω ∈ FaceTangentSpace K (posSupport (P ω)) := by
      simp only [FaceTangentSpace, Submodule.mem_inf, Submodule.mem_iInf]
      refine ⟨sub_mem_zeroSumSubspace_of_mem_simplex (hP_simp ω) (oneHotLabel_mem_simplex Y ω), ?_⟩
      intro j hj
      have hnotpos : ¬ (0 < P ω j) := fun hp =>
        hj (Finset.mem_filter.mpr ⟨Finset.mem_univ j, hp⟩)
      have hp0 : P ω j = 0 := le_antisymm (not_lt.mp hnotpos) ((hP_simp ω).1 j)
      have hz0 : oneHotLabel Y ω j = 0 := hω j hp0
      simp [fitResidual, hp0, hz0]
    have hdecomp := faceGrad_phi_decomp hΦ hB (hP_simp ω) hr_mem
    unfold extendedCanonicalLoss
    rw [if_pos hy, EReal.toReal_coe]
    have hres_eq : P ω - EuclideanSpace.single (Y ω) (1 : ℝ) = fitResidual P Y ω := rfl
    rw [hres_eq, real_inner_comm, hdecomp]
    dsimp [rhsFn, ownTerm, prod]
    ring
  have h_phi_int : Integrable (fun ω => extendSimplex Φ (P ω)) μ :=
    extendSimplex_integrable μ hΦ.2.1 hP_meas hP_simp
  have h_own_int : Integrable ownTerm μ := by
    have hr_meas : Measurable (fitResidual P Y) := hP_meas.sub (oneHotLabel_measurable hY_meas)
    have hpu_meas : Measurable (fun ω => P ω - uniformVec K) := hP_meas.sub measurable_const
    refine integrable_of_aestronglyMeasurable_bounded
      (hr_meas.inner hpu_meas).aestronglyMeasurable 4 (fun ω => ?_)
    rw [Real.norm_eq_abs]
    have hr_le : ‖fitResidual P Y ω‖ ≤ 2 :=
      norm_sub_le_two_of_simplex (hP_simp ω) (oneHotLabel_mem_simplex Y ω)
    have hpu_le : ‖P ω - uniformVec K‖ ≤ 2 :=
      norm_sub_le_two_of_simplex (hP_simp ω) (uniformVec_mem_simplex hK1)
    calc |inner ℝ (fitResidual P Y ω) (P ω - uniformVec K)|
        ≤ ‖fitResidual P Y ω‖ * ‖P ω - uniformVec K‖ := abs_real_inner_le_norm _ _
      _ ≤ 2 * 2 := mul_le_mul hr_le hpu_le (norm_nonneg _) (by norm_num)
      _ = 4 := by norm_num
  have h_neg_phi_int : Integrable (fun ω => -extendSimplex Φ (P ω)) μ := by
    simpa only [Pi.neg_apply] using h_phi_int.neg
  have h_scaled_own_int : Integrable (fun ω => (1 / B) * ownTerm ω) μ :=
    h_own_int.const_mul (1 / B)
  have h_sum1_int : Integrable (fun ω => -extendSimplex Φ (P ω) + (1 / B) * ownTerm ω) μ := by
    simpa only [Pi.add_apply] using h_neg_phi_int.add h_scaled_own_int
  have hprod_int' : Integrable prod μ := hprod_int
  have h_rhs_int : Integrable rhsFn μ := by
    simpa only [Pi.add_apply] using h_sum1_int.add hprod_int'
  have h_fore_int : Integrable (fun ω => (extendedCanonicalLoss Φ (P ω) (Y ω)).toReal) μ :=
    h_rhs_int.congr h_ae_eq.symm
  have h_int_eq : ∫ ω, (extendedCanonicalLoss Φ (P ω) (Y ω)).toReal ∂μ =
      -(∫ ω, extendSimplex Φ (P ω) ∂μ) + (1 / B) * (∫ ω, ownTerm ω ∂μ) + ∫ ω, prod ω ∂μ := by
    rw [integral_congr_ae h_ae_eq]
    change ∫ ω, ((-extendSimplex Φ (P ω) + (1 / B) * ownTerm ω) + prod ω) ∂μ = _
    rw [integral_add h_sum1_int hprod_int', integral_add h_neg_phi_int h_scaled_own_int,
      integral_neg, integral_const_mul]
  refine ⟨h_ae_fin, h_fore_int, ?_⟩
  linarith [h_int_eq, hprod_le]

lemma comparator_loss_integrable_and_decomp
    {Ω : Type u} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    {d K : ℕ} (hK : 1 ≤ K) {β : ℝ} {Φ : Simplex K → ℝ} (hΦ : Φ ∈ EntropyFamily K β)
    {P : Ω → EuclideanSpace ℝ (Fin K)} {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin K}
    (hP_meas : Measurable P) (hX_meas : Measurable X) (hY_meas : Measurable Y)
    (hX_int : Integrable (fun ω => ‖X ω‖) μ)
    (hP_simp : ∀ ω, P ω ∈ Simplex K)
    (V : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K) :
    Integrable (fun ω => matchingLoss Φ (V (X ω)) (Y ω)) μ ∧
    Integrable (fun ω => extendSimplex Φ (P ω) + matchingPotential Φ (V (X ω)) -
      inner ℝ (P ω - uniformVec K) (V (X ω) : EuclideanSpace ℝ (Fin K))) μ ∧
    Integrable (fun ω => inner ℝ (fitResidual P Y ω)
      (V (X ω) : EuclideanSpace ℝ (Fin K))) μ ∧
    (∫ ω, matchingLoss Φ (V (X ω)) (Y ω) ∂μ =
      -(∫ ω, extendSimplex Φ (P ω) ∂μ) +
        (∫ ω, (extendSimplex Φ (P ω) + matchingPotential Φ (V (X ω)) -
          inner ℝ (P ω - uniformVec K) (V (X ω) : EuclideanSpace ℝ (Fin K))) ∂μ) +
        ∫ ω, inner ℝ (fitResidual P Y ω) (V (X ω) : EuclideanSpace ℝ (Fin K)) ∂μ) := by
  have hVX_meas : Measurable (fun ω => (V (X ω) : EuclideanSpace ℝ (Fin K))) :=
    continuous_subtype_val.measurable.comp (V.continuous.measurable.comp hX_meas)
  have h_mp_meas : Measurable (fun ω => matchingPotential Φ (V (X ω))) :=
    (matchingPotential_continuous hK hΦ.2.1).measurable.comp hVX_meas
  have h_mp_int : Integrable (fun ω => matchingPotential Φ (V (X ω))) μ := by
    have h_dom : Integrable (fun ω => |matchingPotential Φ 0| + (2 * ‖V‖) * ‖X ω‖) μ :=
      (integrable_const _).add (hX_int.const_mul (2 * ‖V‖))
    refine h_dom.mono' h_mp_meas.aestronglyMeasurable (Filter.Eventually.of_forall (fun ω => ?_))
    rw [Real.norm_eq_abs]
    have hlip := matchingPotential_lipschitz_bound hK hΦ.2.1 (V (X ω)) 0
    rw [sub_zero] at hlip
    have htri : |matchingPotential Φ (V (X ω))| ≤
        |matchingPotential Φ 0| + |matchingPotential Φ (V (X ω)) - matchingPotential Φ 0| := by
      have hn := norm_add_le (matchingPotential Φ 0)
        (matchingPotential Φ (V (X ω)) - matchingPotential Φ 0)
      have hEq : matchingPotential Φ 0 +
          (matchingPotential Φ (V (X ω)) - matchingPotential Φ 0) =
          matchingPotential Φ (V (X ω)) := by ring
      rw [hEq] at hn
      simpa only [Real.norm_eq_abs] using hn
    have hV_le : 2 * ‖(V (X ω) : EuclideanSpace ℝ (Fin K))‖ ≤ (2 * ‖V‖) * ‖X ω‖ := by
      have h := V.le_opNorm (X ω)
      change ‖(V (X ω) : EuclideanSpace ℝ (Fin K))‖ ≤ ‖V‖ * ‖X ω‖ at h
      linarith
    linarith
  have h_ZVX_int : Integrable (fun ω =>
      inner ℝ (oneHotLabel Y ω) (V (X ω) : EuclideanSpace ℝ (Fin K))) μ :=
    integrable_inner_score μ (oneHotLabel_measurable hY_meas) (by norm_num : (0 : ℝ) ≤ 1)
      (fun ω => norm_le_one_of_mem_simplex (oneHotLabel_mem_simplex Y ω)) hX_meas hX_int V
  have h_eval_eq : (fun ω => ((V (X ω) : EuclideanSpace ℝ (Fin K)) (Y ω))) =
      fun ω => inner ℝ (oneHotLabel Y ω) (V (X ω) : EuclideanSpace ℝ (Fin K)) := by
    ext ω
    exact (inner_oneHotVec_left (Y ω) (V (X ω))).symm
  have h_ml_int : Integrable (fun ω => matchingLoss Φ (V (X ω)) (Y ω)) μ := by
    have h_eq : (fun ω => matchingLoss Φ (V (X ω)) (Y ω)) =
        fun ω => matchingPotential Φ (V (X ω)) -
          inner ℝ (oneHotLabel Y ω) (V (X ω) : EuclideanSpace ℝ (Fin K)) := by
      ext ω
      unfold matchingLoss
      rw [← inner_oneHotVec_left (Y ω) (V (X ω))]
      rfl
    rw [h_eq]
    exact h_mp_int.sub h_ZVX_int
  have h_phi_int : Integrable (fun ω => extendSimplex Φ (P ω)) μ :=
    extendSimplex_integrable μ hΦ.2.1 hP_meas hP_simp
  have h_puVX_int : Integrable (fun ω =>
      inner ℝ (P ω - uniformVec K) (V (X ω) : EuclideanSpace ℝ (Fin K))) μ :=
    integrable_inner_score μ (hP_meas.sub measurable_const) (by norm_num : (0 : ℝ) ≤ 2)
      (fun ω => norm_sub_le_two_of_simplex (hP_simp ω) (uniformVec_mem_simplex hK))
      hX_meas hX_int V
  have h_D_int : Integrable (fun ω => extendSimplex Φ (P ω) + matchingPotential Φ (V (X ω)) -
      inner ℝ (P ω - uniformVec K) (V (X ω) : EuclideanSpace ℝ (Fin K))) μ :=
    (h_phi_int.add h_mp_int).sub h_puVX_int
  have h_rVX_int : Integrable (fun ω =>
      inner ℝ (fitResidual P Y ω) (V (X ω) : EuclideanSpace ℝ (Fin K))) μ :=
    integrable_inner_score μ (hP_meas.sub (oneHotLabel_measurable hY_meas))
      (by norm_num : (0 : ℝ) ≤ 2)
      (fun ω => norm_sub_le_two_of_simplex (hP_simp ω) (oneHotLabel_mem_simplex Y ω))
      hX_meas hX_int V
  have h_ptwise : ∀ ω : Ω,
      matchingLoss Φ (V (X ω)) (Y ω) =
        -extendSimplex Φ (P ω) +
          (extendSimplex Φ (P ω) + matchingPotential Φ (V (X ω)) -
            inner ℝ (P ω - uniformVec K) (V (X ω) : EuclideanSpace ℝ (Fin K))) +
          inner ℝ (fitResidual P Y ω) (V (X ω) : EuclideanSpace ℝ (Fin K)) := by
    intro ω
    unfold matchingLoss
    rw [← inner_oneHotVec_left (Y ω) (V (X ω))]
    change matchingPotential Φ (V (X ω)) -
        inner ℝ (oneHotLabel Y ω) (V (X ω) : EuclideanSpace ℝ (Fin K)) = _
    have hu0 : inner ℝ (uniformVec K) (V (X ω) : EuclideanSpace ℝ (Fin K)) = 0 :=
      inner_uniformVec_zero_of_mem_zeroSumSubspace (V (X ω)).2
    have hinner : inner ℝ (P ω - uniformVec K) (V (X ω) : EuclideanSpace ℝ (Fin K)) -
        inner ℝ (fitResidual P Y ω) (V (X ω) : EuclideanSpace ℝ (Fin K)) =
        inner ℝ (oneHotLabel Y ω) (V (X ω) : EuclideanSpace ℝ (Fin K)) := by
      rw [← inner_sub_left]
      have hvec : (P ω - uniformVec K) - fitResidual P Y ω = oneHotLabel Y ω - uniformVec K := by
        dsimp [fitResidual]
        abel
      rw [hvec, inner_sub_left, hu0, sub_zero]
    linarith
  refine ⟨h_ml_int, h_D_int, h_rVX_int, ?_⟩
  have h_neg_phi_int : Integrable (fun ω => -extendSimplex Φ (P ω)) μ := by
    simpa only [Pi.neg_apply] using h_phi_int.neg
  have h_sum1_int : Integrable (fun ω => -extendSimplex Φ (P ω) +
      (extendSimplex Φ (P ω) + matchingPotential Φ (V (X ω)) -
        inner ℝ (P ω - uniformVec K) (V (X ω) : EuclideanSpace ℝ (Fin K)))) μ := by
    simpa only [Pi.add_apply] using h_neg_phi_int.add h_D_int
  have h_fn_eq : (fun ω => matchingLoss Φ (V (X ω)) (Y ω)) =
      fun ω => (-extendSimplex Φ (P ω) +
        (extendSimplex Φ (P ω) + matchingPotential Φ (V (X ω)) -
          inner ℝ (P ω - uniformVec K) (V (X ω) : EuclideanSpace ℝ (Fin K)))) +
        inner ℝ (fitResidual P Y ω) (V (X ω) : EuclideanSpace ℝ (Fin K)) := by
    ext ω
    exact h_ptwise ω
  rw [h_fn_eq, integral_add h_sum1_int h_rVX_int,
    integral_add h_neg_phi_int h_D_int, integral_neg]

lemma predictionCertificateGap_ge
    {Ω : Type u} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    {d K : ℕ}
    {𝒲 : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)}
    (h𝒲 : IsCompactConvexScoreSet 𝒲)
    {W V : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K} (hV : V ∈ 𝒲)
    {P : Ω → EuclideanSpace ℝ (Fin K)} {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin K}
    (hP_meas : Measurable P) (hX_meas : Measurable X) (hY_meas : Measurable Y)
    (hX_int : Integrable (fun ω => ‖X ω‖) μ)
    (hP_simp : ∀ ω, P ω ∈ Simplex K) :
    (∫ ω, inner ℝ (fitResidual P Y ω) (W (X ω) : EuclideanSpace ℝ (Fin K)) ∂μ) -
      (∫ ω, inner ℝ (fitResidual P Y ω) (V (X ω) : EuclideanSpace ℝ (Fin K)) ∂μ) ≤
      predictionCertificateGap μ 𝒲 X Y W P := by
  have hr_meas : Measurable (fitResidual P Y) := hP_meas.sub (oneHotLabel_measurable hY_meas)
  have hr_bound : ∀ ω, ‖fitResidual P Y ω‖ ≤ 2 :=
    fun ω => norm_sub_le_two_of_simplex (hP_simp ω) (oneHotLabel_mem_simplex Y ω)
  have hInt_U : ∀ U : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K,
      Integrable (fun ω => inner ℝ (fitResidual P Y ω) (U (X ω) : EuclideanSpace ℝ (Fin K))) μ :=
    fun U => integrable_inner_score μ hr_meas (by norm_num : (0 : ℝ) ≤ 2) hr_bound hX_meas hX_int U
  have h_sub_eq :
      (∫ ω, inner ℝ (fitResidual P Y ω) (W (X ω) : EuclideanSpace ℝ (Fin K)) ∂μ) -
        (∫ ω, inner ℝ (fitResidual P Y ω) (V (X ω) : EuclideanSpace ℝ (Fin K)) ∂μ) =
      ∫ ω, inner ℝ (P ω - oneHotLabel Y ω) ((W - V) (X ω) : EuclideanSpace ℝ (Fin K)) ∂μ := by
    rw [← integral_sub (hInt_U W) (hInt_U V)]
    refine integral_congr_ae (Filter.Eventually.of_forall (fun ω => ?_))
    dsimp [fitResidual]
    rw [← inner_sub_right]
  rw [h_sub_eq]
  unfold predictionCertificateGap
  obtain ⟨M, hM⟩ := isBounded_iff_forall_norm_le.mp h𝒲.2.1.isBounded
  let C : ℝ := max M 0
  have hC_nn : 0 ≤ C := le_max_right M 0
  have h_bdd : BddAbove ((fun V' => ∫ ω,
      inner ℝ (P ω - oneHotLabel Y ω) ((W - V') (X ω) : EuclideanSpace ℝ (Fin K)) ∂μ) '' 𝒲) := by
    refine ⟨(2 * (‖W‖ + C)) * ∫ ω, ‖X ω‖ ∂μ, ?_⟩
    rintro _ ⟨V', hV', rfl⟩
    have hWV'_norm : ‖W - V'‖ ≤ ‖W‖ + C := by
      calc ‖W - V'‖
          ≤ ‖W‖ + ‖V'‖ := norm_sub_le W V'
        _ ≤ ‖W‖ + C := add_le_add le_rfl (le_trans (hM V' hV') (le_max_left M 0))
    have h_int_lhs : Integrable (fun ω =>
        inner ℝ (P ω - oneHotLabel Y ω) ((W - V') (X ω) : EuclideanSpace ℝ (Fin K))) μ :=
      hInt_U (W - V')
    have h_int_rhs : Integrable (fun ω => (2 * (‖W‖ + C)) * ‖X ω‖) μ :=
      hX_int.const_mul (2 * (‖W‖ + C))
    calc (∫ ω, inner ℝ (P ω - oneHotLabel Y ω) ((W - V') (X ω) : EuclideanSpace ℝ (Fin K)) ∂μ)
        ≤ ∫ ω, (2 * (‖W‖ + C)) * ‖X ω‖ ∂μ := by
          refine integral_mono h_int_lhs h_int_rhs (fun ω => ?_)
          calc inner ℝ (P ω - oneHotLabel Y ω) ((W - V') (X ω) : EuclideanSpace ℝ (Fin K))
              ≤ |inner ℝ (P ω - oneHotLabel Y ω) ((W - V') (X ω) : EuclideanSpace ℝ (Fin K))| :=
                le_abs_self _
            _ ≤ ‖P ω - oneHotLabel Y ω‖ * ‖((W - V') (X ω) : EuclideanSpace ℝ (Fin K))‖ :=
                abs_real_inner_le_norm _ _
            _ ≤ 2 * (‖W - V'‖ * ‖X ω‖) :=
                mul_le_mul (hr_bound ω) ((W - V').le_opNorm (X ω)) (norm_nonneg _) (by norm_num)
            _ ≤ 2 * ((‖W‖ + C) * ‖X ω‖) := by
                refine mul_le_mul_of_nonneg_left
                  (mul_le_mul_of_nonneg_right hWV'_norm (norm_nonneg _)) (by norm_num)
            _ = (2 * (‖W‖ + C)) * ‖X ω‖ := by ring
      _ = (2 * (‖W‖ + C)) * ∫ ω, ‖X ω‖ ∂μ := integral_const_mul _ _
  exact le_csSup h_bdd (Set.mem_image_of_mem _ hV)

lemma quadratic_gap_integral_le
    {Ω : Type u} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    {d K : ℕ} (hK : 1 ≤ K) {β : ℝ} {Φ : Simplex K → ℝ} (hΦ : Φ ∈ EntropyFamily K β)
    {P : Ω → EuclideanSpace ℝ (Fin K)} {X : Ω → EuclideanSpace ℝ (Fin d)}
    (hP_meas : Measurable P) (hX_meas : Measurable X)
    (hP_simp : ∀ ω, P ω ∈ Simplex K)
    (V : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
    (hD_int : Integrable (fun ω => extendSimplex Φ (P ω) + matchingPotential Φ (V (X ω)) -
      inner ℝ (P ω - uniformVec K) (V (X ω) : EuclideanSpace ℝ (Fin K))) μ) :
    (1 / (2 * β)) * ∫ ω, ‖P ω - qPhiMap Φ (V (X ω))‖ ^ 2 ∂μ ≤
      ∫ ω, (extendSimplex Φ (P ω) + matchingPotential Φ (V (X ω)) -
        inner ℝ (P ω - uniformVec K) (V (X ω) : EuclideanSpace ℝ (Fin K))) ∂μ := by
  have hq_meas : Measurable (fun ω => qPhiMap Φ (V (X ω))) :=
    (qPhiMap_continuous hK hΦ).measurable.comp (V.continuous.measurable.comp hX_meas)
  have hsq_meas : Measurable (fun ω => ‖P ω - qPhiMap Φ (V (X ω))‖ ^ 2) :=
    ((hP_meas.sub hq_meas).norm).pow_const 2
  have hsq_int : Integrable (fun ω => ‖P ω - qPhiMap Φ (V (X ω))‖ ^ 2) μ := by
    refine integrable_of_aestronglyMeasurable_bounded hsq_meas.aestronglyMeasurable 4 (fun ω => ?_)
    rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
    have hle2 : ‖P ω - qPhiMap Φ (V (X ω))‖ ≤ 2 :=
      norm_sub_le_two_of_simplex (hP_simp ω) (qPhiMap_mem_simplex hK hΦ (V (X ω)))
    have hnn : 0 ≤ ‖P ω - qPhiMap Φ (V (X ω))‖ := norm_nonneg _
    nlinarith
  rw [← integral_const_mul]
  exact integral_mono (hsq_int.const_mul (1 / (2 * β))) hD_int
    (fun ω => strong_convex_gap_qPhiMap hK hΦ (hP_simp ω) (V (X ω)))

end UL.Proof_lem_A_6

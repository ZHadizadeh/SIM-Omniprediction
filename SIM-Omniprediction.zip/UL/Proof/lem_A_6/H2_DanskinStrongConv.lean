import Mathlib
import UL.Def.def_2_1
import UL.Def.def_2_matching

set_option autoImplicit false

namespace UL.Proof_lem_A_6

noncomputable def shiftedEntropy {K : ℕ} (Φ : Simplex K → ℝ) (B : ℝ) (q : Simplex K) : ℝ :=
  Φ q - (1 / (2 * B)) * ‖(q : EuclideanSpace ℝ (Fin K)) - uniformVec K‖ ^ 2

noncomputable def qPhiMap {K : ℕ} (Φ : Simplex K → ℝ)
    (a : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K) :=
  uniformVec K +
    ((gradient (fun s : ZeroSumSubspace K => matchingPotential Φ s) a :
      ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))

/-! ### Private Simplex, Subspace, and Inner-Product Helpers -/

private lemma onesVec_apply_aux (K : ℕ) (j : Fin K) : onesVec K j = 1 := rfl

private lemma uniformVec_apply_aux (K : ℕ) (j : Fin K) :
    uniformVec K j = 1 / (K : ℝ) := by
  simp [uniformVec, onesVec_apply_aux]

private lemma sum_uniformVec_aux {K : ℕ} (hK : 1 ≤ K) :
    ∑ j : Fin K, uniformVec K j = 1 := by
  have hK0 : (K : ℝ) ≠ 0 := by exact_mod_cast (by omega : K ≠ 0)
  simp [uniformVec_apply_aux, Finset.sum_const, nsmul_eq_mul, mul_inv_cancel₀ hK0]

private lemma uniformVec_mem_simplex_aux {K : ℕ} (hK : 1 ≤ K) :
    uniformVec K ∈ Simplex K := by
  have hKpos : (0 : ℝ) < K := by exact_mod_cast (by omega : 0 < K)
  refine ⟨fun j => ?_, sum_uniformVec_aux hK⟩
  rw [uniformVec_apply_aux]
  positivity

private lemma norm_le_one_of_mem_simplex_aux {K : ℕ} {q : EuclideanSpace ℝ (Fin K)}
    (hq : q ∈ Simplex K) : ‖q‖ ≤ 1 := by
  have hsq : ‖q‖ ^ 2 ≤ 1 ^ 2 := by
    rw [EuclideanSpace.norm_sq_eq]
    have hle : ∑ i : Fin K, ‖q i‖ ^ 2 ≤ (∑ i : Fin K, q i) ^ 2 := by
      have h1 : ∑ i : Fin K, ‖q i‖ ^ 2 = ∑ i : Fin K, q i * q i := by
        refine Finset.sum_congr rfl fun i _ => ?_
        rw [Real.norm_of_nonneg (hq.1 i), sq]
      rw [h1, hq.2, one_pow, ← hq.2]
      refine Finset.sum_le_sum fun i _ => ?_
      have hi_le : q i ≤ 1 := by
        rw [← hq.2]
        exact Finset.single_le_sum (fun j _ => hq.1 j) (Finset.mem_univ i)
      nlinarith [hq.1 i]
    simpa [hq.2] using hle
  nlinarith [norm_nonneg q]

private lemma norm_sub_uniformVec_le_two {K : ℕ} (hK : 1 ≤ K) {q : EuclideanSpace ℝ (Fin K)}
    (hq : q ∈ Simplex K) : ‖q - uniformVec K‖ ≤ 2 := by
  calc
    ‖q - uniformVec K‖ ≤ ‖q‖ + ‖uniformVec K‖ := norm_sub_le _ _
    _ ≤ 1 + 1 := add_le_add (norm_le_one_of_mem_simplex_aux hq)
        (norm_le_one_of_mem_simplex_aux (uniformVec_mem_simplex_aux hK))
    _ = 2 := by norm_num

private lemma isClosed_simplex_aux (K : ℕ) : IsClosed (Simplex K) := by
  have h1 : IsClosed {q : EuclideanSpace ℝ (Fin K) | ∀ j : Fin K, 0 ≤ q j} := by
    simpa [Set.setOf_forall] using isClosed_iInter fun j : Fin K =>
      isClosed_le continuous_const (EuclideanSpace.proj j).continuous
  have h2 : IsClosed {q : EuclideanSpace ℝ (Fin K) | ∑ j : Fin K, q j = 1} :=
    isClosed_eq (continuous_finset_sum _ fun j _ => (EuclideanSpace.proj j).continuous)
      continuous_const
  exact h1.inter h2

private lemma isCompact_simplex_aux (K : ℕ) : IsCompact (Simplex K) := by
  refine Metric.isCompact_of_isClosed_isBounded (isClosed_simplex_aux K) ?_
  rw [isBounded_iff_forall_norm_le]
  exact ⟨1, fun q hq => norm_le_one_of_mem_simplex_aux hq⟩

private lemma convex_simplex_aux (K : ℕ) : Convex ℝ (Simplex K) := by
  intro p hp q hq a b ha hb hab
  refine ⟨fun j => ?_, ?_⟩
  · simp only [PiLp.add_apply, PiLp.smul_apply, smul_eq_mul]
    exact add_nonneg (mul_nonneg ha (hp.1 j)) (mul_nonneg hb (hq.1 j))
  · simp only [PiLp.add_apply, PiLp.smul_apply, smul_eq_mul,
      Finset.sum_add_distrib, ← Finset.mul_sum, hp.2, hq.2, mul_one]
    exact hab

private lemma mem_zeroSumSubspace_iff_aux (K : ℕ) (v : EuclideanSpace ℝ (Fin K)) :
    v ∈ ZeroSumSubspace K ↔ ∑ j : Fin K, v j = 0 := by
  simp [ZeroSumSubspace, LinearMap.mem_ker, PiLp.inner_apply, onesVec_apply_aux]

private lemma mem_faceTangentSpace_iff_aux (K : ℕ) (J : Finset (Fin K))
    (v : EuclideanSpace ℝ (Fin K)) :
    v ∈ FaceTangentSpace K J ↔ (∑ j : Fin K, v j = 0) ∧ (∀ j : Fin K, j ∉ J → v j = 0) := by
  simp [FaceTangentSpace, Submodule.mem_inf, Submodule.mem_iInf,
    mem_zeroSumSubspace_iff_aux, LinearMap.mem_ker]

private lemma sub_mem_zeroSumSubspace_aux {K : ℕ} {p q : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ Simplex K) (hq : q ∈ Simplex K) :
    p - q ∈ ZeroSumSubspace K := by
  rw [mem_zeroSumSubspace_iff_aux]
  simp [Finset.sum_sub_distrib, hp.2, hq.2]

private lemma sub_mem_faceTangentSpace_aux {K : ℕ} {J : Finset (Fin K)}
    {y p : EuclideanSpace ℝ (Fin K)}
    (hy : y ∈ SimplexFace K J) (hp : p ∈ SimplexFace K J) :
    y - p ∈ FaceTangentSpace K J := by
  rw [mem_faceTangentSpace_iff_aux]
  refine ⟨?_, fun j hj => ?_⟩
  · simp [Finset.sum_sub_distrib, hy.1.2, hp.1.2]
  · simp [hy.2 j hj, hp.2 j hj]

private lemma norm_combo_sq_aux {K : ℕ} (x y : EuclideanSpace ℝ (Fin K)) (t : ℝ) :
    ‖(1 - t) • x + t • y‖ ^ 2 =
      (1 - t) * ‖x‖ ^ 2 + t * ‖y‖ ^ 2 - t * (1 - t) * ‖x - y‖ ^ 2 := by
  rw [norm_add_sq_real, norm_sub_sq_real,
    norm_smul, norm_smul, Real.norm_eq_abs, Real.norm_eq_abs,
    mul_pow, mul_pow, sq_abs, sq_abs, inner_smul_left, inner_smul_right]
  simp only [conj_trivial]
  ring

private lemma norm_combo_sub_sq {K : ℕ} (p q u : EuclideanSpace ℝ (Fin K)) (t : ℝ) :
    ‖((1 - t) • p + t • q) - u‖ ^ 2 =
      (1 - t) * ‖p - u‖ ^ 2 + t * ‖q - u‖ ^ 2 - t * (1 - t) * ‖p - q‖ ^ 2 := by
  have h1 : ((1 - t) • p + t • q) - u = (1 - t) • (p - u) + t • (q - u) := by
    ext j
    simp only [PiLp.sub_apply, PiLp.add_apply, PiLp.smul_apply, smul_eq_mul]
    ring
  have h2 : p - q = (p - u) - (q - u) := by abel
  rw [h1, h2, norm_combo_sq_aux]

/-! ### Part 1: `shiftedEntropy` Continuity, Convexity, and Face Gradient -/

lemma shiftedEntropy_continuous {K : ℕ} {Φ : Simplex K → ℝ} (hΦ : Continuous Φ) (B : ℝ) :
    Continuous (shiftedEntropy Φ B) := by
  unfold shiftedEntropy
  exact hΦ.sub (continuous_const.mul (((continuous_subtype_val.sub continuous_const).norm).pow 2))

lemma shiftedEntropy_convexOn {K : ℕ} {β B : ℝ} {Φ : Simplex K → ℝ}
    (hΦ : Φ ∈ EntropyFamily K β) (hB : β ≤ B) :
    ConvexOn ℝ (Simplex K) (extendSimplex (shiftedEntropy Φ B)) := by
  have hβ : 0 < β := hΦ.1
  have hconv : ConvexOn ℝ (Simplex K)
      (fun q => extendSimplex Φ q - (1 / (2 * β)) * ‖q - uniformVec K‖ ^ 2) := hΦ.2.2.2
  refine ⟨hconv.1, fun p hp q hq a b ha hb hab => ?_⟩
  have hpq : a • p + b • q ∈ Simplex K := hconv.1 hp hq ha hb hab
  have ha_eq : a = 1 - b := by linarith
  have hbase := hconv.2 hp hq ha hb hab
  dsimp only at hbase
  have hnorm : ‖(a • p + b • q) - uniformVec K‖ ^ 2 ≤
      a * ‖p - uniformVec K‖ ^ 2 + b * ‖q - uniformVec K‖ ^ 2 := by
    rw [ha_eq, norm_combo_sub_sq]
    have hnonneg : 0 ≤ b * (1 - b) * ‖p - q‖ ^ 2 := by
      rw [← ha_eq]
      positivity
    linarith
  have hc_nonneg : 0 ≤ 1 / (2 * β) - 1 / (2 * B) := by
    have hle : 1 / (2 * B) ≤ 1 / (2 * β) :=
      one_div_le_one_div_of_le (by positivity) (by linarith)
    linarith
  have hmul : (1 / (2 * β) - 1 / (2 * B)) * ‖(a • p + b • q) - uniformVec K‖ ^ 2 ≤
      (1 / (2 * β) - 1 / (2 * B)) * (a * ‖p - uniformVec K‖ ^ 2 + b * ‖q - uniformVec K‖ ^ 2) :=
    mul_le_mul_of_nonneg_left hnorm hc_nonneg
  have heq_pq : extendSimplex (shiftedEntropy Φ B) (a • p + b • q) =
      extendSimplex Φ (a • p + b • q) -
        (1 / (2 * B)) * ‖(a • p + b • q) - uniformVec K‖ ^ 2 := by
    simp [extendSimplex, hpq, shiftedEntropy]
  have heq_p : extendSimplex (shiftedEntropy Φ B) p =
      extendSimplex Φ p - (1 / (2 * B)) * ‖p - uniformVec K‖ ^ 2 := by
    simp [extendSimplex, hp, shiftedEntropy]
  have heq_q : extendSimplex (shiftedEntropy Φ B) q =
      extendSimplex Φ q - (1 / (2 * B)) * ‖q - uniformVec K‖ ^ 2 := by
    simp [extendSimplex, hq, shiftedEntropy]
  have halg_lhs :
      extendSimplex Φ (a • p + b • q) -
          (1 / (2 * B)) * ‖(a • p + b • q) - uniformVec K‖ ^ 2 =
        (extendSimplex Φ (a • p + b • q) -
            (1 / (2 * β)) * ‖(a • p + b • q) - uniformVec K‖ ^ 2) +
          (1 / (2 * β) - 1 / (2 * B)) * ‖(a • p + b • q) - uniformVec K‖ ^ 2 := by
    ring
  have halg_rhs :
      a * (extendSimplex Φ p - (1 / (2 * B)) * ‖p - uniformVec K‖ ^ 2) +
          b * (extendSimplex Φ q - (1 / (2 * B)) * ‖q - uniformVec K‖ ^ 2) =
        (a * (extendSimplex Φ p - (1 / (2 * β)) * ‖p - uniformVec K‖ ^ 2) +
            b * (extendSimplex Φ q - (1 / (2 * β)) * ‖q - uniformVec K‖ ^ 2)) +
          (1 / (2 * β) - 1 / (2 * B)) *
            (a * ‖p - uniformVec K‖ ^ 2 + b * ‖q - uniformVec K‖ ^ 2) := by
    ring
  simp only [smul_eq_mul] at hbase ⊢
  rw [heq_pq, heq_p, heq_q, halg_lhs, halg_rhs]
  exact add_le_add hbase hmul

lemma shiftedEntropy_hasFaceGrad {K : ℕ} {β B : ℝ} {Φ : Simplex K → ℝ}
    (hΦ : Φ ∈ EntropyFamily K β) (hB : 0 < B) :
    ∀ J : Finset (Fin K), J.Nonempty →
      ∀ p ∈ SimplexFaceRelint K J, ∃ g, HasFaceGradAt (shiftedEntropy Φ B) J p g := by
  intro J hJ p hp
  obtain ⟨gΦ, hgΦ_mem, hgΦ_fderiv⟩ := hΦ.2.2.1 J hJ p hp
  let u0 : EuclideanSpace ℝ (Fin K) := (1 / B) • (p - uniformVec K)
  let S := FaceTangentSpace K J
  let w : EuclideanSpace ℝ (Fin K) := S.starProjection u0
  refine ⟨gΦ - w, Submodule.sub_mem _ hgΦ_mem (S.starProjection_apply_mem u0), ?_⟩
  let qfun : EuclideanSpace ℝ (Fin K) → ℝ :=
    fun y => (1 / (2 * B)) * ‖y - uniformVec K‖ ^ 2
  have hq_fderiv : HasFDerivWithinAt qfun (innerSL ℝ w) (SimplexFace K J) p := by
    rw [hasFDerivWithinAt_iff_tendsto]
    have h_eq : ∀ y ∈ SimplexFace K J,
        ‖y - p‖⁻¹ * ‖qfun y - qfun p - (innerSL ℝ w) (y - p)‖ =
          (1 / (2 * B)) * ‖y - p‖ := by
      intro y hy
      have hyp_mem : y - p ∈ S :=
        sub_mem_faceTangentSpace_aux hy hp.1
      have horth_mem : u0 - w ∈ Sᗮ := by
        have hsplit : w + Sᗮ.starProjection u0 = u0 :=
          S.starProjection_add_starProjection_orthogonal u0
        have heq_orth : u0 - w = Sᗮ.starProjection u0 := (eq_sub_of_add_eq' hsplit).symm
        rw [heq_orth]
        exact Sᗮ.starProjection_apply_mem u0
      have horth : inner ℝ (u0 - w) (y - p) = 0 :=
        (Submodule.mem_orthogonal' S (u0 - w)).mp horth_mem (y - p) hyp_mem
      have hinner_w : (innerSL ℝ w) (y - p) = (1 / B) * inner ℝ (p - uniformVec K) (y - p) := by
        rw [innerSL_apply_apply]
        rw [inner_sub_left] at horth
        have h2 : inner ℝ w (y - p) = inner ℝ u0 (y - p) := by linarith
        rw [h2]
        dsimp only [u0]
        rw [inner_smul_left, conj_trivial]
      have hrem : qfun y - qfun p - (innerSL ℝ w) (y - p) =
          (1 / (2 * B)) * ‖y - p‖ ^ 2 := by
        have hdecomp : y - uniformVec K = (p - uniformVec K) + (y - p) := by abel
        dsimp only [qfun]
        rw [hinner_w, hdecomp, norm_add_sq_real]
        simp only [one_div, mul_inv_rev]
        ring
      rw [hrem, Real.norm_of_nonneg (by positivity)]
      by_cases h0 : ‖y - p‖ = 0
      · simp [h0]
      · rw [sq, mul_left_comm, inv_mul_cancel_left₀ h0]
    have h_tendsto : Filter.Tendsto (fun y : EuclideanSpace ℝ (Fin K) => (1 / (2 * B)) * ‖y - p‖)
        (nhdsWithin p (SimplexFace K J)) (nhds 0) := by
      have hc : Continuous (fun y : EuclideanSpace ℝ (Fin K) => (1 / (2 * B)) * ‖y - p‖) :=
        continuous_const.mul ((continuous_id.sub continuous_const).norm)
      have ht : Filter.Tendsto (fun y : EuclideanSpace ℝ (Fin K) => (1 / (2 * B)) * ‖y - p‖)
          (nhds p) (nhds 0) := by
        simpa using hc.tendsto p
      exact ht.mono_left nhdsWithin_le_nhds
    refine h_tendsto.congr' ?_
    filter_upwards [self_mem_nhdsWithin] with y hy
    exact (h_eq y hy).symm
  have hsub := hgΦ_fderiv.sub hq_fderiv
  have hclm : innerSL ℝ (gΦ - w) = innerSL ℝ gΦ - innerSL ℝ w := map_sub (innerSL ℝ) gΦ w
  rw [← hclm] at hsub
  refine hsub.congr (fun y hy => ?_) ?_
  · simp [extendSimplex, hy.1, shiftedEntropy, qfun]
  · simp [extendSimplex, hp.1.1, shiftedEntropy, qfun]

/-! ### Part 2: Face Gradient Decomposition (`faceGrad_phi_decomp`) -/

private lemma posSupport_nonempty_and_mem_relint {K : ℕ} {p : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ Simplex K) :
    (posSupport p).Nonempty ∧ p ∈ SimplexFaceRelint K (posSupport p) := by
  classical
  have hmem : p ∈ SimplexFaceRelint K (posSupport p) := by
    refine ⟨⟨hp, fun j hj => ?_⟩, fun j hj => ?_⟩
    · have hj' : ¬ (0 < p j) := by
        simpa [posSupport] using hj
      linarith [hp.1 j]
    · simpa [posSupport] using hj
  have hne : (posSupport p).Nonempty := by
    by_contra h_empty
    rw [Finset.not_nonempty_iff_eq_empty] at h_empty
    have hzero : ∀ j : Fin K, p j = 0 := fun j => by
      have hj : j ∉ posSupport p := by simp [h_empty]
      exact hmem.1.2 j hj
    have hsum : ∑ j : Fin K, p j = 0 := Finset.sum_eq_zero fun j _ => hzero j
    linarith [hp.2]
  exact ⟨hne, hmem⟩

private lemma faceGrad_spec_aux {K : ℕ} {F : Simplex K → ℝ} {J : Finset (Fin K)}
    {p : EuclideanSpace ℝ (Fin K)} (h : ∃ g, HasFaceGradAt F J p g) :
    HasFaceGradAt F J p (faceGrad F J p) := by
  classical
  simp only [faceGrad, dif_pos h]
  exact Classical.choose_spec h

private lemma exists_relint_perturbation_aux {K : ℕ} {J : Finset (Fin K)} (hJ : J.Nonempty)
    {p v : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ SimplexFaceRelint K J) (hv : v ∈ FaceTangentSpace K J) :
    ∃ h₀ : ℝ, 0 < h₀ ∧ ∀ t : ℝ, |t| ≤ h₀ → p + t • v ∈ SimplexFaceRelint K J := by
  obtain ⟨hv_sum, hv_out⟩ := (mem_faceTangentSpace_iff_aux K J v).mp hv
  let m : ℝ := J.inf' hJ (fun j => p j)
  have hm_pos : 0 < m := (Finset.lt_inf'_iff hJ).mpr fun j hj => hp.2 j hj
  let h₀ : ℝ := m / (2 * (‖v‖ + 1))
  have hh₀_pos : 0 < h₀ := div_pos hm_pos (by positivity)
  refine ⟨h₀, hh₀_pos, fun t ht => ?_⟩
  have h_pos_on_J : ∀ j ∈ J, 0 < (p + t • v) j := by
    intro j hj
    have hpj : m ≤ p j := Finset.inf'_le (fun i => p i) hj
    have hvj_abs : |v j| ≤ ‖v‖ := by
      simpa [Real.norm_eq_abs] using (PiLp.norm_apply_le v j)
    have htv : |t * v j| ≤ m / 2 := by
      calc
        |t * v j| = |t| * |v j| := abs_mul t (v j)
        _ ≤ h₀ * ‖v‖ := mul_le_mul ht hvj_abs (abs_nonneg _) hh₀_pos.le
        _ = m * ‖v‖ / (2 * (‖v‖ + 1)) := by ring
        _ ≤ m * (‖v‖ + 1) / (2 * (‖v‖ + 1)) := by
          gcongr
          linarith
        _ = m / 2 := mul_div_mul_right m 2 (by positivity)
    have htv_lower : -(m / 2) ≤ t * v j := (abs_le.mp htv).1
    simp only [PiLp.add_apply, PiLp.smul_apply, smul_eq_mul]
    linarith
  have h_out_J : ∀ j : Fin K, j ∉ J → (p + t • v) j = 0 := fun j hj => by
    simp [hp.1.2 j hj, hv_out j hj]
  have h_nonneg : ∀ j : Fin K, 0 ≤ (p + t • v) j := fun j => by
    by_cases hj : j ∈ J
    · exact (h_pos_on_J j hj).le
    · simp [h_out_J j hj]
  have h_sum : ∑ j : Fin K, (p + t • v) j = 1 := by
    simp [Finset.sum_add_distrib, ← Finset.mul_sum, hp.1.1.2, hv_sum]
  exact ⟨⟨⟨h_nonneg, h_sum⟩, h_out_J⟩, h_pos_on_J⟩

private lemma hasDerivAt_line_of_hasFaceGradAt_aux {K : ℕ} {F : Simplex K → ℝ}
    {J : Finset (Fin K)} (hJ : J.Nonempty)
    {p g v : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ SimplexFaceRelint K J)
    (hg : HasFaceGradAt F J p g)
    (hv : v ∈ FaceTangentSpace K J) :
    HasDerivAt (fun t : ℝ => extendSimplex F (p + t • v)) (inner ℝ g v) 0 := by
  obtain ⟨h₀, hh₀_pos, hpert⟩ := exists_relint_perturbation_aux hJ hp hv
  let γ : ℝ → EuclideanSpace ℝ (Fin K) := fun t => p + t • v
  have hγ0 : γ 0 = p := by simp [γ]
  have hγ_deriv : HasDerivAt γ v 0 := by
    have h1 : HasDerivAt (fun t : ℝ => t • v) ((1 : ℝ) • v) 0 :=
      (hasDerivAt_id (0 : ℝ)).smul_const v
    simpa [γ] using h1.const_add p
  have h_mem_nhds : Set.Ioo (-h₀) h₀ ∈ nhds (0 : ℝ) :=
    Ioo_mem_nhds (neg_lt_zero.mpr hh₀_pos) hh₀_pos
  have h_maps : Set.MapsTo γ (Set.Ioo (-h₀) h₀) (SimplexFace K J) := by
    intro t ht
    exact (hpert t (abs_le.mpr ⟨ht.1.le, ht.2.le⟩)).1
  have hf : HasFDerivWithinAt (extendSimplex F) (innerSL ℝ g) (SimplexFace K J) (γ 0) := by
    rw [hγ0]; exact hg.2
  have hcomp : HasDerivWithinAt (fun t : ℝ => extendSimplex F (γ t))
      ((innerSL ℝ g) v) (Set.Ioo (-h₀) h₀) 0 :=
    hf.comp_hasDerivWithinAt 0 hγ_deriv.hasDerivWithinAt h_maps
  simpa [γ, innerSL_apply_apply] using hcomp.hasDerivAt h_mem_nhds

lemma faceGrad_phi_decomp {K : ℕ} {β B : ℝ} {Φ : Simplex K → ℝ}
    (hΦ : Φ ∈ EntropyFamily K β) (hB : 0 < B)
    {p r : EuclideanSpace ℝ (Fin K)} (hp : p ∈ Simplex K)
    (hr : r ∈ FaceTangentSpace K (posSupport p)) :
    inner ℝ r (faceGrad Φ (posSupport p) p) =
      (1 / B) * inner ℝ r (p - uniformVec K) +
        inner ℝ r (faceGrad (shiftedEntropy Φ B) (posSupport p) p) := by
  obtain ⟨hJ, hp_relint⟩ := posSupport_nonempty_and_mem_relint hp
  set J := posSupport p
  let F := shiftedEntropy Φ B
  have hgΦ : HasFaceGradAt Φ J p (faceGrad Φ J p) :=
    faceGrad_spec_aux (hΦ.2.2.1 J hJ p hp_relint)
  have hgF : HasFaceGradAt F J p (faceGrad F J p) :=
    faceGrad_spec_aux (shiftedEntropy_hasFaceGrad hΦ hB J hJ p hp_relint)
  have hdΦ : HasDerivAt (fun t : ℝ => extendSimplex Φ (p + t • r))
      (inner ℝ (faceGrad Φ J p) r) 0 :=
    hasDerivAt_line_of_hasFaceGradAt_aux hJ hp_relint hgΦ hr
  have hdF : HasDerivAt (fun t : ℝ => extendSimplex F (p + t • r))
      (inner ℝ (faceGrad F J p) r) 0 :=
    hasDerivAt_line_of_hasFaceGradAt_aux hJ hp_relint hgF hr
  let qline : ℝ → ℝ := fun t => (1 / (2 * B)) * ‖(p + t • r) - uniformVec K‖ ^ 2
  have hqline_poly : qline = fun t : ℝ =>
      (1 / (2 * B)) * ‖p - uniformVec K‖ ^ 2 +
        t * ((1 / B) * inner ℝ (p - uniformVec K) r) +
        (t * t) * ((1 / (2 * B)) * ‖r‖ ^ 2) := by
    ext t
    dsimp only [qline]
    have hsub : (p + t • r) - uniformVec K = (p - uniformVec K) + t • r := by abel
    rw [hsub, norm_add_sq_real, norm_smul, Real.norm_eq_abs, mul_pow, sq_abs, inner_smul_right]
    simp only [one_div, mul_inv_rev]
    ring
  have hdQ : HasDerivAt qline ((1 / B) * inner ℝ (p - uniformVec K) r) 0 := by
    rw [hqline_poly]
    have hd1 : HasDerivAt (fun _ : ℝ => (1 / (2 * B)) * ‖p - uniformVec K‖ ^ 2) 0 0 :=
      hasDerivAt_const 0 _
    have hd2 : HasDerivAt (fun t : ℝ => t * ((1 / B) * inner ℝ (p - uniformVec K) r))
        (1 * ((1 / B) * inner ℝ (p - uniformVec K) r)) 0 :=
      (hasDerivAt_id 0).mul_const _
    have hd3 : HasDerivAt (fun t : ℝ => (t * t) * ((1 / (2 * B)) * ‖r‖ ^ 2))
        (((1 : ℝ) * 0 + 0 * 1) * ((1 / (2 * B)) * ‖r‖ ^ 2)) 0 :=
      ((hasDerivAt_id 0).mul (hasDerivAt_id 0)).mul_const _
    simpa using (hd1.add hd2).add hd3
  obtain ⟨h₀, hh₀_pos, hpert⟩ := exists_relint_perturbation_aux hJ hp_relint hr
  have hev : (fun t : ℝ => extendSimplex Φ (p + t • r)) =ᶠ[nhds (0 : ℝ)]
      (fun t : ℝ => extendSimplex F (p + t • r) + qline t) := by
    filter_upwards [Ioo_mem_nhds (neg_lt_zero.mpr hh₀_pos) hh₀_pos] with t ht
    have hmem : p + t • r ∈ Simplex K :=
      (hpert t (abs_le.mpr ⟨ht.1.le, ht.2.le⟩)).1.1
    simp [extendSimplex, hmem, F, shiftedEntropy, qline]
  have hd_sum : HasDerivAt (fun t : ℝ => extendSimplex Φ (p + t • r))
      (inner ℝ (faceGrad F J p) r + (1 / B) * inner ℝ (p - uniformVec K) r) 0 :=
    (hdF.add hdQ).congr_of_eventuallyEq hev
  have heq := hdΦ.unique hd_sum
  dsimp only [F] at heq
  rw [← real_inner_comm r (faceGrad Φ J p), ← real_inner_comm r (p - uniformVec K),
    ← real_inner_comm r (faceGrad (shiftedEntropy Φ B) J p)]
  linarith

/-! ### Part 3: `matchingPotential`, `optQ`, Danskin (`qPhiMap`), and Strong Convexity Gap -/

private noncomputable def potObj {K : ℕ} (Φ : Simplex K → ℝ)
    (a : EuclideanSpace ℝ (Fin K)) (q : Simplex K) : ℝ :=
  inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - uniformVec K) a - Φ q

private lemma potObj_continuous {K : ℕ} {Φ : Simplex K → ℝ} (hΦ : Continuous Φ)
    (a : EuclideanSpace ℝ (Fin K)) :
    Continuous (potObj Φ a) := by
  unfold potObj
  exact ((continuous_subtype_val.sub continuous_const).inner continuous_const).sub hΦ

private lemma exists_max_potObj {K : ℕ} (hK : 1 ≤ K) {Φ : Simplex K → ℝ}
    (hΦ : Continuous Φ) (a : EuclideanSpace ℝ (Fin K)) :
    ∃ q : Simplex K, ∀ q' : Simplex K, potObj Φ a q' ≤ potObj Φ a q := by
  haveI : CompactSpace (Simplex K) := isCompact_iff_compactSpace.mp (isCompact_simplex_aux K)
  have hne : (Set.univ : Set (Simplex K)).Nonempty :=
    ⟨⟨uniformVec K, uniformVec_mem_simplex_aux hK⟩, Set.mem_univ _⟩
  obtain ⟨q, _, hq⟩ := isCompact_univ.exists_isMaxOn hne (potObj_continuous hΦ a).continuousOn
  exact ⟨q, fun q' => isMaxOn_iff.mp hq q' (Set.mem_univ q')⟩

open Classical in
private noncomputable def optQ {K : ℕ} (Φ : Simplex K → ℝ)
    (a : EuclideanSpace ℝ (Fin K)) : EuclideanSpace ℝ (Fin K) :=
  if h : ∃ q : Simplex K, ∀ q' : Simplex K, potObj Φ a q' ≤ potObj Φ a q then
    ((Classical.choose h : Simplex K) : EuclideanSpace ℝ (Fin K))
  else
    uniformVec K

private lemma optQ_mem_simplex {K : ℕ} (hK : 1 ≤ K) (Φ : Simplex K → ℝ)
    (a : EuclideanSpace ℝ (Fin K)) :
    optQ Φ a ∈ Simplex K := by
  classical
  unfold optQ
  split_ifs with h
  · exact (Classical.choose h).2
  · exact uniformVec_mem_simplex_aux hK

private lemma matchingPotential_ge_of_mem_simplex {K : ℕ} (hK : 1 ≤ K) {Φ : Simplex K → ℝ}
    (hΦ : Continuous Φ) (a : EuclideanSpace ℝ (Fin K))
    {p : EuclideanSpace ℝ (Fin K)} (hp : p ∈ Simplex K) :
    inner ℝ (p - uniformVec K) a - extendSimplex Φ p ≤ matchingPotential Φ a := by
  obtain ⟨q₀, hq₀⟩ := exists_max_potObj hK hΦ a
  have hbdd : BddAbove (Set.range (potObj Φ a)) := by
    refine ⟨potObj Φ a q₀, ?_⟩
    rintro _ ⟨q', rfl⟩
    exact hq₀ q'
  have hle : potObj Φ a ⟨p, hp⟩ ≤ matchingPotential Φ a :=
    le_ciSup hbdd ⟨p, hp⟩
  simpa [potObj, extendSimplex, hp] using hle

private lemma matchingPotential_eq_optQ {K : ℕ} (hK : 1 ≤ K) {Φ : Simplex K → ℝ}
    (hΦ : Continuous Φ) (a : EuclideanSpace ℝ (Fin K)) :
    matchingPotential Φ a =
      inner ℝ (optQ Φ a - uniformVec K) a - extendSimplex Φ (optQ Φ a) := by
  classical
  have hex := exists_max_potObj hK hΦ a
  set q₀ : Simplex K := Classical.choose hex
  have hq₀ : ∀ q' : Simplex K, potObj Φ a q' ≤ potObj Φ a q₀ := Classical.choose_spec hex
  have hopt : optQ Φ a = (q₀ : EuclideanSpace ℝ (Fin K)) := by
    dsimp only [optQ, q₀]
    rw [dif_pos hex]
  haveI : Nonempty (Simplex K) := ⟨q₀⟩
  have hbdd : BddAbove (Set.range (potObj Φ a)) := by
    refine ⟨potObj Φ a q₀, ?_⟩
    rintro _ ⟨q', rfl⟩
    exact hq₀ q'
  have hsup : matchingPotential Φ a = potObj Φ a q₀ :=
    le_antisymm (ciSup_le hq₀) (le_ciSup hbdd q₀)
  rw [hsup, hopt]
  simp [potObj, extendSimplex, q₀.2]

private lemma matchingPotential_sub_le {K : ℕ} (hK : 1 ≤ K) {Φ : Simplex K → ℝ}
    (hΦ : Continuous Φ) (a b : EuclideanSpace ℝ (Fin K)) :
    matchingPotential Φ a - matchingPotential Φ b ≤ 2 * ‖a - b‖ := by
  set qa := optQ Φ a
  have hqa : qa ∈ Simplex K := optQ_mem_simplex hK Φ a
  have ha := matchingPotential_eq_optQ hK hΦ a
  have hb := matchingPotential_ge_of_mem_simplex hK hΦ b hqa
  have hdiff : matchingPotential Φ a - matchingPotential Φ b ≤
      inner ℝ (qa - uniformVec K) (a - b) := by
    rw [inner_sub_right]
    linarith
  calc
    matchingPotential Φ a - matchingPotential Φ b
      ≤ inner ℝ (qa - uniformVec K) (a - b) := hdiff
    _ ≤ ‖qa - uniformVec K‖ * ‖a - b‖ := real_inner_le_norm _ _
    _ ≤ 2 * ‖a - b‖ :=
        mul_le_mul_of_nonneg_right (norm_sub_uniformVec_le_two hK hqa) (norm_nonneg _)

lemma matchingPotential_lipschitz_bound {K : ℕ} (hK : 1 ≤ K) {Φ : Simplex K → ℝ}
    (hΦ : Continuous Φ) (a b : EuclideanSpace ℝ (Fin K)) :
    |matchingPotential Φ a - matchingPotential Φ b| ≤ 2 * ‖a - b‖ := by
  rw [abs_sub_le_iff]
  refine ⟨matchingPotential_sub_le hK hΦ a b, ?_⟩
  simpa [norm_sub_rev] using matchingPotential_sub_le hK hΦ b a

lemma matchingPotential_continuous {K : ℕ} (hK : 1 ≤ K) {Φ : Simplex K → ℝ}
    (hΦ : Continuous Φ) :
    Continuous (matchingPotential Φ) := by
  have hlip : LipschitzWith 2 (matchingPotential Φ) :=
    LipschitzWith.of_dist_le_mul fun a b => by
      simpa [Real.dist_eq, dist_eq_norm] using matchingPotential_lipschitz_bound hK hΦ a b
  exact hlip.continuous

private lemma strong_convex_gap_optQ {K : ℕ} (hK : 1 ≤ K) {β : ℝ} {Φ : Simplex K → ℝ}
    (hΦ : Φ ∈ EntropyFamily K β) (a : EuclideanSpace ℝ (Fin K))
    {p : EuclideanSpace ℝ (Fin K)} (hp : p ∈ Simplex K) :
    (1 / (2 * β)) * ‖p - optQ Φ a‖ ^ 2 ≤
      extendSimplex Φ p + matchingPotential Φ a - inner ℝ (p - uniformVec K) a := by
  have hβ : 0 < β := hΦ.1
  have hΦ_cont : Continuous Φ := hΦ.2.1
  have hconv := hΦ.2.2.2
  set qa := optQ Φ a
  have hqa : qa ∈ Simplex K := optQ_mem_simplex hK Φ a
  have ha_eq := matchingPotential_eq_optQ hK hΦ_cont a
  set A : ℝ := (1 / (2 * β)) * ‖p - qa‖ ^ 2
  set C : ℝ := extendSimplex Φ p + matchingPotential Φ a - inner ℝ (p - uniformVec K) a
  have hC_nonneg : 0 ≤ C := by
    have hge := matchingPotential_ge_of_mem_simplex hK hΦ_cont a hp
    dsimp only [C]
    linarith
  have h_for_t : ∀ t : ℝ, 0 < t → t < 1 → (1 - t) * A ≤ C := by
    intro t ht0 ht1
    have h1t : 0 ≤ 1 - t := by linarith
    let qt : EuclideanSpace ℝ (Fin K) := (1 - t) • qa + t • p
    have hqt : qt ∈ Simplex K :=
      convex_simplex_aux K hqa hp h1t ht0.le (by ring)
    have hsc := hconv.2 hqa hp h1t ht0.le (by ring)
    have hnorm_qt : ‖qt - uniformVec K‖ ^ 2 =
        (1 - t) * ‖qa - uniformVec K‖ ^ 2 + t * ‖p - uniformVec K‖ ^ 2 -
          t * (1 - t) * ‖p - qa‖ ^ 2 := by
      simpa [qt, norm_sub_rev] using norm_combo_sub_sq qa p (uniformVec K) t
    change extendSimplex Φ qt - (1 / (2 * β)) * ‖qt - uniformVec K‖ ^ 2 ≤
      (1 - t) * (extendSimplex Φ qa - (1 / (2 * β)) * ‖qa - uniformVec K‖ ^ 2) +
        t * (extendSimplex Φ p - (1 / (2 * β)) * ‖p - uniformVec K‖ ^ 2) at hsc
    rw [hnorm_qt] at hsc
    have hsc' : extendSimplex Φ qt + t * ((1 - t) * A) ≤
        (1 - t) * extendSimplex Φ qa + t * extendSimplex Φ p := by
      have halg1 :
          extendSimplex Φ qt -
              (1 / (2 * β)) * ((1 - t) * ‖qa - uniformVec K‖ ^ 2 +
                t * ‖p - uniformVec K‖ ^ 2 - t * (1 - t) * ‖p - qa‖ ^ 2) =
            (extendSimplex Φ qt + t * ((1 - t) * A)) -
              (1 / (2 * β)) * (1 - t) * ‖qa - uniformVec K‖ ^ 2 -
              (1 / (2 * β)) * t * ‖p - uniformVec K‖ ^ 2 := by
        dsimp only [A]
        ring
      have halg2 :
          (1 - t) * (extendSimplex Φ qa - (1 / (2 * β)) * ‖qa - uniformVec K‖ ^ 2) +
              t * (extendSimplex Φ p - (1 / (2 * β)) * ‖p - uniformVec K‖ ^ 2) =
            ((1 - t) * extendSimplex Φ qa + t * extendSimplex Φ p) -
              (1 / (2 * β)) * (1 - t) * ‖qa - uniformVec K‖ ^ 2 -
              (1 / (2 * β)) * t * ‖p - uniformVec K‖ ^ 2 := by
        ring
      linarith
    have hpot_qt := matchingPotential_ge_of_mem_simplex hK hΦ_cont a hqt
    have hinner_qt : inner ℝ (qt - uniformVec K) a =
        (1 - t) * inner ℝ (qa - uniformVec K) a + t * inner ℝ (p - uniformVec K) a := by
      have hsub : qt - uniformVec K =
          (1 - t) • (qa - uniformVec K) + t • (p - uniformVec K) := by
        ext j
        simp only [qt, PiLp.sub_apply, PiLp.add_apply, PiLp.smul_apply, smul_eq_mul]
        ring
      rw [hsub, inner_add_left, inner_smul_left, inner_smul_left]
      simp
    rw [hinner_qt] at hpot_qt
    have hpot' :
        (1 - t) * extendSimplex Φ qa + t * extendSimplex Φ p - extendSimplex Φ qt ≤ t * C := by
      have halg3 :
          t * C - ((1 - t) * extendSimplex Φ qa + t * extendSimplex Φ p - extendSimplex Φ qt) =
            matchingPotential Φ a -
              ((1 - t) * inner ℝ (qa - uniformVec K) a +
                t * inner ℝ (p - uniformVec K) a - extendSimplex Φ qt) := by
        dsimp only [C]
        rw [ha_eq]
        ring
      linarith
    have hcomb : t * ((1 - t) * A) ≤ t * C := by linarith
    exact le_of_mul_le_mul_left hcomb ht0
  by_contra hlt
  push_neg at hlt
  have hA_pos : 0 < A := lt_of_le_of_lt hC_nonneg hlt
  let t₀ : ℝ := (A - C) / (2 * A)
  have ht₀_pos : 0 < t₀ := div_pos (by linarith) (by positivity)
  have ht₀_lt : t₀ < 1 := (div_lt_one (by positivity)).mpr (by linarith)
  have hineq := h_for_t t₀ ht₀_pos ht₀_lt
  have ht₀_mul : t₀ * (2 * A) = A - C := div_mul_cancel₀ (A - C) (by positivity)
  have h2 : 2 * ((1 - t₀) * A) = A + C := by
    calc
      2 * ((1 - t₀) * A) = 2 * A - t₀ * (2 * A) := by ring
      _ = 2 * A - (A - C) := by rw [ht₀_mul]
      _ = A + C := by ring
  linarith

private lemma norm_optQ_sub_le {K : ℕ} (hK : 1 ≤ K) {β : ℝ} {Φ : Simplex K → ℝ}
    (hΦ : Φ ∈ EntropyFamily K β) (a b : EuclideanSpace ℝ (Fin K)) :
    ‖optQ Φ a - optQ Φ b‖ ≤ β * ‖a - b‖ := by
  have hβ : 0 < β := hΦ.1
  have hΦ_cont : Continuous Φ := hΦ.2.1
  set qa := optQ Φ a
  set qb := optQ Φ b
  have hqa : qa ∈ Simplex K := optQ_mem_simplex hK Φ a
  have hqb : qb ∈ Simplex K := optQ_mem_simplex hK Φ b
  have hg1 := strong_convex_gap_optQ hK hΦ a hqb
  have hg2 := strong_convex_gap_optQ hK hΦ b hqa
  have ha_eq := matchingPotential_eq_optQ hK hΦ_cont a
  have hb_eq := matchingPotential_eq_optQ hK hΦ_cont b
  have hsymm : ‖qb - qa‖ = ‖qa - qb‖ := norm_sub_rev qb qa
  rw [hsymm] at hg1
  have hinner_alg :
      (inner ℝ (qa - uniformVec K) a - inner ℝ (qb - uniformVec K) a) +
        (inner ℝ (qb - uniformVec K) b - inner ℝ (qa - uniformVec K) b) =
      inner ℝ (qa - qb) (a - b) := by
    rw [← inner_sub_left, ← inner_sub_left]
    have hs1 : (qa - uniformVec K) - (qb - uniformVec K) = qa - qb := by abel
    have hs2 : (qb - uniformVec K) - (qa - uniformVec K) = -(qa - qb) := by abel
    rw [hs1, hs2, inner_neg_left, ← sub_eq_add_neg, ← inner_sub_right]
  have hsum : (1 / β) * ‖qa - qb‖ ^ 2 ≤ inner ℝ (qa - qb) (a - b) := by
    have hcoef : (1 / (2 * β)) * ‖qa - qb‖ ^ 2 + (1 / (2 * β)) * ‖qa - qb‖ ^ 2 =
        (1 / β) * ‖qa - qb‖ ^ 2 := by
      simp only [one_div, mul_inv_rev]
      ring
    linarith
  have hcs : inner ℝ (qa - qb) (a - b) ≤ ‖qa - qb‖ * ‖a - b‖ := real_inner_le_norm _ _
  have hle1 : (1 / β) * ‖qa - qb‖ ^ 2 ≤ ‖qa - qb‖ * ‖a - b‖ := le_trans hsum hcs
  have hle2 : ‖qa - qb‖ ^ 2 ≤ ‖qa - qb‖ * (β * ‖a - b‖) := by
    have hmul := mul_le_mul_of_nonneg_left hle1 hβ.le
    have hcancel : β * ((1 / β) * ‖qa - qb‖ ^ 2) = ‖qa - qb‖ ^ 2 := by
      rw [one_div, mul_inv_cancel_left₀ hβ.ne']
    have hrhs : β * (‖qa - qb‖ * ‖a - b‖) = ‖qa - qb‖ * (β * ‖a - b‖) := by ring
    linarith
  by_cases h0 : ‖qa - qb‖ = 0
  · rw [h0]; positivity
  · have hpos : 0 < ‖qa - qb‖ := lt_of_le_of_ne (norm_nonneg _) (Ne.symm h0)
    nlinarith

private lemma hasGradientAt_matchingPotential_subspace {K : ℕ} (hK : 1 ≤ K) {β : ℝ}
    {Φ : Simplex K → ℝ} (hΦ : Φ ∈ EntropyFamily K β) (s : ZeroSumSubspace K) :
    HasGradientAt (fun s' : ZeroSumSubspace K => matchingPotential Φ s')
      ⟨optQ Φ (s : EuclideanSpace ℝ (Fin K)) - uniformVec K,
        sub_mem_zeroSumSubspace_aux (optQ_mem_simplex hK Φ _) (uniformVec_mem_simplex_aux hK)⟩ s := by
  have hβ : 0 < β := hΦ.1
  have hΦ_cont : Continuous Φ := hΦ.2.1
  let vs : ZeroSumSubspace K :=
    ⟨optQ Φ (s : EuclideanSpace ℝ (Fin K)) - uniformVec K,
      sub_mem_zeroSumSubspace_aux (optQ_mem_simplex hK Φ _) (uniformVec_mem_simplex_aux hK)⟩
  rw [hasGradientAt_iff_tendsto]
  have h_bound : ∀ s' : ZeroSumSubspace K,
      ‖matchingPotential Φ s' - matchingPotential Φ s - inner ℝ vs (s' - s)‖ ≤
        β * ‖s' - s‖ ^ 2 := by
    intro s'
    have hinner_coe : inner ℝ vs (s' - s) =
        inner ℝ (optQ Φ (s : EuclideanSpace ℝ (Fin K)) - uniformVec K)
          ((s' : EuclideanSpace ℝ (Fin K)) - (s : EuclideanSpace ℝ (Fin K))) := by
      rfl
    have hs_eq := matchingPotential_eq_optQ hK hΦ_cont (s : EuclideanSpace ℝ (Fin K))
    have hs'_ge := matchingPotential_ge_of_mem_simplex hK hΦ_cont
      (s' : EuclideanSpace ℝ (Fin K)) (optQ_mem_simplex hK Φ (s : EuclideanSpace ℝ (Fin K)))
    have h_low : 0 ≤ matchingPotential Φ s' - matchingPotential Φ s - inner ℝ vs (s' - s) := by
      rw [hinner_coe, inner_sub_right]
      linarith
    have hs'_eq := matchingPotential_eq_optQ hK hΦ_cont (s' : EuclideanSpace ℝ (Fin K))
    have hs_ge := matchingPotential_ge_of_mem_simplex hK hΦ_cont
      (s : EuclideanSpace ℝ (Fin K)) (optQ_mem_simplex hK Φ (s' : EuclideanSpace ℝ (Fin K)))
    have h_up1 : matchingPotential Φ s' - matchingPotential Φ s - inner ℝ vs (s' - s) ≤
        inner ℝ (optQ Φ (s' : EuclideanSpace ℝ (Fin K)) -
          optQ Φ (s : EuclideanSpace ℝ (Fin K)))
          ((s' : EuclideanSpace ℝ (Fin K)) - (s : EuclideanSpace ℝ (Fin K))) := by
      rw [hinner_coe]
      have halg :
          inner ℝ (optQ Φ (s' : EuclideanSpace ℝ (Fin K)) - uniformVec K)
              (s' : EuclideanSpace ℝ (Fin K)) -
            inner ℝ (optQ Φ (s' : EuclideanSpace ℝ (Fin K)) - uniformVec K)
              (s : EuclideanSpace ℝ (Fin K)) -
            inner ℝ (optQ Φ (s : EuclideanSpace ℝ (Fin K)) - uniformVec K)
              ((s' : EuclideanSpace ℝ (Fin K)) - (s : EuclideanSpace ℝ (Fin K))) =
          inner ℝ (optQ Φ (s' : EuclideanSpace ℝ (Fin K)) -
              optQ Φ (s : EuclideanSpace ℝ (Fin K)))
              ((s' : EuclideanSpace ℝ (Fin K)) - (s : EuclideanSpace ℝ (Fin K))) := by
        rw [← inner_sub_right, ← inner_sub_left]
        congr 1
        abel
      linarith
    have hnorm_sub_coe :
        ‖(s' : EuclideanSpace ℝ (Fin K)) - (s : EuclideanSpace ℝ (Fin K))‖ = ‖s' - s‖ := by
      rw [← Submodule.coe_sub, Submodule.norm_coe]
    have h_up2 :
        inner ℝ (optQ Φ (s' : EuclideanSpace ℝ (Fin K)) -
            optQ Φ (s : EuclideanSpace ℝ (Fin K)))
            ((s' : EuclideanSpace ℝ (Fin K)) - (s : EuclideanSpace ℝ (Fin K))) ≤
          β * ‖s' - s‖ ^ 2 := by
      calc
        inner ℝ (optQ Φ (s' : EuclideanSpace ℝ (Fin K)) -
            optQ Φ (s : EuclideanSpace ℝ (Fin K)))
            ((s' : EuclideanSpace ℝ (Fin K)) - (s : EuclideanSpace ℝ (Fin K)))
          ≤ ‖optQ Φ (s' : EuclideanSpace ℝ (Fin K)) -
              optQ Φ (s : EuclideanSpace ℝ (Fin K))‖ *
              ‖(s' : EuclideanSpace ℝ (Fin K)) - (s : EuclideanSpace ℝ (Fin K))‖ :=
            real_inner_le_norm _ _
        _ ≤ (β * ‖(s' : EuclideanSpace ℝ (Fin K)) - (s : EuclideanSpace ℝ (Fin K))‖) *
              ‖(s' : EuclideanSpace ℝ (Fin K)) - (s : EuclideanSpace ℝ (Fin K))‖ :=
            mul_le_mul_of_nonneg_right (norm_optQ_sub_le hK hΦ _ _) (norm_nonneg _)
        _ = β * ‖s' - s‖ ^ 2 := by
            rw [hnorm_sub_coe]
            ring
    rw [Real.norm_of_nonneg h_low]
    exact le_trans h_up1 h_up2
  have h_squeeze : ∀ s' : ZeroSumSubspace K,
      ‖s' - s‖⁻¹ * ‖matchingPotential Φ s' - matchingPotential Φ s - inner ℝ vs (s' - s)‖ ≤
        β * ‖s' - s‖ := by
    intro s'
    by_cases hs0 : ‖s' - s‖ = 0
    · simp [hs0]
    · have hpos : 0 < ‖s' - s‖ := lt_of_le_of_ne (norm_nonneg _) (Ne.symm hs0)
      calc
        ‖s' - s‖⁻¹ * ‖matchingPotential Φ s' - matchingPotential Φ s - inner ℝ vs (s' - s)‖
          ≤ ‖s' - s‖⁻¹ * (β * ‖s' - s‖ ^ 2) :=
            mul_le_mul_of_nonneg_left (h_bound s') (inv_nonneg.mpr hpos.le)
        _ = β * ‖s' - s‖ := by
            rw [sq, mul_left_comm, inv_mul_cancel_left₀ hs0]
  have h_tendsto : Filter.Tendsto (fun s' : ZeroSumSubspace K => β * ‖s' - s‖)
      (nhds s) (nhds 0) := by
    have hc : Continuous (fun s' : ZeroSumSubspace K => β * ‖s' - s‖) :=
      continuous_const.mul ((continuous_id.sub continuous_const).norm)
    simpa using hc.tendsto s
  exact squeeze_zero (fun _ => by positivity) h_squeeze h_tendsto

private lemma qPhiMap_eq_optQ {K : ℕ} (hK : 1 ≤ K) {β : ℝ} {Φ : Simplex K → ℝ}
    (hΦ : Φ ∈ EntropyFamily K β) (a : ZeroSumSubspace K) :
    qPhiMap Φ a = optQ Φ (a : EuclideanSpace ℝ (Fin K)) := by
  unfold qPhiMap
  rw [(hasGradientAt_matchingPotential_subspace hK hΦ a).gradient]
  change uniformVec K + (optQ Φ (a : EuclideanSpace ℝ (Fin K)) - uniformVec K) =
    optQ Φ (a : EuclideanSpace ℝ (Fin K))
  abel

lemma qPhiMap_mem_simplex {K : ℕ} (hK : 1 ≤ K) {β : ℝ} {Φ : Simplex K → ℝ}
    (hΦ : Φ ∈ EntropyFamily K β) (a : ZeroSumSubspace K) :
    qPhiMap Φ a ∈ Simplex K := by
  rw [qPhiMap_eq_optQ hK hΦ a]
  exact optQ_mem_simplex hK Φ (a : EuclideanSpace ℝ (Fin K))

lemma qPhiMap_continuous {K : ℕ} (hK : 1 ≤ K) {β : ℝ} {Φ : Simplex K → ℝ}
    (hΦ : Φ ∈ EntropyFamily K β) :
    Continuous (qPhiMap Φ) := by
  have hβ : 0 < β := hΦ.1
  have hlip : LipschitzWith (Real.toNNReal β) (qPhiMap Φ) :=
    LipschitzWith.of_dist_le_mul fun a b => by
      rw [Real.coe_toNNReal β hβ.le, dist_eq_norm, dist_eq_norm,
        qPhiMap_eq_optQ hK hΦ a, qPhiMap_eq_optQ hK hΦ b]
      have hnorm : ‖(a : EuclideanSpace ℝ (Fin K)) - (b : EuclideanSpace ℝ (Fin K))‖ = ‖a - b‖ := by
        rw [← Submodule.coe_sub, Submodule.norm_coe]
      rw [← hnorm]
      exact norm_optQ_sub_le hK hΦ (a : EuclideanSpace ℝ (Fin K))
        (b : EuclideanSpace ℝ (Fin K))
  exact hlip.continuous

lemma strong_convex_gap_qPhiMap {K : ℕ} (hK : 1 ≤ K) {β : ℝ} {Φ : Simplex K → ℝ}
    (hΦ : Φ ∈ EntropyFamily K β)
    {p : EuclideanSpace ℝ (Fin K)} (hp : p ∈ Simplex K) (a : ZeroSumSubspace K) :
    (1 / (2 * β)) * ‖p - qPhiMap Φ a‖ ^ 2 ≤
      extendSimplex Φ p + matchingPotential Φ a -
        inner ℝ (p - uniformVec K) (a : EuclideanSpace ℝ (Fin K)) := by
  rw [qPhiMap_eq_optQ hK hΦ a]
  exact strong_convex_gap_optQ hK hΦ (a : EuclideanSpace ℝ (Fin K)) hp

end UL.Proof_lem_A_6

import Mathlib
import UL.Stmt.lem_A_3
import UL.Stmt.lem_A_4
import UL.Stmt.lem_A_5
import UL.Def.def_2_matching

set_option autoImplicit false

namespace UL.Proof_lem_A_6

open MeasureTheory

universe u v

private lemma onesVec_apply (K : ℕ) (j : Fin K) : onesVec K j = 1 := rfl

private lemma inner_eq_sum {K : ℕ} (x y : EuclideanSpace ℝ (Fin K)) :
    inner ℝ x y = ∑ i : Fin K, x i * y i := by
  rw [PiLp.inner_apply]
  refine Finset.sum_congr rfl (fun i _ => ?_)
  simp [mul_comm]

private lemma norm_sq_eq_sum {K : ℕ} (x : EuclideanSpace ℝ (Fin K)) :
    ‖x‖ ^ 2 = ∑ i : Fin K, (x i) ^ 2 := by
  rw [← real_inner_self_eq_norm_sq, inner_eq_sum]
  refine Finset.sum_congr rfl (fun i _ => ?_)
  ring

private lemma inner_onesVec_eq_sum {K : ℕ} (x : EuclideanSpace ℝ (Fin K)) :
    inner ℝ (onesVec K) x = ∑ j : Fin K, x j := by
  rw [inner_eq_sum]
  simp [onesVec_apply]

private lemma mem_zeroSumSubspace_iff {K : ℕ} (x : EuclideanSpace ℝ (Fin K)) :
    x ∈ ZeroSumSubspace K ↔ inner ℝ (onesVec K) x = 0 := by
  simp [ZeroSumSubspace, LinearMap.mem_ker]

private lemma simplex_coord_le_one {K : ℕ} {q : EuclideanSpace ℝ (Fin K)}
    (hq : q ∈ Simplex K) (j : Fin K) : q j ≤ 1 := by
  rw [← hq.2]
  exact Finset.single_le_sum (fun i _ => hq.1 i) (Finset.mem_univ j)

lemma uniformVec_mem_simplex {K : ℕ} (hK : 1 ≤ K) : uniformVec K ∈ Simplex K := by
  have hK_pos : (0 : ℝ) < (K : ℝ) := Nat.cast_pos.mpr (by omega)
  refine ⟨fun j => ?_, ?_⟩
  · change 0 ≤ ((1 : ℝ) / (K : ℝ)) * onesVec K j
    rw [onesVec_apply, mul_one]
    positivity
  · have h : ∑ j : Fin K, (uniformVec K) j = ∑ _j : Fin K, (1 : ℝ) / (K : ℝ) := by
      refine Finset.sum_congr rfl (fun j _ => ?_)
      change ((1 : ℝ) / (K : ℝ)) * onesVec K j = 1 / (K : ℝ)
      rw [onesVec_apply, mul_one]
    rw [h, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
    field_simp [hK_pos.ne']

lemma oneHotVec_mem_simplex {K : ℕ} (y : Fin K) : oneHotVec y ∈ Simplex K := by
  refine ⟨fun j => ?_, ?_⟩
  · simp only [oneHotVec, EuclideanSpace.single_apply]
    split_ifs <;> norm_num
  · simp [oneHotVec, EuclideanSpace.single_apply]

lemma oneHotLabel_mem_simplex {Ω : Type*} {K : ℕ} (Y : Ω → Fin K) (ω : Ω) :
    oneHotLabel Y ω ∈ Simplex K :=
  oneHotVec_mem_simplex (Y ω)

lemma oneHotLabel_measurable {Ω : Type*} [MeasurableSpace Ω] {K : ℕ}
    {Y : Ω → Fin K} (hY : Measurable Y) :
    Measurable (oneHotLabel Y) :=
  (measurable_of_countable (oneHotVec (K := K))).comp hY

lemma norm_le_one_of_mem_simplex {K : ℕ} {q : EuclideanSpace ℝ (Fin K)}
    (hq : q ∈ Simplex K) : ‖q‖ ≤ 1 := by
  have hsq : ‖q‖ ^ 2 ≤ 1 := by
    rw [norm_sq_eq_sum, ← hq.2]
    refine Finset.sum_le_sum (fun j _ => ?_)
    have h0 := hq.1 j
    have h1 := simplex_coord_le_one hq j
    nlinarith
  have hnn : 0 ≤ ‖q‖ := norm_nonneg q
  nlinarith

lemma sub_mem_zeroSumSubspace_of_mem_simplex {K : ℕ} {p q : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ Simplex K) (hq : q ∈ Simplex K) :
    p - q ∈ ZeroSumSubspace K := by
  rw [mem_zeroSumSubspace_iff, inner_sub_right,
    inner_onesVec_eq_sum, inner_onesVec_eq_sum, hp.2, hq.2, sub_self]

lemma inner_uniformVec_zero_of_mem_zeroSumSubspace {K : ℕ}
    {s : EuclideanSpace ℝ (Fin K)} (hs : s ∈ ZeroSumSubspace K) :
    inner ℝ (uniformVec K) s = 0 := by
  rw [mem_zeroSumSubspace_iff] at hs
  simp [uniformVec, inner_smul_left, hs]

lemma simplex_convex (K : ℕ) : Convex ℝ (Simplex K) := by
  intro x hx y hy a b ha hb hab
  refine ⟨fun j => ?_, ?_⟩
  · change 0 ≤ a * x j + b * y j
    exact add_nonneg (mul_nonneg ha (hx.1 j)) (mul_nonneg hb (hy.1 j))
  · have h : ∑ j : Fin K, (a • x + b • y) j =
        a * (∑ j : Fin K, x j) + b * (∑ j : Fin K, y j) := by
      calc ∑ j : Fin K, (a • x + b • y) j
          = ∑ j : Fin K, (a * x j + b * y j) := rfl
        _ = (∑ j : Fin K, a * x j) + ∑ j : Fin K, b * y j := Finset.sum_add_distrib
        _ = a * (∑ j : Fin K, x j) + b * (∑ j : Fin K, y j) := by
              rw [← Finset.mul_sum, ← Finset.mul_sum]
    rw [h, hx.2, hy.2]
    linarith

private lemma simplex_isClosed (K : ℕ) : IsClosed (Simplex K) := by
  have hEq : Simplex K =
      (⋂ j : Fin K, {q : EuclideanSpace ℝ (Fin K) | 0 ≤ q j}) ∩
      {q : EuclideanSpace ℝ (Fin K) | ∑ j : Fin K, q j = 1} := by
    ext q
    simp [Simplex]
  rw [hEq]
  refine IsClosed.inter ?_ ?_
  · exact isClosed_iInter (fun j => isClosed_le continuous_const (EuclideanSpace.proj j).continuous)
  · exact isClosed_eq
      (continuous_finset_sum Finset.univ (fun j _ => (EuclideanSpace.proj j).continuous))
      continuous_const

lemma simplex_isCompact (K : ℕ) : IsCompact (Simplex K) := by
  rw [Metric.isCompact_iff_isClosed_bounded]
  refine ⟨simplex_isClosed K, ?_⟩
  rw [isBounded_iff_forall_norm_le]
  exact ⟨1, fun q hq => norm_le_one_of_mem_simplex hq⟩

lemma eq_uniformVec_of_mem_simplex_one {q : EuclideanSpace ℝ (Fin 1)}
    (hq : q ∈ Simplex 1) : q = uniformVec 1 := by
  have hq0 : q 0 = 1 := by simpa [Fin.sum_univ_one] using hq.2
  have hu0 : uniformVec 1 0 = 1 := by
    change ((1 : ℝ) / ((1 : ℕ) : ℝ)) * onesVec 1 0 = 1
    simp [onesVec_apply]
  ext i
  rw [Fin.eq_zero i, hq0, hu0]

lemma zeroSumSubspace_one_coe_eq_zero (s : ZeroSumSubspace 1) :
    (s : EuclideanSpace ℝ (Fin 1)) = 0 := by
  have hs : inner ℝ (onesVec 1) (s : EuclideanSpace ℝ (Fin 1)) = 0 :=
    (mem_zeroSumSubspace_iff _).mp s.2
  rw [inner_onesVec_eq_sum, Fin.sum_univ_one] at hs
  ext i
  rw [Fin.eq_zero i]
  exact hs

private lemma const_mem_lipschitzSimplexMaps {K : ℕ} {B : ℝ} (hB : 0 ≤ B)
    {q : EuclideanSpace ℝ (Fin K)} (hq : q ∈ Simplex K) :
    (fun _ : ZeroSumSubspace K => q) ∈ LipschitzSimplexMaps K B := by
  refine ⟨hB, ?_, fun _ => hq⟩
  rw [lipschitzWith_iff_dist_le_mul]
  intro x y
  rw [dist_self]
  positivity

private lemma exists_subseq_tendsto_pointwise {K : ℕ} {B : ℝ}
    {ρ_seq : ℕ → ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (h_mem : ∀ n, ρ_seq n ∈ LipschitzSimplexMaps K B) :
    ∃ (ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)) (φ : ℕ → ℕ),
      ρ ∈ LipschitzSimplexMaps K B ∧ StrictMono φ ∧
      ∀ s : ZeroSumSubspace K,
        Filter.Tendsto (fun k => ρ_seq (φ k) s) Filter.atTop (nhds (ρ s)) := by
  have hB0 : 0 ≤ B := (h_mem 0).1
  let d : ℕ → ZeroSumSubspace K := TopologicalSpace.denseSeq (ZeroSumSubspace K)
  have hd : DenseRange d := TopologicalSpace.denseRange_denseSeq (ZeroSumSubspace K)
  let P : Set (ℕ → EuclideanSpace ℝ (Fin K)) := {x | ∀ m : ℕ, x m ∈ Simplex K}
  have hP_compact : IsCompact P := isCompact_pi_infinite (fun _ => simplex_isCompact K)
  have hP_seq : IsSeqCompact P := hP_compact.isSeqCompact
  let g : ℕ → (ℕ → EuclideanSpace ℝ (Fin K)) := fun n m => ρ_seq n (d m)
  have hg_mem : ∀ n, g n ∈ P := fun n m => (h_mem n).2.2 (d m)
  obtain ⟨L, _, φ, hφ_mono, hφ_lim⟩ := hP_seq hg_mem
  have hφ_coord : ∀ m : ℕ,
      Filter.Tendsto (fun k => ρ_seq (φ k) (d m)) Filter.atTop (nhds (L m)) :=
    tendsto_pi_nhds.mp hφ_lim
  have h_cauchy : ∀ s : ZeroSumSubspace K, CauchySeq (fun k => ρ_seq (φ k) s) := by
    intro s
    rw [Metric.cauchySeq_iff]
    intro ε hε
    have hB1_pos : 0 < B + 1 := by linarith
    have h3B1_pos : 0 < 3 * (B + 1) := by linarith
    let δ : ℝ := ε / (3 * (B + 1))
    have hδ : 0 < δ := div_pos hε h3B1_pos
    obtain ⟨m₀, hm₀⟩ := Metric.denseRange_iff.mp hd s δ hδ
    have hdm : dist s (d m₀) < δ := by simpa [dist_comm] using hm₀
    obtain ⟨N, hN⟩ := Metric.cauchySeq_iff.mp (hφ_coord m₀).cauchySeq (ε / 3) (by linarith)
    refine ⟨N, fun k hk j hj => ?_⟩
    have hlip_k : dist (ρ_seq (φ k) s) (ρ_seq (φ k) (d m₀)) ≤ B * dist s (d m₀) := by
      have h := lipschitzWith_iff_dist_le_mul.mp (h_mem (φ k)).2.1 s (d m₀)
      rw [Real.coe_toNNReal B hB0] at h
      exact h
    have hlip_j : dist (ρ_seq (φ j) (d m₀)) (ρ_seq (φ j) s) ≤ B * dist s (d m₀) := by
      rw [dist_comm s (d m₀)]
      have h := lipschitzWith_iff_dist_le_mul.mp (h_mem (φ j)).2.1 (d m₀) s
      rw [Real.coe_toNNReal B hB0] at h
      exact h
    have hB_bound : B * dist s (d m₀) ≤ ε / 3 := by
      have h1 : B * dist s (d m₀) ≤ (B + 1) * δ := by
        calc B * dist s (d m₀)
            ≤ (B + 1) * dist s (d m₀) := by nlinarith [dist_nonneg (x := s) (y := d m₀)]
          _ ≤ (B + 1) * δ := by nlinarith
      have h2 : (B + 1) * δ = ε / 3 := by
        dsimp [δ]
        field_simp
      linarith
    have hmid : dist (ρ_seq (φ k) (d m₀)) (ρ_seq (φ j) (d m₀)) < ε / 3 := hN k hk j hj
    have htri1 := dist_triangle (ρ_seq (φ k) s) (ρ_seq (φ k) (d m₀)) (ρ_seq (φ j) s)
    have htri2 := dist_triangle (ρ_seq (φ k) (d m₀)) (ρ_seq (φ j) (d m₀)) (ρ_seq (φ j) s)
    linarith
  have h_conv : ∀ s : ZeroSumSubspace K,
      ∃ y : EuclideanSpace ℝ (Fin K),
        Filter.Tendsto (fun k => ρ_seq (φ k) s) Filter.atTop (nhds y) :=
    fun s => cauchySeq_tendsto_of_complete (h_cauchy s)
  let ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) :=
    fun s => Classical.choose (h_conv s)
  have hρ_lim : ∀ s : ZeroSumSubspace K,
      Filter.Tendsto (fun k => ρ_seq (φ k) s) Filter.atTop (nhds (ρ s)) :=
    fun s => Classical.choose_spec (h_conv s)
  refine ⟨ρ, φ, ⟨hB0, ?_, ?_⟩, hφ_mono, hρ_lim⟩
  · rw [lipschitzWith_iff_dist_le_mul]
    intro s₁ s₂
    have hdist_lim : Filter.Tendsto
        (fun k => dist (ρ_seq (φ k) s₁) (ρ_seq (φ k) s₂))
        Filter.atTop (nhds (dist (ρ s₁) (ρ s₂))) :=
      Filter.Tendsto.dist (hρ_lim s₁) (hρ_lim s₂)
    exact le_of_tendsto hdist_lim (Filter.Eventually.of_forall fun k =>
      lipschitzWith_iff_dist_le_mul.mp (h_mem (φ k)).2.1 s₁ s₂)
  · intro s
    exact (simplex_isClosed K).mem_of_tendsto (hρ_lim s)
      (Filter.Eventually.of_forall fun k => (h_mem (φ k)).2.2 s)

private lemma exists_isLipschitzLSFitProfile {Ω : Type u} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ]
    {K : ℕ} (hK : 1 ≤ K) {B : ℝ} (hB : 0 < B)
    {S : Ω → ZeroSumSubspace K} {Y : Ω → Fin K}
    (hS : Measurable S) (hY : Measurable Y) :
    ∃ ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K),
      IsLipschitzLSFitProfile μ B S Y ρ := by
  let M := LipschitzSimplexMaps K B
  let R : Set ℝ := lsFitRisk μ S Y '' M
  have hρ₀ : (fun _ : ZeroSumSubspace K => uniformVec K) ∈ M :=
    const_mem_lipschitzSimplexMaps hB.le (uniformVec_mem_simplex hK)
  have hR_ne : R.Nonempty := ⟨lsFitRisk μ S Y (fun _ => uniformVec K), _, hρ₀, rfl⟩
  have hR_bdd : BddBelow R := by
    refine ⟨0, ?_⟩
    rintro r ⟨ρ', _, rfl⟩
    exact integral_nonneg (fun _ => sq_nonneg _)
  let I : ℝ := sInf R
  have hex_seq : ∀ n : ℕ, ∃ ρ' ∈ M, lsFitRisk μ S Y ρ' < I + 1 / ((n : ℝ) + 1) := by
    intro n
    have hlt : I < I + 1 / ((n : ℝ) + 1) := by
      have hpos : (0 : ℝ) < 1 / ((n : ℝ) + 1) := by positivity
      linarith
    obtain ⟨r, ⟨ρ', hρ', rfl⟩, hr_lt⟩ := exists_lt_of_csInf_lt hR_ne hlt
    exact ⟨ρ', hρ', hr_lt⟩
  choose ρ_seq hρ_mem hρ_lt using hex_seq
  obtain ⟨ρ, φ, hρ_in, hφ_mono, hρ_lim⟩ := exists_subseq_tendsto_pointwise hρ_mem
  have hZ_meas : Measurable (oneHotLabel Y) := oneHotLabel_measurable hY
  have h_tendsto_risk : Filter.Tendsto (fun k => lsFitRisk μ S Y (ρ_seq (φ k)))
      Filter.atTop (nhds (lsFitRisk μ S Y ρ)) := by
    unfold lsFitRisk
    refine tendsto_integral_of_dominated_convergence (fun _ => (4 : ℝ)) ?_ ?_ ?_ ?_
    · intro k
      have h_comp : Measurable (fun ω => ρ_seq (φ k) (S ω)) :=
        (hρ_mem (φ k)).2.1.continuous.measurable.comp hS
      exact ((h_comp.sub hZ_meas).norm.pow_const 2).aestronglyMeasurable
    · exact integrable_const (4 : ℝ)
    · intro k
      refine Filter.Eventually.of_forall (fun ω => ?_)
      rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
      have hsub : ‖ρ_seq (φ k) (S ω) - oneHotLabel Y ω‖ ≤ 2 := by
        calc ‖ρ_seq (φ k) (S ω) - oneHotLabel Y ω‖
            ≤ ‖ρ_seq (φ k) (S ω)‖ + ‖oneHotLabel Y ω‖ := norm_sub_le _ _
          _ ≤ 1 + 1 := add_le_add
              (norm_le_one_of_mem_simplex ((hρ_mem (φ k)).2.2 (S ω)))
              (norm_le_one_of_mem_simplex (oneHotLabel_mem_simplex Y ω))
          _ = 2 := by norm_num
      have hnn : 0 ≤ ‖ρ_seq (φ k) (S ω) - oneHotLabel Y ω‖ := norm_nonneg _
      nlinarith
    · refine Filter.Eventually.of_forall (fun ω => ?_)
      exact (((hρ_lim (S ω)).sub tendsto_const_nhds).norm).pow 2
  have h0 : Filter.Tendsto (fun k => (1 : ℝ) / ((φ k : ℝ) + 1)) Filter.atTop (nhds 0) :=
    tendsto_one_div_add_atTop_nhds_zero_nat.comp hφ_mono.tendsto_atTop
  have h_tendsto_upper : Filter.Tendsto (fun k => I + 1 / ((φ k : ℝ) + 1))
      Filter.atTop (nhds I) := by
    simpa using (tendsto_const_nhds (x := I)).add h0
  have h_le_I : lsFitRisk μ S Y ρ ≤ I :=
    le_of_tendsto_of_tendsto h_tendsto_risk h_tendsto_upper
      (Filter.Eventually.of_forall (fun k => (hρ_lt (φ k)).le))
  refine ⟨ρ, hB, hρ_in, fun ρ' hρ' => ?_⟩
  exact le_trans h_le_I (csInf_le hR_bdd ⟨ρ', hρ', rfl⟩)

lemma linearFittedPrediction_spec {Ω : Type u} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ]
    {d K : ℕ} (hK : 1 ≤ K) {B : ℝ} (hB : 0 < B)
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
    {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin K}
    (hX : Measurable X) (hY : Measurable Y) :
    ∃ ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K),
      IsLipschitzLSFitProfile μ B (linearScore W X) Y ρ ∧
      linearFittedPrediction μ B W X Y = fun ω => ρ (W (X ω)) := by
  have hS : Measurable (linearScore W X) := W.continuous.measurable.comp hX
  obtain ⟨ρ₀, hρ₀⟩ := exists_isLipschitzLSFitProfile μ hK hB hS hY
  have hex : ∃ P, IsLipschitzLSFit μ B (linearScore W X) Y P :=
    ⟨fun ω => ρ₀ (linearScore W X ω), ρ₀, hρ₀, rfl⟩
  obtain ⟨ρ, hρ_prof, hP_eq⟩ := Classical.choose_spec hex
  refine ⟨ρ, hρ_prof, ?_⟩
  unfold linearFittedPrediction fittedPrediction
  rw [dif_pos hex, hP_eq]
  rfl

private abbrev SampleSpace (K : ℕ) : Type v :=
  ULift.{v} (ZeroSumSubspace K × Fin K)

private def liftSample {Ω : Type u} {K : ℕ}
    (S : Ω → ZeroSumSubspace K) (Y : Ω → Fin K) (ω : Ω) : SampleSpace.{v} K :=
  ULift.up (S ω, Y ω)

private def fstScore {K : ℕ} (z : SampleSpace.{v} K) : ZeroSumSubspace K :=
  z.down.1

private def sndLabel {K : ℕ} (z : SampleSpace.{v} K) : Fin K :=
  z.down.2

private lemma liftSample_measurable {Ω : Type u} [MeasurableSpace Ω] {K : ℕ}
    {S : Ω → ZeroSumSubspace K} {Y : Ω → Fin K}
    (hS : Measurable S) (hY : Measurable Y) :
    Measurable (liftSample.{u, v} S Y) :=
  measurable_up.comp (hS.prodMk hY)

private lemma fstScore_measurable {K : ℕ} : Measurable (fstScore.{v} (K := K)) :=
  measurable_fst.comp measurable_down

private lemma sndLabel_measurable {K : ℕ} : Measurable (sndLabel.{v} (K := K)) :=
  measurable_snd.comp measurable_down

private lemma lsFitRisk_map_liftSample {Ω : Type u} [MeasurableSpace Ω] (μ : Measure Ω)
    {K : ℕ} {B : ℝ} {S : Ω → ZeroSumSubspace K} {Y : Ω → Fin K}
    (hS : Measurable S) (hY : Measurable Y)
    {ρ' : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hρ' : ρ' ∈ LipschitzSimplexMaps K B) :
    lsFitRisk (Measure.map (liftSample.{u, v} S Y) μ) fstScore sndLabel ρ' =
      lsFitRisk μ S Y ρ' := by
  have hπ : Measurable (liftSample.{u, v} S Y) := liftSample_measurable hS hY
  have hg : Measurable (fun z : SampleSpace.{v} K =>
      ‖ρ' (fstScore z) - oneHotLabel sndLabel z‖ ^ 2) :=
    (((hρ'.2.1.continuous.measurable.comp fstScore_measurable).sub
      (oneHotLabel_measurable sndLabel_measurable)).norm.pow_const 2)
  unfold lsFitRisk
  exact integral_map hπ.aemeasurable hg.aestronglyMeasurable

private lemma isLipschitzLSFit_map_liftSample {Ω : Type u} [MeasurableSpace Ω] (μ : Measure Ω)
    {K : ℕ} {B : ℝ} {S : Ω → ZeroSumSubspace K} {Y : Ω → Fin K}
    (hS : Measurable S) (hY : Measurable Y)
    {ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hProf : IsLipschitzLSFitProfile μ B S Y ρ) :
    IsLipschitzLSFit (Measure.map (liftSample.{u, v} S Y) μ) B fstScore sndLabel
      (fun z => ρ (fstScore z)) := by
  refine ⟨ρ, ⟨hProf.1, hProf.2.1, fun ρ' hρ' => ?_⟩, rfl⟩
  change lsFitRisk (Measure.map (liftSample.{u, v} S Y) μ) fstScore sndLabel ρ ≤
    lsFitRisk (Measure.map (liftSample.{u, v} S Y) μ) fstScore sndLabel ρ'
  rw [lsFitRisk_map_liftSample μ hS hY hProf.2.1, lsFitRisk_map_liftSample μ hS hY hρ']
  exact hProf.2.2 hρ'

private lemma integral_grad_map_liftSample {Ω : Type u} [MeasurableSpace Ω] (μ : Measure Ω)
    {K : ℕ} {S : Ω → ZeroSumSubspace K} {Y : Ω → Fin K}
    (hS : Measurable S) (hY : Measurable Y)
    {ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)} (hρ_cont : Continuous ρ)
    (f : ZeroSumSubspace K → ℝ) {L : NNReal} (hL : LipschitzWith L (gradient f)) :
    ∫ z, inner ℝ (fitResidual (fun z => ρ (fstScore z)) sndLabel z)
        (↑(gradient f ((ZeroSumSubspace K).orthogonalProjection
          (ρ (fstScore z) - uniformVec K))) : EuclideanSpace ℝ (Fin K))
      ∂Measure.map (liftSample.{u, v} S Y) μ =
    ∫ ω, inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω)
        (↑(gradient f ((ZeroSumSubspace K).orthogonalProjection
          (ρ (S ω) - uniformVec K))) : EuclideanSpace ℝ (Fin K)) ∂μ := by
  have hπ : Measurable (liftSample.{u, v} S Y) := liftSample_measurable hS hY
  have hP_v : Measurable (fun z : SampleSpace.{v} K => ρ (fstScore z)) :=
    hρ_cont.measurable.comp fstScore_measurable
  have hr_v : Measurable (fitResidual (fun z : SampleSpace.{v} K => ρ (fstScore z)) sndLabel) :=
    hP_v.sub (oneHotLabel_measurable sndLabel_measurable)
  have hgrad_v : Measurable (fun z : SampleSpace.{v} K =>
      (↑(gradient f ((ZeroSumSubspace K).orthogonalProjection
        (ρ (fstScore z) - uniformVec K))) : EuclideanSpace ℝ (Fin K))) :=
    continuous_subtype_val.measurable.comp
      (hL.continuous.measurable.comp
        ((ZeroSumSubspace K).orthogonalProjection.continuous.measurable.comp
          (hP_v.sub measurable_const)))
  exact integral_map hπ.aemeasurable (hr_v.inner hgrad_v).aestronglyMeasurable

lemma apply_lem_A_3 (h_lem_A_3 : S_lem_A_3.{v})
    {Ω : Type u} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    {K : ℕ} (hK : 2 ≤ K) {B : ℝ} (hB : 0 < B)
    {S : Ω → ZeroSumSubspace K} {Y : Ω → Fin K}
    (hS : Measurable S) (hY : Measurable Y)
    {ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hProf : IsLipschitzLSFitProfile μ B S Y ρ) :
    ∀ j : Fin K, ∀ᵐ ω ∂μ, ρ (S ω) j = 0 → oneHotLabel Y ω j = 0 := by
  let π := liftSample.{u, v} S Y
  have hπ : Measurable π := liftSample_measurable hS hY
  let μ_v : Measure (SampleSpace.{v} K) := Measure.map π μ
  haveI : IsProbabilityMeasure μ_v := Measure.isProbabilityMeasure_map hπ.aemeasurable
  have hFit_v : IsLipschitzLSFit μ_v B fstScore sndLabel (fun z => ρ (fstScore z)) :=
    isLipschitzLSFit_map_liftSample μ hS hY hProf
  have hA3 := (h_lem_A_3 (SampleSpace.{v} K) μ_v K hK B hB fstScore sndLabel
    fstScore_measurable sndLabel_measurable (fun z => ρ (fstScore z)) hFit_v).1
  intro j
  exact ae_of_ae_map hπ.aemeasurable (hA3 j)

lemma apply_lem_A_4 (h_lem_A_4 : S_lem_A_4.{v})
    {Ω : Type u} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    {K : ℕ} {B : ℝ} (hB : 0 < B)
    {S : Ω → ZeroSumSubspace K} {Y : Ω → Fin K}
    (hS_meas : Measurable S) (hS_int : Integrable S μ) (hY : Measurable Y)
    {ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hProf : IsLipschitzLSFitProfile μ B S Y ρ) :
    (∀ (f : ZeroSumSubspace K → ℝ),
      Differentiable ℝ f →
      ConvexOn ℝ Set.univ f →
      (∃ L : NNReal, LipschitzWith L (gradient f)) →
      ∫ ω, inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω)
        (↑(gradient f ((ZeroSumSubspace K).orthogonalProjection (ρ (S ω) - uniformVec K))) :
          EuclideanSpace ℝ (Fin K)) ∂μ ≤ 0) ∧
    (∫ ω, inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω) (ρ (S ω) - uniformVec K) ∂μ ≤
      B * ∫ ω, inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω) (S ω : EuclideanSpace ℝ (Fin K)) ∂μ) := by
  let π := liftSample.{u, v} S Y
  have hπ : Measurable π := liftSample_measurable hS_meas hY
  let μ_v : Measure (SampleSpace.{v} K) := Measure.map π μ
  haveI : IsProbabilityMeasure μ_v := Measure.isProbabilityMeasure_map hπ.aemeasurable
  have hS_v_int : Integrable (fstScore.{v} (K := K)) μ_v :=
    (integrable_map_measure fstScore_measurable.aestronglyMeasurable hπ.aemeasurable).mpr hS_int
  have hFit_v : IsLipschitzLSFit μ_v B fstScore sndLabel (fun z => ρ (fstScore z)) :=
    isLipschitzLSFit_map_liftSample μ hS_meas hY hProf
  obtain ⟨_, hA4_smooth, hA4_corr⟩ := h_lem_A_4 (SampleSpace.{v} K) μ_v K B
    fstScore sndLabel (fun z => ρ (fstScore z)) hB hS_v_int sndLabel_measurable hFit_v
  have hρ_cont : Continuous ρ := hProf.2.1.2.1.continuous
  refine ⟨?_, ?_⟩
  · intro f hf_diff hf_conv hf_lip
    obtain ⟨L, hL⟩ := hf_lip
    rw [← integral_grad_map_liftSample μ hS_meas hY hρ_cont f hL]
    exact hA4_smooth f hf_diff hf_conv ⟨L, hL⟩
  · have hP_v : Measurable (fun z : SampleSpace.{v} K => ρ (fstScore z)) :=
      hρ_cont.measurable.comp fstScore_measurable
    have hr_v : Measurable (fitResidual (fun z : SampleSpace.{v} K => ρ (fstScore z)) sndLabel) :=
      hP_v.sub (oneHotLabel_measurable sndLabel_measurable)
    have hint1 : ∫ z, inner ℝ (fitResidual (fun z => ρ (fstScore z)) sndLabel z)
          (ρ (fstScore z) - uniformVec K) ∂μ_v =
        ∫ ω, inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω) (ρ (S ω) - uniformVec K) ∂μ :=
      integral_map hπ.aemeasurable (hr_v.inner (hP_v.sub measurable_const)).aestronglyMeasurable
    have hint2 : ∫ z, inner ℝ (fitResidual (fun z => ρ (fstScore z)) sndLabel z)
          (fstScore z : EuclideanSpace ℝ (Fin K)) ∂μ_v =
        ∫ ω, inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω) (S ω : EuclideanSpace ℝ (Fin K)) ∂μ :=
      integral_map hπ.aemeasurable
        (hr_v.inner (continuous_subtype_val.measurable.comp fstScore_measurable)).aestronglyMeasurable
    rw [← hint1, ← hint2]
    exact hA4_corr

private lemma posSupport_eq_filter {K : ℕ} (p : EuclideanSpace ℝ (Fin K)) :
    posSupport p = (open Classical in Finset.univ.filter (fun j : Fin K => 0 < p j)) := by
  ext j
  simp [posSupport]

lemma apply_lem_A_5 (h_lem_A_5 : S_lem_A_5.{v})
    {Ω : Type u} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    {K : ℕ} (hK : 2 ≤ K)
    {S : Ω → ZeroSumSubspace K} {Y : Ω → Fin K}
    (hS : Measurable S) (hY : Measurable Y)
    {ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hρ_cont : Continuous ρ) (hρ_simp : ∀ s, ρ s ∈ Simplex K)
    (hsupp : ∀ j : Fin K, ∀ᵐ ω ∂μ, ρ (S ω) j = 0 → oneHotLabel Y ω j = 0)
    (hsmooth : ∀ (f : ZeroSumSubspace K → ℝ),
      Differentiable ℝ f →
      ConvexOn ℝ Set.univ f →
      (∃ L : NNReal, LipschitzWith L (gradient f)) →
      ∫ ω, inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω)
        (↑(gradient f ((ZeroSumSubspace K).orthogonalProjection (ρ (S ω) - uniformVec K))) :
          EuclideanSpace ℝ (Fin K)) ∂μ ≤ 0)
    (F : Simplex K → ℝ)
    (hF_cont : Continuous F)
    (hF_conv : ConvexOn ℝ (Simplex K) (extendSimplex F))
    (hF_diff : ∀ J : Finset (Fin K), J.Nonempty →
      ∀ p ∈ SimplexFaceRelint K J, ∃ g, HasFaceGradAt F J p g) :
    (∫ ω, inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω)
      (faceGrad F (posSupport (ρ (S ω))) (ρ (S ω))) ∂μ ≤ 0) ∧
    Integrable (fun ω => inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω)
      (faceGrad F (posSupport (ρ (S ω))) (ρ (S ω)))) μ := by
  let π := liftSample.{u, v} S Y
  have hπ : Measurable π := liftSample_measurable hS hY
  let μ_v : Measure (SampleSpace.{v} K) := Measure.map π μ
  haveI : IsProbabilityMeasure μ_v := Measure.isProbabilityMeasure_map hπ.aemeasurable
  let P_v : SampleSpace.{v} K → EuclideanSpace ℝ (Fin K) := fun z => ρ (fstScore z)
  have hP_v_meas : Measurable P_v := hρ_cont.measurable.comp fstScore_measurable
  have hsupp_v : ∀ j : Fin K, ∀ᵐ z ∂μ_v, P_v z j = 0 → oneHotLabel sndLabel z j = 0 := by
    intro j
    have hs_eq : {z : SampleSpace.{v} K | P_v z j = 0 → oneHotLabel sndLabel z j = 0} =
        {z | P_v z j = 0}ᶜ ∪ {z | oneHotLabel sndLabel z j = 0} := by
      ext z
      simp [imp_iff_not_or]
    have hs_meas : MeasurableSet
        {z : SampleSpace.{v} K | P_v z j = 0 → oneHotLabel sndLabel z j = 0} := by
      rw [hs_eq]
      have hm1 : MeasurableSet {z : SampleSpace.{v} K | P_v z j = 0} :=
        measurableSet_eq_fun ((EuclideanSpace.proj j).continuous.measurable.comp hP_v_meas)
          measurable_const
      have hm2 : MeasurableSet {z : SampleSpace.{v} K | oneHotLabel sndLabel z j = 0} :=
        measurableSet_eq_fun
          ((EuclideanSpace.proj j).continuous.measurable.comp
            (oneHotLabel_measurable sndLabel_measurable))
          measurable_const
      exact hm1.compl.union hm2
    exact (ae_map_iff hπ.aemeasurable hs_meas).mpr (hsupp j)
  have hsmooth_v : ∀ (f : ZeroSumSubspace K → ℝ),
      Differentiable ℝ f →
      ConvexOn ℝ Set.univ f →
      (∃ L : NNReal, LipschitzWith L (gradient f)) →
      ∫ z, inner ℝ (fitResidual P_v sndLabel z)
        (↑(gradient f ((ZeroSumSubspace K).orthogonalProjection (P_v z - uniformVec K))) :
          EuclideanSpace ℝ (Fin K)) ∂μ_v ≤ 0 := by
    intro f hf_diff hf_conv hf_lip
    obtain ⟨L, hL⟩ := hf_lip
    rw [integral_grad_map_liftSample μ hS hY hρ_cont f hL]
    exact hsmooth f hf_diff hf_conv ⟨L, hL⟩
  obtain ⟨hA5_le, hA5_int⟩ := h_lem_A_5 (SampleSpace.{v} K) μ_v K hK P_v sndLabel
    hP_v_meas sndLabel_measurable (fun z => hρ_simp (fstScore z)) hsupp_v hsmooth_v
    F hF_cont hF_conv hF_diff
  dsimp only at hA5_le hA5_int
  simp_rw [← posSupport_eq_filter] at hA5_le hA5_int
  refine ⟨?_, ?_⟩
  · have hint_eq : ∫ z, inner ℝ (fitResidual P_v sndLabel z)
          (faceGrad F (posSupport (P_v z)) (P_v z)) ∂μ_v =
        ∫ ω, inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω)
          (faceGrad F (posSupport (ρ (S ω))) (ρ (S ω))) ∂μ :=
      integral_map hπ.aemeasurable hA5_int.aestronglyMeasurable
    linarith
  · exact hA5_int.comp_measurable hπ

end UL.Proof_lem_A_6

import UL.Stmt.cor_A_8
import UL.Stmt.cit_brouwer
import UL.Stmt.lem_A_1
import UL.Stmt.lem_A_2
import UL.Stmt.lem_A_3
import UL.Stmt.lem_A_4
import UL.Stmt.lem_A_5
import UL.Stmt.lem_A_6
import UL.Stmt.thm_A_7
import UL.Proof.cor_A_8.H2_RiskBound
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_cor_A_8 (h_cit_brouwer : S_cit_brouwer) (h_lem_A_1 : S_lem_A_1) (h_lem_A_2 : S_lem_A_2) (h_lem_A_3 : S_lem_A_3) (h_lem_A_4 : S_lem_A_4) (h_lem_A_5 : S_lem_A_5) (h_lem_A_6 : S_lem_A_6) (h_thm_A_7 : S_thm_A_7) : S_cor_A_8 := by
  have _ : S_cit_brouwer ∧ S_lem_A_2 ∧ S_lem_A_6 ∧ S_thm_A_7 :=
    ⟨h_cit_brouwer, h_lem_A_2, h_lem_A_6, h_thm_A_7⟩
  unfold S_cor_A_8
  intro Ω _ μ _ d K hK β hβ X Y hX hY hX_int 𝒲 h𝒲 W hW ρ hρ hΓ Φ hΦ
  dsimp only
  let P : Ω → EuclideanSpace ℝ (Fin K) := fun ω => ρ (W (X ω))
  let p_δ : ℝ → EuclideanSpace ℝ (Fin K) → EuclideanSpace ℝ (Fin K) :=
    fun δ p => (1 - δ) • p + δ • uniformVec K
  let kΦδ : ℝ → EuclideanSpace ℝ (Fin K) → EuclideanSpace ℝ (Fin K) :=
    fun δ p => simplexGrad Φ (p_δ δ p)
  let jensenGap : (Simplex K → ℝ) → ℝ → ℝ :=
    fun Ψ δ => sSup ((fun p =>
      (1 - δ) * extendSimplex Ψ p + δ * extendSimplex Ψ (uniformVec K) -
        extendSimplex Ψ (p_δ δ p)) '' Simplex K)
  let JΦ : ℝ → ℝ := jensenGap Φ
  have h_part1 : ∀ δ ∈ Set.Ioo (0 : ℝ) 1,
      (∀ p ∈ Simplex K, kΦδ δ p ∈ ZeroSumSubspace K) ∧
      ContinuousOn (kΦδ δ) (Simplex K) ∧
      Bornology.IsBounded (kΦδ δ '' Simplex K) ∧
      MeasureTheory.Integrable (fun ω => matchingLoss Φ (kΦδ δ (P ω)) (Y ω)) μ ∧
      (∀ V ∈ 𝒲, MeasureTheory.Integrable (fun ω => matchingLoss Φ (V (X ω)) (Y ω)) μ) ∧
      BddBelow ((fun V => ∫ ω, matchingLoss Φ (V (X ω)) (Y ω) ∂μ) '' 𝒲) ∧
      (∫ ω, matchingLoss Φ (kΦδ δ (P ω)) (Y ω) ∂μ) ≤
        sInf ((fun V => ∫ ω, matchingLoss Φ (V (X ω)) (Y ω) ∂μ) '' 𝒲) +
          JΦ δ / (1 - δ) + δ * (1 - 1 / (K : ℝ)) / (4 * β) := by
    intro δ hδ
    obtain ⟨hk_zs, hk_cont, hk_bdd⟩ := Proof_cor_A_8.kΦδ_properties hK hΦ hδ
    obtain ⟨h_int_k, h_int_V, h_bdd_V, h_ineq⟩ :=
      Proof_cor_A_8.smoothing_bound_all h_lem_A_1 h_lem_A_3 h_lem_A_4 h_lem_A_5
        hK hβ hX hY hX_int h𝒲 hW hρ hΓ hΦ hδ
    exact ⟨hk_zs, hk_cont, hk_bdd, h_int_k, h_int_V, h_bdd_V, h_ineq⟩
  have h_part2 : Filter.Tendsto JΦ (nhdsWithin 0 (Set.Ioi 0)) (nhds 0) :=
    Proof_cor_A_8.tendsto_jensenGap hK hΦ.2.1
  have h_part3 : ∀ (A : EuclideanSpace ℝ (Fin K) →ᵃ[ℝ] ℝ), ∀ δ ∈ Set.Ioo (0 : ℝ) 1,
      jensenGap (fun q => Φ q + A q.1) δ = JΦ δ :=
    fun A δ hδ => Proof_cor_A_8.jensenGap_affine_invariant hK Φ A hδ
  have h_part4 : ∀ ε : ℝ, 0 < ε →
      ∃ δ ∈ Set.Ioo (0 : ℝ) 1,
        (∫ ω, matchingLoss Φ (kΦδ δ (P ω)) (Y ω) ∂μ) ≤
          sInf ((fun V => ∫ ω, matchingLoss Φ (V (X ω)) (Y ω) ∂μ) '' 𝒲) + ε := by
    intro ε hε
    let E : ℝ → ℝ := fun δ => JΦ δ / (1 - δ) + δ * (1 - 1 / (K : ℝ)) / (4 * β)
    have h_id : Filter.Tendsto (fun δ : ℝ => δ) (nhdsWithin 0 (Set.Ioi 0)) (nhds 0) :=
      tendsto_nhdsWithin_of_tendsto_nhds Filter.tendsto_id
    have h_1d : Filter.Tendsto (fun δ : ℝ => 1 - δ) (nhdsWithin 0 (Set.Ioi 0)) (nhds 1) := by
      simpa using tendsto_const_nhds.sub h_id
    have h_div1 : Filter.Tendsto (fun δ : ℝ => JΦ δ / (1 - δ))
        (nhdsWithin 0 (Set.Ioi 0)) (nhds 0) := by
      simpa using h_part2.div h_1d one_ne_zero
    have h_div2 : Filter.Tendsto (fun δ : ℝ => δ * (1 - 1 / (K : ℝ)) / (4 * β))
        (nhdsWithin 0 (Set.Ioi 0)) (nhds 0) := by
      have h1 := (h_id.mul_const (1 - 1 / (K : ℝ))).div_const (4 * β)
      simpa using h1
    have hE_lim : Filter.Tendsto E (nhdsWithin 0 (Set.Ioi 0)) (nhds 0) := by
      simpa [E] using h_div1.add h_div2
    have h_ev1 : ∀ᶠ δ in nhdsWithin (0 : ℝ) (Set.Ioi 0), E δ < ε :=
      hE_lim.eventually (Iio_mem_nhds hε)
    have h_ev2 : ∀ᶠ δ in nhdsWithin (0 : ℝ) (Set.Ioi 0), δ ∈ Set.Ioo (0 : ℝ) 1 :=
      Ioo_mem_nhdsGT zero_lt_one
    have h_ev : ∀ᶠ δ in nhdsWithin (0 : ℝ) (Set.Ioi 0), δ ∈ Set.Ioo (0 : ℝ) 1 ∧ E δ < ε :=
      h_ev2.and h_ev1
    haveI : Filter.NeBot (nhdsWithin (0 : ℝ) (Set.Ioi 0)) := nhdsWithin_Ioi_neBot (le_refl 0)
    obtain ⟨δ, hδ_mem, hE_lt⟩ := h_ev.exists
    refine ⟨δ, hδ_mem, ?_⟩
    have h_bound := (h_part1 δ hδ_mem).2.2.2.2.2.2
    dsimp [E] at hE_lt
    linarith
  exact ⟨h_part1, h_part2, h_part3, h_part4⟩

end UL

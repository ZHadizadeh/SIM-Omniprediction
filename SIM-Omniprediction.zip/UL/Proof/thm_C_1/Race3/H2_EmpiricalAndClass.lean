import Mathlib
import UL.Def.def_2_1
import UL.Def.def_2_matching
import UL.Def.def_5_smooth
import UL.Def.def_C_profiles
import UL.Stmt.lem_C_2
import UL.Stmt.lem_C_4
import UL.Proof.lem_C_2.H1_HilbertSchmidt
import UL.Proof.lem_C_2.H2_SmoothEntropy
import UL.Proof.cor_A_8.H1_SimplexGrad
import UL.Proof.cor_A_8.H2_RiskBound
import UL.Proof.thm_C_1.Race3.H1_UniverseTransfer
set_option autoImplicit false

namespace UL.Proof_thm_C_1_Race3

open MeasureTheory

/-! ### Dimension and isometric identification of `ZeroSumSubspace K` -/

lemma finrank_zeroSumSubspace {K : ℕ} (hK : 2 ≤ K) :
    Module.finrank ℝ (UL.ZeroSumSubspace K) = K - 1 := by
  let φ : EuclideanSpace ℝ (Fin K) →ₗ[ℝ] ℝ := (innerSL ℝ (UL.onesVec K)).toLinearMap
  have hker : UL.ZeroSumSubspace K = LinearMap.ker φ := rfl
  have hrn := LinearMap.finrank_range_add_finrank_ker φ
  have hdimE : Module.finrank ℝ (EuclideanSpace ℝ (Fin K)) = K :=
    finrank_euclideanSpace_fin
  have hrange : LinearMap.range φ = ⊤ := by
    rw [LinearMap.range_eq_top]
    intro r
    refine ⟨r • UL.uniformVec K, ?_⟩
    have hu : inner ℝ (UL.onesVec K) (UL.uniformVec K) = 1 :=
      UL.Proof_lem_A_4.inner_onesVec_of_mem_simplex
        (UL.Proof_lem_A_4.uniformVec_mem_simplex (by omega))
    change inner ℝ (UL.onesVec K) (r • UL.uniformVec K) = r
    rw [inner_smul_right, hu, mul_one]
  rw [hrange, finrank_top, Module.finrank_self, ← hker, hdimE] at hrn
  omega

noncomputable def isoZeroSum {K : ℕ} (hK : 2 ≤ K) :
    UL.ZeroSumSubspace K ≃ₗᵢ[ℝ] EuclideanSpace ℝ (Fin (K - 1)) :=
  ((stdOrthonormalBasis ℝ (UL.ZeroSumSubspace K)).reindex
    (finCongr (finrank_zeroSumSubspace hK))).repr

/-! ### Smooth entropy parameter bound `1 ≤ B * lam` -/

lemma one_le_B_mul_lam_of_mem {K : ℕ} (hK : 2 ≤ K) {β B lam M : ℝ}
    (hβ : 0 < β) (hB : β ≤ B) {Φ : UL.Simplex K → ℝ}
    (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M) :
    1 ≤ B * lam := by
  have hlam : 0 < lam := hΦ.2.1
  let i₀ : Fin K := ⟨0, by omega⟩
  let i₁ : Fin K := ⟨1, by omega⟩
  have hne : i₀ ≠ i₁ := by
    intro h
    have : (0 : ℕ) = 1 := congrArg Fin.val h
    omega
  let p : EuclideanSpace ℝ (Fin K) := EuclideanSpace.single i₀ (1 : ℝ)
  let q : EuclideanSpace ℝ (Fin K) := EuclideanSpace.single i₁ (1 : ℝ)
  have hp : p ∈ UL.Simplex K := by
    refine ⟨fun j => ?_, ?_⟩
    · simp only [p, EuclideanSpace.single_apply]
      split_ifs <;> norm_num
    · simp [p, EuclideanSpace.single_apply]
  have hq : q ∈ UL.Simplex K := by
    refine ⟨fun j => ?_, ?_⟩
    · simp only [q, EuclideanSpace.single_apply]
      split_ifs <;> norm_num
    · simp [q, EuclideanSpace.single_apply]
  have hpq_ne : p ≠ q := by
    intro h
    have h0 : p i₀ = q i₀ := congrArg (fun v => v i₀) h
    simp [p, q, EuclideanSpace.single_apply, hne] at h0
  have hnorm_pos : 0 < ‖p - q‖ := norm_pos_iff.mpr (sub_ne_zero.mpr hpq_ne)
  have hmono := UL.Proof_lem_C_2.gJSimplex_monotone hβ (le_refl β) hΦ hp hq
  have hdiff :
      UL.Proof_lem_C_2.gJSimplex Φ β p - UL.Proof_lem_C_2.gJSimplex Φ β q =
        (UL.simplexGrad Φ p - UL.simplexGrad Φ q) - (1 / β) • (p - q) := by
    unfold UL.Proof_lem_C_2.gJSimplex
    rw [smul_sub, smul_sub, smul_sub]
    abel
  rw [hdiff, inner_sub_left, inner_smul_left, conj_trivial, real_inner_self_eq_norm_sq] at hmono
  have hcs : inner ℝ (UL.simplexGrad Φ p - UL.simplexGrad Φ q) (p - q) ≤
      lam * ‖p - q‖ ^ 2 := by
    calc inner ℝ (UL.simplexGrad Φ p - UL.simplexGrad Φ q) (p - q)
        ≤ ‖UL.simplexGrad Φ p - UL.simplexGrad Φ q‖ * ‖p - q‖ := real_inner_le_norm _ _
      _ ≤ (lam * ‖p - q‖) * ‖p - q‖ :=
          mul_le_mul_of_nonneg_right (hΦ.2.2.2.2.1 p hp q hq) hnorm_pos.le
      _ = lam * ‖p - q‖ ^ 2 := by ring
  have hsq_pos : 0 < ‖p - q‖ ^ 2 := sq_pos_of_pos hnorm_pos
  have h1b_le_lam : 1 / β ≤ lam := by nlinarith
  have h1_le_blam : 1 ≤ β * lam := by
    have hmul := mul_le_mul_of_nonneg_left h1b_le_lam hβ.le
    have hcancel : β * (1 / β) = 1 := by field_simp [hβ.ne']
    linarith
  have hblam_le_Blam : β * lam ≤ B * lam := mul_le_mul_of_nonneg_right hB hlam.le
  linarith

/-! ### Empirical fixed-point learner from Lemma C.2 and Lemma C.4 -/

theorem exists_empirical_learner.{u}
    (h_lem_C_2 : UL.S_lem_C_2.{u})
    (h_lem_C_4 : UL.S_lem_C_4)
    {K : ℕ} (hK : 2 ≤ K)
    (X : Type u) [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {n : ℕ} (hn : 1 ≤ n)
    {L R β B lam M : ℝ}
    (hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) (hB : β ≤ B)
    (hlam : 0 < lam) (hM : 0 < M) :
    ∃ (learnerW : (Fin n → X × Fin K) → (X →L[ℝ] UL.ZeroSumSubspace K))
      (learnerRho : (Fin n → X × Fin K) → (UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K))),
      (∀ sample : Fin n → X × Fin K,
        UL.hilbertSchmidtNorm (learnerW sample) ≤ R ∧
        (∀ s : UL.ZeroSumSubspace K, learnerRho sample s ∈ UL.Simplex K) ∧
        LipschitzWith (Real.toNNReal B) (learnerRho sample)) ∧
      (∀ sample : Fin n → X × Fin K,
        (∀ i : Fin n, ‖(sample i).1‖ ≤ L) →
        ∀ Φ ∈ UL.SmoothEntropyFamily K β lam M,
        ∀ V : X →L[ℝ] UL.ZeroSumSubspace K, UL.hilbertSchmidtNorm V ≤ R →
          (1 / (n : ℝ)) * ∑ i : Fin n,
              UL.finiteCanonicalLoss Φ
                (learnerRho sample (learnerW sample (sample i).1)) (sample i).2 ≤
            (1 / (n : ℝ)) * ∑ i : Fin n,
              UL.matchingLoss Φ
                ((V (sample i).1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
                (sample i).2) := by
  classical
  have hB_pos : 0 < B := lt_of_lt_of_le hβ hB
  have h_pointwise : ∀ sample : Fin n → X × Fin K,
      ∃ (W : X →L[ℝ] UL.ZeroSumSubspace K)
        (ρ : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)),
        (UL.hilbertSchmidtNorm W ≤ R ∧
          (∀ s : UL.ZeroSumSubspace K, ρ s ∈ UL.Simplex K) ∧
          LipschitzWith (Real.toNNReal B) ρ) ∧
        ((∀ i : Fin n, ‖(sample i).1‖ ≤ L) →
          ∀ Φ ∈ UL.SmoothEntropyFamily K β lam M,
          ∀ V : X →L[ℝ] UL.ZeroSumSubspace K, UL.hilbertSchmidtNorm V ≤ R →
            (1 / (n : ℝ)) * ∑ i : Fin n,
                UL.finiteCanonicalLoss Φ (ρ (W (sample i).1)) (sample i).2 ≤
              (1 / (n : ℝ)) * ∑ i : Fin n,
                UL.matchingLoss Φ
                  ((V (sample i).1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
                  (sample i).2) := by
    intro sample
    by_cases hx : ∀ i : Fin n, ‖(sample i).1‖ ≤ L
    · let x : Fin n → X := fun i => (sample i).1
      let y : Fin n → Fin K := fun i => (sample i).2
      obtain ⟨Z, _hZ, hRegretAll, ⟨W, hW_norm, _hW_orth, P, hWP_opt, hWP_gamma⟩⟩ :=
        h_lem_C_2 K hK X n hn x y L R β B lam M hL hx hR hβ hB hlam hM
      have hEmpRegret := (hRegretAll W hW_norm).2 P hWP_opt
      obtain ⟨⟨ρ₀, ⟨hρ₀_simp, hρ₀_lip⟩, hP_eq⟩, _⟩ := hWP_opt
      have hWx_le : ∀ i : Fin n, ‖W (x i)‖ ≤ L * R := by
        intro i
        calc ‖W (x i)‖
            ≤ UL.hilbertSchmidtNorm W * ‖x i‖ :=
              UL.Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm W (x i)
          _ ≤ R * L := mul_le_mul hW_norm (hx i) (norm_nonneg _) hR.le
          _ = L * R := mul_comm R L
      let p_pts : Fin n → EuclideanSpace ℝ (Fin K) :=
        fun i => UL.uniformVec K + (P i : EuclideanSpace ℝ (Fin K))
      have hp_pts : ∀ i : Fin n, p_pts i ∈ UL.Simplex K := by
        intro i
        dsimp [p_pts]
        rw [hP_eq i]
        exact hρ₀_simp (W (x i)) (hWx_le i)
      let iso := isoZeroSum hK
      let s_pts : Fin n → EuclideanSpace ℝ (Fin (K - 1)) := fun i => iso (W (x i))
      have hLip_pts : ∀ i j : Fin n, ‖p_pts i - p_pts j‖ ≤ B * ‖s_pts i - s_pts j‖ := by
        intro i j
        have hdiff_p : p_pts i - p_pts j =
            (P i : EuclideanSpace ℝ (Fin K)) - (P j : EuclideanSpace ℝ (Fin K)) := by
          dsimp [p_pts]
          abel
        have hnorm_s : ‖s_pts i - s_pts j‖ = ‖W (x i) - W (x j)‖ := by
          rw [← dist_eq_norm, ← dist_eq_norm]
          exact iso.isometry.dist_eq (W (x i)) (W (x j))
        rw [hdiff_p, ← Submodule.coe_sub, Submodule.norm_coe, hnorm_s, hP_eq i, hP_eq j]
        exact hρ₀_lip (W (x i)) (W (x j)) (hWx_le i) (hWx_le j)
      obtain ⟨hExMin, _hUniqMin, hExt⟩ :=
        h_lem_C_4 (K - 1) n K (by omega) hn hK s_pts p_pts hp_pts B hB_pos hLip_pts
      choose θ_s hθ_s using hExMin
      obtain ⟨hρm_hull, hhull_sub, hρm_interp, hρm_lip, _⟩ := hExt θ_s hθ_s
      let P_mat : Matrix (Fin K) (Fin n) ℝ := Matrix.of (fun k i => p_pts i k)
      let ρ_m : EuclideanSpace ℝ (Fin (K - 1)) → EuclideanSpace ℝ (Fin K) :=
        fun s₀ => Matrix.toEuclideanLin P_mat (θ_s s₀)
      let ρ : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) := fun z => ρ_m (iso z)
      have hρ_simp : ∀ z : UL.ZeroSumSubspace K, ρ z ∈ UL.Simplex K :=
        fun z => hhull_sub (hρm_hull (iso z))
      have hρ_lip : LipschitzWith (Real.toNNReal B) ρ := by
        simpa [ρ, mul_one] using hρm_lip.comp iso.lipschitz
      have hρ_interp : ∀ i : Fin n, ρ (W (x i)) = p_pts i :=
        fun i => hρm_interp i
      refine ⟨W, ρ, ⟨hW_norm, hρ_simp, hρ_lip⟩, fun _ Φ hΦ V hV => ?_⟩
      have h_emp := hEmpRegret Φ hΦ
      rw [hWP_gamma, add_zero] at h_emp
      have h_lhs_eq :
          (1 / (n : ℝ)) * ∑ i : Fin n, UL.finiteCanonicalLoss Φ (ρ (W (x i))) (y i) =
            (1 / (n : ℝ)) * ∑ i : Fin n,
              UL.finiteCanonicalLoss Φ (UL.uniformVec K + (P i : EuclideanSpace ℝ (Fin K))) (y i) := by
        congr 1
        refine Finset.sum_congr rfl fun i _ => ?_
        rw [hρ_interp i]
      rw [← h_lhs_eq] at h_emp
      have h_bdd : BddBelow (Set.range (fun V' : {V' : X →L[ℝ] UL.ZeroSumSubspace K //
          UL.hilbertSchmidtNorm V' ≤ R} =>
          (1 / (n : ℝ)) * ∑ i : Fin n,
            UL.matchingLoss Φ ((V'.1 (x i) : UL.ZeroSumSubspace K) :
              EuclideanSpace ℝ (Fin K)) (y i))) := by
        refine ⟨-(|UL.matchingPotential Φ 0| + 3 * (R * L)), ?_⟩
        rintro _ ⟨V', rfl⟩
        dsimp only
        have hterm_ge : ∀ i : Fin n,
            -(|UL.matchingPotential Φ 0| + 3 * (R * L)) ≤
              UL.matchingLoss Φ ((V'.1 (x i) : UL.ZeroSumSubspace K) :
                EuclideanSpace ℝ (Fin K)) (y i) := by
          intro i
          have habs := UL.Proof_cor_A_8.matchingLoss_abs_le (by omega) hΦ.1.2.1
            ((V'.1 (x i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) (y i)
          have hnormV : ‖((V'.1 (x i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))‖ ≤
              R * L := by
            rw [Submodule.norm_coe]
            exact (UL.Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm V'.1 (x i)).trans
              (mul_le_mul V'.2 (hx i) (norm_nonneg _) hR.le)
          linarith [(abs_le.mp habs).1]
        have hsum_ge :
            ∑ _i : Fin n, (-(|UL.matchingPotential Φ 0| + 3 * (R * L))) ≤
              ∑ i : Fin n, UL.matchingLoss Φ ((V'.1 (x i) : UL.ZeroSumSubspace K) :
                EuclideanSpace ℝ (Fin K)) (y i) :=
          Finset.sum_le_sum fun i _ => hterm_ge i
        have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
        have hmul := mul_le_mul_of_nonneg_left hsum_ge (by positivity : (0 : ℝ) ≤ 1 / (n : ℝ))
        rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul] at hmul
        have hconst : (1 / (n : ℝ)) * ((n : ℝ) * -(|UL.matchingPotential Φ 0| + 3 * (R * L))) =
            -(|UL.matchingPotential Φ 0| + 3 * (R * L)) := by
          field_simp [hn_pos.ne']
        linarith
      exact h_emp.trans (ciInf_le h_bdd ⟨V, hV⟩)
    · refine ⟨0, fun _ => UL.uniformVec K, ⟨?_, ?_, ?_⟩, fun hx' => False.elim (hx hx')⟩
      · rw [UL.Proof_lem_C_2.hilbertSchmidtNorm_zero]
        exact hR.le
      · intro _
        exact UL.Proof_lem_A_4.uniformVec_mem_simplex (by omega)
      · exact (LipschitzWith.const (UL.uniformVec K)).weaken (zero_le _)
  choose learnerW learnerRho hspec using h_pointwise
  exact ⟨learnerW, learnerRho, fun s => (hspec s).1, fun s => (hspec s).2⟩

/-- Universe-polymorphic version of `exists_empirical_learner`, transporting along an isometric
equivalence between any separable Hilbert space `X : Type v` and an `ℓ²` space in `Type u`. -/
theorem exists_empirical_learner_univ.{u, v}
    (h_lem_C_2 : UL.S_lem_C_2.{u})
    (h_lem_C_4 : UL.S_lem_C_4)
    {K : ℕ} (hK : 2 ≤ K)
    (X : Type v) [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {n : ℕ} (hn : 1 ≤ n)
    {L R β B lam M : ℝ}
    (hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) (hB : β ≤ B)
    (hlam : 0 < lam) (hM : 0 < M) :
    ∃ (learnerW : (Fin n → X × Fin K) → (X →L[ℝ] UL.ZeroSumSubspace K))
      (learnerRho : (Fin n → X × Fin K) → (UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K))),
      (∀ sample : Fin n → X × Fin K,
        UL.hilbertSchmidtNorm (learnerW sample) ≤ R ∧
        (∀ s : UL.ZeroSumSubspace K, learnerRho sample s ∈ UL.Simplex K) ∧
        LipschitzWith (Real.toNNReal B) (learnerRho sample)) ∧
      (∀ sample : Fin n → X × Fin K,
        (∀ i : Fin n, ‖(sample i).1‖ ≤ L) →
        ∀ Φ ∈ UL.SmoothEntropyFamily K β lam M,
        ∀ V : X →L[ℝ] UL.ZeroSumSubspace K, UL.hilbertSchmidtNorm V ≤ R →
          (1 / (n : ℝ)) * ∑ i : Fin n,
              UL.finiteCanonicalLoss Φ
                (learnerRho sample (learnerW sample (sample i).1)) (sample i).2 ≤
            (1 / (n : ℝ)) * ∑ i : Fin n,
              UL.matchingLoss Φ
                ((V (sample i).1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
                (sample i).2) := by
  obtain ⟨w, b, _⟩ := exists_hilbertBasis ℝ X
  haveI : Countable w := countable_of_hilbertBasis b
  let ι₀ : Type 0 := Shrink.{0} w
  let e₀ : w ≃ ι₀ := equivShrink.{0} w
  let X₀ : Type 0 := lp (fun _ : ι₀ => ℝ) 2
  let X' : Type u := lp (fun _ : ULift.{u} ι₀ => ℝ) 2
  let Φ₀ : X ≃ₗᵢ[ℝ] X₀ := reindexHilbertEquiv b e₀
  let b₀ : HilbertBasis ι₀ ℝ X₀ := HilbertBasis.ofRepr (LinearIsometryEquiv.refl ℝ X₀)
  let ξ : X₀ ≃ₗᵢ[ℝ] X' := reindexHilbertEquiv b₀ Equiv.ulift.symm
  let Φ_iso : X ≃ₗᵢ[ℝ] X' := Φ₀.trans ξ
  haveI : TopologicalSpace.SeparableSpace X' :=
    Φ_iso.surjective.denseRange.separableSpace Φ_iso.continuous
  obtain ⟨learnerW', learnerRho', h_feas', h_emp'⟩ :=
    exists_empirical_learner h_lem_C_2 h_lem_C_4 hK X' hn hL hR hβ hB hlam hM
  let mapSample : (Fin n → X × Fin K) → (Fin n → X' × Fin K) :=
    fun sample i => (Φ_iso (sample i).1, (sample i).2)
  refine ⟨fun sample =>
      (learnerW' (mapSample sample)).comp Φ_iso.toContinuousLinearEquiv.toContinuousLinearMap,
    fun sample => learnerRho' (mapSample sample), ?_, ?_⟩
  · intro sample
    obtain ⟨hW', hsimp', hlip'⟩ := h_feas' (mapSample sample)
    refine ⟨?_, hsimp', hlip'⟩
    rwa [hilbertSchmidtNorm_comp_lie (learnerW' (mapSample sample)) Φ_iso]
  · intro sample hx Φ hΦ V hV
    have hx' : ∀ i : Fin n, ‖(mapSample sample i).1‖ ≤ L := by
      intro i
      dsimp [mapSample]
      rw [Φ_iso.norm_map]
      exact hx i
    let V' : X' →L[ℝ] UL.ZeroSumSubspace K :=
      V.comp Φ_iso.symm.toContinuousLinearEquiv.toContinuousLinearMap
    have hV' : UL.hilbertSchmidtNorm V' ≤ R := by
      change UL.hilbertSchmidtNorm
        (V.comp Φ_iso.symm.toContinuousLinearEquiv.toContinuousLinearMap) ≤ R
      rwa [hilbertSchmidtNorm_comp_lie V Φ_iso.symm]
    have hemp := h_emp' (mapSample sample) hx' Φ hΦ V' hV'
    have hlhs :
        (∑ i : Fin n,
          UL.finiteCanonicalLoss Φ
            (learnerRho' (mapSample sample) ((learnerW' (mapSample sample)) (mapSample sample i).1))
            (mapSample sample i).2) =
        ∑ i : Fin n,
          UL.finiteCanonicalLoss Φ
            (learnerRho' (mapSample sample)
              (((learnerW' (mapSample sample)).comp
                Φ_iso.toContinuousLinearEquiv.toContinuousLinearMap) (sample i).1))
            (sample i).2 := rfl
    have hrhs :
        (∑ i : Fin n,
          UL.matchingLoss Φ
            ((V' (mapSample sample i).1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
            (mapSample sample i).2) =
        ∑ i : Fin n,
          UL.matchingLoss Φ
            ((V (sample i).1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
            (sample i).2 := by
      refine Finset.sum_congr rfl fun i _ => ?_
      change UL.matchingLoss Φ
        ((V (Φ_iso.symm (Φ_iso (sample i).1)) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
        (sample i).2 = _
      rw [Φ_iso.symm_apply_apply]
    rwa [hlhs, hrhs] at hemp

/-! ### Smooth loss Lipschitzness, boundedness, and `ScoreProfileClass` membership -/

lemma matchingLoss_lipschitz_three {K : ℕ} (hK : 1 ≤ K) {Φ : UL.Simplex K → ℝ}
    (hΦ_cont : Continuous Φ) (a b : EuclideanSpace ℝ (Fin K)) (y : Fin K) :
    |UL.matchingLoss Φ a y - UL.matchingLoss Φ b y| ≤ 3 * ‖a - b‖ := by
  have hpot := UL.Proof_cor_A_8.matchingPotential_lipschitz_two hK hΦ_cont a b
  have hcoord : |a y - b y| ≤ ‖a - b‖ := by
    simpa [PiLp.sub_apply, Real.norm_eq_abs] using PiLp.norm_apply_le (a - b) y
  unfold UL.matchingLoss
  have hsplit : (UL.matchingPotential Φ a - a y) - (UL.matchingPotential Φ b - b y) =
      (UL.matchingPotential Φ a - UL.matchingPotential Φ b) - (a y - b y) := by ring
  rw [hsplit]
  calc |(UL.matchingPotential Φ a - UL.matchingPotential Φ b) - (a y - b y)|
      ≤ |UL.matchingPotential Φ a - UL.matchingPotential Φ b| + |a y - b y| := abs_sub _ _
    _ ≤ 2 * ‖a - b‖ + ‖a - b‖ := add_le_add hpot hcoord
    _ = 3 * ‖a - b‖ := by ring

lemma matchingLoss_zero {K : ℕ} (Φ : UL.Simplex K → ℝ) (y : Fin K) :
    UL.matchingLoss Φ 0 y = UL.matchingPotential Φ 0 := by
  simp [UL.matchingLoss]

noncomputable def evalBallProfile {X : Type*} [NormedAddCommGroup X] {K : ℕ} (L : ℝ)
    (f : Metric.closedBall (0 : X) L × Fin K → ℝ) (x : X) (y : Fin K) : ℝ :=
  open Classical in
  if hx : x ∈ Metric.closedBall (0 : X) L then f (⟨x, hx⟩, y) else 0

lemma learnerProfile_mem_scoreProfileClass.{u}
    {X : Type u} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {K : ℕ} (hK : 2 ≤ K) {L R β B lam M : ℝ}
    (hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) (hB : β ≤ B)
    {Φ : UL.Simplex K → ℝ} (hΦ : UL.SmoothEntropyFamily K β lam M Φ)
    {W : X →L[ℝ] UL.ZeroSumSubspace K} (hW : UL.hilbertSchmidtNorm W ≤ R)
    {ρ : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hρ_simp : ∀ s : UL.ZeroSumSubspace K, ρ s ∈ UL.Simplex K)
    (hρ_lip : LipschitzWith (Real.toNNReal B) ρ) :
    let C : ℝ := 3 * B * lam
    let M₀ : ℝ := 3 * (M + L * R)
    let c_Φ : ℝ := UL.matchingPotential Φ 0
    (fun xy : Metric.closedBall (0 : X) L × Fin K =>
      UL.finiteCanonicalLoss Φ (ρ (W xy.1.1)) xy.2 - c_Φ) ∈
      UL.ScoreProfileClass X K L R C M₀ := by
  intro C M₀ c_Φ
  have hB_pos : 0 < B := lt_of_lt_of_le hβ hB
  have hlam_pos : 0 < lam := hΦ.2.1
  have hM_pos : 0 < M := hΦ.2.2.1
  have hΦ_cont : Continuous Φ := hΦ.1.2.1
  have hC_pos : 0 < C := by dsimp [C]; positivity
  have hM₀_pos : 0 < M₀ := by dsimp [M₀]; positivity
  let a : Fin K → UL.ZeroSumSubspace K → ℝ :=
    fun y s => UL.finiteCanonicalLoss Φ (ρ s) y - c_Φ
  refine ⟨hK, hL, hR, hC_pos, hM₀_pos, W, a, hW, fun y => ⟨?_, ?_⟩, fun _ _ => rfl⟩
  · rw [lipschitzOnWith_iff_dist_le_mul]
    intro s₁ _ s₂ _
    rw [Real.coe_toNNReal C hC_pos.le, Real.dist_eq, dist_eq_norm]
    dsimp [a, c_Φ, UL.finiteCanonicalLoss, UL.finiteCanonicalAction]
    have hsub : (UL.matchingLoss Φ (UL.simplexGrad Φ (ρ s₁)) y - UL.matchingPotential Φ 0) -
        (UL.matchingLoss Φ (UL.simplexGrad Φ (ρ s₂)) y - UL.matchingPotential Φ 0) =
        UL.matchingLoss Φ (UL.simplexGrad Φ (ρ s₁)) y -
          UL.matchingLoss Φ (UL.simplexGrad Φ (ρ s₂)) y := by ring
    rw [hsub]
    have hρ_dist : ‖ρ s₁ - ρ s₂‖ ≤ B * ‖s₁ - s₂‖ := by
      have h := hρ_lip.dist_le_mul s₁ s₂
      rwa [Real.coe_toNNReal B hB_pos.le, dist_eq_norm, dist_eq_norm] at h
    calc |UL.matchingLoss Φ (UL.simplexGrad Φ (ρ s₁)) y -
            UL.matchingLoss Φ (UL.simplexGrad Φ (ρ s₂)) y|
        ≤ 3 * ‖UL.simplexGrad Φ (ρ s₁) - UL.simplexGrad Φ (ρ s₂)‖ :=
          matchingLoss_lipschitz_three (by omega) hΦ_cont _ _ y
      _ ≤ 3 * (lam * ‖ρ s₁ - ρ s₂‖) :=
          mul_le_mul_of_nonneg_left (hΦ.2.2.2.2.1 _ (hρ_simp s₁) _ (hρ_simp s₂)) (by norm_num)
      _ ≤ 3 * (lam * (B * ‖s₁ - s₂‖)) :=
          mul_le_mul_of_nonneg_left
            (mul_le_mul_of_nonneg_left hρ_dist hlam_pos.le) (by norm_num)
      _ = C * ‖s₁ - s₂‖ := by dsimp [C]; ring
  · intro s _hs
    rw [Set.mem_Icc, ← abs_le]
    dsimp [a, c_Φ, UL.finiteCanonicalLoss, UL.finiteCanonicalAction]
    rw [← matchingLoss_zero Φ y]
    calc |UL.matchingLoss Φ (UL.simplexGrad Φ (ρ s)) y - UL.matchingLoss Φ 0 y|
        ≤ 3 * ‖UL.simplexGrad Φ (ρ s) - 0‖ :=
          matchingLoss_lipschitz_three (by omega) hΦ_cont _ _ y
      _ = 3 * ‖UL.simplexGrad Φ (ρ s)‖ := by rw [sub_zero]
      _ ≤ 3 * M := mul_le_mul_of_nonneg_left (hΦ.2.2.2.2.2 _ (hρ_simp s)) (by norm_num)
      _ ≤ M₀ := by dsimp [M₀]; nlinarith

lemma compProfile_mem_scoreProfileClass.{u}
    {X : Type u} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {K : ℕ} (hK : 2 ≤ K) {L R β B lam M : ℝ}
    (hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) (hB : β ≤ B)
    {Φ : UL.Simplex K → ℝ} (hΦ : UL.SmoothEntropyFamily K β lam M Φ)
    {V : X →L[ℝ] UL.ZeroSumSubspace K} (hV : UL.hilbertSchmidtNorm V ≤ R) :
    let C : ℝ := 3 * B * lam
    let M₀ : ℝ := 3 * (M + L * R)
    let c_Φ : ℝ := UL.matchingPotential Φ 0
    (fun xy : Metric.closedBall (0 : X) L × Fin K =>
      UL.matchingLoss Φ (V xy.1.1 : EuclideanSpace ℝ (Fin K)) xy.2 - c_Φ) ∈
      UL.ScoreProfileClass X K L R C M₀ := by
  intro C M₀ c_Φ
  have hB_pos : 0 < B := lt_of_lt_of_le hβ hB
  have hlam_pos : 0 < lam := hΦ.2.1
  have hM_pos : 0 < M := hΦ.2.2.1
  have hΦ_cont : Continuous Φ := hΦ.1.2.1
  have h1_le_Blam : 1 ≤ B * lam := one_le_B_mul_lam_of_mem hK hβ hB hΦ
  have hC_pos : 0 < C := by dsimp [C]; positivity
  have hM₀_pos : 0 < M₀ := by dsimp [M₀]; positivity
  let a : Fin K → UL.ZeroSumSubspace K → ℝ :=
    fun y s => UL.matchingLoss Φ (s : EuclideanSpace ℝ (Fin K)) y - c_Φ
  refine ⟨hK, hL, hR, hC_pos, hM₀_pos, V, a, hV, fun y => ⟨?_, ?_⟩, fun _ _ => rfl⟩
  · rw [lipschitzOnWith_iff_dist_le_mul]
    intro s₁ _ s₂ _
    rw [Real.coe_toNNReal C hC_pos.le, Real.dist_eq, dist_eq_norm]
    dsimp [a, c_Φ]
    have hsub : (UL.matchingLoss Φ (s₁ : EuclideanSpace ℝ (Fin K)) y - UL.matchingPotential Φ 0) -
        (UL.matchingLoss Φ (s₂ : EuclideanSpace ℝ (Fin K)) y - UL.matchingPotential Φ 0) =
        UL.matchingLoss Φ (s₁ : EuclideanSpace ℝ (Fin K)) y -
          UL.matchingLoss Φ (s₂ : EuclideanSpace ℝ (Fin K)) y := by ring
    rw [hsub]
    calc |UL.matchingLoss Φ (s₁ : EuclideanSpace ℝ (Fin K)) y -
            UL.matchingLoss Φ (s₂ : EuclideanSpace ℝ (Fin K)) y|
        ≤ 3 * ‖(s₁ : EuclideanSpace ℝ (Fin K)) - (s₂ : EuclideanSpace ℝ (Fin K))‖ :=
          matchingLoss_lipschitz_three (by omega) hΦ_cont _ _ y
      _ = 3 * ‖s₁ - s₂‖ := by rw [← Submodule.coe_sub, Submodule.norm_coe]
      _ ≤ (3 * (B * lam)) * ‖s₁ - s₂‖ :=
          mul_le_mul_of_nonneg_right (by linarith) (norm_nonneg _)
      _ = C * ‖s₁ - s₂‖ := by dsimp [C]; ring
  · intro s hs
    rw [Metric.mem_closedBall, dist_zero_right] at hs
    rw [Set.mem_Icc, ← abs_le]
    dsimp [a, c_Φ]
    rw [← matchingLoss_zero Φ y]
    calc |UL.matchingLoss Φ (s : EuclideanSpace ℝ (Fin K)) y - UL.matchingLoss Φ 0 y|
        ≤ 3 * ‖(s : EuclideanSpace ℝ (Fin K)) - 0‖ :=
          matchingLoss_lipschitz_three (by omega) hΦ_cont _ _ y
      _ = 3 * ‖s‖ := by rw [sub_zero, Submodule.norm_coe]
      _ ≤ 3 * (L * R) := mul_le_mul_of_nonneg_left hs (by norm_num)
      _ ≤ M₀ := by dsimp [M₀]; linarith

/-! ### Boundedness and measurability of `evalBallProfile` for `ScoreProfileClass` -/

lemma evalBallProfile_abs_le.{u}
    {X : Type u} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {K : ℕ} {L R C M₀ : ℝ}
    {f : Metric.closedBall (0 : X) L × Fin K → ℝ}
    (hf : f ∈ UL.ScoreProfileClass X K L R C M₀) (x : X) (y : Fin K) :
    |evalBallProfile L f x y| ≤ M₀ := by
  classical
  obtain ⟨_, _hL, hR, _hC, hM₀, W, a, hW, ha, hfeq⟩ := hf
  unfold evalBallProfile
  split_ifs with hx
  · rw [hfeq ⟨x, hx⟩ y]
    rw [Metric.mem_closedBall, dist_zero_right] at hx
    have hWx : W x ∈ Metric.closedBall (0 : UL.ZeroSumSubspace K) (L * R) := by
      rw [Metric.mem_closedBall, dist_zero_right]
      calc ‖W x‖ ≤ UL.hilbertSchmidtNorm W * ‖x‖ :=
            UL.Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm W x
        _ ≤ R * L := mul_le_mul hW hx (norm_nonneg _) hR.le
        _ = L * R := mul_comm R L
    exact abs_le.mpr ((ha y).2 hWx)
  · rw [abs_zero]
    exact hM₀.le

lemma measurable_of_fin_snd {α β : Type*} [MeasurableSpace α] [MeasurableSpace β]
    {K : ℕ} {g : α × Fin K → β}
    (hg : ∀ y : Fin K, Measurable (fun x : α => g (x, y))) :
    Measurable g := by
  intro B hB
  have heq : g ⁻¹' B = ⋃ y : Fin K, ((fun x : α => g (x, y)) ⁻¹' B) ×ˢ ({y} : Set (Fin K)) := by
    ext ⟨x, y₀⟩
    simp only [Set.mem_preimage, Set.mem_iUnion, Set.mem_prod, Set.mem_singleton_iff]
    constructor
    · intro h
      exact ⟨y₀, h, rfl⟩
    · rintro ⟨y, hx, rfl⟩
      exact hx
  rw [heq]
  exact MeasurableSet.iUnion fun y => (hg y hB).prod (measurableSet_singleton y)

lemma measurable_evalBallProfile.{u}
    {X : Type u} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    [MeasurableSpace X] [BorelSpace X]
    {K : ℕ} {L R C M₀ : ℝ}
    {f : Metric.closedBall (0 : X) L × Fin K → ℝ}
    (hf : f ∈ UL.ScoreProfileClass X K L R C M₀) :
    Measurable (fun xy : X × Fin K => evalBallProfile L f xy.1 xy.2) := by
  classical
  obtain ⟨_, _hL, hR, _hC, _hM₀, W, a, hW, ha, hfeq⟩ := hf
  refine measurable_of_fin_snd fun y => ?_
  let S : Set X := Metric.closedBall (0 : X) L
  have hS_meas : MeasurableSet S := Metric.isClosed_closedBall.measurableSet
  let g_sub : S → ℝ := fun x => a y (W x.1)
  have hmaps : Set.MapsTo (fun x : X => W x) S
      (Metric.closedBall (0 : UL.ZeroSumSubspace K) (L * R)) := by
    intro x hx
    rw [Metric.mem_closedBall, dist_zero_right] at hx ⊢
    calc ‖W x‖ ≤ UL.hilbertSchmidtNorm W * ‖x‖ :=
          UL.Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm W x
      _ ≤ R * L := mul_le_mul hW hx (norm_nonneg _) hR.le
      _ = L * R := mul_comm R L
  have hg_contOn : ContinuousOn (fun x : X => a y (W x)) S :=
    (ha y).1.continuousOn.comp W.continuous.continuousOn hmaps
  have hg_sub_meas : Measurable g_sub :=
    (continuousOn_iff_continuous_restrict.mp hg_contOn).measurable
  intro B hB
  have hpre : (fun x : X => evalBallProfile L f x y) ⁻¹' B =
      (Subtype.val '' (g_sub ⁻¹' B)) ∪ (if (0 : ℝ) ∈ B then Sᶜ else ∅) := by
    ext x
    simp only [Set.mem_preimage, Set.mem_union, Set.mem_image, Subtype.exists]
    unfold evalBallProfile
    by_cases hx : x ∈ S
    · have hcond : x ∈ Metric.closedBall (0 : X) L := hx
      simp only [dif_pos hcond, hfeq ⟨x, hcond⟩ y]
      constructor
      · intro hB_mem
        exact Or.inl ⟨x, hx, hB_mem, rfl⟩
      · rintro (⟨x', hx', hB_mem, rfl⟩ | h2)
        · exact hB_mem
        · split_ifs at h2 with h0
          · exact False.elim (h2 hx)
          · exact False.elim h2
    · have hcond : x ∉ Metric.closedBall (0 : X) L := hx
      simp only [dif_neg hcond]
      constructor
      · intro h0
        right
        rw [if_pos h0]
        exact hx
      · rintro (⟨x', hx', _, rfl⟩ | h2)
        · exact False.elim (hx hx')
        · split_ifs at h2 with h0
          · exact h0
          · exact False.elim h2
  rw [hpre]
  refine (hS_meas.subtype_image (hg_sub_meas hB)).union ?_
  split_ifs
  · exact hS_meas.compl
  · exact MeasurableSet.empty

lemma scoreProfileClass_dev_bddAbove.{u}
    {X : Type u} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    [MeasurableSpace X] [BorelSpace X]
    {K n : ℕ} (hn : 1 ≤ n) {L R C M₀ : ℝ} (hM₀ : 0 < M₀)
    (ν : Measure (X × Fin K)) [IsProbabilityMeasure ν]
    (x_s : Fin n → X) (y_s : Fin n → Fin K) :
    BddAbove ((fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
      |(∫ xy, evalBallProfile L f xy.1 xy.2 ∂ν) -
        ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalBallProfile L f (x_s i) (y_s i)|) ''
      UL.ScoreProfileClass X K L R C M₀) := by
  refine ⟨2 * M₀, ?_⟩
  rintro _ ⟨f, hf, rfl⟩
  dsimp only
  have hint_le : |∫ xy, evalBallProfile L f xy.1 xy.2 ∂ν| ≤ M₀ := by
    calc |∫ xy, evalBallProfile L f xy.1 xy.2 ∂ν|
        = ‖∫ xy, evalBallProfile L f xy.1 xy.2 ∂ν‖ := (Real.norm_eq_abs _).symm
      _ ≤ ∫ xy, ‖evalBallProfile L f xy.1 xy.2‖ ∂ν := norm_integral_le_integral_norm _
      _ ≤ ∫ _xy : X × Fin K, M₀ ∂ν := by
          refine integral_mono ?_ (integrable_const M₀) (fun xy => ?_)
          · refine ((integrable_const M₀).mono'
              (measurable_evalBallProfile hf).aestronglyMeasurable
              (Filter.Eventually.of_forall fun xy => ?_)).norm
            rw [Real.norm_eq_abs]
            exact evalBallProfile_abs_le hf xy.1 xy.2
          · rw [Real.norm_eq_abs]
            exact evalBallProfile_abs_le hf xy.1 xy.2
      _ = M₀ := by simp
  have hsum_le : |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalBallProfile L f (x_s i) (y_s i)| ≤ M₀ := by
    have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
    rw [abs_mul, abs_of_pos (one_div_pos.mpr hn_pos)]
    calc (1 / (n : ℝ)) * |∑ i : Fin n, evalBallProfile L f (x_s i) (y_s i)|
        ≤ (1 / (n : ℝ)) * ∑ i : Fin n, |evalBallProfile L f (x_s i) (y_s i)| :=
          mul_le_mul_of_nonneg_left (Finset.abs_sum_le_sum_abs _ _) (by positivity)
      _ ≤ (1 / (n : ℝ)) * ∑ _i : Fin n, M₀ :=
          mul_le_mul_of_nonneg_left (Finset.sum_le_sum fun i _ => evalBallProfile_abs_le hf _ _)
            (by positivity)
      _ = M₀ := by
          rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
          field_simp [hn_pos.ne']
  calc |(∫ xy, evalBallProfile L f xy.1 xy.2 ∂ν) -
          ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalBallProfile L f (x_s i) (y_s i)|
      ≤ |∫ xy, evalBallProfile L f xy.1 xy.2 ∂ν| +
          |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalBallProfile L f (x_s i) (y_s i)| := abs_sub _ _
    _ ≤ M₀ + M₀ := add_le_add hint_le hsum_le
    _ = 2 * M₀ := by ring

/-! ### Relating `evalBallProfile` deviation to population-minus-empirical loss -/

lemma evalBallProfile_dev_learner_eq.{u}
    {X : Type u} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    [MeasurableSpace X] [BorelSpace X]
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R β B lam M : ℝ}
    (_hL : 0 < L) (_hR : 0 < R) (_hβ : 0 < β) (_hB : β ≤ B)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    {W : X →L[ℝ] UL.ZeroSumSubspace K} (_hW : UL.hilbertSchmidtNorm W ≤ R)
    {ρ : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hρ_simp : ∀ s : UL.ZeroSumSubspace K, ρ s ∈ UL.Simplex K)
    (hρ_lip : LipschitzWith (Real.toNNReal B) ρ)
    (ν : Measure (X × Fin K)) [IsProbabilityMeasure ν]
    (hX_bound : ∀ᵐ xy ∂ν, ‖xy.1‖ ≤ L)
    (x_s : Fin n → X) (y_s : Fin n → Fin K)
    (hx_s : ∀ i : Fin n, ‖x_s i‖ ≤ L) :
    let c_Φ : ℝ := UL.matchingPotential Φ 0
    let f_learn : Metric.closedBall (0 : X) L × Fin K → ℝ :=
      fun xy => UL.finiteCanonicalLoss Φ (ρ (W xy.1.1)) xy.2 - c_Φ
    (∫ xy, evalBallProfile L f_learn xy.1 xy.2 ∂ν) -
        ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalBallProfile L f_learn (x_s i) (y_s i) =
      (∫ xy, UL.finiteCanonicalLoss Φ (ρ (W xy.1)) xy.2 ∂ν) -
        ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, UL.finiteCanonicalLoss Φ (ρ (W (x_s i))) (y_s i) := by
  intro c_Φ f_learn
  have hΦ_cont : Continuous Φ := hΦ.1.2.1
  have hgrad_contOn : ContinuousOn (UL.simplexGrad Φ) (UL.Simplex K) := by
    rw [Metric.continuousOn_iff]
    intro p hp ε hε
    have hlam_pos : 0 < lam := hΦ.2.1
    refine ⟨ε / lam, div_pos hε hlam_pos, fun q hq hpq => ?_⟩
    rw [dist_eq_norm] at hpq ⊢
    calc ‖UL.simplexGrad Φ q - UL.simplexGrad Φ p‖
        ≤ lam * ‖q - p‖ := hΦ.2.2.2.2.1 q hq p hp
      _ < lam * (ε / lam) := mul_lt_mul_of_pos_left hpq hlam_pos
      _ = ε := mul_div_cancel₀ ε hlam_pos.ne'
  have hp_meas : Measurable (fun xy : X × Fin K => ρ (W xy.1)) :=
    hρ_lip.continuous.measurable.comp (W.continuous.measurable.comp measurable_fst)
  have hgrad_meas : Measurable (fun xy : X × Fin K => UL.simplexGrad Φ (ρ (W xy.1))) :=
    UL.Proof_cor_A_8.measurable_comp_of_continuousOn hgrad_contOn hp_meas
      (fun xy => hρ_simp (W xy.1))
  have hloss_meas : Measurable (fun xy : X × Fin K =>
      UL.finiteCanonicalLoss Φ (ρ (W xy.1)) xy.2) :=
    UL.Proof_cor_A_8.measurable_matchingLoss_comp (by omega) hΦ_cont hgrad_meas measurable_snd
  have hloss_int : Integrable (fun xy : X × Fin K =>
      UL.finiteCanonicalLoss Φ (ρ (W xy.1)) xy.2) ν := by
    refine (integrable_const (|c_Φ| + 3 * M)).mono' hloss_meas.aestronglyMeasurable
      (Filter.Eventually.of_forall fun xy => ?_)
    rw [Real.norm_eq_abs]
    have h1 := UL.Proof_cor_A_8.matchingLoss_abs_le (by omega) hΦ_cont
      (UL.simplexGrad Φ (ρ (W xy.1))) xy.2
    have h2 : ‖UL.simplexGrad Φ (ρ (W xy.1))‖ ≤ M := hΦ.2.2.2.2.2 _ (hρ_simp (W xy.1))
    dsimp [UL.finiteCanonicalLoss, UL.finiteCanonicalAction, c_Φ] at h1 ⊢
    linarith
  have hae : (fun xy : X × Fin K => evalBallProfile L f_learn xy.1 xy.2) =ᵐ[ν]
      (fun xy : X × Fin K => UL.finiteCanonicalLoss Φ (ρ (W xy.1)) xy.2 - c_Φ) := by
    filter_upwards [hX_bound] with xy hxy
    classical
    have hmem : xy.1 ∈ Metric.closedBall (0 : X) L := by
      rwa [Metric.mem_closedBall, dist_zero_right]
    simp [evalBallProfile, hmem, f_learn]
  have hint_eq : (∫ xy, evalBallProfile L f_learn xy.1 xy.2 ∂ν) =
      (∫ xy, UL.finiteCanonicalLoss Φ (ρ (W xy.1)) xy.2 ∂ν) - c_Φ := by
    rw [integral_congr_ae hae, integral_sub hloss_int (integrable_const c_Φ)]
    simp
  have hsum_eq :
      ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalBallProfile L f_learn (x_s i) (y_s i) =
        ((1 : ℝ) / (n : ℝ)) * (∑ i : Fin n, UL.finiteCanonicalLoss Φ (ρ (W (x_s i))) (y_s i)) -
          c_Φ := by
    have hpt : ∀ i : Fin n, evalBallProfile L f_learn (x_s i) (y_s i) =
        UL.finiteCanonicalLoss Φ (ρ (W (x_s i))) (y_s i) - c_Φ := by
      intro i
      classical
      have hmem : x_s i ∈ Metric.closedBall (0 : X) L := by
        rw [Metric.mem_closedBall, dist_zero_right]
        exact hx_s i
      simp [evalBallProfile, hmem, f_learn]
    simp_rw [hpt, Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
      nsmul_eq_mul]
    have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
    field_simp [hn_pos.ne']
  rw [hint_eq, hsum_eq]
  ring

lemma evalBallProfile_dev_comp_eq.{u}
    {X : Type u} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    [MeasurableSpace X] [BorelSpace X]
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R β lam M : ℝ}
    (_hL : 0 < L) (hR : 0 < R)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    {V : X →L[ℝ] UL.ZeroSumSubspace K} (hV : UL.hilbertSchmidtNorm V ≤ R)
    (ν : Measure (X × Fin K)) [IsProbabilityMeasure ν]
    (hX_bound : ∀ᵐ xy ∂ν, ‖xy.1‖ ≤ L)
    (x_s : Fin n → X) (y_s : Fin n → Fin K)
    (hx_s : ∀ i : Fin n, ‖x_s i‖ ≤ L) :
    let c_Φ : ℝ := UL.matchingPotential Φ 0
    let f_comp : Metric.closedBall (0 : X) L × Fin K → ℝ :=
      fun xy => UL.matchingLoss Φ (V xy.1.1 : EuclideanSpace ℝ (Fin K)) xy.2 - c_Φ
    (∫ xy, evalBallProfile L f_comp xy.1 xy.2 ∂ν) -
        ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalBallProfile L f_comp (x_s i) (y_s i) =
      (∫ xy, UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 ∂ν) -
        ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
          UL.matchingLoss Φ (V (x_s i) : EuclideanSpace ℝ (Fin K)) (y_s i) := by
  intro c_Φ f_comp
  have hΦ_cont : Continuous Φ := hΦ.1.2.1
  have hV_meas : Measurable (fun xy : X × Fin K => (V xy.1 : EuclideanSpace ℝ (Fin K))) :=
    (UL.ZeroSumSubspace K).subtypeL.continuous.measurable.comp
      (V.continuous.measurable.comp measurable_fst)
  have hloss_meas : Measurable (fun xy : X × Fin K =>
      UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2) :=
    UL.Proof_cor_A_8.measurable_matchingLoss_comp (by omega) hΦ_cont hV_meas measurable_snd
  have hloss_int : Integrable (fun xy : X × Fin K =>
      UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2) ν := by
    refine (integrable_const (|c_Φ| + 3 * (R * L))).mono' hloss_meas.aestronglyMeasurable ?_
    filter_upwards [hX_bound] with xy hxy
    rw [Real.norm_eq_abs]
    have h1 := UL.Proof_cor_A_8.matchingLoss_abs_le (by omega) hΦ_cont
      (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2
    have h2 : ‖(V xy.1 : EuclideanSpace ℝ (Fin K))‖ ≤ R * L := by
      rw [Submodule.norm_coe]
      exact (UL.Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm V xy.1).trans
        (mul_le_mul hV hxy (norm_nonneg _) hR.le)
    dsimp [c_Φ] at h1 ⊢
    linarith
  have hae : (fun xy : X × Fin K => evalBallProfile L f_comp xy.1 xy.2) =ᵐ[ν]
      (fun xy : X × Fin K => UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 - c_Φ) := by
    filter_upwards [hX_bound] with xy hxy
    classical
    have hmem : xy.1 ∈ Metric.closedBall (0 : X) L := by
      rwa [Metric.mem_closedBall, dist_zero_right]
    simp [evalBallProfile, hmem, f_comp]
  have hint_eq : (∫ xy, evalBallProfile L f_comp xy.1 xy.2 ∂ν) =
      (∫ xy, UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 ∂ν) - c_Φ := by
    rw [integral_congr_ae hae, integral_sub hloss_int (integrable_const c_Φ)]
    simp
  have hsum_eq :
      ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalBallProfile L f_comp (x_s i) (y_s i) =
        ((1 : ℝ) / (n : ℝ)) *
          (∑ i : Fin n, UL.matchingLoss Φ (V (x_s i) : EuclideanSpace ℝ (Fin K)) (y_s i)) -
          c_Φ := by
    have hpt : ∀ i : Fin n, evalBallProfile L f_comp (x_s i) (y_s i) =
        UL.matchingLoss Φ (V (x_s i) : EuclideanSpace ℝ (Fin K)) (y_s i) - c_Φ := by
      intro i
      classical
      have hmem : x_s i ∈ Metric.closedBall (0 : X) L := by
        rw [Metric.mem_closedBall, dist_zero_right]
        exact hx_s i
      simp [evalBallProfile, hmem, f_comp]
    simp_rw [hpt, Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
      nsmul_eq_mul]
    have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
    field_simp [hn_pos.ne']
  rw [hint_eq, hsum_eq]
  ring

end UL.Proof_thm_C_1_Race3

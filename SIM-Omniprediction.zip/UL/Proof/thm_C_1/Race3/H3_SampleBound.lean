import Mathlib
set_option autoImplicit false

namespace UL.Proof_thm_C_1_Race3

noncomputable def sampleConstCK (K : ℕ) (C₃ : ℝ) : ℝ :=
  let c₃ : ℝ := max 1 C₃
  max ((72 * c₃) ^ 2) ((12 * c₃) ^ (K - 1))

lemma sampleConstCK_pos (K : ℕ) (C₃ : ℝ) : 0 < sampleConstCK K C₃ := by
  unfold sampleConstCK
  dsimp only
  have hc₃ : (0 : ℝ) < max 1 C₃ := lt_of_lt_of_le zero_lt_one (le_max_left 1 C₃)
  exact lt_of_lt_of_le (by positivity : (0 : ℝ) < (72 * max 1 C₃) ^ 2) (le_max_left _ _)

private lemma exp_two_lt_eight : Real.exp 2 < 8 := by
  have h1 : Real.exp 1 < 2.72 := lt_trans Real.exp_one_lt_d9 (by norm_num)
  have hpos : 0 < Real.exp 1 := Real.exp_pos 1
  rw [show (2 : ℝ) = 1 + 1 by norm_num, Real.exp_add]
  nlinarith only [h1, hpos]

lemma log_two_sq_div_antitone {u v : ℝ} (hu : 2 ≤ u) (huv : u ≤ v) :
    Real.log (2 * v ^ 2) / v ≤ Real.log (2 * u ^ 2) / u := by
  have hu_pos : 0 < u := by linarith
  have hv_pos : 0 < v := by linarith
  rw [div_le_div_iff₀ hv_pos hu_pos]
  have h2u_pos : 0 < 2 * u ^ 2 := by positivity
  have hvu_pos : 0 < v / u := div_pos hv_pos hu_pos
  have hdecomp : 2 * v ^ 2 = (2 * u ^ 2) * (v / u) ^ 2 := by
    field_simp [hu_pos.ne']
  rw [hdecomp, Real.log_mul h2u_pos.ne' (pow_pos hvu_pos 2).ne', Real.log_pow, Nat.cast_ofNat]
  have hlog_vu : 2 * u * Real.log (v / u) ≤ 2 * (v - u) := by
    have h1 : Real.log (v / u) ≤ v / u - 1 := Real.log_le_sub_one_of_pos hvu_pos
    have h2 : 2 * u * Real.log (v / u) ≤ 2 * u * (v / u - 1) :=
      mul_le_mul_of_nonneg_left h1 (by positivity)
    have h3 : 2 * u * (v / u - 1) = 2 * (v - u) := by
      field_simp [hu_pos.ne']
    linarith
  have hlog_2u : 2 ≤ Real.log (2 * u ^ 2) := by
    have h8 : (8 : ℝ) ≤ 2 * u ^ 2 := by nlinarith only [hu]
    conv_lhs => rw [← Real.log_exp 2]
    exact Real.log_le_log (Real.exp_pos 2) (le_trans exp_two_lt_eight.le h8)
  have hvu_nn : 0 ≤ v - u := sub_nonneg.mpr huv
  have hmul : 2 * (v - u) ≤ (v - u) * Real.log (2 * u ^ 2) := by
    nlinarith only [hvu_nn, hlog_2u]
  nlinarith only [hlog_vu, hmul]

theorem sample_bound_implies_two_bound_le
    (K : ℕ) (_hK : 2 ≤ K) (C₃ : ℝ) (_hC₃ : 0 < C₃)
    (M A₀ B lam ε δ : ℝ)
    (hM : 0 < M) (hA₀ : 0 < A₀) (hB : 0 < B) (hlam : 0 < lam)
    (hε0 : 0 < ε) (hεD : ε ≤ M + A₀ + B * lam * A₀)
    (hδ0 : 0 < δ) (hδ1 : δ < (1 : ℝ) / 2)
    (n : ℕ) (hn : 1 ≤ n)
    (hn_ge :
      let m : ℕ := K - 1
      let D : ℝ := M + A₀ + B * lam * A₀
      let C_K : ℝ := sampleConstCK K C₃
      (n : ℝ) ≥
        if m ≤ 2 then
          C_K * (D / ε) ^ 2 * (Real.log (C_K * D / (ε * δ))) ^ 2
        else
          C_K * ((D / ε) ^ m + (D / ε) ^ 2 * Real.log ((2 : ℝ) / δ))) :
    let m : ℕ := K - 1
    let D₀ : ℝ := 3 * (M + A₀) + (3 * B * lam) * A₀
    let M₀ : ℝ := 3 * (M + A₀)
    2 *
      (if m ≤ 2 then
        C₃ * (D₀ * Real.log (2 * (n : ℝ)) + M₀ * Real.sqrt (Real.log (2 / δ))) /
          Real.sqrt (n : ℝ)
      else
        C₃ * D₀ * ((n : ℝ) ^ (-(1 : ℝ) / (m : ℝ))) +
          C₃ * M₀ * Real.sqrt (Real.log (2 / δ) / (n : ℝ))) ≤ ε := by
  intro m D₀ M₀
  dsimp only at hn_ge
  set D : ℝ := M + A₀ + B * lam * A₀
  set c₃ : ℝ := max 1 C₃
  set C_K : ℝ := sampleConstCK K C₃
  have hc₃_ge1 : 1 ≤ c₃ := le_max_left 1 C₃
  have hc₃_pos : 0 < c₃ := lt_of_lt_of_le zero_lt_one hc₃_ge1
  have hC₃_le : C₃ ≤ c₃ := le_max_right 1 C₃
  have hCK_ge72 : (72 * c₃) ^ 2 ≤ C_K := le_max_left _ _
  have hCK_ge12m : (12 * c₃) ^ m ≤ C_K := le_max_right _ _
  have hBlA_pos : 0 < B * lam * A₀ := by positivity
  have hD_pos : 0 < D := by positivity
  have hD₀_eq : D₀ = 3 * D := by dsimp [D₀, D]; ring
  have hM₀_pos : 0 < M₀ := by positivity
  have hM₀_le : M₀ ≤ 3 * D := by dsimp [M₀, D]; linarith
  change ε ≤ D at hεD
  clear_value c₃ C_K D D₀ M₀
  have hCK_ge5184 : 5184 ≤ C_K := by
    have h72 : (72 : ℝ) ^ 2 ≤ (72 * c₃) ^ 2 :=
      pow_le_pow_left₀ (by norm_num) (by linarith) 2
    linarith [show (72 : ℝ) ^ 2 = 5184 by norm_num]
  have hCK_pos : 0 < C_K := by linarith
  have hDe_ge1 : 1 ≤ D / ε := (one_le_div hε0).mpr hεD
  have hDe_pos : 0 < D / ε := lt_of_lt_of_le zero_lt_one hDe_ge1
  have h1d_gt2 : 2 < 1 / δ := by
    rw [lt_div_iff₀ hδ0]
    linarith
  have h2d_gt4 : 4 < (2 : ℝ) / δ := by
    rw [lt_div_iff₀ hδ0]
    linarith
  have hlog2d_pos : 0 < Real.log ((2 : ℝ) / δ) := Real.log_pos (by linarith)
  have hn_ge1 : (1 : ℝ) ≤ (n : ℝ) := Nat.one_le_cast.mpr hn
  have hn_pos : (0 : ℝ) < (n : ℝ) := lt_of_lt_of_le zero_lt_one hn_ge1
  split_ifs with hm2
  · rw [if_pos hm2] at hn_ge
    set T : ℝ := C_K * D / (ε * δ)
    have hT_eq : T = C_K * (D / ε) * (1 / δ) := by
      dsimp [T]
      field_simp [hε0.ne', hδ0.ne']
    clear_value T
    have hCK_De_ge : 5184 ≤ C_K * (D / ε) := by
      have h1 := mul_le_mul hCK_ge5184 hDe_ge1 zero_le_one hCK_pos.le
      linarith
    have hT_gt32 : 32 < T := by
      rw [hT_eq]
      have h1 : 5184 * 2 ≤ (C_K * (D / ε)) * (1 / δ) :=
        mul_le_mul hCK_De_ge h1d_gt2.le (by norm_num) (by linarith)
      linarith
    have hT_pos : 0 < T := by linarith
    have hCK_le_T : C_K ≤ T := by
      rw [hT_eq]
      have h1 : 1 ≤ (D / ε) * (1 / δ) :=
        le_trans (by norm_num : (1 : ℝ) ≤ 1 * 2)
          (mul_le_mul hDe_ge1 h1d_gt2.le (by norm_num) hDe_pos.le)
      have h2 := mul_le_mul_of_nonneg_left h1 hCK_pos.le
      linarith [show C_K * ((D / ε) * (1 / δ)) = C_K * (D / ε) * (1 / δ) by ring]
    have hDe_le_T : D / ε ≤ T := by
      rw [hT_eq]
      have h1 : 1 ≤ C_K * (1 / δ) :=
        le_trans (by norm_num : (1 : ℝ) ≤ 5184 * 2)
          (mul_le_mul hCK_ge5184 h1d_gt2.le (by norm_num) hCK_pos.le)
      have h2 := mul_le_mul_of_nonneg_right h1 hDe_pos.le
      linarith [show (C_K * (1 / δ)) * (D / ε) = C_K * (D / ε) * (1 / δ) by ring]
    have h2d_le_T : (2 : ℝ) / δ ≤ T := by
      rw [hT_eq]
      have h2 := mul_le_mul_of_nonneg_right (by linarith : (2 : ℝ) ≤ C_K * (D / ε))
        (by linarith : (0 : ℝ) ≤ 1 / δ)
      linarith [show (2 : ℝ) / δ = 2 * (1 / δ) by ring]
    have hlogT_ge2 : 2 ≤ Real.log T := by
      conv_lhs => rw [← Real.log_exp 2]
      exact Real.log_le_log (Real.exp_pos 2) (le_trans exp_two_lt_eight.le (by linarith))
    have hlogT_pos : 0 < Real.log T := by linarith
    have hlogT_le_T : Real.log T ≤ T := by
      linarith [Real.log_le_sub_one_of_pos hT_pos]
    have hsqrtCK_ge : 72 * c₃ ≤ Real.sqrt C_K :=
      Real.le_sqrt_of_sq_le hCK_ge72
    have hsqrtCK_pos : 0 < Real.sqrt C_K := Real.sqrt_pos.mpr hCK_pos
    set u : ℝ := Real.sqrt C_K * (D / ε) * Real.log T
    set v : ℝ := Real.sqrt (n : ℝ)
    have hu_ge2 : 2 ≤ u := by
      have h1 : 72 ≤ Real.sqrt C_K := by linarith
      have h2 : 72 ≤ Real.sqrt C_K * (D / ε) := by
        simpa using mul_le_mul h1 hDe_ge1 zero_le_one hsqrtCK_pos.le
      have h3 : 72 * 2 ≤ (Real.sqrt C_K * (D / ε)) * Real.log T :=
        mul_le_mul h2 hlogT_ge2 (by norm_num) (by linarith)
      dsimp [u]
      linarith
    have hu_pos : 0 < u := by linarith
    have hv_pos : 0 < v := Real.sqrt_pos.mpr hn_pos
    have hu_sq : u ^ 2 = C_K * (D / ε) ^ 2 * (Real.log T) ^ 2 := by
      dsimp [u]
      rw [mul_pow, mul_pow, Real.sq_sqrt hCK_pos.le]
    have hv_sq : v ^ 2 = (n : ℝ) := Real.sq_sqrt hn_pos.le
    have huv : u ≤ v := by
      have hsq : u ^ 2 ≤ v ^ 2 := by rw [hu_sq, hv_sq]; exact hn_ge
      nlinarith only [hsq, hu_pos, hv_pos]
    have hantitone : Real.log (2 * (n : ℝ)) / v ≤ Real.log (2 * u ^ 2) / u := by
      rw [← hv_sq]
      exact log_two_sq_div_antitone hu_ge2 huv
    have h2u2_le_T6 : 2 * u ^ 2 ≤ T ^ 6 := by
      rw [hu_sq]
      have hA : 2 * C_K ≤ T * T := mul_le_mul (by linarith) hCK_le_T hCK_pos.le hT_pos.le
      have hB2 : (D / ε) ^ 2 ≤ T ^ 2 := pow_le_pow_left₀ hDe_pos.le hDe_le_T 2
      have hC2 : (Real.log T) ^ 2 ≤ T ^ 2 := pow_le_pow_left₀ hlogT_pos.le hlogT_le_T 2
      have hAB : (2 * C_K) * (D / ε) ^ 2 ≤ (T * T) * T ^ 2 :=
        mul_le_mul hA hB2 (by positivity) (by positivity)
      have hABC : ((2 * C_K) * (D / ε) ^ 2) * (Real.log T) ^ 2 ≤ ((T * T) * T ^ 2) * T ^ 2 :=
        mul_le_mul hAB hC2 (by positivity) (by positivity)
      linarith [show ((T * T) * T ^ 2) * T ^ 2 = T ^ 6 by ring,
        show ((2 * C_K) * (D / ε) ^ 2) * (Real.log T) ^ 2 =
          2 * (C_K * (D / ε) ^ 2 * (Real.log T) ^ 2) by ring]
    have hlog_2u2 : Real.log (2 * u ^ 2) ≤ 6 * Real.log T := by
      have h1 : Real.log (2 * u ^ 2) ≤ Real.log (T ^ 6) :=
        Real.log_le_log (by positivity) h2u2_le_T6
      rw [Real.log_pow, Nat.cast_ofNat] at h1
      exact h1
    have hterm1_ratio : Real.log (2 * (n : ℝ)) / v ≤ 6 * ε / (Real.sqrt C_K * D) := by
      have h1 : Real.log (2 * u ^ 2) / u ≤ (6 * Real.log T) / u :=
        div_le_div_of_nonneg_right hlog_2u2 hu_pos.le
      have h2 : (6 * Real.log T) / u = 6 * ε / (Real.sqrt C_K * D) := by
        dsimp [u]
        field_simp [hsqrtCK_pos.ne', hD_pos.ne', hε0.ne', hlogT_pos.ne']
      exact le_trans hantitone (h1.trans_eq h2)
    have hterm2_ratio : Real.sqrt (Real.log (2 / δ)) / v ≤ ε / (Real.sqrt C_K * D) := by
      have hlog_le : Real.log ((2 : ℝ) / δ) ≤ Real.log T :=
        Real.log_le_log (by positivity) h2d_le_T
      have hsqrt_le : Real.sqrt (Real.log ((2 : ℝ) / δ)) ≤ Real.log T := by
        have h1 : Real.sqrt (Real.log ((2 : ℝ) / δ)) ≤ Real.sqrt (Real.log T) :=
          Real.sqrt_le_sqrt hlog_le
        have h2 : Real.sqrt (Real.log T) ≤ Real.log T := by
          rw [Real.sqrt_le_left hlogT_pos.le]
          nlinarith only [hlogT_ge2]
        exact le_trans h1 h2
      have hdiv1 : Real.sqrt (Real.log ((2 : ℝ) / δ)) / v ≤ Real.log T / u := by
        calc Real.sqrt (Real.log ((2 : ℝ) / δ)) / v
            ≤ Real.log T / v := div_le_div_of_nonneg_right hsqrt_le hv_pos.le
          _ ≤ Real.log T / u := div_le_div_of_nonneg_left hlogT_pos.le hu_pos huv
      have hdiv2 : Real.log T / u = ε / (Real.sqrt C_K * D) := by
        dsimp [u]
        field_simp [hsqrtCK_pos.ne', hD_pos.ne', hε0.ne', hlogT_pos.ne']
      exact hdiv1.trans_eq hdiv2
    have hlog2n_nn : 0 ≤ Real.log (2 * (n : ℝ)) :=
      Real.log_nonneg (by linarith)
    have hsplit :
        2 * (C₃ * (D₀ * Real.log (2 * (n : ℝ)) + M₀ * Real.sqrt (Real.log (2 / δ))) / v) =
          (2 * C₃ * D₀) * (Real.log (2 * (n : ℝ)) / v) +
            (2 * C₃ * M₀) * (Real.sqrt (Real.log (2 / δ)) / v) := by
      ring
    rw [hsplit]
    have hpart1 :
        (2 * C₃ * D₀) * (Real.log (2 * (n : ℝ)) / v) ≤ (36 * c₃ / Real.sqrt C_K) * ε := by
      have hc1 : 2 * C₃ * D₀ ≤ 6 * c₃ * D := by
        rw [hD₀_eq]
        nlinarith only [hC₃_le, hD_pos]
      calc (2 * C₃ * D₀) * (Real.log (2 * (n : ℝ)) / v)
          ≤ (6 * c₃ * D) * (6 * ε / (Real.sqrt C_K * D)) :=
            mul_le_mul hc1 hterm1_ratio (div_nonneg hlog2n_nn hv_pos.le) (by positivity)
        _ = (36 * c₃ / Real.sqrt C_K) * ε := by
            field_simp [hsqrtCK_pos.ne', hD_pos.ne']; ring
    have hpart2 :
        (2 * C₃ * M₀) * (Real.sqrt (Real.log (2 / δ)) / v) ≤ (6 * c₃ / Real.sqrt C_K) * ε := by
      have hc2 : 2 * C₃ * M₀ ≤ 6 * c₃ * D := by
        nlinarith only [hC₃_le, hM₀_le, hM₀_pos, hc₃_pos]
      calc (2 * C₃ * M₀) * (Real.sqrt (Real.log (2 / δ)) / v)
          ≤ (6 * c₃ * D) * (ε / (Real.sqrt C_K * D)) :=
            mul_le_mul hc2 hterm2_ratio (div_nonneg (Real.sqrt_nonneg _) hv_pos.le) (by positivity)
        _ = (6 * c₃ / Real.sqrt C_K) * ε := by
            field_simp [hsqrtCK_pos.ne', hD_pos.ne']
    have h42 : (42 * c₃ / Real.sqrt C_K) * ε ≤ ε := by
      have hdiv_le1 : 42 * c₃ / Real.sqrt C_K ≤ 1 := by
        rw [div_le_one hsqrtCK_pos]
        linarith
      simpa using mul_le_mul_of_nonneg_right hdiv_le1 hε0.le
    linarith [show (36 * c₃ / Real.sqrt C_K) * ε + (6 * c₃ / Real.sqrt C_K) * ε =
      (42 * c₃ / Real.sqrt C_K) * ε by ring]
  · rw [if_neg hm2] at hn_ge
    have hm_ge3 : 3 ≤ m := by omega
    have hm_pos : (0 : ℝ) < (m : ℝ) := Nat.cast_pos.mpr (by omega)
    have h_n_m : (12 * c₃ * (D / ε)) ^ m ≤ (n : ℝ) := by
      have h1 : (12 * c₃) ^ m * (D / ε) ^ m ≤ C_K * (D / ε) ^ m :=
        mul_le_mul_of_nonneg_right hCK_ge12m (by positivity)
      have h2 : C_K * (D / ε) ^ m ≤ C_K * ((D / ε) ^ m + (D / ε) ^ 2 * Real.log ((2 : ℝ) / δ)) :=
        mul_le_mul_of_nonneg_left (le_add_of_nonneg_right (by positivity)) hCK_pos.le
      rw [mul_pow]
      exact le_trans h1 (le_trans h2 hn_ge)
    have h_rpow : 12 * c₃ * (D / ε) ≤ (n : ℝ) ^ ((1 : ℝ) / (m : ℝ)) := by
      set a : ℝ := 12 * c₃ * (D / ε)
      have ha_pos : 0 < a := by positivity
      have h1 : (a ^ m) ^ ((1 : ℝ) / (m : ℝ)) ≤ (n : ℝ) ^ ((1 : ℝ) / (m : ℝ)) :=
        Real.rpow_le_rpow (by positivity) h_n_m (by positivity)
      have h2 : (a ^ m) ^ ((1 : ℝ) / (m : ℝ)) = a := by
        rw [← Real.rpow_natCast a m, ← Real.rpow_mul ha_pos.le]
        have hm_inv : (m : ℝ) * ((1 : ℝ) / (m : ℝ)) = 1 := by field_simp [hm_pos.ne']
        rw [hm_inv, Real.rpow_one]
      rwa [h2] at h1
    have h_term1 : 2 * C₃ * D₀ * ((n : ℝ) ^ (-(1 : ℝ) / (m : ℝ))) ≤ ε / 2 := by
      have hinv : (n : ℝ) ^ (-(1 : ℝ) / (m : ℝ)) ≤ (12 * c₃ * (D / ε))⁻¹ := by
        rw [neg_div, Real.rpow_neg hn_pos.le]
        exact inv_anti₀ (by positivity) h_rpow
      have hc1 : 2 * C₃ * D₀ ≤ 6 * c₃ * D := by
        rw [hD₀_eq]
        nlinarith only [hC₃_le, hD_pos]
      calc 2 * C₃ * D₀ * ((n : ℝ) ^ (-(1 : ℝ) / (m : ℝ)))
          ≤ (6 * c₃ * D) * (12 * c₃ * (D / ε))⁻¹ :=
            mul_le_mul hc1 hinv (Real.rpow_nonneg hn_pos.le _) (by positivity)
        _ = ε / 2 := by
            field_simp [hc₃_pos.ne', hD_pos.ne', hε0.ne']; ring
    have h_n_2 : (12 * c₃) ^ 2 * (D / ε) ^ 2 * Real.log ((2 : ℝ) / δ) ≤ (n : ℝ) := by
      have h12_72 : (12 * c₃) ^ 2 ≤ C_K :=
        le_trans (pow_le_pow_left₀ (by positivity) (by linarith) 2) hCK_ge72
      have h1 : (12 * c₃) ^ 2 * ((D / ε) ^ 2 * Real.log ((2 : ℝ) / δ)) ≤
          C_K * ((D / ε) ^ 2 * Real.log ((2 : ℝ) / δ)) :=
        mul_le_mul_of_nonneg_right h12_72 (by positivity)
      have h2 : C_K * ((D / ε) ^ 2 * Real.log ((2 : ℝ) / δ)) ≤
          C_K * ((D / ε) ^ m + (D / ε) ^ 2 * Real.log ((2 : ℝ) / δ)) :=
        mul_le_mul_of_nonneg_left (le_add_of_nonneg_left (by positivity)) hCK_pos.le
      linarith [show (12 * c₃) ^ 2 * ((D / ε) ^ 2 * Real.log ((2 : ℝ) / δ)) =
        (12 * c₃) ^ 2 * (D / ε) ^ 2 * Real.log ((2 : ℝ) / δ) by ring]
    have h_term2 : 2 * C₃ * M₀ * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ)) ≤ ε / 2 := by
      have hdiv : Real.log ((2 : ℝ) / δ) / (n : ℝ) ≤ (ε / (12 * c₃ * D)) ^ 2 := by
        rw [div_le_iff₀ hn_pos]
        have hrhs : (ε / (12 * c₃ * D)) ^ 2 * (n : ℝ) ≥
            (ε / (12 * c₃ * D)) ^ 2 * ((12 * c₃) ^ 2 * (D / ε) ^ 2 * Real.log ((2 : ℝ) / δ)) :=
          mul_le_mul_of_nonneg_left h_n_2 (by positivity)
        have hcancel :
            (ε / (12 * c₃ * D)) ^ 2 * ((12 * c₃) ^ 2 * (D / ε) ^ 2 * Real.log ((2 : ℝ) / δ)) =
              Real.log ((2 : ℝ) / δ) := by
          field_simp [hc₃_pos.ne', hD_pos.ne', hε0.ne']
        linarith
      have hsqrt : Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ)) ≤ ε / (12 * c₃ * D) := by
        calc Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ))
            ≤ Real.sqrt ((ε / (12 * c₃ * D)) ^ 2) := Real.sqrt_le_sqrt hdiv
          _ = ε / (12 * c₃ * D) := Real.sqrt_sq (by positivity)
      have hc2 : 2 * C₃ * M₀ ≤ 6 * c₃ * D := by
        nlinarith only [hC₃_le, hM₀_le, hM₀_pos, hc₃_pos]
      calc 2 * C₃ * M₀ * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ))
          ≤ (6 * c₃ * D) * (ε / (12 * c₃ * D)) :=
            mul_le_mul hc2 hsqrt (Real.sqrt_nonneg _) (by positivity)
        _ = ε / 2 := by
            field_simp [hc₃_pos.ne', hD_pos.ne']; ring
    linarith

end UL.Proof_thm_C_1_Race3

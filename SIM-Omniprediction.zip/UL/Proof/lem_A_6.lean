import UL.Stmt.lem_A_6
import UL.Stmt.lem_A_1
import UL.Stmt.lem_A_3
import UL.Stmt.lem_A_4
import UL.Stmt.lem_A_5
import UL.Proof.lem_A_6.H1_FitAndTransfer
import UL.Proof.lem_A_6.H2_DanskinStrongConv
import UL.Proof.lem_A_6.H3_RiskAndGap

set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_lem_A_6 (h_lem_A_1 : S_lem_A_1) (h_lem_A_3 : S_lem_A_3) (h_lem_A_4 : S_lem_A_4) (h_lem_A_5 : S_lem_A_5) : S_lem_A_6 := by
  let _ := h_lem_A_1
  unfold S_lem_A_6
  intro Ω _ μ _ d K hK β B hβ hB X Y hX hY hX_int 𝒲 h𝒲 W V _hW hV Φ hΦ
  rcases eq_or_lt_of_le hK with hK1 | hK_gt1
  · subst hK1
    exact Proof_lem_A_6.case_K_eq_one Ω μ d β B hβ hB X Y hX hY 𝒲 h𝒲 W V Φ
  · have hK2 : 2 ≤ K := hK_gt1
    have hB_pos : 0 < B := lt_of_lt_of_le hβ hB
    obtain ⟨ρ, hProf, hPW_eq⟩ :=
      Proof_lem_A_6.linearFittedPrediction_spec μ hK hB_pos W hX hY
    let S : Ω → ZeroSumSubspace K := linearScore W X
    have hS_meas : Measurable S := W.continuous.measurable.comp hX
    have hS_int : MeasureTheory.Integrable S μ := by
      refine (hX_int.const_mul ‖W‖).mono' hS_meas.aestronglyMeasurable ?_
      exact Filter.Eventually.of_forall (fun ω => W.le_opNorm (X ω))
    have hρ_cont : Continuous ρ := hProf.2.1.2.1.continuous
    have hρ_simp : ∀ s, ρ s ∈ Simplex K := hProf.2.1.2.2
    let P_W : Ω → EuclideanSpace ℝ (Fin K) := linearFittedPrediction μ B W X Y
    have hPW_meas : Measurable P_W := by
      rw [show P_W = fun ω => ρ (S ω) from hPW_eq]
      exact hρ_cont.measurable.comp hS_meas
    have hPW_simp : ∀ ω, P_W ω ∈ Simplex K := by
      intro ω
      rw [show P_W ω = ρ (W (X ω)) from congr_fun hPW_eq ω]
      exact hρ_simp (W (X ω))
    have hsupp_ρ := Proof_lem_A_6.apply_lem_A_3 h_lem_A_3 μ hK2 hB_pos hS_meas hY hProf
    obtain ⟨hsmooth_ρ, hown_ρ⟩ :=
      Proof_lem_A_6.apply_lem_A_4 h_lem_A_4 μ hB_pos hS_meas hS_int hY hProf
    let F : Simplex K → ℝ := Proof_lem_A_6.shiftedEntropy Φ B
    have hF_cont : Continuous F := Proof_lem_A_6.shiftedEntropy_continuous hΦ.2.1 B
    have hF_conv : ConvexOn ℝ (Simplex K) (extendSimplex F) :=
      Proof_lem_A_6.shiftedEntropy_convexOn hΦ hB
    have hF_diff := Proof_lem_A_6.shiftedEntropy_hasFaceGrad hΦ hB_pos
    obtain ⟨hprod_le_ρ, hprod_int_ρ⟩ :=
      Proof_lem_A_6.apply_lem_A_5 h_lem_A_5 μ hK2 hS_meas hY hρ_cont hρ_simp
        hsupp_ρ hsmooth_ρ F hF_cont hF_conv hF_diff
    have hsupp : ∀ j : Fin K, ∀ᵐ ω ∂μ, P_W ω j = 0 → oneHotLabel Y ω j = 0 := by
      simpa [P_W, hPW_eq, S, linearScore] using hsupp_ρ
    have hprod_le : ∫ ω, inner ℝ (fitResidual P_W Y ω)
        (faceGrad F (posSupport (P_W ω)) (P_W ω)) ∂μ ≤ 0 := by
      simpa [P_W, hPW_eq, S, linearScore, F] using hprod_le_ρ
    have hprod_int : MeasureTheory.Integrable (fun ω => inner ℝ (fitResidual P_W Y ω)
        (faceGrad F (posSupport (P_W ω)) (P_W ω))) μ := by
      simpa [P_W, hPW_eq, S, linearScore, F] using hprod_int_ρ
    have hown : ∫ ω, inner ℝ (fitResidual P_W Y ω) (P_W ω - uniformVec K) ∂μ ≤
        B * ∫ ω, inner ℝ (fitResidual P_W Y ω) (W (X ω) : EuclideanSpace ℝ (Fin K)) ∂μ := by
      simpa [P_W, hPW_eq, S, linearScore] using hown_ρ
    obtain ⟨h_ae_fin, h_fore_int, h_fore_bound⟩ :=
      Proof_lem_A_6.forecast_loss_ae_and_bound μ hΦ hB_pos hPW_meas hY hPW_simp
        hsupp hprod_le hprod_int
    obtain ⟨h_comp_int, h_D_int, _h_rV_int, h_comp_decomp⟩ :=
      Proof_lem_A_6.comparator_loss_integrable_and_decomp μ hK hΦ hPW_meas hX hY
        hX_int hPW_simp V
    have h_gap : (∫ ω, inner ℝ (fitResidual P_W Y ω) (W (X ω) : EuclideanSpace ℝ (Fin K)) ∂μ) -
        (∫ ω, inner ℝ (fitResidual P_W Y ω) (V (X ω) : EuclideanSpace ℝ (Fin K)) ∂μ) ≤
        certificateGap μ B 𝒲 X Y W := by
      unfold certificateGap
      exact Proof_lem_A_6.predictionCertificateGap_ge μ h𝒲 hV hPW_meas hX hY hX_int hPW_simp
    have h_own_div : (1 / B) * ∫ ω, inner ℝ (fitResidual P_W Y ω) (P_W ω - uniformVec K) ∂μ ≤
        ∫ ω, inner ℝ (fitResidual P_W Y ω) (W (X ω) : EuclideanSpace ℝ (Fin K)) ∂μ := by
      rw [one_div, inv_mul_le_iff₀ hB_pos]
      exact hown
    have h_quad := Proof_lem_A_6.quadratic_gap_integral_le μ hK hΦ hPW_meas hX hPW_simp V h_D_int
    dsimp only
    refine ⟨h_ae_fin, h_fore_int, h_comp_int, ?_, ?_⟩
    · linarith
    · change certificateGap μ B 𝒲 X Y W -
          ∫ ω, (extendSimplex Φ (P_W ω) + matchingPotential Φ (V (X ω)) -
            inner ℝ (P_W ω - uniformVec K) (V (X ω) : EuclideanSpace ℝ (Fin K))) ∂μ ≤
        certificateGap μ B 𝒲 X Y W -
          (1 / (2 * β)) * ∫ ω, ‖P_W ω - Proof_lem_A_6.qPhiMap Φ (V (X ω))‖ ^ 2 ∂μ
      linarith

end UL

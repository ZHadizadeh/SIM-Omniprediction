import Mathlib
import UL.Stmt.cor_A_8
import UL.Stmt.lem_A_1
import UL.Stmt.lem_A_3
import UL.Stmt.lem_A_4
import UL.Stmt.lem_A_5
import UL.Proof.cor_A_8.H1_SimplexGrad

set_option autoImplicit false

namespace UL.Proof_cor_A_8

open Set Filter Topology MeasureTheory

lemma measurable_comp_of_continuousOn {Ω β γ : Type*} [MeasurableSpace Ω]
    [TopologicalSpace β] [MeasurableSpace β] [OpensMeasurableSpace β]
    [TopologicalSpace γ] [MeasurableSpace γ] [BorelSpace γ]
    {s : Set β} {f : β → γ} {g : Ω → β}
    (hf : ContinuousOn f s) (hg : Measurable g) (hgs : ∀ ω, g ω ∈ s) :
    Measurable (fun ω => f (g ω)) :=
  (continuousOn_iff_continuous_restrict.mp hf).measurable.comp (hg.subtype_mk (h := hgs))

lemma measurable_matchingLoss_comp {Ω : Type*} [MeasurableSpace Ω] {K : ℕ} (hK : 1 ≤ K)
    {Φ : UL.Simplex K → ℝ} (hΦ_cont : Continuous Φ)
    {g : Ω → EuclideanSpace ℝ (Fin K)} {Y : Ω → Fin K}
    (hg : Measurable g) (hY : Measurable Y) :
    Measurable (fun ω => UL.matchingLoss Φ (g ω) (Y ω)) := by
  have hpot : Measurable (fun ω => UL.matchingPotential Φ (g ω)) :=
    (continuous_matchingPotential hK hΦ_cont).measurable.comp hg
  have hcoord : Measurable (fun ω => g ω (Y ω)) := by
    have hEq : (fun ω => g ω (Y ω)) = fun ω => inner ℝ (g ω) (UL.oneHotLabel Y ω) := by
      funext ω
      exact (UL.Proof_lem_A_1.inner_single_right (g ω) (Y ω)).symm
    rw [hEq]
    exact hg.inner (UL.Proof_lem_A_4.oneHotLabel_measurable hY)
  exact hpot.sub hcoord

/-! ### Uniqueness a.e. of Lipschitz least-squares fits -/

lemma lsFit_ae_eq.{u} {Ω : Type u} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {K : ℕ} {B : ℝ} {S : Ω → UL.ZeroSumSubspace K} {Y : Ω → Fin K}
    (hS_meas : Measurable S) (hY_meas : Measurable Y)
    {P₁ P₂ : Ω → EuclideanSpace ℝ (Fin K)}
    (hFit₁ : UL.IsLipschitzLSFit μ B S Y P₁)
    (hFit₂ : UL.IsLipschitzLSFit μ B S Y P₂) :
    P₁ =ᵐ[μ] P₂ := by
  obtain ⟨ρ₁, hProf₁, rfl⟩ := hFit₁
  obtain ⟨ρ₂, hProf₂, rfl⟩ := hFit₂
  let ρ_mid : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) :=
    fun s => (1 - (1 / 2 : ℝ)) • ρ₁ s + (1 / 2 : ℝ) • ρ₂ s
  have hρ_mid : ρ_mid ∈ UL.LipschitzSimplexMaps K B :=
    UL.Proof_lem_A_4.lipschitzSimplexMaps_convex_comb hProf₁.2.1 hProf₂.2.1
      (by norm_num) (by norm_num)
  let eY : Ω → EuclideanSpace ℝ (Fin K) := UL.oneHotLabel Y
  have hP₁_meas : Measurable (fun ω => ρ₁ (S ω)) := hProf₁.2.1.2.1.continuous.measurable.comp hS_meas
  have hP₂_meas : Measurable (fun ω => ρ₂ (S ω)) := hProf₂.2.1.2.1.continuous.measurable.comp hS_meas
  have hZ_meas : Measurable eY := UL.Proof_lem_A_4.oneHotLabel_measurable hY_meas
  have hInt₁ : Integrable (fun ω => ‖ρ₁ (S ω) - eY ω‖ ^ 2) μ :=
    UL.Proof_lem_A_4.integrable_of_aestronglyMeasurable_bounded
      (((hP₁_meas.sub hZ_meas).norm).pow_const 2).aestronglyMeasurable 4 (fun ω => by
        rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
        have h := UL.Proof_lem_A_4.fitResidual_norm_le_two Y (fun ω' => hProf₁.2.1.2.2 (S ω')) ω
        have h0 := norm_nonneg (ρ₁ (S ω) - eY ω)
        dsimp [UL.fitResidual, eY] at h ⊢
        nlinarith)
  have hInt₂ : Integrable (fun ω => ‖ρ₂ (S ω) - eY ω‖ ^ 2) μ :=
    UL.Proof_lem_A_4.integrable_of_aestronglyMeasurable_bounded
      (((hP₂_meas.sub hZ_meas).norm).pow_const 2).aestronglyMeasurable 4 (fun ω => by
        rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
        have h := UL.Proof_lem_A_4.fitResidual_norm_le_two Y (fun ω' => hProf₂.2.1.2.2 (S ω')) ω
        have h0 := norm_nonneg (ρ₂ (S ω) - eY ω)
        dsimp [UL.fitResidual, eY] at h ⊢
        nlinarith)
  have hInt_diff : Integrable (fun ω => ‖ρ₁ (S ω) - ρ₂ (S ω)‖ ^ 2) μ :=
    UL.Proof_lem_A_4.integrable_of_aestronglyMeasurable_bounded
      (((hP₁_meas.sub hP₂_meas).norm).pow_const 2).aestronglyMeasurable 4 (fun ω => by
        rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
        have hb : ‖ρ₁ (S ω) - ρ₂ (S ω)‖ ≤ 2 := by
          calc ‖ρ₁ (S ω) - ρ₂ (S ω)‖ ≤ ‖ρ₁ (S ω)‖ + ‖ρ₂ (S ω)‖ := norm_sub_le _ _
            _ ≤ 1 + 1 := add_le_add (UL.Proof_lem_A_4.simplex_norm_le_one (hProf₁.2.1.2.2 (S ω)))
                (UL.Proof_lem_A_4.simplex_norm_le_one (hProf₂.2.1.2.2 (S ω)))
            _ = 2 := by norm_num
        have h0 := norm_nonneg (ρ₁ (S ω) - ρ₂ (S ω))
        nlinarith)
  have hpara : ∀ ω : Ω, ‖ρ_mid (S ω) - eY ω‖ ^ 2 =
      (1 / 2 : ℝ) * ‖ρ₁ (S ω) - eY ω‖ ^ 2 + (1 / 2 : ℝ) * ‖ρ₂ (S ω) - eY ω‖ ^ 2 -
        (1 / 4 : ℝ) * ‖ρ₁ (S ω) - ρ₂ (S ω)‖ ^ 2 := by
    intro ω
    set u₁ := ρ₁ (S ω) - eY ω
    set u₂ := ρ₂ (S ω) - eY ω
    have hmid : ρ_mid (S ω) - eY ω = (1 / 2 : ℝ) • (u₁ + u₂) := by
      dsimp [ρ_mid, u₁, u₂]
      ext j
      simp only [PiLp.sub_apply, PiLp.add_apply, PiLp.smul_apply, smul_eq_mul]
      ring
    have hdiff : ρ₁ (S ω) - ρ₂ (S ω) = u₁ - u₂ := by dsimp [u₁, u₂]; abel
    rw [hmid, hdiff, norm_smul, Real.norm_eq_abs, mul_pow, sq_abs,
      norm_add_sq_real u₁ u₂, norm_sub_sq_real u₁ u₂]
    ring
  have hInt_half₁ : Integrable (fun ω => (1 / 2 : ℝ) * ‖ρ₁ (S ω) - eY ω‖ ^ 2) μ :=
    hInt₁.const_mul (1 / 2)
  have hInt_half₂ : Integrable (fun ω => (1 / 2 : ℝ) * ‖ρ₂ (S ω) - eY ω‖ ^ 2) μ :=
    hInt₂.const_mul (1 / 2)
  have hInt_sum12 : Integrable (fun ω =>
      (1 / 2 : ℝ) * ‖ρ₁ (S ω) - eY ω‖ ^ 2 + (1 / 2 : ℝ) * ‖ρ₂ (S ω) - eY ω‖ ^ 2) μ :=
    hInt_half₁.add hInt_half₂
  have hInt_quar : Integrable (fun ω => (1 / 4 : ℝ) * ‖ρ₁ (S ω) - ρ₂ (S ω)‖ ^ 2) μ :=
    hInt_diff.const_mul (1 / 4)
  have h_risk_mid : UL.lsFitRisk μ S Y ρ_mid =
      (1 / 2 : ℝ) * UL.lsFitRisk μ S Y ρ₁ + (1 / 2 : ℝ) * UL.lsFitRisk μ S Y ρ₂ -
        (1 / 4 : ℝ) * ∫ ω, ‖ρ₁ (S ω) - ρ₂ (S ω)‖ ^ 2 ∂μ := by
    unfold UL.lsFitRisk
    rw [integral_congr_ae (Eventually.of_forall hpara),
      integral_sub hInt_sum12 hInt_quar,
      integral_add hInt_half₁ hInt_half₂,
      integral_const_mul, integral_const_mul, integral_const_mul]
  have hmin₁ : UL.lsFitRisk μ S Y ρ₁ ≤ UL.lsFitRisk μ S Y ρ_mid := hProf₁.2.2 hρ_mid
  have hmin₂ : UL.lsFitRisk μ S Y ρ₂ ≤ UL.lsFitRisk μ S Y ρ_mid := hProf₂.2.2 hρ_mid
  have h_int_le : ∫ ω, ‖ρ₁ (S ω) - ρ₂ (S ω)‖ ^ 2 ∂μ ≤ 0 := by linarith
  have h_int_zero : ∫ ω, ‖ρ₁ (S ω) - ρ₂ (S ω)‖ ^ 2 ∂μ = 0 :=
    le_antisymm h_int_le (integral_nonneg fun _ => sq_nonneg _)
  have hae_zero : (fun ω => ‖ρ₁ (S ω) - ρ₂ (S ω)‖ ^ 2) =ᵐ[μ] 0 :=
    (integral_eq_zero_iff_of_nonneg (fun _ => sq_nonneg _) hInt_diff).mp h_int_zero
  filter_upwards [hae_zero] with ω hω
  exact sub_eq_zero.mp (norm_eq_zero.mp (sq_eq_zero_iff.mp hω))

lemma profile_ae_eq_linearFittedPrediction.{u} {Ω : Type u} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {d K : ℕ} {B : ℝ}
    {W : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K}
    {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin K}
    (hX : Measurable X) (hY : Measurable Y)
    {ρ : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hρ : UL.IsLipschitzLSFitProfile μ B (UL.linearScore W X) Y ρ) :
    (fun ω => ρ (W (X ω))) =ᵐ[μ] UL.linearFittedPrediction μ B W X Y := by
  classical
  have hS_meas : Measurable (UL.linearScore W X) := W.continuous.measurable.comp hX
  have hFit₁ : UL.IsLipschitzLSFit μ B (UL.linearScore W X) Y (fun ω => ρ (W (X ω))) :=
    ⟨ρ, hρ, rfl⟩
  have hex : ∃ P, UL.IsLipschitzLSFit μ B (UL.linearScore W X) Y P := ⟨_, hFit₁⟩
  have hFit₂ : UL.IsLipschitzLSFit μ B (UL.linearScore W X) Y
      (UL.linearFittedPrediction μ B W X Y) := by
    unfold UL.linearFittedPrediction UL.fittedPrediction
    rw [dif_pos hex]
    exact Classical.choose_spec hex
  exact lsFit_ae_eq hS_meas hY hFit₁ hFit₂

/-! ### Universe-polymorphic pushforward bridge along `ULift` -/

lemma isLipschitzLSFitProfile_ulift.{u, v} {Ω : Type u} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] {d K : ℕ} {B : ℝ}
    {W : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K}
    {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin K}
    (hX : Measurable X) (hY : Measurable Y)
    {ρ : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hρ : UL.IsLipschitzLSFitProfile μ B (UL.linearScore W X) Y ρ) :
    let e : ULift.{v} (EuclideanSpace ℝ (Fin d) × Fin K) ≃ᵐ
        (EuclideanSpace ℝ (Fin d) × Fin K) := MeasurableEquiv.ulift
    let ψ : Ω → ULift.{v} (EuclideanSpace ℝ (Fin d) × Fin K) := fun ω => e.symm (X ω, Y ω)
    let μ' := Measure.map ψ μ
    let X' := fun z => (e z).1
    let Y' := fun z => (e z).2
    UL.IsLipschitzLSFitProfile μ' B (UL.linearScore W X') Y' ρ := by
  intro e ψ μ' X' Y'
  have hψ : Measurable ψ := e.symm.measurable.comp (hX.prodMk hY)
  refine ⟨hρ.1, hρ.2.1, fun ρ' hρ' => ?_⟩
  have h_risk_eq : ∀ τ ∈ UL.LipschitzSimplexMaps K B,
      UL.lsFitRisk μ' (UL.linearScore W X') Y' τ =
        UL.lsFitRisk μ (UL.linearScore W X) Y τ := by
    intro τ hτ
    unfold UL.lsFitRisk
    have hX'_meas : Measurable X' := measurable_fst.comp e.measurable
    have hY'_meas : Measurable Y' := measurable_snd.comp e.measurable
    have h_meas : Measurable (fun z => ‖τ (W (X' z)) - UL.oneHotLabel Y' z‖ ^ 2) :=
      (((hτ.2.1.continuous.measurable.comp (W.continuous.measurable.comp hX'_meas)).sub
        (UL.Proof_lem_A_4.oneHotLabel_measurable hY'_meas)).norm).pow_const 2
    exact integral_map hψ.aemeasurable h_meas.aestronglyMeasurable
  change UL.lsFitRisk μ' (UL.linearScore W X') Y' ρ ≤
    UL.lsFitRisk μ' (UL.linearScore W X') Y' ρ'
  rw [h_risk_eq ρ hρ.2.1, h_risk_eq ρ' hρ']
  exact hρ.2.2 hρ'

lemma extract_support_from_lem_A_3.{u, u₃}
    (h_lem_A_3 : UL.S_lem_A_3.{u₃})
    {Ω : Type u} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {d K : ℕ} (hK2 : 2 ≤ K) {β : ℝ} (hβ : 0 < β)
    {W : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K}
    {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin K}
    (hX : Measurable X) (hY : Measurable Y)
    {ρ : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hρ : UL.IsLipschitzLSFitProfile μ β (UL.linearScore W X) Y ρ) :
    ∀ j : Fin K, ∀ᵐ ω ∂μ, ρ (W (X ω)) j = 0 → UL.oneHotLabel Y ω j = 0 := by
  unfold UL.S_lem_A_3 at h_lem_A_3
  let e : ULift.{u₃} (EuclideanSpace ℝ (Fin d) × Fin K) ≃ᵐ
      (EuclideanSpace ℝ (Fin d) × Fin K) := MeasurableEquiv.ulift
  let ψ : Ω → ULift.{u₃} (EuclideanSpace ℝ (Fin d) × Fin K) := fun ω => e.symm (X ω, Y ω)
  have hψ : Measurable ψ := e.symm.measurable.comp (hX.prodMk hY)
  let μ' : Measure (ULift.{u₃} (EuclideanSpace ℝ (Fin d) × Fin K)) := Measure.map ψ μ
  haveI : IsProbabilityMeasure μ' := Measure.isProbabilityMeasure_map hψ.aemeasurable
  let X' : ULift.{u₃} (EuclideanSpace ℝ (Fin d) × Fin K) → EuclideanSpace ℝ (Fin d) :=
    fun z => (e z).1
  let Y' : ULift.{u₃} (EuclideanSpace ℝ (Fin d) × Fin K) → Fin K := fun z => (e z).2
  have hX'_meas : Measurable X' := measurable_fst.comp e.measurable
  have hY'_meas : Measurable Y' := measurable_snd.comp e.measurable
  have hS'_meas : Measurable (UL.linearScore W X') := W.continuous.measurable.comp hX'_meas
  have hProf' := isLipschitzLSFitProfile_ulift.{u, u₃} hX hY hρ
  have hFit' : UL.IsLipschitzLSFit μ' β (UL.linearScore W X') Y'
      (fun z => ρ (W (X' z))) := ⟨ρ, hProf', rfl⟩
  have hsupp' := (h_lem_A_3 _ μ' K hK2 β hβ (UL.linearScore W X') Y' hS'_meas hY'_meas
    (fun z => ρ (W (X' z))) hFit').1
  intro j
  have hP'_j_meas : Measurable (fun z => ρ (W (X' z)) j) :=
    (EuclideanSpace.proj j).continuous.measurable.comp
      (hρ.2.1.2.1.continuous.measurable.comp hS'_meas)
  have hZ'_j_meas : Measurable (fun z => UL.oneHotLabel Y' z j) :=
    (EuclideanSpace.proj j).continuous.measurable.comp
      (UL.Proof_lem_A_4.oneHotLabel_measurable hY'_meas)
  have h_set_meas : MeasurableSet
      {z : ULift.{u₃} (EuclideanSpace ℝ (Fin d) × Fin K) |
        ρ (W (X' z)) j = 0 → UL.oneHotLabel Y' z j = 0} := by
    have hEq : {z | ρ (W (X' z)) j = 0 → UL.oneHotLabel Y' z j = 0} =
        {z | ρ (W (X' z)) j = 0}ᶜ ∪ {z | UL.oneHotLabel Y' z j = 0} := by
      ext z; simp [imp_iff_not_or]
    rw [hEq]
    exact (measurableSet_eq_fun hP'_j_meas measurable_const).compl.union
      (measurableSet_eq_fun hZ'_j_meas measurable_const)
  exact (ae_map_iff hψ.aemeasurable h_set_meas).mp (hsupp' j)

lemma extract_from_lem_A_4.{u, u₄}
    (h_lem_A_4 : UL.S_lem_A_4.{u₄})
    {Ω : Type u} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {d K : ℕ} {β : ℝ} (hβ : 0 < β)
    {W : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K}
    {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin K}
    (hX : Measurable X) (hY : Measurable Y)
    (hX_int : Integrable (fun ω => ‖X ω‖) μ)
    {ρ : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hρ : UL.IsLipschitzLSFitProfile μ β (UL.linearScore W X) Y ρ) :
    let P := fun ω => ρ (W (X ω))
    (∫ ω, UL.fitResidual P Y ω ∂μ = 0) ∧
    (∀ (f : UL.ZeroSumSubspace K → ℝ),
      Differentiable ℝ f →
      ConvexOn ℝ Set.univ f →
      (∃ L : NNReal, LipschitzWith L (gradient f)) →
      ∫ ω, inner ℝ (UL.fitResidual P Y ω)
        (↑(gradient f ((UL.ZeroSumSubspace K).orthogonalProjection (P ω - UL.uniformVec K))) :
          EuclideanSpace ℝ (Fin K)) ∂μ ≤ 0) ∧
    (β * ∫ ω, inner ℝ (UL.fitResidual P Y ω) (W (X ω) : EuclideanSpace ℝ (Fin K)) ∂μ ≥
      ∫ ω, inner ℝ (UL.fitResidual P Y ω) (P ω - UL.uniformVec K) ∂μ) := by
  intro P
  unfold UL.S_lem_A_4 at h_lem_A_4
  let e : ULift.{u₄} (EuclideanSpace ℝ (Fin d) × Fin K) ≃ᵐ
      (EuclideanSpace ℝ (Fin d) × Fin K) := MeasurableEquiv.ulift
  let ψ : Ω → ULift.{u₄} (EuclideanSpace ℝ (Fin d) × Fin K) := fun ω => e.symm (X ω, Y ω)
  have hψ : Measurable ψ := e.symm.measurable.comp (hX.prodMk hY)
  have hψ_ae : AEMeasurable ψ μ := hψ.aemeasurable
  let μ' : Measure (ULift.{u₄} (EuclideanSpace ℝ (Fin d) × Fin K)) := Measure.map ψ μ
  haveI : IsProbabilityMeasure μ' := Measure.isProbabilityMeasure_map hψ.aemeasurable
  let X' : ULift.{u₄} (EuclideanSpace ℝ (Fin d) × Fin K) → EuclideanSpace ℝ (Fin d) :=
    fun z => (e z).1
  let Y' : ULift.{u₄} (EuclideanSpace ℝ (Fin d) × Fin K) → Fin K := fun z => (e z).2
  let P' : ULift.{u₄} (EuclideanSpace ℝ (Fin d) × Fin K) → EuclideanSpace ℝ (Fin K) :=
    fun z => ρ (W (X' z))
  have hX'_meas : Measurable X' := measurable_fst.comp e.measurable
  have hY'_meas : Measurable Y' := measurable_snd.comp e.measurable
  have hS'_meas : Measurable (UL.linearScore W X') := W.continuous.measurable.comp hX'_meas
  have hP'_meas : Measurable P' := hρ.2.1.2.1.continuous.measurable.comp hS'_meas
  have hr'_meas : Measurable (UL.fitResidual P' Y') :=
    hP'_meas.sub (UL.Proof_lem_A_4.oneHotLabel_measurable hY'_meas)
  have hX'_norm_int : Integrable (fun z => ‖X' z‖) μ' :=
    (integrable_map_measure hX'_meas.norm.aestronglyMeasurable hψ.aemeasurable).mpr hX_int
  have hS'_int : Integrable (UL.linearScore W X') μ' := by
    refine (hX'_norm_int.const_mul ‖W‖).mono' hS'_meas.aestronglyMeasurable ?_
    exact Eventually.of_forall (fun z => W.le_opNorm (X' z))
  have hProf' := isLipschitzLSFitProfile_ulift.{u, u₄} hX hY hρ
  have hFit' : UL.IsLipschitzLSFit μ' β (UL.linearScore W X') Y' P' := ⟨ρ, hProf', rfl⟩
  obtain ⟨h_mean', h_smooth', h_own'⟩ :=
    h_lem_A_4 _ μ' K β (UL.linearScore W X') Y' P' hβ hS'_int hY'_meas hFit'
  refine ⟨?_, ?_, ?_⟩
  · have h_eq : ∫ z, UL.fitResidual P' Y' z ∂μ' = ∫ ω, UL.fitResidual P Y ω ∂μ :=
      integral_map hψ_ae hr'_meas.aestronglyMeasurable
    rwa [h_eq] at h_mean'
  · intro f hf_diff hf_conv hf_lip
    obtain ⟨L, hL⟩ := hf_lip
    have hgrad_cont : Continuous (gradient f) := hL.continuous
    have hg_meas : Measurable (fun z => inner ℝ (UL.fitResidual P' Y' z)
        (↑(gradient f ((UL.ZeroSumSubspace K).orthogonalProjection (P' z - UL.uniformVec K))) :
          EuclideanSpace ℝ (Fin K))) := by
      refine hr'_meas.inner ?_
      exact (UL.ZeroSumSubspace K).subtypeL.continuous.measurable.comp
        (hgrad_cont.measurable.comp
          ((UL.ZeroSumSubspace K).orthogonalProjection.continuous.measurable.comp
            (hP'_meas.sub measurable_const)))
    have h_eq := integral_map hψ_ae hg_meas.aestronglyMeasurable
    have h_res := h_smooth' f hf_diff hf_conv ⟨L, hL⟩
    rwa [h_eq] at h_res
  · have h_lhs_meas : Measurable (fun z =>
        inner ℝ (UL.fitResidual P' Y' z) (W (X' z) : EuclideanSpace ℝ (Fin K))) :=
      hr'_meas.inner ((UL.ZeroSumSubspace K).subtypeL.continuous.measurable.comp hS'_meas)
    have h_rhs_meas : Measurable (fun z =>
        inner ℝ (UL.fitResidual P' Y' z) (P' z - UL.uniformVec K)) :=
      hr'_meas.inner (hP'_meas.sub measurable_const)
    have h_eq1 := integral_map hψ_ae h_lhs_meas.aestronglyMeasurable
    have h_eq2 := integral_map hψ_ae h_rhs_meas.aestronglyMeasurable
    unfold UL.linearScore at h_own'
    rw [h_eq1, h_eq2] at h_own'
    exact h_own'

lemma trimmed_convex_test_bound.{u, u₃, u₄, u₅}
    (h_lem_A_3 : UL.S_lem_A_3.{u₃})
    (h_lem_A_4 : UL.S_lem_A_4.{u₄})
    (h_lem_A_5 : UL.S_lem_A_5.{u₅})
    {Ω : Type u} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {d K : ℕ} (hK2 : 2 ≤ K) {β : ℝ} (hβ : 0 < β)
    {W : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K}
    {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin K}
    (hX : Measurable X) (hY : Measurable Y)
    (hX_int : Integrable (fun ω => ‖X ω‖) μ)
    {ρ : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hρ : UL.IsLipschitzLSFitProfile μ β (UL.linearScore W X) Y ρ)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.EntropyFamily K β)
    {δ : ℝ} (hδ : δ ∈ Set.Ioo (0 : ℝ) 1) :
    let P := fun ω => ρ (W (X ω))
    let p_δ := fun p => (1 - δ) • p + δ • UL.uniformVec K
    let k := fun p => UL.simplexGrad Φ (p_δ p)
    ∫ ω, inner ℝ (UL.fitResidual P Y ω) (k (P ω)) ∂μ ≤
      ((1 - δ) / β) * ∫ ω, inner ℝ (UL.fitResidual P Y ω) (P ω - UL.uniformVec K) ∂μ := by
  intro P p_δ k
  have hsupp_Ω := extract_support_from_lem_A_3 h_lem_A_3 hK2 hβ hX hY hρ
  obtain ⟨_, hsmooth_Ω, _⟩ := extract_from_lem_A_4 h_lem_A_4 hβ hX hY hX_int hρ
  unfold UL.S_lem_A_5 at h_lem_A_5
  let e : ULift.{u₅} (EuclideanSpace ℝ (Fin d) × Fin K) ≃ᵐ
      (EuclideanSpace ℝ (Fin d) × Fin K) := MeasurableEquiv.ulift
  let ψ : Ω → ULift.{u₅} (EuclideanSpace ℝ (Fin d) × Fin K) := fun ω => e.symm (X ω, Y ω)
  have hψ : Measurable ψ := e.symm.measurable.comp (hX.prodMk hY)
  let μ' : Measure (ULift.{u₅} (EuclideanSpace ℝ (Fin d) × Fin K)) := Measure.map ψ μ
  haveI : IsProbabilityMeasure μ' := Measure.isProbabilityMeasure_map hψ.aemeasurable
  let X' : ULift.{u₅} (EuclideanSpace ℝ (Fin d) × Fin K) → EuclideanSpace ℝ (Fin d) :=
    fun z => (e z).1
  let Y' : ULift.{u₅} (EuclideanSpace ℝ (Fin d) × Fin K) → Fin K := fun z => (e z).2
  let P' : ULift.{u₅} (EuclideanSpace ℝ (Fin d) × Fin K) → EuclideanSpace ℝ (Fin K) :=
    fun z => ρ (W (X' z))
  have hX'_meas : Measurable X' := measurable_fst.comp e.measurable
  have hY'_meas : Measurable Y' := measurable_snd.comp e.measurable
  have hS'_meas : Measurable (UL.linearScore W X') := W.continuous.measurable.comp hX'_meas
  have hP'_meas : Measurable P' := hρ.2.1.2.1.continuous.measurable.comp hS'_meas
  have hr'_meas : Measurable (UL.fitResidual P' Y') :=
    hP'_meas.sub (UL.Proof_lem_A_4.oneHotLabel_measurable hY'_meas)
  have hP'_simp : ∀ z, P' z ∈ UL.Simplex K := fun z => hρ.2.1.2.2 (W (X' z))
  have hP_simp : ∀ ω, P ω ∈ UL.Simplex K := fun ω => hρ.2.1.2.2 (W (X ω))
  have hsupp' : ∀ j : Fin K, ∀ᵐ z ∂μ', P' z j = 0 → UL.oneHotLabel Y' z j = 0 := by
    intro j
    have hP'_j_meas : Measurable (fun z => P' z j) :=
      (EuclideanSpace.proj j).continuous.measurable.comp hP'_meas
    have hZ'_j_meas : Measurable (fun z => UL.oneHotLabel Y' z j) :=
      (EuclideanSpace.proj j).continuous.measurable.comp
        (UL.Proof_lem_A_4.oneHotLabel_measurable hY'_meas)
    have h_set_meas : MeasurableSet
        {z : ULift.{u₅} (EuclideanSpace ℝ (Fin d) × Fin K) |
          P' z j = 0 → UL.oneHotLabel Y' z j = 0} := by
      have hEq : {z | P' z j = 0 → UL.oneHotLabel Y' z j = 0} =
          {z | P' z j = 0}ᶜ ∪ {z | UL.oneHotLabel Y' z j = 0} := by
        ext z; simp [imp_iff_not_or]
      rw [hEq]
      exact (measurableSet_eq_fun hP'_j_meas measurable_const).compl.union
        (measurableSet_eq_fun hZ'_j_meas measurable_const)
    exact (ae_map_iff hψ.aemeasurable h_set_meas).mpr (hsupp_Ω j)
  have hsmooth' : ∀ (f : UL.ZeroSumSubspace K → ℝ),
      Differentiable ℝ f →
      ConvexOn ℝ Set.univ f →
      (∃ L : NNReal, LipschitzWith L (gradient f)) →
      ∫ z, inner ℝ (UL.fitResidual P' Y' z)
        (↑(gradient f ((UL.ZeroSumSubspace K).orthogonalProjection (P' z - UL.uniformVec K))) :
          EuclideanSpace ℝ (Fin K)) ∂μ' ≤ 0 := by
    intro f hf_diff hf_conv hf_lip
    obtain ⟨L, hL⟩ := hf_lip
    have hg_meas : Measurable (fun z => inner ℝ (UL.fitResidual P' Y' z)
        (↑(gradient f ((UL.ZeroSumSubspace K).orthogonalProjection (P' z - UL.uniformVec K))) :
          EuclideanSpace ℝ (Fin K))) := by
      refine hr'_meas.inner ?_
      exact (UL.ZeroSumSubspace K).subtypeL.continuous.measurable.comp
        (hL.continuous.measurable.comp
          ((UL.ZeroSumSubspace K).orthogonalProjection.continuous.measurable.comp
            (hP'_meas.sub measurable_const)))
    rw [integral_map hψ.aemeasurable hg_meas.aestronglyMeasurable]
    exact hsmooth_Ω f hf_diff hf_conv ⟨L, hL⟩
  let F_δ := trimmedExcessPotential hK2 Φ β δ hδ
  have hFδ_cont : Continuous F_δ := continuous_trimmedExcessPotential hK2 hΦ hδ
  have hFδ_conv : ConvexOn ℝ (UL.Simplex K) (UL.extendSimplex F_δ) :=
    convexOn_trimmedExcessPotential hK2 hΦ hδ
  have hFδ_diff : ∀ J : Finset (Fin K), J.Nonempty →
      ∀ p ∈ UL.SimplexFaceRelint K J, ∃ g, UL.HasFaceGradAt F_δ J p g :=
    fun J hJ p hp => ⟨_, hasFaceGradAt_trimmedExcessPotential hK2 hΦ hδ hJ hp⟩
  obtain ⟨h_int_le', h_int_prod'⟩ :=
    h_lem_A_5 _ μ' K hK2 P' Y' hP'_meas hY'_meas hP'_simp hsupp' hsmooth'
      F_δ hFδ_cont hFδ_conv hFδ_diff
  let prod_Ω : Ω → ℝ := fun ω =>
    inner ℝ (UL.fitResidual P Y ω)
      (UL.faceGrad F_δ (open Classical in Finset.univ.filter (fun j : Fin K => 0 < P ω j)) (P ω))
  have h_int_prod_Ω : Integrable prod_Ω μ :=
    (integrable_map_measure h_int_prod'.aestronglyMeasurable hψ.aemeasurable).mp h_int_prod'
  have h_int_le_Ω : ∫ ω, prod_Ω ω ∂μ ≤ 0 := by
    have h_eq := integral_map hψ.aemeasurable h_int_prod'.aestronglyMeasurable
    rwa [h_eq] at h_int_le'
  have h_ae_tangent := UL.Proof_lem_A_5.fitResidual_mem_faceTangentSpace_ae hP_simp hsupp_Ω
  have h_ae_eq : prod_Ω =ᵐ[μ] fun ω =>
      inner ℝ (UL.fitResidual P Y ω) (k (P ω)) -
        ((1 - δ) / β) * inner ℝ (UL.fitResidual P Y ω) (P ω - UL.uniformVec K) := by
    filter_upwards [h_ae_tangent] with ω hr_tan
    classical
    set J := Finset.univ.filter (fun j : Fin K => 0 < P ω j)
    obtain ⟨hJ_ne, hP_relint⟩ := UL.Proof_lem_A_5.support_nonempty_and_mem_relint (hP_simp ω)
    set g₀ := k (P ω) - ((1 - δ) / β) • (P ω - UL.uniformVec K)
    have hg_Fδ : UL.HasFaceGradAt F_δ J (P ω)
        (((UL.FaceTangentSpace K J).orthogonalProjection g₀ : UL.FaceTangentSpace K J) :
          EuclideanSpace ℝ (Fin K)) :=
      hasFaceGradAt_trimmedExcessPotential hK2 hΦ hδ hJ_ne hP_relint
    have hfg_eq : UL.faceGrad F_δ J (P ω) =
        (((UL.FaceTangentSpace K J).orthogonalProjection g₀ : UL.FaceTangentSpace K J) :
          EuclideanSpace ℝ (Fin K)) :=
      faceGrad_eq_of_hasFaceGradAt hJ_ne hP_relint hg_Fδ
    dsimp [prod_Ω]
    rw [hfg_eq, real_inner_comm, inner_orthProj_eq_of_mem (UL.FaceTangentSpace K J) g₀ _ hr_tan,
      real_inner_comm]
    dsimp [g₀]
    rw [inner_sub_right, inner_smul_right]
  have hP_meas : Measurable P :=
    hρ.2.1.2.1.continuous.measurable.comp (W.continuous.measurable.comp hX)
  have hr_meas : Measurable (UL.fitResidual P Y) :=
    hP_meas.sub (UL.Proof_lem_A_4.oneHotLabel_measurable hY)
  obtain ⟨_, hk_cont, hk_bdd⟩ := kΦδ_properties (by omega) hΦ hδ
  have hkP_meas : Measurable (fun ω => k (P ω)) :=
    measurable_comp_of_continuousOn hk_cont hP_meas hP_simp
  obtain ⟨M_k, hM_k⟩ := isBounded_iff_forall_norm_le.mp hk_bdd
  have hInt_rk : Integrable (fun ω => inner ℝ (UL.fitResidual P Y ω) (k (P ω))) μ :=
    UL.Proof_lem_A_4.integrable_of_aestronglyMeasurable_bounded
      (hr_meas.inner hkP_meas).aestronglyMeasurable (2 * (|M_k| + 1)) (fun ω => by
        rw [Real.norm_eq_abs]
        have hr_b := UL.Proof_lem_A_4.fitResidual_norm_le_two Y hP_simp ω
        have hk_b : ‖k (P ω)‖ ≤ |M_k| + 1 :=
          (hM_k _ ⟨P ω, hP_simp ω, rfl⟩).trans (by linarith [le_abs_self M_k])
        calc |inner ℝ (UL.fitResidual P Y ω) (k (P ω))|
            ≤ ‖UL.fitResidual P Y ω‖ * ‖k (P ω)‖ := abs_real_inner_le_norm _ _
          _ ≤ 2 * (|M_k| + 1) := mul_le_mul hr_b hk_b (norm_nonneg _) (by norm_num))
  have hInt_rb : Integrable (fun ω =>
      inner ℝ (UL.fitResidual P Y ω) (P ω - UL.uniformVec K)) μ :=
    UL.Proof_lem_A_4.integrable_of_aestronglyMeasurable_bounded
      (hr_meas.inner (hP_meas.sub measurable_const)).aestronglyMeasurable 4 (fun ω => by
        rw [Real.norm_eq_abs]
        have hr_b := UL.Proof_lem_A_4.fitResidual_norm_le_two Y hP_simp ω
        have hpu_b : ‖P ω - UL.uniformVec K‖ ≤ 2 := by
          calc ‖P ω - UL.uniformVec K‖ ≤ ‖P ω‖ + ‖UL.uniformVec K‖ := norm_sub_le _ _
            _ ≤ 1 + 1 := add_le_add (UL.Proof_lem_A_4.simplex_norm_le_one (hP_simp ω))
                (UL.Proof_lem_A_4.simplex_norm_le_one (UL.Proof_lem_A_4.uniformVec_mem_simplex (by omega)))
            _ = 2 := by norm_num
        calc |inner ℝ (UL.fitResidual P Y ω) (P ω - UL.uniformVec K)|
            ≤ ‖UL.fitResidual P Y ω‖ * ‖P ω - UL.uniformVec K‖ := abs_real_inner_le_norm _ _
          _ ≤ 2 * 2 := mul_le_mul hr_b hpu_b (norm_nonneg _) (by norm_num)
          _ = 4 := by norm_num)
  have h_int_rewrite : ∫ ω, prod_Ω ω ∂μ =
      (∫ ω, inner ℝ (UL.fitResidual P Y ω) (k (P ω)) ∂μ) -
        ((1 - δ) / β) * ∫ ω, inner ℝ (UL.fitResidual P Y ω) (P ω - UL.uniformVec K) ∂μ := by
    rw [integral_congr_ae h_ae_eq, integral_sub hInt_rk (hInt_rb.const_mul ((1 - δ) / β)),
      integral_const_mul]
  linarith

/-! ### Variance lower bound on `b = 𝔼⟨ξ, P - u⟩` -/

lemma lower_bound_b.{u} {Ω : Type u} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {K : ℕ} (hK : 1 ≤ K) {P : Ω → EuclideanSpace ℝ (Fin K)} {Y : Ω → Fin K}
    (hP_meas : Measurable P) (hY_meas : Measurable Y)
    (hP_simp : ∀ ω, P ω ∈ UL.Simplex K)
    (h_mean_zero : ∫ ω, UL.fitResidual P Y ω ∂μ = 0) :
    -(1 / 4 : ℝ) * (1 - 1 / (K : ℝ)) ≤
      ∫ ω, inner ℝ (UL.fitResidual P Y ω) (P ω - UL.uniformVec K) ∂μ := by
  let eY : Ω → EuclideanSpace ℝ (Fin K) := UL.oneHotLabel Y
  have hZ_meas : Measurable eY := UL.Proof_lem_A_4.oneHotLabel_measurable hY_meas
  have hr_meas : Measurable (UL.fitResidual P Y) := hP_meas.sub hZ_meas
  have hZ_int : Integrable eY μ :=
    UL.Proof_lem_A_4.integrable_of_aestronglyMeasurable_bounded hZ_meas.aestronglyMeasurable 1
      (fun ω => UL.Proof_lem_A_4.simplex_norm_le_one (UL.Proof_lem_A_4.oneHotLabel_mem_simplex Y ω))
  have hr_int : Integrable (UL.fitResidual P Y) μ :=
    UL.Proof_lem_A_4.integrable_of_aestronglyMeasurable_bounded hr_meas.aestronglyMeasurable 2
      (UL.Proof_lem_A_4.fitResidual_norm_le_two Y hP_simp)
  let m : EuclideanSpace ℝ (Fin K) := ∫ ω, eY ω ∂μ
  have hm_norm_le_one : ‖m‖ ≤ 1 := by
    calc ‖∫ ω, eY ω ∂μ‖
        ≤ ∫ ω, ‖eY ω‖ ∂μ := norm_integral_le_integral_norm eY
      _ ≤ ∫ _ω : Ω, (1 : ℝ) ∂μ :=
          integral_mono hZ_int.norm (integrable_const 1)
            (fun ω => UL.Proof_lem_A_4.simplex_norm_le_one
              (UL.Proof_lem_A_4.oneHotLabel_mem_simplex Y ω))
      _ = 1 := by simp
  have hr_orth_const : ∀ c : EuclideanSpace ℝ (Fin K),
      ∫ ω, inner ℝ (UL.fitResidual P Y ω) c ∂μ = 0 := by
    intro c
    have hclm := (innerSL ℝ c).integral_comp_comm hr_int
    have hcomm : (fun ω => inner ℝ (UL.fitResidual P Y ω) c) =
        fun ω => (innerSL ℝ c) (UL.fitResidual P Y ω) := by
      funext ω
      simp [real_inner_comm]
    rw [hcomm, hclm, h_mean_zero, map_zero]
  have hInt_r_Pm : Integrable (fun ω => inner ℝ (UL.fitResidual P Y ω) (P ω - m)) μ :=
    UL.Proof_lem_A_4.integrable_of_aestronglyMeasurable_bounded
      (hr_meas.inner (hP_meas.sub measurable_const)).aestronglyMeasurable 4 (fun ω => by
        rw [Real.norm_eq_abs]
        have hr_b := UL.Proof_lem_A_4.fitResidual_norm_le_two Y hP_simp ω
        have hPm_b : ‖P ω - m‖ ≤ 2 := by
          calc ‖P ω - m‖ ≤ ‖P ω‖ + ‖m‖ := norm_sub_le _ _
            _ ≤ 1 + 1 := add_le_add (UL.Proof_lem_A_4.simplex_norm_le_one (hP_simp ω)) hm_norm_le_one
            _ = 2 := by norm_num
        calc |inner ℝ (UL.fitResidual P Y ω) (P ω - m)|
            ≤ ‖UL.fitResidual P Y ω‖ * ‖P ω - m‖ := abs_real_inner_le_norm _ _
          _ ≤ 2 * 2 := mul_le_mul hr_b hPm_b (norm_nonneg _) (by norm_num)
          _ = 4 := by norm_num)
  have hInt_r_mu : Integrable (fun ω => inner ℝ (UL.fitResidual P Y ω) (m - UL.uniformVec K)) μ :=
    ((innerSL ℝ (m - UL.uniformVec K)).integrable_comp hr_int).congr
      (Eventually.of_forall fun ω => by simp only [innerSL_apply_apply, real_inner_comm])
  have hb_shift : ∫ ω, inner ℝ (UL.fitResidual P Y ω) (P ω - UL.uniformVec K) ∂μ =
      ∫ ω, inner ℝ (UL.fitResidual P Y ω) (P ω - m) ∂μ := by
    have hsplit : (fun ω => inner ℝ (UL.fitResidual P Y ω) (P ω - UL.uniformVec K)) =
        fun ω => inner ℝ (UL.fitResidual P Y ω) (P ω - m) +
          inner ℝ (UL.fitResidual P Y ω) (m - UL.uniformVec K) := by
      funext ω
      rw [← inner_add_right]
      congr 1
      abel
    rw [hsplit, integral_add hInt_r_Pm hInt_r_mu, hr_orth_const (m - UL.uniformVec K), add_zero]
  have h_ptwise_sq : ∀ ω : Ω,
      -(1 / 4 : ℝ) * ‖eY ω - m‖ ^ 2 ≤ inner ℝ (UL.fitResidual P Y ω) (P ω - m) := by
    intro ω
    set a := P ω - m
    set z := eY ω - m
    have hr_eq : UL.fitResidual P Y ω = a - z := by dsimp [UL.fitResidual, eY, a, z]; abel
    have hid : inner ℝ (a - z) a = ‖a - (1 / 2 : ℝ) • z‖ ^ 2 - (1 / 4 : ℝ) * ‖z‖ ^ 2 := by
      rw [norm_sub_sq_real, inner_smul_right, norm_smul, Real.norm_eq_abs, mul_pow, sq_abs,
        inner_sub_left, real_inner_self_eq_norm_sq, real_inner_comm z a]
      ring
    rw [hr_eq, hid]
    linarith [sq_nonneg ‖a - (1 / 2 : ℝ) • z‖]
  have hInt_Zm_sq : Integrable (fun ω => ‖eY ω - m‖ ^ 2) μ :=
    UL.Proof_lem_A_4.integrable_of_aestronglyMeasurable_bounded
      (((hZ_meas.sub measurable_const).norm).pow_const 2).aestronglyMeasurable 4 (fun ω => by
        rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
        have hZm : ‖eY ω - m‖ ≤ 2 := by
          calc ‖eY ω - m‖ ≤ ‖eY ω‖ + ‖m‖ := norm_sub_le _ _
            _ ≤ 1 + 1 := add_le_add (UL.Proof_lem_A_4.simplex_norm_le_one
                (UL.Proof_lem_A_4.oneHotLabel_mem_simplex Y ω)) hm_norm_le_one
            _ = 2 := by norm_num
        have h0 := norm_nonneg (eY ω - m)
        nlinarith)
  have hb_ge_var : -(1 / 4 : ℝ) * (∫ ω, ‖eY ω - m‖ ^ 2 ∂μ) ≤
      ∫ ω, inner ℝ (UL.fitResidual P Y ω) (P ω - UL.uniformVec K) ∂μ := by
    rw [hb_shift, ← integral_const_mul]
    exact integral_mono (hInt_Zm_sq.const_mul (-(1 / 4 : ℝ))) hInt_r_Pm h_ptwise_sq
  have hZ_norm_one : ∀ ω : Ω, ‖eY ω‖ ^ 2 = 1 := by
    intro ω
    rw [UL.Proof_lem_A_4.norm_sq_eq_sum]
    simp [eY, UL.oneHotLabel, UL.oneHotVec, EuclideanSpace.single_apply]
  have hInt_Zm_inn : Integrable (fun ω => inner ℝ (eY ω) m) μ :=
    ((innerSL ℝ m).integrable_comp hZ_int).congr
      (Eventually.of_forall fun ω => by simp only [innerSL_apply_apply, real_inner_comm])
  have h_inn_m : ∫ ω, inner ℝ (eY ω) m ∂μ = ‖m‖ ^ 2 := by
    have hclm := (innerSL ℝ m).integral_comp_comm hZ_int
    have hcomm : (fun ω => inner ℝ (eY ω) m) = fun ω => (innerSL ℝ m) (eY ω) := by
      funext ω; simp only [innerSL_apply_apply, real_inner_comm]
    rw [hcomm, hclm]
    exact real_inner_self_eq_norm_sq m
  have h_var_eq : ∫ ω, ‖eY ω - m‖ ^ 2 ∂μ = 1 - ‖m‖ ^ 2 := by
    have hexp : (fun ω => ‖eY ω - m‖ ^ 2) =
        fun ω => (1 + ‖m‖ ^ 2) - 2 * inner ℝ (eY ω) m := by
      funext ω
      rw [norm_sub_sq_real, hZ_norm_one ω]
      ring
    rw [hexp, integral_sub (integrable_const _) (hInt_Zm_inn.const_mul 2),
      integral_const_mul, h_inn_m]
    simp only [integral_const, probReal_univ, one_smul]
    ring
  have hm_norm_ge : 1 / (K : ℝ) ≤ ‖m‖ ^ 2 := by
    have hK_pos : (0 : ℝ) < (K : ℝ) := Nat.cast_pos.mpr (by omega)
    have h_ones_m : inner ℝ (UL.onesVec K) m = 1 := by
      have hclm := (innerSL ℝ (UL.onesVec K)).integral_comp_comm hZ_int
      have h_pt : (fun ω => (innerSL ℝ (UL.onesVec K)) (eY ω)) = fun _ => (1 : ℝ) := by
        funext ω
        exact UL.Proof_lem_A_4.inner_onesVec_of_mem_simplex
          (UL.Proof_lem_A_4.oneHotLabel_mem_simplex Y ω)
      dsimp [m]
      rw [← innerSL_apply_apply, ← hclm, h_pt]
      simp
    have h_ones_u : inner ℝ (UL.onesVec K) (UL.uniformVec K) = 1 :=
      UL.Proof_lem_A_4.inner_onesVec_of_mem_simplex (UL.Proof_lem_A_4.uniformVec_mem_simplex hK)
    have horth : inner ℝ (m - UL.uniformVec K) (UL.uniformVec K) = 0 := by
      have hdiff : inner ℝ (UL.onesVec K) (m - UL.uniformVec K) = 0 := by
        rw [inner_sub_right, h_ones_m, h_ones_u, sub_self]
      calc inner ℝ (m - UL.uniformVec K) (UL.uniformVec K)
          = inner ℝ (m - UL.uniformVec K) ((1 / (K : ℝ)) • UL.onesVec K) := rfl
        _ = (1 / (K : ℝ)) * inner ℝ (UL.onesVec K) (m - UL.uniformVec K) := by
              rw [inner_smul_right, real_inner_comm]
        _ = 0 := by rw [hdiff, mul_zero]
    have hu_sq : ‖UL.uniformVec K‖ ^ 2 = 1 / (K : ℝ) := by
      rw [UL.Proof_lem_A_4.norm_sq_eq_sum]
      have hterm : ∀ i : Fin K, (UL.uniformVec K i) ^ 2 = (1 / (K : ℝ)) ^ 2 := by
        intro i
        rw [UL.Proof_lem_A_1.uniformVec_apply]
      simp_rw [hterm]
      rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
      field_simp [hK_pos.ne']
    have hpyth : ‖m‖ ^ 2 = ‖m - UL.uniformVec K‖ ^ 2 + ‖UL.uniformVec K‖ ^ 2 := by
      have h1 : m = (m - UL.uniformVec K) + UL.uniformVec K := by abel
      nth_rw 1 [h1]
      rw [norm_add_sq_real, horth]
      ring
    rw [hpyth, hu_sq]
    linarith [sq_nonneg ‖m - UL.uniformVec K‖]
  rw [h_var_eq] at hb_ge_var
  linarith

/-! ### Main smoothing risk inequality for all `1 ≤ K` -/

theorem smoothing_bound_all.{u, u₃, u₄, u₅}
    (h_lem_A_1 : UL.S_lem_A_1)
    (h_lem_A_3 : UL.S_lem_A_3.{u₃})
    (h_lem_A_4 : UL.S_lem_A_4.{u₄})
    (h_lem_A_5 : UL.S_lem_A_5.{u₅})
    {Ω : Type u} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {d K : ℕ} (hK : 1 ≤ K) {β : ℝ} (hβ : 0 < β)
    {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin K}
    (hX : Measurable X) (hY : Measurable Y)
    (hX_int : Integrable (fun ω => ‖X ω‖) μ)
    {𝒲 : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K)}
    (h𝒲 : UL.IsCompactConvexScoreSet 𝒲)
    {W : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K} (_hW : W ∈ 𝒲)
    {ρ : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hρ : UL.IsLipschitzLSFitProfile μ β (UL.linearScore W X) Y ρ)
    (hΓ : UL.certificateGap μ β 𝒲 X Y W = 0)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.EntropyFamily K β)
    {δ : ℝ} (hδ : δ ∈ Set.Ioo (0 : ℝ) 1) :
    let P := fun ω => ρ (W (X ω))
    let p_δ := fun p => (1 - δ) • p + δ • UL.uniformVec K
    let k := fun p => UL.simplexGrad Φ (p_δ p)
    let JΦ_δ := sSup ((fun p =>
      (1 - δ) * UL.extendSimplex Φ p + δ * UL.extendSimplex Φ (UL.uniformVec K) -
        UL.extendSimplex Φ (p_δ p)) '' UL.Simplex K)
    Integrable (fun ω => UL.matchingLoss Φ (k (P ω)) (Y ω)) μ ∧
    (∀ V ∈ 𝒲, Integrable (fun ω => UL.matchingLoss Φ (V (X ω)) (Y ω)) μ) ∧
    BddBelow ((fun V => ∫ ω, UL.matchingLoss Φ (V (X ω)) (Y ω) ∂μ) '' 𝒲) ∧
    (∫ ω, UL.matchingLoss Φ (k (P ω)) (Y ω) ∂μ) ≤
      sInf ((fun V => ∫ ω, UL.matchingLoss Φ (V (X ω)) (Y ω) ∂μ) '' 𝒲) +
        JΦ_δ / (1 - δ) + δ * (1 - 1 / (K : ℝ)) / (4 * β) := by
  intro P p_δ k JΦ_δ
  have hΦ_cont : Continuous Φ := hΦ.2.1
  have h_comp_int : ∀ V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K,
      Integrable (fun ω => UL.matchingLoss Φ (V (X ω)) (Y ω)) μ := by
    intro V
    have hVX_meas : Measurable (fun ω => (V (X ω) : EuclideanSpace ℝ (Fin K))) :=
      (UL.ZeroSumSubspace K).subtypeL.continuous.measurable.comp (V.continuous.measurable.comp hX)
    have h_meas : Measurable (fun ω => UL.matchingLoss Φ (V (X ω)) (Y ω)) :=
      measurable_matchingLoss_comp hK hΦ_cont hVX_meas hY
    have h_dom : Integrable (fun ω => |UL.matchingPotential Φ 0| + (3 * ‖V‖) * ‖X ω‖) μ :=
      (integrable_const _).add (hX_int.const_mul (3 * ‖V‖))
    refine h_dom.mono' h_meas.aestronglyMeasurable (Eventually.of_forall fun ω => ?_)
    rw [Real.norm_eq_abs]
    calc |UL.matchingLoss Φ (V (X ω)) (Y ω)|
        ≤ |UL.matchingPotential Φ 0| + 3 * ‖(V (X ω) : EuclideanSpace ℝ (Fin K))‖ :=
          matchingLoss_abs_le hK hΦ_cont (V (X ω)) (Y ω)
      _ ≤ |UL.matchingPotential Φ 0| + 3 * (‖V‖ * ‖X ω‖) := by
          gcongr
          exact V.le_opNorm (X ω)
      _ = |UL.matchingPotential Φ 0| + (3 * ‖V‖) * ‖X ω‖ := by ring
  obtain ⟨_, hk_cont, hk_bdd⟩ := kΦδ_properties hK hΦ hδ
  have hP_meas : Measurable P :=
    hρ.2.1.2.1.continuous.measurable.comp (W.continuous.measurable.comp hX)
  have hP_simp : ∀ ω, P ω ∈ UL.Simplex K := fun ω => hρ.2.1.2.2 (W (X ω))
  have hkP_meas : Measurable (fun ω => k (P ω)) :=
    measurable_comp_of_continuousOn hk_cont hP_meas hP_simp
  obtain ⟨M_k, hM_k⟩ := isBounded_iff_forall_norm_le.mp hk_bdd
  have hk_loss_int : Integrable (fun ω => UL.matchingLoss Φ (k (P ω)) (Y ω)) μ := by
    have h_meas : Measurable (fun ω => UL.matchingLoss Φ (k (P ω)) (Y ω)) :=
      measurable_matchingLoss_comp hK hΦ_cont hkP_meas hY
    refine UL.Proof_lem_A_4.integrable_of_aestronglyMeasurable_bounded h_meas.aestronglyMeasurable
      (|UL.matchingPotential Φ 0| + 3 * (|M_k| + 1)) (fun ω => ?_)
    rw [Real.norm_eq_abs]
    have hk_b : ‖k (P ω)‖ ≤ |M_k| + 1 :=
      (hM_k _ ⟨P ω, hP_simp ω, rfl⟩).trans (by linarith [le_abs_self M_k])
    calc |UL.matchingLoss Φ (k (P ω)) (Y ω)|
        ≤ |UL.matchingPotential Φ 0| + 3 * ‖k (P ω)‖ :=
          matchingLoss_abs_le hK hΦ_cont (k (P ω)) (Y ω)
      _ ≤ |UL.matchingPotential Φ 0| + 3 * (|M_k| + 1) := by linarith
  rcases eq_or_lt_of_le hK with hK_eq | hK_gt
  · subst hK_eq
    have hk_zero : ∀ ω, k (P ω) = 0 := fun ω =>
      zeroSumSubspace_one_eq_zero (simplexGrad_mem_zeroSumSubspace Φ (p_δ (P ω)))
    have hV_zero : ∀ (V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace 1) (ω : Ω),
        (V (X ω) : EuclideanSpace ℝ (Fin 1)) = 0 :=
      fun V ω => zeroSumSubspace_one_eq_zero (V (X ω)).2
    let c₀ : ℝ := UL.matchingPotential Φ 0
    have hloss_zero : ∀ y : Fin 1, UL.matchingLoss Φ 0 y = c₀ := by
      intro y; simp [UL.matchingLoss, c₀]
    have h_int_k : (∫ ω, UL.matchingLoss Φ (k (P ω)) (Y ω) ∂μ) = c₀ := by
      simp_rw [hk_zero, hloss_zero]
      simp
    have h_int_V : ∀ V ∈ 𝒲, (∫ ω, UL.matchingLoss Φ (V (X ω)) (Y ω) ∂μ) = c₀ := by
      intro V _
      simp_rw [hV_zero V, hloss_zero]
      simp
    have h_bdd : BddBelow ((fun V => ∫ ω, UL.matchingLoss Φ (V (X ω)) (Y ω) ∂μ) '' 𝒲) := by
      refine ⟨c₀, ?_⟩
      rintro _ ⟨V, hV, rfl⟩
      exact (h_int_V V hV).ge
    refine ⟨hk_loss_int, fun V _ => h_comp_int V, h_bdd, ?_⟩
    have h_ne_img : ((fun V => ∫ ω, UL.matchingLoss Φ (V (X ω)) (Y ω) ∂μ) '' 𝒲).Nonempty :=
      h𝒲.1.image _
    have h_sinf : c₀ ≤ sInf ((fun V => ∫ ω, UL.matchingLoss Φ (V (X ω)) (Y ω) ∂μ) '' 𝒲) := by
      refine le_csInf h_ne_img ?_
      rintro _ ⟨V, hV, rfl⟩
      exact (h_int_V V hV).ge
    have hJ_nn : 0 ≤ JΦ_δ := jensenGap_nonneg (le_refl 1) hΦ_cont hδ
    have h1d_pos : 0 < 1 - δ := sub_pos.mpr hδ.2
    have hexcess_nn : 0 ≤ JΦ_δ / (1 - δ) + δ * (1 - 1 / ((1 : ℕ) : ℝ)) / (4 * β) := by
      have hdiv : 0 ≤ JΦ_δ / (1 - δ) := div_nonneg hJ_nn h1d_pos.le
      norm_num
      exact hdiv
    rw [h_int_k]
    linarith
  · have hK2 : 2 ≤ K := by omega
    obtain ⟨h_mean_zero, _, h_own_score⟩ := extract_from_lem_A_4 h_lem_A_4 hβ hX hY hX_int hρ
    have h_trimmed := trimmed_convex_test_bound h_lem_A_3 h_lem_A_4 h_lem_A_5
      hK2 hβ hX hY hX_int hρ hΦ hδ
    have hb_lb := lower_bound_b hK hP_meas hY hP_simp h_mean_zero
    set b : ℝ := ∫ ω, inner ℝ (UL.fitResidual P Y ω) (P ω - UL.uniformVec K) ∂μ
    -- Integrability of -extendSimplex Φ (P ω)
    obtain ⟨D, _, _⟩ := exists_oscillation_bound_ge_one hK hΦ_cont
    have hΦP_meas : Measurable (fun ω => UL.extendSimplex Φ (P ω)) :=
      measurable_comp_of_continuousOn
        (UL.Proof_lem_A_5.continuousOn_extendSimplex hΦ_cont) hP_meas hP_simp
    have hΦ_bdd_img : Bornology.IsBounded (UL.extendSimplex Φ '' UL.Simplex K) :=
      ((UL.Proof_lem_A_5.isCompact_simplex K).image_of_continuousOn
        (UL.Proof_lem_A_5.continuousOn_extendSimplex hΦ_cont)).isBounded
    obtain ⟨M_Φ, hM_Φ⟩ := isBounded_iff_forall_norm_le.mp hΦ_bdd_img
    have hInt_ΦP : Integrable (fun ω => UL.extendSimplex Φ (P ω)) μ :=
      UL.Proof_lem_A_4.integrable_of_aestronglyMeasurable_bounded hΦP_meas.aestronglyMeasurable
        (|M_Φ| + 1) (fun ω =>
          (hM_Φ _ ⟨P ω, hP_simp ω, rfl⟩).trans (by linarith [le_abs_self M_Φ]))
    -- Comparator lower bound for all V ∈ 𝒲
    have hP_ae_PW := profile_ae_eq_linearFittedPrediction hX hY hρ
    obtain ⟨M_𝒲, hM_𝒲⟩ := isBounded_iff_forall_norm_le.mp h𝒲.2.1.isBounded
    have hr_meas : Measurable (UL.fitResidual P Y) :=
      hP_meas.sub (UL.Proof_lem_A_4.oneHotLabel_measurable hY)
    have hInt_rL : ∀ L : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K,
        Integrable (fun ω =>
          inner ℝ (UL.fitResidual P Y ω) (L (X ω) : EuclideanSpace ℝ (Fin K))) μ := by
      intro L
      have hLX_meas : Measurable (fun ω => (L (X ω) : EuclideanSpace ℝ (Fin K))) :=
        (UL.ZeroSumSubspace K).subtypeL.continuous.measurable.comp (L.continuous.measurable.comp hX)
      refine (hX_int.const_mul (2 * ‖L‖)).mono' (hr_meas.inner hLX_meas).aestronglyMeasurable
        (Eventually.of_forall fun ω => ?_)
      rw [Real.norm_eq_abs]
      have hr_b := UL.Proof_lem_A_4.fitResidual_norm_le_two Y hP_simp ω
      calc |inner ℝ (UL.fitResidual P Y ω) (L (X ω) : EuclideanSpace ℝ (Fin K))|
          ≤ ‖UL.fitResidual P Y ω‖ * ‖(L (X ω) : EuclideanSpace ℝ (Fin K))‖ :=
            abs_real_inner_le_norm _ _
        _ ≤ 2 * (‖L‖ * ‖X ω‖) :=
            mul_le_mul hr_b (L.le_opNorm (X ω)) (norm_nonneg _) (by norm_num)
        _ = (2 * ‖L‖) * ‖X ω‖ := by ring
    have hΓ_bdd : BddAbove ((fun V => ∫ ω,
        inner ℝ (UL.linearFittedPrediction μ β W X Y ω - UL.oneHotLabel Y ω)
          ((W - V) (X ω) : EuclideanSpace ℝ (Fin K)) ∂μ) '' 𝒲) := by
      refine ⟨(2 * (‖W‖ + (|M_𝒲| + 1))) * ∫ ω, ‖X ω‖ ∂μ, ?_⟩
      rintro _ ⟨V, hV, rfl⟩
      dsimp only
      have hV_norm : ‖V‖ ≤ |M_𝒲| + 1 :=
        (hM_𝒲 V hV).trans (by linarith [le_abs_self M_𝒲])
      have hae_eq : (fun ω =>
          inner ℝ (UL.linearFittedPrediction μ β W X Y ω - UL.oneHotLabel Y ω)
            ((W - V) (X ω) : EuclideanSpace ℝ (Fin K))) =ᵐ[μ]
          fun ω => inner ℝ (UL.fitResidual P Y ω) ((W - V) (X ω) : EuclideanSpace ℝ (Fin K)) := by
        filter_upwards [hP_ae_PW] with ω hω
        rw [← hω]; rfl
      rw [integral_congr_ae hae_eq]
      calc ∫ ω, inner ℝ (UL.fitResidual P Y ω) ((W - V) (X ω) : EuclideanSpace ℝ (Fin K)) ∂μ
          ≤ ∫ ω, (2 * (‖W‖ + (|M_𝒲| + 1))) * ‖X ω‖ ∂μ := by
            refine integral_mono (hInt_rL (W - V))
              (hX_int.const_mul (2 * (‖W‖ + (|M_𝒲| + 1)))) (fun ω => ?_)
            have hr_b := UL.Proof_lem_A_4.fitResidual_norm_le_two Y hP_simp ω
            have hWV_b : ‖W - V‖ ≤ ‖W‖ + (|M_𝒲| + 1) :=
              (norm_sub_le W V).trans (by linarith)
            calc inner ℝ (UL.fitResidual P Y ω) ((W - V) (X ω) : EuclideanSpace ℝ (Fin K))
                ≤ ‖UL.fitResidual P Y ω‖ * ‖((W - V) (X ω) : EuclideanSpace ℝ (Fin K))‖ :=
                  real_inner_le_norm _ _
              _ ≤ 2 * (‖W - V‖ * ‖X ω‖) :=
                  mul_le_mul hr_b ((W - V).le_opNorm (X ω)) (norm_nonneg _) (by norm_num)
              _ ≤ 2 * ((‖W‖ + (|M_𝒲| + 1)) * ‖X ω‖) :=
                  mul_le_mul_of_nonneg_left
                    (mul_le_mul_of_nonneg_right hWV_b (norm_nonneg _)) (by norm_num)
              _ = (2 * (‖W‖ + (|M_𝒲| + 1))) * ‖X ω‖ := by ring
        _ = (2 * (‖W‖ + (|M_𝒲| + 1))) * ∫ ω, ‖X ω‖ ∂μ := integral_const_mul _ _
    have h_comp_lb : ∀ V ∈ 𝒲,
        -(∫ ω, UL.extendSimplex Φ (P ω) ∂μ) + b / β ≤
          ∫ ω, UL.matchingLoss Φ (V (X ω)) (Y ω) ∂μ := by
      intro V hV
      have h_gap_V : ∫ ω,
          inner ℝ (UL.linearFittedPrediction μ β W X Y ω - UL.oneHotLabel Y ω)
            ((W - V) (X ω) : EuclideanSpace ℝ (Fin K)) ∂μ ≤ 0 := by
        have h1 : _ ≤ UL.certificateGap μ β 𝒲 X Y W := le_csSup hΓ_bdd ⟨V, hV, rfl⟩
        rwa [hΓ] at h1
      have hae_eq : (fun ω =>
          inner ℝ (UL.linearFittedPrediction μ β W X Y ω - UL.oneHotLabel Y ω)
            ((W - V) (X ω) : EuclideanSpace ℝ (Fin K))) =ᵐ[μ]
          fun ω => inner ℝ (UL.fitResidual P Y ω) ((W - V) (X ω) : EuclideanSpace ℝ (Fin K)) := by
        filter_upwards [hP_ae_PW] with ω hω
        rw [← hω]; rfl
      rw [integral_congr_ae hae_eq] at h_gap_V
      have h_sub_int : ∫ ω, inner ℝ (UL.fitResidual P Y ω)
          ((W - V) (X ω) : EuclideanSpace ℝ (Fin K)) ∂μ =
          (∫ ω, inner ℝ (UL.fitResidual P Y ω) (W (X ω) : EuclideanSpace ℝ (Fin K)) ∂μ) -
            (∫ ω, inner ℝ (UL.fitResidual P Y ω) (V (X ω) : EuclideanSpace ℝ (Fin K)) ∂μ) := by
        have hpt : (fun ω => inner ℝ (UL.fitResidual P Y ω)
            ((W - V) (X ω) : EuclideanSpace ℝ (Fin K))) =
            fun ω => inner ℝ (UL.fitResidual P Y ω) (W (X ω) : EuclideanSpace ℝ (Fin K)) -
              inner ℝ (UL.fitResidual P Y ω) (V (X ω) : EuclideanSpace ℝ (Fin K)) := by
          funext ω
          change inner ℝ (UL.fitResidual P Y ω) ((W (X ω) : EuclideanSpace ℝ (Fin K)) -
            (V (X ω) : EuclideanSpace ℝ (Fin K))) = _
          exact inner_sub_right _ _ _
        rw [hpt, integral_sub (hInt_rL W) (hInt_rL V)]
      have h_b_le_W : b / β ≤
          ∫ ω, inner ℝ (UL.fitResidual P Y ω) (W (X ω) : EuclideanSpace ℝ (Fin K)) ∂μ := by
        rw [div_le_iff₀ hβ]
        change b ≤ β * ∫ ω, inner ℝ (UL.fitResidual P Y ω) (W (X ω) : EuclideanSpace ℝ (Fin K)) ∂μ
          at h_own_score
        linarith
      have h_b_le_V : b / β ≤
          ∫ ω, inner ℝ (UL.fitResidual P Y ω) (V (X ω) : EuclideanSpace ℝ (Fin K)) ∂μ := by
        linarith
      have hInt_negΦP : Integrable (fun ω => -UL.extendSimplex Φ (P ω)) μ := hInt_ΦP.neg
      have h_fenchel_int : -(∫ ω, UL.extendSimplex Φ (P ω) ∂μ) +
          (∫ ω, inner ℝ (UL.fitResidual P Y ω) (V (X ω) : EuclideanSpace ℝ (Fin K)) ∂μ) ≤
          ∫ ω, UL.matchingLoss Φ (V (X ω)) (Y ω) ∂μ := by
        rw [← integral_neg, ← integral_add hInt_negΦP (hInt_rL V)]
        refine integral_mono (hInt_negΦP.add (hInt_rL V)) (h_comp_int V) (fun ω => ?_)
        exact matchingLoss_fenchel_lower hΦ_cont (hP_simp ω) (V (X ω)).2 (Y ω)
      linarith
    have h_bdd_below : BddBelow ((fun V => ∫ ω, UL.matchingLoss Φ (V (X ω)) (Y ω) ∂μ) '' 𝒲) := by
      refine ⟨-(∫ ω, UL.extendSimplex Φ (P ω) ∂μ) + b / β, ?_⟩
      rintro _ ⟨V, hV, rfl⟩
      exact h_comp_lb V hV
    -- Upper bound on ∫ matchingLoss Φ (k (P ω)) (Y ω) ∂μ
    have hΦ_conv : ConvexOn ℝ (UL.Simplex K) (UL.extendSimplex Φ) :=
      convexOn_extendSimplex_of_mem_entropyFamily hΦ
    unfold UL.S_lem_A_1 at h_lem_A_1
    have hA1_int := (h_lem_A_1 K hK2 Φ hΦ_cont hΦ_conv hΦ.2.2.1).2.2.2
    have h1d_pos : 0 < 1 - δ := sub_pos.mpr hδ.2
    have h_ptwise_upper : ∀ ω : Ω,
        UL.matchingLoss Φ (k (P ω)) (Y ω) ≤
          -UL.extendSimplex Φ (P ω) + JΦ_δ / (1 - δ) +
            inner ℝ (UL.fitResidual P Y ω) (k (P ω)) := by
      intro ω
      have hpδ_relint : p_δ (P ω) ∈ UL.SimplexFaceRelint K Finset.univ :=
        UL.Proof_lem_A_5.trimmed_mem_simplexFaceRelint_univ hK2 (hP_simp ω) hδ.1 hδ.2
      have h_ereal_eq := (hA1_int (p_δ (P ω)) hpδ_relint).2 (Y ω)
      have hy_pos : Y ω ∈ UL.posSupport (p_δ (P ω)) :=
        (UL.Proof_lem_A_1.mem_posSupport_iff (p_δ (P ω)) (Y ω)).mpr
          (hpδ_relint.2 (Y ω) (Finset.mem_univ (Y ω)))
      have hsupp_univ : UL.posSupport (p_δ (P ω)) = Finset.univ := by
        ext j
        simp only [Finset.mem_univ, iff_true]
        exact (UL.Proof_lem_A_1.mem_posSupport_iff (p_δ (P ω)) j).mpr
          (hpδ_relint.2 j (Finset.mem_univ j))
      unfold UL.extendedCanonicalLoss at h_ereal_eq
      rw [if_pos hy_pos, hsupp_univ, EReal.coe_eq_coe_iff] at h_ereal_eq
      have h_fenchel_eq : UL.matchingLoss Φ (k (P ω)) (Y ω) =
          -UL.extendSimplex Φ (p_δ (P ω)) +
            inner ℝ (p_δ (P ω) - UL.oneHotLabel Y ω) (k (P ω)) := by
        dsimp [k, UL.simplexGrad, UL.oneHotLabel, UL.oneHotVec] at h_ereal_eq ⊢
        rw [real_inner_comm]
        exact h_ereal_eq
      have h_split_inner : inner ℝ (p_δ (P ω) - UL.oneHotLabel Y ω) (k (P ω)) =
          inner ℝ (UL.fitResidual P Y ω) (k (P ω)) +
            δ * inner ℝ (UL.uniformVec K - P ω) (k (P ω)) := by
        have hvec : p_δ (P ω) - UL.oneHotLabel Y ω =
            UL.fitResidual P Y ω + δ • (UL.uniformVec K - P ω) := by
          ext j
          simp only [p_δ, UL.fitResidual, PiLp.sub_apply, PiLp.add_apply, PiLp.smul_apply,
            smul_eq_mul]
          ring
        rw [hvec, inner_add_left, inner_smul_left]
        simp
      have hUniv_ne : (Finset.univ : Finset (Fin K)).Nonempty := by
        haveI : Nonempty (Fin K) := ⟨⟨0, by omega⟩⟩
        exact Finset.univ_nonempty
      have hg_spec : UL.HasFaceGradAt Φ Finset.univ (p_δ (P ω)) (k (P ω)) :=
        UL.Proof_lem_A_5.faceGrad_spec (hΦ.2.2.1 Finset.univ hUniv_ne (p_δ (P ω)) hpδ_relint)
      have hu_face : UL.uniformVec K ∈ UL.SimplexFace K Finset.univ := by
        rw [UL.Proof_lem_A_5.simplexFace_univ]
        exact UL.Proof_lem_A_4.uniformVec_mem_simplex hK
      have hsub_u : inner ℝ (k (P ω)) (UL.uniformVec K - p_δ (P ω)) ≤
          UL.extendSimplex Φ (UL.uniformVec K) - UL.extendSimplex Φ (p_δ (P ω)) :=
        UL.Proof_lem_A_5.subgradient_ineq_of_hasFaceGradAt hΦ_conv hpδ_relint.1 hg_spec hu_face
      have h_u_rel : δ * inner ℝ (UL.uniformVec K - P ω) (k (P ω)) ≤
          (δ / (1 - δ)) * (UL.extendSimplex Φ (UL.uniformVec K) - UL.extendSimplex Φ (p_δ (P ω))) := by
        have hvec_u : UL.uniformVec K - p_δ (P ω) = (1 - δ) • (UL.uniformVec K - P ω) := by
          ext j
          simp only [p_δ, PiLp.sub_apply, PiLp.add_apply, PiLp.smul_apply, smul_eq_mul]
          ring
        rw [hvec_u, inner_smul_right] at hsub_u
        have hmul := mul_le_mul_of_nonneg_left hsub_u (div_pos hδ.1 h1d_pos).le
        have hlhs : (δ / (1 - δ)) * ((1 - δ) * inner ℝ (k (P ω)) (UL.uniformVec K - P ω)) =
            δ * inner ℝ (UL.uniformVec K - P ω) (k (P ω)) := by
          rw [real_inner_comm]
          field_simp [h1d_pos.ne']
        linarith
      have hJ_pt : (1 - δ) * UL.extendSimplex Φ (P ω) +
          δ * UL.extendSimplex Φ (UL.uniformVec K) - UL.extendSimplex Φ (p_δ (P ω)) ≤ JΦ_δ :=
        jensenGap_pointwise_le hΦ_cont hδ (hP_simp ω)
      have hJ_div : -UL.extendSimplex Φ (p_δ (P ω)) +
          (δ / (1 - δ)) * (UL.extendSimplex Φ (UL.uniformVec K) - UL.extendSimplex Φ (p_δ (P ω))) ≤
          -UL.extendSimplex Φ (P ω) + JΦ_δ / (1 - δ) := by
        have halg : (-UL.extendSimplex Φ (p_δ (P ω)) +
            (δ / (1 - δ)) * (UL.extendSimplex Φ (UL.uniformVec K) - UL.extendSimplex Φ (p_δ (P ω)))) -
            (-UL.extendSimplex Φ (P ω)) =
            ((1 - δ) * UL.extendSimplex Φ (P ω) + δ * UL.extendSimplex Φ (UL.uniformVec K) -
              UL.extendSimplex Φ (p_δ (P ω))) / (1 - δ) := by
          field_simp [h1d_pos.ne']
          ring
        have hdiv_le : ((1 - δ) * UL.extendSimplex Φ (P ω) +
            δ * UL.extendSimplex Φ (UL.uniformVec K) - UL.extendSimplex Φ (p_δ (P ω))) / (1 - δ) ≤
            JΦ_δ / (1 - δ) := div_le_div_of_nonneg_right hJ_pt h1d_pos.le
        linarith
      rw [h_fenchel_eq, h_split_inner]
      linarith
    have hInt_rk : Integrable (fun ω => inner ℝ (UL.fitResidual P Y ω) (k (P ω))) μ :=
      UL.Proof_lem_A_4.integrable_of_aestronglyMeasurable_bounded
        (hr_meas.inner hkP_meas).aestronglyMeasurable (2 * (|M_k| + 1)) (fun ω => by
          rw [Real.norm_eq_abs]
          have hr_b := UL.Proof_lem_A_4.fitResidual_norm_le_two Y hP_simp ω
          have hk_b : ‖k (P ω)‖ ≤ |M_k| + 1 :=
            (hM_k _ ⟨P ω, hP_simp ω, rfl⟩).trans (by linarith [le_abs_self M_k])
          calc |inner ℝ (UL.fitResidual P Y ω) (k (P ω))|
              ≤ ‖UL.fitResidual P Y ω‖ * ‖k (P ω)‖ := abs_real_inner_le_norm _ _
            _ ≤ 2 * (|M_k| + 1) := mul_le_mul hr_b hk_b (norm_nonneg _) (by norm_num))
    have hInt_negΦP : Integrable (fun ω => -UL.extendSimplex Φ (P ω)) μ := hInt_ΦP.neg
    have hInt_lhs1 : Integrable (fun ω => -UL.extendSimplex Φ (P ω) + JΦ_δ / (1 - δ)) μ :=
      hInt_negΦP.add (integrable_const (JΦ_δ / (1 - δ)))
    have hInt_lhs2 : Integrable (fun ω =>
        -UL.extendSimplex Φ (P ω) + JΦ_δ / (1 - δ) +
          inner ℝ (UL.fitResidual P Y ω) (k (P ω))) μ :=
      hInt_lhs1.add hInt_rk
    have h_upper_int : ∫ ω, UL.matchingLoss Φ (k (P ω)) (Y ω) ∂μ ≤
        -(∫ ω, UL.extendSimplex Φ (P ω) ∂μ) + JΦ_δ / (1 - δ) +
          ((1 - δ) / β) * b := by
      have h1 : ∫ ω, UL.matchingLoss Φ (k (P ω)) (Y ω) ∂μ ≤
          ∫ ω, (-UL.extendSimplex Φ (P ω) + JΦ_δ / (1 - δ) +
            inner ℝ (UL.fitResidual P Y ω) (k (P ω))) ∂μ :=
        integral_mono hk_loss_int hInt_lhs2 h_ptwise_upper
      rw [integral_add hInt_lhs1 hInt_rk,
        integral_add hInt_negΦP (integrable_const (JΦ_δ / (1 - δ))), integral_neg] at h1
      simp only [integral_const, probReal_univ, one_smul] at h1
      have h_trim_b : ∫ ω, inner ℝ (UL.fitResidual P Y ω) (k (P ω)) ∂μ ≤ ((1 - δ) / β) * b :=
        h_trimmed
      linarith [h_trim_b]
    have h_neg_db : -(δ * b / β) ≤ δ * (1 - 1 / (K : ℝ)) / (4 * β) := by
      have h1 : -b ≤ (1 / 4 : ℝ) * (1 - 1 / (K : ℝ)) := by linarith [hb_lb]
      have h2 : δ * (-b) ≤ δ * ((1 / 4 : ℝ) * (1 - 1 / (K : ℝ))) :=
        mul_le_mul_of_nonneg_left h1 hδ.1.le
      have h3 : (δ * (-b)) / β ≤ (δ * ((1 / 4 : ℝ) * (1 - 1 / (K : ℝ)))) / β :=
        div_le_div_of_nonneg_right h2 hβ.le
      calc -(δ * b / β) = (δ * (-b)) / β := by ring
        _ ≤ (δ * ((1 / 4 : ℝ) * (1 - 1 / (K : ℝ)))) / β := h3
        _ = δ * (1 - 1 / (K : ℝ)) / (4 * β) := by ring
    refine ⟨hk_loss_int, fun V _ => h_comp_int V, h_bdd_below, ?_⟩
    have h_ne_img : ((fun V => ∫ ω, UL.matchingLoss Φ (V (X ω)) (Y ω) ∂μ) '' 𝒲).Nonempty :=
      h𝒲.1.image _
    have h_le_sinf : (∫ ω, UL.matchingLoss Φ (k (P ω)) (Y ω) ∂μ) -
        (JΦ_δ / (1 - δ) + δ * (1 - 1 / (K : ℝ)) / (4 * β)) ≤
        sInf ((fun V => ∫ ω, UL.matchingLoss Φ (V (X ω)) (Y ω) ∂μ) '' 𝒲) := by
      refine le_csInf h_ne_img ?_
      rintro _ ⟨V, hV, rfl⟩
      have hV_lb := h_comp_lb V hV
      have halg : ((1 - δ) / β) * b - b / β = -(δ * b / β) := by
        field_simp [hβ.ne']; ring
      linarith
    linarith

end UL.Proof_cor_A_8

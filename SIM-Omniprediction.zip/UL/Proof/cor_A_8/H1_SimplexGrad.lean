import Mathlib
import UL.Stmt.cor_A_8
import UL.Proof.lem_A_1.H1_FaceSubgrad
import UL.Proof.lem_A_4.H1_SimplexFit
import UL.Proof.lem_A_5.H1_Simplex

set_option autoImplicit false

namespace UL.Proof_cor_A_8

open Set Filter Topology

/-! ### K = 1 degeneracy helpers -/

lemma fin1_eq_zero (j : Fin 1) : j = 0 := Subsingleton.elim j 0

lemma zeroSumSubspace_one_eq_zero {v : EuclideanSpace ℝ (Fin 1)}
    (hv : v ∈ UL.ZeroSumSubspace 1) : v = 0 := by
  have hsum : ∑ j : Fin 1, v j = 0 := (UL.Proof_lem_A_5.mem_zeroSumSubspace_iff 1 v).mp hv
  ext j
  rw [fin1_eq_zero j]
  simpa using hsum

lemma simplex_one_eq_uniformVec {q : EuclideanSpace ℝ (Fin 1)}
    (hq : q ∈ UL.Simplex 1) : q = UL.uniformVec 1 := by
  have hsum : q 0 = 1 := by simpa using hq.2
  ext j
  rw [fin1_eq_zero j, hsum, UL.Proof_lem_A_5.uniformVec_apply]
  norm_num

lemma faceGrad_mem_zeroSumSubspace {K : ℕ} (Φ : UL.Simplex K → ℝ)
    (J : Finset (Fin K)) (p : EuclideanSpace ℝ (Fin K)) :
    UL.faceGrad Φ J p ∈ UL.ZeroSumSubspace K := by
  classical
  unfold UL.faceGrad
  split_ifs with h
  · have hg : UL.HasFaceGradAt Φ J p (Classical.choose h) := Classical.choose_spec h
    exact (UL.Proof_lem_A_1.mem_faceTangentSpace_iff (Classical.choose h)).mp hg.1 |>.1
  · exact Submodule.zero_mem _

lemma simplexGrad_mem_zeroSumSubspace {K : ℕ} (Φ : UL.Simplex K → ℝ)
    (p : EuclideanSpace ℝ (Fin K)) :
    UL.simplexGrad Φ p ∈ UL.ZeroSumSubspace K :=
  faceGrad_mem_zeroSumSubspace Φ Finset.univ p

/-! ### EntropyFamily convexity and oscillation -/

lemma convexOn_quad_term {K : ℕ} {β : ℝ} (hβ : 0 < β) :
    ConvexOn ℝ (UL.Simplex K)
      (fun q => (1 / (2 * β)) * ‖q - UL.uniformVec K‖ ^ 2) := by
  refine ⟨UL.Proof_lem_A_4.simplex_convex K, fun x _ y _ a b ha hb hab => ?_⟩
  dsimp only
  simp only [smul_eq_mul]
  have hcomb : (a • x + b • y) - UL.uniformVec K =
      a • (x - UL.uniformVec K) + b • (y - UL.uniformVec K) := by
    calc (a • x + b • y) - UL.uniformVec K
        = (a • x + b • y) - (a + b) • UL.uniformVec K := by rw [hab, one_smul]
      _ = a • (x - UL.uniformVec K) + b • (y - UL.uniformVec K) := by
          rw [add_smul, smul_sub, smul_sub]; abel
  rw [hcomb]
  set v := x - UL.uniformVec K
  set w := y - UL.uniformVec K
  have hnorm_ineq : ‖a • v + b • w‖ ^ 2 ≤ a * ‖v‖ ^ 2 + b * ‖w‖ ^ 2 := by
    have hid : a * ‖v‖ ^ 2 + b * ‖w‖ ^ 2 - ‖a • v + b • w‖ ^ 2 =
        a * b * ‖v - w‖ ^ 2 := by
      have h1 : ‖a • v + b • w‖ ^ 2 =
          a ^ 2 * ‖v‖ ^ 2 + 2 * a * b * inner ℝ v w + b ^ 2 * ‖w‖ ^ 2 := by
        rw [norm_add_sq_real, norm_smul, norm_smul, Real.norm_eq_abs, Real.norm_eq_abs,
          abs_of_nonneg ha, abs_of_nonneg hb, inner_smul_left, inner_smul_right]
        simp only [conj_trivial]
        ring
      have h2 : ‖v - w‖ ^ 2 = ‖v‖ ^ 2 - 2 * inner ℝ v w + ‖w‖ ^ 2 := norm_sub_sq_real v w
      calc a * ‖v‖ ^ 2 + b * ‖w‖ ^ 2 - ‖a • v + b • w‖ ^ 2
          = a * (a + b) * ‖v‖ ^ 2 + b * (a + b) * ‖w‖ ^ 2 - ‖a • v + b • w‖ ^ 2 := by
              rw [hab]; ring
        _ = a * b * (‖v‖ ^ 2 - 2 * inner ℝ v w + ‖w‖ ^ 2) := by rw [h1]; ring
        _ = a * b * ‖v - w‖ ^ 2 := by rw [h2]
    have hnn : 0 ≤ a * b * ‖v - w‖ ^ 2 := mul_nonneg (mul_nonneg ha hb) (sq_nonneg _)
    linarith
  have hc : 0 ≤ 1 / (2 * β) := by positivity
  calc (1 / (2 * β)) * ‖a • v + b • w‖ ^ 2
      ≤ (1 / (2 * β)) * (a * ‖v‖ ^ 2 + b * ‖w‖ ^ 2) := mul_le_mul_of_nonneg_left hnorm_ineq hc
    _ = a * ((1 / (2 * β)) * ‖v‖ ^ 2) + b * ((1 / (2 * β)) * ‖w‖ ^ 2) := by ring

lemma convexOn_extendSimplex_of_mem_entropyFamily {K : ℕ} {β : ℝ} {Φ : UL.Simplex K → ℝ}
    (hΦ : Φ ∈ UL.EntropyFamily K β) :
    ConvexOn ℝ (UL.Simplex K) (UL.extendSimplex Φ) := by
  obtain ⟨hβ, _, _, hconv⟩ := hΦ
  have hsum := hconv.add (convexOn_quad_term (K := K) hβ)
  refine hsum.congr (fun q _ => ?_)
  dsimp only [Pi.add_apply]
  ring

lemma exists_oscillation_bound_ge_one {K : ℕ} (hK : 1 ≤ K) {F : UL.Simplex K → ℝ}
    (hF : Continuous F) :
    ∃ D : ℝ, 0 ≤ D ∧ ∀ p ∈ UL.Simplex K, ∀ q ∈ UL.Simplex K,
      UL.extendSimplex F p - UL.extendSimplex F q ≤ D := by
  have hne : (UL.Simplex K).Nonempty := ⟨UL.uniformVec K, UL.Proof_lem_A_4.uniformVec_mem_simplex hK⟩
  have hcomp : IsCompact (UL.Simplex K) := UL.Proof_lem_A_5.isCompact_simplex K
  have hcont : ContinuousOn (UL.extendSimplex F) (UL.Simplex K) :=
    UL.Proof_lem_A_5.continuousOn_extendSimplex hF
  obtain ⟨p_max, hp_max, hmax⟩ := hcomp.exists_isMaxOn hne hcont
  obtain ⟨p_min, hp_min, hmin⟩ := hcomp.exists_isMinOn hne hcont
  refine ⟨UL.extendSimplex F p_max - UL.extendSimplex F p_min, ?_, fun p hp q hq => ?_⟩
  · have h0 : UL.extendSimplex F p_min ≤ UL.extendSimplex F p_max := hmin hp_max
    linarith
  · have h1 : UL.extendSimplex F p ≤ UL.extendSimplex F p_max := hmax hp
    have h2 : UL.extendSimplex F p_min ≤ UL.extendSimplex F q := hmin hq
    linarith

/-! ### Face gradient uniqueness and continuity of `simplexGrad` -/

lemma hasFaceGradAt_unique {K : ℕ} {Ψ : UL.Simplex K → ℝ} {J : Finset (Fin K)}
    (hJ : J.Nonempty) {p g₁ g₂ : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ UL.SimplexFaceRelint K J)
    (hg₁ : UL.HasFaceGradAt Ψ J p g₁) (hg₂ : UL.HasFaceGradAt Ψ J p g₂) :
    g₁ = g₂ := by
  have hdiff_mem : g₁ - g₂ ∈ UL.FaceTangentSpace K J := Submodule.sub_mem _ hg₁.1 hg₂.1
  have hd₁ := UL.Proof_lem_A_5.hasDerivAt_line_of_hasFaceGradAt hJ hp hg₁ hdiff_mem
  have hd₂ := UL.Proof_lem_A_5.hasDerivAt_line_of_hasFaceGradAt hJ hp hg₂ hdiff_mem
  have heq : inner ℝ g₁ (g₁ - g₂) = inner ℝ g₂ (g₁ - g₂) := hd₁.unique hd₂
  have hzero : inner ℝ (g₁ - g₂) (g₁ - g₂) = 0 := by
    rw [inner_sub_left, heq, sub_self]
  exact sub_eq_zero.mp (inner_self_eq_zero.mp hzero)

lemma faceGrad_eq_of_hasFaceGradAt {K : ℕ} {Ψ : UL.Simplex K → ℝ} {J : Finset (Fin K)}
    (hJ : J.Nonempty) {p g : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ UL.SimplexFaceRelint K J) (hg : UL.HasFaceGradAt Ψ J p g) :
    UL.faceGrad Ψ J p = g :=
  hasFaceGradAt_unique hJ hp (UL.Proof_lem_A_5.faceGrad_spec ⟨g, hg⟩) hg

lemma isClosed_zeroSumSubspace (K : ℕ) :
    IsClosed (UL.ZeroSumSubspace K : Set (EuclideanSpace ℝ (Fin K))) := by
  have hEq : (UL.ZeroSumSubspace K : Set (EuclideanSpace ℝ (Fin K))) =
      {v | inner ℝ (UL.onesVec K) v = 0} := by
    ext v
    exact UL.Proof_lem_A_1.mem_zeroSumSubspace_iff v
  rw [hEq]
  exact isClosed_eq ((innerSL ℝ (UL.onesVec K)).continuous) continuous_const

lemma continuousWithinAt_simplexGrad {K : ℕ} (hK : 2 ≤ K) {β : ℝ} {Φ : UL.Simplex K → ℝ}
    (hΦ : Φ ∈ UL.EntropyFamily K β) {p₀ : EuclideanSpace ℝ (Fin K)}
    (hp₀ : p₀ ∈ UL.SimplexFaceRelint K Finset.univ) :
    ContinuousWithinAt (UL.simplexGrad Φ) (UL.Simplex K) p₀ := by
  have hΦ_conv : ConvexOn ℝ (UL.Simplex K) (UL.extendSimplex Φ) :=
    convexOn_extendSimplex_of_mem_entropyFamily hΦ
  obtain ⟨_, hΦ_cont, hΦ_diff, _⟩ := hΦ
  have hK1 : 1 ≤ K := by omega
  have hUniv_ne : (Finset.univ : Finset (Fin K)).Nonempty := by
    haveI : Nonempty (Fin K) := ⟨⟨0, by omega⟩⟩
    exact Finset.univ_nonempty
  obtain ⟨D, hD_nn, hD⟩ := exists_oscillation_bound_ge_one hK1 hΦ_cont
  let m : ℝ := Finset.univ.inf' hUniv_ne (fun j => p₀ j)
  have hm_pos : 0 < m := (Finset.lt_inf'_iff hUniv_ne).mpr (fun j hj => hp₀.2 j hj)
  let R : ℝ := 4 * D / m + 1
  have h_local : ∀ q ∈ UL.Simplex K, ‖q - p₀‖ ≤ m / 4 →
      q ∈ UL.SimplexFaceRelint K Finset.univ ∧ ‖UL.simplexGrad Φ q‖ ≤ R := by
    intro q hq hq_dist
    have hq_pos : ∀ j ∈ (Finset.univ : Finset (Fin K)), 3 * m / 4 ≤ q j := by
      intro j _
      have hp₀j : m ≤ p₀ j := Finset.inf'_le (fun i => p₀ i) (Finset.mem_univ j)
      have hqj_diff : |q j - p₀ j| ≤ m / 4 := by
        calc |q j - p₀ j| = ‖(q - p₀) j‖ := by rw [PiLp.sub_apply, Real.norm_eq_abs]
          _ ≤ ‖q - p₀‖ := PiLp.norm_apply_le (q - p₀) j
          _ ≤ m / 4 := hq_dist
      linarith [(abs_le.mp hqj_diff).1]
    have hq_relint : q ∈ UL.SimplexFaceRelint K Finset.univ := by
      refine ⟨⟨hq, fun j hj => False.elim (hj (Finset.mem_univ j))⟩, fun j hj => ?_⟩
      linarith [hq_pos j hj]
    refine ⟨hq_relint, ?_⟩
    set g := UL.simplexGrad Φ q
    have hg_spec : UL.HasFaceGradAt Φ Finset.univ q g :=
      UL.Proof_lem_A_5.faceGrad_spec (hΦ_diff Finset.univ hUniv_ne q hq_relint)
    have hg_zs : g ∈ UL.ZeroSumSubspace K := by
      rw [← UL.Proof_lem_A_5.faceTangentSpace_univ]
      exact hg_spec.1
    let c : ℝ := (m / 2) / (‖g‖ + 1)
    have hc_pos : 0 < c := div_pos (by linarith) (by positivity)
    let v : EuclideanSpace ℝ (Fin K) := c • g
    have hv_norm : ‖v‖ ≤ m / 2 := by
      rw [norm_smul, Real.norm_eq_abs, abs_of_pos hc_pos]
      calc (m / 2) / (‖g‖ + 1) * ‖g‖
          = (m / 2) * (‖g‖ / (‖g‖ + 1)) := by ring
        _ ≤ (m / 2) * 1 := by
            refine mul_le_mul_of_nonneg_left ?_ (by linarith)
            rw [div_le_one (by positivity)]
            linarith
        _ = m / 2 := mul_one _
    have hqv_mem : q + v ∈ UL.Simplex K := by
      refine ⟨fun j => ?_, ?_⟩
      · have hvj : |v j| ≤ m / 2 :=
          (Real.norm_eq_abs (v j) ▸ PiLp.norm_apply_le v j).trans hv_norm
        have hqj := hq_pos j (Finset.mem_univ j)
        simp only [PiLp.add_apply]
        linarith [(abs_le.mp hvj).1]
      · have hv_sum : ∑ j : Fin K, v j = 0 :=
          (UL.Proof_lem_A_5.mem_zeroSumSubspace_iff K v).mp (Submodule.smul_mem _ c hg_zs)
        simp [Finset.sum_add_distrib, hq.2, hv_sum]
    have hqv_face : q + v ∈ UL.SimplexFace K Finset.univ := by
      rwa [UL.Proof_lem_A_5.simplexFace_univ]
    have hsub : inner ℝ g ((q + v) - q) ≤ UL.extendSimplex Φ (q + v) - UL.extendSimplex Φ q :=
      UL.Proof_lem_A_5.subgradient_ineq_of_hasFaceGradAt hΦ_conv hq_relint.1 hg_spec hqv_face
    have hstep : c * ‖g‖ ^ 2 ≤ D := by
      have h1 : inner ℝ g ((q + v) - q) = c * ‖g‖ ^ 2 := by
        simp [v, inner_smul_right, real_inner_self_eq_norm_sq]
      linarith [hD (q + v) hqv_mem q hq]
    have h2 : (m / 2) * ‖g‖ ^ 2 ≤ D * (‖g‖ + 1) := by
      dsimp [c] at hstep
      have hpos : (0 : ℝ) < ‖g‖ + 1 := by positivity
      calc (m / 2) * ‖g‖ ^ 2
          = ((m / 2) / (‖g‖ + 1) * ‖g‖ ^ 2) * (‖g‖ + 1) := by field_simp [hpos.ne']
        _ ≤ D * (‖g‖ + 1) := mul_le_mul_of_nonneg_right hstep hpos.le
    by_contra hgt
    push_neg at hgt
    have hg_ge1 : 1 ≤ ‖g‖ := by
      dsimp [R] at hgt
      have : 0 ≤ 4 * D / m := div_nonneg (by linarith) hm_pos.le
      linarith
    have h3 : (m / 2) * ‖g‖ ^ 2 ≤ 2 * D * ‖g‖ := by nlinarith
    have hg_pos : 0 < ‖g‖ := by linarith
    have h4 : (m / 2) * ‖g‖ ≤ 2 * D := by nlinarith
    have h5 : ‖g‖ ≤ 4 * D / m := by
      rw [le_div_iff₀ hm_pos]
      linarith
    dsimp [R] at hgt
    linarith
  by_contra hnot_cont
  rw [Metric.continuousWithinAt_iff] at hnot_cont
  push_neg at hnot_cont
  obtain ⟨ε₀, hε₀, hbad⟩ := hnot_cont
  have hex_seq : ∀ n : ℕ, ∃ x ∈ UL.Simplex K,
      dist x p₀ < 1 / ((n : ℝ) + 1) ∧ ε₀ ≤ dist (UL.simplexGrad Φ x) (UL.simplexGrad Φ p₀) :=
    fun n => hbad (1 / ((n : ℝ) + 1)) (by positivity)
  choose q hq_mem hq_dist hq_far using hex_seq
  have hq_tendsto : Tendsto q atTop (𝓝 p₀) := by
    rw [Metric.tendsto_atTop]
    intro ε hε
    obtain ⟨N, hN⟩ := exists_nat_gt (1 / ε)
    refine ⟨N, fun n hn => ?_⟩
    have hn_gt : 1 / ε < (n : ℝ) + 1 := by
      have : (N : ℝ) ≤ (n : ℝ) := Nat.cast_le.mpr hn
      linarith
    have hdiv : 1 / ((n : ℝ) + 1) < ε := (div_lt_iff₀ (by positivity)).mpr
      ((div_lt_iff₀ hε).mp hn_gt |>.trans_eq (mul_comm _ _))
    exact (hq_dist n).trans hdiv
  have h_ev_near : ∀ᶠ n in atTop, ‖q n - p₀‖ ≤ m / 4 := by
    have h_ball : Metric.ball p₀ (m / 4) ∈ 𝓝 p₀ := Metric.ball_mem_nhds p₀ (by linarith)
    filter_upwards [hq_tendsto h_ball] with n hn
    simp only [Set.mem_preimage, Metric.mem_ball, dist_eq_norm] at hn
    exact hn.le
  rw [Filter.eventually_atTop] at h_ev_near
  obtain ⟨N₀, hN₀⟩ := h_ev_near
  let q' : ℕ → EuclideanSpace ℝ (Fin K) := fun k => q (k + N₀)
  let g' : ℕ → EuclideanSpace ℝ (Fin K) := fun k => UL.simplexGrad Φ (q' k)
  have hq'_tendsto : Tendsto q' atTop (𝓝 p₀) :=
    hq_tendsto.comp (tendsto_add_atTop_nat N₀)
  have hg'_in_ball : ∀ k : ℕ, g' k ∈ Metric.closedBall (0 : EuclideanSpace ℝ (Fin K)) R := by
    intro k
    have hloc := h_local (q' k) (hq_mem (k + N₀)) (hN₀ (k + N₀) (Nat.le_add_left N₀ k))
    rw [Metric.mem_closedBall, dist_zero_right]
    exact hloc.2
  obtain ⟨g_star, _, ψ, hψ_mono, hg'_sub_tendsto⟩ :=
    (isCompact_closedBall (0 : EuclideanSpace ℝ (Fin K)) R).tendsto_subseq hg'_in_ball
  have hq'_sub_tendsto : Tendsto (q' ∘ ψ) atTop (𝓝 p₀) :=
    hq'_tendsto.comp hψ_mono.tendsto_atTop
  have hg_star_zs : g_star ∈ UL.ZeroSumSubspace K :=
    (isClosed_zeroSumSubspace K).mem_of_tendsto hg'_sub_tendsto
      (Eventually.of_forall fun k => simplexGrad_mem_zeroSumSubspace Φ (q' (ψ k)))
  have hg_star_subgrad : ∀ y ∈ UL.Simplex K,
      inner ℝ g_star (y - p₀) ≤ UL.extendSimplex Φ y - UL.extendSimplex Φ p₀ := by
    intro y hy
    have hy_face : y ∈ UL.SimplexFace K Finset.univ := by
      rwa [UL.Proof_lem_A_5.simplexFace_univ]
    have hineq_k : ∀ k : ℕ,
        inner ℝ (g' (ψ k)) (y - q' (ψ k)) ≤ UL.extendSimplex Φ y - UL.extendSimplex Φ (q' (ψ k)) := by
      intro k
      have hloc := h_local (q' (ψ k)) (hq_mem (ψ k + N₀))
        (hN₀ (ψ k + N₀) (Nat.le_add_left N₀ (ψ k)))
      have hg_spec : UL.HasFaceGradAt Φ Finset.univ (q' (ψ k)) (g' (ψ k)) :=
        UL.Proof_lem_A_5.faceGrad_spec (hΦ_diff Finset.univ hUniv_ne (q' (ψ k)) hloc.1)
      exact UL.Proof_lem_A_5.subgradient_ineq_of_hasFaceGradAt hΦ_conv hloc.1.1 hg_spec hy_face
    have h_lhs : Tendsto (fun k => inner ℝ (g' (ψ k)) (y - q' (ψ k))) atTop (𝓝 (inner ℝ g_star (y - p₀))) :=
      Filter.Tendsto.inner hg'_sub_tendsto (tendsto_const_nhds.sub hq'_sub_tendsto)
    have hΦ_cont_on : ContinuousOn (UL.extendSimplex Φ) (UL.Simplex K) :=
      UL.Proof_lem_A_5.continuousOn_extendSimplex hΦ_cont
    have hq'_within : Tendsto (q' ∘ ψ) atTop (𝓝[UL.Simplex K] p₀) :=
      tendsto_nhdsWithin_of_tendsto_nhds_of_eventually_within _ hq'_sub_tendsto
        (Eventually.of_forall fun k => hq_mem (ψ k + N₀))
    have h_rhs : Tendsto (fun k => UL.extendSimplex Φ y - UL.extendSimplex Φ (q' (ψ k)))
        atTop (𝓝 (UL.extendSimplex Φ y - UL.extendSimplex Φ p₀)) :=
      tendsto_const_nhds.sub ((hΦ_cont_on p₀ hp₀.1.1).tendsto.comp hq'_within)
    exact le_of_tendsto_of_tendsto h_lhs h_rhs (Eventually.of_forall hineq_k)
  set g₀ := UL.simplexGrad Φ p₀
  have hg₀_spec : UL.HasFaceGradAt Φ Finset.univ p₀ g₀ :=
    UL.Proof_lem_A_5.faceGrad_spec (hΦ_diff Finset.univ hUniv_ne p₀ hp₀)
  have hg₀_zs : g₀ ∈ UL.ZeroSumSubspace K := simplexGrad_mem_zeroSumSubspace Φ p₀
  have h_dir_le : ∀ v ∈ UL.ZeroSumSubspace K, inner ℝ g_star v ≤ inner ℝ g₀ v := by
    intro v hv
    have hv_ft : v ∈ UL.FaceTangentSpace K Finset.univ := by
      rwa [UL.Proof_lem_A_5.faceTangentSpace_univ]
    obtain ⟨h₀, hh₀_pos, hpert⟩ :=
      UL.Proof_lem_A_5.exists_relint_perturbation hUniv_ne hp₀ hv_ft
    have hderiv := UL.Proof_lem_A_5.hasDerivAt_line_of_hasFaceGradAt hUniv_ne hp₀ hg₀_spec hv_ft
    have hslope_tendsto : Tendsto
        (fun t : ℝ => (UL.extendSimplex Φ (p₀ + t • v) - UL.extendSimplex Φ p₀) / t)
        (𝓝[>] (0 : ℝ)) (𝓝 (inner ℝ g₀ v)) := by
      have h1 := hderiv.tendsto_slope_zero_right
      refine h1.congr' ?_
      filter_upwards [self_mem_nhdsWithin] with t _
      dsimp [slope_def_field]
      simp [div_eq_inv_mul]
    have hslope_ge : ∀ᶠ t : ℝ in 𝓝[>] (0 : ℝ),
        inner ℝ g_star v ≤ (UL.extendSimplex Φ (p₀ + t • v) - UL.extendSimplex Φ p₀) / t := by
      filter_upwards [Ioo_mem_nhdsGT hh₀_pos] with t ht
      have hmem : p₀ + t • v ∈ UL.Simplex K :=
        (hpert t (abs_le.mpr ⟨by linarith [ht.1], ht.2.le⟩)).1.1
      have hsub := hg_star_subgrad (p₀ + t • v) hmem
      have hdiff : (p₀ + t • v) - p₀ = t • v := by abel
      rw [hdiff, inner_smul_right] at hsub
      exact (le_div_iff₀ ht.1).mpr (by linarith)
    exact le_of_tendsto_of_tendsto tendsto_const_nhds hslope_tendsto hslope_ge
  have hv_diff : g_star - g₀ ∈ UL.ZeroSumSubspace K := Submodule.sub_mem _ hg_star_zs hg₀_zs
  have hle := h_dir_le (g_star - g₀) hv_diff
  have hnorm_zero : ‖g_star - g₀‖ ^ 2 ≤ 0 := by
    rw [← real_inner_self_eq_norm_sq, inner_sub_left]
    linarith
  have hg_eq : g_star = g₀ := by
    have h0 : ‖g_star - g₀‖ = 0 := by
      have hsq : ‖g_star - g₀‖ ^ 2 = 0 := le_antisymm hnorm_zero (sq_nonneg _)
      exact sq_eq_zero_iff.mp hsq
    exact sub_eq_zero.mp (norm_eq_zero.mp h0)
  have hdist_lim : Tendsto (fun k => dist (g' (ψ k)) g₀) atTop (𝓝 (dist g_star g₀)) :=
    hg'_sub_tendsto.dist tendsto_const_nhds
  have hdist_ge : ε₀ ≤ dist g_star g₀ :=
    le_of_tendsto_of_tendsto tendsto_const_nhds hdist_lim
      (Eventually.of_forall fun k => hq_far (ψ k + N₀))
  rw [hg_eq, dist_self] at hdist_ge
  linarith

/-! ### Smoothed action rule `kΦδ` -/

lemma kΦδ_properties {K : ℕ} (hK : 1 ≤ K) {β : ℝ} {Φ : UL.Simplex K → ℝ}
    (hΦ : Φ ∈ UL.EntropyFamily K β) {δ : ℝ} (hδ : δ ∈ Set.Ioo (0 : ℝ) 1) :
    let p_δ := fun p : EuclideanSpace ℝ (Fin K) => (1 - δ) • p + δ • UL.uniformVec K
    let k := fun p : EuclideanSpace ℝ (Fin K) => UL.simplexGrad Φ (p_δ p)
    (∀ p ∈ UL.Simplex K, k p ∈ UL.ZeroSumSubspace K) ∧
    ContinuousOn k (UL.Simplex K) ∧
    Bornology.IsBounded (k '' UL.Simplex K) := by
  intro p_δ k
  have hk_zs : ∀ p ∈ UL.Simplex K, k p ∈ UL.ZeroSumSubspace K :=
    fun p _ => simplexGrad_mem_zeroSumSubspace Φ (p_δ p)
  have hk_cont : ContinuousOn k (UL.Simplex K) := by
    rcases eq_or_lt_of_le hK with hK_eq | hK_gt
    · subst hK_eq
      have hk_zero : ∀ p, k p = 0 := fun p =>
        zeroSumSubspace_one_eq_zero (simplexGrad_mem_zeroSumSubspace Φ (p_δ p))
      have hk_eq : k = fun _ => (0 : EuclideanSpace ℝ (Fin 1)) := funext hk_zero
      rw [hk_eq]
      exact continuousOn_const
    · have hK2 : 2 ≤ K := by omega
      have hp_δ_cont : Continuous p_δ :=
        (continuous_id.const_smul (1 - δ)).add continuous_const
      intro p hp
      have hp_relint : p_δ p ∈ UL.SimplexFaceRelint K Finset.univ :=
        UL.Proof_lem_A_5.trimmed_mem_simplexFaceRelint_univ hK2 hp hδ.1 hδ.2
      have hgrad_cont : ContinuousWithinAt (UL.simplexGrad Φ) (UL.Simplex K) (p_δ p) :=
        continuousWithinAt_simplexGrad hK2 hΦ hp_relint
      have hmaps : MapsTo p_δ (UL.Simplex K) (UL.Simplex K) := fun q hq =>
        (UL.Proof_lem_A_5.trimmed_mem_simplexFaceRelint_univ hK2 hq hδ.1 hδ.2).1.1
      exact hgrad_cont.comp (hp_δ_cont.continuousWithinAt) hmaps
  have hk_bdd : Bornology.IsBounded (k '' UL.Simplex K) :=
    ((UL.Proof_lem_A_5.isCompact_simplex K).image_of_continuousOn hk_cont).isBounded
  exact ⟨hk_zs, hk_cont, hk_bdd⟩

/-! ### Matching potential and matching loss properties -/

lemma matchingPotential_bddAbove {K : ℕ} {Φ : UL.Simplex K → ℝ} (hΦ_cont : Continuous Φ)
    (a : EuclideanSpace ℝ (Fin K)) :
    BddAbove (Set.range (fun q : UL.Simplex K =>
      inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) a - Φ q)) := by
  haveI : CompactSpace (UL.Simplex K) :=
    isCompact_iff_compactSpace.mp (UL.Proof_lem_A_5.isCompact_simplex K)
  have hcont : Continuous (fun q : UL.Simplex K =>
      inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) a - Φ q) :=
    ((continuous_subtype_val.sub continuous_const).inner continuous_const).sub hΦ_cont
  exact (isCompact_range hcont).bddAbove

lemma matchingPotential_ge_of_mem {K : ℕ} {Φ : UL.Simplex K → ℝ} (hΦ_cont : Continuous Φ)
    (a : EuclideanSpace ℝ (Fin K)) {q : EuclideanSpace ℝ (Fin K)} (hq : q ∈ UL.Simplex K) :
    inner ℝ (q - UL.uniformVec K) a - UL.extendSimplex Φ q ≤ UL.matchingPotential Φ a := by
  unfold UL.matchingPotential
  have h := le_ciSup (matchingPotential_bddAbove hΦ_cont a) (⟨q, hq⟩ : UL.Simplex K)
  rwa [← UL.Proof_lem_A_5.extendSimplex_eq_of_mem Φ hq] at h

lemma matchingPotential_lipschitz_two {K : ℕ} (hK : 1 ≤ K) {Φ : UL.Simplex K → ℝ}
    (hΦ_cont : Continuous Φ) (a b : EuclideanSpace ℝ (Fin K)) :
    |UL.matchingPotential Φ a - UL.matchingPotential Φ b| ≤ 2 * ‖a - b‖ := by
  haveI : Nonempty (UL.Simplex K) := ⟨⟨UL.uniformVec K, UL.Proof_lem_A_4.uniformVec_mem_simplex hK⟩⟩
  have h_half : ∀ x y : EuclideanSpace ℝ (Fin K),
      UL.matchingPotential Φ x ≤ UL.matchingPotential Φ y + 2 * ‖x - y‖ := by
    intro x y
    unfold UL.matchingPotential
    refine ciSup_le (fun q => ?_)
    have hq_norm : ‖(q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K‖ ≤ 2 := by
      calc ‖(q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K‖
          ≤ ‖(q : EuclideanSpace ℝ (Fin K))‖ + ‖UL.uniformVec K‖ := norm_sub_le _ _
        _ ≤ 1 + 1 := add_le_add (UL.Proof_lem_A_4.simplex_norm_le_one q.2)
            (UL.Proof_lem_A_4.simplex_norm_le_one (UL.Proof_lem_A_4.uniformVec_mem_simplex hK))
        _ = 2 := by norm_num
    have h_diff : inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) (x - y) ≤ 2 * ‖x - y‖ := by
      calc inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) (x - y)
          ≤ ‖(q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K‖ * ‖x - y‖ :=
            real_inner_le_norm _ _
        _ ≤ 2 * ‖x - y‖ := mul_le_mul_of_nonneg_right hq_norm (norm_nonneg _)
    have h_le_y : inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) y - Φ q ≤
        ⨆ q' : UL.Simplex K, (inner ℝ ((q' : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) y - Φ q') :=
      le_ciSup (matchingPotential_bddAbove hΦ_cont y) q
    have h_eq : inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) x =
        inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) y +
          inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) (x - y) := by
      rw [← inner_add_right, add_sub_cancel]
    linarith
  rw [abs_le]
  refine ⟨?_, ?_⟩
  · have := h_half b a
    rw [norm_sub_rev] at this
    linarith
  · linarith [h_half a b]

lemma continuous_matchingPotential {K : ℕ} (hK : 1 ≤ K) {Φ : UL.Simplex K → ℝ}
    (hΦ_cont : Continuous Φ) :
    Continuous (UL.matchingPotential Φ) := by
  have hlip : LipschitzWith 2 (UL.matchingPotential Φ) := by
    rw [lipschitzWith_iff_dist_le_mul]
    intro a b
    simpa [Real.dist_eq, dist_eq_norm] using matchingPotential_lipschitz_two hK hΦ_cont a b
  exact hlip.continuous

lemma continuous_matchingLoss {K : ℕ} (hK : 1 ≤ K) {Φ : UL.Simplex K → ℝ}
    (hΦ_cont : Continuous Φ) :
    Continuous (fun p : EuclideanSpace ℝ (Fin K) × Fin K => UL.matchingLoss Φ p.1 p.2) := by
  rw [continuous_prod_of_discrete_right]
  intro y
  exact (continuous_matchingPotential hK hΦ_cont).sub (EuclideanSpace.proj y).continuous

lemma matchingLoss_abs_le {K : ℕ} (hK : 1 ≤ K) {Φ : UL.Simplex K → ℝ}
    (hΦ_cont : Continuous Φ) (a : EuclideanSpace ℝ (Fin K)) (y : Fin K) :
    |UL.matchingLoss Φ a y| ≤ |UL.matchingPotential Φ 0| + 3 * ‖a‖ := by
  have hpot : |UL.matchingPotential Φ a| ≤ |UL.matchingPotential Φ 0| + 2 * ‖a‖ := by
    have h1 := matchingPotential_lipschitz_two hK hΦ_cont a 0
    rw [sub_zero] at h1
    linarith [abs_sub_abs_le_abs_sub (UL.matchingPotential Φ a) (UL.matchingPotential Φ 0)]
  have hay : |a y| ≤ ‖a‖ := by
    simpa [Real.norm_eq_abs] using PiLp.norm_apply_le a y
  unfold UL.matchingLoss
  calc |UL.matchingPotential Φ a - a y|
      ≤ |UL.matchingPotential Φ a| + |a y| := abs_sub _ _
    _ ≤ (|UL.matchingPotential Φ 0| + 2 * ‖a‖) + ‖a‖ := add_le_add hpot hay
    _ = |UL.matchingPotential Φ 0| + 3 * ‖a‖ := by ring

lemma matchingLoss_fenchel_lower {K : ℕ} {Φ : UL.Simplex K → ℝ}
    (hΦ_cont : Continuous Φ) {p a : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ UL.Simplex K) (ha : a ∈ UL.ZeroSumSubspace K) (y : Fin K) :
    -UL.extendSimplex Φ p + inner ℝ (p - UL.oneHotVec y) a ≤ UL.matchingLoss Φ a y := by
  have hpot := matchingPotential_ge_of_mem hΦ_cont a hp
  have hu_orth : inner ℝ (UL.uniformVec K) a = 0 := by
    have h1 : inner ℝ (UL.onesVec K) a = 0 := (UL.Proof_lem_A_1.mem_zeroSumSubspace_iff a).mp ha
    unfold UL.uniformVec
    rw [inner_smul_left]
    simp [h1]
  have hey : inner ℝ (UL.oneHotVec y) a = a y := by
    rw [real_inner_comm]
    exact UL.Proof_lem_A_1.inner_single_right a y
  unfold UL.matchingLoss
  rw [inner_sub_left, hu_orth, sub_zero] at hpot
  rw [inner_sub_left, hey]
  linarith

/-! ### Jensen gap properties -/

lemma jensenGap_bddAbove {K : ℕ} {Ψ : UL.Simplex K → ℝ} (hΨ_cont : Continuous Ψ) (δ : ℝ)
    (hδ0 : 0 ≤ δ) (hδ1 : δ ≤ 1) :
    BddAbove ((fun p =>
      (1 - δ) * UL.extendSimplex Ψ p + δ * UL.extendSimplex Ψ (UL.uniformVec K) -
        UL.extendSimplex Ψ ((1 - δ) • p + δ • UL.uniformVec K)) '' UL.Simplex K) := by
  have hcomp : IsCompact (UL.Simplex K) := UL.Proof_lem_A_5.isCompact_simplex K
  have hΨ_on : ContinuousOn (UL.extendSimplex Ψ) (UL.Simplex K) :=
    UL.Proof_lem_A_5.continuousOn_extendSimplex hΨ_cont
  rcases eq_or_ne K 0 with rfl | hK0
  · have hempty : UL.Simplex 0 = ∅ := by
      ext q
      simp [UL.Simplex]
    rw [hempty, Set.image_empty]
    exact bddAbove_empty
  · have hK1 : 1 ≤ K := Nat.one_le_iff_ne_zero.mpr hK0
    have hmaps : MapsTo (fun p : EuclideanSpace ℝ (Fin K) => (1 - δ) • p + δ • UL.uniformVec K)
        (UL.Simplex K) (UL.Simplex K) := fun p hp =>
      UL.Proof_lem_A_4.simplex_convex K hp (UL.Proof_lem_A_4.uniformVec_mem_simplex hK1)
        (by linarith) hδ0 (by ring)
    have hcont_on : ContinuousOn (fun p =>
        (1 - δ) * UL.extendSimplex Ψ p + δ * UL.extendSimplex Ψ (UL.uniformVec K) -
          UL.extendSimplex Ψ ((1 - δ) • p + δ • UL.uniformVec K)) (UL.Simplex K) := by
      refine ((continuousOn_const.mul hΨ_on).add continuousOn_const).sub ?_
      exact hΨ_on.comp (((continuous_id.const_smul (1 - δ)).add continuous_const).continuousOn) hmaps
    exact (hcomp.image_of_continuousOn hcont_on).bddAbove

lemma jensenGap_pointwise_le {K : ℕ} {Φ : UL.Simplex K → ℝ} (hΦ_cont : Continuous Φ)
    {δ : ℝ} (hδ : δ ∈ Set.Ioo (0 : ℝ) 1) {p : EuclideanSpace ℝ (Fin K)} (hp : p ∈ UL.Simplex K) :
    (1 - δ) * UL.extendSimplex Φ p + δ * UL.extendSimplex Φ (UL.uniformVec K) -
      UL.extendSimplex Φ ((1 - δ) • p + δ • UL.uniformVec K) ≤
    sSup ((fun q =>
      (1 - δ) * UL.extendSimplex Φ q + δ * UL.extendSimplex Φ (UL.uniformVec K) -
        UL.extendSimplex Φ ((1 - δ) • q + δ • UL.uniformVec K)) '' UL.Simplex K) :=
  le_csSup (jensenGap_bddAbove hΦ_cont δ hδ.1.le hδ.2.le) ⟨p, hp, rfl⟩

lemma jensenGap_nonneg {K : ℕ} (hK : 1 ≤ K) {Φ : UL.Simplex K → ℝ} (hΦ_cont : Continuous Φ)
    {δ : ℝ} (hδ : δ ∈ Set.Ioo (0 : ℝ) 1) :
    0 ≤ sSup ((fun q =>
      (1 - δ) * UL.extendSimplex Φ q + δ * UL.extendSimplex Φ (UL.uniformVec K) -
        UL.extendSimplex Φ ((1 - δ) • q + δ • UL.uniformVec K)) '' UL.Simplex K) := by
  have hu : UL.uniformVec K ∈ UL.Simplex K := UL.Proof_lem_A_4.uniformVec_mem_simplex hK
  have hle := jensenGap_pointwise_le hΦ_cont hδ hu
  have hcomb : (1 - δ) • UL.uniformVec K + δ • UL.uniformVec K = UL.uniformVec K := by
    rw [← add_smul]
    ring_nf
    exact one_smul ℝ _
  rw [hcomb] at hle
  linarith

lemma tendsto_jensenGap {K : ℕ} (hK : 1 ≤ K) {Φ : UL.Simplex K → ℝ} (hΦ_cont : Continuous Φ) :
    let JΦ : ℝ → ℝ := fun δ => sSup ((fun p =>
      (1 - δ) * UL.extendSimplex Φ p + δ * UL.extendSimplex Φ (UL.uniformVec K) -
        UL.extendSimplex Φ ((1 - δ) • p + δ • UL.uniformVec K)) '' UL.Simplex K)
    Tendsto JΦ (nhdsWithin 0 (Set.Ioi 0)) (𝓝 0) := by
  intro JΦ
  rw [Metric.tendsto_nhds]
  intro ε hε
  have hcomp : IsCompact (UL.Simplex K) := UL.Proof_lem_A_5.isCompact_simplex K
  have hcont_on : ContinuousOn (UL.extendSimplex Φ) (UL.Simplex K) :=
    UL.Proof_lem_A_5.continuousOn_extendSimplex hΦ_cont
  have hunif : UniformContinuousOn (UL.extendSimplex Φ) (UL.Simplex K) :=
    hcomp.uniformContinuousOn_of_continuous hcont_on
  rw [Metric.uniformContinuousOn_iff] at hunif
  obtain ⟨r, hr_pos, hr⟩ := hunif (ε / 3) (by linarith)
  obtain ⟨D, hD_nn, hD⟩ := exists_oscillation_bound_ge_one hK hΦ_cont
  let δ₀ : ℝ := min 1 (min (r / 3) ((ε / 3) / (D + 1)))
  have hδ₀_pos : 0 < δ₀ := lt_min zero_lt_one (lt_min (by positivity) (by positivity))
  filter_upwards [Ioo_mem_nhdsGT hδ₀_pos] with δ hδ
  have hδ0 : 0 < δ := hδ.1
  have hδ1 : δ < 1 := lt_of_lt_of_le hδ.2 (min_le_left _ _)
  have hδ_r : δ < r / 3 := lt_of_lt_of_le hδ.2 ((min_le_right _ _).trans (min_le_left _ _))
  have hδ_D : δ < (ε / 3) / (D + 1) :=
    lt_of_lt_of_le hδ.2 ((min_le_right _ _).trans (min_le_right _ _))
  have hJ_nn : 0 ≤ JΦ δ := jensenGap_nonneg hK hΦ_cont ⟨hδ0, hδ1⟩
  have hu : UL.uniformVec K ∈ UL.Simplex K := UL.Proof_lem_A_4.uniformVec_mem_simplex hK
  have hne_img : ((fun p =>
      (1 - δ) * UL.extendSimplex Φ p + δ * UL.extendSimplex Φ (UL.uniformVec K) -
        UL.extendSimplex Φ ((1 - δ) • p + δ • UL.uniformVec K)) '' UL.Simplex K).Nonempty :=
    ⟨_, ⟨UL.uniformVec K, hu, rfl⟩⟩
  have hJ_le : JΦ δ ≤ 2 * ε / 3 := by
    refine csSup_le hne_img ?_
    rintro _ ⟨p, hp, rfl⟩
    let pδ := (1 - δ) • p + δ • UL.uniformVec K
    have hpδ : pδ ∈ UL.Simplex K :=
      UL.Proof_lem_A_4.simplex_convex K hp hu (by linarith) hδ0.le (by ring)
    have hdist_p : dist p pδ < r := by
      rw [dist_eq_norm]
      have hdiff : p - pδ = δ • (p - UL.uniformVec K) := by
        dsimp [pδ]; rw [sub_smul, one_smul, smul_sub]; abel
      rw [hdiff, norm_smul, Real.norm_eq_abs, abs_of_pos hδ0]
      have hpu : ‖p - UL.uniformVec K‖ ≤ 2 := by
        calc ‖p - UL.uniformVec K‖ ≤ ‖p‖ + ‖UL.uniformVec K‖ := norm_sub_le _ _
          _ ≤ 1 + 1 := add_le_add (UL.Proof_lem_A_4.simplex_norm_le_one hp)
              (UL.Proof_lem_A_4.simplex_norm_le_one hu)
          _ = 2 := by norm_num
      calc δ * ‖p - UL.uniformVec K‖ ≤ δ * 2 := mul_le_mul_of_nonneg_left hpu hδ0.le
        _ < (r / 3) * 2 := mul_lt_mul_of_pos_right hδ_r (by norm_num)
        _ < r := by linarith
    have hterm1 : UL.extendSimplex Φ p - UL.extendSimplex Φ pδ ≤ ε / 3 := by
      have h1 := hr p hp pδ hpδ hdist_p
      rw [Real.dist_eq] at h1
      linarith [(abs_lt.mp h1).2]
    have hterm2 : δ * (UL.extendSimplex Φ (UL.uniformVec K) - UL.extendSimplex Φ p) ≤ ε / 3 := by
      calc δ * (UL.extendSimplex Φ (UL.uniformVec K) - UL.extendSimplex Φ p)
          ≤ δ * D := mul_le_mul_of_nonneg_left (hD (UL.uniformVec K) hu p hp) hδ0.le
        _ ≤ ((ε / 3) / (D + 1)) * D := mul_le_mul_of_nonneg_right hδ_D.le hD_nn
        _ = (ε / 3) * (D / (D + 1)) := by ring
        _ ≤ (ε / 3) * 1 := by
            refine mul_le_mul_of_nonneg_left ?_ (by linarith)
            rw [div_le_one (by positivity)]
            linarith
        _ = ε / 3 := mul_one _
    have hrewrite : (1 - δ) * UL.extendSimplex Φ p + δ * UL.extendSimplex Φ (UL.uniformVec K) -
        UL.extendSimplex Φ pδ =
        (UL.extendSimplex Φ p - UL.extendSimplex Φ pδ) +
          δ * (UL.extendSimplex Φ (UL.uniformVec K) - UL.extendSimplex Φ p) := by ring
    dsimp [pδ] at hrewrite hterm1
    linarith
  rw [Real.dist_eq, sub_zero, abs_of_nonneg hJ_nn]
  linarith

lemma jensenGap_affine_invariant {K : ℕ} (hK : 1 ≤ K) (Φ : UL.Simplex K → ℝ)
    (A : EuclideanSpace ℝ (Fin K) →ᵃ[ℝ] ℝ) {δ : ℝ} (hδ : δ ∈ Set.Ioo (0 : ℝ) 1) :
    let p_δ := fun q : EuclideanSpace ℝ (Fin K) => (1 - δ) • q + δ • UL.uniformVec K
    let jensenGap : (UL.Simplex K → ℝ) → ℝ := fun Ψ => sSup ((fun p =>
      (1 - δ) * UL.extendSimplex Ψ p + δ * UL.extendSimplex Ψ (UL.uniformVec K) -
        UL.extendSimplex Ψ (p_δ p)) '' UL.Simplex K)
    jensenGap (fun q => Φ q + A q.1) = jensenGap Φ := by
  intro p_δ jensenGap
  dsimp only [jensenGap]
  congr 1
  refine Set.image_congr (fun p hp => ?_)
  have hu : UL.uniformVec K ∈ UL.Simplex K := UL.Proof_lem_A_4.uniformVec_mem_simplex hK
  have hpδ : p_δ p ∈ UL.Simplex K :=
    UL.Proof_lem_A_4.simplex_convex K hp hu (by linarith [hδ.2]) hδ.1.le (by ring)
  rw [UL.Proof_lem_A_5.extendSimplex_eq_of_mem (fun q => Φ q + A q.1) hp,
    UL.Proof_lem_A_5.extendSimplex_eq_of_mem (fun q => Φ q + A q.1) hu,
    UL.Proof_lem_A_5.extendSimplex_eq_of_mem (fun q => Φ q + A q.1) hpδ,
    UL.Proof_lem_A_5.extendSimplex_eq_of_mem Φ hp,
    UL.Proof_lem_A_5.extendSimplex_eq_of_mem Φ hu,
    UL.Proof_lem_A_5.extendSimplex_eq_of_mem Φ hpδ]
  have hA_comb : A (p_δ p) = (1 - δ) * A p + δ * A (UL.uniformVec K) := by
    have hpδ_eq : p_δ p = AffineMap.lineMap p (UL.uniformVec K) δ := by
      simp [p_δ, AffineMap.lineMap_apply_module]
    rw [hpδ_eq, A.apply_lineMap, AffineMap.lineMap_apply_ring]
  dsimp only
  linarith

/-! ### Trimmed strongly-convex residual potential `F_δ` for Lemma A.5 -/

noncomputable def excessPotential {K : ℕ} (Φ : UL.Simplex K → ℝ) (β : ℝ) : UL.Simplex K → ℝ :=
  fun q => Φ q - (1 / (2 * β)) * ‖(q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K‖ ^ 2

noncomputable def trimmedExcessPotential {K : ℕ} (hK : 2 ≤ K)
    (Φ : UL.Simplex K → ℝ) (β δ : ℝ) (hδ : δ ∈ Set.Ioo (0 : ℝ) 1) : UL.Simplex K → ℝ :=
  fun q => (1 / (1 - δ)) * excessPotential Φ β
    ⟨(1 - δ) • q.1 + δ • UL.uniformVec K,
      (UL.Proof_lem_A_5.trimmed_mem_simplexFaceRelint_univ hK q.2 hδ.1 hδ.2).1.1⟩

lemma continuous_trimmedExcessPotential {K : ℕ} (hK : 2 ≤ K) {β : ℝ}
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.EntropyFamily K β) {δ : ℝ} (hδ : δ ∈ Set.Ioo (0 : ℝ) 1) :
    Continuous (trimmedExcessPotential hK Φ β δ hδ) := by
  have hF_cont : Continuous (excessPotential Φ β) :=
    hΦ.2.1.sub (continuous_const.mul (((continuous_subtype_val.sub continuous_const).norm).pow 2))
  unfold trimmedExcessPotential
  refine continuous_const.mul (hF_cont.comp ?_)
  exact Continuous.subtype_mk
    ((continuous_subtype_val.const_smul (1 - δ)).add continuous_const) _

lemma extendSimplex_trimmedExcessPotential {K : ℕ} (hK : 2 ≤ K)
    (Φ : UL.Simplex K → ℝ) (β δ : ℝ) (hδ : δ ∈ Set.Ioo (0 : ℝ) 1)
    {p : EuclideanSpace ℝ (Fin K)} (hp : p ∈ UL.Simplex K) :
    UL.extendSimplex (trimmedExcessPotential hK Φ β δ hδ) p =
      (1 / (1 - δ)) * UL.extendSimplex (excessPotential Φ β)
        ((1 - δ) • p + δ • UL.uniformVec K) := by
  have hpδ : (1 - δ) • p + δ • UL.uniformVec K ∈ UL.Simplex K :=
    (UL.Proof_lem_A_5.trimmed_mem_simplexFaceRelint_univ hK hp hδ.1 hδ.2).1.1
  rw [UL.Proof_lem_A_5.extendSimplex_eq_of_mem (trimmedExcessPotential hK Φ β δ hδ) hp,
    UL.Proof_lem_A_5.extendSimplex_eq_of_mem (excessPotential Φ β) hpδ]
  rfl

lemma convexOn_trimmedExcessPotential {K : ℕ} (hK : 2 ≤ K) {β : ℝ}
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.EntropyFamily K β) {δ : ℝ} (hδ : δ ∈ Set.Ioo (0 : ℝ) 1) :
    ConvexOn ℝ (UL.Simplex K) (UL.extendSimplex (trimmedExcessPotential hK Φ β δ hδ)) := by
  have hF_conv : ConvexOn ℝ (UL.Simplex K) (UL.extendSimplex (excessPotential Φ β)) := by
    refine hΦ.2.2.2.congr (fun q hq => ?_)
    dsimp only
    rw [UL.Proof_lem_A_5.extendSimplex_eq_of_mem (excessPotential Φ β) hq,
      UL.Proof_lem_A_5.extendSimplex_eq_of_mem Φ hq]
    rfl
  refine ⟨UL.Proof_lem_A_4.simplex_convex K, fun x hx y hy a b ha hb hab => ?_⟩
  dsimp only
  simp only [smul_eq_mul]
  have hxy : a • x + b • y ∈ UL.Simplex K :=
    UL.Proof_lem_A_4.simplex_convex K hx hy ha hb hab
  rw [extendSimplex_trimmedExcessPotential hK Φ β δ hδ hxy,
    extendSimplex_trimmedExcessPotential hK Φ β δ hδ hx,
    extendSimplex_trimmedExcessPotential hK Φ β δ hδ hy]
  have hlin : (1 - δ) • (a • x + b • y) + δ • UL.uniformVec K =
      a • ((1 - δ) • x + δ • UL.uniformVec K) +
        b • ((1 - δ) • y + δ • UL.uniformVec K) := by
    ext j
    simp only [PiLp.add_apply, PiLp.smul_apply, smul_eq_mul]
    calc (1 - δ) * (a * x j + b * y j) + δ * UL.uniformVec K j
        = (1 - δ) * (a * x j + b * y j) + (a + b) * (δ * UL.uniformVec K j) := by
            rw [hab, one_mul]
      _ = a * ((1 - δ) * x j + δ * UL.uniformVec K j) +
            b * ((1 - δ) * y j + δ * UL.uniformVec K j) := by ring
  rw [hlin]
  have hxδ : (1 - δ) • x + δ • UL.uniformVec K ∈ UL.Simplex K :=
    (UL.Proof_lem_A_5.trimmed_mem_simplexFaceRelint_univ hK hx hδ.1 hδ.2).1.1
  have hyδ : (1 - δ) • y + δ • UL.uniformVec K ∈ UL.Simplex K :=
    (UL.Proof_lem_A_5.trimmed_mem_simplexFaceRelint_univ hK hy hδ.1 hδ.2).1.1
  have hstep := hF_conv.2 hxδ hyδ ha hb hab
  have hc : 0 ≤ 1 / (1 - δ) := by
    have : 0 < 1 - δ := sub_pos.mpr hδ.2
    positivity
  calc (1 / (1 - δ)) * UL.extendSimplex (excessPotential Φ β)
          (a • ((1 - δ) • x + δ • UL.uniformVec K) + b • ((1 - δ) • y + δ • UL.uniformVec K))
      ≤ (1 / (1 - δ)) *
          (a * UL.extendSimplex (excessPotential Φ β) ((1 - δ) • x + δ • UL.uniformVec K) +
            b * UL.extendSimplex (excessPotential Φ β) ((1 - δ) • y + δ • UL.uniformVec K)) :=
        mul_le_mul_of_nonneg_left hstep hc
    _ = a * ((1 / (1 - δ)) * UL.extendSimplex (excessPotential Φ β) ((1 - δ) • x + δ • UL.uniformVec K)) +
        b * ((1 / (1 - δ)) * UL.extendSimplex (excessPotential Φ β) ((1 - δ) • y + δ • UL.uniformVec K)) := by
        ring

lemma hasFDerivAt_quad_term {K : ℕ} (β : ℝ) (q : EuclideanSpace ℝ (Fin K)) :
    HasFDerivAt (fun x : EuclideanSpace ℝ (Fin K) =>
      (1 / (2 * β)) * ‖x - UL.uniformVec K‖ ^ 2)
      (innerSL ℝ ((1 / β) • (q - UL.uniformVec K))) q := by
  rw [hasFDerivAt_iff_isLittleO_nhds_zero]
  refine Asymptotics.isLittleO_iff.mpr (fun c hc => ?_)
  have hpos : 0 < c / (|1 / (2 * β)| + 1) := div_pos hc (by positivity)
  filter_upwards [Metric.ball_mem_nhds (0 : EuclideanSpace ℝ (Fin K)) hpos] with h hh
  rw [Metric.mem_ball, dist_zero_right] at hh
  have hid : (1 / (2 * β)) * ‖(q + h) - UL.uniformVec K‖ ^ 2 -
      (1 / (2 * β)) * ‖q - UL.uniformVec K‖ ^ 2 -
      (innerSL ℝ ((1 / β) • (q - UL.uniformVec K))) h =
      (1 / (2 * β)) * ‖h‖ ^ 2 := by
    have hsub : (q + h) - UL.uniformVec K = (q - UL.uniformVec K) + h := by abel
    rw [hsub, norm_add_sq_real, innerSL_apply_apply, inner_smul_left]
    simp only [conj_trivial]
    ring
  rw [hid, Real.norm_eq_abs, abs_mul, abs_of_nonneg (sq_nonneg ‖h‖)]
  have h1 : |1 / (2 * β)| * ‖h‖ ≤ c := by
    calc |1 / (2 * β)| * ‖h‖
        ≤ |1 / (2 * β)| * (c / (|1 / (2 * β)| + 1)) :=
          mul_le_mul_of_nonneg_left hh.le (abs_nonneg _)
      _ = c * (|1 / (2 * β)| / (|1 / (2 * β)| + 1)) := by ring
      _ ≤ c * 1 := by
          refine mul_le_mul_of_nonneg_left ?_ hc.le
          rw [div_le_one (by positivity)]
          linarith
      _ = c := mul_one c
  calc |1 / (2 * β)| * ‖h‖ ^ 2
      = (|1 / (2 * β)| * ‖h‖) * ‖h‖ := by ring
    _ ≤ c * ‖h‖ := mul_le_mul_of_nonneg_right h1 (norm_nonneg h)

lemma sub_mem_faceTangentSpace {K : ℕ} {J : Finset (Fin K)}
    {p q : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ UL.SimplexFace K J) (hq : q ∈ UL.SimplexFace K J) :
    q - p ∈ UL.FaceTangentSpace K J := by
  rw [UL.Proof_lem_A_1.mem_faceTangentSpace_iff]
  refine ⟨UL.Proof_lem_A_4.sub_mem_zeroSumSubspace_of_mem_simplex hq.1 hp.1, fun j hj => ?_⟩
  simp [hq.2 j hj, hp.2 j hj]

lemma inner_orthProj_eq_of_mem {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    (S : Submodule ℝ E) [S.HasOrthogonalProjection] (g v : E) (hv : v ∈ S) :
    inner ℝ (S.orthogonalProjection g : E) v = inner ℝ g v := by
  have hzero : inner ℝ (g - (S.orthogonalProjection g : E)) v = 0 :=
    S.starProjection_inner_eq_zero g v hv
  rw [inner_sub_left] at hzero
  linarith

lemma hasFaceGradAt_trimmedExcessPotential {K : ℕ} (hK : 2 ≤ K) {β : ℝ}
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.EntropyFamily K β) {δ : ℝ} (hδ : δ ∈ Set.Ioo (0 : ℝ) 1)
    {J : Finset (Fin K)} (_hJ : J.Nonempty)
    {p : EuclideanSpace ℝ (Fin K)} (hp : p ∈ UL.SimplexFaceRelint K J) :
    let pδ := (1 - δ) • p + δ • UL.uniformVec K
    let g₀ := UL.simplexGrad Φ pδ - ((1 - δ) / β) • (p - UL.uniformVec K)
    UL.HasFaceGradAt (trimmedExcessPotential hK Φ β δ hδ) J p
      (((UL.FaceTangentSpace K J).orthogonalProjection g₀ : UL.FaceTangentSpace K J) :
        EuclideanSpace ℝ (Fin K)) := by
  intro pδ g₀
  obtain ⟨_, _, hΦ_diff, _⟩ := hΦ
  have hUniv_ne : (Finset.univ : Finset (Fin K)).Nonempty := by
    haveI : Nonempty (Fin K) := ⟨⟨0, by omega⟩⟩
    exact Finset.univ_nonempty
  have hp_simp : p ∈ UL.Simplex K := hp.1.1
  have hpδ_relint : pδ ∈ UL.SimplexFaceRelint K Finset.univ :=
    UL.Proof_lem_A_5.trimmed_mem_simplexFaceRelint_univ hK hp_simp hδ.1 hδ.2
  have hgΦ : UL.HasFaceGradAt Φ Finset.univ pδ (UL.simplexGrad Φ pδ) :=
    UL.Proof_lem_A_5.faceGrad_spec (hΦ_diff Finset.univ hUniv_ne pδ hpδ_relint)
  have hpδ_sub_u : (1 / β) • (pδ - UL.uniformVec K) = ((1 - δ) / β) • (p - UL.uniformVec K) := by
    ext j
    simp only [pδ, PiLp.sub_apply, PiLp.add_apply, PiLp.smul_apply, smul_eq_mul]
    ring
  have hfderiv_F_raw : HasFDerivWithinAt
      (fun x => UL.extendSimplex Φ x - (1 / (2 * β)) * ‖x - UL.uniformVec K‖ ^ 2)
      (innerSL ℝ g₀) (UL.Simplex K) pδ := by
    have h1 : HasFDerivWithinAt (UL.extendSimplex Φ)
        (innerSL ℝ (UL.simplexGrad Φ pδ)) (UL.Simplex K) pδ := by
      rw [← UL.Proof_lem_A_5.simplexFace_univ]
      exact hgΦ.2
    have h2 : HasFDerivWithinAt (fun x => (1 / (2 * β)) * ‖x - UL.uniformVec K‖ ^ 2)
        (innerSL ℝ (((1 - δ) / β) • (p - UL.uniformVec K))) (UL.Simplex K) pδ := by
      rw [← hpδ_sub_u]
      exact (hasFDerivAt_quad_term β pδ).hasFDerivWithinAt
    have hsub := h1.sub h2
    convert hsub using 1
    ext v
    simp [g₀, inner_sub_left]
  have hfderiv_F : HasFDerivWithinAt (UL.extendSimplex (excessPotential Φ β))
      (innerSL ℝ g₀) (UL.Simplex K) pδ := by
    refine hfderiv_F_raw.congr (fun x hx => ?_) ?_
    · dsimp only
      rw [UL.Proof_lem_A_5.extendSimplex_eq_of_mem (excessPotential Φ β) hx,
        UL.Proof_lem_A_5.extendSimplex_eq_of_mem Φ hx]
      rfl
    · dsimp only
      rw [UL.Proof_lem_A_5.extendSimplex_eq_of_mem (excessPotential Φ β) hpδ_relint.1.1,
        UL.Proof_lem_A_5.extendSimplex_eq_of_mem Φ hpδ_relint.1.1]
      rfl
  let τ : EuclideanSpace ℝ (Fin K) → EuclideanSpace ℝ (Fin K) :=
    fun q => (1 - δ) • q + δ • UL.uniformVec K
  have hτ_fderiv : HasFDerivWithinAt τ
      ((1 - δ) • ContinuousLinearMap.id ℝ (EuclideanSpace ℝ (Fin K)))
      (UL.SimplexFace K J) p := by
    have hd : HasFDerivAt τ
        ((1 - δ) • ContinuousLinearMap.id ℝ (EuclideanSpace ℝ (Fin K))) p := by
      simpa [τ] using ((hasFDerivAt_id p).const_smul (1 - δ)).add_const (δ • UL.uniformVec K)
    exact hd.hasFDerivWithinAt
  have hτ_maps : MapsTo τ (UL.SimplexFace K J) (UL.Simplex K) := fun q hq =>
    (UL.Proof_lem_A_5.trimmed_mem_simplexFaceRelint_univ hK hq.1 hδ.1 hδ.2).1.1
  have hcomp := (hfderiv_F.comp p hτ_fderiv hτ_maps).const_mul (1 / (1 - δ))
  have h1d_ne : 1 - δ ≠ 0 := (sub_pos.mpr hδ.2).ne'
  have hclm_eq : (1 / (1 - δ)) •
      ((innerSL ℝ g₀).comp ((1 - δ) • ContinuousLinearMap.id ℝ (EuclideanSpace ℝ (Fin K)))) =
      innerSL ℝ g₀ := by
    ext v
    simp only [ContinuousLinearMap.smul_apply, ContinuousLinearMap.comp_apply,
      ContinuousLinearMap.id_apply, innerSL_apply_apply, inner_smul_right, smul_eq_mul]
    field_simp [h1d_ne]
  rw [hclm_eq] at hcomp
  have hfderiv_Fδ_g₀ : HasFDerivWithinAt
      (UL.extendSimplex (trimmedExcessPotential hK Φ β δ hδ))
      (innerSL ℝ g₀) (UL.SimplexFace K J) p := by
    refine hcomp.congr (fun q hq => ?_) (extendSimplex_trimmedExcessPotential hK Φ β δ hδ hp_simp)
    exact extendSimplex_trimmedExcessPotential hK Φ β δ hδ hq.1
  set g_J : EuclideanSpace ℝ (Fin K) :=
    ((UL.FaceTangentSpace K J).orthogonalProjection g₀ : EuclideanSpace ℝ (Fin K))
  refine ⟨Submodule.coe_mem _, HasFDerivAtFilter.of_isLittleO ?_⟩
  refine hfderiv_Fδ_g₀.isLittleO.congr' ?_ (Eventually.of_forall fun _ => rfl)
  filter_upwards [self_mem_nhdsWithin] with q hq
  have hqp : q - p ∈ UL.FaceTangentSpace K J := sub_mem_faceTangentSpace hp.1 hq
  have hinn : inner ℝ g_J (q - p) = inner ℝ g₀ (q - p) :=
    inner_orthProj_eq_of_mem (UL.FaceTangentSpace K J) g₀ (q - p) hqp
  simp only [innerSL_apply_apply, hinn]

end UL.Proof_cor_A_8

import UL.Stmt.lem_C_3
import UL.Stmt.cit_mcdiarmid1989
import UL.Proof.lem_C_3.Race2.H4_SymmMcDiarmid
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_lem_C_3 (h_cit_mcdiarmid1989 : S_cit_mcdiarmid1989) : S_lem_C_3 := by
  unfold S_lem_C_3
  intro K hK
  refine ⟨Proof_lem_C_3_Race2.totalConst K, Proof_lem_C_3_Race2.totalConst_pos K, ?_⟩
  intro X _ _ _ _ _ _ L R C M₀ hL hR hC hM₀ n hn δ hδ0 hδ1 ν _ hX_bound Ω _ μ _ X_samp Y_samp
    hX_meas hY_meas hindep hident
  exact Proof_lem_C_3_Race2.main_bound_for_K h_cit_mcdiarmid1989 K hK X L R C M₀ hL hR hC hM₀
    n hn δ hδ0 hδ1 ν hX_bound Ω μ X_samp Y_samp hX_meas hY_meas hindep hident

end UL

import UL.Proof.cit_brouwer.H2_CubeBrouwer
set_option autoImplicit false

namespace UL.Proof_cit_brouwer

/-- Metric projection onto a nonempty compact convex subset of a real inner product space
    is continuous and satisfies the projection inequality. -/
theorem exists_metric_projection_on_compact_convex
    (E : Type*) [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    (C : Set E) (hCne : C.Nonempty) (hCcomp : IsCompact C) (hCconv : Convex ℝ C) :
    ∃ π : E → C, Continuous π ∧
      ∀ (u w : E), w ∈ C → inner ℝ (u - (π u : E)) (w - (π u : E)) ≤ 0 := by
  have hex : ∀ u : E, ∃ v ∈ C, ‖u - v‖ = ⨅ w : C, ‖u - w‖ :=
    exists_norm_eq_iInf_of_complete_convex hCne hCcomp.isComplete hCconv
  let π : E → C := fun u => ⟨Classical.choose (hex u), (Classical.choose_spec (hex u)).1⟩
  have hπ_norm : ∀ u : E, ‖u - (π u : E)‖ = ⨅ w : C, ‖u - w‖ :=
    fun u => (Classical.choose_spec (hex u)).2
  have hπ_inner : ∀ (u w : E), w ∈ C → inner ℝ (u - (π u : E)) (w - (π u : E)) ≤ 0 := by
    intro u w hw
    exact (norm_eq_iInf_iff_real_inner_le_zero hCconv (π u).2).mp (hπ_norm u) w hw
  have hπ_lip : ∀ u₁ u₂ : E, dist (π u₁) (π u₂) ≤ dist u₁ u₂ := by
    intro u₁ u₂
    rw [Subtype.dist_eq, dist_eq_norm, dist_eq_norm]
    let v₁ : E := (π u₁).1
    let v₂ : E := (π u₂).1
    change ‖v₁ - v₂‖ ≤ ‖u₁ - u₂‖
    have h₁ : inner ℝ (u₁ - v₁) (v₂ - v₁) ≤ 0 := hπ_inner u₁ v₂ (π u₂).2
    have h₂ : inner ℝ (u₂ - v₂) (v₁ - v₂) ≤ 0 := hπ_inner u₂ v₁ (π u₁).2
    have h₁' : 0 ≤ inner ℝ (u₁ - v₁) (v₁ - v₂) := by
      have hneg : v₁ - v₂ = -(v₂ - v₁) := by abel
      rw [hneg, inner_neg_right]
      linarith
    have hdiff : 0 ≤ inner ℝ ((u₁ - u₂) - (v₁ - v₂)) (v₁ - v₂) := by
      have heq : (u₁ - u₂) - (v₁ - v₂) = (u₁ - v₁) - (u₂ - v₂) := by abel
      rw [heq, inner_sub_left]
      linarith
    rw [inner_sub_left, real_inner_self_eq_norm_sq] at hdiff
    have hcs : inner ℝ (u₁ - u₂) (v₁ - v₂) ≤ ‖u₁ - u₂‖ * ‖v₁ - v₂‖ := real_inner_le_norm _ _
    have hsq : ‖v₁ - v₂‖ ^ 2 ≤ ‖u₁ - u₂‖ * ‖v₁ - v₂‖ := by linarith
    by_cases h0 : ‖v₁ - v₂‖ = 0
    · rw [h0]
      exact norm_nonneg _
    · have hpos : 0 < ‖v₁ - v₂‖ := lt_of_le_of_ne (norm_nonneg _) (Ne.symm h0)
      nlinarith
  have hπ_cont : Continuous π :=
    Metric.continuous_iff.mpr fun u ε hε => ⟨ε, hε, fun y hy => lt_of_le_of_lt (hπ_lip y u) hy⟩
  exact ⟨π, hπ_cont, hπ_inner⟩

/-- Metric projection onto a nonempty compact convex subset of a real inner product space
    is a continuous retraction. -/
theorem exists_continuous_retraction_of_compact_convex
    (E : Type*) [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    (C : Set E) (hCne : C.Nonempty) (hCcomp : IsCompact C) (hCconv : Convex ℝ C) :
    ∃ π : E → C, Continuous π ∧ ∀ x : C, π x = x := by
  obtain ⟨π, hπ_cont, hπ_inner⟩ :=
    exists_metric_projection_on_compact_convex E C hCne hCcomp hCconv
  have hπ_id : ∀ x : C, π x = x := by
    intro x
    apply Subtype.ext
    have h0 : inner ℝ ((x : E) - (π x : E)) ((x : E) - (π x : E)) ≤ 0 := hπ_inner x x x.2
    rw [real_inner_self_eq_norm_sq] at h0
    have hn : ‖(x : E) - (π x : E)‖ = 0 := by
      have hnn : 0 ≤ ‖(x : E) - (π x : E)‖ := norm_nonneg _
      nlinarith
    exact (sub_eq_zero.mp (norm_eq_zero.mp hn)).symm
  exact ⟨π, hπ_cont, hπ_id⟩

/-- General Brouwer fixed-point theorem deduced from `exists_fixedPoint_unitCube` and
    metric retraction. -/
theorem brouwer_of_compact_convex
    (E : Type*) [NormedAddCommGroup E] [InnerProductSpace ℝ E] [FiniteDimensional ℝ E]
    (C : Set E) (hCne : C.Nonempty) (hCcomp : IsCompact C) (hCconv : Convex ℝ C)
    (f : C → C) (hf : Continuous f) :
    ∃ x : C, f x = x := by
  obtain ⟨π, hπ_cont, hπ_id⟩ :=
    exists_continuous_retraction_of_compact_convex E C hCne hCcomp hCconv
  let n : ℕ := Module.finrank ℝ E
  let e : E ≃L[ℝ] (Fin n → ℝ) := (Module.finBasis ℝ E).equivFun.toContinuousLinearEquiv
  have hC_bdd : Bornology.IsBounded (e '' C) := (hCcomp.image e.continuous).isBounded
  obtain ⟨B, hB⟩ := isBounded_iff_forall_norm_le.mp hC_bdd
  let R : ℝ := max B 1
  have hR_pos : 0 < R := lt_of_lt_of_le zero_lt_one (le_max_right B 1)
  have hR_ne : (2 * R : ℝ) ≠ 0 := by positivity
  have hC_box : ∀ u ∈ C, ∀ i : Fin n, -R ≤ e u i ∧ e u i ≤ R := by
    intro u hu i
    have hnorm : ‖e u‖ ≤ R := le_trans (hB (e u) ⟨u, hu, rfl⟩) (le_max_left B 1)
    have hi : |e u i| ≤ R := le_trans (norm_le_pi_norm (e u) i) hnorm
    exact abs_le.mp hi
  let ψ : (Fin n → ℝ) → (Fin n → ℝ) := fun t i => (2 * t i - 1) * R
  let ψ_inv : (Fin n → ℝ) → (Fin n → ℝ) := fun y i => (y i + R) / (2 * R)
  have hψ_cont : Continuous ψ := by
    refine continuous_pi fun i => ?_
    fun_prop
  have hψ_inv_cont : Continuous ψ_inv := by
    refine continuous_pi fun i => ?_
    fun_prop
  let F : E → E := fun u => (f (π u) : E)
  have hF_cont : Continuous F := continuous_subtype_val.comp (hf.comp hπ_cont)
  let g : (Fin n → ℝ) → (Fin n → ℝ) := fun t => ψ_inv (e (F (e.symm (ψ t))))
  have hg_cont : Continuous g :=
    hψ_inv_cont.comp (e.continuous.comp (hF_cont.comp (e.symm.continuous.comp hψ_cont)))
  have hg_mem : ∀ (t : Fin n → ℝ) (i : Fin n), 0 ≤ g t i ∧ g t i ≤ 1 := by
    intro t i
    have hFu : F (e.symm (ψ t)) ∈ C := (f (π (e.symm (ψ t)))).2
    obtain ⟨hlo, hhi⟩ := hC_box _ hFu i
    dsimp [g, ψ_inv]
    constructor
    · exact div_nonneg (by linarith) (by positivity)
    · rw [div_le_one (by positivity)]
      linarith
  obtain ⟨t₀, _, ht₀⟩ := exists_fixedPoint_unitCube n g hg_cont hg_mem
  let u₀ : E := e.symm (ψ t₀)
  have hψ_left : ψ (ψ_inv (e (F u₀))) = e (F u₀) := by
    ext i
    dsimp [ψ, ψ_inv]
    field_simp [hR_ne]
    ring
  have he_eq : e (F u₀) = ψ t₀ := by
    calc
      e (F u₀) = ψ (ψ_inv (e (F u₀))) := hψ_left.symm
      _ = ψ (g t₀) := rfl
      _ = ψ t₀ := by rw [ht₀]
  have hFu₀ : F u₀ = u₀ := by
    calc
      F u₀ = e.symm (e (F u₀)) := (e.symm_apply_apply _).symm
      _ = e.symm (ψ t₀) := by rw [he_eq]
      _ = u₀ := rfl
  have hu₀_mem : u₀ ∈ C := by
    rw [← hFu₀]
    exact (f (π u₀)).2
  refine ⟨⟨u₀, hu₀_mem⟩, ?_⟩
  apply Subtype.ext
  have hπ_u₀ : π u₀ = ⟨u₀, hu₀_mem⟩ := hπ_id ⟨u₀, hu₀_mem⟩
  calc
    (f ⟨u₀, hu₀_mem⟩ : E) = (f (π u₀) : E) := by rw [hπ_u₀]
    _ = F u₀ := rfl
    _ = u₀ := hFu₀

end UL.Proof_cit_brouwer

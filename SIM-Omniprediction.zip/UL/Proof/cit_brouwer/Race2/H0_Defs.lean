import Mathlib
set_option autoImplicit false

namespace UL.Proof_cit_brouwer_Race2

/-- Grid vertices `{0, ..., M + 1}^n` of the subdivided `n`-cube with `M + 1` steps per axis. -/
abbrev Vert (n M : ℕ) : Type := Fin n → Fin (M + 2)

/-- Kuhn `n`-simplices in `{0, ..., M + 1}^n`: a base cell `z ∈ {0, ..., M}^n` and a permutation
`σ ∈ Perm (Fin n)` specifying the order in which coordinates are incremented. -/
abbrev Simplex (n M : ℕ) : Type := (Fin n → Fin (M + 1)) × Equiv.Perm (Fin n)

/-- The `k`-th vertex (`k : Fin (n + 1)`) of a Kuhn `n`-simplex `s = (z, σ)`. -/
def vertex {n M : ℕ} (s : Simplex n M) (k : Fin (n + 1)) (i : Fin n) : Fin (M + 2) :=
  if (s.2.symm i).val < k.val then (s.1 i).succ else (s.1 i).castSucc

/-- A Kuhn `n`-simplex `s` is panchromatic under `c` if its `n + 1` vertices realize all `n + 1`
colors. -/
def IsPanchromatic {n M : ℕ} (c : Vert n M → Fin (n + 1)) (s : Simplex n M) : Prop :=
  Function.Surjective (fun k : Fin (n + 1) => c (vertex s k))

/-- The unit `n`-cube `[0, 1]^n ⊆ (Fin n → ℝ)`. -/
def Cube (n : ℕ) : Set (Fin n → ℝ) :=
  { x | ∀ i : Fin n, x i ∈ Set.Icc (0 : ℝ) 1 }

end UL.Proof_cit_brouwer_Race2

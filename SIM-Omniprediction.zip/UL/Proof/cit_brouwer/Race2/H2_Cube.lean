import UL.Proof.cit_brouwer.Race2.H0_Defs
set_option autoImplicit false

namespace UL.Proof_cit_brouwer_Race2

section CubeHelpers

open Classical

private noncomputable def toPoint {n : ℕ} (M : ℕ) (v : Vert n M) : Cube n :=
  ⟨fun i => ((v i).val : ℝ) / ((M : ℝ) + 1), by
    intro i
    have hpos : (0 : ℝ) < (M : ℝ) + 1 := by positivity
    have hle_nat : (v i).val ≤ M + 1 := by
      have hlt : (v i).val < M + 2 := (v i).isLt
      omega
    have hle_real : ((v i).val : ℝ) ≤ (M : ℝ) + 1 := by
      have h1 : ((v i).val : ℝ) ≤ ((M + 1 : ℕ) : ℝ) := Nat.cast_le.mpr hle_nat
      push_cast at h1
      exact h1
    exact ⟨by positivity, (div_le_one hpos).mpr hle_real⟩⟩

private def good {n : ℕ} (M : ℕ) (f : Cube n → Cube n) (v : Vert n M) (i : Fin n) : Prop :=
  0 < (v i).val ∧ (f (toPoint M v)).1 i ≤ (toPoint M v).1 i

private noncomputable def goodSet {n : ℕ} (M : ℕ) (f : Cube n → Cube n) (v : Vert n M) :
    Finset (Fin n) :=
  Finset.univ.filter (good M f v)

private noncomputable def color {n : ℕ} (M : ℕ) (f : Cube n → Cube n) (v : Vert n M) :
    Fin (n + 1) :=
  if h : (goodSet M f v).Nonempty then ((goodSet M f v).min' h).castSucc else Fin.last n

private lemma mem_goodSet_iff {n : ℕ} (M : ℕ) (f : Cube n → Cube n) (v : Vert n M) (i : Fin n) :
    i ∈ goodSet M f v ↔ good M f v i := by
  simp [goodSet]

private lemma color_low {n : ℕ} (M : ℕ) (f : Cube n → Cube n)
    (v : Vert n M) (i : Fin n) (hv : v i = 0) :
    color M f v ≠ i.castSucc := by
  intro hc
  unfold color at hc
  split_ifs at hc with hne
  · have hmin_eq : (goodSet M f v).min' hne = i := by
      apply Fin.ext
      simpa using congrArg Fin.val hc
    have hmem : i ∈ goodSet M f v := hmin_eq ▸ (goodSet M f v).min'_mem hne
    have hgood : good M f v i := (mem_goodSet_iff M f v i).mp hmem
    have hval0 : (v i).val = 0 := by simp [hv]
    exact absurd hgood.1 (by omega)
  · have hval : n = i.val := by simpa using congrArg Fin.val hc
    exact absurd i.isLt (by omega)

private lemma color_high {n : ℕ} (M : ℕ) (f : Cube n → Cube n)
    (v : Vert n M) (i : Fin n) (hv : v i = Fin.last (M + 1)) :
    (color M f v).val ≤ i.val := by
  have hval : (v i).val = M + 1 := by simp [hv]
  have hpos : 0 < (v i).val := by omega
  have hpt : (toPoint M v).1 i = 1 := by
    change ((v i).val : ℝ) / ((M : ℝ) + 1) = 1
    rw [hval]
    push_cast
    have hd : ((M : ℝ) + 1) ≠ 0 := by positivity
    exact div_self hd
  have hfle : (f (toPoint M v)).1 i ≤ (toPoint M v).1 i := by
    rw [hpt]
    exact ((f (toPoint M v)).2 i).2
  have hi : i ∈ goodSet M f v := (mem_goodSet_iff M f v i).mpr ⟨hpos, hfle⟩
  have hne : (goodSet M f v).Nonempty := ⟨i, hi⟩
  have hc : color M f v = ((goodSet M f v).min' hne).castSucc := by
    unfold color
    exact dif_pos hne
  rw [hc, Fin.val_castSucc]
  exact (goodSet M f v).min'_le i hi

private lemma le_of_color_eq_last {n : ℕ} (M : ℕ) (f : Cube n → Cube n)
    (v : Vert n M) (hc : color M f v = Fin.last n) (i : Fin n) :
    (toPoint M v).1 i ≤ (f (toPoint M v)).1 i := by
  have hnotgood : ¬ good M f v i := by
    intro hgood
    have hi : i ∈ goodSet M f v := (mem_goodSet_iff M f v i).mpr hgood
    have hne : (goodSet M f v).Nonempty := ⟨i, hi⟩
    have hc' : color M f v = ((goodSet M f v).min' hne).castSucc := by
      unfold color
      exact dif_pos hne
    have hval : ((goodSet M f v).min' hne).val = n := by
      simpa [hc'] using congrArg Fin.val hc
    exact absurd ((goodSet M f v).min' hne).isLt (by omega)
  rcases Nat.eq_zero_or_pos (v i).val with hv0 | hvpos
  · have hpt0 : (toPoint M v).1 i = 0 := by
      change ((v i).val : ℝ) / ((M : ℝ) + 1) = 0
      simp [hv0]
    rw [hpt0]
    exact ((f (toPoint M v)).2 i).1
  · unfold good at hnotgood
    push_neg at hnotgood
    exact (hnotgood hvpos).le

private lemma le_of_color_eq_castSucc {n : ℕ} (M : ℕ) (f : Cube n → Cube n)
    (v : Vert n M) (i : Fin n) (hc : color M f v = i.castSucc) :
    (f (toPoint M v)).1 i ≤ (toPoint M v).1 i := by
  unfold color at hc
  split_ifs at hc with hne
  · have hmin_eq : (goodSet M f v).min' hne = i := by
      apply Fin.ext
      simpa using congrArg Fin.val hc
    have hmem : i ∈ goodSet M f v := hmin_eq ▸ (goodSet M f v).min'_mem hne
    exact ((mem_goodSet_iff M f v i).mp hmem).2
  · have hval : n = i.val := by simpa using congrArg Fin.val hc
    exact False.elim (absurd i.isLt (by omega))

private lemma vertex_val_bounds {n M : ℕ} (s : Simplex n M) (k : Fin (n + 1)) (j : Fin n) :
    (s.1 j).val ≤ (vertex s k j).val ∧ (vertex s k j).val ≤ (s.1 j).val + 1 := by
  unfold vertex
  split_ifs <;> simp

private lemma toPoint_vertex_bounds {n M : ℕ} (s : Simplex n M) (k₁ k₂ : Fin (n + 1)) (j : Fin n) :
    (toPoint M (vertex s k₁)).1 j - 1 / ((M : ℝ) + 1) ≤ (toPoint M (vertex s k₂)).1 j ∧
    (toPoint M (vertex s k₂)).1 j ≤ (toPoint M (vertex s k₁)).1 j + 1 / ((M : ℝ) + 1) := by
  have h1 := vertex_val_bounds s k₁ j
  have h2 := vertex_val_bounds s k₂ j
  have h1r : ((s.1 j).val : ℝ) ≤ ((vertex s k₁ j).val : ℝ) ∧
      ((vertex s k₁ j).val : ℝ) ≤ ((s.1 j).val : ℝ) + 1 := by
    constructor
    · exact_mod_cast h1.1
    · have hle : ((vertex s k₁ j).val : ℝ) ≤ (((s.1 j).val + 1 : ℕ) : ℝ) := Nat.cast_le.mpr h1.2
      push_cast at hle
      exact hle
  have h2r : ((s.1 j).val : ℝ) ≤ ((vertex s k₂ j).val : ℝ) ∧
      ((vertex s k₂ j).val : ℝ) ≤ ((s.1 j).val : ℝ) + 1 := by
    constructor
    · exact_mod_cast h2.1
    · have hle : ((vertex s k₂ j).val : ℝ) ≤ (((s.1 j).val + 1 : ℕ) : ℝ) := Nat.cast_le.mpr h2.2
      push_cast at hle
      exact hle
  have hpos : (0 : ℝ) < (M : ℝ) + 1 := by positivity
  change ((vertex s k₁ j).val : ℝ) / ((M : ℝ) + 1) - 1 / ((M : ℝ) + 1) ≤
      ((vertex s k₂ j).val : ℝ) / ((M : ℝ) + 1) ∧
    ((vertex s k₂ j).val : ℝ) / ((M : ℝ) + 1) ≤
      ((vertex s k₁ j).val : ℝ) / ((M : ℝ) + 1) + 1 / ((M : ℝ) + 1)
  constructor
  · rw [← sub_div, div_le_iff₀ hpos, div_mul_cancel₀ _ hpos.ne']
    linarith
  · rw [← add_div, le_div_iff₀ hpos, div_mul_cancel₀ _ hpos.ne']
    linarith

end CubeHelpers

theorem brouwer_cube_of_sperner
    (h_sperner : ∀ {n : ℕ} (M : ℕ) (c : Vert n M → Fin (n + 1)),
      (∀ (v : Vert n M) (i : Fin n), v i = 0 → c v ≠ i.castSucc) →
      (∀ (v : Vert n M) (i : Fin n), v i = Fin.last (M + 1) → (c v).val ≤ i.val) →
      ∃ s : Simplex n M, IsPanchromatic c s)
    (n : ℕ) (f : Cube n → Cube n) (hf : Continuous f) :
    ∃ x : Cube n, f x = x := by
  have hs_ex : ∀ M : ℕ, ∃ s : Simplex n M, IsPanchromatic (color M f) s :=
    fun M => h_sperner M (color M f) (color_low M f) (color_high M f)
  choose s hs using hs_ex
  choose kLast hkLast using fun M => hs M (Fin.last n)
  choose kIdx hkIdx using fun M (i : Fin n) => hs M i.castSucc
  let xSeq : ℕ → Cube n := fun M => toPoint M (vertex (s M) (kLast M))
  let ySeq : ℕ → Fin n → Cube n := fun M i => toPoint M (vertex (s M) (kIdx M i))
  have hxSeq : ∀ (M : ℕ) (i : Fin n), (xSeq M).1 i ≤ (f (xSeq M)).1 i :=
    fun M i => le_of_color_eq_last M f (vertex (s M) (kLast M)) (hkLast M) i
  have hySeq : ∀ (M : ℕ) (i : Fin n), (f (ySeq M i)).1 i ≤ (ySeq M i).1 i :=
    fun M i => le_of_color_eq_castSucc M f (vertex (s M) (kIdx M i)) i (hkIdx M i)
  have hCube_eq : Cube n = Set.pi Set.univ (fun _ : Fin n => Set.Icc (0 : ℝ) 1) := by
    ext x
    exact ⟨fun hx i _ => hx i, fun hx i => hx i (Set.mem_univ i)⟩
  have hCube_compact : IsCompact (Cube n) := by
    rw [hCube_eq]
    exact isCompact_univ_pi (fun _ => isCompact_Icc)
  obtain ⟨xStar, hxStar, φ, hφ_mono, hφ_lim⟩ :=
    hCube_compact.tendsto_subseq (x := fun M => (xSeq M).1) (fun M => (xSeq M).2)
  let xLim : Cube n := ⟨xStar, hxStar⟩
  have hx_tendsto : Filter.Tendsto (fun m => xSeq (φ m)) Filter.atTop (nhds xLim) :=
    tendsto_subtype_rng.mpr hφ_lim
  have hinv_tendsto : Filter.Tendsto (fun m : ℕ => 1 / ((φ m : ℝ) + 1)) Filter.atTop (nhds 0) :=
    tendsto_one_div_add_atTop_nhds_zero_nat.comp hφ_mono.tendsto_atTop
  have hy_tendsto : ∀ i : Fin n,
      Filter.Tendsto (fun m => ySeq (φ m) i) Filter.atTop (nhds xLim) := by
    intro i
    apply tendsto_subtype_rng.mpr
    apply tendsto_pi_nhds.mpr
    intro j
    have hx_j : Filter.Tendsto (fun m => (xSeq (φ m)).1 j) Filter.atTop (nhds (xStar j)) :=
      tendsto_pi_nhds.mp hφ_lim j
    have hlow_lim : Filter.Tendsto (fun m => (xSeq (φ m)).1 j - 1 / ((φ m : ℝ) + 1))
        Filter.atTop (nhds (xStar j)) := by
      simpa using hx_j.sub hinv_tendsto
    have hhigh_lim : Filter.Tendsto (fun m => (xSeq (φ m)).1 j + 1 / ((φ m : ℝ) + 1))
        Filter.atTop (nhds (xStar j)) := by
      simpa using hx_j.add hinv_tendsto
    exact tendsto_of_tendsto_of_tendsto_of_le_of_le hlow_lim hhigh_lim
      (fun m => (toPoint_vertex_bounds (s (φ m)) (kLast (φ m)) (kIdx (φ m) i) j).1)
      (fun m => (toPoint_vertex_bounds (s (φ m)) (kLast (φ m)) (kIdx (φ m) i) j).2)
  refine ⟨xLim, ?_⟩
  apply Subtype.ext
  funext i
  have hcoord_cont : Continuous (fun z : Cube n => z.1 i) :=
    (continuous_apply i).comp continuous_subtype_val
  have hfx_tendsto : Filter.Tendsto (fun m => (f (xSeq (φ m))).1 i)
      Filter.atTop (nhds ((f xLim).1 i)) :=
    ((hcoord_cont.comp hf).continuousAt (x := xLim)).tendsto.comp hx_tendsto
  have hx_coord_tendsto : Filter.Tendsto (fun m => (xSeq (φ m)).1 i)
      Filter.atTop (nhds (xLim.1 i)) :=
    (hcoord_cont.continuousAt (x := xLim)).tendsto.comp hx_tendsto
  have h1 : xLim.1 i ≤ (f xLim).1 i :=
    le_of_tendsto_of_tendsto' hx_coord_tendsto hfx_tendsto (fun m => hxSeq (φ m) i)
  have hfy_tendsto : Filter.Tendsto (fun m => (f (ySeq (φ m) i)).1 i)
      Filter.atTop (nhds ((f xLim).1 i)) :=
    ((hcoord_cont.comp hf).continuousAt (x := xLim)).tendsto.comp (hy_tendsto i)
  have hy_coord_tendsto : Filter.Tendsto (fun m => (ySeq (φ m) i).1 i)
      Filter.atTop (nhds (xLim.1 i)) :=
    (hcoord_cont.continuousAt (x := xLim)).tendsto.comp (hy_tendsto i)
  have h2 : (f xLim).1 i ≤ xLim.1 i :=
    le_of_tendsto_of_tendsto' hfy_tendsto hy_coord_tendsto (fun m => hySeq (φ m) i)
  exact le_antisymm h2 h1

end UL.Proof_cit_brouwer_Race2

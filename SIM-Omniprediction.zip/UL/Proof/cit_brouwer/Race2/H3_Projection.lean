import UL.Proof.cit_brouwer.Race2.H0_Defs
set_option autoImplicit false

namespace UL.Proof_cit_brouwer_Race2

theorem brouwer_of_cube
    (h_cube : ∀ (n : ℕ) (f : Cube n → Cube n), Continuous f → ∃ x : Cube n, f x = x)
    (E : Type*) [NormedAddCommGroup E] [InnerProductSpace ℝ E] [FiniteDimensional ℝ E]
    (C : Set E) (hC_ne : C.Nonempty) (hC_comp : IsCompact C) (hC_conv : Convex ℝ C)
    (f : C → C) (hf : Continuous f) :
    ∃ x : C, f x = x := by
  have h_ex : ∀ u : E, ∃ v ∈ C, ‖u - v‖ = ⨅ w : C, ‖u - w‖ :=
    exists_norm_eq_iInf_of_complete_convex hC_ne hC_comp.isComplete hC_conv
  let projC : E → C := fun u => ⟨(h_ex u).choose, (h_ex u).choose_spec.1⟩
  have h_proj_min : ∀ u : E, ‖u - (projC u).1‖ = ⨅ w : C, ‖u - w.1‖ :=
    fun u => (h_ex u).choose_spec.2
  haveI : Nonempty C := hC_ne.to_subtype
  have projC_coe : ∀ x : C, projC x.1 = x := by
    intro x
    apply Subtype.ext
    have h1 : ‖x.1 - (projC x.1).1‖ ≤ ‖x.1 - x.1‖ := by
      rw [h_proj_min x.1]
      exact ciInf_le ⟨0, Set.forall_mem_range.2 fun _ => norm_nonneg _⟩ x
    rw [sub_self, norm_zero] at h1
    have h0 : ‖x.1 - (projC x.1).1‖ = 0 := le_antisymm h1 (norm_nonneg _)
    exact (sub_eq_zero.mp (norm_eq_zero.mp h0)).symm
  have h_nonexp : ∀ u₁ u₂ : E, ‖(projC u₁).1 - (projC u₂).1‖ ≤ ‖u₁ - u₂‖ := by
    intro u₁ u₂
    set v₁ : E := (projC u₁).1
    set v₂ : E := (projC u₂).1
    have h₁ : inner ℝ (u₁ - v₁) (v₂ - v₁) ≤ 0 :=
      (norm_eq_iInf_iff_real_inner_le_zero hC_conv (projC u₁).2).mp (h_proj_min u₁) v₂ (projC u₂).2
    have h₂ : inner ℝ (u₂ - v₂) (v₁ - v₂) ≤ 0 :=
      (norm_eq_iInf_iff_real_inner_le_zero hC_conv (projC u₂).2).mp (h_proj_min u₂) v₁ (projC u₁).2
    rw [← neg_sub v₁ v₂, inner_neg_right] at h₁
    have h_id : v₁ - v₂ = (u₁ - u₂) - (u₁ - v₁) + (u₂ - v₂) := by abel
    have h_inner_eq :
        inner ℝ (v₁ - v₂) (v₁ - v₂) =
          inner ℝ (u₁ - u₂) (v₁ - v₂) - inner ℝ (u₁ - v₁) (v₁ - v₂) +
            inner ℝ (u₂ - v₂) (v₁ - v₂) := by
      calc
        inner ℝ (v₁ - v₂) (v₁ - v₂) =
            inner ℝ ((u₁ - u₂) - (u₁ - v₁) + (u₂ - v₂)) (v₁ - v₂) :=
          congrArg (fun z => inner ℝ z (v₁ - v₂)) h_id
        _ = inner ℝ (u₁ - u₂) (v₁ - v₂) - inner ℝ (u₁ - v₁) (v₁ - v₂) +
              inner ℝ (u₂ - v₂) (v₁ - v₂) := by
          rw [inner_add_left, inner_sub_left]
    have h_sq : ‖v₁ - v₂‖ ^ 2 ≤ ‖u₁ - u₂‖ * ‖v₁ - v₂‖ := by
      have h_self : inner ℝ (v₁ - v₂) (v₁ - v₂) = ‖v₁ - v₂‖ ^ 2 :=
        real_inner_self_eq_norm_sq (v₁ - v₂)
      have h_cs : inner ℝ (u₁ - u₂) (v₁ - v₂) ≤ ‖u₁ - u₂‖ * ‖v₁ - v₂‖ :=
        real_inner_le_norm (u₁ - u₂) (v₁ - v₂)
      linarith
    by_contra! hlt
    have hpos : 0 < ‖v₁ - v₂‖ := lt_of_le_of_lt (norm_nonneg _) hlt
    have hmul : ‖u₁ - u₂‖ * ‖v₁ - v₂‖ < ‖v₁ - v₂‖ ^ 2 := by
      simpa only [sq] using mul_lt_mul_of_pos_right hlt hpos
    linarith
  have h_proj_lip : LipschitzWith 1 projC := by
    refine LipschitzWith.of_dist_le_mul fun u₁ u₂ => ?_
    simpa only [NNReal.coe_one, one_mul, Subtype.dist_eq, dist_eq_norm] using h_nonexp u₁ u₂
  have h_proj_cont : Continuous projC := h_proj_lip.continuous
  let F : E → E := fun u => (f (projC u)).1
  have hF_cont : Continuous F := continuous_subtype_val.comp (hf.comp h_proj_cont)
  have hF_mem : ∀ u : E, F u ∈ C := fun u => (f (projC u)).2
  let n : ℕ := Module.finrank ℝ E
  let e : E ≃L[ℝ] (Fin n → ℝ) := (Module.finBasis ℝ E).equivFun.toContinuousLinearEquiv
  obtain ⟨R, hR_pos, hR_bound⟩ : ∃ R > 0, ∀ y ∈ e '' C, ‖y‖ ≤ R :=
    (hC_comp.image e.continuous).isBounded.exists_pos_norm_le
  have hC_coord : ∀ u ∈ C, ∀ i : Fin n, -R ≤ e u i ∧ e u i ≤ R := by
    intro u hu i
    rw [← abs_le, ← Real.norm_eq_abs]
    exact (norm_le_pi_norm (e u) i).trans (hR_bound (e u) ⟨u, hu, rfl⟩)
  let G : (Fin n → ℝ) → (Fin n → ℝ) := fun y => e (F (e.symm y))
  have hG_cont : Continuous G := e.continuous.comp (hF_cont.comp e.symm.continuous)
  have hG_coord : ∀ (y : Fin n → ℝ) (i : Fin n), -R ≤ G y i ∧ G y i ≤ R :=
    fun y i => hC_coord (F (e.symm y)) (hF_mem (e.symm y)) i
  let fromCube : Cube n → (Fin n → ℝ) := fun x i => (2 * R) * x.1 i - R
  have h_fromCube_cont : Continuous fromCube := by
    refine continuous_pi fun i => ?_
    exact (continuous_const.mul ((continuous_apply i).comp continuous_subtype_val)).sub
      continuous_const
  let g : Cube n → Cube n := fun x =>
    ⟨fun i => (G (fromCube x) i + R) / (2 * R), fun i => by
      have ⟨h1, h2⟩ := hG_coord (fromCube x) i
      refine ⟨div_nonneg (by linarith) (by linarith), ?_⟩
      rw [div_le_one (by linarith : (0 : ℝ) < 2 * R)]
      linarith⟩
  have hg_cont : Continuous g := by
    refine Continuous.subtype_mk (continuous_pi fun i => ?_) _
    exact (((continuous_apply i).comp (hG_cont.comp h_fromCube_cont)).add
      continuous_const).div_const (2 * R)
  obtain ⟨x, hx⟩ := h_cube n g hg_cont
  have hG_fix : G (fromCube x) = fromCube x := by
    ext i
    have hxi : (G (fromCube x) i + R) / (2 * R) = x.1 i :=
      congr_fun (congr_arg Subtype.val hx) i
    have h2R : (2 * R : ℝ) ≠ 0 := by linarith
    have hmul : G (fromCube x) i + R = x.1 i * (2 * R) :=
      (div_eq_iff h2R).mp hxi
    exact eq_sub_iff_add_eq.mpr (hmul.trans (mul_comm _ _))
  let u : E := e.symm (fromCube x)
  have hu : F u = u := by
    apply e.injective
    calc
      e (F u) = G (fromCube x) := rfl
      _ = fromCube x := hG_fix
      _ = e u := (e.apply_symm_apply (fromCube x)).symm
  refine ⟨projC u, ?_⟩
  calc
    f (projC u) = projC (f (projC u)).1 := (projC_coe (f (projC u))).symm
    _ = projC (F u) := rfl
    _ = projC u := by rw [hu]

end UL.Proof_cit_brouwer_Race2

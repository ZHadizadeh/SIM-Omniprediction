import UL.Proof.cit_brouwer.Race2.H0_Defs
set_option autoImplicit false

namespace UL.Proof_cit_brouwer_Race2

open Classical

/-! ### Step 1: Fixed-point-free involution implies even cardinality -/

private lemma even_card_of_involutive_ne {α : Type*} [DecidableEq α] (S : Finset α)
    (f : α → α) (h_mem : ∀ x ∈ S, f x ∈ S) (h_inv : ∀ x ∈ S, f (f x) = x)
    (h_ne : ∀ x ∈ S, f x ≠ x) : Even S.card := by
  suffices ∀ m : ℕ, ∀ T : Finset α, T.card = m →
      (∀ x ∈ T, f x ∈ T) → (∀ x ∈ T, f (f x) = x) → (∀ x ∈ T, f x ≠ x) → Even T.card from
    this S.card S rfl h_mem h_inv h_ne
  intro m
  induction m using Nat.strongRecOn with
  | ind m ih =>
    intro T hcard hT_mem hT_inv hT_ne
    rcases T.eq_empty_or_nonempty with rfl | ⟨a, ha⟩
    · simp
    · set b := f a
      have hb : b ∈ T := hT_mem a ha
      have hab : b ≠ a := hT_ne a ha
      have hb_er : b ∈ T.erase a := Finset.mem_erase.mpr ⟨hab, hb⟩
      set T' := (T.erase a).erase b
      have hcard' : T'.card + 2 = T.card := by
        have h1 : (T.erase a).card + 1 = T.card := Finset.card_erase_add_one ha
        have h2 : T'.card + 1 = (T.erase a).card := Finset.card_erase_add_one hb_er
        omega
      have hT'_mem : ∀ x ∈ T', f x ∈ T' := by
        intro x hx
        have hx1 : x ≠ b ∧ x ∈ T.erase a := Finset.mem_erase.mp hx
        have hx2 : x ≠ a ∧ x ∈ T := Finset.mem_erase.mp hx1.2
        refine Finset.mem_erase.mpr ⟨?_, Finset.mem_erase.mpr ⟨?_, hT_mem x hx2.2⟩⟩
        · intro hfx
          apply hx2.1
          rw [← hT_inv x hx2.2, hfx, hT_inv a ha]
        · intro hfx
          apply hx1.1
          rw [← hT_inv x hx2.2, hfx]
      have hT'_even : Even T'.card :=
        ih T'.card (by omega) T' rfl hT'_mem
          (fun x hx => hT_inv x (Finset.mem_of_mem_erase (Finset.mem_of_mem_erase hx)))
          (fun x hx => hT_ne x (Finset.mem_of_mem_erase (Finset.mem_of_mem_erase hx)))
      rw [← hcard']
      exact hT'_even.add ⟨1, rfl⟩

/-! ### Step 2: Facets, doors, and per-simplex door parity -/

private def facetVerts {n M : ℕ} (s : Simplex (n + 1) M) (k : Fin (n + 2))
    (m : Fin (n + 1)) : Vert (n + 1) M :=
  vertex s (k.succAbove m)

private def IsDoor {n M : ℕ} (c : Vert (n + 1) M → Fin (n + 2))
    (s : Simplex (n + 1) M) (k : Fin (n + 2)) : Prop :=
  Finset.univ.image (fun m : Fin (n + 1) => c (facetVerts s k m)) =
    Finset.univ.erase (Fin.last (n + 1))

private lemma image_succAbove_eq_erase {d : ℕ} (k : Fin (d + 1)) :
    Finset.univ.image k.succAbove = Finset.univ.erase k := by
  ext r
  simp only [Finset.mem_image, Finset.mem_univ, true_and, Finset.mem_erase, and_true]
  constructor
  · rintro ⟨m, rfl⟩
    exact Fin.succAbove_ne k m
  · intro hr
    exact Fin.exists_succAbove_eq hr

private lemma isDoor_iff_erase_image {n M : ℕ} (c : Vert (n + 1) M → Fin (n + 2))
    (s : Simplex (n + 1) M) (k : Fin (n + 2)) :
    IsDoor c s k ↔
      (Finset.univ.erase k).image (fun r => c (vertex s r)) =
        Finset.univ.erase (Fin.last (n + 1)) := by
  unfold IsDoor facetVerts
  rw [← image_succAbove_eq_erase k, Finset.image_image]
  rfl

private lemma odd_card_doors_iff_surjective {n : ℕ} (g : Fin (n + 2) → Fin (n + 2)) :
    Odd (Finset.univ.filter (fun k : Fin (n + 2) =>
      (Finset.univ.erase k).image g = Finset.univ.erase (Fin.last (n + 1)))).card ↔
      Function.Surjective g := by
  set T : Finset (Fin (n + 2)) := Finset.univ.erase (Fin.last (n + 1))
  set D : Finset (Fin (n + 2)) := Finset.univ.filter (fun k => (Finset.univ.erase k).image g = T)
  have hT_card : T.card = n + 1 := by
    simp [T]
  rcases D.eq_empty_or_nonempty with hD_empty | ⟨k₀, hk₀⟩
  · rw [hD_empty]
    simp only [Finset.card_empty, Nat.not_odd_zero, false_iff]
    intro hg_surj
    have hg_bij : Function.Bijective g := Finite.surjective_iff_bijective.mp hg_surj
    obtain ⟨k₀, hk₀_eq⟩ := hg_surj (Fin.last (n + 1))
    have hk₀_mem : k₀ ∈ D := by
      simp only [D, Finset.mem_filter, Finset.mem_univ, true_and]
      ext y
      simp only [Finset.mem_image, Finset.mem_erase, Finset.mem_univ, and_true, T]
      constructor
      · rintro ⟨x, hx_ne, rfl⟩
        intro hgx
        apply hx_ne
        exact hg_bij.1 (hgx.trans hk₀_eq.symm)
      · intro hy_ne
        obtain ⟨x, rfl⟩ := hg_surj y
        refine ⟨x, ?_, rfl⟩
        rintro rfl
        exact hy_ne hk₀_eq
    rw [hD_empty] at hk₀_mem
    exact Finset.notMem_empty k₀ hk₀_mem
  · have hk₀_img : (Finset.univ.erase k₀).image g = T := (Finset.mem_filter.mp hk₀).2
    have hk₀_card : (Finset.univ.erase k₀).card = n + 1 := by simp
    have h_inj : Set.InjOn g (Finset.univ.erase k₀ : Set (Fin (n + 2))) := by
      apply Finset.injOn_of_card_image_eq
      rw [hk₀_img, hT_card, hk₀_card]
    by_cases hgk₀ : g k₀ = Fin.last (n + 1)
    · have h_surj : Function.Surjective g := by
        intro y
        by_cases hy : y = Fin.last (n + 1)
        · exact ⟨k₀, hgk₀.trans hy.symm⟩
        · have hyT : y ∈ T := Finset.mem_erase.mpr ⟨hy, Finset.mem_univ y⟩
          rw [← hk₀_img] at hyT
          obtain ⟨x, _, hgx⟩ := Finset.mem_image.mp hyT
          exact ⟨x, hgx⟩
      have hD_eq : D = {k₀} := by
        ext k
        simp only [Finset.mem_singleton]
        constructor
        · intro hk
          by_contra hk_ne
          have hk_img : (Finset.univ.erase k).image g = T := (Finset.mem_filter.mp hk).2
          have hk₀_in : k₀ ∈ Finset.univ.erase k :=
            Finset.mem_erase.mpr ⟨Ne.symm hk_ne, Finset.mem_univ k₀⟩
          have h_last_in : g k₀ ∈ T := by
            rw [← hk_img]
            exact Finset.mem_image_of_mem g hk₀_in
          rw [hgk₀] at h_last_in
          exact (Finset.mem_erase.mp h_last_in).1 rfl
        · rintro rfl
          exact hk₀
      rw [hD_eq]
      simp [h_surj]
    · have hgk₀_T : g k₀ ∈ T := Finset.mem_erase.mpr ⟨hgk₀, Finset.mem_univ _⟩
      have hgk₀_im : g k₀ ∈ (Finset.univ.erase k₀).image g := hk₀_img.symm ▸ hgk₀_T
      obtain ⟨k₁, hk₁_er, hgk₁⟩ := Finset.mem_image.mp hgk₀_im
      have hk₁_ne : k₁ ≠ k₀ := (Finset.mem_erase.mp hk₁_er).1
      have h_not_surj : ¬ Function.Surjective g := by
        intro hg_surj
        obtain ⟨x, hx⟩ := hg_surj (Fin.last (n + 1))
        by_cases hxk₀ : x = k₀
        · subst hxk₀
          exact hgk₀ hx
        · have hx_er : x ∈ Finset.univ.erase k₀ := Finset.mem_erase.mpr ⟨hxk₀, Finset.mem_univ x⟩
          have hgx_T : g x ∈ T := hk₀_img ▸ Finset.mem_image_of_mem g hx_er
          rw [hx] at hgx_T
          exact (Finset.mem_erase.mp hgx_T).1 rfl
      have hk₁_D : k₁ ∈ D := by
        simp only [D, Finset.mem_filter, Finset.mem_univ, true_and]
        ext y
        constructor
        · intro hy
          obtain ⟨x, _, rfl⟩ := Finset.mem_image.mp hy
          by_cases hxk₀ : x = k₀
          · exact hxk₀ ▸ hgk₀_T
          · rw [← hk₀_img]
            exact Finset.mem_image_of_mem g (Finset.mem_erase.mpr ⟨hxk₀, Finset.mem_univ x⟩)
        · intro hy
          rw [← hk₀_img] at hy
          obtain ⟨x, hx_er, rfl⟩ := Finset.mem_image.mp hy
          by_cases hxk₁ : x = k₁
          · rw [hxk₁, hgk₁]
            exact Finset.mem_image_of_mem g (Finset.mem_erase.mpr ⟨hk₁_ne.symm, Finset.mem_univ k₀⟩)
          · exact Finset.mem_image_of_mem g (Finset.mem_erase.mpr ⟨hxk₁, Finset.mem_univ x⟩)
      have hD_pair : D = {k₀, k₁} := by
        ext k
        simp only [Finset.mem_insert, Finset.mem_singleton]
        constructor
        · intro hk
          by_contra hk_not
          push_neg at hk_not
          rcases hk_not with ⟨hk_ne₀, hk_ne₁⟩
          have hk_er₀ : k ∈ Finset.univ.erase k₀ := Finset.mem_erase.mpr ⟨hk_ne₀, Finset.mem_univ k⟩
          have hgk_T : g k ∈ T := hk₀_img ▸ Finset.mem_image_of_mem g hk_er₀
          have hk_img : (Finset.univ.erase k).image g = T := (Finset.mem_filter.mp hk).2
          rw [← hk_img] at hgk_T
          obtain ⟨x, hx_er, hgx⟩ := Finset.mem_image.mp hgk_T
          have hxk : x ≠ k := (Finset.mem_erase.mp hx_er).1
          have hxk₀ : x ≠ k₀ := by
            rintro rfl
            have hgk_eq : g k = g k₁ := hgx.symm.trans hgk₁.symm
            exact hk_ne₁ (h_inj hk_er₀ hk₁_er hgk_eq)
          have hx_er₀ : x ∈ Finset.univ.erase k₀ := Finset.mem_erase.mpr ⟨hxk₀, Finset.mem_univ x⟩
          exact hxk (h_inj hx_er₀ hk_er₀ hgx)
        · rintro (rfl | rfl)
          · exact hk₀
          · exact hk₁_D
      rw [hD_pair, Finset.card_pair hk₁_ne.symm]
      simp [h_not_surj]

private lemma odd_doors_iff_panchromatic {n M : ℕ} (c : Vert (n + 1) M → Fin (n + 2))
    (s : Simplex (n + 1) M) :
    Odd (Finset.univ.filter (fun k => IsDoor c s k)).card ↔ IsPanchromatic c s := by
  have h_eq : Finset.univ.filter (fun k => IsDoor c s k) =
      Finset.univ.filter (fun k =>
        (Finset.univ.erase k).image (fun r => c (vertex s r)) =
          Finset.univ.erase (Fin.last (n + 1))) := by
    ext k
    simp [isDoor_iff_erase_image]
  rw [h_eq]
  exact odd_card_doors_iff_surjective (fun r => c (vertex s r))

/-! ### Step 3: Cyclic permutation and interior facet involution -/

private def rotLeft (n : ℕ) : Equiv.Perm (Fin (n + 1)) where
  toFun := Fin.lastCases 0 Fin.succ
  invFun := Fin.cases (Fin.last n) Fin.castSucc
  left_inv x := by
    induction x using Fin.lastCases with
    | last => simp
    | cast j => simp
  right_inv x := by
    induction x using Fin.cases with
    | zero => simp
    | succ j => simp

private def incFin {M : ℕ} (x : Fin (M + 1)) (hx : x ≠ Fin.last M) : Fin (M + 1) :=
  ⟨x.val + 1, by
    have hlt : x.val < M := Nat.lt_of_le_of_ne (Nat.lt_succ_iff.mp x.isLt) (fun h => hx (Fin.ext h))
    omega⟩

private def decFin {M : ℕ} (x : Fin (M + 1)) (hx : x ≠ 0) : Fin (M + 1) :=
  ⟨x.val - 1, by
    have hpos : 0 < x.val := Nat.pos_of_ne_zero (fun h => hx (Fin.ext h))
    omega⟩

private def isBoundary {n M : ℕ} (p : Simplex (n + 1) M × Fin (n + 2)) : Prop :=
  (p.2 = 0 ∧ p.1.1 (p.1.2 0) = Fin.last M) ∨
    (p.2 = Fin.last (n + 1) ∧ p.1.1 (p.1.2 (Fin.last n)) = 0)

private def partner {n M : ℕ} (p : Simplex (n + 1) M × Fin (n + 2)) :
    Simplex (n + 1) M × Fin (n + 2) :=
  let z := p.1.1
  let σ := p.1.2
  let k := p.2
  if hk0 : k = 0 then
    if hz : z (σ 0) = Fin.last M then p
    else
      ((Function.update z (σ 0) (incFin (z (σ 0)) hz), (rotLeft n).trans σ), Fin.last (n + 1))
  else if hkl : k = Fin.last (n + 1) then
    if hz : z (σ (Fin.last n)) = 0 then p
    else
      ((Function.update z (σ (Fin.last n)) (decFin (z (σ (Fin.last n))) hz),
        (rotLeft n).symm.trans σ), 0)
  else
    have hk_pos : 0 < k.val := Nat.pos_of_ne_zero (fun h => hk0 (Fin.ext h))
    have hk_lt : k.val < n + 1 :=
      Nat.lt_of_le_of_ne (Nat.lt_succ_iff.mp k.isLt) (fun h => hkl (Fin.ext h))
    let a : Fin (n + 1) := ⟨k.val - 1, by omega⟩
    let b : Fin (n + 1) := ⟨k.val, hk_lt⟩
    ((z, (Equiv.swap a b).trans σ), k)

private lemma last_ne_zero_fin (n : ℕ) : (Fin.last (n + 1) : Fin (n + 2)) ≠ 0 := by
  intro h
  have := congr_arg Fin.val h
  simp at this

private lemma partner_not_boundary {n M : ℕ} (p : Simplex (n + 1) M × Fin (n + 2))
    (hp : ¬ isBoundary p) : ¬ isBoundary (partner p) := by
  rcases p with ⟨⟨z, σ⟩, k⟩
  unfold partner
  dsimp only
  split_ifs with hk0 hz0 hkl hzl
  · exact False.elim (hp (Or.inl ⟨hk0, hz0⟩))
  · rintro (⟨h1, _⟩ | ⟨_, h2⟩)
    · exact last_ne_zero_fin n h1
    · dsimp only at h2
      have hrot : ((rotLeft n).trans σ) (Fin.last n) = σ 0 := by simp [rotLeft]
      rw [hrot, Function.update_self] at h2
      have hval := congr_arg Fin.val h2
      simp [incFin] at hval
  · exact False.elim (hp (Or.inr ⟨hkl, hzl⟩))
  · rintro (⟨_, h1⟩ | ⟨h2, _⟩)
    · dsimp only at h1
      have hrot : ((rotLeft n).symm.trans σ) 0 = σ (Fin.last n) := by simp [rotLeft]
      rw [hrot, Function.update_self] at h1
      have hval := congr_arg Fin.val h1
      have hpos : 0 < (z (σ (Fin.last n))).val :=
        Nat.pos_of_ne_zero (fun h => hzl (Fin.ext h))
      have hlt : (z (σ (Fin.last n))).val < M + 1 := (z (σ (Fin.last n))).isLt
      simp [decFin] at hval
      omega
    · exact last_ne_zero_fin n h2.symm
  · rintro (⟨h1, _⟩ | ⟨h2, _⟩)
    · exact hk0 h1
    · exact hkl h2

private lemma partner_involutive {n M : ℕ} (p : Simplex (n + 1) M × Fin (n + 2))
    (hp : ¬ isBoundary p) : partner (partner p) = p := by
  rcases p with ⟨⟨z, σ⟩, k⟩
  by_cases hk0 : k = 0
  · subst hk0
    have hz0 : z (σ 0) ≠ Fin.last M := fun h => hp (Or.inl ⟨rfl, h⟩)
    have hp1 : partner ((z, σ), 0) =
        ((Function.update z (σ 0) (incFin (z (σ 0)) hz0), (rotLeft n).trans σ),
          Fin.last (n + 1)) := by
      simp [partner, hz0]
    rw [hp1]
    unfold partner
    dsimp only
    rw [dif_neg (last_ne_zero_fin n), dif_pos rfl]
    split_ifs with hz
    · exfalso
      have hrot : ((rotLeft n).trans σ) (Fin.last n) = σ 0 := by simp [rotLeft]
      rw [hrot, Function.update_self] at hz
      have := congr_arg Fin.val hz
      simp [incFin] at this
    · ext1
      · ext1
        · funext i
          dsimp only
          have hrot : ((rotLeft n).trans σ) (Fin.last n) = σ 0 := by simp [rotLeft]
          by_cases hi : i = ((rotLeft n).trans σ) (Fin.last n)
          · rw [hi, Function.update_self]
            ext
            dsimp only [decFin]
            rw [hrot, Function.update_self]
            simp [incFin]
          · have hi0 : i ≠ σ 0 := hrot ▸ hi
            rw [Function.update_of_ne hi, Function.update_of_ne hi0]
        · ext x
          simp
      · rfl
  · by_cases hkl : k = Fin.last (n + 1)
    · subst hkl
      have hzl : z (σ (Fin.last n)) ≠ 0 := fun h => hp (Or.inr ⟨rfl, h⟩)
      have hp1 : partner ((z, σ), Fin.last (n + 1)) =
          ((Function.update z (σ (Fin.last n)) (decFin (z (σ (Fin.last n))) hzl),
            (rotLeft n).symm.trans σ), 0) := by
        simp [partner, last_ne_zero_fin n, hzl]
      rw [hp1]
      unfold partner
      dsimp only
      rw [dif_pos rfl]
      split_ifs with hz
      · exfalso
        have hrot : ((rotLeft n).symm.trans σ) 0 = σ (Fin.last n) := by simp [rotLeft]
        rw [hrot, Function.update_self] at hz
        have hval := congr_arg Fin.val hz
        have hpos : 0 < (z (σ (Fin.last n))).val :=
          Nat.pos_of_ne_zero (fun h0 => hzl (Fin.ext h0))
        have hlt : (z (σ (Fin.last n))).val < M + 1 := (z (σ (Fin.last n))).isLt
        simp [decFin] at hval
        omega
      · ext1
        · ext1
          · funext i
            dsimp only
            have hrot : ((rotLeft n).symm.trans σ) 0 = σ (Fin.last n) := by simp [rotLeft]
            by_cases hi : i = ((rotLeft n).symm.trans σ) 0
            · rw [hi, Function.update_self]
              have hpos : 0 < (z (σ (Fin.last n))).val :=
                Nat.pos_of_ne_zero (fun h0 => hzl (Fin.ext h0))
              ext
              simp [incFin, rotLeft, decFin]
              omega
            · have hil : i ≠ σ (Fin.last n) := hrot ▸ hi
              rw [Function.update_of_ne hi, Function.update_of_ne hil]
          · ext x
            simp
        · rfl
    · have hp1 : partner ((z, σ), k) =
          ((z, (Equiv.swap ⟨k.val - 1, by
              have := Nat.pos_of_ne_zero (fun h => hk0 (Fin.ext h))
              have := Nat.lt_of_le_of_ne (Nat.lt_succ_iff.mp k.isLt) (fun h => hkl (Fin.ext h))
              omega⟩
            ⟨k.val, Nat.lt_of_le_of_ne (Nat.lt_succ_iff.mp k.isLt) (fun h => hkl (Fin.ext h))⟩).trans σ), k) := by
        simp [partner, hk0, hkl]
      rw [hp1]
      unfold partner
      dsimp only
      rw [dif_neg hk0, dif_neg hkl]
      ext1
      · ext1
        · rfl
        · ext x
          simp [Equiv.swap_apply_self]
      · rfl

private lemma partner_ne_self {n M : ℕ} (p : Simplex (n + 1) M × Fin (n + 2))
    (hp : ¬ isBoundary p) : partner p ≠ p := by
  rcases p with ⟨⟨z, σ⟩, k⟩
  unfold partner
  dsimp only
  split_ifs with hk0 hz0 hkl hzl
  · exact False.elim (hp (Or.inl ⟨hk0, hz0⟩))
  · intro h
    have := congr_arg Prod.snd h
    exact last_ne_zero_fin n (this.trans hk0)
  · exact False.elim (hp (Or.inr ⟨hkl, hzl⟩))
  · intro h
    have := congr_arg Prod.snd h
    exact last_ne_zero_fin n (this.trans hkl).symm
  · intro h
    have hσ := congr_arg (fun q => q.1.2) h
    dsimp only at hσ
    have hk_pos : 0 < k.val := Nat.pos_of_ne_zero (fun h0 => hk0 (Fin.ext h0))
    have hk_lt : k.val < n + 1 :=
      Nat.lt_of_le_of_ne (Nat.lt_succ_iff.mp k.isLt) (fun hl => hkl (Fin.ext hl))
    set a : Fin (n + 1) := ⟨k.val - 1, by omega⟩
    set b : Fin (n + 1) := ⟨k.val, hk_lt⟩
    have ha : ((Equiv.swap a b).trans σ) a = σ a := congr_fun (congr_arg DFunLike.coe hσ) a
    simp only [Equiv.trans_apply, Equiv.swap_apply_left, EmbeddingLike.apply_eq_iff_eq] at ha
    have hval := congr_arg Fin.val ha
    simp [a, b] at hval
    omega

private lemma partner_facetVerts {n M : ℕ} (p : Simplex (n + 1) M × Fin (n + 2)) :
    facetVerts (partner p).1 (partner p).2 = facetVerts p.1 p.2 := by
  rcases p with ⟨⟨z, σ⟩, k⟩
  unfold partner
  dsimp only
  split_ifs with hk0 hz0 hkl hzl
  · rfl
  · subst hk0
    funext m i
    simp only [facetVerts, Fin.succAbove_last, Fin.succAbove_zero, vertex, Equiv.symm_trans_apply,
      Fin.val_castSucc, Fin.val_succ]
    generalize ht : σ.symm i = t
    have hi : σ t = i := by rw [← ht, σ.apply_symm_apply]
    revert ht hi
    induction t using Fin.cases with
    | zero =>
      intro _ hi
      have hi0 : i = σ 0 := hi.symm
      subst hi0
      have hrot : (rotLeft n).symm 0 = Fin.last n := by simp [rotLeft]
      rw [hrot, Function.update_self]
      have hnot : ¬ (Fin.last n).val < m.val := by
        simp only [Fin.val_last, not_lt]
        exact Nat.lt_succ_iff.mp m.isLt
      have hpos : (0 : Fin (n + 1)).val < m.val + 1 := by simp
      rw [if_neg hnot, if_pos hpos]
      ext
      simp [incFin]
    | succ j =>
      intro _ hi
      have hij : i ≠ σ 0 := by
        intro h
        have := σ.injective (hi.trans h)
        exact Fin.succ_ne_zero j this
      have hrot : (rotLeft n).symm j.succ = j.castSucc := by simp [rotLeft]
      rw [hrot, Function.update_of_ne hij]
      simp only [Fin.val_castSucc, Fin.val_succ, add_lt_add_iff_right]
  · rfl
  · subst hkl
    funext m i
    simp only [facetVerts, Fin.succAbove_zero, Fin.succAbove_last, vertex, Equiv.symm_trans_apply,
      Equiv.symm_symm, Fin.val_succ, Fin.val_castSucc]
    generalize ht : σ.symm i = t
    have hi : σ t = i := by rw [← ht, σ.apply_symm_apply]
    revert ht hi
    induction t using Fin.lastCases with
    | last =>
      intro _ hi
      have hil : i = σ (Fin.last n) := hi.symm
      subst hil
      have hrot : (rotLeft n) (Fin.last n) = 0 := by simp [rotLeft]
      rw [hrot, Function.update_self]
      have hpos : (0 : Fin (n + 1)).val < m.val + 1 := by simp
      have hnot : ¬ (Fin.last n).val < m.val := by
        simp only [Fin.val_last, not_lt]
        exact Nat.lt_succ_iff.mp m.isLt
      rw [if_pos hpos, if_neg hnot]
      have hz_pos : 0 < (z (σ (Fin.last n))).val :=
        Nat.pos_of_ne_zero (fun h0 => hzl (Fin.ext h0))
      ext
      simp [decFin]
      omega
    | cast j =>
      intro _ hi
      have hij : i ≠ σ (Fin.last n) := by
        intro h
        have := σ.injective (hi.trans h)
        exact Fin.castSucc_ne_last j this
      have hrot : (rotLeft n) j.castSucc = j.succ := by simp [rotLeft]
      rw [hrot, Function.update_of_ne hij]
      simp only [Fin.val_succ, Fin.val_castSucc, add_lt_add_iff_right]
  · funext m i
    simp only [facetVerts, vertex, Equiv.symm_trans_apply, Equiv.symm_swap]
    have hk_pos : 0 < k.val := Nat.pos_of_ne_zero (fun h0 => hk0 (Fin.ext h0))
    have hk_lt : k.val < n + 1 :=
      Nat.lt_of_le_of_ne (Nat.lt_succ_iff.mp k.isLt) (fun hl => hkl (Fin.ext hl))
    set a : Fin (n + 1) := ⟨k.val - 1, by omega⟩
    set b : Fin (n + 1) := ⟨k.val, hk_lt⟩
    set r := k.succAbove m
    have hr_ne : r.val ≠ k.val := fun h => Fin.succAbove_ne k m (Fin.ext h)
    set t := σ.symm i
    have hiff : (Equiv.swap a b t).val < r.val ↔ t.val < r.val := by
      by_cases hta : t = a
      · rw [hta, Equiv.swap_apply_left]
        simp only [a, b]
        omega
      · by_cases htb : t = b
        · rw [htb, Equiv.swap_apply_right]
          simp only [a, b]
          omega
        · rw [Equiv.swap_apply_of_ne_of_ne hta htb]
    by_cases h : t.val < r.val
    · rw [if_pos (hiff.mpr h), if_pos h]
    · rw [if_neg (mt hiff.mp h), if_neg h]

/-! ### Step 4: Boundary doors and dimensional reduction -/

private lemma boundary_door_upper_last {n M : ℕ} (c : Vert (n + 1) M → Fin (n + 2))
    (h_low : ∀ (v : Vert (n + 1) M) (i : Fin (n + 1)), v i = 0 → c v ≠ i.castSucc)
    (h_high : ∀ (v : Vert (n + 1) M) (i : Fin (n + 1)),
      v i = Fin.last (M + 1) → (c v).val ≤ i.val)
    (p : Simplex (n + 1) M × Fin (n + 2)) (hp_bdry : isBoundary p)
    (hp_door : IsDoor c p.1 p.2) :
    p.2 = 0 ∧ p.1.2 0 = Fin.last n ∧ p.1.1 (Fin.last n) = Fin.last M := by
  rcases p with ⟨⟨z, σ⟩, k⟩
  rcases hp_bdry with ⟨hk0, hz0⟩ | ⟨hkl, hzl⟩
  · subst hk0
    dsimp only at hz0 ⊢
    suffices hσ0 : σ 0 = Fin.last n by
      exact ⟨rfl, hσ0, hσ0 ▸ hz0⟩
    by_contra hσ_ne
    have hσ_lt : (σ 0).val < n :=
      Nat.lt_of_le_of_ne (Nat.lt_succ_iff.mp (σ 0).isLt) (fun h => hσ_ne (Fin.ext h))
    have h_mem : (Fin.last n).castSucc ∈ Finset.univ.erase (Fin.last (n + 1)) := by
      refine Finset.mem_erase.mpr ⟨?_, Finset.mem_univ _⟩
      intro h
      have := congr_arg Fin.val h
      simp at this
    rw [← hp_door] at h_mem
    obtain ⟨m, _, hm_eq⟩ := Finset.mem_image.mp h_mem
    have hv_top : facetVerts (z, σ) 0 m (σ 0) = Fin.last (M + 1) := by
      simp only [facetVerts, Fin.succAbove_zero, vertex, Equiv.symm_apply_apply, Fin.val_zero,
         Fin.val_succ]
      rw [if_pos (Nat.succ_pos m.val), hz0, Fin.succ_last]
    have h_le := h_high (facetVerts (z, σ) 0 m) (σ 0) hv_top
    rw [hm_eq] at h_le
    simp only [Fin.val_castSucc, Fin.val_last] at h_le
    omega
  · exfalso
    subst hkl
    dsimp only at hzl hp_door
    set i₀ := σ (Fin.last n)
    have h_mem : i₀.castSucc ∈ Finset.univ.erase (Fin.last (n + 1)) := by
      refine Finset.mem_erase.mpr ⟨Fin.castSucc_ne_last i₀, Finset.mem_univ _⟩
    rw [← hp_door] at h_mem
    obtain ⟨m, _, hm_eq⟩ := Finset.mem_image.mp h_mem
    have hv_zero : facetVerts (z, σ) (Fin.last (n + 1)) m i₀ = 0 := by
      simp only [facetVerts, Fin.succAbove_last, vertex, i₀, Equiv.symm_apply_apply,
        Fin.val_last, Fin.val_castSucc]
      have hnot : ¬ n < m.val := by
        simp only [not_lt]
        exact Nat.lt_succ_iff.mp m.isLt
      rw [if_neg hnot, hzl, Fin.castSucc_zero]
    exact h_low (facetVerts (z, σ) (Fin.last (n + 1)) m) i₀ hv_zero hm_eq

private def liftVert {n M : ℕ} (w : Vert n M) : Vert (n + 1) M :=
  Fin.snoc w (Fin.last (M + 1))

private def liftSimplex {n M : ℕ} (s' : Simplex n M) : Simplex (n + 1) M :=
  (Fin.snoc s'.1 (Fin.last M),
    { toFun := Fin.cases (Fin.last n) (fun j => (s'.2 j).castSucc)
      invFun := Fin.lastCases 0 (fun j => (s'.2.symm j).succ)
      left_inv := fun x => by
        induction x using Fin.cases with
        | zero => simp
        | succ j => simp
      right_inv := fun x => by
        induction x using Fin.lastCases with
        | last => simp
        | cast j => simp })

private lemma facetVerts_liftSimplex {n M : ℕ} (s' : Simplex n M) (m : Fin (n + 1)) :
    facetVerts (liftSimplex s') 0 m = liftVert (vertex s' m) := by
  funext i
  induction i using Fin.lastCases with
  | last =>
    simp [facetVerts, liftSimplex, liftVert, vertex]
  | cast j =>
    simp [facetVerts, liftSimplex, liftVert, vertex]

/-! ### Step 5: Inductive parity proof of Cubical Sperner Lemma -/

private lemma odd_card_panchromatic {n : ℕ} :
    ∀ (M : ℕ) (c : Vert n M → Fin (n + 1)),
      (∀ (v : Vert n M) (i : Fin n), v i = 0 → c v ≠ i.castSucc) →
      (∀ (v : Vert n M) (i : Fin n), v i = Fin.last (M + 1) → (c v).val ≤ i.val) →
      Odd (Finset.univ.filter (fun s : Simplex n M => IsPanchromatic c s)).card := by
  induction n with
  | zero =>
    intro M c _ _
    have h_all : ∀ s : Simplex 0 M, IsPanchromatic c s := by
      intro s y
      exact ⟨0, (Fin.eq_zero _).trans (Fin.eq_zero y).symm⟩
    have h_eq : Finset.univ.filter (fun s : Simplex 0 M => IsPanchromatic c s) = Finset.univ := by
      ext s
      simp [h_all s]
    rw [h_eq, Finset.card_univ, Fintype.card_prod]
    simp
  | succ n ih =>
    intro M c h_low h_high
    set AllDoors : Finset (Simplex (n + 1) M × Fin (n + 2)) :=
      Finset.univ.filter (fun p => IsDoor c p.1 p.2)
    have h_sum : AllDoors.card =
        ∑ s : Simplex (n + 1) M, (Finset.univ.filter (fun k => IsDoor c s k)).card := by
      simp only [AllDoors, Finset.card_filter, Fintype.sum_prod_type]
    have h_filt : Finset.univ.filter (fun s : Simplex (n + 1) M =>
        Odd (Finset.univ.filter (fun k => IsDoor c s k)).card) =
        Finset.univ.filter (fun s : Simplex (n + 1) M => IsPanchromatic c s) := by
      ext s
      simp [odd_doors_iff_panchromatic]
    have h_odd_iff : Odd AllDoors.card ↔
        Odd (Finset.univ.filter (fun s : Simplex (n + 1) M => IsPanchromatic c s)).card := by
      rw [h_sum, Finset.odd_sum_iff_odd_card_odd, h_filt]
    rw [← h_odd_iff]
    set BdryDoors := AllDoors.filter isBoundary
    set IntDoors := AllDoors.filter (fun p => ¬ isBoundary p)
    have h_split : BdryDoors.card + IntDoors.card = AllDoors.card :=
      Finset.card_filter_add_card_filter_not isBoundary
    have h_int_even : Even IntDoors.card := by
      refine even_card_of_involutive_ne IntDoors partner ?_ ?_ ?_
      · intro p hp
        have hp1 : p ∈ AllDoors ∧ ¬ isBoundary p := Finset.mem_filter.mp hp
        have hp_door : IsDoor c p.1 p.2 := (Finset.mem_filter.mp hp1.1).2
        refine Finset.mem_filter.mpr ⟨Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩,
          partner_not_boundary p hp1.2⟩
        unfold IsDoor
        rw [partner_facetVerts p]
        exact hp_door
      · intro p hp
        exact partner_involutive p (Finset.mem_filter.mp hp).2
      · intro p hp
        exact partner_ne_self p (Finset.mem_filter.mp hp).2
    -- Induced coloring on the top face `v (Fin.last n) = Fin.last (M + 1)`
    let c' : Vert n M → Fin (n + 1) := fun w =>
      ⟨(c (liftVert w)).val, Nat.lt_succ_iff.mpr
        (h_high (liftVert w) (Fin.last n) (by simp [liftVert]))⟩
    have hc'_cast : ∀ w : Vert n M, (c' w).castSucc = c (liftVert w) := by
      intro w
      ext
      rfl
    have h_low' : ∀ (w : Vert n M) (j : Fin n), w j = 0 → c' w ≠ j.castSucc := by
      intro w j hwj hc'
      have hlw : liftVert w j.castSucc = 0 := by simp [liftVert, hwj]
      apply h_low (liftVert w) j.castSucc hlw
      rw [← hc'_cast w, hc']
    have h_high' : ∀ (w : Vert n M) (j : Fin n),
        w j = Fin.last (M + 1) → (c' w).val ≤ j.val := by
      intro w j hwj
      have hlw : liftVert w j.castSucc = Fin.last (M + 1) := by simp [liftVert, hwj]
      exact h_high (liftVert w) j.castSucc hlw
    have h_door_iff : ∀ s' : Simplex n M,
        IsDoor c (liftSimplex s') 0 ↔ IsPanchromatic c' s' := by
      intro s'
      unfold IsDoor IsPanchromatic
      have h_im : Finset.univ.image (fun m : Fin (n + 1) => c (facetVerts (liftSimplex s') 0 m)) =
          (Finset.univ.image (fun m : Fin (n + 1) => c' (vertex s' m))).image Fin.castSucc := by
        rw [Finset.image_image]
        ext y
        simp [facetVerts_liftSimplex, hc'_cast]
      have h_er : Finset.univ.erase (Fin.last (n + 1)) = Finset.univ.image Fin.castSucc := by
        rw [← Fin.succAbove_last, image_succAbove_eq_erase]
      rw [h_im, h_er]
      constructor
      · intro h y
        have hy : y.castSucc ∈ (Finset.univ.image (fun m => c' (vertex s' m))).image Fin.castSucc := by
          rw [h]
          exact Finset.mem_image_of_mem Fin.castSucc (Finset.mem_univ y)
        obtain ⟨x, hx_mem, hx_eq⟩ := Finset.mem_image.mp hy
        cases Fin.castSucc_injective (n + 1) hx_eq
        obtain ⟨m, _, hm⟩ := Finset.mem_image.mp hx_mem
        exact ⟨m, hm⟩
      · intro h_surj
        congr 1
        ext y
        simp only [Finset.mem_image, Finset.mem_univ, true_and]
        exact ⟨fun _ => trivial, fun _ => h_surj y⟩
    have h_bdry_card : BdryDoors.card =
        (Finset.univ.filter (fun s' : Simplex n M => IsPanchromatic c' s')).card := by
      symm
      refine Finset.card_bij (fun s' _ => (liftSimplex s', 0)) ?_ ?_ ?_
      · intro s' hs'
        have hpanch : IsPanchromatic c' s' := (Finset.mem_filter.mp hs').2
        have hdoor : IsDoor c (liftSimplex s') 0 := (h_door_iff s').mpr hpanch
        have hbdry : isBoundary (liftSimplex s', 0) := by
          left
          refine ⟨rfl, ?_⟩
          simp [liftSimplex]
        exact Finset.mem_filter.mpr ⟨Finset.mem_filter.mpr ⟨Finset.mem_univ _, hdoor⟩, hbdry⟩
      · intro s₁ _ s₂ _ h_eq
        dsimp only at h_eq
        have hs : liftSimplex s₁ = liftSimplex s₂ := congr_arg Prod.fst h_eq
        have hz_eq : s₁.1 = s₂.1 := by
          funext j
          have := congr_fun (congr_arg Prod.fst hs) j.castSucc
          simpa [liftSimplex, Fin.snoc_castSucc] using this
        have hσ := congr_arg Prod.snd hs
        have hτ_eq : s₁.2 = s₂.2 := by
          ext j
          have := congr_arg (fun e : Equiv.Perm (Fin (n + 1)) => (e j.succ).val) hσ
          simpa [liftSimplex] using this
        exact Prod.ext hz_eq hτ_eq
      · intro p hp
        have hp1 : p ∈ AllDoors ∧ isBoundary p := Finset.mem_filter.mp hp
        have hp_door : IsDoor c p.1 p.2 := (Finset.mem_filter.mp hp1.1).2
        obtain ⟨hk0, hσ0, hzl⟩ := boundary_door_upper_last c h_low h_high p hp1.2 hp_door
        rcases p with ⟨⟨z, σ⟩, k⟩
        dsimp only at hk0 hσ0 hzl hp_door
        subst hk0
        let z' : Fin n → Fin (M + 1) := Fin.init z
        have h_fwd : ∀ j : Fin n, (σ j.succ).val < n := by
          intro j
          have hne : σ j.succ ≠ Fin.last n := by
            intro h
            exact Fin.succ_ne_zero j (σ.injective (h.trans hσ0.symm))
          exact Nat.lt_of_le_of_ne (Nat.lt_succ_iff.mp (σ j.succ).isLt) (fun h => hne (Fin.ext h))
        have h_bwd : ∀ j : Fin n, 0 < (σ.symm j.castSucc).val := by
          intro j
          have hne : σ.symm j.castSucc ≠ 0 := by
            intro h
            have := congr_arg σ h
            rw [σ.apply_symm_apply, hσ0] at this
            exact Fin.castSucc_ne_last j this
          exact Nat.pos_of_ne_zero (fun h => hne (Fin.ext h))
        let τ : Equiv.Perm (Fin n) :=
          { toFun := fun j => ⟨(σ j.succ).val, h_fwd j⟩
            invFun := fun j => ⟨(σ.symm j.castSucc).val - 1, by
              have hlt := (σ.symm j.castSucc).isLt
              have hpos := h_bwd j
              omega⟩
            left_inv := fun j => by
              ext
              have hcast : (⟨(σ j.succ).val, h_fwd j⟩ : Fin n).castSucc = σ j.succ := by
                ext
                rfl
              simp only [hcast, σ.symm_apply_apply, Fin.val_succ]
              omega
            right_inv := fun j => by
              ext
              dsimp only
              have hpos := h_bwd j
              have hsucc : (⟨(σ.symm j.castSucc).val - 1, by
                  have hlt := (σ.symm j.castSucc).isLt
                  omega⟩ : Fin n).succ = σ.symm j.castSucc := by
                ext
                simp
                omega
              rw [hsucc, σ.apply_symm_apply, Fin.val_castSucc] }
        have h_lift : liftSimplex (z', τ) = (z, σ) := by
          ext1
          · funext i
            induction i using Fin.lastCases with
            | last => simp [liftSimplex, hzl]
            | cast j => simp [liftSimplex, z', Fin.init]
          · ext x
            induction x using Fin.cases with
            | zero => simp [liftSimplex, hσ0]
            | succ j => simp [liftSimplex, τ]
        refine ⟨(z', τ), ?_, Prod.ext h_lift rfl⟩
        refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, (h_door_iff (z', τ)).mp ?_⟩
        rw [h_lift]
        exact hp_door
    have h_bdry_odd : Odd BdryDoors.card := by
      rw [h_bdry_card]
      exact ih M c' h_low' h_high'
    rw [← h_split]
    exact h_bdry_odd.add_even h_int_even

theorem cubical_sperner {n : ℕ} (M : ℕ) (c : Vert n M → Fin (n + 1))
    (h_low : ∀ (v : Vert n M) (i : Fin n), v i = 0 → c v ≠ i.castSucc)
    (h_high : ∀ (v : Vert n M) (i : Fin n), v i = Fin.last (M + 1) → (c v).val ≤ i.val) :
    ∃ s : Simplex n M, IsPanchromatic c s := by
  have h_odd := odd_card_panchromatic M c h_low h_high
  have h_ne : (Finset.univ.filter (fun s : Simplex n M => IsPanchromatic c s)).Nonempty := by
    rw [Finset.nonempty_iff_ne_empty]
    intro h_emp
    rw [h_emp] at h_odd
    simp at h_odd
  obtain ⟨s, hs⟩ := h_ne
  exact ⟨s, (Finset.mem_filter.mp hs).2⟩

end UL.Proof_cit_brouwer_Race2

import UL.Proof.cit_brouwer.H1_Sperner
set_option autoImplicit false

open Filter Topology

namespace UL.Proof_cit_brouwer

/-- Grid point `(w i : ℝ) / (M : ℝ)` in `ℝ^n`. -/
noncomputable def gridPt {n : ℕ} (M : ℕ) (w : Fin n → ℕ) : Fin n → ℝ :=
  fun i => (w i : ℝ) / (M : ℝ)

/-- Coordinate `k` is active at grid vertex `w` if `w k < M` and `gridPt M w k ≤ g (gridPt M w) k`. -/
def activeCoord {n : ℕ} (g : (Fin n → ℝ) → (Fin n → ℝ)) (M : ℕ) (w : Fin n → ℕ) (k : Fin n) : Prop :=
  w k < M ∧ gridPt M w k ≤ g (gridPt M w) k

/-- Cubical Sperner coloring associated to `g` at mesh `M`. -/
noncomputable def cubeColor {n : ℕ} (g : (Fin n → ℝ) → (Fin n → ℝ)) (M : ℕ) (w : Fin n → ℕ) :
    Fin (n + 1) := by
  classical
  exact if h : ∃ k : Fin n, activeCoord g M w k then
    ((Finset.univ.filter (activeCoord g M w)).min'
      ⟨h.choose, Finset.mem_filter.mpr ⟨Finset.mem_univ _, h.choose_spec⟩⟩).castSucc
  else
    Fin.last n

private lemma cubeColor_le_of_eq_zero {n : ℕ} (g : (Fin n → ℝ) → (Fin n → ℝ))
    (hg_mem : ∀ (x : Fin n → ℝ) (i : Fin n), 0 ≤ g x i ∧ g x i ≤ 1)
    {M : ℕ} (hM : 0 < M) (w : Fin n → ℕ) (i : Fin n) (hw : w i = 0) :
    cubeColor g M w ≤ i.castSucc := by
  classical
  have hact : activeCoord g M w i := by
    refine ⟨by omega, ?_⟩
    simp [gridPt, hw, (hg_mem (gridPt M w) i).1]
  have hex : ∃ k : Fin n, activeCoord g M w k := ⟨i, hact⟩
  unfold cubeColor
  rw [dif_pos hex, Fin.castSucc_le_castSucc_iff]
  exact Finset.min'_le _ i (Finset.mem_filter.mpr ⟨Finset.mem_univ _, hact⟩)

private lemma cubeColor_ne_of_eq_M {n : ℕ} (g : (Fin n → ℝ) → (Fin n → ℝ))
    {M : ℕ} (w : Fin n → ℕ) (i : Fin n) (hw : w i = M) :
    cubeColor g M w ≠ i.castSucc := by
  classical
  have hnact : ¬ activeCoord g M w i := by
    simp [activeCoord, hw]
  unfold cubeColor
  split_ifs with hex
  · intro heq
    have hm_eq : (Finset.univ.filter (activeCoord g M w)).min'
        ⟨hex.choose, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hex.choose_spec⟩⟩ = i :=
      Fin.castSucc_inj.mp heq
    have hm_mem := Finset.min'_mem (Finset.univ.filter (activeCoord g M w))
      ⟨hex.choose, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hex.choose_spec⟩⟩
    rw [hm_eq] at hm_mem
    exact hnact (Finset.mem_filter.mp hm_mem).2
  · exact (Fin.castSucc_lt_last i).ne'

private lemma le_g_of_cubeColor_eq_castSucc {n : ℕ} (g : (Fin n → ℝ) → (Fin n → ℝ))
    {M : ℕ} (w : Fin n → ℕ) (j : Fin n) (hc : cubeColor g M w = j.castSucc) :
    gridPt M w j ≤ g (gridPt M w) j := by
  classical
  unfold cubeColor at hc
  split_ifs at hc with hex
  · have hm_eq : (Finset.univ.filter (activeCoord g M w)).min'
        ⟨hex.choose, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hex.choose_spec⟩⟩ = j :=
      Fin.castSucc_inj.mp hc
    have hm_mem := Finset.min'_mem (Finset.univ.filter (activeCoord g M w))
      ⟨hex.choose, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hex.choose_spec⟩⟩
    rw [hm_eq] at hm_mem
    exact (Finset.mem_filter.mp hm_mem).2.2
  · exact False.elim ((Fin.castSucc_lt_last j).ne' hc)

private lemma g_le_of_cubeColor_eq_succ {n : ℕ} (g : (Fin n → ℝ) → (Fin n → ℝ))
    (hg_mem : ∀ (x : Fin n → ℝ) (i : Fin n), 0 ≤ g x i ∧ g x i ≤ 1)
    {M : ℕ} (hM : 0 < M) (w : Fin n → ℕ) (j : Fin n) (hw : w j ≤ M)
    (hc : cubeColor g M w = j.succ) :
    g (gridPt M w) j ≤ gridPt M w j := by
  classical
  have hnact : ¬ activeCoord g M w j := by
    unfold cubeColor at hc
    split_ifs at hc with hex
    · intro hact
      set m := (Finset.univ.filter (activeCoord g M w)).min'
        ⟨hex.choose, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hex.choose_spec⟩⟩
      have hm_le : m ≤ j := Finset.min'_le _ j (Finset.mem_filter.mpr ⟨Finset.mem_univ _, hact⟩)
      have hval : m.val = j.val + 1 := congr_arg Fin.val hc
      have hle_val : m.val ≤ j.val := hm_le
      omega
    · exact fun hact => hex ⟨j, hact⟩
  rcases Nat.eq_or_lt_of_le hw with h_eq | h_lt
  · have hM_ne : (M : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (by omega)
    have hpt : gridPt M w j = 1 := by
      simp [gridPt, h_eq, hM_ne]
    rw [hpt]
    exact (hg_mem (gridPt M w) j).2
  · have hnotle : ¬ (gridPt M w j ≤ g (gridPt M w) j) := fun hle => hnact ⟨h_lt, hle⟩
    exact le_of_lt (not_le.mp hnotle)

/-- Brouwer's fixed-point theorem for continuous maps into `[0, 1]^n`. -/
theorem exists_fixedPoint_unitCube (n : ℕ) (g : (Fin n → ℝ) → (Fin n → ℝ))
    (hg_cont : Continuous g)
    (hg_mem : ∀ (x : Fin n → ℝ) (i : Fin n), 0 ≤ g x i ∧ g x i ≤ 1) :
    ∃ x : Fin n → ℝ, (∀ i, 0 ≤ x i ∧ x i ≤ 1) ∧ g x = x := by
  have hpan : ∀ m : ℕ, ∃ (v : Fin n → Fin (m + 1)) (σ : Equiv.Perm (Fin n)),
      Function.Surjective (fun r : Fin (n + 1) => cubeColor g (m + 1) (kuhnVertex v σ r)) := by
    intro m
    exact exists_panchromatic_kuhn n (m + 1) (Nat.succ_pos m) (cubeColor g (m + 1))
      (cubeColor_le_of_eq_zero g hg_mem (Nat.succ_pos m))
      (cubeColor_ne_of_eq_M g)
  let vSeq : (m : ℕ) → Fin n → Fin (m + 1) := fun m => Classical.choose (hpan m)
  let σSeq : (m : ℕ) → Equiv.Perm (Fin n) :=
    fun m => Classical.choose (Classical.choose_spec (hpan m))
  have hsurj : ∀ m : ℕ, Function.Surjective
      (fun r : Fin (n + 1) => cubeColor g (m + 1) (kuhnVertex (vSeq m) (σSeq m) r)) :=
    fun m => Classical.choose_spec (Classical.choose_spec (hpan m))
  let xSeq : ℕ → (Fin n → ℝ) := fun m => gridPt (m + 1) (kuhnVertex (vSeq m) (σSeq m) 0)
  let K : Set (Fin n → ℝ) := Set.pi Set.univ (fun _ => Set.Icc (0 : ℝ) 1)
  have hK_comp : IsCompact K := isCompact_univ_pi (fun _ => isCompact_Icc)
  have hx_mem : ∀ m : ℕ, xSeq m ∈ K := by
    intro m i _
    dsimp [xSeq, gridPt]
    constructor
    · positivity
    · rw [div_le_one (by positivity)]
      exact_mod_cast kuhnVertex_le (vSeq m) (σSeq m) 0 i
  obtain ⟨xStar, hxStar, φ, hφ, hlim⟩ := hK_comp.tendsto_subseq hx_mem
  have hvert_lim : ∀ r : ℕ → Fin (n + 1),
      Tendsto (fun k : ℕ => gridPt (φ k + 1) (kuhnVertex (vSeq (φ k)) (σSeq (φ k)) (r (φ k))))
        atTop (𝓝 xStar) := by
    intro r
    rw [tendsto_pi_nhds]
    intro i
    have hx_i : Tendsto (fun k : ℕ => xSeq (φ k) i) atTop (𝓝 (xStar i)) :=
      (tendsto_pi_nhds.mp hlim) i
    let d : ℕ → ℝ := fun k =>
      gridPt (φ k + 1) (kuhnVertex (vSeq (φ k)) (σSeq (φ k)) (r (φ k))) i - xSeq (φ k) i
    have h1 : Tendsto (fun k : ℕ => (1 : ℝ) / ((φ k : ℝ) + 1)) atTop (𝓝 0) :=
      tendsto_one_div_add_atTop_nhds_zero_nat.comp hφ.tendsto_atTop
    have hneg1 : Tendsto (fun k : ℕ => -((1 : ℝ) / ((φ k : ℝ) + 1))) atTop (𝓝 0) := by
      simpa using h1.neg
    have hd_abs : ∀ k : ℕ, |d k| ≤ (1 : ℝ) / ((φ k : ℝ) + 1) := by
      intro k
      have hpos : (0 : ℝ) < (φ k : ℝ) + 1 := by positivity
      have heq : d k =
          ((kuhnVertex (vSeq (φ k)) (σSeq (φ k)) (r (φ k)) i : ℝ) -
            (kuhnVertex (vSeq (φ k)) (σSeq (φ k)) 0 i : ℝ)) / ((φ k : ℝ) + 1) := by
        dsimp [d, xSeq, gridPt]
        push_cast
        ring
      rw [heq, abs_div, abs_of_pos hpos]
      exact div_le_div_of_nonneg_right (kuhnVertex_sub_le_one _ _ _ _ _) hpos.le
    have hd_lim : Tendsto d atTop (𝓝 0) :=
      tendsto_of_tendsto_of_tendsto_of_le_of_le hneg1 h1
        (fun k => (abs_le.mp (hd_abs k)).1)
        (fun k => (abs_le.mp (hd_abs k)).2)
    have hsum : Tendsto (fun k : ℕ => xSeq (φ k) i + d k) atTop (𝓝 (xStar i + 0)) :=
      hx_i.add hd_lim
    simpa [d] using hsum
  have hxStar_mem : ∀ i : Fin n, 0 ≤ xStar i ∧ xStar i ≤ 1 :=
    fun i => hxStar i (Set.mem_univ i)
  refine ⟨xStar, hxStar_mem, ?_⟩
  ext j
  have hlo : xStar j ≤ g xStar j := by
    let r₁ : ℕ → Fin (n + 1) := fun m => Classical.choose (hsurj m j.castSucc)
    have hr₁ : ∀ m : ℕ, cubeColor g (m + 1) (kuhnVertex (vSeq m) (σSeq m) (r₁ m)) = j.castSucc :=
      fun m => Classical.choose_spec (hsurj m j.castSucc)
    have hy₁ : Tendsto (fun k : ℕ =>
        gridPt (φ k + 1) (kuhnVertex (vSeq (φ k)) (σSeq (φ k)) (r₁ (φ k)))) atTop (𝓝 xStar) :=
      hvert_lim r₁
    have hy₁_j : Tendsto (fun k : ℕ =>
        gridPt (φ k + 1) (kuhnVertex (vSeq (φ k)) (σSeq (φ k)) (r₁ (φ k))) j) atTop (𝓝 (xStar j)) :=
      (tendsto_pi_nhds.mp hy₁) j
    have hgy₁_j : Tendsto (fun k : ℕ =>
        g (gridPt (φ k + 1) (kuhnVertex (vSeq (φ k)) (σSeq (φ k)) (r₁ (φ k)))) j)
        atTop (𝓝 (g xStar j)) :=
      ((tendsto_pi_nhds.mp (hg_cont.tendsto xStar)) j).comp hy₁
    exact le_of_tendsto_of_tendsto' hy₁_j hgy₁_j
      (fun k => le_g_of_cubeColor_eq_castSucc g _ j (hr₁ (φ k)))
  have hhi : g xStar j ≤ xStar j := by
    let r₂ : ℕ → Fin (n + 1) := fun m => Classical.choose (hsurj m j.succ)
    have hr₂ : ∀ m : ℕ, cubeColor g (m + 1) (kuhnVertex (vSeq m) (σSeq m) (r₂ m)) = j.succ :=
      fun m => Classical.choose_spec (hsurj m j.succ)
    have hy₂ : Tendsto (fun k : ℕ =>
        gridPt (φ k + 1) (kuhnVertex (vSeq (φ k)) (σSeq (φ k)) (r₂ (φ k)))) atTop (𝓝 xStar) :=
      hvert_lim r₂
    have hy₂_j : Tendsto (fun k : ℕ =>
        gridPt (φ k + 1) (kuhnVertex (vSeq (φ k)) (σSeq (φ k)) (r₂ (φ k))) j) atTop (𝓝 (xStar j)) :=
      (tendsto_pi_nhds.mp hy₂) j
    have hgy₂_j : Tendsto (fun k : ℕ =>
        g (gridPt (φ k + 1) (kuhnVertex (vSeq (φ k)) (σSeq (φ k)) (r₂ (φ k)))) j)
        atTop (𝓝 (g xStar j)) :=
      ((tendsto_pi_nhds.mp (hg_cont.tendsto xStar)) j).comp hy₂
    exact le_of_tendsto_of_tendsto' hgy₂_j hy₂_j
      (fun k => g_le_of_cubeColor_eq_succ g hg_mem (Nat.succ_pos (φ k)) _ j
        (kuhnVertex_le _ _ _ _) (hr₂ (φ k)))
  exact le_antisymm hhi hlo

end UL.Proof_cit_brouwer

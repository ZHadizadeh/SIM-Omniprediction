import Mathlib
set_option autoImplicit false

namespace UL.Proof_cit_brouwer

/-- Vertices of a Kuhn `n`-simplex `(v, σ)` in `{0, …, M}^n`. -/
def kuhnVertex {n M : ℕ} (v : Fin n → Fin M) (σ : Equiv.Perm (Fin n))
    (j : Fin (n + 1)) (i : Fin n) : ℕ :=
  (v i).val + if (σ.symm i).val < j.val then 1 else 0

theorem kuhnVertex_le {n M : ℕ} (v : Fin n → Fin M) (σ : Equiv.Perm (Fin n))
    (j : Fin (n + 1)) (i : Fin n) :
    kuhnVertex v σ j i ≤ M := by
  dsimp [kuhnVertex]
  have hv : (v i).val < M := (v i).isLt
  split_ifs <;> omega

theorem kuhnVertex_sub_le_one {n M : ℕ} (v : Fin n → Fin M) (σ : Equiv.Perm (Fin n))
    (j₁ j₂ : Fin (n + 1)) (i : Fin n) :
    |(kuhnVertex v σ j₁ i : ℝ) - (kuhnVertex v σ j₂ i : ℝ)| ≤ 1 := by
  dsimp [kuhnVertex]
  split_ifs <;> push_cast <;> norm_num

/-! ### Part 1: Involution parity on finite sets -/

private lemma even_card_of_involutive_ne {α : Type*} [DecidableEq α] :
    ∀ (m : ℕ) (s : Finset α) (ι : α → α),
      s.card = m →
      (∀ x ∈ s, ι x ∈ s) →
      (∀ x ∈ s, ι (ι x) = x) →
      (∀ x ∈ s, ι x ≠ x) →
      s.card % 2 = 0 := by
  intro m
  induction m using Nat.strong_induction_on with
  | h m ih =>
    intro s ι hcard hmem hinv hne
    rcases s.eq_empty_or_nonempty with rfl | ⟨a, ha⟩
    · simp
    · have hb : ι a ∈ s := hmem a ha
      have hba : ι a ≠ a := hne a ha
      have hb_er : ι a ∈ s.erase a := Finset.mem_erase.mpr ⟨hba, hb⟩
      let s' : Finset α := (s.erase a).erase (ι a)
      have hcard_er1 : (s.erase a).card + 1 = s.card := Finset.card_erase_add_one ha
      have hcard_er2 : s'.card + 1 = (s.erase a).card := Finset.card_erase_add_one hb_er
      have hs'_lt : s'.card < m := by omega
      have hs'_mem : ∀ x ∈ s', ι x ∈ s' := by
        intro x hx
        have hx1 : x ≠ ι a ∧ x ∈ s.erase a := Finset.mem_erase.mp hx
        have hx2 : x ≠ a ∧ x ∈ s := Finset.mem_erase.mp hx1.2
        refine Finset.mem_erase.mpr ⟨?_, Finset.mem_erase.mpr ⟨?_, hmem x hx2.2⟩⟩
        · intro h_eq
          have := congr_arg ι h_eq
          rw [hinv x hx2.2, hinv a ha] at this
          exact hx2.1 this
        · intro h_eq
          have := congr_arg ι h_eq
          rw [hinv x hx2.2] at this
          exact hx1.1 this
      have hs'_sub : ∀ x ∈ s', x ∈ s := fun x hx =>
        (Finset.mem_erase.mp (Finset.mem_erase.mp hx).2).2
      have hpar := ih s'.card hs'_lt s' ι rfl hs'_mem
        (fun x hx => hinv x (hs'_sub x hx))
        (fun x hx => hne x (hs'_sub x hx))
      omega

private lemma card_mod_two_eq_filter_fixed {α : Type*} [DecidableEq α]
    (s : Finset α) (ι : α → α)
    (hmem : ∀ x ∈ s, ι x ∈ s)
    (hinv : ∀ x ∈ s, ι (ι x) = x) :
    s.card % 2 = (s.filter (fun x => ι x = x)).card % 2 := by
  have hsplit := Finset.filter_card_add_filter_neg_card_eq_card (s := s) (p := fun x => ι x = x)
  let smove := s.filter (fun x => ¬ ι x = x)
  have hmove_mem : ∀ x ∈ smove, ι x ∈ smove := by
    intro x hx
    rcases Finset.mem_filter.mp hx with ⟨hxs, hne⟩
    refine Finset.mem_filter.mpr ⟨hmem x hxs, ?_⟩
    intro heq
    have h2 : ι (ι x) = ι x := heq
    rw [hinv x hxs] at h2
    exact hne h2.symm
  have heven : smove.card % 2 = 0 :=
    even_card_of_involutive_ne smove.card smove ι rfl hmove_mem
      (fun x hx => hinv x (Finset.mem_filter.mp hx).1)
      (fun x hx => (Finset.mem_filter.mp hx).2)
  have hsplit' : (s.filter (fun x => ι x = x)).card + smove.card = s.card := hsplit
  omega

private lemma sum_mod_two {α : Type*} [DecidableEq α] (s : Finset α) (f : α → ℕ) :
    (∑ x ∈ s, f x) % 2 = (∑ x ∈ s, f x % 2) % 2 := by
  induction s using Finset.induction_on with
  | empty => simp
  | @insert a t ha ih =>
    rw [Finset.sum_insert ha, Finset.sum_insert ha]
    omega

/-! ### Part 2: Door parity on a single simplex -/

attribute [local instance] Classical.propDecidable

private def isDoorAt {n : ℕ} (f : Fin (n + 2) → Fin (n + 2)) (k : Fin (n + 2)) : Prop :=
  ∀ a : Fin (n + 1), ∃ j : Fin (n + 2), j ≠ k ∧ f j = a.castSucc

private lemma surjective_fin_succ_fibers {n : ℕ} (g : Fin (n + 2) → Fin (n + 1))
    (hg : Function.Surjective g) :
    ∃ b₀ : Fin (n + 1),
      (Finset.univ.filter (fun j => g j = b₀)).card = 2 ∧
      ∀ b : Fin (n + 1), b ≠ b₀ → (Finset.univ.filter (fun j => g j = b)).card = 1 := by
  have hlt : Fintype.card (Fin (n + 1)) < Fintype.card (Fin (n + 2)) := by simp
  obtain ⟨j₁, j₂, hj_ne, hj_eq⟩ := Fintype.exists_ne_map_eq_of_card_lt g hlt
  let F : Fin (n + 1) → Finset (Fin (n + 2)) := fun b => Finset.univ.filter (fun j => g j = b)
  let b₀ : Fin (n + 1) := g j₁
  have hge1 : ∀ b : Fin (n + 1), 1 ≤ (F b).card := by
    intro b
    obtain ⟨j, hj⟩ := hg b
    exact Finset.card_pos.mpr ⟨j, Finset.mem_filter.mpr ⟨Finset.mem_univ j, hj⟩⟩
  have hge2 : 2 ≤ (F b₀).card := by
    have hsub : ({j₁, j₂} : Finset (Fin (n + 2))) ⊆ F b₀ := by
      intro x hx
      rcases Finset.mem_insert.mp hx with rfl | hx2
      · exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, rfl⟩
      · rw [Finset.mem_singleton.mp hx2]
        exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, hj_eq.symm⟩
    have hpair : ({j₁, j₂} : Finset (Fin (n + 2))).card = 2 := Finset.card_pair hj_ne
    linarith [Finset.card_le_card hsub]
  have htot : ∑ b : Fin (n + 1), (F b).card = n + 2 := by
    have h := Finset.card_eq_sum_card_fiberwise
      (s := (Finset.univ : Finset (Fin (n + 2))))
      (t := (Finset.univ : Finset (Fin (n + 1))))
      (f := g) (fun x _ => Finset.mem_univ (g x))
    simpa [F] using h.symm
  have hsplit : (F b₀).card + ∑ b ∈ Finset.univ.erase b₀, (F b).card = n + 2 := by
    have hadd := Finset.add_sum_erase (Finset.univ : Finset (Fin (n + 1)))
      (fun b => (F b).card) (Finset.mem_univ b₀)
    exact hadd.trans htot
  have herase_card : (Finset.univ.erase b₀).card = n := by
    have := Finset.card_erase_of_mem (Finset.mem_univ b₀)
    simpa using this
  have hsum_lo : n ≤ ∑ b ∈ Finset.univ.erase b₀, (F b).card := by
    calc
      n = ∑ _b ∈ Finset.univ.erase b₀, 1 := by simp [herase_card]
      _ ≤ ∑ b ∈ Finset.univ.erase b₀, (F b).card :=
        Finset.sum_le_sum (fun b _ => hge1 b)
  have hFb₀ : (F b₀).card = 2 := by omega
  have hsum_eq : ∑ b ∈ Finset.univ.erase b₀, (F b).card = ∑ _b ∈ Finset.univ.erase b₀, 1 := by
    simp [herase_card]
    omega
  have hall1 : ∀ b ∈ Finset.univ.erase b₀, (F b).card = 1 :=
    (Finset.sum_eq_sum_iff_of_le (fun b _ => hge1 b)).mp hsum_eq.symm |> fun h b hb => (h b hb).symm
  refine ⟨b₀, hFb₀, fun b hb => hall1 b (Finset.mem_erase.mpr ⟨hb, Finset.mem_univ b⟩)⟩

private lemma door_card_mod_two {n : ℕ} (f : Fin (n + 2) → Fin (n + 2)) :
    ((Finset.univ : Finset (Fin (n + 2))).filter (isDoorAt f)).card % 2 =
      if Function.Surjective f then 1 else 0 := by
  by_cases hsurj : Function.Surjective f
  · rw [if_pos hsurj]
    have hinj : Function.Injective f := Finite.injective_iff_surjective.mpr hsurj
    obtain ⟨k₀, hk₀⟩ := hsurj (Fin.last (n + 1))
    have hfilt : (Finset.univ : Finset (Fin (n + 2))).filter (isDoorAt f) = {k₀} := by
      ext k
      simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_singleton]
      constructor
      · intro hdoor
        by_contra hne
        have hfk_ne : f k ≠ Fin.last (n + 1) := fun heq => hne (hinj (heq.trans hk₀.symm))
        have hfk_lt : (f k).val < n + 1 := Fin.val_lt_last hfk_ne
        let a : Fin (n + 1) := ⟨(f k).val, hfk_lt⟩
        obtain ⟨j, hj_ne, hj_eq⟩ := hdoor a
        have hcast : a.castSucc = f k := Fin.ext rfl
        rw [hcast] at hj_eq
        exact hj_ne (hinj hj_eq)
      · rintro rfl a
        obtain ⟨j, hj_eq⟩ := hsurj a.castSucc
        refine ⟨j, ?_, hj_eq⟩
        rintro rfl
        exact (Fin.castSucc_lt_last a).ne (hj_eq.symm.trans hk₀)
    rw [hfilt]
    simp
  · rw [if_neg hsurj]
    by_cases hall : ∀ a : Fin (n + 1), ∃ j : Fin (n + 2), f j = a.castSucc
    · have hno_last : ∀ j : Fin (n + 2), f j ≠ Fin.last (n + 1) := by
        intro j₀ hj₀
        apply hsurj
        intro y
        by_cases hy : y = Fin.last (n + 1)
        · exact ⟨j₀, hj₀.trans hy.symm⟩
        · let a : Fin (n + 1) := ⟨y.val, Fin.val_lt_last hy⟩
          obtain ⟨j, hj⟩ := hall a
          exact ⟨j, hj.trans (Fin.ext rfl)⟩
      let g : Fin (n + 2) → Fin (n + 1) := fun j => ⟨(f j).val, Fin.val_lt_last (hno_last j)⟩
      have hg_cast : ∀ j : Fin (n + 2), (g j).castSucc = f j := fun j => Fin.ext rfl
      have hg_surj : Function.Surjective g := by
        intro a
        obtain ⟨j, hj⟩ := hall a
        exact ⟨j, Fin.castSucc_inj.mp ((hg_cast j).trans hj)⟩
      obtain ⟨b₀, hFb₀, hFb_one⟩ := surjective_fin_succ_fibers g hg_surj
      have hfilt : (Finset.univ : Finset (Fin (n + 2))).filter (isDoorAt f) =
          Finset.univ.filter (fun j => g j = b₀) := by
        ext k
        simp only [Finset.mem_filter, Finset.mem_univ, true_and]
        constructor
        · intro hdoor
          by_contra hne
          have hcard1 : (Finset.univ.filter (fun j => g j = g k)).card = 1 := hFb_one (g k) hne
          obtain ⟨j, hj_ne, hj_eq⟩ := hdoor (g k)
          have hgj : g j = g k := Fin.castSucc_inj.mp ((hg_cast j).trans hj_eq)
          have hpair_sub : ({j, k} : Finset (Fin (n + 2))) ⊆
              Finset.univ.filter (fun x => g x = g k) := by
            intro x hx
            rcases Finset.mem_insert.mp hx with rfl | hxk
            · exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, hgj⟩
            · rw [Finset.mem_singleton.mp hxk]
              exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, rfl⟩
          have h2 : 2 ≤ (Finset.univ.filter (fun x => g x = g k)).card := by
            have hp : ({j, k} : Finset (Fin (n + 2))).card = 2 := Finset.card_pair hj_ne
            linarith [Finset.card_le_card hpair_sub]
          omega
        · intro hgk a
          by_cases hab : a = b₀
          · subst hab
            have hk_mem : k ∈ Finset.univ.filter (fun j => g j = a) :=
              Finset.mem_filter.mpr ⟨Finset.mem_univ _, hgk⟩
            have her_pos : 0 < ((Finset.univ.filter (fun j => g j = a)).erase k).card := by
              have := Finset.card_erase_of_mem hk_mem
              omega
            obtain ⟨j, hj⟩ := Finset.card_pos.mp her_pos
            rcases Finset.mem_erase.mp hj with ⟨hj_ne, hj_mem⟩
            have hgj : g j = a := (Finset.mem_filter.mp hj_mem).2
            exact ⟨j, hj_ne, (hg_cast j).symm.trans (congr_arg Fin.castSucc hgj)⟩
          · obtain ⟨j, hgj⟩ := hg_surj a
            refine ⟨j, ?_, (hg_cast j).symm.trans (congr_arg Fin.castSucc hgj)⟩
            rintro rfl
            exact hab (hgj.symm.trans hgk)
      rw [hfilt, hFb₀]
    · push_neg at hall
      obtain ⟨a₀, ha₀⟩ := hall
      have hempty : (Finset.univ : Finset (Fin (n + 2))).filter (isDoorAt f) = ∅ := by
        ext k
        simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.notMem_empty, iff_false]
        intro hdoor
        obtain ⟨j, _, hj⟩ := hdoor a₀
        exact ha₀ j hj
      rw [hempty]
      simp

/-! ### Part 3: Neighbor-facet involution on `DoorState` -/

private abbrev DoorState (n M : ℕ) : Type :=
  (Fin (n + 1) → Fin M) × Equiv.Perm (Fin (n + 1)) × Fin (n + 2)

private def neighborInv {n M : ℕ} (x : DoorState n M) : DoorState n M :=
  let v := x.1
  let σ := x.2.1
  let k := x.2.2
  if hk_mid : 0 < k.val ∧ k.val < n + 1 then
    let a : Fin (n + 1) := ⟨k.val - 1, by omega⟩
    let b : Fin (n + 1) := ⟨k.val, by omega⟩
    (v, σ * Equiv.swap a b, k)
  else if _hk0 : k.val = 0 then
    if hv0 : (v (σ 0)).val + 1 < M then
      let v' : Fin (n + 1) → Fin M :=
        fun i => if i = σ 0 then ⟨(v (σ 0)).val + 1, hv0⟩ else v i
      (v', σ * finRotate (n + 1), Fin.last (n + 1))
    else
      x
  else
    if hvn : 0 < (v (σ (Fin.last n))).val then
      let v'' : Fin (n + 1) → Fin M :=
        fun i => if i = σ (Fin.last n) then ⟨(v (σ (Fin.last n))).val - 1, by omega⟩ else v i
      (v'', σ * (finRotate (n + 1)).symm, 0)
    else
      x

private lemma fin_cases_three {n : ℕ} (k : Fin (n + 2)) :
    (0 < k.val ∧ k.val < n + 1) ∨ k = 0 ∨ k = Fin.last (n + 1) := by
  by_cases h0 : k.val = 0
  · exact Or.inr (Or.inl (Fin.ext h0))
  · by_cases hl : k.val = n + 1
    · exact Or.inr (Or.inr (Fin.ext hl))
    · have := k.isLt
      exact Or.inl ⟨by omega, by omega⟩

private lemma neighborInv_mid {n M : ℕ} (v : Fin (n + 1) → Fin M)
    (σ : Equiv.Perm (Fin (n + 1))) (k : Fin (n + 2))
    (hk : 0 < k.val ∧ k.val < n + 1) :
    neighborInv (v, σ, k) =
      (v, σ * Equiv.swap ⟨k.val - 1, by omega⟩ ⟨k.val, by omega⟩, k) := by
  unfold neighborInv
  dsimp only
  rw [dif_pos hk]

private lemma neighborInv_zero_pos {n M : ℕ} (v : Fin (n + 1) → Fin M)
    (σ : Equiv.Perm (Fin (n + 1))) (hv0 : (v (σ 0)).val + 1 < M) :
    neighborInv (v, σ, 0) =
      ((fun i => if i = σ 0 then ⟨(v (σ 0)).val + 1, hv0⟩ else v i),
        σ * finRotate (n + 1), Fin.last (n + 1)) := by
  unfold neighborInv
  dsimp only
  have hnot_mid : ¬ (0 < (0 : Fin (n + 2)).val ∧ (0 : Fin (n + 2)).val < n + 1) := by simp
  have hk0 : (0 : Fin (n + 2)).val = 0 := rfl
  rw [dif_neg hnot_mid, dif_pos hk0, dif_pos hv0]

private lemma neighborInv_zero_neg {n M : ℕ} (v : Fin (n + 1) → Fin M)
    (σ : Equiv.Perm (Fin (n + 1))) (hv0 : ¬ ((v (σ 0)).val + 1 < M)) :
    neighborInv (v, σ, 0) = (v, σ, 0) := by
  unfold neighborInv
  dsimp only
  have hnot_mid : ¬ (0 < (0 : Fin (n + 2)).val ∧ (0 : Fin (n + 2)).val < n + 1) := by simp
  have hk0 : (0 : Fin (n + 2)).val = 0 := rfl
  rw [dif_neg hnot_mid, dif_pos hk0, dif_neg hv0]

private lemma neighborInv_last_pos {n M : ℕ} (v : Fin (n + 1) → Fin M)
    (σ : Equiv.Perm (Fin (n + 1))) (hvn : 0 < (v (σ (Fin.last n))).val) :
    neighborInv (v, σ, Fin.last (n + 1)) =
      ((fun i => if i = σ (Fin.last n) then ⟨(v (σ (Fin.last n))).val - 1, by omega⟩ else v i),
        σ * (finRotate (n + 1)).symm, 0) := by
  unfold neighborInv
  dsimp only
  have hnot_mid : ¬ (0 < (Fin.last (n + 1)).val ∧ (Fin.last (n + 1)).val < n + 1) := by simp
  have hnot_zero : ¬ ((Fin.last (n + 1)).val = 0) := by simp
  rw [dif_neg hnot_mid, dif_neg hnot_zero, dif_pos hvn]

private lemma neighborInv_last_neg {n M : ℕ} (v : Fin (n + 1) → Fin M)
    (σ : Equiv.Perm (Fin (n + 1))) (hvn : ¬ (0 < (v (σ (Fin.last n))).val)) :
    neighborInv (v, σ, Fin.last (n + 1)) = (v, σ, Fin.last (n + 1)) := by
  unfold neighborInv
  dsimp only
  have hnot_mid : ¬ (0 < (Fin.last (n + 1)).val ∧ (Fin.last (n + 1)).val < n + 1) := by simp
  have hnot_zero : ¬ ((Fin.last (n + 1)).val = 0) := by simp
  rw [dif_neg hnot_mid, dif_neg hnot_zero, dif_neg hvn]

private lemma finRotate_symm_zero (n : ℕ) :
    (finRotate (n + 1)).symm 0 = Fin.last n :=
  (finRotate (n + 1)).symm_apply_eq.mpr (finRotate_last (n := n)).symm

private lemma neighborInv_involutive {n M : ℕ} (x : DoorState n M) :
    neighborInv (neighborInv x) = x := by
  rcases x with ⟨v, σ, k⟩
  rcases fin_cases_three k with hk_mid | rfl | rfl
  · rw [neighborInv_mid v σ k hk_mid, neighborInv_mid _ _ k hk_mid]
    ext1
    · rfl
    · ext1
      · simp [mul_assoc]
      · rfl
  · by_cases hv0 : (v (σ 0)).val + 1 < M
    · rw [neighborInv_zero_pos v σ hv0]
      let v' : Fin (n + 1) → Fin M :=
        fun i => if i = σ 0 then ⟨(v (σ 0)).val + 1, hv0⟩ else v i
      let σ' : Equiv.Perm (Fin (n + 1)) := σ * finRotate (n + 1)
      have hσ_last : σ' (Fin.last n) = σ 0 := by
        change σ (finRotate (n + 1) (Fin.last n)) = σ 0
        rw [finRotate_last]
      have hpos : 0 < (v' (σ' (Fin.last n))).val := by
        rw [hσ_last]
        dsimp [v']
        rw [if_pos rfl]
        dsimp only
        omega
      change neighborInv (v', σ', Fin.last (n + 1)) = (v, σ, 0)
      rw [neighborInv_last_pos v' σ' hpos]
      ext1
      · funext i
        ext
        dsimp only
        by_cases hi : i = σ' (Fin.last n)
        · rw [if_pos hi]
          dsimp only
          rw [hσ_last] at hi ⊢
          subst hi
          dsimp [v']
          rw [if_pos rfl]
          dsimp only
          omega
        · rw [if_neg hi]
          have hi0 : i ≠ σ 0 := by rwa [hσ_last] at hi
          dsimp [v']
          rw [if_neg hi0]
      · ext1
        · ext j
          simp [σ', Equiv.Perm.mul_apply]
        · rfl
    · rw [neighborInv_zero_neg v σ hv0, neighborInv_zero_neg v σ hv0]
  · by_cases hvn : 0 < (v (σ (Fin.last n))).val
    · rw [neighborInv_last_pos v σ hvn]
      let v'' : Fin (n + 1) → Fin M :=
        fun i => if i = σ (Fin.last n) then ⟨(v (σ (Fin.last n))).val - 1, by omega⟩ else v i
      let σ'' : Equiv.Perm (Fin (n + 1)) := σ * (finRotate (n + 1)).symm
      have hσ_zero : σ'' 0 = σ (Fin.last n) := by
        change σ ((finRotate (n + 1)).symm 0) = σ (Fin.last n)
        rw [finRotate_symm_zero]
      have hltM : (v'' (σ'' 0)).val + 1 < M := by
        rw [hσ_zero]
        dsimp [v'']
        rw [if_pos rfl]
        dsimp only
        have := (v (σ (Fin.last n))).isLt
        omega
      change neighborInv (v'', σ'', 0) = (v, σ, Fin.last (n + 1))
      rw [neighborInv_zero_pos v'' σ'' hltM]
      ext1
      · funext i
        ext
        dsimp only
        by_cases hi : i = σ'' 0
        · rw [if_pos hi]
          dsimp only
          rw [hσ_zero] at hi ⊢
          subst hi
          dsimp [v'']
          rw [if_pos rfl]
          dsimp only
          omega
        · rw [if_neg hi]
          have hil : i ≠ σ (Fin.last n) := by rwa [hσ_zero] at hi
          dsimp [v'']
          rw [if_neg hil]
      · ext1
        · ext j
          simp [σ'', Equiv.Perm.mul_apply]
        · rfl
    · rw [neighborInv_last_neg v σ hvn, neighborInv_last_neg v σ hvn]

private lemma kuhnVertex_swap_eq {n M : ℕ} (v : Fin (n + 1) → Fin M)
    (σ : Equiv.Perm (Fin (n + 1))) (k : Fin (n + 2))
    (hk_mid : 0 < k.val ∧ k.val < n + 1)
    (j : Fin (n + 2)) (hj : j ≠ k) :
    kuhnVertex v (σ * Equiv.swap ⟨k.val - 1, by omega⟩ ⟨k.val, by omega⟩) j =
      kuhnVertex v σ j := by
  funext i
  dsimp [kuhnVertex]
  let a : Fin (n + 1) := ⟨k.val - 1, by omega⟩
  let b : Fin (n + 1) := ⟨k.val, by omega⟩
  have hsymm : (σ * Equiv.swap a b).symm i = Equiv.swap a b (σ.symm i) := by
    apply (σ * Equiv.swap a b).symm_apply_eq.mpr
    simp [Equiv.Perm.mul_apply]
  change (v i).val + (if ((σ * Equiv.swap a b).symm i).val < j.val then 1 else 0) = _
  rw [hsymm]
  have hj_val : j.val ≠ k.val := fun h => hj (Fin.ext h)
  by_cases hta : σ.symm i = a
  · rw [hta, Equiv.swap_apply_left]
    have ha : a.val = k.val - 1 := rfl
    have hb : b.val = k.val := rfl
    rw [ha, hb]
    split_ifs <;> omega
  · by_cases htb : σ.symm i = b
    · rw [htb, Equiv.swap_apply_right]
      have ha : a.val = k.val - 1 := rfl
      have hb : b.val = k.val := rfl
      rw [ha, hb]
      split_ifs <;> omega
    · rw [Equiv.swap_apply_of_ne_of_ne hta htb]

private lemma kuhnVertex_rotL_eq {n M : ℕ} (v : Fin (n + 1) → Fin M)
    (σ : Equiv.Perm (Fin (n + 1))) (hv0 : (v (σ 0)).val + 1 < M)
    (j : Fin (n + 1)) :
    let v' : Fin (n + 1) → Fin M :=
      fun i => if i = σ 0 then ⟨(v (σ 0)).val + 1, hv0⟩ else v i
    kuhnVertex v' (σ * finRotate (n + 1)) j.castSucc = kuhnVertex v σ j.succ := by
  intro v'
  funext i
  dsimp [kuhnVertex, v']
  have hsymm : (σ * finRotate (n + 1)).symm i = (finRotate (n + 1)).symm (σ.symm i) := by
    apply (σ * finRotate (n + 1)).symm_apply_eq.mpr
    simp [Equiv.Perm.mul_apply]
  rw [hsymm]
  by_cases hi : i = σ 0
  · subst hi
    rw [if_pos rfl, Equiv.symm_apply_apply, finRotate_symm_zero]
    simp only [Fin.val_last, Fin.val_zero]
    have hj_lt : j.val < n + 1 := j.isLt
    split_ifs <;> omega
  · have ht_ne : σ.symm i ≠ 0 := by
      intro h0
      exact hi (σ.symm_apply_eq.mp h0)
    have hrot_val : ((finRotate (n + 1)).symm (σ.symm i)).val = (σ.symm i).val - 1 :=
      coe_finRotate_symm_of_ne_zero ht_ne
    have ht_pos : 0 < (σ.symm i).val := Nat.pos_of_ne_zero (fun h => ht_ne (Fin.ext h))
    rw [if_neg hi, hrot_val]
    split_ifs <;> omega

private lemma neighborInv_preserves_door {n M : ℕ} (c : (Fin (n + 1) → ℕ) → Fin (n + 2))
    (x : DoorState n M)
    (hx : isDoorAt (fun j => c (kuhnVertex x.1 x.2.1 j)) x.2.2) :
    let y := neighborInv x
    isDoorAt (fun j => c (kuhnVertex y.1 y.2.1 j)) y.2.2 := by
  rcases x with ⟨v, σ, k⟩
  dsimp only at hx ⊢
  rcases fin_cases_three k with hk_mid | rfl | rfl
  · rw [neighborInv_mid v σ k hk_mid]
    dsimp only
    intro a
    obtain ⟨j, hj_ne, hj_eq⟩ := hx a
    dsimp only at hj_eq
    refine ⟨j, hj_ne, ?_⟩
    dsimp only
    rw [kuhnVertex_swap_eq v σ k hk_mid j hj_ne]
    exact hj_eq
  · by_cases hv0 : (v (σ 0)).val + 1 < M
    · rw [neighborInv_zero_pos v σ hv0]
      dsimp only
      intro a
      obtain ⟨r, hr_ne, hr_eq⟩ := hx a
      dsimp only at hr_eq
      rcases Fin.eq_zero_or_eq_succ r with rfl | ⟨j, rfl⟩
      · exact False.elim (hr_ne rfl)
      · refine ⟨j.castSucc, (Fin.castSucc_lt_last j).ne, ?_⟩
        dsimp only
        rw [kuhnVertex_rotL_eq v σ hv0 j]
        exact hr_eq
    · rw [neighborInv_zero_neg v σ hv0]
      exact hx
  · by_cases hvn : 0 < (v (σ (Fin.last n))).val
    · rw [neighborInv_last_pos v σ hvn]
      dsimp only
      let v'' : Fin (n + 1) → Fin M :=
        fun i => if i = σ (Fin.last n) then ⟨(v (σ (Fin.last n))).val - 1, by omega⟩ else v i
      let σ'' : Equiv.Perm (Fin (n + 1)) := σ * (finRotate (n + 1)).symm
      have hσ''0 : σ'' 0 = σ (Fin.last n) := by
        change σ ((finRotate (n + 1)).symm 0) = σ (Fin.last n)
        rw [finRotate_symm_zero]
      have hv''0 : (v'' (σ'' 0)).val + 1 < M := by
        rw [hσ''0]
        dsimp [v'']
        rw [if_pos rfl]
        dsimp only
        have := (v (σ (Fin.last n))).isLt
        omega
      have hv_rec : (fun i => if i = σ'' 0 then ⟨(v'' (σ'' 0)).val + 1, hv''0⟩ else v'' i) = v := by
        funext i
        ext
        dsimp only
        by_cases hi : i = σ'' 0
        · rw [if_pos hi]
          dsimp only
          rw [hσ''0] at hi ⊢
          subst hi
          dsimp [v'']
          rw [if_pos rfl]
          dsimp only
          omega
        · rw [if_neg hi]
          have hil : i ≠ σ (Fin.last n) := by rwa [hσ''0] at hi
          dsimp [v'']
          rw [if_neg hil]
      have hσ_rec : σ'' * finRotate (n + 1) = σ := by
        ext j
        simp [σ'', Equiv.Perm.mul_apply]
      intro a
      obtain ⟨r, hr_ne, hr_eq⟩ := hx a
      dsimp only at hr_eq
      let j : Fin (n + 1) := ⟨r.val, Fin.val_lt_last hr_ne⟩
      have hr_cast : r = j.castSucc := Fin.ext rfl
      rw [hr_cast] at hr_eq
      refine ⟨j.succ, Fin.succ_ne_zero j, ?_⟩
      dsimp only
      have hrot := kuhnVertex_rotL_eq v'' σ'' hv''0 j
      dsimp only at hrot
      rw [hv_rec, hσ_rec] at hrot
      rw [← hrot]
      exact hr_eq
    · rw [neighborInv_last_neg v σ hvn]
      exact hx

/-! ### Part 4: Fixed-point characterization & dimension reduction -/

private lemma fixed_door_structure {n M : ℕ}
    (c : (Fin (n + 1) → ℕ) → Fin (n + 2))
    (hc0 : ∀ (w : Fin (n + 1) → ℕ) (i : Fin (n + 1)), w i = 0 → c w ≤ i.castSucc)
    (hcM : ∀ (w : Fin (n + 1) → ℕ) (i : Fin (n + 1)), w i = M → c w ≠ i.castSucc)
    (x : DoorState n M)
    (hdoor : isDoorAt (fun j => c (kuhnVertex x.1 x.2.1 j)) x.2.2)
    (hfix : neighborInv x = x) :
    x.2.2 = Fin.last (n + 1) ∧
      (x.1 (Fin.last n)).val = 0 ∧
      x.2.1 (Fin.last n) = Fin.last n := by
  rcases x with ⟨v, σ, k⟩
  dsimp only at hdoor ⊢
  rcases fin_cases_three k with hk_mid | rfl | rfl
  · rw [neighborInv_mid v σ k hk_mid] at hfix
    have hσ_eq : σ * Equiv.swap ⟨k.val - 1, by omega⟩ ⟨k.val, by omega⟩ = σ :=
      (Prod.mk.inj (Prod.mk.inj hfix).2).1
    have hswap_one : (Equiv.swap ⟨k.val - 1, by omega⟩ ⟨k.val, by omega⟩ :
        Equiv.Perm (Fin (n + 1))) = 1 :=
      mul_left_cancel (hσ_eq.trans (mul_one σ).symm)
    have happ := Equiv.Perm.ext_iff.mp hswap_one ⟨k.val - 1, by omega⟩
    rw [Equiv.swap_apply_left, Equiv.Perm.one_apply] at happ
    have hval := congr_arg Fin.val happ
    dsimp only at hval
    omega
  · by_cases hv0 : (v (σ 0)).val + 1 < M
    · rw [neighborInv_zero_pos v σ hv0] at hfix
      have hk_eq : Fin.last (n + 1) = (0 : Fin (n + 2)) := (Prod.mk.inj (Prod.mk.inj hfix).2).2
      have hval := congr_arg Fin.val hk_eq
      simp at hval
    · have hv_max : (v (σ 0)).val + 1 = M := by
        have := (v (σ 0)).isLt
        omega
      obtain ⟨j, hj_ne, hj_col⟩ := hdoor (σ 0)
      dsimp only at hj_col
      have hj_pos : 0 < j.val := Nat.pos_of_ne_zero (fun h => hj_ne (Fin.ext h))
      have hw_M : kuhnVertex v σ j (σ 0) = M := by
        dsimp [kuhnVertex]
        rw [Equiv.symm_apply_apply, Fin.val_zero, if_pos hj_pos]
        exact hv_max
      exact False.elim (hcM _ (σ 0) hw_M hj_col)
  · by_cases hvn : 0 < (v (σ (Fin.last n))).val
    · rw [neighborInv_last_pos v σ hvn] at hfix
      have hk_eq : (0 : Fin (n + 2)) = Fin.last (n + 1) := (Prod.mk.inj (Prod.mk.inj hfix).2).2
      have hval := congr_arg Fin.val hk_eq
      simp at hval
    · have hv_zero : (v (σ (Fin.last n))).val = 0 := by omega
      have hσ_last : σ (Fin.last n) = Fin.last n := by
        by_contra hne
        let i : Fin (n + 1) := σ (Fin.last n)
        have hi_lt : i.val < n := Fin.val_lt_last hne
        obtain ⟨r, hr_ne, hr_col⟩ := hdoor (Fin.last n)
        dsimp only at hr_col
        have hr_lt : r.val < n + 1 := Fin.val_lt_last hr_ne
        have hw_0 : kuhnVertex v σ r i = 0 := by
          dsimp [kuhnVertex]
          have hsymm_i : σ.symm i = Fin.last n := σ.symm_apply_apply (Fin.last n)
          have hv_i : (v i).val = 0 := hv_zero
          rw [hv_i, hsymm_i, Fin.val_last]
          split_ifs <;> omega
        have hle : c (kuhnVertex v σ r) ≤ i.castSucc := hc0 _ i hw_0
        rw [hr_col, Fin.castSucc_le_castSucc_iff, Fin.le_def, Fin.val_last] at hle
        omega
      rw [hσ_last] at hv_zero
      exact ⟨rfl, hv_zero, hσ_last⟩

private def liftPermFun {n : ℕ} (f : Fin n → Fin n) (i : Fin (n + 1)) : Fin (n + 1) :=
  if h : i.val < n then (f ⟨i.val, h⟩).castSucc else Fin.last n

private def liftPerm {n : ℕ} (σ₀ : Equiv.Perm (Fin n)) : Equiv.Perm (Fin (n + 1)) where
  toFun := liftPermFun σ₀
  invFun := liftPermFun σ₀.symm
  left_inv i := by
    refine Fin.lastCases ?_ (fun i₀ => ?_) i
    · simp [liftPermFun]
    · simp [liftPermFun, i₀.isLt, (σ₀ i₀).isLt]
  right_inv i := by
    refine Fin.lastCases ?_ (fun i₀ => ?_) i
    · simp [liftPermFun]
    · simp [liftPermFun, i₀.isLt, (σ₀.symm i₀).isLt]

private lemma liftPerm_castSucc {n : ℕ} (σ₀ : Equiv.Perm (Fin n)) (i : Fin n) :
    liftPerm σ₀ i.castSucc = (σ₀ i).castSucc := by
  change liftPermFun σ₀ i.castSucc = (σ₀ i).castSucc
  simp [liftPermFun, i.isLt]

private lemma liftPerm_last {n : ℕ} (σ₀ : Equiv.Perm (Fin n)) :
    liftPerm σ₀ (Fin.last n) = Fin.last n := by
  change liftPermFun σ₀ (Fin.last n) = Fin.last n
  simp [liftPermFun]

private lemma liftPerm_symm {n : ℕ} (σ₀ : Equiv.Perm (Fin n)) :
    (liftPerm σ₀).symm = liftPerm σ₀.symm := rfl

private lemma kuhnVertex_lift {n M : ℕ} (hM : 0 < M)
    (v₀ : Fin n → Fin M) (σ₀ : Equiv.Perm (Fin n)) (j : Fin (n + 1)) :
    kuhnVertex (Fin.snoc v₀ (⟨0, hM⟩ : Fin M)) (liftPerm σ₀) j.castSucc =
      Fin.snoc (kuhnVertex v₀ σ₀ j) 0 := by
  funext i
  refine Fin.lastCases ?_ (fun i₀ => ?_) i
  · dsimp [kuhnVertex]
    rw [Fin.snoc_last, Fin.snoc_last, liftPerm_symm, liftPerm_last, Fin.val_last]
    have hj_lt : j.val < n + 1 := j.isLt
    have hnot : ¬ (n < j.val) := by omega
    rw [if_neg hnot]
  · dsimp [kuhnVertex]
    rw [Fin.snoc_castSucc, Fin.snoc_castSucc, liftPerm_symm, liftPerm_castSucc, Fin.val_castSucc]
    rfl

/-! ### Part 5: Main induction for odd count of panchromatic simplices -/

private theorem odd_card_panchromatic :
    ∀ (n M : ℕ), 0 < M →
      ∀ (c : (Fin n → ℕ) → Fin (n + 1)),
        (∀ (w : Fin n → ℕ) (i : Fin n), w i = 0 → c w ≤ i.castSucc) →
        (∀ (w : Fin n → ℕ) (i : Fin n), w i = M → c w ≠ i.castSucc) →
        ((Finset.univ : Finset ((Fin n → Fin M) × Equiv.Perm (Fin n))).filter
          (fun s => Function.Surjective (fun j : Fin (n + 1) => c (kuhnVertex s.1 s.2 j)))).card % 2 = 1 := by
  intro n
  induction n with
  | zero =>
    intro M _ c _ _
    have hsurj : ∀ s : (Fin 0 → Fin M) × Equiv.Perm (Fin 0),
        Function.Surjective (fun j : Fin (0 + 1) => c (kuhnVertex s.1 s.2 j)) := by
      intro s y
      exact ⟨0, Fin.ext (by omega)⟩
    have hfilt : (Finset.univ : Finset ((Fin 0 → Fin M) × Equiv.Perm (Fin 0))).filter
        (fun s => Function.Surjective (fun j : Fin (0 + 1) => c (kuhnVertex s.1 s.2 j))) =
        Finset.univ := Finset.filter_true_of_mem (fun s _ => hsurj s)
    rw [hfilt, Finset.card_univ]
    simp
  | succ n ih =>
    intro M hM c hc0 hcM
    let Simplex := (Fin (n + 1) → Fin M) × Equiv.Perm (Fin (n + 1))
    let Pan : Finset Simplex := Finset.univ.filter
      (fun s => Function.Surjective (fun j : Fin (n + 2) => c (kuhnVertex s.1 s.2 j)))
    let Doors : Finset (DoorState n M) := Finset.univ.filter
      (fun x => isDoorAt (fun j => c (kuhnVertex x.1 x.2.1 j)) x.2.2)
    -- Step A: Doors.card % 2 = Pan.card % 2 via fiberwise counting over Simplex
    have hdoors_eq_sum : Doors.card =
        ∑ s : Simplex, ((Finset.univ : Finset (Fin (n + 2))).filter
          (isDoorAt (fun j => c (kuhnVertex s.1 s.2 j)))).card := by
      have hfib := Finset.card_eq_sum_card_fiberwise
        (s := Doors) (t := (Finset.univ : Finset Simplex))
        (f := fun x : DoorState n M => (x.1, x.2.1))
        (fun x _ => Finset.mem_univ _)
      rw [hfib]
      refine Finset.sum_congr rfl fun s _ => ?_
      refine Finset.card_bij (fun (x : DoorState n M) _ => x.2.2) ?_ ?_ ?_
      · intro x hx
        rcases Finset.mem_filter.mp hx with ⟨hxD, hxs⟩
        have hxDoor := (Finset.mem_filter.mp hxD).2
        rcases x with ⟨v, σ, k⟩
        rcases Prod.mk.inj hxs with ⟨rfl, rfl⟩
        exact Finset.mem_filter.mpr ⟨Finset.mem_univ k, hxDoor⟩
      · intro x₁ hx₁ x₂ hx₂ hk_eq
        rcases Finset.mem_filter.mp hx₁ with ⟨_, hxs₁⟩
        rcases Finset.mem_filter.mp hx₂ with ⟨_, hxs₂⟩
        rcases x₁ with ⟨v₁, σ₁, k₁⟩
        rcases x₂ with ⟨v₂, σ₂, k₂⟩
        rcases Prod.mk.inj hxs₁ with ⟨rfl, rfl⟩
        rcases Prod.mk.inj hxs₂ with ⟨rfl, rfl⟩
        dsimp only at hk_eq
        rw [hk_eq]
      · intro k hk
        have hkDoor := (Finset.mem_filter.mp hk).2
        refine ⟨(s.1, s.2, k), Finset.mem_filter.mpr ⟨Finset.mem_filter.mpr ⟨Finset.mem_univ _, hkDoor⟩, rfl⟩, rfl⟩
    have hdoors_mod : Doors.card % 2 = Pan.card % 2 := by
      rw [hdoors_eq_sum, sum_mod_two]
      have hterm : (∑ s : Simplex, ((Finset.univ : Finset (Fin (n + 2))).filter
            (isDoorAt (fun j => c (kuhnVertex s.1 s.2 j)))).card % 2) =
          ∑ s : Simplex, if Function.Surjective (fun j : Fin (n + 2) => c (kuhnVertex s.1 s.2 j))
            then 1 else 0 := by
        refine Finset.sum_congr rfl fun s _ => ?_
        exact door_card_mod_two (fun j => c (kuhnVertex s.1 s.2 j))
      rw [hterm, ← Finset.card_filter]
    -- Step B: Doors.card % 2 = FixedDoors.card % 2 via neighborInv
    let FixedDoors : Finset (DoorState n M) := Doors.filter (fun x => neighborInv x = x)
    have hinv_mod : Doors.card % 2 = FixedDoors.card % 2 :=
      card_mod_two_eq_filter_fixed Doors neighborInv
        (fun x hx => Finset.mem_filter.mpr
          ⟨Finset.mem_univ _, neighborInv_preserves_door c x (Finset.mem_filter.mp hx).2⟩)
        (fun x _ => neighborInv_involutive x)
    -- Step C: Bijection between Pan₀ (dimension n) and FixedDoors
    have hc_snoc_lt : ∀ w₀ : Fin n → ℕ, (c (Fin.snoc w₀ 0)).val < n + 1 := by
      intro w₀
      have h0 : (Fin.snoc w₀ 0 : Fin (n + 1) → ℕ) (Fin.last n) = 0 := Fin.snoc_last _ _
      have hle := hc0 (Fin.snoc w₀ 0) (Fin.last n) h0
      exact Nat.lt_succ_of_le (Fin.le_def.mp hle)
    let c₀ : (Fin n → ℕ) → Fin (n + 1) := fun w₀ => ⟨(c (Fin.snoc w₀ 0)).val, hc_snoc_lt w₀⟩
    have hc₀_cast : ∀ w₀ : Fin n → ℕ, (c₀ w₀).castSucc = c (Fin.snoc w₀ 0) :=
      fun _ => Fin.ext rfl
    have hc₀_0 : ∀ (w₀ : Fin n → ℕ) (i : Fin n), w₀ i = 0 → c₀ w₀ ≤ i.castSucc := by
      intro w₀ i hw₀
      have hsnoc : (Fin.snoc w₀ 0 : Fin (n + 1) → ℕ) i.castSucc = 0 := by
        rw [Fin.snoc_castSucc, hw₀]
      have hle := hc0 (Fin.snoc w₀ 0) i.castSucc hsnoc
      rw [← hc₀_cast w₀, Fin.castSucc_le_castSucc_iff] at hle
      exact hle
    have hc₀_M : ∀ (w₀ : Fin n → ℕ) (i : Fin n), w₀ i = M → c₀ w₀ ≠ i.castSucc := by
      intro w₀ i hw₀ heq
      have hsnoc : (Fin.snoc w₀ 0 : Fin (n + 1) → ℕ) i.castSucc = M := by
        rw [Fin.snoc_castSucc, hw₀]
      have hne := hcM (Fin.snoc w₀ 0) i.castSucc hsnoc
      apply hne
      rw [← hc₀_cast w₀, heq]
    let Pan₀ : Finset ((Fin n → Fin M) × Equiv.Perm (Fin n)) := Finset.univ.filter
      (fun s₀ => Function.Surjective (fun j : Fin (n + 1) => c₀ (kuhnVertex s₀.1 s₀.2 j)))
    have hcard_bij : Pan₀.card = FixedDoors.card := by
      refine Finset.card_bij
        (fun (s₀ : (Fin n → Fin M) × Equiv.Perm (Fin n)) _ =>
          (Fin.snoc s₀.1 ⟨0, hM⟩, liftPerm s₀.2, Fin.last (n + 1)))
        ?_ ?_ ?_
      · -- Maps Pan₀ into FixedDoors
        intro s₀ hs₀
        have hsurj₀ : Function.Surjective (fun j : Fin (n + 1) => c₀ (kuhnVertex s₀.1 s₀.2 j)) :=
          (Finset.mem_filter.mp hs₀).2
        have hdoor_lift : isDoorAt
            (fun r => c (kuhnVertex (Fin.snoc s₀.1 ⟨0, hM⟩) (liftPerm s₀.2) r))
            (Fin.last (n + 1)) := by
          intro a
          obtain ⟨j, hj⟩ := hsurj₀ a
          dsimp only at hj
          refine ⟨j.castSucc, (Fin.castSucc_lt_last j).ne, ?_⟩
          dsimp only
          rw [kuhnVertex_lift hM s₀.1 s₀.2 j, ← hc₀_cast, hj]
        have hfix_lift : neighborInv (Fin.snoc s₀.1 ⟨0, hM⟩, liftPerm s₀.2, Fin.last (n + 1)) =
            (Fin.snoc s₀.1 ⟨0, hM⟩, liftPerm s₀.2, Fin.last (n + 1)) := by
          apply neighborInv_last_neg
          rw [liftPerm_last, Fin.snoc_last]
          simp
        exact Finset.mem_filter.mpr ⟨Finset.mem_filter.mpr ⟨Finset.mem_univ _, hdoor_lift⟩, hfix_lift⟩
      · -- Injective
        intro s₁ _ s₂ _ heq
        have hv_eq := (Prod.mk.inj heq).1
        have hσ_eq : liftPerm s₁.2 = liftPerm s₂.2 :=
          (Prod.mk.inj (Prod.mk.inj heq).2).1
        ext1
        · funext i
          have hi := congr_fun hv_eq i.castSucc
          simpa [Fin.snoc_castSucc] using hi
        · ext i
          have hi := Equiv.Perm.ext_iff.mp hσ_eq i.castSucc
          rw [liftPerm_castSucc, liftPerm_castSucc] at hi
          exact congr_arg Fin.val (Fin.castSucc_inj.mp hi)
      · -- Surjective onto FixedDoors
        intro x hx
        rcases Finset.mem_filter.mp hx with ⟨hxD, hfix⟩
        have hdoor := (Finset.mem_filter.mp hxD).2
        obtain ⟨hk_eq, hv_last, hσ_last⟩ := fixed_door_structure c hc0 hcM x hdoor hfix
        rcases x with ⟨v, σ, k⟩
        dsimp only at hk_eq hv_last hσ_last hdoor
        subst hk_eq
        let v₀ : Fin n → Fin M := fun i => v i.castSucc
        have hv_snoc : Fin.snoc v₀ (⟨0, hM⟩ : Fin M) = v := by
          funext i
          refine Fin.lastCases ?_ (fun i₀ => ?_) i
          · rw [Fin.snoc_last]
            exact Fin.ext hv_last.symm
          · simp [Fin.snoc_castSucc, v₀]
        have hσ_symm_last : σ.symm (Fin.last n) = Fin.last n :=
          σ.symm_apply_eq.mpr hσ_last.symm
        have hσ_lt : ∀ i : Fin n, (σ i.castSucc).val < n := by
          intro i
          apply Fin.val_lt_last
          intro heq
          have := σ.injective (heq.trans hσ_last.symm)
          exact (Fin.castSucc_lt_last i).ne this
        have hσ_symm_lt : ∀ i : Fin n, (σ.symm i.castSucc).val < n := by
          intro i
          apply Fin.val_lt_last
          intro heq
          have := σ.symm.injective (heq.trans hσ_symm_last.symm)
          exact (Fin.castSucc_lt_last i).ne this
        let σ₀ : Equiv.Perm (Fin n) :=
          { toFun := fun i => ⟨(σ i.castSucc).val, hσ_lt i⟩
            invFun := fun i => ⟨(σ.symm i.castSucc).val, hσ_symm_lt i⟩
            left_inv := fun i => by
              ext
              have hcast : (⟨(σ i.castSucc).val, hσ_lt i⟩ : Fin n).castSucc = σ i.castSucc :=
                Fin.ext rfl
              simp [hcast]
            right_inv := fun i => by
              ext
              have hcast : (⟨(σ.symm i.castSucc).val, hσ_symm_lt i⟩ : Fin n).castSucc =
                  σ.symm i.castSucc := Fin.ext rfl
              simp [hcast] }
        have hσ_lift : liftPerm σ₀ = σ := by
          ext i
          refine Fin.lastCases ?_ (fun i₀ => ?_) i
          · rw [liftPerm_last, hσ_last]
          · rw [liftPerm_castSucc]
            rfl
        have hsurj₀ : Function.Surjective (fun j : Fin (n + 1) => c₀ (kuhnVertex v₀ σ₀ j)) := by
          intro a
          obtain ⟨r, hr_ne, hr_col⟩ := hdoor a
          dsimp only at hr_col
          let j : Fin (n + 1) := ⟨r.val, Fin.val_lt_last hr_ne⟩
          have hr_cast : r = j.castSucc := Fin.ext rfl
          rw [hr_cast, ← hv_snoc, ← hσ_lift, kuhnVertex_lift hM v₀ σ₀ j, ← hc₀_cast] at hr_col
          exact ⟨j, Fin.castSucc_inj.mp hr_col⟩
        refine ⟨(v₀, σ₀), Finset.mem_filter.mpr ⟨Finset.mem_univ _, hsurj₀⟩, ?_⟩
        dsimp only
        rw [hv_snoc, hσ_lift]
    have hih := ih M hM c₀ hc₀_0 hc₀_M
    change Pan.card % 2 = 1
    have hih' : Pan₀.card % 2 = 1 := hih
    omega

/-- Kuhn's cubical Sperner lemma: for `M > 0` and any grid coloring satisfying the cubical
    boundary conditions, there exists a panchromatic Kuhn `n`-simplex. -/
theorem exists_panchromatic_kuhn (n M : ℕ) (hM : 0 < M)
    (c : (Fin n → ℕ) → Fin (n + 1))
    (hc0 : ∀ (w : Fin n → ℕ) (i : Fin n), w i = 0 → c w ≤ i.castSucc)
    (hcM : ∀ (w : Fin n → ℕ) (i : Fin n), w i = M → c w ≠ i.castSucc) :
    ∃ (v : Fin n → Fin M) (σ : Equiv.Perm (Fin n)),
      Function.Surjective (fun j : Fin (n + 1) => c (kuhnVertex v σ j)) := by
  have hodd := odd_card_panchromatic n M hM c hc0 hcM
  have hpos : 0 < ((Finset.univ : Finset ((Fin n → Fin M) × Equiv.Perm (Fin n))).filter
      (fun s => Function.Surjective (fun j : Fin (n + 1) => c (kuhnVertex s.1 s.2 j)))).card := by
    omega
  obtain ⟨⟨v, σ⟩, hmem⟩ := Finset.card_pos.mp hpos
  exact ⟨v, σ, (Finset.mem_filter.mp hmem).2⟩

end UL.Proof_cit_brouwer

import Mathlib
import UL.Def.def_2_1
import UL.Def.def_2_matching
import UL.Def.def_A_fit
import UL.Def.def_A_gap
import UL.Proof.lem_A_4.H1_SimplexFit
set_option autoImplicit false

namespace UL.Proof_thm_A_7

open MeasureTheory
open UL.Proof_lem_A_4

/-- Canonical joint-law sample space in universe `v` for `(X, Y) ∈ ℝ^d × Fin K`. -/
abbrev LawSpace.{v} (d K : ℕ) : Type v :=
  PUnit.{v + 1} × (EuclideanSpace ℝ (Fin d) × Fin K)

/-- Canonical map sending `ω : Ω` to `(unit, (X ω, Y ω))` in `LawSpace.{v} d K`. -/
def lawMap.{v, u} {Ω : Type u} {d K : ℕ}
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin K) (ω : Ω) : LawSpace.{v} d K :=
  (PUnit.unit, (X ω, Y ω))

/-- Pushforward joint law of `(X, Y)` on `LawSpace.{v} d K`. -/
noncomputable def lawMeas.{v, u} {Ω : Type u} [MeasurableSpace Ω] {d K : ℕ}
    (μ : Measure Ω) (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin K) :
    Measure (LawSpace.{v} d K) :=
  μ.map (lawMap.{v, u} X Y)

/-- First coordinate projection on `LawSpace.{v} d K`. -/
def lawX.{v} {d K : ℕ} (z : LawSpace.{v} d K) : EuclideanSpace ℝ (Fin d) :=
  z.2.1

/-- Label coordinate projection on `LawSpace.{v} d K`. -/
def lawY.{v} {d K : ℕ} (z : LawSpace.{v} d K) : Fin K :=
  z.2.2

@[simp]
lemma lawX_comp_lawMap.{v, u} {Ω : Type u} {d K : ℕ}
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin K) (ω : Ω) :
    lawX.{v} (lawMap.{v, u} X Y ω) = X ω :=
  rfl

@[simp]
lemma lawY_comp_lawMap.{v, u} {Ω : Type u} {d K : ℕ}
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin K) (ω : Ω) :
    lawY.{v} (lawMap.{v, u} X Y ω) = Y ω :=
  rfl

lemma measurable_lawMap.{v, u} {Ω : Type u} [MeasurableSpace Ω] {d K : ℕ}
    {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin K}
    (hX : Measurable X) (hY : Measurable Y) :
    Measurable (lawMap.{v, u} X Y) :=
  measurable_const.prodMk (hX.prodMk hY)

lemma measurable_lawX.{v} (d K : ℕ) : Measurable (@lawX.{v} d K) :=
  measurable_fst.comp measurable_snd

lemma measurable_lawY.{v} (d K : ℕ) : Measurable (@lawY.{v} d K) :=
  measurable_snd.comp measurable_snd

lemma isProbabilityMeasure_lawMeas.{v, u} {Ω : Type u} [MeasurableSpace Ω] {d K : ℕ}
    (μ : Measure Ω) [IsProbabilityMeasure μ]
    {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin K}
    (hX : Measurable X) (hY : Measurable Y) :
    IsProbabilityMeasure (lawMeas.{v, u} μ X Y) :=
  Measure.isProbabilityMeasure_map (measurable_lawMap.{v, u} hX hY).aemeasurable

lemma integrable_norm_lawX.{v, u} {Ω : Type u} [MeasurableSpace Ω] {d K : ℕ}
    {μ : Measure Ω} {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin K}
    (hX : Measurable X) (hY : Measurable Y)
    (hX_int : Integrable (fun ω => ‖X ω‖) μ) :
    Integrable (fun z : LawSpace.{v} d K => ‖lawX.{v} z‖) (lawMeas.{v, u} μ X Y) := by
  have hmeas : Measurable (fun z : LawSpace.{v} d K => ‖lawX.{v} z‖) :=
    (measurable_lawX.{v} d K).norm
  rw [lawMeas, integrable_map_measure hmeas.aestronglyMeasurable
    (measurable_lawMap.{v, u} hX hY).aemeasurable]
  exact hX_int

lemma integrable_lawX.{v, u} {Ω : Type u} [MeasurableSpace Ω] {d K : ℕ}
    {μ : Measure Ω} {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin K}
    (hX : Measurable X) (hY : Measurable Y)
    (hX_int : Integrable (fun ω => ‖X ω‖) μ) :
    Integrable (@lawX.{v} d K) (lawMeas.{v, u} μ X Y) :=
  (integrable_norm_iff (measurable_lawX.{v} d K).aestronglyMeasurable).mp
    (integrable_norm_lawX.{v, u} hX hY hX_int)

/-- `lsFitRisk` on `LawSpace.{v}` equals `lsFitRisk` on `Ω` for every `ρ ∈ LipschitzSimplexMaps K B`. -/
lemma lsFitRisk_lawMeas.{v, u} {Ω : Type u} [MeasurableSpace Ω] {d K : ℕ}
    {μ : Measure Ω} {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin K}
    (hX : Measurable X) (hY : Measurable Y)
    {B : ℝ} (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
    {ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hρ : ρ ∈ LipschitzSimplexMaps K B) :
    lsFitRisk (lawMeas.{v, u} μ X Y) (linearScore W (@lawX.{v} d K)) (@lawY.{v} d K) ρ =
      lsFitRisk μ (linearScore W X) Y ρ := by
  unfold lsFitRisk lawMeas
  have hg_meas : Measurable (fun z : LawSpace.{v} d K =>
      ‖ρ (linearScore W (@lawX.{v} d K) z) - oneHotLabel (@lawY.{v} d K) z‖ ^ 2) := by
    have h1 : Measurable (fun z : LawSpace.{v} d K => ρ (W (lawX.{v} z))) :=
      hρ.2.1.continuous.measurable.comp (W.continuous.measurable.comp (measurable_lawX.{v} d K))
    have h2 : Measurable (oneHotLabel (@lawY.{v} d K)) :=
      oneHotLabel_measurable (measurable_lawY.{v} d K)
    exact (h1.sub h2).norm.pow_const 2
  rw [integral_map (measurable_lawMap.{v, u} hX hY).aemeasurable hg_meas.aestronglyMeasurable]
  rfl

/-- `IsLipschitzLSFitProfile` transfers across any two `LawSpace` universes. -/
lemma isLipschitzLSFitProfile_lawMeas_iff.{v₁, v₂, u}
    {Ω : Type u} [MeasurableSpace Ω] {d K : ℕ}
    {μ : Measure Ω} {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin K}
    (hX : Measurable X) (hY : Measurable Y)
    {B : ℝ} (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
    (ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)) :
    IsLipschitzLSFitProfile (lawMeas.{v₁, u} μ X Y) B
        (linearScore W (@lawX.{v₁} d K)) (@lawY.{v₁} d K) ρ ↔
      IsLipschitzLSFitProfile (lawMeas.{v₂, u} μ X Y) B
        (linearScore W (@lawX.{v₂} d K)) (@lawY.{v₂} d K) ρ := by
  unfold IsLipschitzLSFitProfile IsMinOn IsMinFilter
  constructor
  · rintro ⟨hB, hρ, hmin⟩
    refine ⟨hB, hρ, ?_⟩
    rw [Filter.eventually_principal] at hmin ⊢
    intro ρ' hρ'
    rw [lsFitRisk_lawMeas.{v₂, u} hX hY W hρ, lsFitRisk_lawMeas.{v₂, u} hX hY W hρ']
    rw [← lsFitRisk_lawMeas.{v₁, u} hX hY W hρ, ← lsFitRisk_lawMeas.{v₁, u} hX hY W hρ']
    exact hmin ρ' hρ'
  · rintro ⟨hB, hρ, hmin⟩
    refine ⟨hB, hρ, ?_⟩
    rw [Filter.eventually_principal] at hmin ⊢
    intro ρ' hρ'
    rw [lsFitRisk_lawMeas.{v₁, u} hX hY W hρ, lsFitRisk_lawMeas.{v₁, u} hX hY W hρ']
    rw [← lsFitRisk_lawMeas.{v₂, u} hX hY W hρ, ← lsFitRisk_lawMeas.{v₂, u} hX hY W hρ']
    exact hmin ρ' hρ'

/-- Any two `B`-Lipschitz least-squares fits on a probability space agree almost everywhere. -/
lemma isLipschitzLSFit_ae_unique {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ]
    {K : ℕ} {B : ℝ} {S : Ω → ZeroSumSubspace K} {Y : Ω → Fin K}
    (hS : Measurable S) (hY : Measurable Y)
    {P₁ P₂ : Ω → EuclideanSpace ℝ (Fin K)}
    (hP₁ : IsLipschitzLSFit μ B S Y P₁) (hP₂ : IsLipschitzLSFit μ B S Y P₂) :
    P₁ =ᵐ[μ] P₂ := by
  rcases hP₁ with ⟨ρ₁, hProf₁, rfl⟩
  rcases hP₂ with ⟨ρ₂, hProf₂, rfl⟩
  have hvi₁ := fit_vi hS hY hProf₁ hProf₂.2.1
  have hvi₂ := fit_vi hS hY hProf₂ hProf₁.2.1
  let Q₁ : Ω → EuclideanSpace ℝ (Fin K) := fun ω => ρ₁ (S ω)
  let Q₂ : Ω → EuclideanSpace ℝ (Fin K) := fun ω => ρ₂ (S ω)
  have hQ₁_meas : Measurable Q₁ := hProf₁.2.1.2.1.continuous.measurable.comp hS
  have hQ₂_meas : Measurable Q₂ := hProf₂.2.1.2.1.continuous.measurable.comp hS
  have hZ_meas : Measurable (oneHotLabel Y) := oneHotLabel_measurable hY
  have hr₁_meas : Measurable (fitResidual Q₁ Y) := hQ₁_meas.sub hZ_meas
  have hr₂_meas : Measurable (fitResidual Q₂ Y) := hQ₂_meas.sub hZ_meas
  have hdiff_meas : Measurable (fun ω => Q₁ ω - Q₂ ω) := hQ₁_meas.sub hQ₂_meas
  have hdiff_bound : ∀ ω, ‖Q₁ ω - Q₂ ω‖ ≤ 2 := fun ω => by
    calc ‖Q₁ ω - Q₂ ω‖ ≤ ‖Q₁ ω‖ + ‖Q₂ ω‖ := norm_sub_le _ _
      _ ≤ 1 + 1 := add_le_add (simplex_norm_le_one (hProf₁.2.1.2.2 (S ω)))
          (simplex_norm_le_one (hProf₂.2.1.2.2 (S ω)))
      _ = 2 := by norm_num
  have hr₁_bound : ∀ ω, ‖fitResidual Q₁ Y ω‖ ≤ 2 :=
    fitResidual_norm_le_two Y (fun ω => hProf₁.2.1.2.2 (S ω))
  have hr₂_bound : ∀ ω, ‖fitResidual Q₂ Y ω‖ ≤ 2 :=
    fitResidual_norm_le_two Y (fun ω => hProf₂.2.1.2.2 (S ω))
  have hInt₁ : Integrable (fun ω => inner ℝ (fitResidual Q₁ Y ω) (Q₂ ω - Q₁ ω)) μ :=
    integrable_of_aestronglyMeasurable_bounded
      (hr₁_meas.inner (hQ₂_meas.sub hQ₁_meas)).aestronglyMeasurable 4 (fun ω => by
        rw [Real.norm_eq_abs]
        have h21 : ‖Q₂ ω - Q₁ ω‖ ≤ 2 := by rw [norm_sub_rev]; exact hdiff_bound ω
        calc |inner ℝ (fitResidual Q₁ Y ω) (Q₂ ω - Q₁ ω)|
            ≤ ‖fitResidual Q₁ Y ω‖ * ‖Q₂ ω - Q₁ ω‖ := abs_real_inner_le_norm _ _
          _ ≤ 2 * 2 := mul_le_mul (hr₁_bound ω) h21 (norm_nonneg _) (by norm_num)
          _ = 4 := by norm_num)
  have hInt₂ : Integrable (fun ω => inner ℝ (fitResidual Q₂ Y ω) (Q₁ ω - Q₂ ω)) μ :=
    integrable_of_aestronglyMeasurable_bounded
      (hr₂_meas.inner hdiff_meas).aestronglyMeasurable 4 (fun ω => by
        rw [Real.norm_eq_abs]
        calc |inner ℝ (fitResidual Q₂ Y ω) (Q₁ ω - Q₂ ω)|
            ≤ ‖fitResidual Q₂ Y ω‖ * ‖Q₁ ω - Q₂ ω‖ := abs_real_inner_le_norm _ _
          _ ≤ 2 * 2 := mul_le_mul (hr₂_bound ω) (hdiff_bound ω) (norm_nonneg _) (by norm_num)
          _ = 4 := by norm_num)
  have hInt_sq : Integrable (fun ω => ‖Q₁ ω - Q₂ ω‖ ^ 2) μ :=
    integrable_of_aestronglyMeasurable_bounded
      (hdiff_meas.norm.pow_const 2).aestronglyMeasurable 4 (fun ω => by
        rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
        have h := hdiff_bound ω; have h0 := norm_nonneg (Q₁ ω - Q₂ ω); nlinarith)
  have h_ptwise : ∀ ω,
      inner ℝ (fitResidual Q₁ Y ω) (Q₂ ω - Q₁ ω) +
        inner ℝ (fitResidual Q₂ Y ω) (Q₁ ω - Q₂ ω) = - ‖Q₁ ω - Q₂ ω‖ ^ 2 := by
    intro ω
    have h1 : inner ℝ (fitResidual Q₁ Y ω) (Q₂ ω - Q₁ ω) =
        -inner ℝ (fitResidual Q₁ Y ω) (Q₁ ω - Q₂ ω) := by
      have hneg : Q₂ ω - Q₁ ω = -(Q₁ ω - Q₂ ω) := by abel
      rw [hneg, inner_neg_right]
    have h2 : inner ℝ (fitResidual Q₂ Y ω) (Q₁ ω - Q₂ ω) -
        inner ℝ (fitResidual Q₁ Y ω) (Q₁ ω - Q₂ ω) = -‖Q₁ ω - Q₂ ω‖ ^ 2 := by
      rw [← inner_sub_left]
      have hsub : fitResidual Q₂ Y ω - fitResidual Q₁ Y ω = -(Q₁ ω - Q₂ ω) := by
        dsimp [fitResidual]
        abel
      rw [hsub, inner_neg_left, real_inner_self_eq_norm_sq]
    linarith
  have hsum_int : ∫ ω, (- ‖Q₁ ω - Q₂ ω‖ ^ 2) ∂μ =
      (∫ ω, inner ℝ (fitResidual Q₁ Y ω) (Q₂ ω - Q₁ ω) ∂μ) +
        (∫ ω, inner ℝ (fitResidual Q₂ Y ω) (Q₁ ω - Q₂ ω) ∂μ) := by
    rw [← integral_add hInt₁ hInt₂]
    refine integral_congr_ae (Filter.Eventually.of_forall fun ω => (h_ptwise ω).symm)
  rw [integral_neg] at hsum_int
  have h_le_zero : ∫ ω, ‖Q₁ ω - Q₂ ω‖ ^ 2 ∂μ ≤ 0 := by linarith
  have h_ge_zero : 0 ≤ ∫ ω, ‖Q₁ ω - Q₂ ω‖ ^ 2 ∂μ := integral_nonneg (fun ω => sq_nonneg _)
  have h_eq_zero : ∫ ω, ‖Q₁ ω - Q₂ ω‖ ^ 2 ∂μ = 0 := le_antisymm h_le_zero h_ge_zero
  have hae_zero : (fun ω => ‖Q₁ ω - Q₂ ω‖ ^ 2) =ᵐ[μ] 0 :=
    (integral_eq_zero_iff_of_nonneg (fun ω => sq_nonneg _) hInt_sq).mp h_eq_zero
  filter_upwards [hae_zero] with ω hω
  have hsq0 : ‖Q₁ ω - Q₂ ω‖ ^ 2 = 0 := hω
  have hn0 : ‖Q₁ ω - Q₂ ω‖ = 0 := sq_eq_zero_iff.mp hsq0
  exact sub_eq_zero.mp (norm_eq_zero.mp hn0)

/-- When `ρ` is an optimal `B`-Lipschitz profile at `(W, X, Y)`, `linearFittedPrediction` equals
`fun ω => ρ (W (X ω))` almost everywhere. -/
lemma linearFittedPrediction_ae_eq_of_profile {Ω : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ]
    {d K : ℕ} {B : ℝ} {W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K}
    {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin K}
    (hX : Measurable X) (hY : Measurable Y)
    {ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hProf : IsLipschitzLSFitProfile μ B (linearScore W X) Y ρ) :
    linearFittedPrediction μ B W X Y =ᵐ[μ] fun ω => ρ (W (X ω)) := by
  classical
  have hex : ∃ P, IsLipschitzLSFit μ B (linearScore W X) Y P :=
    ⟨fun ω => ρ (W (X ω)), ⟨ρ, hProf, rfl⟩⟩
  have hFit_sel : IsLipschitzLSFit μ B (linearScore W X) Y
      (linearFittedPrediction μ B W X Y) := by
    unfold linearFittedPrediction fittedPrediction
    rw [dif_pos hex]
    exact Classical.choose_spec hex
  exact isLipschitzLSFit_ae_unique (W.continuous.measurable.comp hX) hY
    hFit_sel ⟨ρ, hProf, rfl⟩

/-- Characterization of `extendedCanonicalLoss Φ p y ≠ ⊤` as `0 < p y`. -/
lemma extendedCanonicalLoss_ne_top_iff {K : ℕ} (Φ : Simplex K → ℝ)
    (p : EuclideanSpace ℝ (Fin K)) (y : Fin K) :
    extendedCanonicalLoss Φ p y ≠ ⊤ ↔ 0 < p y := by
  classical
  unfold extendedCanonicalLoss posSupport
  split_ifs with hy
  · simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hy
    exact ⟨fun _ => hy, fun _ => EReal.coe_ne_top _⟩
  · simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hy
    exact ⟨fun h => False.elim (h rfl), fun h => False.elim (hy h)⟩

/-- Measurability of `ω ↦ p (ω) (Y ω)` when `p` and `Y` are measurable. -/
lemma measurable_eval_fin {Ω : Type*} [MeasurableSpace Ω] {K : ℕ}
    {p : Ω → EuclideanSpace ℝ (Fin K)} {Y : Ω → Fin K}
    (hp : Measurable p) (hY : Measurable Y) :
    Measurable (fun ω => p ω (Y ω)) := by
  have heq : (fun ω => p ω (Y ω)) =
      fun ω => ∑ j : Fin K, (if Y ω = j then (1 : ℝ) else 0) * p ω j := by
    funext ω
    simp [Finset.sum_ite_eq]
  rw [heq]
  refine Finset.measurable_sum Finset.univ (fun j _ => ?_)
  have hind : Measurable (fun ω => if Y ω = j then (1 : ℝ) else 0) :=
    (measurable_of_countable (fun y : Fin K => if y = j then (1 : ℝ) else 0)).comp hY
  have hcoord : Measurable (fun ω => p ω j) :=
    (EuclideanSpace.proj j).continuous.measurable.comp hp
  exact hind.mul hcoord

end UL.Proof_thm_A_7

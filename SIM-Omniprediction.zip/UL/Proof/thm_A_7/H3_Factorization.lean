import Mathlib
import UL.Def.def_2_1
import UL.Def.def_A_fit
set_option autoImplicit false

namespace UL.Proof_thm_A_7

/-- When `K = 1`, every vector in `Simplex K` has its unique coordinate equal to `1`. -/
lemma simplex_apply_eq_one_of_eq_one {K : ℕ} (hK1 : K = 1)
    {q : EuclideanSpace ℝ (Fin K)} (hq : q ∈ Simplex K) (j : Fin K) :
    q j = 1 := by
  have huniv : (Finset.univ : Finset (Fin K)) = {j} := by
    ext i
    simp only [Finset.mem_univ, Finset.mem_singleton, true_iff]
    ext
    omega
  have hsum := hq.2
  rw [huniv, Finset.sum_singleton] at hsum
  exact hsum

/-- The dimension of `ZeroSumSubspace K = 1^⊥ ⊂ ℝ^K` is `K - 1` for `1 ≤ K`. -/
lemma finrank_zeroSumSubspace {K : ℕ} (hK : 1 ≤ K) :
    Module.finrank ℝ (ZeroSumSubspace K) = K - 1 := by
  let L : EuclideanSpace ℝ (Fin K) →ₗ[ℝ] ℝ := (innerSL ℝ (onesVec K)).toLinearMap
  have hker : ZeroSumSubspace K = LinearMap.ker L := rfl
  have h_rn := LinearMap.finrank_range_add_finrank_ker L
  rw [← hker, finrank_euclideanSpace_fin] at h_rn
  let i₀ : Fin K := ⟨0, by omega⟩
  let e₀ : EuclideanSpace ℝ (Fin K) := EuclideanSpace.single i₀ 1
  have hLe₀ : L e₀ = 1 := by
    change inner ℝ (onesVec K) (EuclideanSpace.single i₀ 1) = 1
    rw [PiLp.inner_apply]
    simp [onesVec, EuclideanSpace.single_apply]
  have hrange : LinearMap.range L = ⊤ := by
    rw [eq_top_iff]
    intro r _
    refine ⟨r • e₀, ?_⟩
    simp [map_smul, hLe₀]
  rw [hrange, finrank_top, Module.finrank_self] at h_rn
  omega

/-- Every score map `W : ℝ^d →L[ℝ] ZeroSumSubspace K` and `β`-Lipschitz simplex map `ρ`
factor through `K - 1` linear scores via a linear isometry `U : ℝ^{K-1} →ₗᵢ[ℝ] ZeroSumSubspace K`
preserving both Frobenius and operator norms. -/
lemma exists_score_factorization {d K : ℕ} (hK : 1 ≤ K) {β : ℝ}
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
    {ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hρ : ρ ∈ LipschitzSimplexMaps K β) :
    ∃ (U : EuclideanSpace ℝ (Fin (K - 1)) →ₗᵢ[ℝ] ZeroSumSubspace K)
      (A : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin (K - 1))),
      W = U.toContinuousLinearMap.comp A ∧
      Real.sqrt (∑ i : Fin d, ‖A (EuclideanSpace.single i 1)‖ ^ 2) =
        Real.sqrt (∑ i : Fin d, ‖W (EuclideanSpace.single i 1)‖ ^ 2) ∧
      ‖A‖ = ‖W‖ ∧
      LipschitzWith (Real.toNNReal β) (fun z => ρ (U z)) ∧
      (∀ z, ρ (U z) ∈ Simplex K) := by
  have h_rank : Module.finrank ℝ (ZeroSumSubspace K) = K - 1 := finrank_zeroSumSubspace hK
  let b : OrthonormalBasis (Fin (K - 1)) ℝ (ZeroSumSubspace K) :=
    (stdOrthonormalBasis ℝ (ZeroSumSubspace K)).reindex (finCongr h_rank)
  let U_equiv : EuclideanSpace ℝ (Fin (K - 1)) ≃ₗᵢ[ℝ] ZeroSumSubspace K := b.repr.symm
  let U : EuclideanSpace ℝ (Fin (K - 1)) →ₗᵢ[ℝ] ZeroSumSubspace K := U_equiv.toLinearIsometry
  let A : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin (K - 1)) :=
    U_equiv.symm.toLinearIsometry.toContinuousLinearMap.comp W
  have hWA : ∀ x : EuclideanSpace ℝ (Fin d), U (A x) = W x := fun x =>
    U_equiv.apply_symm_apply (W x)
  refine ⟨U, A, ?_, ?_, ?_, ?_, ?_⟩
  · exact ContinuousLinearMap.ext (fun x => (hWA x).symm)
  · congr 1
    refine Finset.sum_congr rfl (fun i _ => ?_)
    have hn : ‖A (EuclideanSpace.single i 1)‖ = ‖W (EuclideanSpace.single i 1)‖ :=
      U_equiv.symm.norm_map (W (EuclideanSpace.single i 1))
    rw [hn]
  · refine le_antisymm ?_ ?_
    · refine ContinuousLinearMap.opNorm_le_bound A (norm_nonneg W) (fun x => ?_)
      calc ‖A x‖ = ‖U_equiv.symm (W x)‖ := rfl
        _ = ‖W x‖ := U_equiv.symm.norm_map (W x)
        _ ≤ ‖W‖ * ‖x‖ := W.le_opNorm x
    · refine ContinuousLinearMap.opNorm_le_bound W (norm_nonneg A) (fun x => ?_)
      calc ‖W x‖ = ‖U (A x)‖ := by rw [hWA x]
        _ = ‖A x‖ := U.norm_map (A x)
        _ ≤ ‖A‖ * ‖x‖ := A.le_opNorm x
  · simpa [mul_one] using hρ.2.1.comp U.isometry.lipschitz
  · exact fun z => hρ.2.2 (U z)

end UL.Proof_thm_A_7

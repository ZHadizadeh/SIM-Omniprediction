import Mathlib
import UL.Stmt.cit_brouwer
import UL.Stmt.lem_A_2
import UL.Def.def_A_gap
import UL.Proof.thm_A_7.H1_Law
set_option autoImplicit false

namespace UL.Proof_thm_A_7

open MeasureTheory
open UL.Proof_lem_A_4

/-- Transport `S_cit_brouwer` (in an arbitrary universe `u₁`) to any `Type 0` finite-dimensional
real inner product space `E`. -/
lemma brouwer_type0_of_univ.{u₁} (h_brouwer : S_cit_brouwer.{u₁})
    (E : Type) [NormedAddCommGroup E] [InnerProductSpace ℝ E] [FiniteDimensional ℝ E]
    (C : Set E) (hCne : C.Nonempty) (hCcomp : IsCompact C) (hCconv : Convex ℝ C)
    (f : C → C) (hf : Continuous f) :
    ∃ x : C, f x = x := by
  let n : ℕ := Module.finrank ℝ E
  let E₁ : Type u₁ := EuclideanSpace ℝ (ULift.{u₁} (Fin n))
  let e_lin : EuclideanSpace ℝ (Fin n) ≃ₗ[ℝ] E₁ :=
    { toFun := fun x => (WithLp.equiv 2 (ULift.{u₁} (Fin n) → ℝ)).symm (fun k => x k.down)
      invFun := fun y => (WithLp.equiv 2 (Fin n → ℝ)).symm (fun i => y (ULift.up i))
      map_add' := fun x y => by ext k; rfl
      map_smul' := fun c x => by ext k; rfl
      left_inv := fun x => by ext i; rfl
      right_inv := fun y => by ext k; rfl }
  let ψ : E ≃L[ℝ] E₁ :=
    ((stdOrthonormalBasis ℝ E).repr.toLinearEquiv.trans e_lin).toContinuousLinearEquiv
  let C₁ : Set E₁ := ψ '' C
  have hC₁_ne : C₁.Nonempty := hCne.image ψ
  have hC₁_comp : IsCompact C₁ := hCcomp.image ψ.continuous
  have hC₁_conv : Convex ℝ C₁ := hCconv.linear_image ψ.toLinearEquiv.toLinearMap
  have h_mem_symm : ∀ y : C₁, ψ.symm y.1 ∈ C := by
    rintro ⟨_, x, hx, rfl⟩
    simpa using hx
  let toC₁ : C → C₁ := fun x => ⟨ψ x.1, ⟨x.1, x.2, rfl⟩⟩
  let ofC₁ : C₁ → C := fun y => ⟨ψ.symm y.1, h_mem_symm y⟩
  have h_toC₁_cont : Continuous toC₁ :=
    Continuous.subtype_mk (ψ.continuous.comp continuous_subtype_val) _
  have h_ofC₁_cont : Continuous ofC₁ :=
    Continuous.subtype_mk (ψ.symm.continuous.comp continuous_subtype_val) _
  let f₁ : C₁ → C₁ := fun y => toC₁ (f (ofC₁ y))
  have hf₁_cont : Continuous f₁ := h_toC₁_cont.comp (hf.comp h_ofC₁_cont)
  obtain ⟨y, hy_fix⟩ := h_brouwer E₁ C₁ hC₁_ne hC₁_comp hC₁_conv f₁ hf₁_cont
  refine ⟨ofC₁ y, ?_⟩
  apply Subtype.ext
  apply ψ.injective
  have hval : (f₁ y : E₁) = (y : E₁) := congrArg Subtype.val hy_fix
  simpa [f₁, toC₁, ofC₁] using hval

/-- Metric projection onto a nonempty compact convex set in a real inner product space is
continuous and satisfies the variational inequality `⟨u - π u, w - π u⟩ ≤ 0`. -/
lemma exists_metric_proj_vi
    (E : Type*) [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    (C : Set E) (hCne : C.Nonempty) (hCcomp : IsCompact C) (hCconv : Convex ℝ C) :
    ∃ π : E → C, Continuous π ∧
      ∀ (u w : E), w ∈ C → inner ℝ (u - (π u : E)) (w - (π u : E)) ≤ 0 := by
  have hex : ∀ u : E, ∃ v ∈ C, ‖u - v‖ = ⨅ w : C, ‖u - w‖ :=
    exists_norm_eq_iInf_of_complete_convex hCne hCcomp.isComplete hCconv
  let π : E → C := fun u => ⟨Classical.choose (hex u), (Classical.choose_spec (hex u)).1⟩
  have hπ_norm : ∀ u : E, ‖u - (π u : E)‖ = ⨅ w : C, ‖u - w‖ :=
    fun u => (Classical.choose_spec (hex u)).2
  have hπ_inner : ∀ (u w : E), w ∈ C → inner ℝ (u - (π u : E)) (w - (π u : E)) ≤ 0 := by
    intro u w hw
    exact (norm_eq_iInf_iff_real_inner_le_zero hCconv (π u).2).mp (hπ_norm u) w hw
  have hπ_lip : ∀ u₁ u₂ : E, dist (π u₁) (π u₂) ≤ dist u₁ u₂ := by
    intro u₁ u₂
    rw [Subtype.dist_eq, dist_eq_norm, dist_eq_norm]
    let v₁ : E := (π u₁).1
    let v₂ : E := (π u₂).1
    change ‖v₁ - v₂‖ ≤ ‖u₁ - u₂‖
    have h₁ : inner ℝ (u₁ - v₁) (v₂ - v₁) ≤ 0 := hπ_inner u₁ v₂ (π u₂).2
    have h₂ : inner ℝ (u₂ - v₂) (v₁ - v₂) ≤ 0 := hπ_inner u₂ v₁ (π u₁).2
    have h₁' : 0 ≤ inner ℝ (u₁ - v₁) (v₁ - v₂) := by
      have hneg : v₁ - v₂ = -(v₂ - v₁) := by abel
      rw [hneg, inner_neg_right]
      linarith
    have hdiff : 0 ≤ inner ℝ ((u₁ - u₂) - (v₁ - v₂)) (v₁ - v₂) := by
      have heq : (u₁ - u₂) - (v₁ - v₂) = (u₁ - v₁) - (u₂ - v₂) := by abel
      rw [heq, inner_sub_left]
      linarith
    rw [inner_sub_left, real_inner_self_eq_norm_sq] at hdiff
    have hcs : inner ℝ (u₁ - u₂) (v₁ - v₂) ≤ ‖u₁ - u₂‖ * ‖v₁ - v₂‖ := real_inner_le_norm _ _
    have hsq : ‖v₁ - v₂‖ ^ 2 ≤ ‖u₁ - u₂‖ * ‖v₁ - v₂‖ := by linarith
    by_cases h0 : ‖v₁ - v₂‖ = 0
    · rw [h0]
      exact norm_nonneg _
    · have hpos : 0 < ‖v₁ - v₂‖ := lt_of_le_of_ne (norm_nonneg _) (Ne.symm h0)
      nlinarith
  have hπ_cont : Continuous π :=
    Metric.continuous_iff.mpr fun u ε hε => ⟨ε, hε, fun y hy => lt_of_le_of_lt (hπ_lip y u) hy⟩
  exact ⟨π, hπ_cont, hπ_inner⟩

/-- Column-space Euclidean representation of `ℝ^d →L[ℝ] ZeroSumSubspace K` carrying the
Frobenius inner product. -/
abbrev Frob (d K : ℕ) : Type :=
  PiLp 2 (fun _ : Fin d => ZeroSumSubspace K)

lemma euclidean_eq_sum_single {d : ℕ} (x : EuclideanSpace ℝ (Fin d)) :
    ∑ i : Fin d, (x i) • EuclideanSpace.single i (1 : ℝ) = x := by
  ext j
  rw [sum_apply]
  simp [EuclideanSpace.single_apply]

/-- Continuous linear equivalence sending `W : ℝ^d →L[ℝ] ZeroSumSubspace K` to its column tuple
in `Frob d K`. -/
noncomputable def toFrob (d K : ℕ) :
    (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K) ≃L[ℝ] Frob d K :=
  LinearEquiv.toContinuousLinearEquiv
    { toFun := fun W =>
        (WithLp.equiv 2 (Fin d → ZeroSumSubspace K)).symm
          (fun i => W (EuclideanSpace.single i (1 : ℝ)))
      invFun := fun F =>
        ∑ i : Fin d, (EuclideanSpace.proj i).smulRight (F i)
      map_add' := fun W₁ W₂ => by ext i; rfl
      map_smul' := fun c W => by ext i; rfl
      left_inv := fun W => by
        refine ContinuousLinearMap.ext (fun x => ?_)
        have h : (∑ i : Fin d, (EuclideanSpace.proj i).smulRight
            (W (EuclideanSpace.single i (1 : ℝ)))) x =
            ∑ i : Fin d, (x i) • W (EuclideanSpace.single i (1 : ℝ)) := by
          simp [ContinuousLinearMap.sum_apply, ContinuousLinearMap.smulRight_apply]
        have hW : ∑ i : Fin d, (x i) • W (EuclideanSpace.single i (1 : ℝ)) = W x := by
          calc ∑ i : Fin d, (x i) • W (EuclideanSpace.single i (1 : ℝ))
              = ∑ i : Fin d, W ((x i) • EuclideanSpace.single i (1 : ℝ)) :=
                Finset.sum_congr rfl (fun i _ => (W.map_smul (x i) _).symm)
            _ = W (∑ i : Fin d, (x i) • EuclideanSpace.single i (1 : ℝ)) :=
                (map_sum W _ _).symm
            _ = W x := by rw [euclidean_eq_sum_single x]
        exact h.trans hW
      right_inv := fun F => by
        refine (WithLp.equiv 2 (Fin d → ZeroSumSubspace K)).injective (funext fun i => ?_)
        change (∑ j : Fin d, (EuclideanSpace.proj j).smulRight (F j))
            (EuclideanSpace.single i (1 : ℝ)) = F i
        have h : (∑ j : Fin d, (EuclideanSpace.proj j).smulRight (F j))
            (EuclideanSpace.single i (1 : ℝ)) =
            ∑ j : Fin d, ((EuclideanSpace.single i (1 : ℝ)) j) • (F j) := by
          simp [ContinuousLinearMap.sum_apply, ContinuousLinearMap.smulRight_apply]
        have hF : ∑ j : Fin d, ((EuclideanSpace.single i (1 : ℝ)) j) • (F j) = F i := by
          simp [EuclideanSpace.single_apply]
        exact h.trans hF }

/-- The Frobenius pairing of g(W) with W − V equals the expected residual pairing. -/
lemma frob_inner_step_eq_integral {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    {d K : ℕ} {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin K}
    {P : Ω → EuclideanSpace ℝ (Fin K)}
    (hInt_g : Integrable
      (fun z => (innerSL ℝ (X z)).smulRight (P z - oneHotLabel Y z)) μ)
    (hMem_g : ∀ x : EuclideanSpace ℝ (Fin d),
      (∫ z, (innerSL ℝ (X z)).smulRight (P z - oneHotLabel Y z) ∂μ) x ∈ ZeroSumSubspace K)
    (W V : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K) :
    let g_raw : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin K) :=
      ∫ z, (innerSL ℝ (X z)).smulRight (P z - oneHotLabel Y z) ∂μ
    let g : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K :=
      (ZeroSumSubspace K).orthogonalProjection.comp g_raw
    inner ℝ (toFrob d K g) (toFrob d K (W - V)) =
      ∫ z, inner ℝ (P z - oneHotLabel Y z)
        (((W - V) (X z)) : EuclideanSpace ℝ (Fin K)) ∂μ := by
  intro g_raw g
  let F : Ω → (EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin K)) :=
    fun z => (innerSL ℝ (X z)).smulRight (P z - oneHotLabel Y z)
  let e : Fin d → EuclideanSpace ℝ (Fin d) := fun i => EuclideanSpace.single i (1 : ℝ)
  have h_frob : inner ℝ (toFrob d K g) (toFrob d K (W - V)) =
      ∑ i : Fin d, inner ℝ (g_raw (e i)) (((W - V) (e i)) : EuclideanSpace ℝ (Fin K)) := by
    rw [PiLp.inner_apply]
    refine Finset.sum_congr rfl (fun i _ => ?_)
    have hg_coe : ((g (e i)) : EuclideanSpace ℝ (Fin K)) = g_raw (e i) := by
      change (((ZeroSumSubspace K).orthogonalProjection (g_raw (e i))) :
        EuclideanSpace ℝ (Fin K)) = g_raw (e i)
      exact congrArg Subtype.val
        (Submodule.orthogonalProjection_mem_subspace_eq_self ⟨g_raw (e i), hMem_g (e i)⟩)
    change inner ℝ ((g (e i)) : EuclideanSpace ℝ (Fin K))
      (((W - V) (e i)) : EuclideanSpace ℝ (Fin K)) = _
    rw [hg_coe]
  rw [h_frob]
  have h_term_int : ∀ i : Fin d,
      Integrable (fun z => inner ℝ (F z (e i)) (((W - V) (e i)) : EuclideanSpace ℝ (Fin K))) μ ∧
      inner ℝ (g_raw (e i)) (((W - V) (e i)) : EuclideanSpace ℝ (Fin K)) =
        ∫ z, inner ℝ (F z (e i)) (((W - V) (e i)) : EuclideanSpace ℝ (Fin K)) ∂μ := by
    intro i
    let ev_i : (EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin K)) →L[ℝ]
        EuclideanSpace ℝ (Fin K) :=
      ContinuousLinearMap.apply ℝ (EuclideanSpace ℝ (Fin K)) (e i)
    let w_i : EuclideanSpace ℝ (Fin K) := ((W - V) (e i))
    have hInt_evi : Integrable (fun z => F z (e i)) μ := ev_i.integrable_comp hInt_g
    have hg_evi : g_raw (e i) = ∫ z, F z (e i) ∂μ := (ev_i.integral_comp_comm hInt_g).symm
    have hInt_inn : Integrable (fun z => inner ℝ w_i (F z (e i))) μ :=
      (innerSL ℝ w_i).integrable_comp hInt_evi
    have h_inn_eq : inner ℝ w_i (g_raw (e i)) = ∫ z, inner ℝ w_i (F z (e i)) ∂μ := by
      rw [hg_evi]
      exact ((innerSL ℝ w_i).integral_comp_comm hInt_evi).symm
    have h_comm : (fun z => inner ℝ (F z (e i)) w_i) = (fun z => inner ℝ w_i (F z (e i))) := by
      funext z
      exact real_inner_comm w_i (F z (e i))
    refine ⟨h_comm ▸ hInt_inn, ?_⟩
    rw [real_inner_comm w_i (g_raw (e i)), h_inn_eq, h_comm]
  have h_sum_eq : ∑ i : Fin d, inner ℝ (g_raw (e i)) (((W - V) (e i)) : EuclideanSpace ℝ (Fin K)) =
      ∫ z, (∑ i : Fin d, inner ℝ (F z (e i)) (((W - V) (e i)) : EuclideanSpace ℝ (Fin K))) ∂μ := by
    calc ∑ i : Fin d, inner ℝ (g_raw (e i)) (((W - V) (e i)) : EuclideanSpace ℝ (Fin K))
        = ∑ i : Fin d, ∫ z, inner ℝ (F z (e i))
            (((W - V) (e i)) : EuclideanSpace ℝ (Fin K)) ∂μ :=
          Finset.sum_congr rfl (fun i _ => (h_term_int i).2)
      _ = ∫ z, (∑ i : Fin d, inner ℝ (F z (e i))
            (((W - V) (e i)) : EuclideanSpace ℝ (Fin K))) ∂μ :=
          (integral_finset_sum Finset.univ (fun i _ => (h_term_int i).1)).symm
  rw [h_sum_eq]
  refine integral_congr_ae (Filter.Eventually.of_forall fun z => ?_)
  have h_pt : ∑ i : Fin d, inner ℝ (F z (e i)) (((W - V) (e i)) : EuclideanSpace ℝ (Fin K)) =
      inner ℝ (P z - oneHotLabel Y z) (((W - V) (X z)) : EuclideanSpace ℝ (Fin K)) := by
    have hstep : ∀ i : Fin d,
        inner ℝ (F z (e i)) (((W - V) (e i)) : EuclideanSpace ℝ (Fin K)) =
          inner ℝ (P z - oneHotLabel Y z)
            ((X z i) • (((W - V) (e i)) : EuclideanSpace ℝ (Fin K))) := by
      intro i
      have hFe : F z (e i) = (X z i) • (P z - oneHotLabel Y z) := by
        dsimp [F, e]
        congr 1
        rw [PiLp.inner_apply]
        simp [EuclideanSpace.single_apply]
      rw [hFe, real_inner_smul_left, real_inner_smul_right]
    calc ∑ i : Fin d, inner ℝ (F z (e i)) (((W - V) (e i)) : EuclideanSpace ℝ (Fin K))
        = ∑ i : Fin d, inner ℝ (P z - oneHotLabel Y z)
            ((X z i) • (((W - V) (e i)) : EuclideanSpace ℝ (Fin K))) :=
          Finset.sum_congr rfl (fun i _ => hstep i)
      _ = inner ℝ (P z - oneHotLabel Y z)
            (∑ i : Fin d, (X z i) • (((W - V) (e i)) : EuclideanSpace ℝ (Fin K))) :=
          (inner_sum Finset.univ _ _).symm
      _ = inner ℝ (P z - oneHotLabel Y z) (((W - V) (X z)) : EuclideanSpace ℝ (Fin K)) := by
          congr 1
          let L_VW : EuclideanSpace ℝ (Fin d) →ₗ[ℝ] EuclideanSpace ℝ (Fin K) :=
            (ZeroSumSubspace K).subtype.comp (W - V).toLinearMap
          have hL : ∑ i : Fin d, (X z i) • (((W - V) (e i)) : EuclideanSpace ℝ (Fin K)) =
              L_VW (∑ i : Fin d, (X z i) • e i) := by
            rw [map_sum]
            refine Finset.sum_congr rfl (fun i _ => ?_)
            rw [map_smul]
            rfl
          rw [hL, euclidean_eq_sum_single (X z)]
          rfl
  exact h_pt

/-- Existence of a fixed-point matrix `W ∈ 𝒲` and optimal `β`-Lipschitz profile `ρ` such that
the certificate gap integrands are nonpositive for all `V ∈ 𝒲`. -/
lemma exists_fixedPoint_and_profile.{u₁, u₂, u}
    (h_brouwer : S_cit_brouwer.{u₁}) (h_lem_A_2 : S_lem_A_2.{u₂})
    {Ω : Type u} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    {d K : ℕ} {β : ℝ} (hβ : 0 < β)
    {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin K}
    (hX : Measurable X) (hY : Measurable Y)
    (hX_int : Integrable (fun ω => ‖X ω‖) μ)
    {𝒲 : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)}
    (h𝒲 : IsCompactConvexScoreSet 𝒲) :
    ∃ W ∈ 𝒲, ∃ ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K),
      IsLipschitzLSFitProfile (lawMeas.{u₂, u} μ X Y) β
        (linearScore W (@lawX.{u₂} d K)) (@lawY.{u₂} d K) ρ ∧
      ∀ V ∈ 𝒲,
        ∫ ω, inner ℝ (ρ (W (X ω)) - oneHotLabel Y ω)
          (((W - V) (X ω)) : EuclideanSpace ℝ (Fin K)) ∂μ ≤ 0 := by
  classical
  let μ₂ : Measure (LawSpace.{u₂} d K) := lawMeas.{u₂, u} μ X Y
  haveI : IsProbabilityMeasure μ₂ := isProbabilityMeasure_lawMeas.{u₂, u} μ hX hY
  have hX₂_meas : Measurable (@lawX.{u₂} d K) := measurable_lawX.{u₂} d K
  have hY₂_meas : Measurable (@lawY.{u₂} d K) := measurable_lawY.{u₂} d K
  have hX₂_int : Integrable (@lawX.{u₂} d K) μ₂ := integrable_lawX.{u₂, u} hX hY hX_int
  obtain ⟨hFit_ex_uniq, _, hStep⟩ :=
    h_lem_A_2 (LawSpace.{u₂} d K) μ₂ d K β hβ (@lawX.{u₂} d K) (@lawY.{u₂} d K) hX₂_meas hY₂_meas
  obtain ⟨hInt_g, hMem_g, hCont_g_raw⟩ := hStep hX₂_int
  let g_raw : (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K) →
      (EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin K)) :=
    fun W => ∫ z, (innerSL ℝ (lawX.{u₂} z)).smulRight
      (linearFittedPrediction μ₂ β W (@lawX.{u₂} d K) (@lawY.{u₂} d K) z -
        oneHotLabel (@lawY.{u₂} d K) z) ∂μ₂
  let projH : EuclideanSpace ℝ (Fin K) →L[ℝ] ZeroSumSubspace K :=
    (ZeroSumSubspace K).orthogonalProjection
  let g : (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K) →
      (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K) :=
    fun W => projH.comp (g_raw W)
  have hCont_g : Continuous g :=
    (ContinuousLinearMap.compL ℝ (EuclideanSpace ℝ (Fin d))
      (EuclideanSpace ℝ (Fin K)) (ZeroSumSubspace K) projH).continuous.comp hCont_g_raw
  let φ := toFrob d K
  let C₀ : Set (Frob d K) := φ '' 𝒲
  have hC₀_ne : C₀.Nonempty := h𝒲.1.image φ
  have hC₀_comp : IsCompact C₀ := h𝒲.2.1.image φ.continuous
  have hC₀_conv : Convex ℝ C₀ := h𝒲.2.2.linear_image φ.toLinearEquiv.toLinearMap
  obtain ⟨π, hπ_cont, hπ_vi⟩ := exists_metric_proj_vi (Frob d K) C₀ hC₀_ne hC₀_comp hC₀_conv
  let T : C₀ → C₀ := fun x => π ((x : Frob d K) - φ (g (φ.symm (x : Frob d K))))
  have hT_cont : Continuous T :=
    hπ_cont.comp (continuous_subtype_val.sub
      (φ.continuous.comp (hCont_g.comp (φ.symm.continuous.comp continuous_subtype_val))))
  obtain ⟨x_star, hx_fix⟩ :=
    brouwer_type0_of_univ.{u₁} h_brouwer (Frob d K) C₀ hC₀_ne hC₀_comp hC₀_conv T hT_cont
  rcases x_star.2 with ⟨W, hW_mem, hφW⟩
  have hπ_eq : (π (φ W - φ (g W)) : Frob d K) = φ W := by
    have hval : (T x_star : Frob d K) = (x_star : Frob d K) := congrArg Subtype.val hx_fix
    dsimp [T] at hval
    rw [← hφW, φ.symm_apply_apply] at hval
    exact hval
  have hex_fit : ∃ P, IsLipschitzLSFit μ₂ β (linearScore W (@lawX.{u₂} d K)) (@lawY.{u₂} d K) P :=
    (hFit_ex_uniq W).1
  have hP₂_fit : IsLipschitzLSFit μ₂ β (linearScore W (@lawX.{u₂} d K)) (@lawY.{u₂} d K)
      (linearFittedPrediction μ₂ β W (@lawX.{u₂} d K) (@lawY.{u₂} d K)) := by
    unfold linearFittedPrediction fittedPrediction
    rw [dif_pos hex_fit]
    exact Classical.choose_spec hex_fit
  rcases hP₂_fit with ⟨ρ, hρ_prof, hP₂_eq⟩
  refine ⟨W, hW_mem, ρ, hρ_prof, fun V hV => ?_⟩
  have hvi : inner ℝ (φ (g W)) (φ (W - V)) ≤ 0 := by
    have h := hπ_vi (φ W - φ (g W)) (φ V) ⟨V, hV, rfl⟩
    rw [hπ_eq] at h
    have hstep : (φ W - φ (g W)) - φ W = -φ (g W) := by abel
    have hdir : φ V - φ W = -φ (W - V) := by rw [φ.map_sub W V]; abel
    simpa only [hstep, hdir, inner_neg_left, inner_neg_right, neg_neg] using h
  have h_trace := frob_inner_step_eq_integral (hInt_g W) (hMem_g W) W V
  change inner ℝ (φ (g W)) (φ (W - V)) = _ at h_trace
  rw [h_trace, hP₂_eq] at hvi
  have hg_meas : Measurable (fun z : LawSpace.{u₂} d K =>
      inner ℝ (ρ (W (lawX.{u₂} z)) - oneHotLabel (@lawY.{u₂} d K) z)
        (((W - V) (lawX.{u₂} z)) : EuclideanSpace ℝ (Fin K))) := by
    have h1 : Measurable (fun z : LawSpace.{u₂} d K =>
        ρ (W (lawX.{u₂} z)) - oneHotLabel (@lawY.{u₂} d K) z) :=
      (hρ_prof.2.1.2.1.continuous.measurable.comp (W.continuous.measurable.comp hX₂_meas)).sub
        (oneHotLabel_measurable hY₂_meas)
    have h2 : Measurable (fun z : LawSpace.{u₂} d K =>
        (((W - V) (lawX.{u₂} z)) : EuclideanSpace ℝ (Fin K))) :=
      continuous_subtype_val.measurable.comp ((W - V).continuous.measurable.comp hX₂_meas)
    exact h1.inner h2
  have hmap_eq : ∫ z, inner ℝ (ρ (W (lawX.{u₂} z)) - oneHotLabel (@lawY.{u₂} d K) z)
        (((W - V) (lawX.{u₂} z)) : EuclideanSpace ℝ (Fin K)) ∂μ₂ =
      ∫ ω, inner ℝ (ρ (W (X ω)) - oneHotLabel Y ω)
        (((W - V) (X ω)) : EuclideanSpace ℝ (Fin K)) ∂μ := by
    change ∫ z, _ ∂(μ.map (lawMap.{u₂, u} X Y)) = _
    rw [integral_map (measurable_lawMap.{u₂, u} hX hY).aemeasurable hg_meas.aestronglyMeasurable]
    rfl
  rw [← hmap_eq]
  exact hvi

/-- On `LawSpace.{v}`, if `ρ` is an optimal `B`-Lipschitz profile at `W ∈ 𝒲` and all comparator
inner-product expectations on `(Ω, μ)` are `≤ 0`, then `certificateGap` on `LawSpace.{v}` is `0`. -/
lemma certificateGap_lawMeas_eq_zero.{v, u}
    {Ω : Type u} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {d K : ℕ} {B : ℝ}
    {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin K}
    (hX : Measurable X) (hY : Measurable Y)
    {𝒲 : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)}
    {W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K} (hW : W ∈ 𝒲)
    {ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hProf_v : IsLipschitzLSFitProfile (lawMeas.{v, u} μ X Y) B
      (linearScore W (@lawX.{v} d K)) (@lawY.{v} d K) ρ)
    (hle : ∀ V ∈ 𝒲,
      ∫ ω, inner ℝ (ρ (W (X ω)) - oneHotLabel Y ω)
        (((W - V) (X ω)) : EuclideanSpace ℝ (Fin K)) ∂μ ≤ 0) :
    certificateGap (lawMeas.{v, u} μ X Y) B 𝒲 (@lawX.{v} d K) (@lawY.{v} d K) W = 0 := by
  let μ_v := lawMeas.{v, u} μ X Y
  haveI : IsProbabilityMeasure μ_v := isProbabilityMeasure_lawMeas.{v, u} μ hX hY
  have hX_v : Measurable (@lawX.{v} d K) := measurable_lawX.{v} d K
  have hY_v : Measurable (@lawY.{v} d K) := measurable_lawY.{v} d K
  have hae : linearFittedPrediction μ_v B W (@lawX.{v} d K) (@lawY.{v} d K) =ᵐ[μ_v]
      fun z => ρ (W (lawX.{v} z)) :=
    linearFittedPrediction_ae_eq_of_profile hX_v hY_v hProf_v
  let g : (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K) → ℝ :=
    fun V => ∫ z, inner ℝ
      (linearFittedPrediction μ_v B W (@lawX.{v} d K) (@lawY.{v} d K) z -
        oneHotLabel (@lawY.{v} d K) z)
      (((W - V) (lawX.{v} z)) : EuclideanSpace ℝ (Fin K)) ∂μ_v
  have hg_eq : ∀ V : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K,
      g V = ∫ ω, inner ℝ (ρ (W (X ω)) - oneHotLabel Y ω)
        (((W - V) (X ω)) : EuclideanSpace ℝ (Fin K)) ∂μ := by
    intro V
    have hcongr : g V = ∫ z, inner ℝ (ρ (W (lawX.{v} z)) - oneHotLabel (@lawY.{v} d K) z)
        (((W - V) (lawX.{v} z)) : EuclideanSpace ℝ (Fin K)) ∂μ_v := by
      refine integral_congr_ae ?_
      filter_upwards [hae] with z hz
      rw [hz]
    rw [hcongr]
    have hg_meas : Measurable (fun z : LawSpace.{v} d K =>
        inner ℝ (ρ (W (lawX.{v} z)) - oneHotLabel (@lawY.{v} d K) z)
          (((W - V) (lawX.{v} z)) : EuclideanSpace ℝ (Fin K))) := by
      have h1 : Measurable (fun z : LawSpace.{v} d K =>
          ρ (W (lawX.{v} z)) - oneHotLabel (@lawY.{v} d K) z) :=
        (hProf_v.2.1.2.1.continuous.measurable.comp (W.continuous.measurable.comp hX_v)).sub
          (oneHotLabel_measurable hY_v)
      have h2 : Measurable (fun z : LawSpace.{v} d K =>
          (((W - V) (lawX.{v} z)) : EuclideanSpace ℝ (Fin K))) :=
        continuous_subtype_val.measurable.comp ((W - V).continuous.measurable.comp hX_v)
      exact h1.inner h2
    change ∫ z, _ ∂(μ.map (lawMap.{v, u} X Y)) = _
    rw [integral_map (measurable_lawMap.{v, u} hX hY).aemeasurable hg_meas.aestronglyMeasurable]
    rfl
  have hgW : g W = 0 := by
    rw [hg_eq W]
    simp [sub_self]
  have hg_le : ∀ V ∈ 𝒲, g V ≤ 0 := by
    intro V hV
    rw [hg_eq V]
    exact hle V hV
  unfold certificateGap predictionCertificateGap
  change sSup (g '' 𝒲) = 0
  have hne : (g '' 𝒲).Nonempty := ⟨g W, ⟨W, hW, rfl⟩⟩
  have hbdd : BddAbove (g '' 𝒲) := ⟨0, by rintro _ ⟨V, hV, rfl⟩; exact hg_le V hV⟩
  refine le_antisymm ?_ ?_
  · exact csSup_le hne (by rintro _ ⟨V, hV, rfl⟩; exact hg_le V hV)
  · rw [← hgW]
    exact le_csSup hbdd ⟨W, hW, rfl⟩

end UL.Proof_thm_A_7

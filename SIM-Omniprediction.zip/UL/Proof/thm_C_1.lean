import UL.Stmt.thm_C_1
import UL.Stmt.lem_C_2
import UL.Stmt.lem_C_3
import UL.Stmt.lem_C_4
import UL.Proof.thm_C_1.Race3.H1_UniverseTransfer
import UL.Proof.thm_C_1.Race3.H2_EmpiricalAndClass
import UL.Proof.thm_C_1.Race3.H3_SampleBound
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_thm_C_1 (h_lem_C_2 : S_lem_C_2) (h_lem_C_3 : S_lem_C_3) (h_lem_C_4 : S_lem_C_4) : S_thm_C_1 := by
  unfold S_thm_C_1
  intro K hK
  obtain ⟨C₃, hC₃_pos, h_unif⟩ := Proof_thm_C_1_Race3.lem_C_3_transfer h_lem_C_3 K hK
  refine ⟨Proof_thm_C_1_Race3.sampleConstCK K C₃,
    Proof_thm_C_1_Race3.sampleConstCK_pos K C₃, ?_⟩
  intro X _instNACG _instIPS _instCS _instSep _instMS _instBS
    L R β lam M B hL hR hβ hlam hM hB
  dsimp only
  intro ε δ hε0 hεD hδ0 hδ1 n hn hn_ge
  obtain ⟨learnerW, learnerRho, h_feas, h_emp⟩ :=
    Proof_thm_C_1_Race3.exists_empirical_learner_univ h_lem_C_2 h_lem_C_4 hK X hn
      hL hR hβ hB hlam hM
  refine ⟨learnerW, learnerRho, h_feas, ?_⟩
  intro ν _instProbν hX_bound Ω _instMSΩ μ _instProbμ X_samp Y_samp hX_meas hY_meas hindep hident
  by_cases h_smooth_ne : (SmoothEntropyFamily K β lam M).Nonempty
  · have hB_pos : 0 < B := lt_of_lt_of_le hβ hB
    let A₀ : ℝ := L * R
    have hA₀_pos : 0 < A₀ := mul_pos hL hR
    let C : ℝ := 3 * B * lam
    let M₀ : ℝ := 3 * (M + A₀)
    have hC_pos : 0 < C := by dsimp [C]; positivity
    have hM₀_pos : 0 < M₀ := by dsimp [M₀]; positivity
    have hδ_lt_one : δ < 1 := by linarith
    obtain ⟨E, hE_meas, hE_prob, hE_good⟩ :=
      h_unif X L R C M₀ hL hR hC_pos hM₀_pos n hn δ hδ0 hδ_lt_one
        ν hX_bound Ω μ X_samp Y_samp hX_meas hY_meas hindep hident
    have h2bound_le :
        2 *
          (if K - 1 ≤ 2 then
            C₃ * ((M₀ + C * A₀) * Real.log (2 * (n : ℝ)) + M₀ * Real.sqrt (Real.log (2 / δ))) /
              Real.sqrt (n : ℝ)
          else
            C₃ * (M₀ + C * A₀) * ((n : ℝ) ^ (-(1 : ℝ) / ((K - 1 : ℕ) : ℝ))) +
              C₃ * M₀ * Real.sqrt (Real.log (2 / δ) / (n : ℝ))) ≤ ε :=
      Proof_thm_C_1_Race3.sample_bound_implies_two_bound_le K hK C₃ hC₃_pos M A₀ B lam ε δ
        hM hA₀_pos hB_pos hlam hε0 hεD hδ0 hδ1 n hn hn_ge
    refine ⟨E, hE_meas, hE_prob, ?_⟩
    intro ω hω Φ hΦ
    obtain ⟨hx_norm, h_sup⟩ := hE_good ω hω
    let sample : Fin n → X × Fin K := fun i => (X_samp i ω, Y_samp i ω)
    let W : X →L[ℝ] ZeroSumSubspace K := learnerW sample
    let ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) := learnerRho sample
    obtain ⟨hW_norm, hρ_simp, hρ_lip⟩ := h_feas sample
    set bound : ℝ :=
      if K - 1 ≤ 2 then
        C₃ * ((M₀ + C * A₀) * Real.log (2 * (n : ℝ)) + M₀ * Real.sqrt (Real.log (2 / δ))) /
          Real.sqrt (n : ℝ)
      else
        C₃ * (M₀ + C * A₀) * ((n : ℝ) ^ (-(1 : ℝ) / ((K - 1 : ℕ) : ℝ))) +
          C₃ * M₀ * Real.sqrt (Real.log (2 / δ) / (n : ℝ))
    change sSup ((fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
      |(∫ xy, Proof_thm_C_1_Race3.evalBallProfile L f xy.1 xy.2 ∂ν) -
        ((1 : ℝ) / (n : ℝ)) *
          ∑ i : Fin n, Proof_thm_C_1_Race3.evalBallProfile L f (X_samp i ω) (Y_samp i ω)|) ''
      ScoreProfileClass X K L R C M₀) ≤ bound at h_sup
    have h_bdd_sup := Proof_thm_C_1_Race3.scoreProfileClass_dev_bddAbove
      (L := L) (R := R) (C := C) (hn := hn) hM₀_pos ν
      (fun i => X_samp i ω) (fun i => Y_samp i ω)
    suffices h_le_sInf :
        (∫ xy, finiteCanonicalLoss Φ (ρ (W xy.1)) xy.2 ∂ν) - ε ≤
          sInf ((fun V : X →L[ℝ] ZeroSumSubspace K =>
            ∫ xy, matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 ∂ν) ''
            {V | hilbertSchmidtNorm V ≤ R}) by
      linarith
    refine le_csInf
      ⟨_, ⟨0, by change hilbertSchmidtNorm 0 ≤ R; rw [Proof_lem_C_2.hilbertSchmidtNorm_zero]; exact hR.le, rfl⟩⟩ ?_
    rintro _ ⟨V, hV, rfl⟩
    change hilbertSchmidtNorm V ≤ R at hV
    let f_learn : Metric.closedBall (0 : X) L × Fin K → ℝ :=
      fun xy => finiteCanonicalLoss Φ (ρ (W xy.1.1)) xy.2 - matchingPotential Φ 0
    have hf_learn : f_learn ∈ ScoreProfileClass X K L R C M₀ :=
      Proof_thm_C_1_Race3.learnerProfile_mem_scoreProfileClass hK hL hR hβ hB hΦ
        hW_norm hρ_simp hρ_lip
    have hdev_learn :
        |(∫ xy, Proof_thm_C_1_Race3.evalBallProfile L f_learn xy.1 xy.2 ∂ν) -
          ((1 : ℝ) / (n : ℝ)) *
            ∑ i : Fin n, Proof_thm_C_1_Race3.evalBallProfile L f_learn
              (X_samp i ω) (Y_samp i ω)| ≤ bound :=
      (le_csSup h_bdd_sup ⟨f_learn, hf_learn, rfl⟩).trans h_sup
    have heq_learn :
        (∫ xy, Proof_thm_C_1_Race3.evalBallProfile L f_learn xy.1 xy.2 ∂ν) -
          ((1 : ℝ) / (n : ℝ)) *
            ∑ i : Fin n, Proof_thm_C_1_Race3.evalBallProfile L f_learn
              (X_samp i ω) (Y_samp i ω) =
        (∫ xy, finiteCanonicalLoss Φ (ρ (W xy.1)) xy.2 ∂ν) -
          ((1 : ℝ) / (n : ℝ)) *
            ∑ i : Fin n, finiteCanonicalLoss Φ (ρ (W (X_samp i ω))) (Y_samp i ω) :=
      Proof_thm_C_1_Race3.evalBallProfile_dev_learner_eq hK hn hL hR hβ hB
        hΦ hW_norm hρ_simp hρ_lip ν hX_bound
        (fun i => X_samp i ω) (fun i => Y_samp i ω) hx_norm
    rw [heq_learn] at hdev_learn
    have h_fore_step :
        (∫ xy, finiteCanonicalLoss Φ (ρ (W xy.1)) xy.2 ∂ν) ≤
          ((1 : ℝ) / (n : ℝ)) *
            (∑ i : Fin n, finiteCanonicalLoss Φ (ρ (W (X_samp i ω))) (Y_samp i ω)) + bound := by
      linarith [(abs_le.mp hdev_learn).2]
    have h_emp_step :
        (1 / (n : ℝ)) *
            (∑ i : Fin n, finiteCanonicalLoss Φ (ρ (W (X_samp i ω))) (Y_samp i ω)) ≤
          (1 / (n : ℝ)) *
            ∑ i : Fin n, matchingLoss Φ
              ((V (X_samp i ω) : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) (Y_samp i ω) :=
      h_emp sample hx_norm Φ hΦ V hV
    let f_comp : Metric.closedBall (0 : X) L × Fin K → ℝ :=
      fun xy => matchingLoss Φ (V xy.1.1 : EuclideanSpace ℝ (Fin K)) xy.2 - matchingPotential Φ 0
    have hf_comp : f_comp ∈ ScoreProfileClass X K L R C M₀ :=
      Proof_thm_C_1_Race3.compProfile_mem_scoreProfileClass hK hL hR hβ hB hΦ hV
    have hdev_comp :
        |(∫ xy, Proof_thm_C_1_Race3.evalBallProfile L f_comp xy.1 xy.2 ∂ν) -
          ((1 : ℝ) / (n : ℝ)) *
            ∑ i : Fin n, Proof_thm_C_1_Race3.evalBallProfile L f_comp
              (X_samp i ω) (Y_samp i ω)| ≤ bound :=
      (le_csSup h_bdd_sup ⟨f_comp, hf_comp, rfl⟩).trans h_sup
    have heq_comp :
        (∫ xy, Proof_thm_C_1_Race3.evalBallProfile L f_comp xy.1 xy.2 ∂ν) -
          ((1 : ℝ) / (n : ℝ)) *
            ∑ i : Fin n, Proof_thm_C_1_Race3.evalBallProfile L f_comp
              (X_samp i ω) (Y_samp i ω) =
        (∫ xy, matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 ∂ν) -
          ((1 : ℝ) / (n : ℝ)) *
            ∑ i : Fin n, matchingLoss Φ
              (V (X_samp i ω) : EuclideanSpace ℝ (Fin K)) (Y_samp i ω) :=
      Proof_thm_C_1_Race3.evalBallProfile_dev_comp_eq hK hn hL hR
        hΦ hV ν hX_bound (fun i => X_samp i ω) (fun i => Y_samp i ω) hx_norm
    rw [heq_comp] at hdev_comp
    have h_comp_step :
        ((1 : ℝ) / (n : ℝ)) *
            (∑ i : Fin n, matchingLoss Φ
              ((V (X_samp i ω) : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) (Y_samp i ω)) ≤
          (∫ xy, matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 ∂ν) + bound := by
      linarith [(abs_le.mp hdev_comp).1]
    linarith
  · refine ⟨Set.univ, MeasurableSet.univ, ?_, ?_⟩
    · simp only [MeasureTheory.measure_univ, ENNReal.toReal_one]
      linarith
    · intro _ _ Φ hΦ
      exact False.elim (h_smooth_ne ⟨Φ, hΦ⟩)

end UL

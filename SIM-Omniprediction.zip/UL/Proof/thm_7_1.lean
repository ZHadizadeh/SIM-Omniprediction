import UL.Arxiv.DictionarySelection
import UL.Stmt.thm_7_1
import UL.Stmt.cit_mcdiarmid1989
import UL.Proof.thm_7_1.Race2.H1_Dirichlet
import UL.Proof.thm_7_1.Race2.H3_Concentration
import UL.Proof.thm_7_1.Race2.H4_EmpiricalAndLink
set_option autoImplicit false

namespace UL

open UL.Proof_thm_7_1_Race2

/-- The projected affine least-squares learner on a Dirichlet dictionary. -/
theorem P_thm_7_1_measurable (h_cit_mcdiarmid1989 : S_cit_mcdiarmid1989) : DictionaryLearningStatement true := by
  classical
  unfold DictionaryLearningStatement
  refine ⟨4096, by norm_num, ?_⟩
  intro n d K N hn hK L R β lam M hL hR hβ hlam hM D C_set projC ε δ hε _hεD hδ0 hδ1
  let label : Fin K → ZeroSumSubspace K := fun y =>
    ⟨EuclideanSpace.single y (1 : ℝ) - uniformVec K,
      Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex
        (Proof_lem_A_1.single_mem_simplex y) (Proof_lem_A_5.uniformVec_mem_simplex hK)⟩
  -- Use the measurable minimum-Frobenius-norm rule from Appendix E.
  obtain ⟨a, W, hAmeas, hWmeas, hfit⟩ :=
    Arxiv.measurableDictionaryFit (K := K) (d := d) hn β R hR.le
  let data (xs : Fin n → EuclideanSpace ℝ (Fin d)) (ys : Fin n → Fin K) :=
    (xs, fun i => label (ys i))
  let fitA := fun xs ys => a (data xs ys)
  let fitW := fun xs ys => W (data xs ys)
  have hNorm xs ys := (hfit (data xs ys)).1
  have hMin xs ys := (hfit (data xs ys)).2.1
  have hlabel : Measurable label := measurable_of_countable _
  have hdata : Measurable (Function.uncurry data) :=
    measurable_fst.prodMk (measurable_pi_lambda _ fun i =>
      hlabel.comp ((measurable_pi_apply i).comp measurable_snd))
  refine ⟨fitA, fitW, ⟨?_,hAmeas.comp hdata,hWmeas.comp hdata⟩, ?_⟩
  · intro xs ys
    exact ⟨hNorm xs ys, (projC_link_and_rank hK hβ (fitA xs ys) (fitW xs ys))⟩
  · intro hn_samples x_dict h_dir hx_dict ν h_prob_ν h_supp Ω _hMeasΩ μ h_prob_μ X Y
      hX_meas hY_meas h_indep h_map
    obtain ⟨E_good, _hE_meas, hE_prob, hE_spec⟩ :=
      exists_good_sample_event h_cit_mcdiarmid1989 hn hK h_dir.1 hL hδ0 hδ1
        x_dict hx_dict ν h_supp Ω μ X Y hX_meas hY_meas h_indep h_map
    refine le_trans hE_prob ?_
    refine ENNReal.toReal_mono (MeasureTheory.measure_ne_top μ _) (MeasureTheory.measure_mono ?_)
    intro ω hω
    obtain ⟨hx_mem_dict, h_conc⟩ := hE_spec ω hω
    let xs := fun i => X i ω
    let ys := fun i => Y i ω
    apply population_omniprediction_core
      (@dirichlet_contraction_eucl) (@dirichlet_contraction_zeroSum) (@dirichlet_contraction_scalar)
      hn hK hL hR hβ hlam hM hε hδ0 hδ1
      hn_samples h_dir hx_dict ν h_supp xs ys hx_mem_dict h_conc (hNorm xs ys)
    intro a W hW
    have h := mul_le_mul_of_nonneg_left (hMin xs ys a W hW)
      (show (0 : ℝ) ≤ 1 / (2 * (n : ℝ)) by positivity)
    have hAllowance : 0 ≤ ε ^ 2 / (32 * lam ^ 2) := by positivity
    exact h.trans (le_add_of_nonneg_right hAllowance)

theorem P_thm_7_1 (hc : S_cit_mcdiarmid1989) : S_thm_7_1 := by
  obtain ⟨c,hcpos,h⟩ := P_thm_7_1_measurable hc
  refine ⟨c,hcpos,?_⟩
  intro n d K N hn hK L R β lam M hL hR hβ hlam hM D C_set projC ε δ hε hεD hδ0 hδ1
  obtain ⟨a,W,hp,hr⟩ := h n d K N hn hK L R β lam M hL hR hβ hlam hM ε δ hε hεD hδ0 hδ1
  exact ⟨a,W,hp.1,hr⟩

end UL

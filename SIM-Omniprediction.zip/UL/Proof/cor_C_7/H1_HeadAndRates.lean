import Mathlib
import UL.Stmt.cor_C_7
import UL.Stmt.lem_C_4
import UL.Proof.thm_C_1.Race3.H2_EmpiricalAndClass
import UL.Proof.thm_C_1.Race3.H3_SampleBound
set_option autoImplicit false

namespace UL.Proof_cor_C_7

/-! ### 1. Quadratic-program head `qHead` and `extHead` -/

/-- The sample-head objective `Q_head` for Corollary D.5. -/
noncomputable def qHead {n K : ℕ} (β : ℝ)
    (s_samp : Fin n → UL.ZeroSumSubspace K)
    (p_samp : Fin n → EuclideanSpace ℝ (Fin K))
    (s₀ : UL.ZeroSumSubspace K) (θ : EuclideanSpace ℝ (Fin n)) : ℝ :=
  β ^ 2 * ‖∑ i : Fin n, θ i • (s_samp i : EuclideanSpace ℝ (Fin K)) -
      (2 : ℝ) • (s₀ : EuclideanSpace ℝ (Fin K))‖ ^ 2 +
    ‖∑ i : Fin n, θ i • p_samp i‖ ^ 2 +
    ∑ i : Fin n, θ i * (β ^ 2 * ‖s_samp i‖ ^ 2 - ‖p_samp i‖ ^ 2)

/-- Top-level extension map `ext` for Corollary D.5, choosing a minimizer of `qHead` on
`Simplex n` when one exists and falling back to `uniformVec K` otherwise. -/
noncomputable def extHead {n K : ℕ} (β : ℝ)
    (s_samp : Fin n → UL.ZeroSumSubspace K)
    (p_samp : Fin n → EuclideanSpace ℝ (Fin K))
    (s₀ : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K) :=
  letI := Classical.propDecidable
  if h : ∃ θ ∈ UL.Simplex n, IsMinOn (qHead β s_samp p_samp s₀) (UL.Simplex n) θ then
    ∑ i : Fin n, (Classical.choose h) i • p_samp i
  else
    UL.uniformVec K

private lemma toEuclideanLin_of_cols_eq_sum {m n : ℕ}
    (v : Fin n → EuclideanSpace ℝ (Fin m)) (θ : EuclideanSpace ℝ (Fin n)) :
    Matrix.toEuclideanLin (Matrix.of (fun r i => v i r)) θ =
      ∑ i : Fin n, θ i • v i := by
  ext r
  simp [Matrix.toEuclideanLin_apply, Matrix.mulVec, dotProduct, mul_comm]

/-- Properties of the extension `extHead` from `h_lem_C_4` (instantiated at `m = K`). -/
theorem extHead_spec (h_lem_C_4 : UL.S_lem_C_4)
    (n K : ℕ) (hn : 1 ≤ n) (hK : 2 ≤ K)
    (β : ℝ) (s_samp : Fin n → UL.ZeroSumSubspace K)
    (p_samp : Fin n → EuclideanSpace ℝ (Fin K))
    (hβ : 0 < β)
    (hp : ∀ i : Fin n, p_samp i ∈ UL.Simplex K)
    (hLip : ∀ i j : Fin n, ‖p_samp i - p_samp j‖ ≤ β * ‖s_samp i - s_samp j‖) :
    let Q_head : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin n) → ℝ :=
      fun s₀ θ =>
        β ^ 2 * ‖∑ i : Fin n, θ i • (s_samp i : EuclideanSpace ℝ (Fin K)) -
            (2 : ℝ) • (s₀ : EuclideanSpace ℝ (Fin K))‖ ^ 2 +
          ‖∑ i : Fin n, θ i • p_samp i‖ ^ 2 +
          ∑ i : Fin n, θ i * (β ^ 2 * ‖s_samp i‖ ^ 2 - ‖p_samp i‖ ^ 2)
    let ρ : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) := extHead β s_samp p_samp
    (∀ s₀ : UL.ZeroSumSubspace K,
      (∃ θ ∈ UL.Simplex n, IsMinOn (Q_head s₀) (UL.Simplex n) θ) ∧
      (∀ θ ∈ UL.Simplex n, IsMinOn (Q_head s₀) (UL.Simplex n) θ →
        ρ s₀ = ∑ i : Fin n, θ i • p_samp i)) ∧
    (∀ s₀ : UL.ZeroSumSubspace K, ρ s₀ ∈ UL.Simplex K) ∧
    LipschitzWith (Real.toNNReal β) ρ ∧
    (∀ i : Fin n, ρ (s_samp i) = p_samp i) := by
  let s_amb : Fin n → EuclideanSpace ℝ (Fin K) := fun i => (s_samp i : EuclideanSpace ℝ (Fin K))
  have hLip_amb : ∀ i j : Fin n, ‖p_samp i - p_samp j‖ ≤ β * ‖s_amb i - s_amb j‖ := by
    intro i j
    simpa [s_amb, Submodule.coe_sub, Submodule.norm_coe] using hLip i j
  obtain ⟨hExMin, hUniqMin, hExt⟩ :=
    h_lem_C_4 K n K (by omega) hn hK s_amb p_samp hp β hβ hLip_amb
  let S_mat : Matrix (Fin K) (Fin n) ℝ := Matrix.of (fun r i => s_amb i r)
  let P_mat : Matrix (Fin K) (Fin n) ℝ := Matrix.of (fun k i => p_samp i k)
  let d_vec : EuclideanSpace ℝ (Fin n) :=
    (WithLp.equiv 2 (Fin n → ℝ)).symm (fun i => β ^ 2 * ‖s_amb i‖ ^ 2 - ‖p_samp i‖ ^ 2)
  let Q_amb : EuclideanSpace ℝ (Fin K) → EuclideanSpace ℝ (Fin n) → ℝ :=
    fun x₀ θ =>
      β ^ 2 * ‖Matrix.toEuclideanLin S_mat θ - (2 : ℝ) • x₀‖ ^ 2 +
        ‖Matrix.toEuclideanLin P_mat θ‖ ^ 2 + inner ℝ d_vec θ
  have hQ_eq : ∀ (s₀ : UL.ZeroSumSubspace K) (θ : EuclideanSpace ℝ (Fin n)),
      Q_amb (s₀ : EuclideanSpace ℝ (Fin K)) θ = qHead β s_samp p_samp s₀ θ := by
    intro s₀ θ
    dsimp [Q_amb, qHead, S_mat, P_mat, d_vec, s_amb]
    rw [toEuclideanLin_of_cols_eq_sum (fun i => (s_samp i : EuclideanSpace ℝ (Fin K))) θ,
      toEuclideanLin_of_cols_eq_sum p_samp θ]
    simp only [PiLp.inner_apply, WithLp.equiv_symm_apply, RCLike.inner_apply, conj_trivial,
      Submodule.norm_coe]
  have hEx_sub : ∀ s₀ : UL.ZeroSumSubspace K,
      ∃ θ ∈ UL.Simplex n, IsMinOn (qHead β s_samp p_samp s₀) (UL.Simplex n) θ := by
    intro s₀
    obtain ⟨θ, hθ_mem, hθ_min⟩ := hExMin (s₀ : EuclideanSpace ℝ (Fin K))
    refine ⟨θ, hθ_mem, fun θ' hθ' => ?_⟩
    have h1 : Q_amb (s₀ : EuclideanSpace ℝ (Fin K)) θ ≤
        Q_amb (s₀ : EuclideanSpace ℝ (Fin K)) θ' := hθ_min hθ'
    change qHead β s_samp p_samp s₀ θ ≤ qHead β s_samp p_samp s₀ θ'
    rwa [hQ_eq s₀ θ, hQ_eq s₀ θ'] at h1
  choose θ_all hθ_all using hExMin
  obtain ⟨hρ_hull, hhull_sub, hρ_interp, hρ_lip, _⟩ := hExt θ_all hθ_all
  let ρ_amb : EuclideanSpace ℝ (Fin K) → EuclideanSpace ℝ (Fin K) :=
    fun x₀ => Matrix.toEuclideanLin P_mat (θ_all x₀)
  have hext_eq_amb : ∀ s₀ : UL.ZeroSumSubspace K,
      extHead β s_samp p_samp s₀ = ρ_amb (s₀ : EuclideanSpace ℝ (Fin K)) := by
    intro s₀
    have hex := hEx_sub s₀
    unfold extHead
    rw [dif_pos hex]
    obtain ⟨hch_mem, hch_min⟩ := Classical.choose_spec hex
    have hch_min_amb : IsMinOn (Q_amb (s₀ : EuclideanSpace ℝ (Fin K))) (UL.Simplex n)
        (Classical.choose hex) := by
      intro θ' hθ'
      change Q_amb (s₀ : EuclideanSpace ℝ (Fin K)) (Classical.choose hex) ≤
        Q_amb (s₀ : EuclideanSpace ℝ (Fin K)) θ'
      rw [hQ_eq s₀ (Classical.choose hex), hQ_eq s₀ θ']
      exact hch_min hθ'
    have huniq := hUniqMin (s₀ : EuclideanSpace ℝ (Fin K))
      (Classical.choose hex) (θ_all (s₀ : EuclideanSpace ℝ (Fin K)))
      hch_mem hch_min_amb (hθ_all _).1 (hθ_all _).2
    dsimp [ρ_amb, P_mat] at huniq ⊢
    rwa [toEuclideanLin_of_cols_eq_sum p_samp (Classical.choose hex)] at huniq
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro s₀
    refine ⟨hEx_sub s₀, ?_⟩
    intro θ hθ_mem hθ_min
    have hex := hEx_sub s₀
    unfold extHead
    rw [dif_pos hex]
    obtain ⟨hch_mem, hch_min⟩ := Classical.choose_spec hex
    have hch_min_amb : IsMinOn (Q_amb (s₀ : EuclideanSpace ℝ (Fin K))) (UL.Simplex n)
        (Classical.choose hex) := by
      intro θ' hθ'
      change Q_amb (s₀ : EuclideanSpace ℝ (Fin K)) (Classical.choose hex) ≤
        Q_amb (s₀ : EuclideanSpace ℝ (Fin K)) θ'
      rw [hQ_eq s₀ (Classical.choose hex), hQ_eq s₀ θ']
      exact hch_min hθ'
    have hθ_min_amb : IsMinOn (Q_amb (s₀ : EuclideanSpace ℝ (Fin K))) (UL.Simplex n) θ := by
      intro θ' hθ'
      change Q_amb (s₀ : EuclideanSpace ℝ (Fin K)) θ ≤
        Q_amb (s₀ : EuclideanSpace ℝ (Fin K)) θ'
      rw [hQ_eq s₀ θ, hQ_eq s₀ θ']
      exact hθ_min hθ'
    have huniq := hUniqMin (s₀ : EuclideanSpace ℝ (Fin K))
      (Classical.choose hex) θ hch_mem hch_min_amb hθ_mem hθ_min_amb
    simpa [P_mat, toEuclideanLin_of_cols_eq_sum] using huniq
  · intro s₀
    change extHead β s_samp p_samp s₀ ∈ UL.Simplex K
    rw [hext_eq_amb s₀]
    exact hhull_sub (hρ_hull (s₀ : EuclideanSpace ℝ (Fin K)))
  · refine LipschitzWith.of_dist_le_mul fun s₁ s₂ => ?_
    change dist (extHead β s_samp p_samp s₁) (extHead β s_samp p_samp s₂) ≤
      (Real.toNNReal β : ℝ) * dist s₁ s₂
    rw [hext_eq_amb s₁, hext_eq_amb s₂, Subtype.dist_eq]
    exact hρ_lip.dist_le_mul (s₁ : EuclideanSpace ℝ (Fin K)) (s₂ : EuclideanSpace ℝ (Fin K))
  · intro i
    change extHead β s_samp p_samp (s_samp i) = p_samp i
    rw [hext_eq_amb (s_samp i)]
    exact hρ_interp i

/-! ### 2. Smoothed forecast head properties -/

/-- Structural properties of `ρ_τ(s) = (1 - τ) • ρ(s) + τ • u`. -/
lemma smoothedHead_props {K : ℕ} (hK : 2 ≤ K) {β τ : ℝ}
    (hβ : 0 < β) (hτ_pos : 0 < τ) (hτ_half : τ ≤ (1 : ℝ) / 2)
    {ρ : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hρ_simp : ∀ s : UL.ZeroSumSubspace K, ρ s ∈ UL.Simplex K)
    (hρ_lip : LipschitzWith (Real.toNNReal β) ρ) :
    let ρ_τ : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) :=
      fun s => (1 - τ) • ρ s + τ • UL.uniformVec K
    (∀ s : UL.ZeroSumSubspace K, ρ_τ s ∈ UL.Simplex K) ∧
    LipschitzWith (Real.toNNReal ((1 - τ) * β)) ρ_τ ∧
    (1 - τ) * β ≤ β ∧
    (∀ (s : UL.ZeroSumSubspace K) (j : Fin K), τ / (K : ℝ) ≤ ρ_τ s j) := by
  intro ρ_τ
  have h1mτ : 0 ≤ 1 - τ := by linarith only [hτ_half]
  have hu_simp : UL.uniformVec K ∈ UL.Simplex K :=
    UL.Proof_lem_A_4.uniformVec_mem_simplex (by omega)
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro s
    exact (UL.Proof_lem_A_5.convex_simplex K) (hρ_simp s) hu_simp h1mτ hτ_pos.le (by ring)
  · refine LipschitzWith.of_dist_le_mul fun s₁ s₂ => ?_
    rw [Real.coe_toNNReal _ (mul_nonneg h1mτ hβ.le)]
    rw [dist_eq_norm, dist_eq_norm]
    have hdiff : ρ_τ s₁ - ρ_τ s₂ = (1 - τ) • (ρ s₁ - ρ s₂) := by
      dsimp [ρ_τ]
      rw [smul_sub]
      abel
    rw [hdiff, norm_smul, Real.norm_eq_abs, abs_of_nonneg h1mτ]
    have hlip1 : ‖ρ s₁ - ρ s₂‖ ≤ β * ‖s₁ - s₂‖ := by
      have hd := hρ_lip.dist_le_mul s₁ s₂
      rwa [Real.coe_toNNReal β hβ.le, dist_eq_norm, dist_eq_norm] at hd
    calc (1 - τ) * ‖ρ s₁ - ρ s₂‖
        ≤ (1 - τ) * (β * ‖s₁ - s₂‖) := mul_le_mul_of_nonneg_left hlip1 h1mτ
      _ = ((1 - τ) * β) * ‖s₁ - s₂‖ := by ring
  · nlinarith only [hτ_pos, hβ]
  · intro s j
    have hρj_nn : 0 ≤ ρ s j := (hρ_simp s).1 j
    have hprod_nn : 0 ≤ (1 - τ) * ρ s j := mul_nonneg h1mτ hρj_nn
    have hu_j : UL.uniformVec K j = (1 : ℝ) / (K : ℝ) := by
      simp [UL.uniformVec, UL.onesVec]
    have happ : ρ_τ s j = (1 - τ) * ρ s j + τ * UL.uniformVec K j := by
      simp [ρ_τ]
    rw [happ, hu_j]
    have hmul_eq : τ * ((1 : ℝ) / (K : ℝ)) = τ / (K : ℝ) := by ring
    linarith only [hprod_nn, hmul_eq]

/-! ### 3. Parameter positivity and `τ_of` / `D_τ_of` helper bounds -/

lemma tau_pos_and_le_half {lam T_max ε : ℝ}
    (hlam : 0 < lam) (hTmax : 0 < T_max) (hε : 0 < ε) :
    let τ := min ((1 : ℝ) / 2) (ε / (8 * (Real.sqrt 2 * lam + 2 * T_max)))
    0 < τ ∧ τ ≤ (1 : ℝ) / 2 ∧
    Real.sqrt 2 * lam * τ ≤ ε / 8 ∧
    2 * T_max * τ ≤ ε / 8 := by
  intro τ
  set B_τ : ℝ := 8 * (Real.sqrt 2 * lam + 2 * T_max)
  have hsqrt2 : 0 < Real.sqrt 2 := Real.sqrt_pos.mpr (by norm_num)
  have hB_pos : 0 < B_τ := by positivity
  have hτ_pos : 0 < τ := lt_min (by norm_num) (div_pos hε hB_pos)
  have hτ_half : τ ≤ (1 : ℝ) / 2 := min_le_left _ _
  have hτ_le_div : τ ≤ ε / B_τ := min_le_right _ _
  have hmul_le : B_τ * τ ≤ ε := by
    calc B_τ * τ ≤ B_τ * (ε / B_τ) := mul_le_mul_of_nonneg_left hτ_le_div hB_pos.le
      _ = ε := mul_div_cancel₀ ε hB_pos.ne'
  have hexp : 8 * (Real.sqrt 2 * lam) * τ + 8 * (2 * T_max) * τ = B_τ * τ := by
    dsimp [B_τ]; ring
  have h1 : Real.sqrt 2 * lam * τ ≤ ε / 8 := by
    have hnn : 0 ≤ 2 * T_max * τ := by positivity
    linarith only [hmul_le, hexp, hnn]
  have h2 : 2 * T_max * τ ≤ ε / 8 := by
    have hnn : 0 ≤ Real.sqrt 2 * lam * τ := by positivity
    linarith only [hmul_le, hexp, hnn]
  exact ⟨hτ_pos, hτ_half, h1, h2⟩

lemma log_K_div_tau_pos {K : ℕ} (hK : 2 ≤ K) {τ : ℝ} (hτ_pos : 0 < τ) (hτ_half : τ ≤ (1 : ℝ) / 2) :
    0 < Real.log ((K : ℝ) / τ) := by
  have hK_ge2 : (2 : ℝ) ≤ (K : ℝ) := by exact_mod_cast hK
  have hgt1 : 1 < (K : ℝ) / τ := by
    rw [one_lt_div hτ_pos]
    linarith only [hK_ge2, hτ_half]
  exact Real.log_pos hgt1

/-! ### 4. Sample complexity constant `cSamp`, rate bound (Part A), and sample-bound bridge -/

/-- Sample complexity constant `C_samp K` for Corollary D.5, scaling `C₃ K` by `8` so uniform
convergence holds at confidence `δ / 2` with margin `ε / 8`. -/
noncomputable def cSamp (C₃ : ℕ → ℝ) (K : ℕ) : ℝ :=
  UL.Proof_thm_C_1_Race3.sampleConstCK K (8 * C₃ K)

lemma one_le_cSamp (C₃ : ℕ → ℝ) (K : ℕ) : 1 ≤ cSamp C₃ K := by
  unfold cSamp UL.Proof_thm_C_1_Race3.sampleConstCK
  dsimp only
  have hc : (1 : ℝ) ≤ max 1 (8 * C₃ K) := le_max_left _ _
  have h72 : (1 : ℝ) ≤ (72 * max 1 (8 * C₃ K)) ^ 2 := by nlinarith only [hc]
  exact le_trans h72 (le_max_left _ _)

private lemma d_tau_ratio_bounds
    {K : ℕ} (hK : 2 ≤ K) {L R β lam M T_max : ℝ}
    (hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) (hlam : 0 < lam) (hM : 0 < M) (hTmax : 0 < T_max) :
    let A₀ : ℝ := L * R
    let D₀ : ℝ := M + A₀ + β * lam * A₀
    let τ_of : ℝ → ℝ :=
      fun ε => min ((1 : ℝ) / 2) (ε / (8 * (Real.sqrt 2 * lam + 2 * T_max)))
    let D_τ_of : ℝ → ℝ :=
      fun ε =>
        M + A₀ + T_max * Real.log ((K : ℝ) / τ_of ε) +
          β * A₀ * (lam + (K : ℝ) * T_max / τ_of ε)
    ∃ c_D : ℝ, 0 < c_D ∧
      ∀ (ε : ℝ), 0 < ε → ε ≤ D₀ →
        1 ≤ D_τ_of ε / ε ∧
        D_τ_of ε / ε ≤ c_D * ((1 : ℝ) / ε) ^ 2 * Real.log ((2 : ℝ) + 1 / ε) := by
  intro A₀ D₀ τ_of D_τ_of
  have hA₀ : 0 < A₀ := mul_pos hL hR
  have hD₀ : 0 < D₀ := by dsimp [D₀]; positivity
  have hK_pos : (0 : ℝ) < (K : ℝ) := by exact_mod_cast (by omega : 0 < K)
  have hlog2 : 0 < Real.log 2 := Real.log_pos (by norm_num)
  let B_τ : ℝ := 8 * (Real.sqrt 2 * lam + 2 * T_max)
  have hsqrt2 : 0 < Real.sqrt 2 := Real.sqrt_pos.mpr (by norm_num)
  have hB_τ : 0 < B_τ := by positivity
  let c_τ : ℝ := max (2 * D₀) B_τ
  have hc_τ : 0 < c_τ := lt_of_lt_of_le (by positivity : 0 < 2 * D₀) (le_max_left _ _)
  let c_log1 : ℝ := Real.log (max 1 ((K : ℝ) * c_τ)) / Real.log 2 + 1
  have hc_log1 : 0 < c_log1 := by
    have hnn : 0 ≤ Real.log (max 1 ((K : ℝ) * c_τ)) := Real.log_nonneg (le_max_left _ _)
    have hdiv : 0 ≤ Real.log (max 1 ((K : ℝ) * c_τ)) / Real.log 2 := div_nonneg hnn hlog2.le
    dsimp [c_log1]
    linarith only [hdiv]
  let c_D : ℝ :=
    D₀ ^ 2 / Real.log 2 + T_max * D₀ * c_log1 + β * A₀ * (K : ℝ) * T_max * c_τ / Real.log 2
  refine ⟨c_D, by positivity, fun ε hε hεD => ?_⟩
  obtain ⟨hτ_pos, hτ_half, _, _⟩ := tau_pos_and_le_half hlam hTmax hε
  have hlogKτ_pos : 0 < Real.log ((K : ℝ) / τ_of ε) :=
    log_K_div_tau_pos hK hτ_pos hτ_half
  have hDτ_eq : D_τ_of ε =
      D₀ + T_max * Real.log ((K : ℝ) / τ_of ε) + β * A₀ * ((K : ℝ) * T_max / τ_of ε) := by
    dsimp [D_τ_of, D₀]; ring
  have hD₀_le_Dτ : D₀ ≤ D_τ_of ε := by
    have hterm1 : 0 ≤ T_max * Real.log ((K : ℝ) / τ_of ε) := by positivity
    have hterm2 : 0 ≤ β * A₀ * ((K : ℝ) * T_max / τ_of ε) := by positivity
    linarith only [hDτ_eq, hterm1, hterm2]
  have h1_le_ratio : 1 ≤ D_τ_of ε / ε := (one_le_div hε).mpr (hεD.trans hD₀_le_Dτ)
  have hinv_tau : 1 / τ_of ε ≤ c_τ * (1 / ε) := by
    change 1 / min ((1 : ℝ) / 2) (ε / B_τ) ≤ c_τ * (1 / ε)
    by_cases hcase : (1 : ℝ) / 2 ≤ ε / B_τ
    · rw [min_eq_left hcase]
      have h1 : (1 : ℝ) / ((1 : ℝ) / 2) = (2 * ε) * (1 / ε) := by field_simp [hε.ne']
      rw [h1]
      have h2 : 2 * ε ≤ c_τ :=
        le_trans (by linarith only [hεD] : 2 * ε ≤ 2 * D₀) (le_max_left _ _)
      exact mul_le_mul_of_nonneg_right h2 (by positivity)
    · push_neg at hcase
      rw [min_eq_right hcase.le, one_div_div]
      calc B_τ / ε = B_τ * (1 / ε) := div_eq_mul_one_div B_τ ε
        _ ≤ c_τ * (1 / ε) := mul_le_mul_of_nonneg_right (le_max_right _ _) (by positivity)
  have hinv_pos : 0 < 1 / ε := one_div_pos.mpr hε
  have h2_lt : (2 : ℝ) < (2 : ℝ) + 1 / ε := by linarith only [hinv_pos]
  have hlog_ge : Real.log 2 ≤ Real.log ((2 : ℝ) + 1 / ε) :=
    Real.log_le_log (by norm_num) h2_lt.le
  have h1_le_log : 1 ≤ (1 / Real.log 2) * Real.log ((2 : ℝ) + 1 / ε) := by
    rw [one_div_mul_eq_div, one_le_div hlog2]
    exact hlog_ge
  have hlog_Ktau : Real.log ((K : ℝ) / τ_of ε) ≤ c_log1 * Real.log ((2 : ℝ) + 1 / ε) := by
    have harg : (K : ℝ) / τ_of ε ≤ max 1 ((K : ℝ) * c_τ) * ((2 : ℝ) + 1 / ε) := by
      calc (K : ℝ) / τ_of ε
          = (K : ℝ) * (1 / τ_of ε) := div_eq_mul_one_div _ _
        _ ≤ (K : ℝ) * (c_τ * (1 / ε)) := mul_le_mul_of_nonneg_left hinv_tau hK_pos.le
        _ = ((K : ℝ) * c_τ) * (1 / ε) := by ring
        _ ≤ max 1 ((K : ℝ) * c_τ) * (1 / ε) :=
            mul_le_mul_of_nonneg_right (le_max_right _ _) (by positivity)
        _ ≤ max 1 ((K : ℝ) * c_τ) * ((2 : ℝ) + 1 / ε) :=
            mul_le_mul_of_nonneg_left (by linarith only [hinv_pos])
              (le_trans zero_le_one (le_max_left _ _))
    have hmax_pos : 0 < max 1 ((K : ℝ) * c_τ) := lt_of_lt_of_le zero_lt_one (le_max_left _ _)
    have hlog_le := Real.log_le_log (div_pos hK_pos hτ_pos) harg
    rw [Real.log_mul hmax_pos.ne' (by positivity)] at hlog_le
    have hconst_le : Real.log (max 1 ((K : ℝ) * c_τ)) ≤
        (Real.log (max 1 ((K : ℝ) * c_τ)) / Real.log 2) * Real.log ((2 : ℝ) + 1 / ε) := by
      have hnn : 0 ≤ Real.log (max 1 ((K : ℝ) * c_τ)) := Real.log_nonneg (le_max_left _ _)
      calc Real.log (max 1 ((K : ℝ) * c_τ))
          = Real.log (max 1 ((K : ℝ) * c_τ)) * 1 := (mul_one _).symm
        _ ≤ Real.log (max 1 ((K : ℝ) * c_τ)) *
              ((1 / Real.log 2) * Real.log ((2 : ℝ) + 1 / ε)) :=
            mul_le_mul_of_nonneg_left h1_le_log hnn
        _ = (Real.log (max 1 ((K : ℝ) * c_τ)) / Real.log 2) *
              Real.log ((2 : ℝ) + 1 / ε) := by ring
    have hsum_eq : (Real.log (max 1 ((K : ℝ) * c_τ)) / Real.log 2) *
          Real.log ((2 : ℝ) + 1 / ε) + Real.log ((2 : ℝ) + 1 / ε) =
        c_log1 * Real.log ((2 : ℝ) + 1 / ε) := by
      dsimp [c_log1]; ring
    linarith only [hlog_le, hconst_le, hsum_eq]
  have h1_le_D0_inv : 1 ≤ D₀ * (1 / ε) := by
    rw [mul_one_div]
    exact (one_le_div hε).mpr hεD
  have ht1 : D₀ ≤ (D₀ ^ 2 / Real.log 2) * (1 / ε) * Real.log ((2 : ℝ) + 1 / ε) := by
    calc D₀ = D₀ * 1 * 1 := by ring
      _ ≤ D₀ * (D₀ * (1 / ε)) * ((1 / Real.log 2) * Real.log ((2 : ℝ) + 1 / ε)) :=
          mul_le_mul (mul_le_mul_of_nonneg_left h1_le_D0_inv hD₀.le) h1_le_log zero_le_one
            (by positivity)
      _ = (D₀ ^ 2 / Real.log 2) * (1 / ε) * Real.log ((2 : ℝ) + 1 / ε) := by ring
  have ht2 : T_max * Real.log ((K : ℝ) / τ_of ε) ≤
      (T_max * D₀ * c_log1) * (1 / ε) * Real.log ((2 : ℝ) + 1 / ε) := by
    calc T_max * Real.log ((K : ℝ) / τ_of ε)
        = T_max * 1 * Real.log ((K : ℝ) / τ_of ε) := by ring
      _ ≤ T_max * (D₀ * (1 / ε)) * (c_log1 * Real.log ((2 : ℝ) + 1 / ε)) :=
          mul_le_mul (mul_le_mul_of_nonneg_left h1_le_D0_inv hTmax.le) hlog_Ktau
            hlogKτ_pos.le (by positivity)
      _ = (T_max * D₀ * c_log1) * (1 / ε) * Real.log ((2 : ℝ) + 1 / ε) := by ring
  have ht3 : β * A₀ * ((K : ℝ) * T_max / τ_of ε) ≤
      (β * A₀ * (K : ℝ) * T_max * c_τ / Real.log 2) * (1 / ε) *
        Real.log ((2 : ℝ) + 1 / ε) := by
    rw [div_eq_mul_one_div ((K : ℝ) * T_max) (τ_of ε)]
    calc β * A₀ * ((K : ℝ) * T_max * (1 / τ_of ε))
        = (β * A₀ * (K : ℝ) * T_max) * (1 / τ_of ε) * 1 := by ring
      _ ≤ (β * A₀ * (K : ℝ) * T_max) * (c_τ * (1 / ε)) *
            ((1 / Real.log 2) * Real.log ((2 : ℝ) + 1 / ε)) :=
          mul_le_mul (mul_le_mul_of_nonneg_left hinv_tau (by positivity)) h1_le_log
            zero_le_one (by positivity)
      _ = (β * A₀ * (K : ℝ) * T_max * c_τ / Real.log 2) * (1 / ε) *
            Real.log ((2 : ℝ) + 1 / ε) := by ring
  have hcD_split :
      (D₀ ^ 2 / Real.log 2) * (1 / ε) * Real.log ((2 : ℝ) + 1 / ε) +
        (T_max * D₀ * c_log1) * (1 / ε) * Real.log ((2 : ℝ) + 1 / ε) +
        (β * A₀ * (K : ℝ) * T_max * c_τ / Real.log 2) * (1 / ε) *
          Real.log ((2 : ℝ) + 1 / ε) =
      c_D * (1 / ε) * Real.log ((2 : ℝ) + 1 / ε) := by
    dsimp [c_D]; ring
  have hDτ_le : D_τ_of ε ≤ c_D * (1 / ε) * Real.log ((2 : ℝ) + 1 / ε) := by
    linarith only [hDτ_eq, ht1, ht2, ht3, hcD_split]
  refine ⟨h1_le_ratio, ?_⟩
  calc D_τ_of ε / ε
      = D_τ_of ε * (1 / ε) := div_eq_mul_one_div _ _
    _ ≤ (c_D * (1 / ε) * Real.log ((2 : ℝ) + 1 / ε)) * (1 / ε) :=
        mul_le_mul_of_nonneg_right hDτ_le (by positivity)
    _ = c_D * ((1 : ℝ) / ε) ^ 2 * Real.log ((2 : ℝ) + 1 / ε) := by ring

/-- Part A of `S_cor_C_7`: non-asymptotic polylogarithmic rate bound `O_K(ε^{-4} log^4(2 + 1/ε))`
for `K = 2, 3` and `O_K(ε^{-2(K-1)} log^{K-1}(2 + 1/ε))` for `K ≥ 4`. -/
theorem sampleBound_rate_bound
    (K : ℕ) (hK : 2 ≤ K) (C_K : ℝ) (hCK : 1 ≤ C_K)
    (L R β lam M T_max : ℝ)
    (hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) (hlam : 0 < lam) (hM : 0 < M) (hTmax : 0 < T_max)
    (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < (1 : ℝ) / 2) :
    let m : ℕ := K - 1
    let A₀ : ℝ := L * R
    let D₀ : ℝ := M + A₀ + β * lam * A₀
    let τ_of : ℝ → ℝ :=
      fun ε => min ((1 : ℝ) / 2) (ε / (8 * (Real.sqrt 2 * lam + 2 * T_max)))
    let D_τ_of : ℝ → ℝ :=
      fun ε =>
        M + A₀ + T_max * Real.log ((K : ℝ) / τ_of ε) +
          β * A₀ * (lam + (K : ℝ) * T_max / τ_of ε)
    let sampleBound : ℝ → ℝ → ℝ :=
      fun ε δ' =>
        if m ≤ 2 then
          C_K * (D_τ_of ε / ε) ^ 2 * (Real.log (C_K * D_τ_of ε / (ε * δ'))) ^ 2
        else
          C_K * ((D_τ_of ε / ε) ^ m + (D_τ_of ε / ε) ^ 2 * Real.log ((2 : ℝ) / δ'))
    ∃ (C_rate : ℝ) (q_log : ℕ), 0 < C_rate ∧
      ∀ (ε : ℝ), 0 < ε → ε ≤ D₀ →
        sampleBound ε δ ≤
          C_rate * ((1 : ℝ) / ε) ^ (if K ≤ 3 then 4 else 2 * (K - 1)) *
            (Real.log ((2 : ℝ) + 1 / ε)) ^ q_log := by
  intro m A₀ D₀ τ_of D_τ_of sampleBound
  have hCK_pos : 0 < C_K := lt_of_lt_of_le zero_lt_one hCK
  have hlog2 : 0 < Real.log 2 := Real.log_pos (by norm_num)
  obtain ⟨c_D, hc_D, hD_ratio⟩ := d_tau_ratio_bounds hK hL hR hβ hlam hM hTmax
  by_cases hK3 : K ≤ 3
  · have hm2 : m ≤ 2 := by omega
    let c_log2 : ℝ := Real.log (max 1 (C_K * c_D / δ)) / Real.log 2 + 3
    have hc_log2 : 0 < c_log2 := by
      have hnn : 0 ≤ Real.log (max 1 (C_K * c_D / δ)) := Real.log_nonneg (le_max_left _ _)
      have hdiv : 0 ≤ Real.log (max 1 (C_K * c_D / δ)) / Real.log 2 := div_nonneg hnn hlog2.le
      dsimp [c_log2]
      linarith only [hdiv]
    refine ⟨C_K * c_D ^ 2 * c_log2 ^ 2, 4, by positivity, fun ε hε hεD => ?_⟩
    obtain ⟨h1_ratio, hratio_le⟩ := hD_ratio ε hε hεD
    change (if m ≤ 2 then
        C_K * (D_τ_of ε / ε) ^ 2 * (Real.log (C_K * D_τ_of ε / (ε * δ))) ^ 2
      else
        C_K * ((D_τ_of ε / ε) ^ m + (D_τ_of ε / ε) ^ 2 * Real.log ((2 : ℝ) / δ))) ≤ _
    rw [if_pos hm2, if_pos hK3]
    have hinv_pos : 0 < 1 / ε := one_div_pos.mpr hε
    have h2_lt : (2 : ℝ) < (2 : ℝ) + 1 / ε := by linarith only [hinv_pos]
    have hlog_ge : Real.log 2 ≤ Real.log ((2 : ℝ) + 1 / ε) :=
      Real.log_le_log (by norm_num) h2_lt.le
    have hlog_pos : 0 < Real.log ((2 : ℝ) + 1 / ε) := lt_of_lt_of_le hlog2 hlog_ge
    have h1_le_log : 1 ≤ (1 / Real.log 2) * Real.log ((2 : ℝ) + 1 / ε) := by
      rw [one_div_mul_eq_div, one_le_div hlog2]
      exact hlog_ge
    have hratio_nn : 0 ≤ D_τ_of ε / ε := le_trans zero_le_one h1_ratio
    have hratio_sq :
        (D_τ_of ε / ε) ^ 2 ≤
          c_D ^ 2 * ((1 : ℝ) / ε) ^ 4 * (Real.log ((2 : ℝ) + 1 / ε)) ^ 2 := by
      have hsq := pow_le_pow_left₀ hratio_nn hratio_le 2
      have hrew : (c_D * ((1 : ℝ) / ε) ^ 2 * Real.log ((2 : ℝ) + 1 / ε)) ^ 2 =
          c_D ^ 2 * ((1 : ℝ) / ε) ^ 4 * (Real.log ((2 : ℝ) + 1 / ε)) ^ 2 := by ring
      rwa [hrew] at hsq
    have harg_gt1 : 1 < C_K * D_τ_of ε / (ε * δ) := by
      have hrew : C_K * D_τ_of ε / (ε * δ) = (C_K / δ) * (D_τ_of ε / ε) := by
        field_simp [hε.ne', hδ0.ne']
      rw [hrew]
      have hCK_δ : 2 < C_K / δ := by
        rw [lt_div_iff₀ hδ0]
        linarith only [hCK, hδ1]
      nlinarith only [hCK_δ, h1_ratio]
    have hlog_arg_pos : 0 < Real.log (C_K * D_τ_of ε / (ε * δ)) := Real.log_pos harg_gt1
    have hlog_u_le_u : Real.log ((2 : ℝ) + 1 / ε) ≤ (2 : ℝ) + 1 / ε := by
      have hsub := Real.log_le_sub_one_of_pos (by positivity : 0 < (2 : ℝ) + 1 / ε)
      linarith only [hsub]
    have hinv_le_u : 1 / ε ≤ (2 : ℝ) + 1 / ε := by linarith only []
    have hratio_cube : D_τ_of ε / ε ≤ c_D * ((2 : ℝ) + 1 / ε) ^ 3 := by
      have hinv_sq : ((1 : ℝ) / ε) ^ 2 ≤ ((2 : ℝ) + 1 / ε) ^ 2 :=
        pow_le_pow_left₀ (by positivity) hinv_le_u 2
      calc D_τ_of ε / ε
          ≤ c_D * ((1 : ℝ) / ε) ^ 2 * Real.log ((2 : ℝ) + 1 / ε) := hratio_le
        _ ≤ c_D * ((2 : ℝ) + 1 / ε) ^ 2 * ((2 : ℝ) + 1 / ε) := by
            have hm1 : c_D * ((1 : ℝ) / ε) ^ 2 ≤ c_D * ((2 : ℝ) + 1 / ε) ^ 2 :=
              mul_le_mul_of_nonneg_left hinv_sq hc_D.le
            exact mul_le_mul hm1 hlog_u_le_u hlog_pos.le (by positivity)
        _ = c_D * ((2 : ℝ) + 1 / ε) ^ 3 := by ring
    have harg_le : C_K * D_τ_of ε / (ε * δ) ≤
        max 1 (C_K * c_D / δ) * ((2 : ℝ) + 1 / ε) ^ 3 := by
      have hrew : C_K * D_τ_of ε / (ε * δ) = (C_K / δ) * (D_τ_of ε / ε) := by
        field_simp [hε.ne', hδ0.ne']
      rw [hrew]
      calc (C_K / δ) * (D_τ_of ε / ε)
          ≤ (C_K / δ) * (c_D * ((2 : ℝ) + 1 / ε) ^ 3) :=
            mul_le_mul_of_nonneg_left hratio_cube (by positivity)
        _ = (C_K * c_D / δ) * ((2 : ℝ) + 1 / ε) ^ 3 := by ring
        _ ≤ max 1 (C_K * c_D / δ) * ((2 : ℝ) + 1 / ε) ^ 3 :=
            mul_le_mul_of_nonneg_right (le_max_right _ _) (by positivity)
    have hlog_arg_le :
        Real.log (C_K * D_τ_of ε / (ε * δ)) ≤
          c_log2 * Real.log ((2 : ℝ) + 1 / ε) := by
      have hmax_pos : 0 < max 1 (C_K * c_D / δ) := lt_of_lt_of_le zero_lt_one (le_max_left _ _)
      have hl := Real.log_le_log (lt_trans zero_lt_one harg_gt1) harg_le
      rw [Real.log_mul hmax_pos.ne' (by positivity), Real.log_pow, Nat.cast_ofNat] at hl
      have hconst_le : Real.log (max 1 (C_K * c_D / δ)) ≤
          (Real.log (max 1 (C_K * c_D / δ)) / Real.log 2) * Real.log ((2 : ℝ) + 1 / ε) := by
        have hnn : 0 ≤ Real.log (max 1 (C_K * c_D / δ)) := Real.log_nonneg (le_max_left _ _)
        calc Real.log (max 1 (C_K * c_D / δ))
            = Real.log (max 1 (C_K * c_D / δ)) * 1 := (mul_one _).symm
          _ ≤ Real.log (max 1 (C_K * c_D / δ)) *
                ((1 / Real.log 2) * Real.log ((2 : ℝ) + 1 / ε)) :=
              mul_le_mul_of_nonneg_left h1_le_log hnn
          _ = (Real.log (max 1 (C_K * c_D / δ)) / Real.log 2) *
                Real.log ((2 : ℝ) + 1 / ε) := by ring
      have hsum_eq :
          (Real.log (max 1 (C_K * c_D / δ)) / Real.log 2) * Real.log ((2 : ℝ) + 1 / ε) +
            3 * Real.log ((2 : ℝ) + 1 / ε) =
            c_log2 * Real.log ((2 : ℝ) + 1 / ε) := by
        dsimp [c_log2]; ring
      linarith only [hl, hconst_le, hsum_eq]
    have hlog_sq :
        (Real.log (C_K * D_τ_of ε / (ε * δ))) ^ 2 ≤
          c_log2 ^ 2 * (Real.log ((2 : ℝ) + 1 / ε)) ^ 2 := by
      have hsq := pow_le_pow_left₀ hlog_arg_pos.le hlog_arg_le 2
      have hrew : (c_log2 * Real.log ((2 : ℝ) + 1 / ε)) ^ 2 =
          c_log2 ^ 2 * (Real.log ((2 : ℝ) + 1 / ε)) ^ 2 := by ring
      rwa [hrew] at hsq
    calc C_K * (D_τ_of ε / ε) ^ 2 * (Real.log (C_K * D_τ_of ε / (ε * δ))) ^ 2
        ≤ C_K * (c_D ^ 2 * ((1 : ℝ) / ε) ^ 4 * (Real.log ((2 : ℝ) + 1 / ε)) ^ 2) *
            (c_log2 ^ 2 * (Real.log ((2 : ℝ) + 1 / ε)) ^ 2) := by
          have hm1 : C_K * (D_τ_of ε / ε) ^ 2 ≤
              C_K * (c_D ^ 2 * ((1 : ℝ) / ε) ^ 4 * (Real.log ((2 : ℝ) + 1 / ε)) ^ 2) :=
            mul_le_mul_of_nonneg_left hratio_sq hCK_pos.le
          exact mul_le_mul hm1 hlog_sq (sq_nonneg _) (by positivity)
      _ = (C_K * c_D ^ 2 * c_log2 ^ 2) * ((1 : ℝ) / ε) ^ 4 *
            (Real.log ((2 : ℝ) + 1 / ε)) ^ 4 := by ring
  · have hm_not2 : ¬ m ≤ 2 := by omega
    have hm_ge2 : 2 ≤ m := by omega
    have h2δ_gt1 : 1 < (2 : ℝ) / δ := by
      rw [one_lt_div hδ0]
      linarith only [hδ1]
    have hlog2δ : 0 < Real.log ((2 : ℝ) / δ) := Real.log_pos h2δ_gt1
    refine ⟨C_K * (1 + Real.log ((2 : ℝ) / δ)) * c_D ^ m, m, by positivity, fun ε hε hεD => ?_⟩
    obtain ⟨h1_ratio, hratio_le⟩ := hD_ratio ε hε hεD
    change (if m ≤ 2 then
        C_K * (D_τ_of ε / ε) ^ 2 * (Real.log (C_K * D_τ_of ε / (ε * δ))) ^ 2
      else
        C_K * ((D_τ_of ε / ε) ^ m + (D_τ_of ε / ε) ^ 2 * Real.log ((2 : ℝ) / δ))) ≤ _
    rw [if_neg hm_not2, if_neg hK3]
    have hsq_le_m : (D_τ_of ε / ε) ^ 2 ≤ (D_τ_of ε / ε) ^ m :=
      pow_le_pow_right₀ h1_ratio hm_ge2
    have hsum_le :
        (D_τ_of ε / ε) ^ m + (D_τ_of ε / ε) ^ 2 * Real.log ((2 : ℝ) / δ) ≤
          (1 + Real.log ((2 : ℝ) / δ)) * (D_τ_of ε / ε) ^ m := by
      have hm1 : (D_τ_of ε / ε) ^ 2 * Real.log ((2 : ℝ) / δ) ≤
          (D_τ_of ε / ε) ^ m * Real.log ((2 : ℝ) / δ) :=
        mul_le_mul_of_nonneg_right hsq_le_m hlog2δ.le
      have hrew : (D_τ_of ε / ε) ^ m + (D_τ_of ε / ε) ^ m * Real.log ((2 : ℝ) / δ) =
          (1 + Real.log ((2 : ℝ) / δ)) * (D_τ_of ε / ε) ^ m := by ring
      linarith only [hm1, hrew]
    have hpow_m :
        (D_τ_of ε / ε) ^ m ≤
          c_D ^ m * ((1 : ℝ) / ε) ^ (2 * m) * (Real.log ((2 : ℝ) + 1 / ε)) ^ m := by
      have h1 := pow_le_pow_left₀ (le_trans zero_le_one h1_ratio) hratio_le m
      have hrew :
          (c_D * ((1 : ℝ) / ε) ^ 2 * Real.log ((2 : ℝ) + 1 / ε)) ^ m =
            c_D ^ m * ((1 : ℝ) / ε) ^ (2 * m) * (Real.log ((2 : ℝ) + 1 / ε)) ^ m := by
        rw [mul_pow, mul_pow, ← pow_mul]
      rwa [hrew] at h1
    have hm_eq : 2 * (K - 1) = 2 * m := rfl
    rw [hm_eq]
    calc C_K * ((D_τ_of ε / ε) ^ m + (D_τ_of ε / ε) ^ 2 * Real.log ((2 : ℝ) / δ))
        ≤ C_K * ((1 + Real.log ((2 : ℝ) / δ)) * (D_τ_of ε / ε) ^ m) :=
          mul_le_mul_of_nonneg_left hsum_le hCK_pos.le
      _ ≤ C_K * ((1 + Real.log ((2 : ℝ) / δ)) *
            (c_D ^ m * ((1 : ℝ) / ε) ^ (2 * m) * (Real.log ((2 : ℝ) + 1 / ε)) ^ m)) :=
          mul_le_mul_of_nonneg_left
            (mul_le_mul_of_nonneg_left hpow_m (by positivity)) hCK_pos.le
      _ = (C_K * (1 + Real.log ((2 : ℝ) / δ)) * c_D ^ m) *
            ((1 : ℝ) / ε) ^ (2 * m) * (Real.log ((2 : ℝ) + 1 / ε)) ^ m := by ring

/-- Bridge from `n ≥ sampleBound ε δ` (with `C_K = cSamp C₃ K`) to the uniform-convergence
deviation bound at confidence `δ / 2`: `8 * bound(C₃ K, δ / 2) ≤ ε`. -/
theorem sample_bound_implies_eight_bound_half
    (K : ℕ) (hK : 2 ≤ K) (C₃ : ℝ) (hC₃ : 0 < C₃)
    (L R β lam M T_max ε δ : ℝ)
    (hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) (hlam : 0 < lam) (hM : 0 < M) (hTmax : 0 < T_max)
    (hε0 : 0 < ε) (hεD₀ : ε ≤ M + L * R + β * lam * (L * R))
    (hδ0 : 0 < δ) (hδ1 : δ < (1 : ℝ) / 2)
    (n : ℕ) (hn : 1 ≤ n)
    (hn_ge :
      let m : ℕ := K - 1
      let A₀ : ℝ := L * R
      let τ : ℝ := min ((1 : ℝ) / 2) (ε / (8 * (Real.sqrt 2 * lam + 2 * T_max)))
      let D_τ : ℝ :=
        M + A₀ + T_max * Real.log ((K : ℝ) / τ) + β * A₀ * (lam + (K : ℝ) * T_max / τ)
      let C_K : ℝ := UL.Proof_thm_C_1_Race3.sampleConstCK K (8 * C₃)
      (n : ℝ) ≥
        if m ≤ 2 then
          C_K * (D_τ / ε) ^ 2 * (Real.log (C_K * D_τ / (ε * δ))) ^ 2
        else
          C_K * ((D_τ / ε) ^ m + (D_τ / ε) ^ 2 * Real.log ((2 : ℝ) / δ))) :
    let m : ℕ := K - 1
    let A₀ : ℝ := L * R
    let τ : ℝ := min ((1 : ℝ) / 2) (ε / (8 * (Real.sqrt 2 * lam + 2 * T_max)))
    let M_prof : ℝ := 3 * (M + T_max * Real.log ((K : ℝ) / τ) + A₀)
    let C_prof : ℝ := 3 * β * (lam + (K : ℝ) * T_max / τ)
    let D_prof : ℝ := M_prof + C_prof * A₀
    8 *
      (if m ≤ 2 then
        C₃ * (D_prof * Real.log (2 * (n : ℝ)) + M_prof * Real.sqrt (Real.log (2 / (δ / 2)))) /
          Real.sqrt (n : ℝ)
      else
        C₃ * D_prof * ((n : ℝ) ^ (-(1 : ℝ) / (m : ℝ))) +
          C₃ * M_prof * Real.sqrt (Real.log (2 / (δ / 2)) / (n : ℝ))) ≤ ε := by
  intro m A₀ τ M_prof C_prof D_prof
  obtain ⟨hτ_pos, hτ_half, _, _⟩ := tau_pos_and_le_half hlam hTmax hε0
  have hlogKτ : 0 < Real.log ((K : ℝ) / τ) := log_K_div_tau_pos hK hτ_pos hτ_half
  have hA₀ : 0 < A₀ := mul_pos hL hR
  let M' : ℝ := M + T_max * Real.log ((K : ℝ) / τ)
  let lam' : ℝ := lam + (K : ℝ) * T_max / τ
  have hM' : 0 < M' := by dsimp [M']; positivity
  have hlam' : 0 < lam' := by dsimp [lam']; positivity
  have hD_eq :
      M' + A₀ + β * lam' * A₀ =
        M + A₀ + T_max * Real.log ((K : ℝ) / τ) + β * A₀ * (lam + (K : ℝ) * T_max / τ) := by
    dsimp [M', lam']
    ring
  have hεD' : ε ≤ M' + A₀ + β * lam' * A₀ := by
    have hnn1 : 0 ≤ T_max * Real.log ((K : ℝ) / τ) := by positivity
    have hnn2 : 0 ≤ β * A₀ * ((K : ℝ) * T_max / τ) := by positivity
    have hexp : M' + A₀ + β * lam' * A₀ =
        (M + L * R + β * lam * (L * R)) + T_max * Real.log ((K : ℝ) / τ) +
          β * A₀ * ((K : ℝ) * T_max / τ) := by
      dsimp [M', lam', A₀]; ring
    linarith only [hεD₀, hnn1, hnn2, hexp]
  have hn_ge' :
      let C_K := UL.Proof_thm_C_1_Race3.sampleConstCK K (8 * C₃)
      let D := M' + A₀ + β * lam' * A₀
      (n : ℝ) ≥
        if m ≤ 2 then
          C_K * (D / ε) ^ 2 * (Real.log (C_K * D / (ε * δ))) ^ 2
        else
          C_K * ((D / ε) ^ m + (D / ε) ^ 2 * Real.log ((2 : ℝ) / δ)) := by
    dsimp only at hn_ge ⊢
    rwa [hD_eq]
  have hbase := UL.Proof_thm_C_1_Race3.sample_bound_implies_two_bound_le
    K hK (8 * C₃) (by positivity) M' A₀ β lam' ε δ
    hM' hA₀ hβ hlam' hε0 hεD' hδ0 hδ1 n hn hn_ge'
  dsimp only at hbase
  have h2δ_gt4 : (4 : ℝ) < 2 / δ := by
    rw [lt_div_iff₀ hδ0]
    linarith only [hδ1]
  have hhalf_eq : (2 : ℝ) / (δ / 2) = 2 * (2 / δ) := by ring
  have hlog2δ_pos : 0 < Real.log (2 / δ) := Real.log_pos (by linarith only [h2δ_gt4])
  have hlog_half_le : Real.log (2 / (δ / 2)) ≤ 4 * Real.log (2 / δ) := by
    rw [hhalf_eq]
    have hsq : 2 * (2 / δ) ≤ (2 / δ) ^ 2 := by nlinarith only [h2δ_gt4]
    have hl := Real.log_le_log (by positivity) hsq
    rw [Real.log_pow, Nat.cast_ofNat] at hl
    linarith only [hl, hlog2δ_pos]
  have hsqrt_half_le : Real.sqrt (Real.log (2 / (δ / 2))) ≤ 2 * Real.sqrt (Real.log (2 / δ)) := by
    have h1 := Real.sqrt_le_sqrt hlog_half_le
    have h4 : Real.sqrt 4 = (2 : ℝ) := by
      rw [show (4 : ℝ) = 2 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]
    have h2 : Real.sqrt (4 * Real.log (2 / δ)) = 2 * Real.sqrt (Real.log (2 / δ)) := by
      rw [Real.sqrt_mul (by norm_num), h4]
    rwa [h2] at h1
  have hn_pos : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hn
  have hsqrtn_pos : 0 < Real.sqrt (n : ℝ) := Real.sqrt_pos.mpr hn_pos
  have hMprof_eq : M_prof = 3 * (M' + A₀) := rfl
  have hDprof_eq : D_prof = 3 * (M' + A₀) + (3 * β * lam') * A₀ := by
    change M_prof + C_prof * A₀ = 3 * (M' + A₀) + (3 * β * lam') * A₀
    dsimp [M_prof, C_prof, M', lam']
  have hMprof_nn : 0 ≤ M_prof := by dsimp [M_prof]; positivity
  have hDprof_nn : 0 ≤ D_prof := by rw [hDprof_eq]; positivity
  rw [← hMprof_eq, ← hDprof_eq] at hbase
  split_ifs at hbase ⊢ with hm
  · have hn_ge1 : (1 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
    have hlog2n_nn : 0 ≤ Real.log (2 * (n : ℝ)) :=
      Real.log_nonneg (by linarith only [hn_ge1])
    have hm1 : M_prof * Real.sqrt (Real.log (2 / (δ / 2))) ≤
        2 * (M_prof * Real.sqrt (Real.log (2 / δ))) := by
      have hmul := mul_le_mul_of_nonneg_left hsqrt_half_le hMprof_nn
      have hrew : M_prof * (2 * Real.sqrt (Real.log (2 / δ))) =
          2 * (M_prof * Real.sqrt (Real.log (2 / δ))) := by ring
      linarith only [hmul, hrew]
    have hd1 : 0 ≤ D_prof * Real.log (2 * (n : ℝ)) := mul_nonneg hDprof_nn hlog2n_nn
    have hnum :
        8 * C₃ * (D_prof * Real.log (2 * (n : ℝ)) +
            M_prof * Real.sqrt (Real.log (2 / (δ / 2)))) ≤
          2 * (8 * C₃ * (D_prof * Real.log (2 * (n : ℝ)) +
            M_prof * Real.sqrt (Real.log (2 / δ)))) := by
      nlinarith only [hC₃, hm1, hd1]
    have hdiv := div_le_div_of_nonneg_right hnum hsqrtn_pos.le
    have hlhs : 8 * (C₃ * (D_prof * Real.log (2 * (n : ℝ)) +
        M_prof * Real.sqrt (Real.log (2 / (δ / 2)))) / Real.sqrt (n : ℝ)) =
      8 * C₃ * (D_prof * Real.log (2 * (n : ℝ)) +
        M_prof * Real.sqrt (Real.log (2 / (δ / 2)))) / Real.sqrt (n : ℝ) := by ring
    have hrhs : 2 * (8 * C₃ * (D_prof * Real.log (2 * (n : ℝ)) +
        M_prof * Real.sqrt (Real.log (2 / δ))) / Real.sqrt (n : ℝ)) =
      2 * (8 * C₃ * (D_prof * Real.log (2 * (n : ℝ)) +
        M_prof * Real.sqrt (Real.log (2 / δ)))) / Real.sqrt (n : ℝ) := by ring
    linarith only [hbase, hdiv, hlhs, hrhs]
  · have hlog_half_pos : 0 < Real.log (2 / (δ / 2)) :=
      Real.log_pos (by rw [hhalf_eq]; linarith only [h2δ_gt4])
    have hsqrt_div :
        Real.sqrt (Real.log (2 / (δ / 2)) / (n : ℝ)) ≤
          2 * Real.sqrt (Real.log (2 / δ) / (n : ℝ)) := by
      rw [Real.sqrt_div hlog_half_pos.le, Real.sqrt_div hlog2δ_pos.le]
      have hdiv := div_le_div_of_nonneg_right hsqrt_half_le hsqrtn_pos.le
      have hrew : 2 * Real.sqrt (Real.log (2 / δ)) / Real.sqrt (n : ℝ) =
          2 * (Real.sqrt (Real.log (2 / δ)) / Real.sqrt (n : ℝ)) := by ring
      linarith only [hdiv, hrew]
    have hrpow_nn : 0 ≤ (n : ℝ) ^ (-(1 : ℝ) / (m : ℝ)) := Real.rpow_nonneg hn_pos.le _
    have ht1 : 0 ≤ C₃ * D_prof * ((n : ℝ) ^ (-(1 : ℝ) / (m : ℝ))) := by positivity
    have ht2 : C₃ * M_prof * Real.sqrt (Real.log (2 / (δ / 2)) / (n : ℝ)) ≤
        2 * (C₃ * M_prof * Real.sqrt (Real.log (2 / δ) / (n : ℝ))) := by
      have hm1 := mul_le_mul_of_nonneg_left hsqrt_div (mul_nonneg hC₃.le hMprof_nn)
      have hrew : C₃ * M_prof * (2 * Real.sqrt (Real.log (2 / δ) / (n : ℝ))) =
          2 * (C₃ * M_prof * Real.sqrt (Real.log (2 / δ) / (n : ℝ))) := by ring
      linarith only [hm1, hrew]
    have hsplit :
        2 * (8 * C₃ * D_prof * (n : ℝ) ^ (-(1 : ℝ) / (m : ℝ)) +
            8 * C₃ * M_prof * Real.sqrt (Real.log (2 / δ) / (n : ℝ))) -
          8 * (C₃ * D_prof * (n : ℝ) ^ (-(1 : ℝ) / (m : ℝ)) +
            C₃ * M_prof * Real.sqrt (Real.log (2 / (δ / 2)) / (n : ℝ))) =
        8 * (C₃ * D_prof * (n : ℝ) ^ (-(1 : ℝ) / (m : ℝ))) +
          8 * (2 * (C₃ * M_prof * Real.sqrt (Real.log (2 / δ) / (n : ℝ))) -
            C₃ * M_prof * Real.sqrt (Real.log (2 / (δ / 2)) / (n : ℝ))) := by ring
    linarith only [hbase, ht1, ht2, hsplit]

end UL.Proof_cor_C_7

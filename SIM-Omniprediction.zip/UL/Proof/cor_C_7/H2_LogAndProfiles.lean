import Mathlib
import UL.Stmt.cor_C_7
import UL.Proof.cor_C_7.H1_HeadAndRates
import UL.Proof.prop_C_5.Race2.H1_QuadEntropy
set_option autoImplicit false

namespace UL.Proof_cor_C_7

open MeasureTheory

/-! ### 1. Elementary calculus and simplex norm inequalities -/

/-- Mean-value Lipschitz bound for `Real.log` away from zero: if `0 < c ≤ a` and `0 < c ≤ b`,
then `|Real.log a - Real.log b| ≤ |a - b| / c`. -/
lemma abs_log_sub_log_le_div {c a b : ℝ} (hc : 0 < c) (ha : c ≤ a) (hb : c ≤ b) :
    |Real.log a - Real.log b| ≤ |a - b| / c := by
  have aux : ∀ {x y : ℝ}, c ≤ x → x < y → |Real.log x - Real.log y| ≤ |x - y| / c := by
    intro x y hx hxy
    have hx_pos : 0 < x := lt_of_lt_of_le hc hx
    have hy_pos : 0 < y := lt_trans hx_pos hxy
    have hcont : ContinuousOn Real.log (Set.Icc x y) :=
      Real.continuousOn_log.mono fun z hz => (lt_of_lt_of_le hx_pos hz.1).ne'
    have hdiff : DifferentiableOn ℝ Real.log (Set.Ioo x y) :=
      fun z hz => (Real.differentiableAt_log (lt_trans hx_pos hz.1).ne').differentiableWithinAt
    obtain ⟨ξ, hξ, hslope⟩ := exists_deriv_eq_slope Real.log hxy hcont hdiff
    have hξ_ge : c ≤ ξ := le_trans hx hξ.1.le
    have hξ_pos : 0 < ξ := lt_of_lt_of_le hc hξ_ge
    have hderiv : deriv Real.log ξ = ξ⁻¹ := Real.deriv_log ξ
    have hyx_pos : 0 < y - x := sub_pos.mpr hxy
    have heq : Real.log y - Real.log x = ξ⁻¹ * (y - x) := by
      rw [← hderiv]
      exact ((eq_div_iff hyx_pos.ne').mp hslope).symm
    rw [abs_sub_comm (Real.log x) (Real.log y), abs_sub_comm x y, heq,
      abs_of_pos (mul_pos (inv_pos.mpr hξ_pos) hyx_pos), abs_of_pos hyx_pos, div_eq_inv_mul]
    exact mul_le_mul_of_nonneg_right (inv_anti₀ hc hξ_ge) hyx_pos.le
  rcases lt_trichotomy a b with hab | rfl | hba
  · exact aux ha hab
  · simp [hc.le]
  · rw [abs_sub_comm, abs_sub_comm a b]
    exact aux hb hba

/-- Elementary bound `-Real.log (1 - τ) ≤ 2 * τ` for `0 < τ ≤ 1 / 2`. -/
lemma neg_log_one_sub_le_two_mul {τ : ℝ} (hτ_pos : 0 < τ) (hτ_half : τ ≤ (1 : ℝ) / 2) :
    -Real.log (1 - τ) ≤ 2 * τ := by
  have h1mτ : (1 : ℝ) / 2 ≤ 1 - τ := by linarith only [hτ_half]
  have h1mτ_pos : 0 < 1 - τ := by linarith only [h1mτ]
  rw [← Real.log_inv]
  have h1 := Real.log_le_sub_one_of_pos (inv_pos.mpr h1mτ_pos)
  have hrew : (1 - τ)⁻¹ - 1 = τ / (1 - τ) := by
    field_simp [h1mτ_pos.ne']
    ring
  rw [hrew] at h1
  have h2 : τ / (1 - τ) ≤ 2 * τ := by
    rw [div_le_iff₀ h1mτ_pos]
    nlinarith only [hτ_pos, h1mτ]
  linarith only [h1, h2]

/-- Any two points in `Simplex K` have Euclidean distance at most `√2`. -/
lemma norm_sub_le_sqrt_two_of_mem_simplex {K : ℕ} {p q : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ UL.Simplex K) (hq : q ∈ UL.Simplex K) :
    ‖p - q‖ ≤ Real.sqrt 2 := by
  have hp_norm : ‖p‖ ≤ 1 := UL.Proof_lem_A_5.norm_le_one_of_mem_simplex hp
  have hq_norm : ‖q‖ ≤ 1 := UL.Proof_lem_A_5.norm_le_one_of_mem_simplex hq
  have hp_sq : ‖p‖ ^ 2 ≤ 1 := by
    have h0 : 0 ≤ ‖p‖ := norm_nonneg p
    nlinarith only [hp_norm, h0]
  have hq_sq : ‖q‖ ^ 2 ≤ 1 := by
    have h0 : 0 ≤ ‖q‖ := norm_nonneg q
    nlinarith only [hq_norm, h0]
  have hinn_nn : 0 ≤ inner ℝ p q := by
    rw [UL.Proof_lem_A_1.inner_eq_sum]
    exact Finset.sum_nonneg fun j _ => mul_nonneg (hp.1 j) (hq.1 j)
  have hsub_sq : ‖p - q‖ ^ 2 ≤ 2 := by
    have h1 := norm_sub_sq_real p q
    linarith only [h1, hp_sq, hq_sq, hinn_nn]
  rw [← Real.sqrt_sq (norm_nonneg (p - q))]
  exact Real.sqrt_le_sqrt hsub_sq

/-- Zero-sum Pinsker algebraic inequality: if `∑ j, d j = 0`, then `2 * ‖d‖^2 ≤ (∑ j, |d j|)^2`. -/
lemma two_mul_norm_sq_le_sq_l1_of_sum_zero {K : ℕ} (d : EuclideanSpace ℝ (Fin K))
    (hd : ∑ j : Fin K, d j = 0) :
    2 * ‖d‖ ^ 2 ≤ (∑ j : Fin K, |d j|) ^ 2 := by
  let fp : Fin K → ℝ := fun j => (|d j| + d j) / 2
  let fn : Fin K → ℝ := fun j => (|d j| - d j) / 2
  have hfp_nn : ∀ j : Fin K, 0 ≤ fp j := fun j => by
    have h := neg_le_abs (d j)
    dsimp [fp]; linarith only [h]
  have hfn_nn : ∀ j : Fin K, 0 ≤ fn j := fun j => by
    have h := le_abs_self (d j)
    dsimp [fn]; linarith only [h]
  have hsum_sq_le : ∀ (g : Fin K → ℝ), (∀ j : Fin K, 0 ≤ g j) →
      ∑ i : Fin K, g i ^ 2 ≤ (∑ i : Fin K, g i) ^ 2 := by
    intro g hg
    rw [sq (∑ i : Fin K, g i), Finset.sum_mul_sum]
    refine Finset.sum_le_sum fun i _ => ?_
    rw [sq (g i)]
    exact Finset.single_le_sum (fun j _ => mul_nonneg (hg i) (hg j)) (Finset.mem_univ i)
  have hfp_sum : ∑ j : Fin K, fp j = (∑ j : Fin K, |d j|) / 2 := by
    dsimp [fp]
    simp_rw [← Finset.sum_div, Finset.sum_add_distrib, hd, add_zero]
  have hfn_sum : ∑ j : Fin K, fn j = (∑ j : Fin K, |d j|) / 2 := by
    dsimp [fn]
    simp_rw [← Finset.sum_div, Finset.sum_sub_distrib, hd, sub_zero]
  have hpt_sq : ∀ j : Fin K, d j ^ 2 = fp j ^ 2 + fn j ^ 2 := by
    intro j
    dsimp [fp, fn]
    have habs : |d j| ^ 2 = d j ^ 2 := sq_abs (d j)
    linarith only [habs, show ((|d j| + d j) / 2) ^ 2 + ((|d j| - d j) / 2) ^ 2 =
      (|d j| ^ 2 + d j ^ 2) / 2 by ring]
  have hnorm_sq : ‖d‖ ^ 2 = ∑ j : Fin K, d j ^ 2 := by
    rw [PiLp.norm_sq_eq_of_L2]
    simp [Real.norm_eq_abs, sq_abs]
  have hsplit_sum : ∑ j : Fin K, d j ^ 2 = ∑ j : Fin K, fp j ^ 2 + ∑ j : Fin K, fn j ^ 2 := by
    simp_rw [hpt_sq, Finset.sum_add_distrib]
  have h1 := hsum_sq_le fp hfp_nn
  have h2 := hsum_sq_le fn hfn_nn
  rw [hfp_sum] at h1
  rw [hfn_sum] at h2
  linarith only [hnorm_sq, hsplit_sum, h1, h2,
    show ((∑ j : Fin K, |d j|) / 2) ^ 2 + ((∑ j : Fin K, |d j|) / 2) ^ 2 =
      (∑ j : Fin K, |d j|) ^ 2 / 2 by ring]

/-! ### 2. Shifted Shannon entropy `shannonEntropy K T η` and `SmoothEntropyFamily` bridge -/

/-- Open ambient neighborhood `{q ∈ ℝ^K | ∀ j, -η / 2 < q_j}` containing `Simplex K`. -/
def shannonOpenDomain (K : ℕ) (η : ℝ) : Set (EuclideanSpace ℝ (Fin K)) :=
  {q | ∀ j : Fin K, -η / 2 < q j}

/-- Ambient shifted-Shannon potential `(1 + K η) T ∑_j (q_j + η) log(q_j + η)`. -/
noncomputable def shannonExt (K : ℕ) (T η : ℝ) (q : EuclideanSpace ℝ (Fin K)) : ℝ :=
  (1 + (K : ℝ) * η) * T * ∑ j : Fin K, (q j + η) * Real.log (q j + η)

/-- Shifted-Shannon entropy restricted to `Simplex K`. -/
noncomputable def shannonEntropy (K : ℕ) (T η : ℝ) : UL.Simplex K → ℝ :=
  fun q => shannonExt K T η q.1

/-- Unprojected coordinate gradient of `shannonExt K T η`. -/
noncomputable def shannonRawGrad (K : ℕ) (T η : ℝ) (q : EuclideanSpace ℝ (Fin K)) :
    EuclideanSpace ℝ (Fin K) :=
  (WithLp.equiv 2 (Fin K → ℝ)).symm fun j =>
    (1 + (K : ℝ) * η) * T * (Real.log (q j + η) + 1)

/-- Zero-sum projected gradient of `shannonExt K T η`. -/
noncomputable def shannonGrad (K : ℕ) (T η : ℝ) (q : EuclideanSpace ℝ (Fin K)) :
    EuclideanSpace ℝ (Fin K) :=
  shannonRawGrad K T η q -
    (((1 : ℝ) / (K : ℝ)) * ∑ i : Fin K, shannonRawGrad K T η q i) • UL.onesVec K

private lemma isOpen_shannonOpenDomain (K : ℕ) (η : ℝ) :
    IsOpen (shannonOpenDomain K η) := by
  have heq : shannonOpenDomain K η =
      ⋂ j : Fin K, (EuclideanSpace.proj (𝕜 := ℝ) j) ⁻¹' Set.Ioi (-η / 2) := by
    ext q
    simp [shannonOpenDomain]
  rw [heq]
  exact isOpen_iInter_of_finite fun j =>
    isOpen_Ioi.preimage (EuclideanSpace.proj (𝕜 := ℝ) j).continuous

private lemma convex_shannonOpenDomain (K : ℕ) (η : ℝ) :
    Convex ℝ (shannonOpenDomain K η) := by
  intro x hx y hy a b ha hb hab j
  have hxj : -η / 2 < x j := hx j
  have hyj : -η / 2 < y j := hy j
  show -η / 2 < a * x j + b * y j
  rcases eq_or_lt_of_le ha with rfl | ha_pos
  · have hb1 : b = 1 := by linarith only [hab]
    subst hb1
    simpa using hyj
  · have h1 : a * (-η / 2) < a * x j := mul_lt_mul_of_pos_left hxj ha_pos
    have h2 : b * (-η / 2) ≤ b * y j := mul_le_mul_of_nonneg_left hyj.le hb
    have h3 : a * (-η / 2) + b * (-η / 2) = -η / 2 := by
      calc a * (-η / 2) + b * (-η / 2) = (a + b) * (-η / 2) := by ring
        _ = 1 * (-η / 2) := by rw [hab]
        _ = -η / 2 := one_mul _
    linarith only [h1, h2, h3]

private lemma simplex_subset_shannonOpenDomain {K : ℕ} {η : ℝ} (hη : 0 < η) :
    UL.Simplex K ⊆ shannonOpenDomain K η := by
  intro q hq j
  have hqj : 0 ≤ q j := hq.1 j
  linarith only [hqj, hη]

private lemma coord_add_eta_pos_of_mem {K : ℕ} {η : ℝ} (hη : 0 < η)
    {q : EuclideanSpace ℝ (Fin K)} (hq : q ∈ shannonOpenDomain K η) (j : Fin K) :
    0 < q j + η := by
  have hqj : -η / 2 < q j := hq j
  linarith only [hqj, hη]

private lemma hasFDerivAt_shannonExt {K : ℕ} {T η : ℝ} (hη : 0 < η)
    {q : EuclideanSpace ℝ (Fin K)} (hq : q ∈ shannonOpenDomain K η) :
    HasFDerivAt (shannonExt K T η) (innerSL ℝ (shannonRawGrad K T η q)) q := by
  set α : ℝ := (1 + (K : ℝ) * η) * T
  let proj : Fin K → (EuclideanSpace ℝ (Fin K) →L[ℝ] ℝ) :=
    fun j => innerSL ℝ (EuclideanSpace.single j (1 : ℝ))
  have hproj_apply : ∀ (j : Fin K) (x : EuclideanSpace ℝ (Fin K)), proj j x = x j := fun j x => by
    simp [proj, real_inner_comm, UL.Proof_lem_A_1.inner_single_right]
  have hcoord : ∀ j : Fin K,
      HasFDerivAt (fun x : EuclideanSpace ℝ (Fin K) => (x j + η) * Real.log (x j + η))
        ((Real.log (q j + η) + 1) • proj j) q := by
    intro j
    have hpos : 0 < q j + η := coord_add_eta_pos_of_mem hη hq j
    have hd1 : HasDerivAt (fun t : ℝ => (t + η) * Real.log (t + η))
        (Real.log (q j + η) + 1) (proj j q) := by
      rw [hproj_apply]
      have hlin : HasDerivAt (fun t : ℝ => t + η) 1 (q j) := by
        simpa using (hasDerivAt_id (q j)).add_const η
      simpa [mul_one] using (Real.hasDerivAt_mul_log hpos.ne').comp (q j) hlin
    have hcomp := hd1.comp_hasFDerivAt q (proj j).hasFDerivAt
    have hfn : ((fun t : ℝ => (t + η) * Real.log (t + η)) ∘ proj j) =
        fun x : EuclideanSpace ℝ (Fin K) => (x j + η) * Real.log (x j + η) := by
      ext x; simp [Function.comp, hproj_apply]
    rwa [hfn] at hcomp
  have hsum : HasFDerivAt
      (fun x : EuclideanSpace ℝ (Fin K) => ∑ j : Fin K, (x j + η) * Real.log (x j + η))
      (∑ j : Fin K, (Real.log (q j + η) + 1) • proj j) q := by
    have hfn : (fun x : EuclideanSpace ℝ (Fin K) => ∑ j : Fin K, (x j + η) * Real.log (x j + η)) =
        ∑ j ∈ Finset.univ,
          (fun x : EuclideanSpace ℝ (Fin K) => (x j + η) * Real.log (x j + η)) := by
      ext x; simp
    rw [hfn]
    exact HasFDerivAt.sum fun j _ => hcoord j
  have hmul : HasFDerivAt (shannonExt K T η)
      (α • ∑ j : Fin K, (Real.log (q j + η) + 1) • proj j) q :=
    hsum.const_mul α
  refine hmul.congr_fderiv ?_
  ext v
  simp only [ContinuousLinearMap.smul_apply, ContinuousLinearMap.sum_apply,
    hproj_apply, smul_eq_mul,
    innerSL_apply_apply, UL.Proof_lem_A_1.inner_eq_sum, Finset.mul_sum]
  refine Finset.sum_congr rfl fun j _ => ?_
  dsimp [shannonRawGrad, α]
  ring

private lemma shannonGrad_mem_zeroSum {K : ℕ} (hK : 1 ≤ K) (T η : ℝ)
    (q : EuclideanSpace ℝ (Fin K)) :
    shannonGrad K T η q ∈ UL.ZeroSumSubspace K := by
  rw [UL.Proof_lem_A_5.mem_zeroSumSubspace_iff]
  have hK_ne : (K : ℝ) ≠ 0 := by exact_mod_cast (by omega : K ≠ 0)
  dsimp [shannonGrad]
  simp only [PiLp.sub_apply, PiLp.smul_apply, UL.onesVec, WithLp.equiv_symm_apply, smul_eq_mul,
    mul_one, Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
    nsmul_eq_mul]
  field_simp [hK_ne]
  ring

private lemma inner_shannonGrad_eq_rawGrad_of_zeroSum {K : ℕ} (T η : ℝ)
    (q v : EuclideanSpace ℝ (Fin K)) (hv : v ∈ UL.ZeroSumSubspace K) :
    inner ℝ (shannonGrad K T η q) v = inner ℝ (shannonRawGrad K T η q) v := by
  have hv0 : inner ℝ (UL.onesVec K) v = 0 :=
    (UL.Proof_lem_A_1.mem_zeroSumSubspace_iff v).mp hv
  dsimp [shannonGrad]
  rw [inner_sub_left, inner_smul_left, conj_trivial, hv0, mul_zero, sub_zero]

private lemma convex_simplexAffineHull (K : ℕ) : Convex ℝ (UL.SimplexAffineHull K) := by
  intro x hx y hy a b _ha _hb hab
  show ∑ j : Fin K, (a • x + b • y) j = 1
  have hx' : ∑ j : Fin K, x j = 1 := hx
  have hy' : ∑ j : Fin K, y j = 1 := hy
  simp only [PiLp.add_apply, PiLp.smul_apply, smul_eq_mul,
    Finset.sum_add_distrib, ← Finset.mul_sum, hx', hy', mul_one]
  exact hab

private lemma convexOn_mul_log_Ici {η : ℝ} (hη : 0 < η) :
    ConvexOn ℝ (Set.Ici (-η / 2)) (fun t : ℝ => (t + η) * Real.log (t + η)) := by
  refine convexOn_of_hasDerivWithinAt2_nonneg (convex_Ici (-η / 2))
    (f' := fun t => Real.log (t + η) + 1)
    (f'' := fun t => (t + η)⁻¹) ?_ ?_ ?_ ?_
  · refine ContinuousOn.mul (continuousOn_id.add continuousOn_const) ?_
    refine (continuousOn_id.add continuousOn_const).log fun t ht => ?_
    have ht' : -η / 2 ≤ t := ht
    exact (by linarith only [ht', hη] : 0 < t + η).ne'
  · intro t ht
    rw [interior_Ici] at ht
    have ht' : -η / 2 < t := ht
    have hpos : 0 < t + η := by linarith only [ht', hη]
    have hlin : HasDerivAt (fun x : ℝ => x + η) 1 t := by
      simpa using (hasDerivAt_id t).add_const η
    have hd : HasDerivAt (fun x : ℝ => (x + η) * Real.log (x + η))
        (Real.log (t + η) + 1) t := by
      refine (hlin.mul (hlin.log hpos.ne')).congr_deriv ?_
      field_simp [hpos.ne']
    exact hd.hasDerivWithinAt
  · intro t ht
    rw [interior_Ici] at ht
    have ht' : -η / 2 < t := ht
    have hpos : 0 < t + η := by linarith only [ht', hη]
    have hlin : HasDerivAt (fun x : ℝ => x + η) 1 t := by
      simpa using (hasDerivAt_id t).add_const η
    have hd : HasDerivAt (fun x : ℝ => Real.log (x + η) + 1) ((t + η)⁻¹) t :=
      ((hlin.log hpos.ne').add_const 1).congr_deriv (one_div (t + η))
    exact hd.hasDerivWithinAt
  · intro t ht
    rw [interior_Ici] at ht
    have ht' : -η / 2 < t := ht
    have hpos : 0 < t + η := by linarith only [ht', hη]
    exact inv_nonneg.mpr hpos.le

private lemma convexOn_shannonExt_openDomain {K : ℕ} {T η : ℝ} (hT : 0 ≤ T) (hη : 0 < η) :
    ConvexOn ℝ (shannonOpenDomain K η) (shannonExt K T η) := by
  have h1d := convexOn_mul_log_Ici hη
  have hsum : ConvexOn ℝ (shannonOpenDomain K η)
      (fun q : EuclideanSpace ℝ (Fin K) => ∑ j : Fin K, (q j + η) * Real.log (q j + η)) := by
    refine ⟨convex_shannonOpenDomain K η, fun x hx y hy a b ha hb hab => ?_⟩
    simp only [smul_eq_mul, Finset.mul_sum, ← Finset.sum_add_distrib]
    refine Finset.sum_le_sum fun j _ => ?_
    have hxj : x j ∈ Set.Ici (-η / 2) := (hx j).le
    have hyj : y j ∈ Set.Ici (-η / 2) := (hy j).le
    simpa [PiLp.add_apply, PiLp.smul_apply, smul_eq_mul] using h1d.2 hxj hyj ha hb hab
  exact hsum.smul (by positivity : 0 ≤ (1 + (K : ℝ) * η) * T)

private lemma strongConvex_shannonEntropy {K : ℕ} (hK : 2 ≤ K) {β T η : ℝ}
    (hβ : 0 < β) (hT : (1 : ℝ) / (2 * β) ≤ T) (hη : 0 < η) :
    ConvexOn ℝ (UL.Simplex K)
      (fun q => UL.extendSimplex (shannonEntropy K T η) q -
        (1 / (2 * β)) * ‖q - UL.uniformVec K‖ ^ 2) := by
  have hT_pos : 0 < T := lt_of_lt_of_le (by positivity) hT
  set α : ℝ := (1 + (K : ℝ) * η) * T
  have hα_pos : 0 < α := by dsimp [α]; positivity
  refine ⟨UL.Proof_lem_A_5.convex_simplex K, fun x hx y hy a b ha hb hab => ?_⟩
  simp only [smul_eq_mul]
  let d : EuclideanSpace ℝ (Fin K) := y - x
  have hd_zero : d ∈ UL.ZeroSumSubspace K :=
    UL.Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex hy hx
  have hd_sum : ∑ j : Fin K, d j = 0 :=
    (UL.Proof_lem_A_5.mem_zeroSumSubspace_iff K d).mp hd_zero
  let γ : ℝ → EuclideanSpace ℝ (Fin K) := fun t => x + t • d
  have hγ_simp : ∀ t ∈ Set.Icc (0 : ℝ) 1, γ t ∈ UL.Simplex K := by
    intro t ht
    have hrew : γ t = (1 - t) • x + t • y := by
      dsimp [γ, d]
      rw [sub_smul, one_smul, smul_sub]
      abel
    rw [hrew]
    exact UL.Proof_lem_A_5.convex_simplex K hx hy (by linarith only [ht.2]) ht.1 (by ring)
  let ψ : ℝ → ℝ := fun t =>
    shannonExt K T η (γ t) - (1 / (2 * β)) * ‖γ t - UL.uniformVec K‖ ^ 2
  let ψ' : ℝ → ℝ := fun t =>
    α * (∑ j : Fin K, d j * (Real.log (γ t j + η) + 1)) -
      (1 / β) * inner ℝ (γ t - UL.uniformVec K) d
  let ψ'' : ℝ → ℝ := fun t =>
    α * (∑ j : Fin K, d j ^ 2 / (γ t j + η)) - (1 / β) * ‖d‖ ^ 2
  have hψ_conv : ConvexOn ℝ (Set.Icc (0 : ℝ) 1) ψ := by
    refine convexOn_of_hasDerivWithinAt2_nonneg (convex_Icc (0 : ℝ) 1)
      (f' := ψ') (f'' := ψ'') ?_ ?_ ?_ ?_
    · have hγ_cont : Continuous γ :=
        continuous_const.add (continuous_id.smul continuous_const)
      refine ContinuousOn.sub ?_ ?_
      · refine ContinuousOn.mul continuousOn_const
          (continuousOn_finset_sum Finset.univ fun j _ => ?_)
        have hc : Continuous (fun t : ℝ => γ t j + η) :=
          ((EuclideanSpace.proj (𝕜 := ℝ) j).continuous.comp hγ_cont).add continuous_const
        refine hc.continuousOn.mul (hc.continuousOn.log fun t ht => ?_)
        have hnn : 0 ≤ (γ t) j := (hγ_simp t ht).1 j
        exact (by linarith only [hnn, hη] : 0 < γ t j + η).ne'
      · exact continuousOn_const.mul
          (((hγ_cont.sub continuous_const).norm.pow 2).continuousOn)
    · intro t ht
      rw [interior_Icc] at ht
      have ht_Icc : t ∈ Set.Icc (0 : ℝ) 1 := ⟨ht.1.le, ht.2.le⟩
      have hγ_open : γ t ∈ shannonOpenDomain K η :=
        simplex_subset_shannonOpenDomain hη (hγ_simp t ht_Icc)
      have hdγ : HasDerivAt γ d t := by
        simpa [γ, one_smul] using ((hasDerivAt_id t).smul_const d).const_add x
      have hd1 : HasDerivAt (fun s : ℝ => shannonExt K T η (γ s))
          ((innerSL ℝ (shannonRawGrad K T η (γ t))) d) t :=
        (hasFDerivAt_shannonExt hη hγ_open).comp_hasDerivAt t hdγ
      have hd2 : HasDerivAt
          (fun s : ℝ => ((1 : ℝ) / (2 * β)) * ‖γ s - UL.uniformVec K‖ ^ 2)
          ((innerSL ℝ (((1 : ℝ) / β) • (γ t - UL.uniformVec K))) d) t :=
        (UL.Proof_cor_A_8.hasFDerivAt_quad_term β (γ t)).comp_hasDerivAt t hdγ
      have hderiv_eq :
          (innerSL ℝ (shannonRawGrad K T η (γ t))) d -
            (innerSL ℝ (((1 : ℝ) / β) • (γ t - UL.uniformVec K))) d = ψ' t := by
        simp only [innerSL_apply_apply, inner_smul_left, conj_trivial]
        dsimp [ψ', shannonRawGrad, α]
        rw [UL.Proof_lem_A_1.inner_eq_sum, Finset.mul_sum]
        congr 1
        refine Finset.sum_congr rfl fun j _ => ?_
        ring
      exact ((hd1.sub hd2).congr_deriv hderiv_eq).hasDerivWithinAt
    · intro t ht
      rw [interior_Icc] at ht
      have ht_Icc : t ∈ Set.Icc (0 : ℝ) 1 := ⟨ht.1.le, ht.2.le⟩
      have hd_term : ∀ j : Fin K,
          HasDerivAt (fun s : ℝ => d j * (Real.log (γ s j + η) + 1))
            (d j ^ 2 / (γ t j + η)) t := by
        intro j
        have hpos : 0 < γ t j + η := by
          have hnn : 0 ≤ (γ t) j := (hγ_simp t ht_Icc).1 j
          linarith only [hnn, hη]
        have hlin : HasDerivAt (fun s : ℝ => γ s j + η) (d j) t := by
          have h1 : (fun s : ℝ => γ s j + η) = fun s : ℝ => (x j + η) + s * d j := by
            ext s; simp [γ]; ring
          rw [h1]
          simpa using ((hasDerivAt_id t).mul_const (d j)).const_add (x j + η)
        have hlog : HasDerivAt (fun s : ℝ => Real.log (γ s j + η) + 1)
            (d j / (γ t j + η)) t :=
          (hlin.log hpos.ne').add_const 1
        refine (hlog.const_mul (d j)).congr_deriv ?_
        field_simp [hpos.ne']
      have hd_sum_log : HasDerivAt
          (fun s : ℝ => α * ∑ j : Fin K, d j * (Real.log (γ s j + η) + 1))
          (α * ∑ j : Fin K, d j ^ 2 / (γ t j + η)) t := by
        have hfn : (fun s : ℝ => ∑ j : Fin K, d j * (Real.log (γ s j + η) + 1)) =
            ∑ j ∈ Finset.univ, (fun s : ℝ => d j * (Real.log (γ s j + η) + 1)) := by
          ext s; simp
        exact (hfn ▸ HasDerivAt.sum fun j _ => hd_term j).const_mul α
      have hd_lin : HasDerivAt
          (fun s : ℝ => (1 / β) * inner ℝ (γ s - UL.uniformVec K) d)
          ((1 / β) * ‖d‖ ^ 2) t := by
        have h1 : (fun s : ℝ => (1 / β) * inner ℝ (γ s - UL.uniformVec K) d) =
            fun s : ℝ => (1 / β) * inner ℝ (x - UL.uniformVec K) d +
              s * ((1 / β) * ‖d‖ ^ 2) := by
          ext s
          have hγs : γ s - UL.uniformVec K = (x - UL.uniformVec K) + s • d := by
            dsimp [γ]; abel
          rw [hγs, inner_add_left, inner_smul_left, conj_trivial, real_inner_self_eq_norm_sq]
          ring
        rw [h1]
        simpa using ((hasDerivAt_id t).mul_const ((1 / β) * ‖d‖ ^ 2)).const_add
          ((1 / β) * inner ℝ (x - UL.uniformVec K) d)
      exact (hd_sum_log.sub hd_lin).hasDerivWithinAt
    · intro t ht
      rw [interior_Icc] at ht
      have ht_Icc : t ∈ Set.Icc (0 : ℝ) 1 := ⟨ht.1.le, ht.2.le⟩
      have hγt_simp : γ t ∈ UL.Simplex K := hγ_simp t ht_Icc
      let u_cs : Fin K → ℝ := fun j => |d j| / Real.sqrt (γ t j + η)
      let v_cs : Fin K → ℝ := fun j => Real.sqrt (γ t j + η)
      have hpos : ∀ j : Fin K, 0 < γ t j + η := fun j => by
        have hnn : 0 ≤ (γ t) j := hγt_simp.1 j
        linarith only [hnn, hη]
      have hcs := Finset.sum_mul_sq_le_sq_mul_sq Finset.univ u_cs v_cs
      have hlhs : ∑ j : Fin K, u_cs j * v_cs j = ∑ j : Fin K, |d j| := by
        refine Finset.sum_congr rfl fun j _ => ?_
        dsimp [u_cs, v_cs]
        exact div_mul_cancel₀ |d j| (Real.sqrt_pos.mpr (hpos j)).ne'
      have hrhs1 : ∑ j : Fin K, u_cs j ^ 2 = ∑ j : Fin K, d j ^ 2 / (γ t j + η) := by
        refine Finset.sum_congr rfl fun j _ => ?_
        dsimp [u_cs]
        rw [div_pow, sq_abs, Real.sq_sqrt (hpos j).le]
      have hrhs2 : ∑ j : Fin K, v_cs j ^ 2 = 1 + (K : ℝ) * η := by
        have hsq : ∑ j : Fin K, v_cs j ^ 2 = ∑ j : Fin K, (γ t j + η) := by
          refine Finset.sum_congr rfl fun j _ => ?_
          dsimp [v_cs]
          exact Real.sq_sqrt (hpos j).le
        rw [hsq, Finset.sum_add_distrib, hγt_simp.2, Finset.sum_const, Finset.card_univ,
          Fintype.card_fin, nsmul_eq_mul]
      rw [hlhs, hrhs1, hrhs2] at hcs
      have hmulT := mul_le_mul_of_nonneg_left hcs hT_pos.le
      have hrhs_α : T * ((∑ j : Fin K, d j ^ 2 / (γ t j + η)) * (1 + (K : ℝ) * η)) =
          α * ∑ j : Fin K, d j ^ 2 / (γ t j + η) := by
        dsimp [α]; ring
      rw [hrhs_α] at hmulT
      have hpinsker := two_mul_norm_sq_le_sq_l1_of_sum_zero d hd_sum
      have h2T : 2 * T * ‖d‖ ^ 2 ≤ T * (∑ j : Fin K, |d j|) ^ 2 := by
        have hm := mul_le_mul_of_nonneg_left hpinsker hT_pos.le
        linarith only [hm]
      have h1β_le_2T : 1 / β ≤ 2 * T := by
        have hmul := mul_le_mul_of_nonneg_left hT (by norm_num : (0 : ℝ) ≤ 2)
        have hrew : 2 * ((1 : ℝ) / (2 * β)) = 1 / β := by field_simp [hβ.ne']
        linarith only [hmul, hrew]
      have hβ_term : (1 / β) * ‖d‖ ^ 2 ≤ 2 * T * ‖d‖ ^ 2 :=
        mul_le_mul_of_nonneg_right h1β_le_2T (sq_nonneg ‖d‖)
      dsimp [ψ'']
      linarith only [hmulT, h2T, hβ_term]
  have hcomb_simp : a • x + b • y ∈ UL.Simplex K :=
    UL.Proof_lem_A_5.convex_simplex K hx hy ha hb hab
  have hγb : γ b = a • x + b • y := by
    have ha_eq : a = 1 - b := by linarith only [hab]
    rw [ha_eq]
    dsimp [γ, d]
    rw [sub_smul, one_smul, smul_sub]
    abel
  have hγ0 : γ 0 = x := by simp [γ]
  have hγ1 : γ 1 = y := by simp [γ, d]
  have hb_mem : b ∈ Set.Icc (0 : ℝ) 1 := ⟨hb, by linarith only [ha, hab]⟩
  have hstep := hψ_conv.2 (Set.left_mem_Icc.mpr zero_le_one)
    (Set.right_mem_Icc.mpr zero_le_one) ha hb hab
  simp only [smul_eq_mul, mul_zero, zero_add, mul_one] at hstep
  dsimp [ψ] at hstep
  rw [hγb, hγ0, hγ1] at hstep
  rwa [UL.Proof_lem_A_5.extendSimplex_eq_of_mem (shannonEntropy K T η) hcomb_simp,
    UL.Proof_lem_A_5.extendSimplex_eq_of_mem (shannonEntropy K T η) hx,
    UL.Proof_lem_A_5.extendSimplex_eq_of_mem (shannonEntropy K T η) hy]

private lemma hasFaceGradAt_univ_unique_local {K : ℕ} (hK : 2 ≤ K) {Φ : UL.Simplex K → ℝ}
    {q g₁ g₂ : EuclideanSpace ℝ (Fin K)} (hq : q ∈ UL.Simplex K)
    (hg₁ : UL.HasFaceGradAt Φ Finset.univ q g₁)
    (hg₂ : UL.HasFaceGradAt Φ Finset.univ q g₂) :
    g₁ = g₂ := by
  have htendsto : ∀ {g : EuclideanSpace ℝ (Fin K)},
      HasFDerivWithinAt (UL.extendSimplex Φ) (innerSL ℝ g) (UL.Simplex K) q →
      ∀ p ∈ UL.Simplex K,
        Filter.Tendsto
          (fun t : ℝ => (UL.extendSimplex Φ (q + t • (p - q)) - UL.extendSimplex Φ q) / t)
          (nhdsWithin (0 : ℝ) (Set.Ioi 0))
          (nhds (inner ℝ g (p - q))) := by
    intro g hf p hp
    let γ : ℝ → EuclideanSpace ℝ (Fin K) := fun t => q + t • (p - q)
    have hγ0 : γ 0 = q := by simp [γ]
    have hγ_deriv : HasDerivAt γ (p - q) 0 := by
      simpa [γ, one_smul] using ((hasDerivAt_id (0 : ℝ)).smul_const (p - q)).const_add q
    have hγ_maps : Set.MapsTo γ (Set.Ioo (0 : ℝ) 1) (UL.Simplex K) := by
      intro t ht
      have hγt : γ t = (1 - t) • q + t • p := by
        simp [γ, sub_smul, smul_sub]; abel
      rw [hγt]
      exact UL.Proof_lem_A_5.convex_simplex K hq hp (by linarith only [ht.2]) ht.1.le (by ring)
    have hf' : HasFDerivWithinAt (UL.extendSimplex Φ) (innerSL ℝ g) (UL.Simplex K) (γ 0) := by
      rwa [hγ0]
    have hcomp := hf'.comp_hasDerivWithinAt 0 hγ_deriv.hasDerivWithinAt hγ_maps
    have hdiff : Set.Ioo (0 : ℝ) 1 \ {0} = Set.Ioo (0 : ℝ) 1 := by
      ext x
      simp only [Set.mem_diff, Set.mem_Ioo, Set.mem_singleton_iff, and_iff_left_iff_imp]
      intro hx; linarith only [hx.1]
    rw [hasDerivWithinAt_iff_tendsto_slope, hdiff, nhdsWithin_Ioo_eq_nhdsGT zero_lt_one] at hcomp
    have hcongr : (fun t : ℝ => (UL.extendSimplex Φ (γ t) - UL.extendSimplex Φ q) / t) =ᶠ[
        nhdsWithin (0 : ℝ) (Set.Ioi 0)] slope (fun t : ℝ => UL.extendSimplex Φ (γ t)) 0 := by
      filter_upwards [self_mem_nhdsWithin] with t _
      simp [slope_def_field, hγ0]
    simpa [γ, innerSL_apply_apply] using hcomp.congr' hcongr.symm
  have hf₁ : HasFDerivWithinAt (UL.extendSimplex Φ) (innerSL ℝ g₁) (UL.Simplex K) q := by
    have h := hg₁.2; rwa [UL.Proof_lem_A_5.simplexFace_univ K] at h
  have hf₂ : HasFDerivWithinAt (UL.extendSimplex Φ) (innerSL ℝ g₂) (UL.Simplex K) q := by
    have h := hg₂.2; rwa [UL.Proof_lem_A_5.simplexFace_univ K] at h
  have hz₁ : g₁ ∈ UL.ZeroSumSubspace K := by
    have h := hg₁.1; rwa [UL.Proof_lem_A_5.faceTangentSpace_univ K] at h
  have hz₂ : g₂ ∈ UL.ZeroSumSubspace K := by
    have h := hg₂.1; rwa [UL.Proof_lem_A_5.faceTangentSpace_univ K] at h
  have hinn_eq : ∀ p ∈ UL.Simplex K, inner ℝ g₁ (p - q) = inner ℝ g₂ (p - q) := fun p hp =>
    tendsto_nhds_unique (htendsto hf₁ p hp) (htendsto hf₂ p hp)
  let d : EuclideanSpace ℝ (Fin K) := g₁ - g₂
  have hd_zero : d ∈ UL.ZeroSumSubspace K := Submodule.sub_mem _ hz₁ hz₂
  have hd_sum : ∑ j : Fin K, d j = 0 :=
    (UL.Proof_lem_A_5.mem_zeroSumSubspace_iff K d).mp hd_zero
  have hd_const : ∀ j : Fin K, d j = inner ℝ d q := by
    intro j
    have hej : EuclideanSpace.single j (1 : ℝ) ∈ UL.Simplex K :=
      UL.Proof_lem_A_1.single_mem_simplex j
    have h0 : inner ℝ d (EuclideanSpace.single j (1 : ℝ) - q) = 0 := by
      dsimp [d]
      rw [inner_sub_left, hinn_eq _ hej, sub_self]
    rw [inner_sub_right, UL.Proof_lem_A_1.inner_single_right] at h0
    linarith only [h0]
  have hc_sum : (K : ℝ) * inner ℝ d q = 0 := by
    have h1 : ∑ j : Fin K, d j = ∑ _ : Fin K, inner ℝ d q :=
      Finset.sum_congr rfl fun j _ => hd_const j
    rw [hd_sum, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul] at h1
    exact h1.symm
  have hK_ne : (K : ℝ) ≠ 0 := by exact_mod_cast (by omega : K ≠ 0)
  have hc : inner ℝ d q = 0 := (mul_eq_zero.mp hc_sum).resolve_left hK_ne
  ext j
  have hj := hd_const j
  rw [hc] at hj
  simpa [d, sub_eq_zero] using hj

/-- `simplexGrad (shannonEntropy K T η)` on `Simplex K` equals `shannonGrad K T η`. -/
lemma simplexGrad_shannonEntropy {K : ℕ} (hK : 2 ≤ K) {T η : ℝ} (hη : 0 < η)
    {q : EuclideanSpace ℝ (Fin K)} (hq : q ∈ UL.Simplex K) :
    UL.simplexGrad (shannonEntropy K T η) q = shannonGrad K T η q := by
  have hg : UL.HasFaceGradAt (shannonEntropy K T η) Finset.univ q (shannonGrad K T η q) := by
    refine ⟨?_, ?_⟩
    · rw [UL.Proof_lem_A_5.faceTangentSpace_univ K]
      exact shannonGrad_mem_zeroSum (by omega) T η q
    · rw [UL.Proof_lem_A_5.simplexFace_univ K]
      have hopen : q ∈ shannonOpenDomain K η := simplex_subset_shannonOpenDomain hη hq
      have hf0 : HasFDerivWithinAt (UL.extendSimplex (shannonEntropy K T η))
          (innerSL ℝ (shannonRawGrad K T η q)) (UL.Simplex K) q :=
        (hasFDerivAt_shannonExt hη hopen).hasFDerivWithinAt.congr
          (fun x hx => UL.Proof_lem_A_5.extendSimplex_eq_of_mem (shannonEntropy K T η) hx)
          (UL.Proof_lem_A_5.extendSimplex_eq_of_mem (shannonEntropy K T η) hq)
      refine HasFDerivAtFilter.of_isLittleO ?_
      refine hf0.isLittleO.congr' ?_ (Filter.Eventually.of_forall fun _ => rfl)
      filter_upwards [self_mem_nhdsWithin] with x hx
      have hxq : x - q ∈ UL.ZeroSumSubspace K :=
        UL.Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex hx hq
      simp only [innerSL_apply_apply, inner_shannonGrad_eq_rawGrad_of_zeroSum T η q (x - q) hxq]
  have hspec : UL.HasFaceGradAt (shannonEntropy K T η) Finset.univ q
      (UL.simplexGrad (shannonEntropy K T η) q) :=
    UL.Proof_lem_A_5.faceGrad_spec ⟨shannonGrad K T η q, hg⟩
  exact hasFaceGradAt_univ_unique_local hK hq hspec hg

private lemma norm_projZeroSum_le {K : ℕ} (hK : 1 ≤ K) (v : EuclideanSpace ℝ (Fin K)) :
    ‖v - (((1 : ℝ) / (K : ℝ)) * ∑ i : Fin K, v i) • UL.onesVec K‖ ≤ ‖v‖ := by
  set z : EuclideanSpace ℝ (Fin K) :=
    v - (((1 : ℝ) / (K : ℝ)) * ∑ i : Fin K, v i) • UL.onesVec K
  set w : EuclideanSpace ℝ (Fin K) :=
    (((1 : ℝ) / (K : ℝ)) * ∑ i : Fin K, v i) • UL.onesVec K
  have hz_zero : z ∈ UL.ZeroSumSubspace K := by
    rw [UL.Proof_lem_A_5.mem_zeroSumSubspace_iff]
    have hK_ne : (K : ℝ) ≠ 0 := by exact_mod_cast (by omega : K ≠ 0)
    dsimp [z]
    simp only [PiLp.sub_apply, PiLp.smul_apply, UL.onesVec, WithLp.equiv_symm_apply, smul_eq_mul,
      mul_one, Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
      nsmul_eq_mul]
    field_simp [hK_ne]
    ring
  have horth : inner ℝ z w = 0 := by
    dsimp [w]
    rw [inner_smul_right, real_inner_comm,
      (UL.Proof_lem_A_1.mem_zeroSumSubspace_iff z).mp hz_zero, mul_zero]
  have hadd : z + w = v := sub_add_cancel _ _
  have hpyth := norm_add_sq_real z w
  rw [hadd, horth] at hpyth
  have hw_sq : 0 ≤ ‖w‖ ^ 2 := sq_nonneg ‖w‖
  have hz_sq : ‖z‖ ^ 2 ≤ ‖v‖ ^ 2 := by linarith only [hpyth, hw_sq]
  rw [← Real.sqrt_sq (norm_nonneg z), ← Real.sqrt_sq (norm_nonneg v)]
  exact Real.sqrt_le_sqrt hz_sq

/-- For every `0 < η` and `1 / (2 * β) ≤ T`, `shannonEntropy K T η` belongs to
`SmoothEntropyFamily K β lam_η M_η` for explicit positive parameters `(lam_η, M_η)`. -/
lemma shannonEntropy_mem_smoothEntropyFamily {K : ℕ} (hK : 2 ≤ K)
    {β T η : ℝ} (hβ : 0 < β) (hT : (1 : ℝ) / (2 * β) ≤ T) (hη : 0 < η) :
    ∃ (lam_η M_η : ℝ), 0 < lam_η ∧ 0 < M_η ∧
      shannonEntropy K T η ∈ UL.SmoothEntropyFamily K β lam_η M_η := by
  have hT_pos : 0 < T := lt_of_lt_of_le (by positivity) hT
  set α : ℝ := (1 + (K : ℝ) * η) * T
  have hα_pos : 0 < α := by dsimp [α]; positivity
  let lam_η : ℝ := α / η
  let B_η : ℝ := max (|Real.log η|) (|Real.log (1 + η)|) + 1
  let M_η : ℝ := Real.sqrt (K : ℝ) * α * B_η
  have hlam_pos : 0 < lam_η := div_pos hα_pos hη
  have hB_pos : 0 < B_η := by
    have hnn : 0 ≤ max (|Real.log η|) (|Real.log (1 + η)|) :=
      le_trans (abs_nonneg _) (le_max_left _ _)
    dsimp [B_η]; linarith only [hnn]
  have hK_pos : (0 : ℝ) < (K : ℝ) := by exact_mod_cast (by omega : 0 < K)
  have hM_pos : 0 < M_η := by dsimp [M_η]; positivity
  refine ⟨lam_η, M_η, hlam_pos, hM_pos, ?_, hlam_pos, hM_pos, ?_, ?_, ?_⟩
  · -- `shannonEntropy K T η ∈ EntropyFamily K β`
    have hcont : Continuous (shannonEntropy K T η) := by
      unfold shannonEntropy shannonExt
      refine continuous_const.mul (continuous_finset_sum Finset.univ fun j _ => ?_)
      have hc : Continuous (fun q : UL.Simplex K => q.1 j + η) :=
        ((EuclideanSpace.proj (𝕜 := ℝ) j).continuous.comp continuous_subtype_val).add
          continuous_const
      refine hc.mul (hc.log fun q => ?_)
      have hnn : 0 ≤ q.1 j := q.2.1 j
      exact (by linarith only [hnn, hη] : 0 < q.1 j + η).ne'
    refine ⟨hβ, hcont, ?_, strongConvex_shannonEntropy hK hβ hT hη⟩
    intro J _hJ p hp
    let g₀ : EuclideanSpace ℝ (Fin K) := shannonRawGrad K T η p
    let g_J : EuclideanSpace ℝ (Fin K) :=
      ((UL.FaceTangentSpace K J).orthogonalProjection g₀ : EuclideanSpace ℝ (Fin K))
    refine ⟨g_J, Submodule.coe_mem _, ?_⟩
    have hp_open : p ∈ shannonOpenDomain K η :=
      simplex_subset_shannonOpenDomain hη hp.1.1
    have hf0 : HasFDerivWithinAt (UL.extendSimplex (shannonEntropy K T η))
        (innerSL ℝ g₀) (UL.SimplexFace K J) p :=
      (hasFDerivAt_shannonExt hη hp_open).hasFDerivWithinAt.congr
        (fun x hx => UL.Proof_lem_A_5.extendSimplex_eq_of_mem (shannonEntropy K T η) hx.1)
        (UL.Proof_lem_A_5.extendSimplex_eq_of_mem (shannonEntropy K T η) hp.1.1)
    refine HasFDerivAtFilter.of_isLittleO ?_
    refine hf0.isLittleO.congr' ?_ (Filter.Eventually.of_forall fun _ => rfl)
    filter_upwards [self_mem_nhdsWithin] with q hq
    have hqp : q - p ∈ UL.FaceTangentSpace K J :=
      UL.Proof_cor_A_8.sub_mem_faceTangentSpace hp.1 hq
    have hinn : inner ℝ g_J (q - p) = inner ℝ g₀ (q - p) :=
      UL.Proof_cor_A_8.inner_orthProj_eq_of_mem (UL.FaceTangentSpace K J) g₀ (q - p) hqp
    simp only [innerSL_apply_apply, hinn]
  · -- Smooth extension on `U = shannonOpenDomain K η ∩ SimplexAffineHull K`
    let U : Set (EuclideanSpace ℝ (Fin K)) := shannonOpenDomain K η ∩ UL.SimplexAffineHull K
    refine ⟨U, shannonExt K T η, shannonGrad K T η,
      ⟨shannonOpenDomain K η, isOpen_shannonOpenDomain K η, rfl⟩,
      fun q hq => ⟨simplex_subset_shannonOpenDomain hη hq, hq.2⟩,
      fun _ => rfl,
      ⟨(convex_shannonOpenDomain K η).inter (convex_simplexAffineHull K),
        fun x hx y hy a b ha hb hab =>
          (convexOn_shannonExt_openDomain hT_pos.le hη).2 hx.1 hy.1 ha hb hab⟩,
      ?_, ?_⟩
    · intro q hq
      refine ⟨shannonGrad_mem_zeroSum (by omega) T η q, ?_⟩
      have hf0 : HasFDerivWithinAt (shannonExt K T η)
          (innerSL ℝ (shannonRawGrad K T η q)) U q :=
        (hasFDerivAt_shannonExt hη hq.1).hasFDerivWithinAt
      refine HasFDerivAtFilter.of_isLittleO ?_
      refine hf0.isLittleO.congr' ?_ (Filter.Eventually.of_forall fun _ => rfl)
      filter_upwards [self_mem_nhdsWithin] with x hx
      have hxq : x - q ∈ UL.ZeroSumSubspace K := by
        rw [UL.Proof_lem_A_5.mem_zeroSumSubspace_iff]
        have hx1 : ∑ j : Fin K, x j = 1 := hx.2
        have hq1 : ∑ j : Fin K, q j = 1 := hq.2
        simp only [PiLp.sub_apply, Finset.sum_sub_distrib, hx1, hq1, sub_self]
      simp only [innerSL_apply_apply, inner_shannonGrad_eq_rawGrad_of_zeroSum T η q (x - q) hxq]
    · have hraw_cont : ContinuousOn (shannonRawGrad K T η) U := by
        have hraw_eq : shannonRawGrad K T η = fun q =>
            ∑ j : Fin K, ((1 + (K : ℝ) * η) * T * (Real.log (q j + η) + 1)) •
              EuclideanSpace.single j (1 : ℝ) := by
          ext q i
          rw [← UL.Proof_lem_A_1.sum_smul_single (shannonRawGrad K T η q)]
          rfl
        rw [hraw_eq]
        refine continuousOn_finset_sum Finset.univ fun j _ => ?_
        have hc : ContinuousOn (fun q : EuclideanSpace ℝ (Fin K) => q j + η) U :=
          ((EuclideanSpace.proj (𝕜 := ℝ) j).continuous.continuousOn).add continuousOn_const
        have hlog : ContinuousOn (fun q : EuclideanSpace ℝ (Fin K) => Real.log (q j + η)) U :=
          hc.log fun q hq => (coord_add_eta_pos_of_mem hη hq.1 j).ne'
        exact (continuousOn_const.mul (hlog.add continuousOn_const)).smul continuousOn_const
      refine hraw_cont.sub (ContinuousOn.smul ?_ continuousOn_const)
      refine continuousOn_const.mul (continuousOn_finset_sum Finset.univ fun i _ => ?_)
      exact (EuclideanSpace.proj (𝕜 := ℝ) i).continuous.comp_continuousOn hraw_cont
  · -- `lam_η`-Lipschitzness of `simplexGrad (shannonEntropy K T η)` on `Simplex K`
    intro q hq q' hq'
    rw [simplexGrad_shannonEntropy hK hη hq, simplexGrad_shannonEntropy hK hη hq']
    let diffRaw : EuclideanSpace ℝ (Fin K) := shannonRawGrad K T η q - shannonRawGrad K T η q'
    have hproj_eq : shannonGrad K T η q - shannonGrad K T η q' =
        diffRaw - (((1 : ℝ) / (K : ℝ)) * ∑ i : Fin K, diffRaw i) • UL.onesVec K := by
      dsimp [shannonGrad, diffRaw]
      simp only [PiLp.sub_apply, Finset.sum_sub_distrib, mul_sub, sub_smul]
      abel
    rw [hproj_eq]
    refine (norm_projZeroSum_le (by omega) diffRaw).trans ?_
    have hsq : ‖diffRaw‖ ^ 2 ≤ (lam_η * ‖q - q'‖) ^ 2 := by
      rw [PiLp.norm_sq_eq_of_L2, mul_pow, PiLp.norm_sq_eq_of_L2, Finset.mul_sum]
      refine Finset.sum_le_sum fun j _ => ?_
      simp only [Real.norm_eq_abs, sq_abs, PiLp.sub_apply]
      have hcoord : |diffRaw j| ≤ lam_η * |q j - q' j| := by
        dsimp [diffRaw, shannonRawGrad]
        have hsub : (1 + (K : ℝ) * η) * T * (Real.log (q j + η) + 1) -
            (1 + (K : ℝ) * η) * T * (Real.log (q' j + η) + 1) =
            α * (Real.log (q j + η) - Real.log (q' j + η)) := by
          dsimp [α]; ring
        rw [hsub, abs_mul, abs_of_pos hα_pos]
        have hlog := abs_log_sub_log_le_div hη
          (by linarith only [hq.1 j] : η ≤ q j + η)
          (by linarith only [hq'.1 j] : η ≤ q' j + η)
        have hdiff_eq : (q j + η) - (q' j + η) = q j - q' j := by ring
        rw [hdiff_eq] at hlog
        calc α * |Real.log (q j + η) - Real.log (q' j + η)|
            ≤ α * (|q j - q' j| / η) := mul_le_mul_of_nonneg_left hlog hα_pos.le
          _ = lam_η * |q j - q' j| := by dsimp [lam_η]; ring
      have hsq_j := pow_le_pow_left₀ (abs_nonneg _) hcoord 2
      rwa [sq_abs, mul_pow, sq_abs] at hsq_j
    rw [← Real.sqrt_sq (norm_nonneg diffRaw),
      ← Real.sqrt_sq (mul_nonneg hlam_pos.le (norm_nonneg (q - q')))]
    exact Real.sqrt_le_sqrt hsq
  · -- `M_η` norm bound of `simplexGrad (shannonEntropy K T η)` on `Simplex K`
    intro q hq
    rw [simplexGrad_shannonEntropy hK hη hq]
    let logVec : EuclideanSpace ℝ (Fin K) :=
      (WithLp.equiv 2 (Fin K → ℝ)).symm fun j => α * Real.log (q j + η)
    have hgrad_eq : shannonGrad K T η q =
        logVec - (((1 : ℝ) / (K : ℝ)) * ∑ i : Fin K, logVec i) • UL.onesVec K := by
      ext j
      have hK_ne : (K : ℝ) ≠ 0 := by exact_mod_cast (by omega : K ≠ 0)
      dsimp [shannonGrad, shannonRawGrad, logVec, α]
      simp only [PiLp.sub_apply, PiLp.smul_apply, UL.onesVec, WithLp.equiv_symm_apply,
        smul_eq_mul, mul_one, mul_add, Finset.sum_add_distrib, Finset.sum_const,
        Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
      field_simp [hK_ne]
      ring
    rw [hgrad_eq]
    refine (norm_projZeroSum_le (by omega) logVec).trans ?_
    have hsq : ‖logVec‖ ^ 2 ≤ M_η ^ 2 := by
      rw [PiLp.norm_sq_eq_of_L2]
      have hterm : ∀ j : Fin K, ‖logVec j‖ ^ 2 ≤ (α * B_η) ^ 2 := by
        intro j
        rw [Real.norm_eq_abs, sq_abs]
        have hqj_nn : 0 ≤ q j := hq.1 j
        have hqj_le1 : q j ≤ 1 := by
          have hle := Finset.single_le_sum (fun i _ => hq.1 i) (Finset.mem_univ j)
          rwa [hq.2] at hle
        have hlog_lo : Real.log η ≤ Real.log (q j + η) :=
          Real.log_le_log hη (by linarith only [hqj_nn])
        have hlog_hi : Real.log (q j + η) ≤ Real.log (1 + η) :=
          Real.log_le_log (by linarith only [hqj_nn, hη]) (by linarith only [hqj_le1])
        have habs_log : |Real.log (q j + η)| ≤ B_η := by
          have h1 : -B_η ≤ Real.log η := by
            have hle : |Real.log η| ≤ max (|Real.log η|) (|Real.log (1 + η)|) := le_max_left _ _
            have hneg := neg_le_abs (Real.log η)
            dsimp [B_η]; linarith only [hle, hneg]
          have h2 : Real.log (1 + η) ≤ B_η := by
            have hle : |Real.log (1 + η)| ≤ max (|Real.log η|) (|Real.log (1 + η)|) :=
              le_max_right _ _
            have hpos := le_abs_self (Real.log (1 + η))
            dsimp [B_η]; linarith only [hle, hpos]
          exact abs_le.mpr ⟨le_trans h1 hlog_lo, le_trans hlog_hi h2⟩
        have hcoord : |logVec j| ≤ α * B_η := by
          dsimp [logVec]
          rw [abs_mul, abs_of_pos hα_pos]
          exact mul_le_mul_of_nonneg_left habs_log hα_pos.le
        have hsq_j := pow_le_pow_left₀ (abs_nonneg _) hcoord 2
        rwa [sq_abs] at hsq_j
      calc ∑ j : Fin K, ‖logVec j‖ ^ 2
          ≤ ∑ _j : Fin K, (α * B_η) ^ 2 := Finset.sum_le_sum fun j _ => hterm j
        _ = (K : ℝ) * (α * B_η) ^ 2 := by
            rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
        _ = M_η ^ 2 := by
            change (K : ℝ) * (α * B_η) ^ 2 = (Real.sqrt (K : ℝ) * α * B_η) ^ 2
            conv_rhs => rw [mul_assoc (Real.sqrt (K : ℝ)) α B_η, mul_pow, Real.sq_sqrt hK_pos.le]
    rw [← Real.sqrt_sq (norm_nonneg logVec), ← Real.sqrt_sq hM_pos.le]
    exact Real.sqrt_le_sqrt hsq

/-- Exact canonical loss identity on `Simplex K` for `shannonEntropy K T η`. -/
lemma finiteCanonicalLoss_shannonEntropy_eq {K : ℕ} (hK : 2 ≤ K)
    {β T η : ℝ} (hβ : 0 < β) (hT : (1 : ℝ) / (2 * β) ≤ T) (hη : 0 < η)
    {p : EuclideanSpace ℝ (Fin K)} (hp : p ∈ UL.Simplex K) (y : Fin K) :
    UL.finiteCanonicalLoss (shannonEntropy K T η) p y =
      (1 + (K : ℝ) * η) * T * (-Real.log (p y + η) - η * ∑ j : Fin K, Real.log (p j + η)) := by
  obtain ⟨lam_η, M_η, _, _, hmem⟩ := shannonEntropy_mem_smoothEntropyFamily hK hβ hT hη
  rw [UL.Proof_lem_C_2.finiteCanonicalLoss_eq hmem hp y,
    UL.Proof_lem_A_5.extendSimplex_eq_of_mem (shannonEntropy K T η) hp,
    simplexGrad_shannonEntropy hK hη hp]
  have hey : EuclideanSpace.single y (1 : ℝ) ∈ UL.Simplex K :=
    UL.Proof_lem_A_1.single_mem_simplex y
  have hzero : p - EuclideanSpace.single y (1 : ℝ) ∈ UL.ZeroSumSubspace K :=
    UL.Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex hp hey
  rw [real_inner_comm,
    inner_shannonGrad_eq_rawGrad_of_zeroSum T η p (p - EuclideanSpace.single y (1 : ℝ)) hzero]
  change -shannonExt K T η p +
      inner ℝ (shannonRawGrad K T η p) (p - EuclideanSpace.single y (1 : ℝ)) = _
  rw [inner_sub_right, UL.Proof_lem_A_1.inner_single_right]
  rw [UL.Proof_lem_A_1.inner_eq_sum]
  dsimp [shannonExt, shannonRawGrad]
  set α : ℝ := (1 + (K : ℝ) * η) * T
  have hpt : ∀ j : Fin K,
      α * (Real.log (p j + η) + 1) * p j - α * ((p j + η) * Real.log (p j + η)) =
        α * p j - α * η * Real.log (p j + η) := fun j => by ring
  have hsum_ident :
      ∑ j : Fin K, α * (Real.log (p j + η) + 1) * p j -
        α * ∑ j : Fin K, (p j + η) * Real.log (p j + η) =
      α * ∑ j : Fin K, p j - α * η * ∑ j : Fin K, Real.log (p j + η) := by
    rw [Finset.mul_sum, ← Finset.sum_sub_distrib]
    simp_rw [hpt, Finset.sum_sub_distrib, ← Finset.mul_sum]
  have hp_sum : α * ∑ j : Fin K, p j = α := by rw [hp.2, mul_one]
  linarith only [hsum_ident, hp_sum,
    show α * (-Real.log (p y + η) - η * ∑ j : Fin K, Real.log (p j + η)) =
      α - α * η * (∑ j : Fin K, Real.log (p j + η)) - α * (Real.log (p y + η) + 1) by ring]

/-- Gibbs upper bound on `matchingLoss (shannonEntropy K T η)` for zero-sum score vectors. -/
lemma matchingLoss_shannonEntropy_div_le {K : ℕ} (hK : 2 ≤ K)
    {β T η : ℝ} (hβ : 0 < β) (hT : (1 : ℝ) / (2 * β) ≤ T) (hη : 0 < η)
    (a : UL.ZeroSumSubspace K) (y : Fin K) :
    let α : ℝ := (1 + (K : ℝ) * η) * T
    UL.matchingLoss (shannonEntropy K T η) (a : EuclideanSpace ℝ (Fin K)) y /
        (1 + (K : ℝ) * η) ≤
      α * Real.log (∑ j : Fin K, Real.exp ((a : EuclideanSpace ℝ (Fin K)) j / α)) -
        (a : EuclideanSpace ℝ (Fin K)) y / (1 + (K : ℝ) * η) := by
  intro α
  have hT_pos : 0 < T := lt_of_lt_of_le (by positivity) hT
  have hK_pos : (0 : ℝ) < (K : ℝ) := by exact_mod_cast (by omega : 0 < K)
  have h1Kη_pos : 0 < 1 + (K : ℝ) * η := by positivity
  have hα_pos : 0 < α := mul_pos h1Kη_pos hT_pos
  have ha_sum : ∑ j : Fin K, (a : EuclideanSpace ℝ (Fin K)) j = 0 :=
    (UL.Proof_lem_A_5.mem_zeroSumSubspace_iff K (a : EuclideanSpace ℝ (Fin K))).mp a.2
  have hu_orth : inner ℝ (UL.uniformVec K) (a : EuclideanSpace ℝ (Fin K)) = 0 :=
    UL.Proof_lem_C_2.inner_uniformVec_zero_of_mem_zeroSum a.2
  set partitionSum : ℝ := ∑ j : Fin K, Real.exp ((a : EuclideanSpace ℝ (Fin K)) j / α)
  have hZ_pos : 0 < partitionSum :=
    Finset.sum_pos (fun j _ => Real.exp_pos _) ⟨⟨0, by omega⟩, Finset.mem_univ _⟩
  haveI : Nonempty (UL.Simplex K) :=
    ⟨⟨UL.uniformVec K, UL.Proof_lem_A_5.uniformVec_mem_simplex hK⟩⟩
  have hpot_le : UL.matchingPotential (shannonEntropy K T η) (a : EuclideanSpace ℝ (Fin K)) ≤
      (1 + (K : ℝ) * η) * α * Real.log partitionSum := by
    unfold UL.matchingPotential
    refine ciSup_le fun q => ?_
    let w : Fin K → ℝ := fun j => (q.1 j + η) / (1 + (K : ℝ) * η)
    let π : Fin K → ℝ := fun j => Real.exp ((a : EuclideanSpace ℝ (Fin K)) j / α) / partitionSum
    have hw_pos : ∀ j : Fin K, 0 < w j := fun j => by
      have hnn : 0 ≤ q.1 j := q.2.1 j
      exact div_pos (by linarith only [hnn, hη]) h1Kη_pos
    have hπ_pos : ∀ j : Fin K, 0 < π j := fun j => div_pos (Real.exp_pos _) hZ_pos
    have hw_sum : ∑ j : Fin K, w j = 1 := by
      dsimp [w]
      rw [← Finset.sum_div, Finset.sum_add_distrib, q.2.2, Finset.sum_const, Finset.card_univ,
        Fintype.card_fin, nsmul_eq_mul, div_self h1Kη_pos.ne']
    have hπ_sum : ∑ j : Fin K, π j = 1 := by
      dsimp [π]
      rw [← Finset.sum_div, div_self hZ_pos.ne']
    have hkl_nonpos : ∑ j : Fin K, w j * Real.log (π j / w j) ≤ 0 := by
      have hterm : ∀ j : Fin K, w j * Real.log (π j / w j) ≤ π j - w j := by
        intro j
        have h1 := Real.log_le_sub_one_of_pos (div_pos (hπ_pos j) (hw_pos j))
        have hm := mul_le_mul_of_nonneg_left h1 (hw_pos j).le
        have hrew : w j * (π j / w j - 1) = π j - w j := by
          field_simp [(hw_pos j).ne']
        linarith only [hm, hrew]
      calc ∑ j : Fin K, w j * Real.log (π j / w j)
          ≤ ∑ j : Fin K, (π j - w j) := Finset.sum_le_sum fun j _ => hterm j
        _ = ∑ j : Fin K, π j - ∑ j : Fin K, w j := Finset.sum_sub_distrib _ _
        _ = 0 := by rw [hπ_sum, hw_sum, sub_self]
    have hmul_kl := mul_le_mul_of_nonneg_left hkl_nonpos (mul_pos h1Kη_pos hα_pos).le
    rw [mul_zero] at hmul_kl
    have hident :
        ((1 + (K : ℝ) * η) * α) * ∑ j : Fin K, w j * Real.log (π j / w j) =
          (inner ℝ (q.1 - UL.uniformVec K) (a : EuclideanSpace ℝ (Fin K)) -
            shannonEntropy K T η q) -
          (1 + (K : ℝ) * η) * α * Real.log partitionSum +
          (1 + (K : ℝ) * η) * α * Real.log (1 + (K : ℝ) * η) := by
      rw [inner_sub_left, hu_orth, sub_zero, UL.Proof_lem_A_1.inner_eq_sum]
      have h1 : ((1 + (K : ℝ) * η) * α) * ∑ j : Fin K, w j * Real.log (π j / w j) =
          ∑ j : Fin K, (q.1 j + η) * (α * Real.log (π j / w j)) := by
        rw [Finset.mul_sum]
        refine Finset.sum_congr rfl fun j _ => ?_
        dsimp [w]
        field_simp [h1Kη_pos.ne']
      rw [h1]
      have hlog_j : ∀ j : Fin K,
          α * Real.log (π j / w j) =
            (a : EuclideanSpace ℝ (Fin K)) j - α * Real.log partitionSum -
              α * Real.log (q.1 j + η) + α * Real.log (1 + (K : ℝ) * η) := by
        intro j
        have hqj_pos : 0 < q.1 j + η := by
          have hnn : 0 ≤ q.1 j := q.2.1 j
          linarith only [hnn, hη]
        rw [Real.log_div (hπ_pos j).ne' (hw_pos j).ne']
        dsimp [π, w]
        rw [Real.log_div (Real.exp_pos _).ne' hZ_pos.ne', Real.log_exp,
          Real.log_div hqj_pos.ne' h1Kη_pos.ne']
        field_simp [hα_pos.ne']
        ring
      simp_rw [hlog_j]
      have hq_eta_sum : ∑ j : Fin K, (q.1 j + η) = 1 + (K : ℝ) * η := by
        rw [Finset.sum_add_distrib, q.2.2, Finset.sum_const, Finset.card_univ,
          Fintype.card_fin, nsmul_eq_mul]
      have hqa_sum : ∑ j : Fin K, (q.1 j + η) * (a : EuclideanSpace ℝ (Fin K)) j =
          ∑ j : Fin K, q.1 j * (a : EuclideanSpace ℝ (Fin K)) j := by
        simp_rw [add_mul, Finset.sum_add_distrib, ← Finset.mul_sum, ha_sum, mul_zero, add_zero]
      have hsh : shannonEntropy K T η q =
          ∑ j : Fin K, (q.1 j + η) * (α * Real.log (q.1 j + η)) := by
        dsimp [shannonEntropy, shannonExt, α]
        rw [Finset.mul_sum]
        refine Finset.sum_congr rfl fun j _ => ?_
        ring
      rw [hsh]
      simp_rw [mul_add, mul_sub, Finset.sum_add_distrib, Finset.sum_sub_distrib,
        ← Finset.sum_mul, hq_eta_sum, hqa_sum]
      ring
    have hlog1Kη_nn : 0 ≤ (1 + (K : ℝ) * η) * α * Real.log (1 + (K : ℝ) * η) := by
      have hl : 0 ≤ Real.log (1 + (K : ℝ) * η) :=
        Real.log_nonneg (by linarith only [mul_pos hK_pos hη])
      positivity
    linarith only [hmul_kl, hident, hlog1Kη_nn]
  unfold UL.matchingLoss
  rw [sub_div]
  have hdiv := div_le_div_of_nonneg_right hpot_le h1Kη_pos.le
  have hcancel : (1 + (K : ℝ) * η) * α * Real.log partitionSum / (1 + (K : ℝ) * η) = α * Real.log partitionSum := by
    field_simp [h1Kη_pos.ne']
  linarith only [hdiv, hcancel]

/-- Limit `η_m → 0` bridge from smooth-entropy empirical optimality (with arbitrary additive slack
`gam`) to the smoothed empirical log-loss bound against any score vector `a : Fin n → H`. -/
theorem empirical_smoothed_log_bound
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {β T τ gam : ℝ} (hβ : 0 < β) (hT : (1 : ℝ) / (2 * β) ≤ T)
    (hτ_pos : 0 < τ) (hτ_half : τ ≤ (1 : ℝ) / 2)
    (p : Fin n → EuclideanSpace ℝ (Fin K)) (hp : ∀ i : Fin n, p i ∈ UL.Simplex K)
    (y : Fin n → Fin K)
    (a : Fin n → UL.ZeroSumSubspace K)
    (h_emp : ∀ (lam' M' : ℝ), 0 < lam' → 0 < M' →
      ∀ Φ ∈ UL.SmoothEntropyFamily K β lam' M',
        (1 / (n : ℝ)) * ∑ i : Fin n, UL.finiteCanonicalLoss Φ (p i) (y i) ≤
          (1 / (n : ℝ)) * ∑ i : Fin n,
            UL.matchingLoss Φ (a i : EuclideanSpace ℝ (Fin K)) (y i) + gam) :
    let p_τ : Fin n → EuclideanSpace ℝ (Fin K) :=
      fun i => (1 - τ) • p i + τ • UL.uniformVec K
    (1 / (n : ℝ)) * ∑ i : Fin n, (-T * Real.log (p_τ i (y i))) ≤
      (1 / (n : ℝ)) * ∑ i : Fin n,
        (T * Real.log (∑ j : Fin K, Real.exp ((a i : EuclideanSpace ℝ (Fin K)) j / T)) -
          (a i : EuclideanSpace ℝ (Fin K)) (y i)) + gam + 2 * T * τ := by
  intro p_τ
  have hT_pos : 0 < T := lt_of_lt_of_le (by positivity) hT
  have hK_pos : (0 : ℝ) < (K : ℝ) := by exact_mod_cast (by omega : 0 < K)
  have hn_pos : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hn
  have h1mτ_pos : 0 < 1 - τ := by linarith only [hτ_half]
  let rhsFn : ℝ → ℝ := fun η =>
    (1 / (n : ℝ)) *
        (∑ i : Fin n,
          ((1 + (K : ℝ) * η) * T *
              Real.log (∑ j : Fin K,
                Real.exp ((a i : EuclideanSpace ℝ (Fin K)) j / ((1 + (K : ℝ) * η) * T))) -
            (a i : EuclideanSpace ℝ (Fin K)) (y i) / (1 + (K : ℝ) * η))) +
      gam / (1 + (K : ℝ) * η) + T * (K : ℝ) * η ^ 2 + 2 * T * τ
  let ηSeq : ℕ → ℝ := fun m => (τ / (K : ℝ)) / ((m : ℝ) + 1)
  have h_le_seq : ∀ m : ℕ,
      (1 / (n : ℝ)) * ∑ i : Fin n, (-T * Real.log (p_τ i (y i))) ≤ rhsFn (ηSeq m) := by
    intro m
    set η : ℝ := ηSeq m
    have hm1_pos : (0 : ℝ) < (m : ℝ) + 1 := by positivity
    have hη_pos : 0 < η := div_pos (div_pos hτ_pos hK_pos) hm1_pos
    have hη_le_τK : η ≤ τ / (K : ℝ) :=
      div_le_self (div_nonneg hτ_pos.le hK_pos.le) (by linarith only [Nat.cast_nonneg (α := ℝ) m])
    have h1Kη_pos : 0 < 1 + (K : ℝ) * η := by positivity
    obtain ⟨lam_η, M_η, hlam_η, hM_η, hmem_η⟩ :=
      shannonEntropy_mem_smoothEntropyFamily hK hβ hT hη_pos
    have hemp_m := h_emp lam_η M_η hlam_η hM_η (shannonEntropy K T η) hmem_η
    have hpt_lb : ∀ i : Fin n,
        -T * Real.log (p_τ i (y i)) ≤
          UL.finiteCanonicalLoss (shannonEntropy K T η) (p i) (y i) / (1 + (K : ℝ) * η) +
            T * (K : ℝ) * η ^ 2 + 2 * T * τ := by
      intro i
      have hpi_nn : 0 ≤ p i (y i) := (hp i).1 (y i)
      have hu_y : UL.uniformVec K (y i) = (1 : ℝ) / (K : ℝ) := by
        simp [UL.uniformVec, UL.onesVec]
      have hpτ_eq : p_τ i (y i) = (1 - τ) * p i (y i) + τ / (K : ℝ) := by
        change ((1 - τ) • p i + τ • UL.uniformVec K) (y i) = _
        simp only [PiLp.add_apply, PiLp.smul_apply, smul_eq_mul, hu_y]
        ring
      have hpτ_ge : (1 - τ) * (p i (y i) + η) ≤ p_τ i (y i) := by
        rw [hpτ_eq]
        have h1 : (1 - τ) * η ≤ τ / (K : ℝ) := by
          calc (1 - τ) * η ≤ 1 * (τ / (K : ℝ)) :=
                mul_le_mul (by linarith only [hτ_pos]) hη_le_τK hη_pos.le zero_le_one
            _ = τ / (K : ℝ) := one_mul _
        linarith only [h1, show (1 - τ) * (p i (y i) + η) =
          (1 - τ) * p i (y i) + (1 - τ) * η by ring]
      have hprod_pos : 0 < (1 - τ) * (p i (y i) + η) :=
        mul_pos h1mτ_pos (by linarith only [hpi_nn, hη_pos])
      have hlog_ge : Real.log ((1 - τ) * (p i (y i) + η)) ≤ Real.log (p_τ i (y i)) :=
        Real.log_le_log hprod_pos hpτ_ge
      rw [Real.log_mul h1mτ_pos.ne' (by linarith only [hpi_nn, hη_pos])] at hlog_ge
      have hneg_T : -T * Real.log (p_τ i (y i)) ≤
          -T * Real.log (p i (y i) + η) + T * (-Real.log (1 - τ)) := by
        have hm := mul_le_mul_of_nonneg_left hlog_ge hT_pos.le
        linarith only [hm]
      have hτ_term : T * (-Real.log (1 - τ)) ≤ 2 * T * τ := by
        have hm := mul_le_mul_of_nonneg_left (neg_log_one_sub_le_two_mul hτ_pos hτ_half) hT_pos.le
        linarith only [hm]
      have hloss_eq := finiteCanonicalLoss_shannonEntropy_eq hK hβ hT hη_pos (hp i) (y i)
      have hloss_div :
          UL.finiteCanonicalLoss (shannonEntropy K T η) (p i) (y i) / (1 + (K : ℝ) * η) =
            -T * Real.log (p i (y i) + η) - T * η * ∑ j : Fin K, Real.log (p i j + η) := by
        rw [hloss_eq]
        field_simp [h1Kη_pos.ne']
      have hsum_log_le : ∑ j : Fin K, Real.log (p i j + η) ≤ (K : ℝ) * η := by
        have hj_le : ∀ j : Fin K, Real.log (p i j + η) ≤ η := by
          intro j
          have hpj_nn : 0 ≤ p i j := (hp i).1 j
          have hpj_le1 : p i j ≤ 1 := by
            have hle := Finset.single_le_sum (fun r _ => (hp i).1 r) (Finset.mem_univ j)
            rwa [(hp i).2] at hle
          have hl1 : Real.log (p i j + η) ≤ Real.log (1 + η) :=
            Real.log_le_log (by linarith only [hpj_nn, hη_pos]) (by linarith only [hpj_le1])
          have hl2 := Real.log_le_sub_one_of_pos (by linarith only [hη_pos] : 0 < 1 + η)
          linarith only [hl1, hl2]
        calc ∑ j : Fin K, Real.log (p i j + η)
            ≤ ∑ _j : Fin K, η := Finset.sum_le_sum fun j _ => hj_le j
          _ = (K : ℝ) * η := by
              rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
      have hrem_le : T * η * ∑ j : Fin K, Real.log (p i j + η) ≤ T * (K : ℝ) * η ^ 2 := by
        have hm := mul_le_mul_of_nonneg_left hsum_log_le (mul_pos hT_pos hη_pos).le
        linarith only [hm, show T * η * ((K : ℝ) * η) = T * (K : ℝ) * η ^ 2 by ring]
      linarith only [hneg_T, hτ_term, hloss_div, hrem_le]
    have havg_lb :
        (1 / (n : ℝ)) * ∑ i : Fin n, (-T * Real.log (p_τ i (y i))) ≤
          ((1 / (n : ℝ)) * ∑ i : Fin n,
            UL.finiteCanonicalLoss (shannonEntropy K T η) (p i) (y i)) / (1 + (K : ℝ) * η) +
            T * (K : ℝ) * η ^ 2 + 2 * T * τ := by
      have hsum := Finset.sum_le_sum fun i (_ : i ∈ Finset.univ) => hpt_lb i
      have hmul := mul_le_mul_of_nonneg_left hsum (by positivity : (0 : ℝ) ≤ 1 / (n : ℝ))
      simp only [Finset.sum_add_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
        nsmul_eq_mul, ← Finset.sum_div] at hmul
      have hrew :
          (1 / (n : ℝ)) *
              ((∑ i : Fin n, UL.finiteCanonicalLoss (shannonEntropy K T η) (p i) (y i)) /
                (1 + (K : ℝ) * η) +
                (n : ℝ) * (T * (K : ℝ) * η ^ 2) + (n : ℝ) * (2 * T * τ)) =
            ((1 / (n : ℝ)) * ∑ i : Fin n,
              UL.finiteCanonicalLoss (shannonEntropy K T η) (p i) (y i)) / (1 + (K : ℝ) * η) +
              T * (K : ℝ) * η ^ 2 + 2 * T * τ := by
        field_simp [hn_pos.ne', h1Kη_pos.ne']
      linarith only [hmul, hrew]
    have hemp_div :
        ((1 / (n : ℝ)) * ∑ i : Fin n,
          UL.finiteCanonicalLoss (shannonEntropy K T η) (p i) (y i)) / (1 + (K : ℝ) * η) ≤
          (1 / (n : ℝ)) * (∑ i : Fin n,
            UL.matchingLoss (shannonEntropy K T η) (a i : EuclideanSpace ℝ (Fin K)) (y i) /
              (1 + (K : ℝ) * η)) + gam / (1 + (K : ℝ) * η) := by
      have hd := div_le_div_of_nonneg_right hemp_m h1Kη_pos.le
      rw [add_div] at hd
      have hrew : ((1 / (n : ℝ)) * ∑ i : Fin n,
          UL.matchingLoss (shannonEntropy K T η) (a i : EuclideanSpace ℝ (Fin K)) (y i)) /
          (1 + (K : ℝ) * η) =
          (1 / (n : ℝ)) * ∑ i : Fin n,
            (UL.matchingLoss (shannonEntropy K T η) (a i : EuclideanSpace ℝ (Fin K)) (y i) /
              (1 + (K : ℝ) * η)) := by
        rw [← Finset.sum_div]
        ring
      linarith only [hd, hrew]
    have hgibbs_sum :
        (1 / (n : ℝ)) * (∑ i : Fin n,
          UL.matchingLoss (shannonEntropy K T η) (a i : EuclideanSpace ℝ (Fin K)) (y i) /
            (1 + (K : ℝ) * η)) ≤
          (1 / (n : ℝ)) * ∑ i : Fin n,
            ((1 + (K : ℝ) * η) * T *
                Real.log (∑ j : Fin K,
                  Real.exp ((a i : EuclideanSpace ℝ (Fin K)) j / ((1 + (K : ℝ) * η) * T))) -
              (a i : EuclideanSpace ℝ (Fin K)) (y i) / (1 + (K : ℝ) * η)) := by
      refine mul_le_mul_of_nonneg_left (Finset.sum_le_sum fun i _ => ?_) (by positivity)
      exact matchingLoss_shannonEntropy_div_le hK hβ hT hη_pos (a i) (y i)
    dsimp [rhsFn]
    linarith only [havg_lb, hemp_div, hgibbs_sum]
  have hη_tendsto : Filter.Tendsto ηSeq Filter.atTop (nhds 0) :=
    tendsto_const_nhds.div_atTop
      (Filter.tendsto_atTop_add_const_right Filter.atTop 1 tendsto_natCast_atTop_atTop)
  have hrhs_cont : ContinuousAt rhsFn 0 := by
    have h1_ne : (1 : ℝ) + (K : ℝ) * 0 ≠ 0 := by norm_num
    have hα0_ne : ((1 : ℝ) + (K : ℝ) * 0) * T ≠ 0 := by simp [hT_pos.ne']
    have hc_1Kη : ContinuousAt (fun η : ℝ => 1 + (K : ℝ) * η) 0 :=
      continuousAt_const.add (continuousAt_const.mul continuousAt_id)
    have hc_α : ContinuousAt (fun η : ℝ => (1 + (K : ℝ) * η) * T) 0 :=
      hc_1Kη.mul continuousAt_const
    have hc_sum : ContinuousAt
        (fun η : ℝ => ∑ i : Fin n,
          ((1 + (K : ℝ) * η) * T *
              Real.log (∑ j : Fin K,
                Real.exp ((a i : EuclideanSpace ℝ (Fin K)) j / ((1 + (K : ℝ) * η) * T))) -
            (a i : EuclideanSpace ℝ (Fin K)) (y i) / (1 + (K : ℝ) * η))) 0 := by
      refine tendsto_finset_sum Finset.univ fun i _ => ?_
      have hZ0_pos : 0 < ∑ j : Fin K,
          Real.exp ((a i : EuclideanSpace ℝ (Fin K)) j / (((1 : ℝ) + (K : ℝ) * 0) * T)) :=
        Finset.sum_pos (fun j _ => Real.exp_pos _) ⟨⟨0, by omega⟩, Finset.mem_univ _⟩
      have hc_Z : ContinuousAt
          (fun η : ℝ => ∑ j : Fin K,
            Real.exp ((a i : EuclideanSpace ℝ (Fin K)) j / ((1 + (K : ℝ) * η) * T))) 0 :=
        tendsto_finset_sum Finset.univ fun j _ =>
          Real.continuous_exp.continuousAt.comp (continuousAt_const.div hc_α hα0_ne)
      exact (hc_α.mul (hc_Z.log hZ0_pos.ne')).sub
        (continuousAt_const.div hc_1Kη h1_ne)
    exact ((((continuousAt_const.mul hc_sum).add (continuousAt_const.div hc_1Kη h1_ne)).add
      (continuousAt_const.mul (continuousAt_id.pow 2))).add continuousAt_const)
  have hrhs_tendsto : Filter.Tendsto (rhsFn ∘ ηSeq) Filter.atTop (nhds (rhsFn 0)) :=
    hrhs_cont.tendsto.comp hη_tendsto
  have hlim := le_of_tendsto_of_tendsto tendsto_const_nhds hrhs_tendsto
    (Filter.Eventually.of_forall h_le_seq)
  have hrhs0 : rhsFn 0 =
      (1 / (n : ℝ)) * ∑ i : Fin n,
        (T * Real.log (∑ j : Fin K, Real.exp ((a i : EuclideanSpace ℝ (Fin K)) j / T)) -
          (a i : EuclideanSpace ℝ (Fin K)) (y i)) + gam + 2 * T * τ := by
    dsimp [rhsFn]
    simp
  rwa [hrhs0] at hlim

/-! ### 3. Smoothing bias, forecast perturbation, and `ZeroSumSubspace` convex potentials -/

/-- Pointwise smooth-entropy smoothing bias:
`L_Φ((1 - τ) p + τ u, y) - L_Φ(p, y) ≤ √2 * lam * τ`. -/
lemma smooth_entropy_smoothing_bias {K : ℕ} (hK : 2 ≤ K)
    {β lam M τ : ℝ} {Φ : UL.Simplex K → ℝ}
    (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    (hτ_pos : 0 < τ) (hτ_half : τ ≤ (1 : ℝ) / 2)
    {p : EuclideanSpace ℝ (Fin K)} (hp : p ∈ UL.Simplex K) (y : Fin K) :
    let p_τ : EuclideanSpace ℝ (Fin K) := (1 - τ) • p + τ • UL.uniformVec K
    UL.finiteCanonicalLoss Φ p_τ y - UL.finiteCanonicalLoss Φ p y ≤
      Real.sqrt 2 * lam * τ := by
  intro p_τ
  have hlam_pos : 0 < lam := hΦ.2.1
  have hu : UL.uniformVec K ∈ UL.Simplex K := UL.Proof_lem_A_5.uniformVec_mem_simplex hK
  have hpτ : p_τ ∈ UL.Simplex K :=
    UL.Proof_lem_A_5.convex_simplex K hp hu (by linarith only [hτ_half]) hτ_pos.le (by ring)
  rw [UL.Proof_lem_C_2.finiteCanonicalLoss_eq hΦ hpτ y,
    UL.Proof_lem_C_2.finiteCanonicalLoss_eq hΦ hp y]
  have hConv := UL.Proof_lem_C_2.extendSimplex_convex_of_smooth hΦ
  have hGrad := UL.Proof_lem_C_2.hasFaceGradAt_univ_simplexGrad hΦ hp
  have hp_face : p ∈ UL.SimplexFace K Finset.univ := by
    rwa [UL.Proof_lem_A_5.simplexFace_univ K]
  have hpτ_face : p_τ ∈ UL.SimplexFace K Finset.univ := by
    rwa [UL.Proof_lem_A_5.simplexFace_univ K]
  have hsubgrad := UL.Proof_lem_A_1.face_subgrad_ineq hConv hp_face hpτ_face hGrad.2
  rw [real_inner_comm] at hsubgrad
  let ey : EuclideanSpace ℝ (Fin K) := EuclideanSpace.single y (1 : ℝ)
  have hey : ey ∈ UL.Simplex K := UL.Proof_lem_A_1.single_mem_simplex y
  have hcomb_inner :
      inner ℝ (p_τ - p) (UL.simplexGrad Φ p) + inner ℝ (p - ey) (UL.simplexGrad Φ p) =
        inner ℝ (p_τ - ey) (UL.simplexGrad Φ p) := by
    rw [← inner_add_left]
    have hadd : (p_τ - p) + (p - ey) = p_τ - ey := by abel
    rw [hadd]
  have hub1 :
      (-UL.extendSimplex Φ p_τ + inner ℝ (p_τ - ey) (UL.simplexGrad Φ p_τ)) -
        (-UL.extendSimplex Φ p + inner ℝ (p - ey) (UL.simplexGrad Φ p)) ≤
      inner ℝ (p_τ - ey) (UL.simplexGrad Φ p_τ - UL.simplexGrad Φ p) := by
    rw [inner_sub_right]
    linarith only [hsubgrad, hcomb_inner]
  have hnorm_ey : ‖p_τ - ey‖ ≤ Real.sqrt 2 :=
    norm_sub_le_sqrt_two_of_mem_simplex hpτ hey
  have hpτ_sub_p : p_τ - p = τ • (UL.uniformVec K - p) := by
    dsimp [p_τ]
    rw [sub_smul, one_smul, smul_sub]
    abel
  have hnorm_pu : ‖p_τ - p‖ ≤ τ := by
    rw [hpτ_sub_p, norm_smul, Real.norm_eq_abs, abs_of_pos hτ_pos, norm_sub_rev]
    have hpu_le1 : ‖p - UL.uniformVec K‖ ≤ 1 := by
      have horth : inner ℝ (p - UL.uniformVec K) (UL.uniformVec K) = 0 := by
        rw [real_inner_comm]
        exact UL.Proof_lem_C_2.inner_uniformVec_zero_of_mem_zeroSum
          (UL.Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex hp hu)
      have hadd : (p - UL.uniformVec K) + UL.uniformVec K = p := sub_add_cancel _ _
      have hpyth := norm_add_sq_real (p - UL.uniformVec K) (UL.uniformVec K)
      rw [hadd, horth] at hpyth
      have hp_le1 : ‖p‖ ≤ 1 := UL.Proof_lem_A_5.norm_le_one_of_mem_simplex hp
      have hp_sq : ‖p‖ ^ 2 ≤ 1 := by
        have h0 := norm_nonneg p
        nlinarith only [hp_le1, h0]
      have hu_sq : 0 ≤ ‖UL.uniformVec K‖ ^ 2 := sq_nonneg _
      have hsub_sq : ‖p - UL.uniformVec K‖ ^ 2 ≤ 1 := by linarith only [hpyth, hp_sq, hu_sq]
      rw [← Real.sqrt_sq (norm_nonneg (p - UL.uniformVec K)), ← Real.sqrt_one]
      exact Real.sqrt_le_sqrt hsub_sq
    linarith only [mul_le_mul_of_nonneg_left hpu_le1 hτ_pos.le, mul_one τ]
  have hgrad_lip : ‖UL.simplexGrad Φ p_τ - UL.simplexGrad Φ p‖ ≤ lam * τ :=
    (hΦ.2.2.2.2.1 p_τ hpτ p hp).trans (mul_le_mul_of_nonneg_left hnorm_pu hlam_pos.le)
  calc (-UL.extendSimplex Φ p_τ + inner ℝ (p_τ - ey) (UL.simplexGrad Φ p_τ)) -
          (-UL.extendSimplex Φ p + inner ℝ (p - ey) (UL.simplexGrad Φ p))
      ≤ inner ℝ (p_τ - ey) (UL.simplexGrad Φ p_τ - UL.simplexGrad Φ p) := hub1
    _ ≤ ‖p_τ - ey‖ * ‖UL.simplexGrad Φ p_τ - UL.simplexGrad Φ p‖ := real_inner_le_norm _ _
    _ ≤ Real.sqrt 2 * (lam * τ) :=
        mul_le_mul hnorm_ey hgrad_lip (norm_nonneg _) (Real.sqrt_nonneg 2)
    _ = Real.sqrt 2 * lam * τ := by ring

/-- Forecast perturbation bound for smooth canonical losses on `Simplex K`. -/
lemma smooth_loss_forecast_perturbation {K : ℕ} (hK : 2 ≤ K)
    {β lam M : ℝ} {Φ : UL.Simplex K → ℝ}
    (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    {p₁ p₂ : EuclideanSpace ℝ (Fin K)} (hp₁ : p₁ ∈ UL.Simplex K) (hp₂ : p₂ ∈ UL.Simplex K)
    (y : Fin K) :
    |UL.finiteCanonicalLoss Φ p₁ y - UL.finiteCanonicalLoss Φ p₂ y| ≤ 3 * lam * ‖p₁ - p₂‖ := by
  calc |UL.finiteCanonicalLoss Φ p₁ y - UL.finiteCanonicalLoss Φ p₂ y|
      ≤ 3 * ‖UL.simplexGrad Φ p₁ - UL.simplexGrad Φ p₂‖ :=
        UL.Proof_thm_C_1_Race3.matchingLoss_lipschitz_three (by omega) hΦ.1.2.1 _ _ y
    _ ≤ 3 * (lam * ‖p₁ - p₂‖) :=
        mul_le_mul_of_nonneg_left (hΦ.2.2.2.2.1 p₁ hp₁ p₂ hp₂) (by norm_num)
    _ = 3 * lam * ‖p₁ - p₂‖ := by ring

/-- Forecast perturbation bound for smoothed log loss `-T * Real.log (p_τ y)`. -/
lemma smoothed_log_forecast_perturbation {K : ℕ} (hK : 2 ≤ K)
    {T τ : ℝ} (hT_pos : 0 < T) (hτ_pos : 0 < τ) (hτ_half : τ ≤ (1 : ℝ) / 2)
    {p₁ p₂ : EuclideanSpace ℝ (Fin K)} (hp₁ : p₁ ∈ UL.Simplex K) (hp₂ : p₂ ∈ UL.Simplex K)
    (y : Fin K) :
    let p₁_τ : EuclideanSpace ℝ (Fin K) := (1 - τ) • p₁ + τ • UL.uniformVec K
    let p₂_τ : EuclideanSpace ℝ (Fin K) := (1 - τ) • p₂ + τ • UL.uniformVec K
    |(-T * Real.log (p₁_τ y)) - (-T * Real.log (p₂_τ y))| ≤
      ((K : ℝ) * T / τ) * ‖p₁ - p₂‖ := by
  intro p₁_τ p₂_τ
  have hK_pos : (0 : ℝ) < (K : ℝ) := by exact_mod_cast (by omega : 0 < K)
  have h1mτ_nn : 0 ≤ 1 - τ := by linarith only [hτ_half]
  have h1mτ_le1 : 1 - τ ≤ 1 := by linarith only [hτ_pos]
  have hu_y : UL.uniformVec K y = (1 : ℝ) / (K : ℝ) := by
    simp [UL.uniformVec, UL.onesVec]
  have hlb₁ : τ / (K : ℝ) ≤ p₁_τ y := by
    have hnn : 0 ≤ (1 - τ) * p₁ y := mul_nonneg h1mτ_nn (hp₁.1 y)
    change τ / (K : ℝ) ≤ ((1 - τ) • p₁ + τ • UL.uniformVec K) y
    simp only [PiLp.add_apply, PiLp.smul_apply, smul_eq_mul, hu_y]
    linarith only [hnn, show τ * ((1 : ℝ) / (K : ℝ)) = τ / (K : ℝ) by ring]
  have hlb₂ : τ / (K : ℝ) ≤ p₂_τ y := by
    have hnn : 0 ≤ (1 - τ) * p₂ y := mul_nonneg h1mτ_nn (hp₂.1 y)
    change τ / (K : ℝ) ≤ ((1 - τ) • p₂ + τ • UL.uniformVec K) y
    simp only [PiLp.add_apply, PiLp.smul_apply, smul_eq_mul, hu_y]
    linarith only [hnn, show τ * ((1 : ℝ) / (K : ℝ)) = τ / (K : ℝ) by ring]
  have hsub_rew : (-T * Real.log (p₁_τ y)) - (-T * Real.log (p₂_τ y)) =
      -T * (Real.log (p₁_τ y) - Real.log (p₂_τ y)) := by ring
  rw [hsub_rew, abs_mul, abs_neg, abs_of_pos hT_pos]
  have hlog := abs_log_sub_log_le_div (div_pos hτ_pos hK_pos) hlb₁ hlb₂
  have hcoord : |p₁_τ y - p₂_τ y| ≤ ‖p₁ - p₂‖ := by
    have hdiff : p₁_τ y - p₂_τ y = (1 - τ) * (p₁ y - p₂ y) := by
      dsimp [p₁_τ, p₂_τ]; ring
    rw [hdiff, abs_mul, abs_of_nonneg h1mτ_nn]
    have hpy : |p₁ y - p₂ y| ≤ ‖p₁ - p₂‖ := by
      simpa [PiLp.sub_apply, Real.norm_eq_abs] using PiLp.norm_apply_le (p₁ - p₂) y
    calc (1 - τ) * |p₁ y - p₂ y| ≤ 1 * ‖p₁ - p₂‖ :=
          mul_le_mul h1mτ_le1 hpy (abs_nonneg _) zero_le_one
      _ = ‖p₁ - p₂‖ := one_mul _
  calc T * |Real.log (p₁_τ y) - Real.log (p₂_τ y)|
      ≤ T * (|p₁_τ y - p₂_τ y| / (τ / (K : ℝ))) := mul_le_mul_of_nonneg_left hlog hT_pos.le
    _ ≤ T * (‖p₁ - p₂‖ / (τ / (K : ℝ))) :=
        mul_le_mul_of_nonneg_left (div_le_div_of_nonneg_right hcoord (by positivity)) hT_pos.le
    _ = ((K : ℝ) * T / τ) * ‖p₁ - p₂‖ := by
        field_simp [hτ_pos.ne', hK_pos.ne']

/-- 2-Lipschitzness of `logMatchingLoss T` on `EuclideanSpace ℝ (Fin K)`. -/
lemma logMatchingLoss_lipschitz_two {K : ℕ} (hK : 2 ≤ K) {T : ℝ} (hT : 0 < T)
    (s₁ s₂ : EuclideanSpace ℝ (Fin K)) (y : Fin K) :
    |(T * Real.log (∑ j : Fin K, Real.exp (s₁ j / T)) - s₁ y) -
        (T * Real.log (∑ j : Fin K, Real.exp (s₂ j / T)) - s₂ y)| ≤
      2 * ‖s₁ - s₂‖ := by
  have hlse_le : ∀ a b : EuclideanSpace ℝ (Fin K),
      T * Real.log (∑ j : Fin K, Real.exp (a j / T)) -
        T * Real.log (∑ j : Fin K, Real.exp (b j / T)) ≤ ‖a - b‖ := by
    intro a b
    have hZa_pos : 0 < ∑ j : Fin K, Real.exp (a j / T) :=
      Finset.sum_pos (fun _ _ => Real.exp_pos _) ⟨⟨0, by omega⟩, Finset.mem_univ _⟩
    have hZb_pos : 0 < ∑ j : Fin K, Real.exp (b j / T) :=
      Finset.sum_pos (fun _ _ => Real.exp_pos _) ⟨⟨0, by omega⟩, Finset.mem_univ _⟩
    have hsum_le : ∑ j : Fin K, Real.exp (a j / T) ≤
        Real.exp (‖a - b‖ / T) * ∑ j : Fin K, Real.exp (b j / T) := by
      rw [Finset.mul_sum]
      refine Finset.sum_le_sum fun j _ => ?_
      rw [← Real.exp_add]
      refine Real.exp_le_exp.mpr ?_
      have hj : a j - b j ≤ ‖a - b‖ := by
        have habs : |a j - b j| ≤ ‖a - b‖ := by
          simpa [PiLp.sub_apply, Real.norm_eq_abs] using PiLp.norm_apply_le (a - b) j
        exact (le_abs_self _).trans habs
      have hdiv := div_le_div_of_nonneg_right (by linarith only [hj] : a j ≤ ‖a - b‖ + b j) hT.le
      rwa [add_div] at hdiv
    have hlog := Real.log_le_log hZa_pos hsum_le
    rw [Real.log_mul (Real.exp_pos _).ne' hZb_pos.ne', Real.log_exp] at hlog
    have hmul := mul_le_mul_of_nonneg_left hlog hT.le
    have hrew : T * (‖a - b‖ / T + Real.log (∑ j : Fin K, Real.exp (b j / T))) =
        ‖a - b‖ + T * Real.log (∑ j : Fin K, Real.exp (b j / T)) := by
      field_simp [hT.ne']
    linarith only [hmul, hrew]
  have habs_lse : |T * Real.log (∑ j : Fin K, Real.exp (s₁ j / T)) -
      T * Real.log (∑ j : Fin K, Real.exp (s₂ j / T))| ≤ ‖s₁ - s₂‖ := by
    refine abs_le.mpr ⟨?_, hlse_le s₁ s₂⟩
    have h21 := hlse_le s₂ s₁
    rw [norm_sub_rev] at h21
    linarith only [h21]
  have habs_y : |s₁ y - s₂ y| ≤ ‖s₁ - s₂‖ := by
    simpa [PiLp.sub_apply, Real.norm_eq_abs] using PiLp.norm_apply_le (s₁ - s₂) y
  have hsplit : (T * Real.log (∑ j : Fin K, Real.exp (s₁ j / T)) - s₁ y) -
      (T * Real.log (∑ j : Fin K, Real.exp (s₂ j / T)) - s₂ y) =
      (T * Real.log (∑ j : Fin K, Real.exp (s₁ j / T)) -
        T * Real.log (∑ j : Fin K, Real.exp (s₂ j / T))) - (s₁ y - s₂ y) := by ring
  rw [hsplit]
  calc |(T * Real.log (∑ j : Fin K, Real.exp (s₁ j / T)) -
          T * Real.log (∑ j : Fin K, Real.exp (s₂ j / T))) - (s₁ y - s₂ y)|
      ≤ |T * Real.log (∑ j : Fin K, Real.exp (s₁ j / T)) -
          T * Real.log (∑ j : Fin K, Real.exp (s₂ j / T))| + |s₁ y - s₂ y| := abs_sub _ _
    _ ≤ ‖s₁ - s₂‖ + ‖s₁ - s₂‖ := add_le_add habs_lse habs_y
    _ = 2 * ‖s₁ - s₂‖ := by ring

/-! ### 4. Joint `ScoreProfileClass` deviations for smooth and log losses -/

lemma scoreProfileClass_mono.{u}
    {X : Type u} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {K : ℕ} {L R C₁ C₂ M₁ M₂ : ℝ}
    (hC : C₁ ≤ C₂) (hM : M₁ ≤ M₂)
    {f : Metric.closedBall (0 : X) L × Fin K → ℝ}
    (hf : f ∈ UL.ScoreProfileClass X K L R C₁ M₁) :
    f ∈ UL.ScoreProfileClass X K L R C₂ M₂ := by
  obtain ⟨hK, hL, hR, hC₁, hM₁, W, a, hW, ha, hfeq⟩ := hf
  refine ⟨hK, hL, hR, lt_of_lt_of_le hC₁ hC, lt_of_lt_of_le hM₁ hM, W, a, hW, fun y => ⟨?_, ?_⟩, hfeq⟩
  · rw [lipschitzOnWith_iff_dist_le_mul]
    intro s₁ hs₁ s₂ hs₂
    have hd := (lipschitzOnWith_iff_dist_le_mul.mp (ha y).1) s₁ hs₁ s₂ hs₂
    exact hd.trans (mul_le_mul_of_nonneg_right (Real.toNNReal_le_toNNReal hC) dist_nonneg)
  · exact (ha y).2.mono_right (Set.Icc_subset_Icc (neg_le_neg hM) hM)

/-- Given a bound `B` on the uniform empirical-to-population deviation over
`ScoreProfileClass X K L R C_prof M_prof` and bounded sample norms `‖x_s i‖ ≤ L`, all four
profile families (smooth learner, smooth comparator, log learner, log comparator) deviate from
their population expectations by at most `B`. -/
theorem joint_pop_emp_deviations.{u}
    {X : Type u} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    [MeasurableSpace X] [BorelSpace X]
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R β lam M T_min T_max τ B : ℝ}
    (hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) (hlam : 0 < lam) (hM : 0 < M)
    (hTmin_pos : 0 < T_min) (hTmin_le : T_min ≤ T_max) (hTmin_lb : (1 : ℝ) / (2 * β) ≤ T_min)
    (hτ_pos : 0 < τ) (hτ_half : τ ≤ (1 : ℝ) / 2)
    (ν : Measure (X × Fin K)) [IsProbabilityMeasure ν]
    (hX_bound : ∀ᵐ xy ∂ν, ‖xy.1‖ ≤ L)
    (x_s : Fin n → X) (y_s : Fin n → Fin K)
    (hx_s : ∀ i : Fin n, ‖x_s i‖ ≤ L)
    (h_sup :
      let C_prof : ℝ := 3 * β * (lam + (K : ℝ) * T_max / τ)
      let M_prof : ℝ := 3 * (M + T_max * Real.log ((K : ℝ) / τ) + L * R)
      sSup ((fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
        |(∫ xy, UL.Proof_thm_C_1_Race3.evalBallProfile L f xy.1 xy.2 ∂ν) -
          ((1 : ℝ) / (n : ℝ)) *
            ∑ i : Fin n, UL.Proof_thm_C_1_Race3.evalBallProfile L f (x_s i) (y_s i)|) ''
        UL.ScoreProfileClass X K L R C_prof M_prof) ≤ B)
    {W : X →L[ℝ] UL.ZeroSumSubspace K} (hW : UL.hilbertSchmidtNorm W ≤ R)
    {ρ_τ : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hρτ_simp : ∀ s : UL.ZeroSumSubspace K, ρ_τ s ∈ UL.Simplex K)
    (hρτ_lip : LipschitzWith (Real.toNNReal β) ρ_τ)
    (hρτ_lb : ∀ (s : UL.ZeroSumSubspace K) (j : Fin K), τ / (K : ℝ) ≤ ρ_τ s j) :
    (∀ Φ ∈ UL.SmoothEntropyFamily K β lam M,
      |(∫ xy, UL.finiteCanonicalLoss Φ (ρ_τ (W xy.1)) xy.2 ∂ν) -
        ((1 : ℝ) / (n : ℝ)) *
          ∑ i : Fin n, UL.finiteCanonicalLoss Φ (ρ_τ (W (x_s i))) (y_s i)| ≤ B) ∧
    (∀ Φ ∈ UL.SmoothEntropyFamily K β lam M,
      ∀ V : X →L[ℝ] UL.ZeroSumSubspace K, UL.hilbertSchmidtNorm V ≤ R →
        |(∫ xy, UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 ∂ν) -
          ((1 : ℝ) / (n : ℝ)) *
            ∑ i : Fin n, UL.matchingLoss Φ (V (x_s i) : EuclideanSpace ℝ (Fin K)) (y_s i)| ≤ B) ∧
    (∀ T ∈ Set.Icc T_min T_max,
      |(∫ xy, (-T * Real.log (ρ_τ (W xy.1) xy.2)) ∂ν) -
        ((1 : ℝ) / (n : ℝ)) *
          ∑ i : Fin n, (-T * Real.log (ρ_τ (W (x_s i)) (y_s i)))| ≤ B) ∧
    (∀ T ∈ Set.Icc T_min T_max,
      ∀ V : X →L[ℝ] UL.ZeroSumSubspace K, UL.hilbertSchmidtNorm V ≤ R →
        |(∫ xy, (T * Real.log (∑ j : Fin K, Real.exp ((V xy.1 : EuclideanSpace ℝ (Fin K)) j / T)) -
            (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2) ∂ν) -
          ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
            (T * Real.log (∑ j : Fin K, Real.exp ((V (x_s i) : EuclideanSpace ℝ (Fin K)) j / T)) -
              (V (x_s i) : EuclideanSpace ℝ (Fin K)) (y_s i))| ≤ B) := by
  set C_prof : ℝ := 3 * β * (lam + (K : ℝ) * T_max / τ)
  set M_prof : ℝ := 3 * (M + T_max * Real.log ((K : ℝ) / τ) + L * R)
  have hTmax_pos : 0 < T_max := lt_of_lt_of_le hTmin_pos hTmin_le
  have hK_pos : (0 : ℝ) < (K : ℝ) := by exact_mod_cast (by omega : 0 < K)
  have hlogKτ_pos : 0 < Real.log ((K : ℝ) / τ) := log_K_div_tau_pos hK hτ_pos hτ_half
  have hCprof_pos : 0 < C_prof := by dsimp [C_prof]; positivity
  have hMprof_pos : 0 < M_prof := by dsimp [M_prof]; positivity
  have hC_smooth_le : 3 * β * lam ≤ C_prof := by
    have hnn : 0 ≤ 3 * β * ((K : ℝ) * T_max / τ) := by positivity
    dsimp [C_prof]; linarith only [hnn]
  have hM_smooth_le : 3 * (M + L * R) ≤ M_prof := by
    have hnn : 0 ≤ 3 * (T_max * Real.log ((K : ℝ) / τ)) := by positivity
    dsimp [M_prof]; linarith only [hnn]
  have h_bdd_sup := UL.Proof_thm_C_1_Race3.scoreProfileClass_dev_bddAbove
    (L := L) (R := R) (C := C_prof) (hn := hn) hMprof_pos ν x_s y_s
  refine ⟨?_, ?_, ?_, ?_⟩
  · -- (1) Smooth learner profile
    intro Φ hΦ
    let f_learn : Metric.closedBall (0 : X) L × Fin K → ℝ :=
      fun xy => UL.finiteCanonicalLoss Φ (ρ_τ (W xy.1.1)) xy.2 - UL.matchingPotential Φ 0
    have hf_learn : f_learn ∈ UL.ScoreProfileClass X K L R C_prof M_prof :=
      scoreProfileClass_mono hC_smooth_le hM_smooth_le
        (UL.Proof_thm_C_1_Race3.learnerProfile_mem_scoreProfileClass hK hL hR hβ (le_refl β) hΦ
          hW hρτ_simp hρτ_lip)
    have hdev := (le_csSup h_bdd_sup ⟨f_learn, hf_learn, rfl⟩).trans h_sup
    dsimp only at hdev
    have heq := UL.Proof_thm_C_1_Race3.evalBallProfile_dev_learner_eq hK hn hL hR hβ (le_refl β)
      hΦ hW hρτ_simp hρτ_lip ν hX_bound x_s y_s hx_s
    rwa [heq] at hdev
  · -- (2) Smooth comparator profile
    intro Φ hΦ V hV
    let f_comp : Metric.closedBall (0 : X) L × Fin K → ℝ :=
      fun xy => UL.matchingLoss Φ (V xy.1.1 : EuclideanSpace ℝ (Fin K)) xy.2 -
        UL.matchingPotential Φ 0
    have hf_comp : f_comp ∈ UL.ScoreProfileClass X K L R C_prof M_prof :=
      scoreProfileClass_mono hC_smooth_le hM_smooth_le
        (UL.Proof_thm_C_1_Race3.compProfile_mem_scoreProfileClass hK hL hR hβ (le_refl β) hΦ hV)
    have hdev := (le_csSup h_bdd_sup ⟨f_comp, hf_comp, rfl⟩).trans h_sup
    dsimp only at hdev
    have heq := UL.Proof_thm_C_1_Race3.evalBallProfile_dev_comp_eq hK hn hL hR
      hΦ hV ν hX_bound x_s y_s hx_s
    rwa [heq] at hdev
  · -- (3) Smoothed learner log-loss profile
    intro T hT
    have hT_pos : 0 < T := lt_of_lt_of_le hTmin_pos hT.1
    let a : Fin K → UL.ZeroSumSubspace K → ℝ := fun y s => -T * Real.log (ρ_τ s y)
    let f_log : Metric.closedBall (0 : X) L × Fin K → ℝ := fun xy => a xy.2 (W xy.1.1)
    have ha_abs : ∀ (y : Fin K) (s : UL.ZeroSumSubspace K),
        |a y s| ≤ T_max * Real.log ((K : ℝ) / τ) := by
      intro y s
      have hlb : τ / (K : ℝ) ≤ ρ_τ s y := hρτ_lb s y
      have hub : ρ_τ s y ≤ 1 := by
        have hle := Finset.single_le_sum (fun r _ => (hρτ_simp s).1 r) (Finset.mem_univ y)
        rwa [(hρτ_simp s).2] at hle
      have hlog_le0 : Real.log (ρ_τ s y) ≤ 0 := by
        simpa using Real.log_le_log (lt_of_lt_of_le (div_pos hτ_pos hK_pos) hlb) hub
      have hlog_ge : -Real.log ((K : ℝ) / τ) ≤ Real.log (ρ_τ s y) := by
        have hinv : ((K : ℝ) / τ)⁻¹ = τ / (K : ℝ) := inv_div (K : ℝ) τ
        rw [← Real.log_inv, hinv]
        exact Real.log_le_log (div_pos hτ_pos hK_pos) hlb
      have hnn : 0 ≤ a y s := by
        dsimp [a]; nlinarith only [hT_pos, hlog_le0]
      have hhi : a y s ≤ T_max * Real.log ((K : ℝ) / τ) := by
        have h1 : -T * Real.log (ρ_τ s y) ≤ T * Real.log ((K : ℝ) / τ) := by
          have hm := mul_le_mul_of_nonneg_left (neg_le_neg hlog_ge) hT_pos.le
          linarith only [hm]
        have h2 : T * Real.log ((K : ℝ) / τ) ≤ T_max * Real.log ((K : ℝ) / τ) :=
          mul_le_mul_of_nonneg_right hT.2 hlogKτ_pos.le
        dsimp [a]; linarith only [h1, h2]
      have hprod_nn : 0 ≤ T_max * Real.log ((K : ℝ) / τ) :=
        mul_nonneg hTmax_pos.le hlogKτ_pos.le
      exact abs_le.mpr ⟨by linarith only [hnn, hprod_nn], hhi⟩
    have hf_log : f_log ∈ UL.ScoreProfileClass X K L R C_prof M_prof := by
      refine ⟨hK, hL, hR, hCprof_pos, hMprof_pos, W, a, hW, fun y => ⟨?_, ?_⟩, fun _ _ => rfl⟩
      · rw [lipschitzOnWith_iff_dist_le_mul]
        intro s₁ _ s₂ _
        rw [Real.coe_toNNReal C_prof hCprof_pos.le, Real.dist_eq, dist_eq_norm]
        dsimp [a]
        have hsub : (-T * Real.log (ρ_τ s₁ y)) - (-T * Real.log (ρ_τ s₂ y)) =
            -T * (Real.log (ρ_τ s₁ y) - Real.log (ρ_τ s₂ y)) := by ring
        rw [hsub, abs_mul, abs_neg, abs_of_pos hT_pos]
        have hlog := abs_log_sub_log_le_div (div_pos hτ_pos hK_pos)
          (hρτ_lb s₁ y) (hρτ_lb s₂ y)
        have hρ_lip : ‖ρ_τ s₁ - ρ_τ s₂‖ ≤ β * ‖s₁ - s₂‖ := by
          have hd := hρτ_lip.dist_le_mul s₁ s₂
          rwa [Real.coe_toNNReal β hβ.le, dist_eq_norm, dist_eq_norm] at hd
        have hcoord : |ρ_τ s₁ y - ρ_τ s₂ y| ≤ β * ‖s₁ - s₂‖ := by
          have h1 : |ρ_τ s₁ y - ρ_τ s₂ y| ≤ ‖ρ_τ s₁ - ρ_τ s₂‖ := by
            simpa [PiLp.sub_apply, Real.norm_eq_abs] using PiLp.norm_apply_le (ρ_τ s₁ - ρ_τ s₂) y
          exact h1.trans hρ_lip
        have hcoeff_le : β * ((K : ℝ) * T / τ) ≤ C_prof := by
          have hT_le : β * ((K : ℝ) * T / τ) ≤ β * ((K : ℝ) * T_max / τ) :=
            mul_le_mul_of_nonneg_left
              (div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left hT.2 hK_pos.le) hτ_pos.le)
              hβ.le
          have hnn1 : 0 ≤ β * lam := by positivity
          have hnn2 : 0 ≤ β * ((K : ℝ) * T_max / τ) := by positivity
          dsimp [C_prof]
          linarith only [hT_le, hnn1, hnn2]
        calc T * |Real.log (ρ_τ s₁ y) - Real.log (ρ_τ s₂ y)|
            ≤ T * ((β * ‖s₁ - s₂‖) / (τ / (K : ℝ))) :=
              mul_le_mul_of_nonneg_left
                (hlog.trans (div_le_div_of_nonneg_right hcoord (by positivity))) hT_pos.le
          _ = (β * ((K : ℝ) * T / τ)) * ‖s₁ - s₂‖ := by
              field_simp [hτ_pos.ne', hK_pos.ne']
          _ ≤ C_prof * ‖s₁ - s₂‖ := mul_le_mul_of_nonneg_right hcoeff_le (norm_nonneg _)
      · intro s _
        rw [Set.mem_Icc, ← abs_le]
        refine (ha_abs y s).trans ?_
        have hnn1 : 0 ≤ M + L * R := by positivity
        have hnn2 : 0 ≤ T_max * Real.log ((K : ℝ) / τ) := by positivity
        dsimp [M_prof]
        linarith only [hnn1, hnn2]
    have hdev := (le_csSup h_bdd_sup ⟨f_log, hf_log, rfl⟩).trans h_sup
    dsimp only at hdev
    have hae : (fun xy : X × Fin K => UL.Proof_thm_C_1_Race3.evalBallProfile L f_log xy.1 xy.2)
        =ᵐ[ν] (fun xy : X × Fin K => -T * Real.log (ρ_τ (W xy.1) xy.2)) := by
      filter_upwards [hX_bound] with xy hxy
      classical
      have hmem : xy.1 ∈ Metric.closedBall (0 : X) L := by
        rwa [Metric.mem_closedBall, dist_zero_right]
      simp [UL.Proof_thm_C_1_Race3.evalBallProfile, hmem, f_log, a]
    have hint_eq : (∫ xy, UL.Proof_thm_C_1_Race3.evalBallProfile L f_log xy.1 xy.2 ∂ν) =
        ∫ xy, (-T * Real.log (ρ_τ (W xy.1) xy.2)) ∂ν :=
      integral_congr_ae hae
    have hsum_eq :
        (∑ i : Fin n, UL.Proof_thm_C_1_Race3.evalBallProfile L f_log (x_s i) (y_s i)) =
          ∑ i : Fin n, (-T * Real.log (ρ_τ (W (x_s i)) (y_s i))) := by
      refine Finset.sum_congr rfl fun i _ => ?_
      classical
      have hmem : x_s i ∈ Metric.closedBall (0 : X) L := by
        rw [Metric.mem_closedBall, dist_zero_right]; exact hx_s i
      simp [UL.Proof_thm_C_1_Race3.evalBallProfile, hmem, f_log, a]
    rwa [hint_eq, hsum_eq] at hdev
  · -- (4) Comparator log-matching loss profile
    intro T hT V hV
    have hT_pos : 0 < T := lt_of_lt_of_le hTmin_pos hT.1
    let lml : UL.ZeroSumSubspace K → Fin K → ℝ := fun s y =>
      T * Real.log (∑ j : Fin K, Real.exp ((s : EuclideanSpace ℝ (Fin K)) j / T)) -
        (s : EuclideanSpace ℝ (Fin K)) y
    let c_T : ℝ := T * Real.log (K : ℝ)
    let a : Fin K → UL.ZeroSumSubspace K → ℝ := fun y s => lml s y - c_T
    let f_lcomp : Metric.closedBall (0 : X) L × Fin K → ℝ := fun xy => a xy.2 (V xy.1.1)
    have hlml_zero : ∀ y : Fin K, lml 0 y = c_T := by
      intro y
      dsimp [lml, c_T]
      simp only [Submodule.coe_zero, PiLp.zero_apply, zero_div, Real.exp_zero, sub_zero,
        Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, mul_one]
    have h2_le_Cprof : 2 ≤ C_prof := by
      have h2βT : 1 ≤ 2 * β * T_max := by
        have h1 : (1 : ℝ) / (2 * β) ≤ T_max := hTmin_lb.trans hTmin_le
        have hm := mul_le_mul_of_nonneg_left h1 (by positivity : 0 ≤ 2 * β)
        have hrew : (2 * β) * ((1 : ℝ) / (2 * β)) = 1 := by field_simp [hβ.ne']
        linarith only [hm, hrew, show (2 * β) * T_max = 2 * β * T_max by ring]
      have hK_ge2 : (2 : ℝ) ≤ (K : ℝ) := by exact_mod_cast hK
      have h4_le_Kτ : 4 ≤ (K : ℝ) / τ := by
        rw [le_div_iff₀ hτ_pos]
        linarith only [hK_ge2, hτ_half]
      have hprod : 2 ≤ β * ((K : ℝ) * T_max / τ) := by
        have hm := mul_le_mul h2βT h4_le_Kτ zero_le_four (by positivity)
        linarith only [hm, show (2 * β * T_max) * ((K : ℝ) / τ) =
          2 * (β * ((K : ℝ) * T_max / τ)) by ring]
      have hnn_lam : 0 ≤ 3 * β * lam := by positivity
      dsimp [C_prof]
      linarith only [hprod, hnn_lam]
    have hf_lcomp : f_lcomp ∈ UL.ScoreProfileClass X K L R C_prof M_prof := by
      refine ⟨hK, hL, hR, hCprof_pos, hMprof_pos, V, a, hV, fun y => ⟨?_, ?_⟩, fun _ _ => rfl⟩
      · rw [lipschitzOnWith_iff_dist_le_mul]
        intro s₁ _ s₂ _
        rw [Real.coe_toNNReal C_prof hCprof_pos.le, Real.dist_eq, dist_eq_norm]
        dsimp [a, lml]
        have hsub :
            (T * Real.log (∑ j : Fin K, Real.exp ((s₁ : EuclideanSpace ℝ (Fin K)) j / T)) -
                (s₁ : EuclideanSpace ℝ (Fin K)) y - c_T) -
              (T * Real.log (∑ j : Fin K, Real.exp ((s₂ : EuclideanSpace ℝ (Fin K)) j / T)) -
                (s₂ : EuclideanSpace ℝ (Fin K)) y - c_T) =
            (T * Real.log (∑ j : Fin K, Real.exp ((s₁ : EuclideanSpace ℝ (Fin K)) j / T)) -
                (s₁ : EuclideanSpace ℝ (Fin K)) y) -
              (T * Real.log (∑ j : Fin K, Real.exp ((s₂ : EuclideanSpace ℝ (Fin K)) j / T)) -
                (s₂ : EuclideanSpace ℝ (Fin K)) y) := by ring
        rw [hsub]
        calc |(T * Real.log (∑ j : Fin K, Real.exp ((s₁ : EuclideanSpace ℝ (Fin K)) j / T)) -
                (s₁ : EuclideanSpace ℝ (Fin K)) y) -
              (T * Real.log (∑ j : Fin K, Real.exp ((s₂ : EuclideanSpace ℝ (Fin K)) j / T)) -
                (s₂ : EuclideanSpace ℝ (Fin K)) y)|
            ≤ 2 * ‖(s₁ : EuclideanSpace ℝ (Fin K)) - (s₂ : EuclideanSpace ℝ (Fin K))‖ :=
              logMatchingLoss_lipschitz_two hK hT_pos _ _ y
          _ = 2 * ‖s₁ - s₂‖ := by rw [← Submodule.coe_sub, Submodule.norm_coe]
          _ ≤ C_prof * ‖s₁ - s₂‖ := mul_le_mul_of_nonneg_right h2_le_Cprof (norm_nonneg _)
      · intro s hs
        rw [Metric.mem_closedBall, dist_zero_right] at hs
        rw [Set.mem_Icc, ← abs_le]
        dsimp [a]
        rw [← hlml_zero y]
        calc |lml s y - lml 0 y|
            ≤ 2 * ‖(s : EuclideanSpace ℝ (Fin K)) - (0 : EuclideanSpace ℝ (Fin K))‖ :=
              logMatchingLoss_lipschitz_two hK hT_pos _ _ y
          _ = 2 * ‖s‖ := by rw [sub_zero, Submodule.norm_coe]
          _ ≤ 2 * (L * R) := mul_le_mul_of_nonneg_left hs (by norm_num)
          _ ≤ M_prof := by
              have hnn1 : 0 ≤ M + T_max * Real.log ((K : ℝ) / τ) := by positivity
              have hnn2 : 0 ≤ L * R := by positivity
              dsimp [M_prof]
              linarith only [hnn1, hnn2]
    have hdev := (le_csSup h_bdd_sup ⟨f_lcomp, hf_lcomp, rfl⟩).trans h_sup
    have hlml_meas : Measurable (fun xy : X × Fin K => lml (V xy.1) xy.2) := by
      refine UL.Proof_thm_C_1_Race3.measurable_of_fin_snd fun y => ?_
      have hcont : Continuous (fun x : X => lml (V x) y) := by
        dsimp [lml]
        have hV_coe : Continuous (fun x : X => (V x : EuclideanSpace ℝ (Fin K))) :=
          (UL.ZeroSumSubspace K).subtypeL.continuous.comp V.continuous
        have hZ : Continuous (fun x : X =>
            ∑ j : Fin K, Real.exp ((V x : EuclideanSpace ℝ (Fin K)) j / T)) :=
          continuous_finset_sum Finset.univ fun j _ =>
            Real.continuous_exp.comp
              (((EuclideanSpace.proj (𝕜 := ℝ) j).continuous.comp hV_coe).div_const T)
        have hZ_ne : ∀ x : X,
            ∑ j : Fin K, Real.exp ((V x : EuclideanSpace ℝ (Fin K)) j / T) ≠ 0 := fun x =>
          (Finset.sum_pos (fun _ _ => Real.exp_pos _) ⟨⟨0, by omega⟩, Finset.mem_univ _⟩).ne'
        exact (continuous_const.mul (hZ.log hZ_ne)).sub
          ((EuclideanSpace.proj (𝕜 := ℝ) y).continuous.comp hV_coe)
      exact hcont.measurable
    have hlml_int : Integrable (fun xy : X × Fin K => lml (V xy.1) xy.2) ν := by
      refine (integrable_const (|c_T| + 2 * (R * L))).mono' hlml_meas.aestronglyMeasurable ?_
      filter_upwards [hX_bound] with xy hxy
      rw [Real.norm_eq_abs]
      have hdiff : |lml (V xy.1) xy.2 - c_T| ≤ 2 * (R * L) := by
        rw [← hlml_zero xy.2]
        calc |lml (V xy.1) xy.2 - lml 0 xy.2|
            ≤ 2 * ‖(V xy.1 : EuclideanSpace ℝ (Fin K)) - 0‖ :=
              logMatchingLoss_lipschitz_two hK hT_pos _ _ xy.2
          _ = 2 * ‖V xy.1‖ := by rw [sub_zero, Submodule.norm_coe]
          _ ≤ 2 * (R * L) := by
              refine mul_le_mul_of_nonneg_left ?_ (by norm_num)
              exact (UL.Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm V xy.1).trans
                (mul_le_mul hV hxy (norm_nonneg _) hR.le)
      have habs : |lml (V xy.1) xy.2| ≤ |lml (V xy.1) xy.2 - c_T| + |c_T| := by
        calc |lml (V xy.1) xy.2|
            = |(lml (V xy.1) xy.2 - c_T) + c_T| := by ring_nf
          _ ≤ |lml (V xy.1) xy.2 - c_T| + |c_T| := abs_add_le _ _
      linarith only [habs, hdiff]
    have hae : (fun xy : X × Fin K => UL.Proof_thm_C_1_Race3.evalBallProfile L f_lcomp xy.1 xy.2)
        =ᵐ[ν] (fun xy : X × Fin K => lml (V xy.1) xy.2 - c_T) := by
      filter_upwards [hX_bound] with xy hxy
      classical
      have hmem : xy.1 ∈ Metric.closedBall (0 : X) L := by
        rwa [Metric.mem_closedBall, dist_zero_right]
      simp [UL.Proof_thm_C_1_Race3.evalBallProfile, hmem, f_lcomp, a]
    have hint_eq : (∫ xy, UL.Proof_thm_C_1_Race3.evalBallProfile L f_lcomp xy.1 xy.2 ∂ν) =
        (∫ xy, lml (V xy.1) xy.2 ∂ν) - c_T := by
      rw [integral_congr_ae hae, integral_sub hlml_int (integrable_const c_T)]
      simp
    have hsum_eq :
        ((1 : ℝ) / (n : ℝ)) *
            ∑ i : Fin n, UL.Proof_thm_C_1_Race3.evalBallProfile L f_lcomp (x_s i) (y_s i) =
          ((1 : ℝ) / (n : ℝ)) * (∑ i : Fin n, lml (V (x_s i)) (y_s i)) - c_T := by
      have hpt : ∀ i : Fin n,
          UL.Proof_thm_C_1_Race3.evalBallProfile L f_lcomp (x_s i) (y_s i) =
            lml (V (x_s i)) (y_s i) - c_T := by
        intro i
        classical
        have hmem : x_s i ∈ Metric.closedBall (0 : X) L := by
          rw [Metric.mem_closedBall, dist_zero_right]; exact hx_s i
        simp [UL.Proof_thm_C_1_Race3.evalBallProfile, hmem, f_lcomp, a]
      simp_rw [hpt, Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
        nsmul_eq_mul]
      have hn_pos : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hn
      field_simp [hn_pos.ne']
    have hcancel : (∫ xy, UL.Proof_thm_C_1_Race3.evalBallProfile L f_lcomp xy.1 xy.2 ∂ν) -
        ((1 : ℝ) / (n : ℝ)) *
          ∑ i : Fin n, UL.Proof_thm_C_1_Race3.evalBallProfile L f_lcomp (x_s i) (y_s i) =
        (∫ xy, lml (V xy.1) xy.2 ∂ν) -
          ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, lml (V (x_s i)) (y_s i) := by
      rw [hint_eq, hsum_eq]; ring
    dsimp only at hdev
    rwa [hcancel] at hdev

/-! ### 5. Universal `S_lem_C_2` extraction and Part B of `S_cor_C_7` -/

/-- Because `isOptimalFit` and `gamma_n` in `S_lem_C_2` are independent of `(lam, M)`, invoking
`h_lem_C_2` at `(1, 1)` to pick `Z` and optimal fits and at arbitrary `(lam', M')` yields
empirical regret simultaneously across ALL `0 < lam'`, `0 < M'`, and
`Φ ∈ SmoothEntropyFamily K β lam' M'`. -/
theorem lem_C_2_universal_smooth.{u}
    (h_lem_C_2 : UL.S_lem_C_2.{u})
    {K : ℕ} (hK : 2 ≤ K)
    (X : Type u) [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {n : ℕ} (hn : 1 ≤ n)
    (x : Fin n → X) (y : Fin n → Fin K)
    {L R β : ℝ} (hL : 0 < L) (hx : ∀ i : Fin n, ‖x i‖ ≤ L)
    (hR : 0 < R) (hβ : 0 < β) :
    let u : EuclideanSpace ℝ (Fin K) := UL.uniformVec K
    let A : ℝ := L * R
    let memCenteredSimplex : UL.ZeroSumSubspace K → Prop :=
      fun p => u + (p : EuclideanSpace ℝ (Fin K)) ∈ UL.Simplex K
    let isBLip : (UL.ZeroSumSubspace K → UL.ZeroSumSubspace K) → Prop :=
      fun rhoTilde =>
        (∀ s : UL.ZeroSumSubspace K, ‖s‖ ≤ A → memCenteredSimplex (rhoTilde s)) ∧
        (∀ s s' : UL.ZeroSumSubspace K, ‖s‖ ≤ A → ‖s'‖ ≤ A → ‖rhoTilde s - rhoTilde s'‖ ≤ β * ‖s - s'‖)
    ∃ Z : Fin n → UL.ZeroSumSubspace K,
      (∀ i : Fin n, (Z i : EuclideanSpace ℝ (Fin K)) = EuclideanSpace.single (y i) (1 : ℝ) - u) ∧
      let isOptimalFit : (X →L[ℝ] UL.ZeroSumSubspace K) →
          (Fin n → UL.ZeroSumSubspace K) → Prop :=
        fun W pTilde =>
          (∃ rhoTilde : UL.ZeroSumSubspace K → UL.ZeroSumSubspace K,
            isBLip rhoTilde ∧ ∀ i : Fin n, pTilde i = rhoTilde (W (x i))) ∧
          (∀ ρ' : UL.ZeroSumSubspace K → UL.ZeroSumSubspace K, isBLip ρ' →
            (1 / (n : ℝ)) * ∑ i : Fin n, ‖pTilde i - Z i‖ ^ 2 ≤
              (1 / (n : ℝ)) * ∑ i : Fin n, ‖ρ' (W (x i)) - Z i‖ ^ 2)
      let gamma_n : (X →L[ℝ] UL.ZeroSumSubspace K) → (Fin n → UL.ZeroSumSubspace K) → ℝ :=
        fun W pTilde =>
          let gₙ : X →L[ℝ] UL.ZeroSumSubspace K :=
            (1 / (n : ℝ)) • ∑ i : Fin n, (innerSL ℝ (x i)).smulRight (pTilde i - Z i)
          ((1 : ℝ) / 4) * (UL.hilbertSchmidtNorm (gₙ + W) ^ 2 - UL.hilbertSchmidtNorm (gₙ - W) ^ 2) +
            R * UL.hilbertSchmidtNorm gₙ
      (∀ W : X →L[ℝ] UL.ZeroSumSubspace K, UL.hilbertSchmidtNorm W ≤ R →
        (∃ pTilde : Fin n → UL.ZeroSumSubspace K,
          isOptimalFit W pTilde ∧ (∀ otherCenteredFit : Fin n → UL.ZeroSumSubspace K, isOptimalFit W otherCenteredFit → otherCenteredFit = pTilde)) ∧
        (∀ pTilde : Fin n → UL.ZeroSumSubspace K, isOptimalFit W pTilde →
          ∀ (lam' M' : ℝ), 0 < lam' → 0 < M' →
          ∀ Φ ∈ UL.SmoothEntropyFamily K β lam' M',
          ∀ V : X →L[ℝ] UL.ZeroSumSubspace K, UL.hilbertSchmidtNorm V ≤ R →
            (1 / (n : ℝ)) * ∑ i : Fin n,
                UL.finiteCanonicalLoss Φ (u + (pTilde i : EuclideanSpace ℝ (Fin K))) (y i) ≤
              (1 / (n : ℝ)) * ∑ i : Fin n,
                UL.matchingLoss Φ ((V (x i) : UL.ZeroSumSubspace K) :
                  EuclideanSpace ℝ (Fin K)) (y i) +
                gamma_n W pTilde)) ∧
      (∃ W : X →L[ℝ] UL.ZeroSumSubspace K,
        UL.hilbertSchmidtNorm W ≤ R ∧
        ∃ pTilde : Fin n → UL.ZeroSumSubspace K, isOptimalFit W pTilde ∧ gamma_n W pTilde = 0) := by
  intro u A memCenteredSimplex isBLip
  obtain ⟨Z, hZ, hRegret1, ⟨W₀, hW₀_norm, _hW₀_orth, pTilde₀, hP₀_opt, hP₀_gam⟩⟩ :=
    h_lem_C_2 K hK X n hn x y L R β β 1 1 hL hx hR hβ (le_refl β) zero_lt_one zero_lt_one
  refine ⟨Z, hZ, ⟨fun W hW => ⟨(hRegret1 W hW).1, ?_⟩, ⟨W₀, hW₀_norm, pTilde₀, hP₀_opt, hP₀_gam⟩⟩⟩
  intro pTilde hP lam' M' hlam' hM' Φ hΦ V hV
  obtain ⟨Z', hZ', hRegret', _⟩ :=
    h_lem_C_2 K hK X n hn x y L R β β lam' M' hL hx hR hβ (le_refl β) hlam' hM'
  have hZ_eq : Z' = Z := by
    funext i
    apply Subtype.ext
    rw [hZ' i, hZ i]
  subst hZ_eq
  have hemp := (hRegret' W hW).2 pTilde hP Φ hΦ
  have hbdd : BddBelow (Set.range (fun V' : {V' : X →L[ℝ] UL.ZeroSumSubspace K //
      UL.hilbertSchmidtNorm V' ≤ R} =>
      (1 / (n : ℝ)) * ∑ i : Fin n,
        UL.matchingLoss Φ ((V'.1 (x i) : UL.ZeroSumSubspace K) :
          EuclideanSpace ℝ (Fin K)) (y i))) := by
    refine ⟨-(|UL.matchingPotential Φ 0| + 3 * (R * L)), ?_⟩
    rintro _ ⟨V', rfl⟩
    dsimp only
    have hterm_ge : ∀ i : Fin n,
        -(|UL.matchingPotential Φ 0| + 3 * (R * L)) ≤
          UL.matchingLoss Φ ((V'.1 (x i) : UL.ZeroSumSubspace K) :
            EuclideanSpace ℝ (Fin K)) (y i) := by
      intro i
      have habs := UL.Proof_cor_A_8.matchingLoss_abs_le (by omega) hΦ.1.2.1
        ((V'.1 (x i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) (y i)
      have hnormV : ‖((V'.1 (x i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))‖ ≤
          R * L := by
        rw [Submodule.norm_coe]
        exact (UL.Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm V'.1 (x i)).trans
          (mul_le_mul V'.2 (hx i) (norm_nonneg _) hR.le)
      linarith only [(abs_le.mp habs).1, hnormV]
    have hsum_ge := Finset.sum_le_sum fun i (_ : i ∈ Finset.univ) => hterm_ge i
    have hn_pos : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hn
    have hmul := mul_le_mul_of_nonneg_left hsum_ge (by positivity : (0 : ℝ) ≤ 1 / (n : ℝ))
    rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul] at hmul
    have hconst : (1 / (n : ℝ)) * ((n : ℝ) * -(|UL.matchingPotential Φ 0| + 3 * (R * L))) =
        -(|UL.matchingPotential Φ 0| + 3 * (R * L)) := by
      field_simp [hn_pos.ne']
    linarith only [hmul, hconst]
  have hinf := ciInf_le hbdd ⟨V, hV⟩
  dsimp only at hinf hemp ⊢
  linarith only [hemp, hinf]

/-- Universe-polymorphic empirical fixed-point learner achieving zero empirical regret
simultaneously across ALL smooth entropy families (for arbitrary `(lam', M')`). -/
theorem exists_universal_empirical_learner_univ.{u, v}
    (h_lem_C_2 : UL.S_lem_C_2.{u})
    (h_lem_C_4 : UL.S_lem_C_4)
    {K : ℕ} (hK : 2 ≤ K)
    (X : Type v) [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {n : ℕ} (hn : 1 ≤ n)
    {L R β : ℝ} (hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) :
    ∃ (learnerW : (Fin n → X × Fin K) → (X →L[ℝ] UL.ZeroSumSubspace K))
      (learnerRho : (Fin n → X × Fin K) → (UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K))),
      (∀ sample : Fin n → X × Fin K,
        UL.hilbertSchmidtNorm (learnerW sample) ≤ R ∧
        (∀ s : UL.ZeroSumSubspace K, learnerRho sample s ∈ UL.Simplex K) ∧
        LipschitzWith (Real.toNNReal β) (learnerRho sample)) ∧
      (∀ sample : Fin n → X × Fin K,
        (∀ i : Fin n, ‖(sample i).1‖ ≤ L) →
        ∀ (lam' M' : ℝ), 0 < lam' → 0 < M' →
        ∀ Φ ∈ UL.SmoothEntropyFamily K β lam' M',
        ∀ V : X →L[ℝ] UL.ZeroSumSubspace K, UL.hilbertSchmidtNorm V ≤ R →
          (1 / (n : ℝ)) * ∑ i : Fin n,
              UL.finiteCanonicalLoss Φ
                (learnerRho sample (learnerW sample (sample i).1)) (sample i).2 ≤
            (1 / (n : ℝ)) * ∑ i : Fin n,
              UL.matchingLoss Φ
                ((V (sample i).1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
                (sample i).2) := by
  classical
  obtain ⟨w, b, _⟩ := exists_hilbertBasis ℝ X
  haveI : Countable w := UL.Proof_thm_C_1_Race3.countable_of_hilbertBasis b
  let ι₀ : Type 0 := Shrink.{0} w
  let e₀ : w ≃ ι₀ := equivShrink.{0} w
  let X₀ : Type 0 := lp (fun _ : ι₀ => ℝ) 2
  let X' : Type u := lp (fun _ : ULift.{u} ι₀ => ℝ) 2
  let Φ₀ : X ≃ₗᵢ[ℝ] X₀ := UL.Proof_thm_C_1_Race3.reindexHilbertEquiv b e₀
  let b₀ : HilbertBasis ι₀ ℝ X₀ := HilbertBasis.ofRepr (LinearIsometryEquiv.refl ℝ X₀)
  let ξ : X₀ ≃ₗᵢ[ℝ] X' := UL.Proof_thm_C_1_Race3.reindexHilbertEquiv b₀ Equiv.ulift.symm
  let Φ_iso : X ≃ₗᵢ[ℝ] X' := Φ₀.trans ξ
  haveI : TopologicalSpace.SeparableSpace X' :=
    Φ_iso.surjective.denseRange.separableSpace Φ_iso.continuous
  have h_pointwise : ∀ sample : Fin n → X × Fin K,
      ∃ (W : X →L[ℝ] UL.ZeroSumSubspace K)
        (ρ : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)),
        (UL.hilbertSchmidtNorm W ≤ R ∧
          (∀ s : UL.ZeroSumSubspace K, ρ s ∈ UL.Simplex K) ∧
          LipschitzWith (Real.toNNReal β) ρ) ∧
        ((∀ i : Fin n, ‖(sample i).1‖ ≤ L) →
          ∀ (lam' M' : ℝ), 0 < lam' → 0 < M' →
          ∀ Φ ∈ UL.SmoothEntropyFamily K β lam' M',
          ∀ V : X →L[ℝ] UL.ZeroSumSubspace K, UL.hilbertSchmidtNorm V ≤ R →
            (1 / (n : ℝ)) * ∑ i : Fin n,
                UL.finiteCanonicalLoss Φ (ρ (W (sample i).1)) (sample i).2 ≤
              (1 / (n : ℝ)) * ∑ i : Fin n,
                UL.matchingLoss Φ
                  ((V (sample i).1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
                  (sample i).2) := by
    intro sample
    by_cases hx : ∀ i : Fin n, ‖(sample i).1‖ ≤ L
    · let x' : Fin n → X' := fun i => Φ_iso (sample i).1
      let y' : Fin n → Fin K := fun i => (sample i).2
      have hx' : ∀ i : Fin n, ‖x' i‖ ≤ L := fun i => by
        dsimp [x']; rw [Φ_iso.norm_map]; exact hx i
      obtain ⟨Z, _hZ, hRegretAll, ⟨W', hW'_norm, P, hP_opt, hP_gam⟩⟩ :=
        lem_C_2_universal_smooth h_lem_C_2 hK X' hn x' y' hL hx' hR hβ
      have ⟨⟨ρ₀, ⟨hρ₀_simp, hρ₀_lip⟩, hP_eq⟩, _⟩ := hP_opt
      have hWx_le : ∀ i : Fin n, ‖W' (x' i)‖ ≤ L * R := fun i =>
        (UL.Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm W' (x' i)).trans
          ((mul_le_mul hW'_norm (hx' i) (norm_nonneg _) hR.le).trans_eq (mul_comm R L))
      let p_pts : Fin n → EuclideanSpace ℝ (Fin K) :=
        fun i => UL.uniformVec K + (P i : EuclideanSpace ℝ (Fin K))
      have hp_pts : ∀ i : Fin n, p_pts i ∈ UL.Simplex K := by
        intro i; dsimp [p_pts]; rw [hP_eq i]; exact hρ₀_simp (W' (x' i)) (hWx_le i)
      have hLip_pts : ∀ i j : Fin n, ‖p_pts i - p_pts j‖ ≤ β * ‖W' (x' i) - W' (x' j)‖ := by
        intro i j
        have hdiff : p_pts i - p_pts j =
            (P i : EuclideanSpace ℝ (Fin K)) - (P j : EuclideanSpace ℝ (Fin K)) := by
          dsimp [p_pts]; abel
        rw [hdiff, ← Submodule.coe_sub, Submodule.norm_coe, hP_eq i, hP_eq j]
        exact hρ₀_lip (W' (x' i)) (W' (x' j)) (hWx_le i) (hWx_le j)
      let W : X →L[ℝ] UL.ZeroSumSubspace K :=
        W'.comp Φ_iso.toContinuousLinearEquiv.toContinuousLinearMap
      have hW_norm : UL.hilbertSchmidtNorm W ≤ R := by
        rwa [UL.Proof_thm_C_1_Race3.hilbertSchmidtNorm_comp_lie W' Φ_iso]
      let ρ := extHead β (fun i => W' (x' i)) p_pts
      obtain ⟨_, hρ_simp, hρ_lip, hρ_interp⟩ :=
        extHead_spec h_lem_C_4 n K hn hK β (fun i => W' (x' i)) p_pts hβ hp_pts hLip_pts
      refine ⟨W, ρ, ⟨hW_norm, hρ_simp, hρ_lip⟩, fun _ lam' M' hlam' hM' Φ hΦ V hV => ?_⟩
      let V' : X' →L[ℝ] UL.ZeroSumSubspace K :=
        V.comp Φ_iso.symm.toContinuousLinearEquiv.toContinuousLinearMap
      have hV' : UL.hilbertSchmidtNorm V' ≤ R := by
        change UL.hilbertSchmidtNorm
          (V.comp Φ_iso.symm.toContinuousLinearEquiv.toContinuousLinearMap) ≤ R
        rwa [UL.Proof_thm_C_1_Race3.hilbertSchmidtNorm_comp_lie V Φ_iso.symm]
      have hemp := (hRegretAll W' hW'_norm).2 P hP_opt lam' M' hlam' hM' Φ hΦ V' hV'
      rw [hP_gam, add_zero] at hemp
      have hlhs :
          (∑ i : Fin n, UL.finiteCanonicalLoss Φ (ρ (W (sample i).1)) (sample i).2) =
            ∑ i : Fin n, UL.finiteCanonicalLoss Φ
              (UL.uniformVec K + (P i : EuclideanSpace ℝ (Fin K))) (y' i) := by
        refine Finset.sum_congr rfl fun i _ => ?_
        change UL.finiteCanonicalLoss Φ (extHead β (fun j => W' (x' j)) p_pts (W' (x' i))) (y' i) = _
        rw [hρ_interp i]
      have hrhs :
          (∑ i : Fin n, UL.matchingLoss Φ
            ((V' (x' i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) (y' i)) =
            ∑ i : Fin n, UL.matchingLoss Φ
              ((V (sample i).1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
              (sample i).2 := by
        refine Finset.sum_congr rfl fun i _ => ?_
        change UL.matchingLoss Φ
          ((V (Φ_iso.symm (Φ_iso (sample i).1)) : UL.ZeroSumSubspace K) :
            EuclideanSpace ℝ (Fin K)) (sample i).2 = _
        rw [Φ_iso.symm_apply_apply]
      rwa [← hlhs, hrhs] at hemp
    · refine ⟨0, fun _ => UL.uniformVec K, ⟨?_, ?_, ?_⟩, fun hx' => False.elim (hx hx')⟩
      · rw [UL.Proof_lem_C_2.hilbertSchmidtNorm_zero]; exact hR.le
      · intro _; exact UL.Proof_lem_A_5.uniformVec_mem_simplex hK
      · exact (LipschitzWith.const (UL.uniformVec K)).weaken (zero_le _)
  choose learnerW learnerRho hspec using h_pointwise
  exact ⟨learnerW, learnerRho, fun s => (hspec s).1, fun s => (hspec s).2⟩

/-- Complete proof of Part B of `S_cor_C_7`: general separable Borel Hilbert space joint
smooth-entropy and multi-temperature log-loss PAC learning guarantee. -/
theorem partB_joint_learner.{u_c2, v_X, v_Ω}
    (h_lem_C_2 : UL.S_lem_C_2.{u_c2})
    (h_lem_C_4 : UL.S_lem_C_4)
    {K : ℕ} (hK : 2 ≤ K)
    {C₃ : ℝ} (hC₃_pos : 0 < C₃)
    (h_unif :
      ∀ (X : Type v_X) [NormedAddCommGroup X] [InnerProductSpace ℝ X]
        [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
        [MeasurableSpace X] [BorelSpace X]
        (L R C M₀ : ℝ),
        0 < L → 0 < R → 0 < C → 0 < M₀ →
        ∀ (n : ℕ), 1 ≤ n →
        ∀ (δ : ℝ), 0 < δ → δ < 1 →
        ∀ (ν : Measure (X × Fin K)) [IsProbabilityMeasure ν],
          (∀ᵐ xy ∂ν, ‖xy.1‖ ≤ L) →
          ∀ (Ω : Type v_Ω) [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
            (X_samp : Fin n → Ω → X) (Y_samp : Fin n → Ω → Fin K),
            (∀ i : Fin n, Measurable (X_samp i)) →
            (∀ i : Fin n, Measurable (Y_samp i)) →
            ProbabilityTheory.iIndepFun (fun i ω => (X_samp i ω, Y_samp i ω)) μ →
            (∀ i : Fin n, Measure.map (fun ω => (X_samp i ω, Y_samp i ω)) μ = ν) →
            let m : ℕ := K - 1
            let A₀ : ℝ := L * R
            let D₀ : ℝ := M₀ + C * A₀
            let evalProfile : (Metric.closedBall (0 : X) L × Fin K → ℝ) → X → Fin K → ℝ :=
              open Classical in
              fun f x y => if hx : x ∈ Metric.closedBall (0 : X) L then f (⟨x, hx⟩, y) else 0
            let bound : ℝ :=
              if m ≤ 2 then
                C₃ * (D₀ * Real.log (2 * (n : ℝ)) + M₀ * Real.sqrt (Real.log (2 / δ))) /
                  Real.sqrt (n : ℝ)
              else
                C₃ * D₀ * ((n : ℝ) ^ (-(1 : ℝ) / (m : ℝ))) +
                  C₃ * M₀ * Real.sqrt (Real.log (2 / δ) / (n : ℝ))
            ∃ E : Set Ω, MeasurableSet E ∧ (μ E).toReal ≥ 1 - δ ∧
              ∀ ω ∈ E,
                (∀ i : Fin n, ‖X_samp i ω‖ ≤ L) ∧
                sSup ((fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
                  |(∫ xy, evalProfile f xy.1 xy.2 ∂ν) -
                    ((1 : ℝ) / (n : ℝ)) *
                      ∑ i : Fin n, evalProfile f (X_samp i ω) (Y_samp i ω)|) ''
                  UL.ScoreProfileClass X K L R C M₀) ≤ bound)
    {L R β lam M T_min T_max : ℝ}
    (hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) (hlam : 0 < lam) (hM : 0 < M)
    (hTmin_pos : 0 < T_min) (hTmin_le : T_min ≤ T_max) (hTmin_lb : (1 : ℝ) / (2 * β) ≤ T_min)
    (X : Type v_X) [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    [MeasurableSpace X] [BorelSpace X]
    {ε δ : ℝ} (hδ0 : 0 < δ) (hδ1 : δ < (1 : ℝ) / 2)
    (hε0 : 0 < ε) (hεD₀ : ε ≤ M + L * R + β * lam * (L * R))
    (n : ℕ) (hn : 1 ≤ n)
    (hn_ge :
      let m : ℕ := K - 1
      let C_K : ℝ := cSamp (fun _ => C₃) K
      let A₀ : ℝ := L * R
      let τ : ℝ := min ((1 : ℝ) / 2) (ε / (8 * (Real.sqrt 2 * lam + 2 * T_max)))
      let D_τ : ℝ :=
        M + A₀ + T_max * Real.log ((K : ℝ) / τ) + β * A₀ * (lam + (K : ℝ) * T_max / τ)
      (n : ℝ) ≥
        if m ≤ 2 then
          C_K * (D_τ / ε) ^ 2 * (Real.log (C_K * D_τ / (ε * δ))) ^ 2
        else
          C_K * ((D_τ / ε) ^ m + (D_τ / ε) ^ 2 * Real.log ((2 : ℝ) / δ))) :
    let τ : ℝ := min ((1 : ℝ) / 2) (ε / (8 * (Real.sqrt 2 * lam + 2 * T_max)))
    let logMatchingLoss : ℝ → UL.ZeroSumSubspace K → Fin K → ℝ :=
      fun T a y =>
        T * Real.log (∑ j : Fin K, Real.exp ((a : EuclideanSpace ℝ (Fin K)) j / T)) -
          (a : EuclideanSpace ℝ (Fin K)) y
    ∃ (learnerW : (Fin n → X × Fin K) → (X →L[ℝ] UL.ZeroSumSubspace K))
      (learnerRho : (Fin n → X × Fin K) → (UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K))),
      (∀ sample : Fin n → X × Fin K,
        let W : X →L[ℝ] UL.ZeroSumSubspace K := learnerW sample
        let ρ_τ : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) := learnerRho sample
        let p_τ : X → EuclideanSpace ℝ (Fin K) := fun x => ρ_τ (W x)
        UL.hilbertSchmidtNorm W ≤ R ∧
        (∀ s : UL.ZeroSumSubspace K, ρ_τ s ∈ UL.Simplex K) ∧
        LipschitzWith (Real.toNNReal ((1 - τ) * β)) ρ_τ ∧
        (1 - τ) * β ≤ β ∧
        (∀ (x : X) (j : Fin K), τ / (K : ℝ) ≤ p_τ x j)) ∧
      ∀ (ν : Measure (X × Fin K)) [IsProbabilityMeasure ν],
        (∀ᵐ xy ∂ν, ‖xy.1‖ ≤ L) →
        ∀ (Ω : Type v_Ω) [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
          (X_samp : Fin n → Ω → X) (Y_samp : Fin n → Ω → Fin K),
          (∀ i : Fin n, Measurable (X_samp i)) →
          (∀ i : Fin n, Measurable (Y_samp i)) →
          ProbabilityTheory.iIndepFun (fun i ω => (X_samp i ω, Y_samp i ω)) μ →
          (∀ i : Fin n, Measure.map (fun ω => (X_samp i ω, Y_samp i ω)) μ = ν) →
          ∃ E : Set Ω, MeasurableSet E ∧ (μ E).toReal ≥ 1 - δ ∧
            ∀ ω ∈ E,
              let sample : Fin n → X × Fin K := fun i => (X_samp i ω, Y_samp i ω)
              let W : X →L[ℝ] UL.ZeroSumSubspace K := learnerW sample
              let ρ_τ : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) := learnerRho sample
              let p_τ : X → EuclideanSpace ℝ (Fin K) := fun x => ρ_τ (W x)
              (∀ Φ ∈ UL.SmoothEntropyFamily K β lam M,
                (∫ xy, UL.finiteCanonicalLoss Φ (p_τ xy.1) xy.2 ∂ν) ≤
                  sInf ((fun V : X →L[ℝ] UL.ZeroSumSubspace K =>
                    ∫ xy, UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 ∂ν) ''
                    {V | UL.hilbertSchmidtNorm V ≤ R}) + ε) ∧
              (∀ T ∈ Set.Icc T_min T_max,
                (∫ xy, (-T * Real.log (p_τ xy.1 xy.2)) ∂ν) ≤
                  sInf ((fun V : X →L[ℝ] UL.ZeroSumSubspace K =>
                    ∫ xy, logMatchingLoss T (V xy.1) xy.2 ∂ν) ''
                    {V | UL.hilbertSchmidtNorm V ≤ R}) + ε) := by
  intro τ logMatchingLoss
  have hTmax_pos : 0 < T_max := lt_of_lt_of_le hTmin_pos hTmin_le
  obtain ⟨hτ_pos, hτ_half, hbias_smooth, hbias_log⟩ := tau_pos_and_le_half hlam hTmax_pos hε0
  obtain ⟨baseW, baseRho, hbase_feas, hbase_emp⟩ :=
    exists_universal_empirical_learner_univ h_lem_C_2 h_lem_C_4 hK X hn hL hR hβ
  let learnerRho : (Fin n → X × Fin K) → (UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)) :=
    fun sample s => (1 - τ) • baseRho sample s + τ • UL.uniformVec K
  refine ⟨baseW, learnerRho, ?_, ?_⟩
  · intro sample
    obtain ⟨hW_norm, hρ_simp, hρ_lip⟩ := hbase_feas sample
    obtain ⟨hρτ_simp, hρτ_lip, h1mτβ, hρτ_lb⟩ :=
      smoothedHead_props hK hβ hτ_pos hτ_half hρ_simp hρ_lip
    exact ⟨hW_norm, hρτ_simp, hρτ_lip, h1mτβ, fun x j => hρτ_lb (baseW sample x) j⟩
  · intro ν _ hX_bound Ω _ μ _ X_samp Y_samp hX_meas hY_meas hindep hident
    let A₀ : ℝ := L * R
    let C_prof : ℝ := 3 * β * (lam + (K : ℝ) * T_max / τ)
    let M_prof : ℝ := 3 * (M + T_max * Real.log ((K : ℝ) / τ) + A₀)
    have hlogKτ_pos : 0 < Real.log ((K : ℝ) / τ) := log_K_div_tau_pos hK hτ_pos hτ_half
    have hCprof_pos : 0 < C_prof := by dsimp [C_prof]; positivity
    have hMprof_pos : 0 < M_prof := by dsimp [M_prof, A₀]; positivity
    obtain ⟨E, hE_meas, hE_prob_half, hE_good⟩ :=
      h_unif X L R C_prof M_prof hL hR hCprof_pos hMprof_pos n hn (δ / 2)
        (by linarith only [hδ0]) (by linarith only [hδ1])
        ν hX_bound Ω μ X_samp Y_samp hX_meas hY_meas hindep hident
    have h8bound := sample_bound_implies_eight_bound_half K hK C₃ hC₃_pos
      L R β lam M T_max ε δ hL hR hβ hlam hM hTmax_pos hε0 hεD₀ hδ0 hδ1 n hn hn_ge
    dsimp only at h8bound
    set bound_half : ℝ :=
      if K - 1 ≤ 2 then
        C₃ * ((M_prof + C_prof * A₀) * Real.log (2 * (n : ℝ)) +
            M_prof * Real.sqrt (Real.log (2 / (δ / 2)))) /
          Real.sqrt (n : ℝ)
      else
        C₃ * (M_prof + C_prof * A₀) * ((n : ℝ) ^ (-(1 : ℝ) / ((K - 1 : ℕ) : ℝ))) +
          C₃ * M_prof * Real.sqrt (Real.log (2 / (δ / 2)) / (n : ℝ))
    have hbound_le : bound_half ≤ ε / 8 := by linarith only [h8bound]
    refine ⟨E, hE_meas, by linarith only [hE_prob_half, hδ0], ?_⟩
    intro ω hω
    obtain ⟨hx_norm, h_sup⟩ := hE_good ω hω
    let sample : Fin n → X × Fin K := fun i => (X_samp i ω, Y_samp i ω)
    let W : X →L[ℝ] UL.ZeroSumSubspace K := baseW sample
    let ρ : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) := baseRho sample
    let ρ_τ : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) := learnerRho sample
    obtain ⟨hW_norm, hρ_simp, hρ_lip⟩ := hbase_feas sample
    obtain ⟨hρτ_simp, hρτ_lip_tight, h1mτβ, hρτ_lb⟩ :=
      smoothedHead_props hK hβ hτ_pos hτ_half hρ_simp hρ_lip
    have hρτ_lip : LipschitzWith (Real.toNNReal β) ρ_τ :=
      hρτ_lip_tight.weaken (Real.toNNReal_le_toNNReal h1mτβ)
    change sSup ((fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
      |(∫ xy, UL.Proof_thm_C_1_Race3.evalBallProfile L f xy.1 xy.2 ∂ν) -
        ((1 : ℝ) / (n : ℝ)) *
          ∑ i : Fin n, UL.Proof_thm_C_1_Race3.evalBallProfile L f (X_samp i ω) (Y_samp i ω)|) ''
      UL.ScoreProfileClass X K L R C_prof M_prof) ≤ bound_half at h_sup
    obtain ⟨hdev_s_learn, hdev_s_comp, hdev_l_learn, hdev_l_comp⟩ :=
      joint_pop_emp_deviations hK hn hL hR hβ hlam hM hTmin_pos hTmin_le hTmin_lb
        hτ_pos hτ_half ν hX_bound (fun i => X_samp i ω) (fun i => Y_samp i ω) hx_norm
        (h_sup.trans hbound_le) hW_norm hρτ_simp hρτ_lip hρτ_lb
    have hV0_mem : (0 : X →L[ℝ] UL.ZeroSumSubspace K) ∈ {V | UL.hilbertSchmidtNorm V ≤ R} := by
      change UL.hilbertSchmidtNorm 0 ≤ R
      rw [UL.Proof_lem_C_2.hilbertSchmidtNorm_zero]
      exact hR.le
    have hn_pos : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hn
    refine ⟨?_, ?_⟩
    · -- Smooth-entropy population guarantee
      intro Φ hΦ
      suffices h_le_sInf :
          (∫ xy, UL.finiteCanonicalLoss Φ (ρ_τ (W xy.1)) xy.2 ∂ν) - ε ≤
            sInf ((fun V : X →L[ℝ] UL.ZeroSumSubspace K =>
              ∫ xy, UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 ∂ν) ''
              {V | UL.hilbertSchmidtNorm V ≤ R}) by
        linarith only [h_le_sInf]
      refine le_csInf ⟨_, ⟨0, hV0_mem, rfl⟩⟩ ?_
      rintro _ ⟨V, hV, rfl⟩
      have hd1 := (abs_le.mp (hdev_s_learn Φ hΦ)).2
      have hd2 := (abs_le.mp (hdev_s_comp Φ hΦ V hV)).1
      have hbias_avg :
          ((1 : ℝ) / (n : ℝ)) *
              (∑ i : Fin n, UL.finiteCanonicalLoss Φ (ρ_τ (W (X_samp i ω))) (Y_samp i ω)) -
            ((1 : ℝ) / (n : ℝ)) *
              (∑ i : Fin n, UL.finiteCanonicalLoss Φ (ρ (W (X_samp i ω))) (Y_samp i ω)) ≤
          ε / 8 := by
        have hpt : ∀ i : Fin n,
            UL.finiteCanonicalLoss Φ (ρ_τ (W (X_samp i ω))) (Y_samp i ω) -
              UL.finiteCanonicalLoss Φ (ρ (W (X_samp i ω))) (Y_samp i ω) ≤
            Real.sqrt 2 * lam * τ := fun i =>
          smooth_entropy_smoothing_bias hK hΦ hτ_pos hτ_half (hρ_simp (W (X_samp i ω))) (Y_samp i ω)
        have hsum := Finset.sum_le_sum fun i (_ : i ∈ Finset.univ) => hpt i
        rw [Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
          nsmul_eq_mul] at hsum
        have hmul := mul_le_mul_of_nonneg_left hsum (by positivity : (0 : ℝ) ≤ 1 / (n : ℝ))
        have hrew : (1 / (n : ℝ)) * ((n : ℝ) * (Real.sqrt 2 * lam * τ)) =
            Real.sqrt 2 * lam * τ := by field_simp [hn_pos.ne']
        have hlhs_rew :
            (1 / (n : ℝ)) *
              ((∑ i : Fin n, UL.finiteCanonicalLoss Φ (ρ_τ (W (X_samp i ω))) (Y_samp i ω)) -
                ∑ i : Fin n, UL.finiteCanonicalLoss Φ (ρ (W (X_samp i ω))) (Y_samp i ω)) =
            ((1 : ℝ) / (n : ℝ)) *
              (∑ i : Fin n, UL.finiteCanonicalLoss Φ (ρ_τ (W (X_samp i ω))) (Y_samp i ω)) -
            ((1 : ℝ) / (n : ℝ)) *
              (∑ i : Fin n, UL.finiteCanonicalLoss Φ (ρ (W (X_samp i ω))) (Y_samp i ω)) := by ring
        linarith only [hmul, hrew, hlhs_rew, hbias_smooth]
      have hemp := hbase_emp sample hx_norm lam M hlam hM Φ hΦ V hV
      linarith only [hd1, hd2, hbias_avg, hemp, hε0]
    · -- Multi-temperature log-loss population guarantee
      intro T hT
      suffices h_le_sInf :
          (∫ xy, (-T * Real.log (ρ_τ (W xy.1) xy.2)) ∂ν) - ε ≤
            sInf ((fun V : X →L[ℝ] UL.ZeroSumSubspace K =>
              ∫ xy, logMatchingLoss T (V xy.1) xy.2 ∂ν) ''
              {V | UL.hilbertSchmidtNorm V ≤ R}) by
        linarith only [h_le_sInf]
      refine le_csInf ⟨_, ⟨0, hV0_mem, rfl⟩⟩ ?_
      rintro _ ⟨V, hV, rfl⟩
      have hd1 := (abs_le.mp (hdev_l_learn T hT)).2
      have hd2 := (abs_le.mp (hdev_l_comp T hT V hV)).1
      have hT_lb : (1 : ℝ) / (2 * β) ≤ T := hTmin_lb.trans hT.1
      have hemp_log := empirical_smoothed_log_bound (gam := (0 : ℝ)) hK hn hβ hT_lb hτ_pos hτ_half
        (fun i => ρ (W (X_samp i ω))) (fun i => hρ_simp (W (X_samp i ω)))
        (fun i => Y_samp i ω) (fun i => V (X_samp i ω))
        (fun lam' M' hlam' hM' Φ' hΦ' => by
          rw [add_zero]
          exact hbase_emp sample hx_norm lam' M' hlam' hM' Φ' hΦ' V hV)
      dsimp only at hemp_log
      rw [add_zero] at hemp_log
      change ((1 : ℝ) / (n : ℝ)) *
          ∑ i : Fin n, (-T * Real.log (ρ_τ (W (X_samp i ω)) (Y_samp i ω))) ≤
        ((1 : ℝ) / (n : ℝ)) *
          ∑ i : Fin n,
            (T * Real.log (∑ j : Fin K,
                Real.exp ((V (X_samp i ω) : EuclideanSpace ℝ (Fin K)) j / T)) -
              (V (X_samp i ω) : EuclideanSpace ℝ (Fin K)) (Y_samp i ω)) +
          2 * T * τ at hemp_log
      have h2Tτ : 2 * T * τ ≤ ε / 8 := by
        have hT2 : 2 * T ≤ 2 * T_max := by linarith only [hT.2]
        have hm : 2 * T * τ ≤ 2 * T_max * τ := mul_le_mul_of_nonneg_right hT2 hτ_pos.le
        linarith only [hm, hbias_log]
      change (∫ xy, (-T * Real.log (ρ_τ (W xy.1) xy.2)) ∂ν) - ε ≤
        ∫ xy, (T * Real.log (∑ j : Fin K, Real.exp ((V xy.1 : EuclideanSpace ℝ (Fin K)) j / T)) -
          (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2) ∂ν
      linarith only [hd1, hd2, hemp_log, h2Tτ, hε0]

end UL.Proof_cor_C_7

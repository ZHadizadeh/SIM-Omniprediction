import UL.Stmt.lem_C_3
import UL.Proof.thm_C_1.Race3.H1_UniverseTransfer
import UL.Proof.cor_C_7.H2_LogAndProfiles
set_option autoImplicit false

namespace UL.Proof_cor_C_7

open MeasureTheory

/-! ### 1. Universe-polymorphic `S_lem_C_3` constant and uniform-convergence transfer -/

/-- Canonical constant `C₃(K)` extracted from `h_lem_C_3` (depending only on `h_lem_C_3`'s
fixed universes `u₁, u₂`, so `cSamp (chooseC3 h_lem_C_3)` can be supplied at the top level of
`S_cor_C_7` before any sample-space or Hilbert-space universe is quantified). -/
noncomputable def chooseC3.{u₁, u₂} (h_lem_C_3 : UL.S_lem_C_3.{u₁, u₂}) (K : ℕ) : ℝ :=
  open Classical in
  if hK : 2 ≤ K then Classical.choose (h_lem_C_3 K hK) else 1

lemma chooseC3_pos.{u₁, u₂} (h_lem_C_3 : UL.S_lem_C_3.{u₁, u₂}) (K : ℕ) :
    0 < chooseC3 h_lem_C_3 K := by
  classical
  unfold chooseC3
  split_ifs with hK
  · exact (Classical.choose_spec (h_lem_C_3 K hK)).1
  · exact zero_lt_one

private noncomputable def pushProf {E₁ E₂ : Type*}
    [NormedAddCommGroup E₁] [InnerProductSpace ℝ E₁]
    [NormedAddCommGroup E₂] [InnerProductSpace ℝ E₂]
    (e : E₁ ≃ₗᵢ[ℝ] E₂) {K : ℕ} {L : ℝ}
    (f : Metric.closedBall (0 : E₁) L × Fin K → ℝ) :
    Metric.closedBall (0 : E₂) L × Fin K → ℝ :=
  fun p => f (⟨e.symm p.1.1, by
    have hp := p.1.2
    rw [Metric.mem_closedBall, dist_zero_right] at hp ⊢
    rwa [e.symm.norm_map]⟩, p.2)

private lemma pushProf_mem {E₁ E₂ : Type*}
    [NormedAddCommGroup E₁] [InnerProductSpace ℝ E₁] [CompleteSpace E₁]
    [TopologicalSpace.SeparableSpace E₁]
    [NormedAddCommGroup E₂] [InnerProductSpace ℝ E₂] [CompleteSpace E₂]
    [TopologicalSpace.SeparableSpace E₂]
    (e : E₁ ≃ₗᵢ[ℝ] E₂) {K : ℕ} {L R C M₀ : ℝ}
    {f : Metric.closedBall (0 : E₁) L × Fin K → ℝ}
    (hf : f ∈ UL.ScoreProfileClass E₁ K L R C M₀) :
    pushProf e f ∈ UL.ScoreProfileClass E₂ K L R C M₀ := by
  rcases hf with ⟨hK, hL, hR, hC, hM₀, W, a, hW, ha, hfa⟩
  refine ⟨hK, hL, hR, hC, hM₀,
    W.comp e.symm.toContinuousLinearEquiv.toContinuousLinearMap, a, ?_, ha, ?_⟩
  · rwa [UL.Proof_thm_C_1_Race3.hilbertSchmidtNorm_comp_lie W e.symm]
  · intro x₂ y
    unfold pushProf
    rw [hfa]
    rfl

private lemma pushProf_symm_cancel {E₁ E₂ : Type*}
    [NormedAddCommGroup E₁] [InnerProductSpace ℝ E₁]
    [NormedAddCommGroup E₂] [InnerProductSpace ℝ E₂]
    (e : E₁ ≃ₗᵢ[ℝ] E₂) {K : ℕ} {L : ℝ}
    (f : Metric.closedBall (0 : E₂) L × Fin K → ℝ) :
    pushProf e (pushProf e.symm f) = f := by
  funext ⟨⟨x, hx⟩, y⟩
  unfold pushProf
  dsimp only
  congr 1
  ext1
  · exact Subtype.ext (e.apply_symm_apply x)
  · rfl

private lemma evalBallProfile_pushProf {E₁ E₂ : Type*}
    [NormedAddCommGroup E₁] [InnerProductSpace ℝ E₁]
    [NormedAddCommGroup E₂] [InnerProductSpace ℝ E₂]
    (e : E₁ ≃ₗᵢ[ℝ] E₂) {K : ℕ} {L : ℝ}
    (f : Metric.closedBall (0 : E₁) L × Fin K → ℝ) (x : E₁) (y : Fin K) :
    UL.Proof_thm_C_1_Race3.evalBallProfile L (pushProf e f) (e x) y =
      UL.Proof_thm_C_1_Race3.evalBallProfile L f x y := by
  classical
  unfold UL.Proof_thm_C_1_Race3.evalBallProfile
  have hmem_iff : e x ∈ Metric.closedBall (0 : E₂) L ↔ x ∈ Metric.closedBall (0 : E₁) L := by
    simp [Metric.mem_closedBall, dist_zero_right, e.norm_map]
  by_cases hx : x ∈ Metric.closedBall (0 : E₁) L
  · have hex : e x ∈ Metric.closedBall (0 : E₂) L := hmem_iff.mpr hx
    rw [dif_pos hex, dif_pos hx]
    unfold pushProf
    dsimp only
    congr 1
    ext1
    · exact Subtype.ext (e.symm_apply_apply x)
    · rfl
  · have hex : e x ∉ Metric.closedBall (0 : E₂) L := fun h => hx (hmem_iff.mp h)
    rw [dif_neg hex, dif_neg hx]

/-- Universe-polymorphic transfer of `h_lem_C_3 K hK` to arbitrary `(X : Type v₁)` and
`(Ω : Type v₂)` with the fixed constant `chooseC3 h_lem_C_3 K`, intersected with the
full-measure sample-norm event `∀ i : Fin n, ‖X_samp i ω‖ ≤ L`. -/
theorem lem_C_3_univ.{u₁, u₂, v₁, v₂}
    (h_lem_C_3 : UL.S_lem_C_3.{u₁, u₂}) {K : ℕ} (hK : 2 ≤ K) :
    let C₃ : ℝ := chooseC3 h_lem_C_3 K
    ∀ (X : Type v₁) [NormedAddCommGroup X] [InnerProductSpace ℝ X]
      [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
      [MeasurableSpace X] [BorelSpace X]
      (L R C M₀ : ℝ),
      0 < L → 0 < R → 0 < C → 0 < M₀ →
      ∀ (n : ℕ), 1 ≤ n →
      ∀ (δ : ℝ), 0 < δ → δ < 1 →
      ∀ (ν : Measure (X × Fin K)) [IsProbabilityMeasure ν],
        (∀ᵐ xy ∂ν, ‖xy.1‖ ≤ L) →
        ∀ (Ω : Type v₂) [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
          (X_samp : Fin n → Ω → X) (Y_samp : Fin n → Ω → Fin K),
          (∀ i : Fin n, Measurable (X_samp i)) →
          (∀ i : Fin n, Measurable (Y_samp i)) →
          ProbabilityTheory.iIndepFun (fun i ω => (X_samp i ω, Y_samp i ω)) μ →
          (∀ i : Fin n, Measure.map (fun ω => (X_samp i ω, Y_samp i ω)) μ = ν) →
          let m : ℕ := K - 1
          let A₀ : ℝ := L * R
          let D₀ : ℝ := M₀ + C * A₀
          let evalProfile : (Metric.closedBall (0 : X) L × Fin K → ℝ) → X → Fin K → ℝ :=
            open Classical in
            fun f x y => if hx : x ∈ Metric.closedBall (0 : X) L then f (⟨x, hx⟩, y) else 0
          let bound : ℝ :=
            if m ≤ 2 then
              C₃ * (D₀ * Real.log (2 * (n : ℝ)) + M₀ * Real.sqrt (Real.log (2 / δ))) /
                Real.sqrt (n : ℝ)
            else
              C₃ * D₀ * ((n : ℝ) ^ (-(1 : ℝ) / (m : ℝ))) +
                C₃ * M₀ * Real.sqrt (Real.log (2 / δ) / (n : ℝ))
          ∃ E : Set Ω, MeasurableSet E ∧ (μ E).toReal ≥ 1 - δ ∧
            ∀ ω ∈ E,
              (∀ i : Fin n, ‖X_samp i ω‖ ≤ L) ∧
              sSup ((fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
                |(∫ xy, evalProfile f xy.1 xy.2 ∂ν) -
                  ((1 : ℝ) / (n : ℝ)) *
                    ∑ i : Fin n, evalProfile f (X_samp i ω) (Y_samp i ω)|) ''
                UL.ScoreProfileClass X K L R C M₀) ≤ bound := by
  intro C₃
  have hC₃_eq : C₃ = Classical.choose (h_lem_C_3 K hK) := by
    dsimp [C₃, chooseC3]
    rw [dif_pos hK]
  have hCK := (Classical.choose_spec (h_lem_C_3 K hK)).2
  rw [← hC₃_eq] at hCK
  intro X _ _ _ _ _ _ L R C M₀ hL hR hC hM₀ n hn δ hδ0 hδ1
    ν _ hX_bound Ω _ μ _ X_samp Y_samp hX_meas hY_meas hindep hident m A₀ D₀ evalProfile bound
  obtain ⟨w, b, _⟩ := exists_hilbertBasis ℝ X
  haveI : Countable w := UL.Proof_thm_C_1_Race3.countable_of_hilbertBasis b
  let ι₀ : Type 0 := Shrink.{0} w
  let e₀ : w ≃ ι₀ := equivShrink.{0} w
  let X₀ : Type 0 := lp (fun _ : ι₀ => ℝ) 2
  let X' : Type u₁ := lp (fun _ : ULift.{u₁} ι₀ => ℝ) 2
  let Φ₀ : X ≃ₗᵢ[ℝ] X₀ := UL.Proof_thm_C_1_Race3.reindexHilbertEquiv b e₀
  let b₀ : HilbertBasis ι₀ ℝ X₀ := HilbertBasis.ofRepr (LinearIsometryEquiv.refl ℝ X₀)
  let ξ : X₀ ≃ₗᵢ[ℝ] X' := UL.Proof_thm_C_1_Race3.reindexHilbertEquiv b₀ Equiv.ulift.symm
  let Φ : X ≃ₗᵢ[ℝ] X' := Φ₀.trans ξ
  haveI : TopologicalSpace.SeparableSpace X' :=
    Φ.surjective.denseRange.separableSpace Φ.continuous
  letI : MeasurableSpace X₀ := borel X₀
  haveI : BorelSpace X₀ := ⟨rfl⟩
  letI : MeasurableSpace X' := borel X'
  haveI : BorelSpace X' := ⟨rfl⟩
  have hΦ₀_meas : Measurable Φ₀ := Φ₀.continuous.measurable
  have hξ_meas : Measurable ξ := ξ.continuous.measurable
  have hΦ_meas : Measurable Φ := Φ.continuous.measurable
  let mapXY : X × Fin K → X' × Fin K := Prod.map Φ id
  have hmapXY_meas : Measurable mapXY := hΦ_meas.prodMap measurable_id
  let ν' : Measure (X' × Fin K) := Measure.map mapXY ν
  haveI : IsProbabilityMeasure ν' :=
    ⟨by rw [Measure.map_apply hmapXY_meas MeasurableSet.univ, Set.preimage_univ, measure_univ]⟩
  have hX'_bound : ∀ᵐ xy' ∂ν', ‖xy'.1‖ ≤ L := by
    have hm : MeasurableSet {xy' : X' × Fin K | ‖xy'.1‖ ≤ L} :=
      measurableSet_le (continuous_norm.measurable.comp measurable_fst) measurable_const
    rw [ae_map_iff hmapXY_meas.aemeasurable hm]
    refine hX_bound.mono fun xy hxy => ?_
    simpa [mapXY, Φ.norm_map] using hxy
  let Ω₀ : Type 0 := Fin n → X₀ × Fin K
  let Ω' : Type u₂ := ULift.{u₂} Ω₀
  have h_up_meas : Measurable (ULift.up : Ω₀ → Ω') := fun _ => id
  have h_down_meas : Measurable (ULift.down : Ω' → Ω₀) := fun _ => id
  let Ψ : Ω → Ω' := fun ω => ULift.up (fun i => (Φ₀ (X_samp i ω), Y_samp i ω))
  have hΨ_meas : Measurable Ψ :=
    h_up_meas.comp
      (measurable_pi_lambda _ fun i => (hΦ₀_meas.comp (hX_meas i)).prodMk (hY_meas i))
  let μ' : Measure Ω' := Measure.map Ψ μ
  haveI : IsProbabilityMeasure μ' :=
    ⟨by rw [Measure.map_apply hΨ_meas MeasurableSet.univ, Set.preimage_univ, measure_univ]⟩
  let X'_samp : Fin n → Ω' → X' := fun i ω' => ξ (ω'.down i).1
  let Y'_samp : Fin n → Ω' → Fin K := fun i ω' => (ω'.down i).2
  have hX'_meas : ∀ i : Fin n, Measurable (X'_samp i) := fun i =>
    hξ_meas.comp (measurable_fst.comp ((measurable_pi_apply i).comp h_down_meas))
  have hY'_meas : ∀ i : Fin n, Measurable (Y'_samp i) := fun i =>
    measurable_snd.comp ((measurable_pi_apply i).comp h_down_meas)
  have hZ'_comp : ∀ i : Fin n,
      (fun ω' : Ω' => (X'_samp i ω', Y'_samp i ω')) ∘ Ψ =
        fun ω : Ω => mapXY (X_samp i ω, Y_samp i ω) := fun _ => funext fun _ => rfl
  have hident' : ∀ i : Fin n,
      Measure.map (fun ω' => (X'_samp i ω', Y'_samp i ω')) μ' = ν' := by
    intro i
    rw [Measure.map_map ((hX'_meas i).prodMk (hY'_meas i)) hΨ_meas, hZ'_comp i]
    have hcomp_eq :
        (fun ω : Ω => mapXY (X_samp i ω, Y_samp i ω)) =
          mapXY ∘ (fun ω : Ω => (X_samp i ω, Y_samp i ω)) := rfl
    rw [hcomp_eq, ← Measure.map_map hmapXY_meas ((hX_meas i).prodMk (hY_meas i)), hident i]
  have hindep' : ProbabilityTheory.iIndepFun (fun i ω' => (X'_samp i ω', Y'_samp i ω')) μ' := by
    have hindep_comp : ProbabilityTheory.iIndepFun
        (fun i ω => mapXY (X_samp i ω, Y_samp i ω)) μ :=
      hindep.comp (fun _ => mapXY) (fun _ => hmapXY_meas)
    rw [ProbabilityTheory.iIndepFun_iff_measure_inter_preimage_eq_mul]
    intro S sets hsets
    have hmeas_inter :
        MeasurableSet (⋂ i ∈ S, (fun ω' : Ω' => (X'_samp i ω', Y'_samp i ω')) ⁻¹' sets i) :=
      MeasurableSet.biInter S.countable_toSet fun i hi =>
        ((hX'_meas i).prodMk (hY'_meas i)) (hsets i hi)
    rw [Measure.map_apply hΨ_meas hmeas_inter]
    have hpre_inter :
        Ψ ⁻¹' (⋂ i ∈ S, (fun ω' : Ω' => (X'_samp i ω', Y'_samp i ω')) ⁻¹' sets i) =
          ⋂ i ∈ S, (fun ω : Ω => mapXY (X_samp i ω, Y_samp i ω)) ⁻¹' sets i := by
      ext ω; simp only [Set.mem_preimage, Set.mem_iInter]; rfl
    rw [hpre_inter, hindep_comp.measure_inter_preimage_eq_mul S hsets]
    refine Finset.prod_congr rfl fun i hi => ?_
    rw [Measure.map_apply hΨ_meas (((hX'_meas i).prodMk (hY'_meas i)) (hsets i hi))]
    rfl
  obtain ⟨E', hE'_meas, hE'_prob, hE'_sup⟩ :=
    hCK X' L R C M₀ hL hR hC hM₀ n hn δ hδ0 hδ1 ν' hX'_bound Ω' μ' X'_samp Y'_samp
      hX'_meas hY'_meas hindep' hident'
  have hdev_eq : ∀ ω : Ω,
      ((fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
        |(∫ xy, evalProfile f xy.1 xy.2 ∂ν) -
          ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalProfile f (X_samp i ω) (Y_samp i ω)|) ''
        UL.ScoreProfileClass X K L R C M₀) =
      ((fun f' : Metric.closedBall (0 : X') L × Fin K → ℝ =>
        |(∫ xy', UL.Proof_thm_C_1_Race3.evalBallProfile L f' xy'.1 xy'.2 ∂ν') -
          ((1 : ℝ) / (n : ℝ)) *
            ∑ i : Fin n,
              UL.Proof_thm_C_1_Race3.evalBallProfile L f'
                (X'_samp i (Ψ ω)) (Y'_samp i (Ψ ω))|) ''
        UL.ScoreProfileClass X' K L R C M₀) := by
    intro ω
    have heval_eq : evalProfile = UL.Proof_thm_C_1_Race3.evalBallProfile (X := X) (K := K) L := rfl
    rw [heval_eq]
    have hpoint : ∀ f : Metric.closedBall (0 : X) L × Fin K → ℝ,
        f ∈ UL.ScoreProfileClass X K L R C M₀ →
        |(∫ xy', UL.Proof_thm_C_1_Race3.evalBallProfile L (pushProf Φ f) xy'.1 xy'.2 ∂ν') -
          ((1 : ℝ) / (n : ℝ)) *
            ∑ i : Fin n,
              UL.Proof_thm_C_1_Race3.evalBallProfile L (pushProf Φ f)
                (X'_samp i (Ψ ω)) (Y'_samp i (Ψ ω))| =
        |(∫ xy, UL.Proof_thm_C_1_Race3.evalBallProfile L f xy.1 xy.2 ∂ν) -
          ((1 : ℝ) / (n : ℝ)) *
            ∑ i : Fin n,
              UL.Proof_thm_C_1_Race3.evalBallProfile L f (X_samp i ω) (Y_samp i ω)| := by
      intro f hf
      have hf' : pushProf Φ f ∈ UL.ScoreProfileClass X' K L R C M₀ := pushProf_mem Φ hf
      have hint :
          ∫ xy', UL.Proof_thm_C_1_Race3.evalBallProfile L (pushProf Φ f) xy'.1 xy'.2 ∂ν' =
            ∫ xy, UL.Proof_thm_C_1_Race3.evalBallProfile L f xy.1 xy.2 ∂ν := by
        dsimp [ν']
        rw [integral_map hmapXY_meas.aemeasurable
          (UL.Proof_thm_C_1_Race3.measurable_evalBallProfile hf').aestronglyMeasurable]
        refine integral_congr_ae (Filter.Eventually.of_forall fun xy => ?_)
        exact evalBallProfile_pushProf Φ f xy.1 xy.2
      have hsum :
          (∑ i : Fin n,
            UL.Proof_thm_C_1_Race3.evalBallProfile L (pushProf Φ f)
              (X'_samp i (Ψ ω)) (Y'_samp i (Ψ ω))) =
          ∑ i : Fin n,
            UL.Proof_thm_C_1_Race3.evalBallProfile L f (X_samp i ω) (Y_samp i ω) :=
        Finset.sum_congr rfl fun i _ => evalBallProfile_pushProf Φ f (X_samp i ω) (Y_samp i ω)
      rw [hint, hsum]
    ext r
    constructor
    · rintro ⟨f, hf, rfl⟩
      exact ⟨pushProf Φ f, pushProf_mem Φ hf, hpoint f hf⟩
    · rintro ⟨f', hf', rfl⟩
      let f : Metric.closedBall (0 : X) L × Fin K → ℝ := pushProf Φ.symm f'
      have hf : f ∈ UL.ScoreProfileClass X K L R C M₀ := pushProf_mem Φ.symm hf'
      have hpush_f : pushProf Φ f = f' := pushProf_symm_cancel Φ f'
      refine ⟨f, hf, ?_⟩
      dsimp only
      rw [← hpoint f hf, hpush_f]
  let E_norm : Set Ω := ⋂ i : Fin n, {ω : Ω | ‖X_samp i ω‖ ≤ L}
  have hEnorm_meas : MeasurableSet E_norm :=
    MeasurableSet.iInter fun i =>
      measurableSet_le (continuous_norm.measurable.comp (hX_meas i)) measurable_const
  have hEnorm_compl : μ E_normᶜ = 0 := by
    have hcompl_eq : E_normᶜ = ⋃ i : Fin n, {ω : Ω | L < ‖X_samp i ω‖} := by
      ext ω; simp [E_norm, not_le]
    rw [hcompl_eq, measure_iUnion_null_iff]
    intro i
    have hB_meas : MeasurableSet {xy : X × Fin K | L < ‖xy.1‖} :=
      measurableSet_lt measurable_const (continuous_norm.measurable.comp measurable_fst)
    have hB_null : ν {xy : X × Fin K | L < ‖xy.1‖} = 0 := by
      have hae : ν {xy : X × Fin K | ¬ ‖xy.1‖ ≤ L} = 0 := ae_iff.mp hX_bound
      simpa [not_le] using hae
    have hpre :
        {ω : Ω | L < ‖X_samp i ω‖} =
          (fun ω : Ω => (X_samp i ω, Y_samp i ω)) ⁻¹' {xy : X × Fin K | L < ‖xy.1‖} := rfl
    rw [hpre, ← Measure.map_apply ((hX_meas i).prodMk (hY_meas i)) hB_meas, hident i, hB_null]
  let E : Set Ω := (Ψ ⁻¹' E') ∩ E_norm
  have hE_meas : MeasurableSet E := (hΨ_meas hE'_meas).inter hEnorm_meas
  have hE_mu : μ E = μ' E' := by
    have hdiff_null : μ ((Ψ ⁻¹' E') \ E_norm) = 0 :=
      le_antisymm ((measure_mono fun _ h => h.2).trans_eq hEnorm_compl) (zero_le _)
    have hadd := measure_inter_add_diff (μ := μ) (Ψ ⁻¹' E') hEnorm_meas
    rw [hdiff_null, add_zero] at hadd
    dsimp [E, μ']
    rw [hadd, Measure.map_apply hΨ_meas hE'_meas]
  refine ⟨E, hE_meas, ?_, ?_⟩
  · rw [hE_mu]; exact hE'_prob
  · intro ω hω
    refine ⟨fun i => Set.mem_iInter.mp hω.2 i, ?_⟩
    rw [hdev_eq ω]
    exact hE'_sup (Ψ ω) hω.1

end UL.Proof_cor_C_7

import UL.Stmt.lem_A_1
import UL.Proof.lem_A_1.H1_FaceSubgrad
import UL.Proof.lem_A_1.H2_MatchingApprox
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_lem_A_1 : S_lem_A_1 := by
  unfold S_lem_A_1
  intro K hK Φ hCont hConv hDiff
  refine ⟨fun q hq => Proof_lem_A_1.properness hConv hDiff hq,
    fun p hp y => Proof_lem_A_1.lower_bound hConv hDiff hp y,
    fun p hp => Proof_lem_A_1.approx_matching_loss hK hCont hConv hDiff hp,
    fun p hp => Proof_lem_A_1.interior_attainment hK hCont hConv hDiff hp⟩

end UL

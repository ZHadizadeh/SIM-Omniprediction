import UL.Stmt.lem_A_1
set_option autoImplicit false

namespace UL
namespace Proof_lem_A_1

lemma sum_apply {K : ℕ} {α : Type*} (s : Finset α)
    (f : α → EuclideanSpace ℝ (Fin K)) (j : Fin K) :
    (∑ a ∈ s, f a) j = ∑ a ∈ s, f a j := by
  classical
  induction s using Finset.induction_on with
  | empty => rfl
  | @insert a s ha ih => simp [Finset.sum_insert ha, ih]

lemma inner_eq_sum {K : ℕ} (x y : EuclideanSpace ℝ (Fin K)) :
    inner ℝ x y = ∑ j : Fin K, x j * y j := by
  rw [PiLp.inner_apply]
  refine Finset.sum_congr rfl (fun j _ => ?_)
  simp [mul_comm]

lemma onesVec_apply (K : ℕ) (j : Fin K) : onesVec K j = 1 := rfl

lemma uniformVec_apply (K : ℕ) (j : Fin K) : uniformVec K j = 1 / (K : ℝ) := by
  simp [uniformVec, onesVec_apply]

lemma single_apply {K : ℕ} (y j : Fin K) :
    (EuclideanSpace.single y (1 : ℝ)) j = if j = y then 1 else 0 := by
  simp [EuclideanSpace.single_apply]

lemma inner_single_right {K : ℕ} (x : EuclideanSpace ℝ (Fin K)) (y : Fin K) :
    inner ℝ x (EuclideanSpace.single y (1 : ℝ)) = x y := by
  rw [inner_eq_sum]
  simp [single_apply]

lemma sum_smul_single {K : ℕ} (q : EuclideanSpace ℝ (Fin K)) :
    ∑ y : Fin K, q y • EuclideanSpace.single y (1 : ℝ) = q := by
  ext j
  rw [sum_apply]
  simp [single_apply]

lemma simplex_convex (K : ℕ) : Convex ℝ (Simplex K) := by
  intro x hx y hy a b ha hb hab
  refine ⟨fun j => ?_, ?_⟩
  · change 0 ≤ a * x j + b * y j
    exact add_nonneg (mul_nonneg ha (hx.1 j)) (mul_nonneg hb (hy.1 j))
  · have h : ∑ j : Fin K, (a • x + b • y) j =
        a * (∑ j : Fin K, x j) + b * (∑ j : Fin K, y j) := by
      calc ∑ j : Fin K, (a • x + b • y) j
          = ∑ j : Fin K, (a * x j + b * y j) := rfl
        _ = (∑ j : Fin K, a * x j) + ∑ j : Fin K, b * y j := Finset.sum_add_distrib
        _ = a * (∑ j : Fin K, x j) + b * (∑ j : Fin K, y j) := by
              rw [← Finset.mul_sum, ← Finset.mul_sum]
    rw [h, hx.2, hy.2]
    linarith

lemma simplexFace_subset_simplex (K : ℕ) (J : Finset (Fin K)) :
    SimplexFace K J ⊆ Simplex K :=
  fun _ hq => hq.1

lemma simplexFace_convex (K : ℕ) (J : Finset (Fin K)) : Convex ℝ (SimplexFace K J) := by
  intro x hx y hy a b ha hb hab
  refine ⟨simplex_convex K hx.1 hy.1 ha hb hab, fun j hj => ?_⟩
  change a * x j + b * y j = 0
  rw [hx.2 j hj, hy.2 j hj]
  ring

lemma single_mem_simplex {K : ℕ} (y : Fin K) :
    EuclideanSpace.single y (1 : ℝ) ∈ Simplex K := by
  refine ⟨fun j => ?_, ?_⟩
  · rw [single_apply]
    split_ifs <;> norm_num
  · simp [single_apply]

lemma single_mem_simplexFace {K : ℕ} {J : Finset (Fin K)} {y : Fin K} (hy : y ∈ J) :
    EuclideanSpace.single y (1 : ℝ) ∈ SimplexFace K J := by
  refine ⟨single_mem_simplex y, fun j hj => ?_⟩
  rw [single_apply, if_neg]
  intro hEq
  exact hj (hEq ▸ hy)

lemma mem_posSupport_iff {K : ℕ} (p : EuclideanSpace ℝ (Fin K)) (j : Fin K) :
    j ∈ posSupport p ↔ 0 < p j := by
  simp [posSupport]

lemma eq_zero_of_not_mem_posSupport {K : ℕ} {p : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ Simplex K) {j : Fin K} (hj : j ∉ posSupport p) : p j = 0 := by
  rw [mem_posSupport_iff] at hj
  linarith [hp.1 j]

lemma posSupport_nonempty {K : ℕ} {p : EuclideanSpace ℝ (Fin K)} (hp : p ∈ Simplex K) :
    (posSupport p).Nonempty := by
  by_contra hEmpty
  rw [Finset.not_nonempty_iff_eq_empty] at hEmpty
  have hzero : ∀ j : Fin K, p j = 0 := by
    intro j
    apply eq_zero_of_not_mem_posSupport hp
    rw [hEmpty]
    simp
  have hsum : ∑ j : Fin K, p j = 0 := Finset.sum_eq_zero (fun j _ => hzero j)
  linarith [hp.2]

lemma mem_simplexFaceRelint_posSupport {K : ℕ} {p : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ Simplex K) :
    p ∈ SimplexFaceRelint K (posSupport p) := by
  refine ⟨⟨hp, fun j hj => eq_zero_of_not_mem_posSupport hp hj⟩, fun j hj => ?_⟩
  exact (mem_posSupport_iff p j).mp hj

lemma mem_simplexFace_of_posSupport_subset {K : ℕ} {q : EuclideanSpace ℝ (Fin K)}
    {J : Finset (Fin K)} (hq : q ∈ Simplex K) (hsub : posSupport q ⊆ J) :
    q ∈ SimplexFace K J := by
  refine ⟨hq, fun j hj => eq_zero_of_not_mem_posSupport hq (fun hjq => hj (hsub hjq))⟩

lemma faceGrad_spec {K : ℕ} {Φ : Simplex K → ℝ} {J : Finset (Fin K)}
    {p : EuclideanSpace ℝ (Fin K)} (hex : ∃ g, HasFaceGradAt Φ J p g) :
    HasFaceGradAt Φ J p (faceGrad Φ J p) := by
  unfold faceGrad
  rw [dif_pos hex]
  exact Classical.choose_spec hex

lemma mem_zeroSumSubspace_iff {K : ℕ} (g : EuclideanSpace ℝ (Fin K)) :
    g ∈ ZeroSumSubspace K ↔ inner ℝ (onesVec K) g = 0 := by
  simp [ZeroSumSubspace]

lemma mem_faceTangentSpace_iff {K : ℕ} {J : Finset (Fin K)} (g : EuclideanSpace ℝ (Fin K)) :
    g ∈ FaceTangentSpace K J ↔ g ∈ ZeroSumSubspace K ∧ ∀ j : Fin K, j ∉ J → g j = 0 := by
  simp [FaceTangentSpace, Submodule.mem_inf, Submodule.mem_iInf]

/-- Convex face-subgradient inequality: if `extendSimplex Φ` is convex on `Simplex K` and has
face gradient `g` at `p ∈ SimplexFace K J`, then `g` is a global subgradient of `extendSimplex Φ`
across `SimplexFace K J`. -/
lemma face_subgrad_ineq {K : ℕ} {Φ : Simplex K → ℝ} {J : Finset (Fin K)}
    {p q g : EuclideanSpace ℝ (Fin K)}
    (hConv : ConvexOn ℝ (Simplex K) (extendSimplex Φ))
    (hp : p ∈ SimplexFace K J) (hq : q ∈ SimplexFace K J)
    (hfderiv : HasFDerivWithinAt (extendSimplex Φ) (innerSL ℝ g) (SimplexFace K J) p) :
    extendSimplex Φ p + inner ℝ g (q - p) ≤ extendSimplex Φ q := by
  by_cases hqp : q = p
  · subst hqp
    simp
  · have hnorm_pos : 0 < ‖q - p‖ := norm_pos_iff.mpr (sub_ne_zero.mpr hqp)
    let Δ : ℝ := extendSimplex Φ q - extendSimplex Φ p - inner ℝ g (q - p)
    suffices hΔ_nonneg : 0 ≤ Δ by
      dsimp [Δ] at hΔ_nonneg
      linarith
    by_contra! hΔ
    let t : ℕ → ℝ := fun n => ((n : ℝ) + 2)⁻¹
    let x : ℕ → EuclideanSpace ℝ (Fin K) := fun n => (1 - t n) • p + t n • q
    have ht_pos : ∀ n : ℕ, 0 < t n := fun n => by
      dsimp [t]
      positivity
    have ht_lt_one : ∀ n : ℕ, t n < 1 := fun n => by
      dsimp [t]
      have hn : (1 : ℝ) < (n : ℝ) + 2 := by linarith [(Nat.cast_nonneg n : (0 : ℝ) ≤ n)]
      exact inv_lt_one_of_one_lt₀ hn
    have hx_mem : ∀ n : ℕ, x n ∈ SimplexFace K J := fun n =>
      simplexFace_convex K J hp hq (by linarith [ht_lt_one n]) (le_of_lt (ht_pos n)) (by ring)
    have hx_sub : ∀ n : ℕ, x n - p = t n • (q - p) := fun n => by
      ext j
      simp only [x, PiLp.add_apply, PiLp.sub_apply, PiLp.smul_apply, smul_eq_mul]
      ring
    have hratio_ge : ∀ n : ℕ,
        (-Δ) / ‖q - p‖ ≤
          ‖x n - p‖⁻¹ *
            ‖extendSimplex Φ (x n) - extendSimplex Φ p - (innerSL ℝ g) (x n - p)‖ := by
      intro n
      have hconv_step :
          extendSimplex Φ (x n) ≤ (1 - t n) * extendSimplex Φ p + t n * extendSimplex Φ q :=
        hConv.2 hp.1 hq.1 (by linarith [ht_lt_one n]) (le_of_lt (ht_pos n)) (by ring)
      have hinner_step : (innerSL ℝ g) (x n - p) = t n * inner ℝ g (q - p) := by
        rw [hx_sub n, map_smul, smul_eq_mul]
        rfl
      have hnum_le :
          extendSimplex Φ (x n) - extendSimplex Φ p - (innerSL ℝ g) (x n - p) ≤ t n * Δ := by
        rw [hinner_step]
        dsimp [Δ]
        linarith
      have hnum_norm :
          t n * (-Δ) ≤ ‖extendSimplex Φ (x n) - extendSimplex Φ p - (innerSL ℝ g) (x n - p)‖ := by
        rw [Real.norm_eq_abs]
        exact le_trans (by linarith)
          (neg_le_abs (extendSimplex Φ (x n) - extendSimplex Φ p - (innerSL ℝ g) (x n - p)))
      have hx_norm : ‖x n - p‖ = t n * ‖q - p‖ := by
        rw [hx_sub n, norm_smul, Real.norm_eq_abs, abs_of_pos (ht_pos n)]
      rw [hx_norm]
      have hinv_nonneg : 0 ≤ (t n * ‖q - p‖)⁻¹ :=
        inv_nonneg.mpr (mul_nonneg (le_of_lt (ht_pos n)) (le_of_lt hnorm_pos))
      calc (-Δ) / ‖q - p‖
          = (t n * ‖q - p‖)⁻¹ * (t n * (-Δ)) := by
              field_simp [(ht_pos n).ne', hnorm_pos.ne']
        _ ≤ (t n * ‖q - p‖)⁻¹ *
              ‖extendSimplex Φ (x n) - extendSimplex Φ p - (innerSL ℝ g) (x n - p)‖ :=
            mul_le_mul_of_nonneg_left hnum_norm hinv_nonneg
    have ht_tendsto : Filter.Tendsto t Filter.atTop (nhds 0) :=
      Filter.Tendsto.inv_tendsto_atTop
        (Filter.Tendsto.atTop_add tendsto_natCast_atTop_atTop tendsto_const_nhds)
    have hx_tendsto : Filter.Tendsto x Filter.atTop (nhds p) := by
      have hx_eq : x = fun n => p + t n • (q - p) := by
        funext n
        ext j
        simp only [x, PiLp.add_apply, PiLp.sub_apply, PiLp.smul_apply, smul_eq_mul]
        ring
      rw [hx_eq]
      simpa using tendsto_const_nhds.add (ht_tendsto.smul_const (q - p))
    have hx_within : Filter.Tendsto x Filter.atTop (nhdsWithin p (SimplexFace K J)) :=
      tendsto_nhdsWithin_of_tendsto_nhds_of_eventually_within x hx_tendsto
        (Filter.Eventually.of_forall hx_mem)
    have hlim : Filter.Tendsto
        (fun n => ‖x n - p‖⁻¹ *
          ‖extendSimplex Φ (x n) - extendSimplex Φ p - (innerSL ℝ g) (x n - p)‖)
        Filter.atTop (nhds 0) :=
      (hasFDerivWithinAt_iff_tendsto.mp hfderiv).comp hx_within
    have hle_zero : (-Δ) / ‖q - p‖ ≤ 0 :=
      le_of_tendsto_of_tendsto tendsto_const_nhds hlim (Filter.Eventually.of_forall hratio_ge)
    have hpos : 0 < (-Δ) / ‖q - p‖ := div_pos (by linarith) hnorm_pos
    linarith

lemma face_max_ineq {K : ℕ} {Φ : Simplex K → ℝ} {J : Finset (Fin K)}
    {p q g : EuclideanSpace ℝ (Fin K)}
    (hConv : ConvexOn ℝ (Simplex K) (extendSimplex Φ))
    (hp : p ∈ SimplexFace K J) (hq : q ∈ SimplexFace K J)
    (hfderiv : HasFDerivWithinAt (extendSimplex Φ) (innerSL ℝ g) (SimplexFace K J) p) :
    inner ℝ q g - extendSimplex Φ q ≤ inner ℝ p g - extendSimplex Φ p := by
  have h := face_subgrad_ineq hConv hp hq hfderiv
  rw [inner_sub_right, ← real_inner_comm g q, ← real_inner_comm g p] at h
  linarith

lemma ereal_coe_sum {α : Type*} (s : Finset α) (f : α → ℝ) :
    ∑ a ∈ s, ((f a : ℝ) : EReal) = ((∑ a ∈ s, f a : ℝ) : EReal) := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | @insert a s ha ih =>
      rw [Finset.sum_insert ha, Finset.sum_insert ha, ih, EReal.coe_add]

lemma ereal_add_ne_bot {a b : EReal} (ha : a ≠ ⊥) (hb : b ≠ ⊥) : a + b ≠ ⊥ := by
  induction a using EReal.rec <;> induction b using EReal.rec <;> simp_all [← EReal.coe_add]

lemma ereal_top_add_of_ne_bot {b : EReal} (hb : b ≠ ⊥) : (⊤ : EReal) + b = ⊤ := by
  induction b using EReal.rec <;> simp_all

lemma ereal_add_top_of_ne_bot {a : EReal} (ha : a ≠ ⊥) : a + (⊤ : EReal) = ⊤ := by
  induction a using EReal.rec <;> simp_all

lemma ereal_sum_ne_bot {α : Type*} (s : Finset α) (f : α → EReal)
    (hne : ∀ a ∈ s, f a ≠ ⊥) : (∑ a ∈ s, f a) ≠ ⊥ := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | @insert a s ha ih =>
      rw [Finset.sum_insert ha]
      exact ereal_add_ne_bot (hne a (Finset.mem_insert_self a s))
        (ih (fun b hb => hne b (Finset.mem_insert_of_mem hb)))

lemma ereal_sum_eq_top {α : Type*} (s : Finset α) (f : α → EReal)
    (hne : ∀ a ∈ s, f a ≠ ⊥) {a₀ : α} (ha₀ : a₀ ∈ s) (htop : f a₀ = ⊤) :
    ∑ a ∈ s, f a = ⊤ := by
  classical
  induction s using Finset.induction_on with
  | empty => simp at ha₀
  | @insert a s ha ih =>
      rw [Finset.sum_insert ha]
      rcases Finset.mem_insert.mp ha₀ with rfl | ha₀s
      · rw [htop]
        exact ereal_top_add_of_ne_bot
          (ereal_sum_ne_bot s f (fun b hb => hne b (Finset.mem_insert_of_mem hb)))
      · rw [ih (fun b hb => hne b (Finset.mem_insert_of_mem hb)) ha₀s]
        exact ereal_add_top_of_ne_bot (hne a (Finset.mem_insert_self a s))

/-- Conjunct 2 of `S_lem_A_1`: pointwise lower bound `L_Φ(p, y) ≥ -Φ(e_y)`. -/
lemma lower_bound {K : ℕ} {Φ : Simplex K → ℝ}
    (hConv : ConvexOn ℝ (Simplex K) (extendSimplex Φ))
    (hDiff : ∀ J : Finset (Fin K), J.Nonempty →
      ∀ p ∈ SimplexFaceRelint K J, ∃ g, HasFaceGradAt Φ J p g)
    {p : EuclideanSpace ℝ (Fin K)} (hp : p ∈ Simplex K) (y : Fin K) :
    ((-extendSimplex Φ (EuclideanSpace.single y (1 : ℝ)) : ℝ) : EReal) ≤
      extendedCanonicalLoss Φ p y := by
  unfold extendedCanonicalLoss
  by_cases hy : y ∈ posSupport p
  · rw [if_pos hy, EReal.coe_le_coe_iff]
    have hJne : (posSupport p).Nonempty := posSupport_nonempty hp
    have hpRel : p ∈ SimplexFaceRelint K (posSupport p) := mem_simplexFaceRelint_posSupport hp
    have hg : HasFaceGradAt Φ (posSupport p) p (faceGrad Φ (posSupport p) p) :=
      faceGrad_spec (hDiff (posSupport p) hJne p hpRel)
    have hey : EuclideanSpace.single y (1 : ℝ) ∈ SimplexFace K (posSupport p) :=
      single_mem_simplexFace hy
    have hineq := face_subgrad_ineq hConv hpRel.1 hey hg.2
    have hinner : inner ℝ (faceGrad Φ (posSupport p) p)
        (EuclideanSpace.single y (1 : ℝ) - p) =
        -inner ℝ (faceGrad Φ (posSupport p) p) (p - EuclideanSpace.single y (1 : ℝ)) := by
      rw [← inner_neg_right, neg_sub]
    linarith
  · rw [if_neg hy]
    exact le_top

lemma expected_loss_of_posSupport_subset {K : ℕ} {Φ : Simplex K → ℝ}
    {q p : EuclideanSpace ℝ (Fin K)} (hq : q ∈ Simplex K)
    (hsub : posSupport q ⊆ posSupport p) :
    ∑ y : Fin K, ((q y : ℝ) : EReal) * extendedCanonicalLoss Φ p y =
      (((-extendSimplex Φ p +
        inner ℝ (faceGrad Φ (posSupport p) p) (p - q)) : ℝ) : EReal) := by
  let g := faceGrad Φ (posSupport p) p
  have hterm : ∀ y : Fin K,
      ((q y : ℝ) : EReal) * extendedCanonicalLoss Φ p y =
        (((q y * (-extendSimplex Φ p +
          inner ℝ g (p - EuclideanSpace.single y (1 : ℝ)))) : ℝ) : EReal) := by
    intro y
    unfold extendedCanonicalLoss
    by_cases hy : y ∈ posSupport p
    · rw [if_pos hy, ← EReal.coe_mul]
    · have hqy : q y = 0 :=
        eq_zero_of_not_mem_posSupport hq (fun hyq => hy (hsub hyq))
      rw [if_neg hy, hqy]
      simp
  calc ∑ y : Fin K, ((q y : ℝ) : EReal) * extendedCanonicalLoss Φ p y
      = ∑ y : Fin K,
          (((q y * (-extendSimplex Φ p +
            inner ℝ g (p - EuclideanSpace.single y (1 : ℝ)))) : ℝ) : EReal) :=
        Finset.sum_congr rfl (fun y _ => hterm y)
    _ = ((∑ y : Fin K, q y * (-extendSimplex Φ p +
          inner ℝ g (p - EuclideanSpace.single y (1 : ℝ))) : ℝ) : EReal) :=
        ereal_coe_sum Finset.univ _
    _ = (((-extendSimplex Φ p + inner ℝ g (p - q)) : ℝ) : EReal) := by
        congr 1
        have h1 : ∑ y : Fin K, q y * (-extendSimplex Φ p +
            inner ℝ g (p - EuclideanSpace.single y (1 : ℝ))) =
            (∑ y : Fin K, q y) * (-extendSimplex Φ p) +
              ∑ y : Fin K, q y * inner ℝ g (p - EuclideanSpace.single y (1 : ℝ)) := by
          calc ∑ y : Fin K, q y * (-extendSimplex Φ p +
              inner ℝ g (p - EuclideanSpace.single y (1 : ℝ)))
              = ∑ y : Fin K, (q y * (-extendSimplex Φ p) +
                  q y * inner ℝ g (p - EuclideanSpace.single y (1 : ℝ))) :=
                Finset.sum_congr rfl (fun _ _ => mul_add _ _ _)
            _ = (∑ y : Fin K, q y * (-extendSimplex Φ p)) +
                  ∑ y : Fin K, q y * inner ℝ g (p - EuclideanSpace.single y (1 : ℝ)) :=
                Finset.sum_add_distrib
            _ = (∑ y : Fin K, q y) * (-extendSimplex Φ p) +
                  ∑ y : Fin K, q y * inner ℝ g (p - EuclideanSpace.single y (1 : ℝ)) := by
                rw [← Finset.sum_mul]
        have h2 : ∑ y : Fin K, q y * inner ℝ g (p - EuclideanSpace.single y (1 : ℝ)) =
            inner ℝ g (p - q) := by
          calc ∑ y : Fin K, q y * inner ℝ g (p - EuclideanSpace.single y (1 : ℝ))
              = ∑ y : Fin K, inner ℝ g (q y • (p - EuclideanSpace.single y (1 : ℝ))) := by
                  refine Finset.sum_congr rfl (fun y _ => ?_)
                  rw [inner_smul_right]
            _ = inner ℝ g (∑ y : Fin K, q y • (p - EuclideanSpace.single y (1 : ℝ))) := by
                  rw [← inner_sum]
            _ = inner ℝ g (p - q) := by
                  congr 1
                  calc ∑ y : Fin K, q y • (p - EuclideanSpace.single y (1 : ℝ))
                      = ∑ y : Fin K, (q y • p - q y • EuclideanSpace.single y (1 : ℝ)) :=
                        Finset.sum_congr rfl (fun _ _ => smul_sub _ _ _)
                    _ = (∑ y : Fin K, q y • p) -
                          ∑ y : Fin K, q y • EuclideanSpace.single y (1 : ℝ) :=
                        Finset.sum_sub_distrib _ _
                    _ = (∑ y : Fin K, q y) • p - q := by
                        rw [← Finset.sum_smul, sum_smul_single]
                    _ = p - q := by rw [hq.2, one_smul]
        rw [h1, h2, hq.2, one_mul]

/-- Conjunct 1 of `S_lem_A_1`: properness and exact value `-Φ(q)` at `p = q`. -/
lemma properness {K : ℕ} {Φ : Simplex K → ℝ}
    (hConv : ConvexOn ℝ (Simplex K) (extendSimplex Φ))
    (hDiff : ∀ J : Finset (Fin K), J.Nonempty →
      ∀ p ∈ SimplexFaceRelint K J, ∃ g, HasFaceGradAt Φ J p g)
    {q : EuclideanSpace ℝ (Fin K)} (hq : q ∈ Simplex K) :
    (∑ y : Fin K, ((q y : ℝ) : EReal) * extendedCanonicalLoss Φ q y =
      ((-extendSimplex Φ q : ℝ) : EReal)) ∧
    (∀ p ∈ Simplex K,
      ∑ y : Fin K, ((q y : ℝ) : EReal) * extendedCanonicalLoss Φ q y ≤
        ∑ y : Fin K, ((q y : ℝ) : EReal) * extendedCanonicalLoss Φ p y) := by
  have hself : ∑ y : Fin K, ((q y : ℝ) : EReal) * extendedCanonicalLoss Φ q y =
      ((-extendSimplex Φ q : ℝ) : EReal) := by
    rw [expected_loss_of_posSupport_subset hq (Finset.Subset.refl _)]
    simp
  refine ⟨hself, fun p hp => ?_⟩
  rw [hself]
  by_cases hsub : posSupport q ⊆ posSupport p
  · rw [expected_loss_of_posSupport_subset hq hsub, EReal.coe_le_coe_iff]
    have hJne : (posSupport p).Nonempty := posSupport_nonempty hp
    have hpRel : p ∈ SimplexFaceRelint K (posSupport p) := mem_simplexFaceRelint_posSupport hp
    have hg : HasFaceGradAt Φ (posSupport p) p (faceGrad Φ (posSupport p) p) :=
      faceGrad_spec (hDiff (posSupport p) hJne p hpRel)
    have hqFace : q ∈ SimplexFace K (posSupport p) :=
      mem_simplexFace_of_posSupport_subset hq hsub
    have hineq := face_subgrad_ineq hConv hpRel.1 hqFace hg.2
    have hinner : inner ℝ (faceGrad Φ (posSupport p) p) (q - p) =
        -inner ℝ (faceGrad Φ (posSupport p) p) (p - q) := by
      rw [← inner_neg_right, neg_sub]
    linarith
  · rw [Finset.not_subset] at hsub
    rcases hsub with ⟨y₀, hy₀q, hy₀p⟩
    have hsum_top :
        ∑ y : Fin K, ((q y : ℝ) : EReal) * extendedCanonicalLoss Φ p y = ⊤ := by
      refine ereal_sum_eq_top Finset.univ
        (fun y => ((q y : ℝ) : EReal) * extendedCanonicalLoss Φ p y) ?_
        (Finset.mem_univ y₀) ?_
      · intro y _
        dsimp only
        unfold extendedCanonicalLoss
        by_cases hyp : y ∈ posSupport p
        · rw [if_pos hyp, ← EReal.coe_mul]
          exact EReal.coe_ne_bot _
        · rw [if_neg hyp]
          rcases lt_or_eq_of_le (hq.1 y) with hqy_pos | hqy_zero
          · rw [EReal.coe_mul_top_of_pos hqy_pos]
            exact top_ne_bot
          · rw [← hqy_zero]
            simp
      · dsimp only
        unfold extendedCanonicalLoss
        rw [if_neg hy₀p]
        have hqy₀_pos : 0 < q y₀ := (mem_posSupport_iff q y₀).mp hy₀q
        exact EReal.coe_mul_top_of_pos hqy₀_pos
    rw [hsum_top]
    exact le_top

end Proof_lem_A_1
end UL

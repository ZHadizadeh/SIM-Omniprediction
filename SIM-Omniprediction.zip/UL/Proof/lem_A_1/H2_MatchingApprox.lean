import UL.Stmt.lem_A_1
import UL.Proof.lem_A_1.H1_FaceSubgrad
set_option autoImplicit false

namespace UL
namespace Proof_lem_A_1

lemma norm_sq_eq_sum {K : ℕ} (x : EuclideanSpace ℝ (Fin K)) :
    ‖x‖ ^ 2 = ∑ j : Fin K, (x j) ^ 2 := by
  rw [← real_inner_self_eq_norm_sq, inner_eq_sum]
  refine Finset.sum_congr rfl (fun j _ => ?_)
  ring

lemma simplex_isCompact (K : ℕ) : IsCompact (Simplex K) := by
  rw [Metric.isCompact_iff_isClosed_bounded]
  constructor
  · have hEq : Simplex K = (⋂ j : Fin K, {q : EuclideanSpace ℝ (Fin K) | 0 ≤ q j}) ∩
        {q : EuclideanSpace ℝ (Fin K) | ∑ j : Fin K, q j = 1} := by
      ext q
      simp [Simplex]
    rw [hEq]
    have hcont : ∀ j : Fin K, Continuous (fun q : EuclideanSpace ℝ (Fin K) => q j) :=
      fun j => PiLp.continuous_apply 2 (fun _ : Fin K => ℝ) j
    refine IsClosed.inter ?_ ?_
    · exact isClosed_iInter (fun j => isClosed_le continuous_const (hcont j))
    · exact isClosed_eq (continuous_finset_sum Finset.univ (fun j _ => hcont j)) continuous_const
  · rw [Metric.isBounded_iff_subset_closedBall 0]
    refine ⟨(K : ℝ) + 1, fun q hq => ?_⟩
    rw [Metric.mem_closedBall, dist_zero_right]
    have hcoord : ∀ j : Fin K, q j ≤ 1 := by
      intro j
      have hsub : q j ≤ ∑ i : Fin K, q i :=
        Finset.single_le_sum (fun i _ => hq.1 i) (Finset.mem_univ j)
      linarith [hq.2]
    have h1 : ‖q‖ ^ 2 ≤ (K : ℝ) := by
      rw [norm_sq_eq_sum]
      calc ∑ i : Fin K, (q i) ^ 2
          ≤ ∑ _i : Fin K, (1 : ℝ) := by
            refine Finset.sum_le_sum (fun i _ => ?_)
            nlinarith [hq.1 i, hcoord i]
        _ = (K : ℝ) := by simp
    have hK0 : (0 : ℝ) ≤ (K : ℝ) := Nat.cast_nonneg K
    nlinarith [norm_nonneg q]

lemma simplex_nonempty {K : ℕ} (hK : 2 ≤ K) : Nonempty (Simplex K) :=
  ⟨⟨EuclideanSpace.single ⟨0, by omega⟩ (1 : ℝ), single_mem_simplex _⟩⟩

lemma continuous_inner_simplex {K : ℕ} (b : EuclideanSpace ℝ (Fin K)) :
    Continuous (fun q : Simplex K => inner ℝ (q : EuclideanSpace ℝ (Fin K)) b) := by
  have hEq : (fun q : Simplex K => inner ℝ (q : EuclideanSpace ℝ (Fin K)) b) =
      (fun q : Simplex K => (innerSL ℝ b) (q : EuclideanSpace ℝ (Fin K))) := by
    funext q
    exact real_inner_comm b (q : EuclideanSpace ℝ (Fin K))
  rw [hEq]
  exact (innerSL ℝ b).continuous.comp continuous_subtype_val

lemma exists_max_simplex {K : ℕ} (hK : 2 ≤ K) {f : Simplex K → ℝ} (hf : Continuous f) :
    ∃ q₀ : Simplex K, ∀ q : Simplex K, f q ≤ f q₀ := by
  haveI : CompactSpace (Simplex K) := isCompact_iff_compactSpace.mp (simplex_isCompact K)
  haveI : Nonempty (Simplex K) := simplex_nonempty hK
  rcases isCompact_univ.exists_isMaxOn Set.univ_nonempty hf.continuousOn with ⟨q₀, _, hmax⟩
  exact ⟨q₀, fun q => hmax (Set.mem_univ q)⟩

lemma ciSup_simplex_eq_of_isMax {K : ℕ} (hK : 2 ≤ K) {f : Simplex K → ℝ}
    {q₀ : Simplex K} (hmax : ∀ q : Simplex K, f q ≤ f q₀) :
    (⨆ q : Simplex K, f q) = f q₀ := by
  haveI : Nonempty (Simplex K) := simplex_nonempty hK
  have hbdd : BddAbove (Set.range f) := ⟨f q₀, by rintro _ ⟨q, rfl⟩; exact hmax q⟩
  exact le_antisymm (ciSup_le hmax) (le_ciSup hbdd q₀)

lemma ciSup_simplex_le {K : ℕ} (hK : 2 ≤ K) {f : Simplex K → ℝ}
    {C : ℝ} (hle : ∀ q : Simplex K, f q ≤ C) :
    (⨆ q : Simplex K, f q) ≤ C := by
  haveI : Nonempty (Simplex K) := simplex_nonempty hK
  exact ciSup_le hle

lemma le_ciSup_simplex {K : ℕ} (hK : 2 ≤ K) {f : Simplex K → ℝ}
    (hf : Continuous f) (q : Simplex K) :
    f q ≤ ⨆ q' : Simplex K, f q' := by
  rcases exists_max_simplex hK hf with ⟨q₀, hmax⟩
  have hbdd : BddAbove (Set.range f) := ⟨f q₀, by rintro _ ⟨q', rfl⟩; exact hmax q'⟩
  exact le_ciSup hbdd q

lemma inner_onesVec_self (K : ℕ) : inner ℝ (onesVec K) (onesVec K) = (K : ℝ) := by
  rw [inner_eq_sum]
  simp [onesVec_apply]

lemma inner_simplex_onesVec {K : ℕ} {q : EuclideanSpace ℝ (Fin K)} (hq : q ∈ Simplex K) :
    inner ℝ q (onesVec K) = 1 := by
  rw [inner_eq_sum]
  simp [onesVec_apply, hq.2]

lemma inner_uniformVec_onesVec {K : ℕ} (hK : 2 ≤ K) :
    inner ℝ (uniformVec K) (onesVec K) = 1 := by
  rw [inner_eq_sum]
  simp [uniformVec_apply, onesVec_apply]
  have hK0 : (K : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (by omega)
  field_simp [hK0]

noncomputable def rawPot {K : ℕ} (Φ : Simplex K → ℝ) (b : EuclideanSpace ℝ (Fin K)) : ℝ :=
  ⨆ q : Simplex K, (inner ℝ (q : EuclideanSpace ℝ (Fin K)) b - Φ q)

noncomputable def centerVec {K : ℕ} (b : EuclideanSpace ℝ (Fin K)) :
    EuclideanSpace ℝ (Fin K) :=
  b - ((1 / (K : ℝ)) * inner ℝ (onesVec K) b) • onesVec K

lemma centerVec_mem_zeroSum {K : ℕ} (hK : 2 ≤ K) (b : EuclideanSpace ℝ (Fin K)) :
    centerVec b ∈ ZeroSumSubspace K := by
  rw [mem_zeroSumSubspace_iff]
  unfold centerVec
  rw [inner_sub_right, inner_smul_right, inner_onesVec_self]
  have hK0 : (K : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (by omega)
  field_simp [hK0]
  ring

lemma centerVec_eq_self_of_mem_zeroSum {K : ℕ} {g : EuclideanSpace ℝ (Fin K)}
    (hg : g ∈ ZeroSumSubspace K) : centerVec g = g := by
  rw [mem_zeroSumSubspace_iff] at hg
  unfold centerVec
  rw [hg]
  simp

lemma matchingLoss_centerVec {K : ℕ} (hK : 2 ≤ K) {Φ : Simplex K → ℝ}
    (hCont : Continuous Φ) (b : EuclideanSpace ℝ (Fin K)) (y : Fin K) :
    matchingLoss Φ (centerVec b) y = rawPot Φ b - b y := by
  let c : ℝ := (1 / (K : ℝ)) * inner ℝ (onesVec K) b
  have hc_unif : inner ℝ (uniformVec K) b = c := by
    unfold uniformVec
    rw [real_inner_comm, inner_smul_right, real_inner_comm]
  have hpoint : ∀ q : Simplex K,
      inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - uniformVec K) (centerVec b) - Φ q =
        (inner ℝ (q : EuclideanSpace ℝ (Fin K)) b - Φ q) - c := by
    intro q
    have hzero : inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - uniformVec K) (onesVec K) = 0 := by
      rw [inner_sub_left, inner_simplex_onesVec q.2, inner_uniformVec_onesVec hK, sub_self]
    have hinner :
        inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - uniformVec K) (centerVec b) =
          inner ℝ (q : EuclideanSpace ℝ (Fin K)) b - c := by
      change inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - uniformVec K) (b - c • onesVec K) =
        inner ℝ (q : EuclideanSpace ℝ (Fin K)) b - c
      rw [inner_sub_right, inner_smul_right, hzero, mul_zero, sub_zero, inner_sub_left, hc_unif]
    linarith
  have hf_cont : Continuous (fun q : Simplex K =>
      inner ℝ (q : EuclideanSpace ℝ (Fin K)) b - Φ q) :=
    (continuous_inner_simplex b).sub hCont
  rcases exists_max_simplex hK hf_cont with ⟨q₀, hmax⟩
  have hraw : rawPot Φ b = inner ℝ (q₀ : EuclideanSpace ℝ (Fin K)) b - Φ q₀ :=
    ciSup_simplex_eq_of_isMax hK hmax
  have hpot : matchingPotential Φ (centerVec b) = rawPot Φ b - c := by
    unfold matchingPotential
    rw [hraw, ← hpoint q₀]
    refine ciSup_simplex_eq_of_isMax hK (fun q => ?_)
    rw [hpoint q, hpoint q₀]
    linarith [hmax q]
  have hcoord : (centerVec b) y = b y - c := by
    change (b - c • onesVec K) y = b y - c
    simp [onesVec_apply]
  unfold matchingLoss
  rw [hpot, hcoord]
  ring

lemma matchingLoss_of_mem_zeroSum {K : ℕ} (hK : 2 ≤ K) {Φ : Simplex K → ℝ}
    (hCont : Continuous Φ) {g : EuclideanSpace ℝ (Fin K)}
    (hg : g ∈ ZeroSumSubspace K) (y : Fin K) :
    matchingLoss Φ g y = rawPot Φ g - g y := by
  have h := matchingLoss_centerVec hK hCont g y
  rwa [centerVec_eq_self_of_mem_zeroSum hg] at h

/-- Conjunct 4 of `S_lem_A_1`: for interior `p`, `simplexGrad Φ p` lies in `ZeroSumSubspace K`
and attains `extendedCanonicalLoss Φ p y` exactly for all `y`. -/
lemma interior_attainment {K : ℕ} (hK : 2 ≤ K) {Φ : Simplex K → ℝ}
    (hCont : Continuous Φ)
    (hConv : ConvexOn ℝ (Simplex K) (extendSimplex Φ))
    (hDiff : ∀ J : Finset (Fin K), J.Nonempty →
      ∀ p ∈ SimplexFaceRelint K J, ∃ g, HasFaceGradAt Φ J p g)
    {p : EuclideanSpace ℝ (Fin K)} (hp : p ∈ SimplexFaceRelint K Finset.univ) :
    simplexGrad Φ p ∈ ZeroSumSubspace K ∧
    ∀ y : Fin K,
      ((matchingLoss Φ (simplexGrad Φ p) y : ℝ) : EReal) =
        extendedCanonicalLoss Φ p y := by
  have huniv_ne : (Finset.univ : Finset (Fin K)).Nonempty :=
    ⟨⟨0, by omega⟩, Finset.mem_univ _⟩
  have hg_grad : HasFaceGradAt Φ Finset.univ p (simplexGrad Φ p) := by
    unfold simplexGrad
    exact faceGrad_spec (hDiff Finset.univ huniv_ne p hp)
  have hg_zero : simplexGrad Φ p ∈ ZeroSumSubspace K :=
    ((mem_faceTangentSpace_iff (simplexGrad Φ p)).mp hg_grad.1).1
  refine ⟨hg_zero, fun y => ?_⟩
  have hpos_univ : posSupport p = Finset.univ := by
    ext j
    simp only [mem_posSupport_iff, Finset.mem_univ, iff_true]
    exact hp.2 j (Finset.mem_univ j)
  let q_p : Simplex K := ⟨p, hp.1.1⟩
  have hΦ_qp : Φ q_p = extendSimplex Φ p := by
    unfold extendSimplex
    rw [dif_pos hp.1.1]
  have hmax : ∀ q : Simplex K,
      inner ℝ (q : EuclideanSpace ℝ (Fin K)) (simplexGrad Φ p) - Φ q ≤
        inner ℝ (q_p : EuclideanSpace ℝ (Fin K)) (simplexGrad Φ p) - Φ q_p := by
    intro q
    have hq_face : (q : EuclideanSpace ℝ (Fin K)) ∈ SimplexFace K Finset.univ :=
      ⟨q.2, fun _ hj => False.elim (hj (Finset.mem_univ _))⟩
    have hΦ_q : Φ q = extendSimplex Φ (q : EuclideanSpace ℝ (Fin K)) := by
      unfold extendSimplex
      rw [dif_pos q.2]
    rw [hΦ_q, hΦ_qp]
    exact face_max_ineq hConv hp.1 hq_face hg_grad.2
  have hraw : rawPot Φ (simplexGrad Φ p) =
      inner ℝ p (simplexGrad Φ p) - extendSimplex Φ p := by
    unfold rawPot
    rw [ciSup_simplex_eq_of_isMax hK hmax, hΦ_qp]
  have hloss : matchingLoss Φ (simplexGrad Φ p) y =
      -extendSimplex Φ p +
        inner ℝ (simplexGrad Φ p) (p - EuclideanSpace.single y (1 : ℝ)) := by
    rw [matchingLoss_of_mem_zeroSum hK hCont hg_zero y, hraw]
    have hgy : simplexGrad Φ p y =
        inner ℝ (simplexGrad Φ p) (EuclideanSpace.single y (1 : ℝ)) :=
      (inner_single_right (simplexGrad Φ p) y).symm
    rw [hgy, inner_sub_right, real_inner_comm (simplexGrad Φ p) p]
    ring
  unfold extendedCanonicalLoss
  rw [hpos_univ, if_pos (Finset.mem_univ y), hloss]
  rfl

noncomputable def penaltyVec {K : ℕ} (J : Finset (Fin K))
    (g : EuclideanSpace ℝ (Fin K)) (t : ℕ) : EuclideanSpace ℝ (Fin K) :=
  (WithLp.equiv 2 (Fin K → ℝ)).symm (fun j => if j ∈ J then g j else -(t : ℝ))

lemma penaltyVec_apply {K : ℕ} (J : Finset (Fin K))
    (g : EuclideanSpace ℝ (Fin K)) (t : ℕ) (j : Fin K) :
    penaltyVec J g t j = if j ∈ J then g j else -(t : ℝ) := rfl

lemma inner_penaltyVec_eq {K : ℕ} {J : Finset (Fin K)} {g : EuclideanSpace ℝ (Fin K)}
    (hg_out : ∀ j : Fin K, j ∉ J → g j = 0)
    (q : EuclideanSpace ℝ (Fin K)) (t : ℕ) :
    inner ℝ q (penaltyVec J g t) =
      inner ℝ q g - (t : ℝ) * ∑ j ∈ Finset.univ \ J, q j := by
  let Jc : Finset (Fin K) := Finset.univ \ J
  have hcoord : ∀ j : Fin K,
      q j * penaltyVec J g t j = q j * g j - (if j ∈ Jc then (t : ℝ) * q j else 0) := by
    intro j
    rw [penaltyVec_apply]
    by_cases hj : j ∈ J
    · have hjc : j ∉ Jc := by simp [Jc, hj]
      rw [if_pos hj, if_neg hjc]
      ring
    · have hjc : j ∈ Jc := by simp [Jc, hj]
      rw [if_neg hj, if_pos hjc, hg_out j hj]
      ring
  calc inner ℝ q (penaltyVec J g t)
      = ∑ j : Fin K, q j * penaltyVec J g t j := inner_eq_sum q _
    _ = ∑ j : Fin K, (q j * g j - (if j ∈ Jc then (t : ℝ) * q j else 0)) :=
        Finset.sum_congr rfl (fun j _ => hcoord j)
    _ = (∑ j : Fin K, q j * g j) -
          ∑ j : Fin K, (if j ∈ Jc then (t : ℝ) * q j else 0) :=
        Finset.sum_sub_distrib _ _
    _ = inner ℝ q g - (t : ℝ) * ∑ j ∈ Jc, q j := by
        rw [← inner_eq_sum, Finset.sum_ite_mem, Finset.univ_inter, ← Finset.mul_sum]

/-- Conjunct 3 of `S_lem_A_1`: existence of a sequence `a t ∈ ZeroSumSubspace K` whose
matching losses converge in `EReal` to `extendedCanonicalLoss Φ p y` for every `y`. -/
lemma approx_matching_loss {K : ℕ} (hK : 2 ≤ K) {Φ : Simplex K → ℝ}
    (hCont : Continuous Φ)
    (hConv : ConvexOn ℝ (Simplex K) (extendSimplex Φ))
    (hDiff : ∀ J : Finset (Fin K), J.Nonempty →
      ∀ p ∈ SimplexFaceRelint K J, ∃ g, HasFaceGradAt Φ J p g)
    {p : EuclideanSpace ℝ (Fin K)} (hp : p ∈ Simplex K) :
    ∃ a : ℕ → EuclideanSpace ℝ (Fin K),
      (∀ t : ℕ, a t ∈ ZeroSumSubspace K) ∧
      ∀ y : Fin K, Filter.Tendsto
        (fun t : ℕ => ((matchingLoss Φ (a t) y : ℝ) : EReal))
        Filter.atTop (nhds (extendedCanonicalLoss Φ p y)) := by
  let J : Finset (Fin K) := posSupport p
  let g : EuclideanSpace ℝ (Fin K) := faceGrad Φ J p
  let b : ℕ → EuclideanSpace ℝ (Fin K) := penaltyVec J g
  let a : ℕ → EuclideanSpace ℝ (Fin K) := fun t => centerVec (b t)
  refine ⟨a, fun t => centerVec_mem_zeroSum hK (b t), ?_⟩
  have hJne : J.Nonempty := posSupport_nonempty hp
  have hpRel : p ∈ SimplexFaceRelint K J := mem_simplexFaceRelint_posSupport hp
  have hg_grad : HasFaceGradAt Φ J p g := faceGrad_spec (hDiff J hJne p hpRel)
  have hg_out : ∀ j : Fin K, j ∉ J → g j = 0 :=
    ((mem_faceTangentSpace_iff g).mp hg_grad.1).2
  let F : Simplex K → ℝ := fun q => inner ℝ (q : EuclideanSpace ℝ (Fin K)) g - Φ q
  let S : Simplex K → ℝ := fun q => ∑ j ∈ Finset.univ \ J, (q : EuclideanSpace ℝ (Fin K)) j
  let M_star : ℝ := inner ℝ p g - extendSimplex Φ p
  have hF_cont : Continuous F := (continuous_inner_simplex g).sub hCont
  have hS_cont : Continuous S :=
    continuous_finset_sum (Finset.univ \ J) (fun j _ =>
      (PiLp.continuous_apply 2 (fun _ : Fin K => ℝ) j).comp continuous_subtype_val)
  have hS_nonneg : ∀ q : Simplex K, 0 ≤ S q :=
    fun q => Finset.sum_nonneg (fun j _ => q.2.1 j)
  have hF_le_of_S_zero : ∀ q : Simplex K, S q = 0 → F q ≤ M_star := by
    intro q hSq0
    have hzero : ∀ j ∈ Finset.univ \ J, (q : EuclideanSpace ℝ (Fin K)) j = 0 :=
      (Finset.sum_eq_zero_iff_of_nonneg (fun j _ => q.2.1 j)).mp hSq0
    have hq_face : (q : EuclideanSpace ℝ (Fin K)) ∈ SimplexFace K J := by
      refine ⟨q.2, fun j hj => hzero j (by simp [hj])⟩
    have hΦ_q : Φ q = extendSimplex Φ (q : EuclideanSpace ℝ (Fin K)) := by
      unfold extendSimplex
      rw [dif_pos q.2]
    dsimp [F, M_star]
    rw [hΦ_q]
    exact face_max_ineq hConv hpRel.1 hq_face hg_grad.2
  have hobj_eq : ∀ (t : ℕ) (q : Simplex K),
      inner ℝ (q : EuclideanSpace ℝ (Fin K)) (b t) - Φ q = F q - (t : ℝ) * S q := by
    intro t q
    dsimp [b, F, S]
    rw [inner_penaltyVec_eq hg_out]
    ring
  let q_p : Simplex K := ⟨p, hp⟩
  have hSp : S q_p = 0 :=
    Finset.sum_eq_zero (fun j hj => hpRel.1.2 j (by simp at hj; exact hj))
  have hFp : F q_p = M_star := by
    dsimp [F, M_star, q_p]
    unfold extendSimplex
    rw [dif_pos hp]
  have hM_lower : ∀ t : ℕ, M_star ≤ rawPot Φ (b t) := by
    intro t
    have hbt_cont : Continuous (fun q : Simplex K =>
        inner ℝ (q : EuclideanSpace ℝ (Fin K)) (b t) - Φ q) :=
      (continuous_inner_simplex (b t)).sub hCont
    have hle := le_ciSup_simplex hK hbt_cont q_p
    rw [hobj_eq t q_p, hSp, hFp, mul_zero, sub_zero] at hle
    exact hle
  have hM_tendsto : Filter.Tendsto (fun t : ℕ => rawPot Φ (b t)) Filter.atTop (nhds M_star) := by
    rw [Metric.tendsto_atTop]
    intro ε hε
    haveI : CompactSpace (Simplex K) := isCompact_iff_compactSpace.mp (simplex_isCompact K)
    let K_bad : Set (Simplex K) := {q : Simplex K | M_star + ε / 2 ≤ F q}
    have hKbad_closed : IsClosed K_bad := isClosed_le continuous_const hF_cont
    have hKbad_compact : IsCompact K_bad := hKbad_closed.isCompact
    have hS_pos_on_bad : ∀ q ∈ K_bad, 0 < S q := by
      intro q hq_bad
      rcases lt_or_eq_of_le (hS_nonneg q) with hpos | hzero
      · exact hpos
      · have hle := hF_le_of_S_zero q hzero.symm
        have hge : M_star + ε / 2 ≤ F q := hq_bad
        linarith
    by_cases hKbad_ne : K_bad.Nonempty
    · rcases hKbad_compact.exists_isMinOn hKbad_ne hS_cont.continuousOn with ⟨q_min, hq_min, hmin⟩
      rcases exists_max_simplex hK hF_cont with ⟨q_max, hmaxF⟩
      let δ : ℝ := S q_min
      let B : ℝ := F q_max
      have hδ_pos : 0 < δ := hS_pos_on_bad q_min hq_min
      rcases exists_nat_ge ((B - M_star) / δ) with ⟨T, hT⟩
      refine ⟨T, fun t ht => ?_⟩
      have hupper : rawPot Φ (b t) ≤ M_star + ε / 2 := by
        refine ciSup_simplex_le hK (fun q => ?_)
        rw [hobj_eq t q]
        by_cases hq_in : q ∈ K_bad
        · have hSq_ge : δ ≤ S q := hmin hq_in
          have hFq_le : F q ≤ B := hmaxF q
          have ht_ge : (T : ℝ) ≤ (t : ℝ) := Nat.cast_le.mpr ht
          have hT_nonneg : (0 : ℝ) ≤ (T : ℝ) := Nat.cast_nonneg T
          have hmul : (T : ℝ) * δ ≤ (t : ℝ) * S q :=
            mul_le_mul ht_ge hSq_ge hδ_pos.le (le_trans hT_nonneg ht_ge)
          have hBM : B - M_star ≤ (T : ℝ) * δ := (div_le_iff₀ hδ_pos).mp hT
          linarith
        · have hFq_lt : F q < M_star + ε / 2 := not_le.mp hq_in
          have htS_nonneg : 0 ≤ (t : ℝ) * S q :=
            mul_nonneg (Nat.cast_nonneg t) (hS_nonneg q)
          linarith
      have hlower : M_star ≤ rawPot Φ (b t) := hM_lower t
      rw [Real.dist_eq, abs_lt]
      constructor <;> linarith
    · rw [Set.not_nonempty_iff_eq_empty] at hKbad_ne
      refine ⟨0, fun t _ => ?_⟩
      have hupper : rawPot Φ (b t) ≤ M_star + ε / 2 := by
        refine ciSup_simplex_le hK (fun q => ?_)
        rw [hobj_eq t q]
        have hq_not : q ∉ K_bad := by simp [hKbad_ne]
        have hFq_lt : F q < M_star + ε / 2 := not_le.mp hq_not
        have htS_nonneg : 0 ≤ (t : ℝ) * S q :=
          mul_nonneg (Nat.cast_nonneg t) (hS_nonneg q)
        linarith
      have hlower : M_star ≤ rawPot Φ (b t) := hM_lower t
      rw [Real.dist_eq, abs_lt]
      constructor <;> linarith
  intro y
  have hloss_eq : ∀ t : ℕ, matchingLoss Φ (a t) y = rawPot Φ (b t) - b t y :=
    fun t => matchingLoss_centerVec hK hCont (b t) y
  unfold extendedCanonicalLoss
  change Filter.Tendsto (fun t : ℕ => ((matchingLoss Φ (a t) y : ℝ) : EReal))
    Filter.atTop (nhds (if y ∈ J then
      (((-extendSimplex Φ p + inner ℝ g (p - EuclideanSpace.single y (1 : ℝ))) : ℝ) : EReal)
      else ⊤))
  by_cases hy : y ∈ J
  · rw [if_pos hy]
    apply EReal.tendsto_coe.mpr
    have hfun_eq : (fun t : ℕ => matchingLoss Φ (a t) y) =
        fun t : ℕ => rawPot Φ (b t) - g y := by
      funext t
      rw [hloss_eq t]
      dsimp [b]
      rw [penaltyVec_apply, if_pos hy]
    have hlim_eq : M_star - g y =
        -extendSimplex Φ p + inner ℝ g (p - EuclideanSpace.single y (1 : ℝ)) := by
      dsimp [M_star]
      have hgy : g y = inner ℝ g (EuclideanSpace.single y (1 : ℝ)) :=
        (inner_single_right g y).symm
      rw [hgy, inner_sub_right, real_inner_comm g p]
      ring
    rw [hfun_eq, ← hlim_eq]
    exact hM_tendsto.sub tendsto_const_nhds
  · rw [if_neg hy]
    apply EReal.tendsto_coe_nhds_top_iff.mpr
    have hfun_eq : (fun t : ℕ => matchingLoss Φ (a t) y) =
        fun t : ℕ => rawPot Φ (b t) + (t : ℝ) := by
      funext t
      rw [hloss_eq t]
      dsimp [b]
      rw [penaltyVec_apply, if_neg hy]
      ring
    rw [hfun_eq]
    exact Filter.Tendsto.add_atTop hM_tendsto tendsto_natCast_atTop_atTop

end Proof_lem_A_1
end UL

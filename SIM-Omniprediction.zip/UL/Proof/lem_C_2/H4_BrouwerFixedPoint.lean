import Mathlib
import UL.Stmt.cit_brouwer
set_option autoImplicit false

namespace UL.Proof_lem_C_2

section BrouwerBall

universe v

private noncomputable def toLifted {N : ℕ} (x : EuclideanSpace ℝ (Fin N)) :
    EuclideanSpace ℝ (ULift.{v} (Fin N)) :=
  (WithLp.equiv 2 (ULift.{v} (Fin N) → ℝ)).symm (fun k => x k.down)

private noncomputable def fromLifted {N : ℕ} (y : EuclideanSpace ℝ (ULift.{v} (Fin N))) :
    EuclideanSpace ℝ (Fin N) :=
  (WithLp.equiv 2 (Fin N → ℝ)).symm (fun i => y (ULift.up i))

private lemma fromLifted_toLifted {N : ℕ} (x : EuclideanSpace ℝ (Fin N)) :
    fromLifted.{v} (toLifted.{v} x) = x := by
  ext i
  rfl

private lemma toLifted_fromLifted {N : ℕ} (y : EuclideanSpace ℝ (ULift.{v} (Fin N))) :
    toLifted.{v} (fromLifted.{v} y) = y := by
  ext ⟨i⟩
  rfl

private lemma toLifted_sub {N : ℕ} (x₁ x₂ : EuclideanSpace ℝ (Fin N)) :
    toLifted.{v} (x₁ - x₂) = toLifted.{v} x₁ - toLifted.{v} x₂ := by
  ext ⟨i⟩
  rfl

private lemma norm_toLifted {N : ℕ} (x : EuclideanSpace ℝ (Fin N)) :
    ‖toLifted.{v} x‖ = ‖x‖ := by
  have hsq : ‖toLifted.{v} x‖ ^ 2 = ‖x‖ ^ 2 := by
    rw [EuclideanSpace.norm_sq_eq, EuclideanSpace.norm_sq_eq]
    exact Equiv.ulift.sum_comp (fun i : Fin N => ‖x i‖ ^ 2)
  have h1 : 0 ≤ ‖toLifted.{v} x‖ := norm_nonneg _
  have h2 : 0 ≤ ‖x‖ := norm_nonneg _
  nlinarith

private lemma norm_fromLifted {N : ℕ} (y : EuclideanSpace ℝ (ULift.{v} (Fin N))) :
    ‖fromLifted.{v} y‖ = ‖y‖ := by
  conv_rhs => rw [← toLifted_fromLifted.{v} y]
  exact (norm_toLifted.{v} (fromLifted.{v} y)).symm

private lemma isometry_toLifted {N : ℕ} : Isometry (toLifted.{v} (N := N)) := by
  refine Isometry.of_dist_eq fun x₁ x₂ => ?_
  rw [dist_eq_norm, dist_eq_norm, ← toLifted_sub, norm_toLifted]

private lemma isometry_fromLifted {N : ℕ} : Isometry (fromLifted.{v} (N := N)) := by
  refine Isometry.of_dist_eq fun y₁ y₂ => ?_
  have hsub : fromLifted.{v} y₁ - fromLifted.{v} y₂ = fromLifted.{v} (y₁ - y₂) := by
    ext i
    rfl
  rw [dist_eq_norm, dist_eq_norm, hsub, norm_fromLifted]

/-- Brouwer fixed point on `Metric.closedBall (0 : EuclideanSpace ℝ (Fin N)) R`,
transferred across universe `v` from `h_cit_brouwer : S_cit_brouwer.{v}`. -/
lemma brouwer_closedBall_fin (h_cit_brouwer : UL.S_cit_brouwer.{v})
    {N : ℕ} {R : ℝ} (hR : 0 ≤ R)
    (F : Metric.closedBall (0 : EuclideanSpace ℝ (Fin N)) R →
      Metric.closedBall (0 : EuclideanSpace ℝ (Fin N)) R)
    (hF : Continuous F) :
    ∃ x : Metric.closedBall (0 : EuclideanSpace ℝ (Fin N)) R, F x = x := by
  let E' := EuclideanSpace ℝ (ULift.{v} (Fin N))
  let C' : Set E' := Metric.closedBall 0 R
  have hC'_ne : C'.Nonempty := ⟨0, Metric.mem_closedBall_self hR⟩
  have hC'_comp : IsCompact C' := isCompact_closedBall (0 : E') R
  have hC'_conv : Convex ℝ C' := convex_closedBall (0 : E') R
  have h_from_mem : ∀ y : C', fromLifted.{v} y.1 ∈
      Metric.closedBall (0 : EuclideanSpace ℝ (Fin N)) R := by
    intro y
    have hy : y.1 ∈ Metric.closedBall (0 : E') R := y.2
    rw [Metric.mem_closedBall, dist_zero_right] at hy ⊢
    rwa [norm_fromLifted]
  have h_to_mem : ∀ x : Metric.closedBall (0 : EuclideanSpace ℝ (Fin N)) R,
      toLifted.{v} x.1 ∈ C' := by
    intro x
    have hx : x.1 ∈ Metric.closedBall (0 : EuclideanSpace ℝ (Fin N)) R := x.2
    show toLifted.{v} x.1 ∈ Metric.closedBall (0 : E') R
    rw [Metric.mem_closedBall, dist_zero_right] at hx ⊢
    rwa [norm_toLifted]
  let g_down : C' → Metric.closedBall (0 : EuclideanSpace ℝ (Fin N)) R :=
    fun y => ⟨fromLifted.{v} y.1, h_from_mem y⟩
  let g_up : Metric.closedBall (0 : EuclideanSpace ℝ (Fin N)) R → C' :=
    fun x => ⟨toLifted.{v} x.1, h_to_mem x⟩
  have hg_down_cont : Continuous g_down :=
    (isometry_fromLifted.{v}.continuous.comp continuous_subtype_val).subtype_mk h_from_mem
  have hg_up_cont : Continuous g_up :=
    (isometry_toLifted.{v}.continuous.comp continuous_subtype_val).subtype_mk h_to_mem
  let F' : C' → C' := fun y => g_up (F (g_down y))
  have hF'_cont : Continuous F' := hg_up_cont.comp (hF.comp hg_down_cont)
  obtain ⟨y₀, hy₀⟩ := h_cit_brouwer E' C' hC'_ne hC'_comp hC'_conv F' hF'_cont
  refine ⟨g_down y₀, ?_⟩
  apply Subtype.ext
  have hval : toLifted.{v} (F (g_down y₀)).1 = y₀.1 := congrArg Subtype.val hy₀
  calc (F (g_down y₀)).1
      = fromLifted.{v} (toLifted.{v} (F (g_down y₀)).1) := (fromLifted_toLifted _).symm
    _ = fromLifted.{v} y₀.1 := by rw [hval]

/-- Smooth radial retraction onto `Metric.closedBall 0 R`. -/
noncomputable def projBall {N : ℕ} (R : ℝ) (u : EuclideanSpace ℝ (Fin N)) :
    EuclideanSpace ℝ (Fin N) :=
  (R / max R ‖u‖) • u

lemma projBall_continuous {N : ℕ} {R : ℝ} (hR : 0 < R) :
    Continuous (projBall R (N := N)) := by
  unfold projBall
  have hne : ∀ u : EuclideanSpace ℝ (Fin N), max R ‖u‖ ≠ 0 :=
    fun u => ne_of_gt (lt_of_lt_of_le hR (le_max_left R ‖u‖))
  exact (continuous_const.div (continuous_const.max continuous_norm) hne).smul continuous_id

lemma projBall_norm_le {N : ℕ} {R : ℝ} (hR : 0 < R) (u : EuclideanSpace ℝ (Fin N)) :
    ‖projBall R u‖ ≤ R := by
  unfold projBall
  have hmax_pos : 0 < max R ‖u‖ := lt_of_lt_of_le hR (le_max_left R ‖u‖)
  have hdiv_pos : 0 < R / max R ‖u‖ := div_pos hR hmax_pos
  rw [norm_smul, Real.norm_eq_abs, abs_of_pos hdiv_pos]
  calc (R / max R ‖u‖) * ‖u‖
      ≤ (R / max R ‖u‖) * max R ‖u‖ :=
        mul_le_mul_of_nonneg_left (le_max_right R ‖u‖) hdiv_pos.le
    _ = R := div_mul_cancel₀ R hmax_pos.ne'

lemma projBall_mem_closedBall {N : ℕ} {R : ℝ} (hR : 0 < R) (u : EuclideanSpace ℝ (Fin N)) :
    projBall R u ∈ Metric.closedBall (0 : EuclideanSpace ℝ (Fin N)) R := by
  simpa [Metric.mem_closedBall] using projBall_norm_le hR u

/-- Fixed point of projected gradient step implies zero certificate gap. -/
lemma projBall_fixed_gap_eq_zero {N : ℕ} {R : ℝ} (hR : 0 < R)
    {w g : EuclideanSpace ℝ (Fin N)} (hfix : projBall R (w - g) = w) :
    inner ℝ g w + R * ‖g‖ = 0 := by
  set u := w - g
  by_cases hu : ‖u‖ ≤ R
  · have hmax : max R ‖u‖ = R := max_eq_left hu
    have hproj : projBall R u = u := by
      simp [projBall, hmax, div_self hR.ne']
    have hwg : w - g = w := by simpa [u, hproj] using hfix
    have hg0 : g = 0 := sub_eq_self.mp hwg
    simp [hg0]
  · have hu_gt : R < ‖u‖ := lt_of_not_ge hu
    have hu_pos : 0 < ‖u‖ := lt_trans hR hu_gt
    have hmax : max R ‖u‖ = ‖u‖ := max_eq_right hu_gt.le
    have hproj : (R / ‖u‖) • u = w := by simpa [projBall, hmax] using hfix
    have hw_norm : ‖w‖ = R := by
      rw [← hproj, norm_smul, Real.norm_eq_abs, abs_of_pos (div_pos hR hu_pos),
        div_mul_cancel₀ R hu_pos.ne']
    let c : ℝ := ‖u‖ / R - 1
    have hc_pos : 0 < c := by
      dsimp [c]
      rw [sub_pos, one_lt_div hR]
      exact hu_gt
    have hu_eq : (‖u‖ / R) • w = u := by
      rw [← hproj, smul_smul]
      have hmul : (‖u‖ / R) * (R / ‖u‖) = 1 := by field_simp [hR.ne', hu_pos.ne']
      rw [hmul, one_smul]
    have hg_eq : g = - (c • w) := by
      have hg1 : g = w - u := by simp [u]
      rw [hg1, ← hu_eq]
      ext i
      simp only [PiLp.sub_apply, PiLp.neg_apply, PiLp.smul_apply, smul_eq_mul, c]
      ring
    have h_inner : inner ℝ g w = - (c * R ^ 2) := by
      rw [hg_eq, inner_neg_left, inner_smul_left, real_inner_self_eq_norm_sq, hw_norm]
      simp
    have h_norm_g : ‖g‖ = c * R := by
      rw [hg_eq, norm_neg, norm_smul, Real.norm_eq_abs, abs_of_pos hc_pos, hw_norm]
    rw [h_inner, h_norm_g]
    ring

/-- Combined Brouwer equilibrium lemma on `Metric.closedBall 0 R`:
given continuous `gMap : Metric.closedBall 0 R → EuclideanSpace ℝ (Fin N)`,
there exists `w ∈ Metric.closedBall 0 R` with `inner ℝ (gMap w) w.1 + R * ‖gMap w‖ = 0`. -/
lemma exists_zero_gap_on_ball (h_cit_brouwer : UL.S_cit_brouwer.{v})
    {N : ℕ} {R : ℝ} (hR : 0 < R)
    (gMap : Metric.closedBall (0 : EuclideanSpace ℝ (Fin N)) R → EuclideanSpace ℝ (Fin N))
    (hg_cont : Continuous gMap) :
    ∃ w : Metric.closedBall (0 : EuclideanSpace ℝ (Fin N)) R,
      inner ℝ (gMap w) w.1 + R * ‖gMap w‖ = 0 := by
  let F : Metric.closedBall (0 : EuclideanSpace ℝ (Fin N)) R →
      Metric.closedBall (0 : EuclideanSpace ℝ (Fin N)) R :=
    fun w => ⟨projBall R (w.1 - gMap w), projBall_mem_closedBall hR (w.1 - gMap w)⟩
  have hF_cont : Continuous F :=
    ((projBall_continuous hR).comp (continuous_subtype_val.sub hg_cont)).subtype_mk _
  obtain ⟨w, hw⟩ := brouwer_closedBall_fin h_cit_brouwer hR.le F hF_cont
  refine ⟨w, projBall_fixed_gap_eq_zero hR (congrArg Subtype.val hw)⟩

end BrouwerBall

end UL.Proof_lem_C_2

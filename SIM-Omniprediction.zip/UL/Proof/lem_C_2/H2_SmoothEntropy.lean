import Mathlib
import UL.Def.def_2_1
import UL.Def.def_2_matching
import UL.Def.def_5_smooth
import UL.Proof.lem_A_1.H1_FaceSubgrad
import UL.Proof.lem_A_3.H1_SimplexProj
import UL.Proof.lem_A_5.H1_Simplex
set_option autoImplicit false

namespace UL.Proof_lem_C_2

section SmoothEntropy

open UL.Proof_lem_A_3

lemma inner_uniformVec_zero_of_mem_zeroSum {K : ℕ} {v : EuclideanSpace ℝ (Fin K)}
    (hv : v ∈ UL.ZeroSumSubspace K) :
    inner ℝ (UL.uniformVec K) v = 0 := by
  have hv0 : inner ℝ (UL.onesVec K) v = 0 :=
    (UL.Proof_lem_A_1.mem_zeroSumSubspace_iff v).mp hv
  unfold UL.uniformVec
  rw [inner_smul_left, conj_trivial, hv0, mul_zero]

lemma extendSimplex_convex_of_smooth {K : ℕ} {β lam M : ℝ} {Φ : UL.Simplex K → ℝ}
    (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M) :
    ConvexOn ℝ (UL.Simplex K) (UL.extendSimplex Φ) := by
  rcases hΦ.2.2.2.1 with ⟨U, Φ_ext, _G, _hOpen, hSub, hEq, hConvU, _hGrad, _hCont⟩
  refine ⟨UL.Proof_lem_A_5.convex_simplex K, fun p hp q hq a b ha hb hab => ?_⟩
  have hcomb : a • p + b • q ∈ UL.Simplex K :=
    UL.Proof_lem_A_5.convex_simplex K hp hq ha hb hab
  have h1 : UL.extendSimplex Φ (a • p + b • q) = Φ_ext (a • p + b • q) := by
    rw [UL.Proof_lem_A_5.extendSimplex_eq_of_mem Φ hcomb, ← hEq ⟨a • p + b • q, hcomb⟩]
  have h2 : UL.extendSimplex Φ p = Φ_ext p := by
    rw [UL.Proof_lem_A_5.extendSimplex_eq_of_mem Φ hp, ← hEq ⟨p, hp⟩]
  have h3 : UL.extendSimplex Φ q = Φ_ext q := by
    rw [UL.Proof_lem_A_5.extendSimplex_eq_of_mem Φ hq, ← hEq ⟨q, hq⟩]
  rw [h1, h2, h3]
  exact hConvU.2 (hSub hp) (hSub hq) ha hb hab

lemma hasFaceGradAt_univ_simplexGrad {K : ℕ} {β lam M : ℝ} {Φ : UL.Simplex K → ℝ}
    (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M) {q : EuclideanSpace ℝ (Fin K)}
    (hq : q ∈ UL.Simplex K) :
    UL.HasFaceGradAt Φ Finset.univ q (UL.simplexGrad Φ q) := by
  rcases hΦ.2.2.2.1 with ⟨U, Φ_ext, G, _hOpen, hSub, hEq, _hConvU, hGrad, _hCont⟩
  obtain ⟨hGq_mem, hGq_fderiv⟩ := hGrad q (hSub hq)
  have hex : ∃ g, UL.HasFaceGradAt Φ Finset.univ q g := by
    refine ⟨G q, ?_, ?_⟩
    · rwa [UL.Proof_lem_A_5.faceTangentSpace_univ K]
    · rw [UL.Proof_lem_A_5.simplexFace_univ K]
      have hmono : HasFDerivWithinAt Φ_ext (innerSL ℝ (G q)) (UL.Simplex K) q :=
        hGq_fderiv.mono hSub
      refine hmono.congr (fun x hx => ?_) ?_
      · rw [UL.Proof_lem_A_5.extendSimplex_eq_of_mem Φ hx, hEq ⟨x, hx⟩]
      · rw [UL.Proof_lem_A_5.extendSimplex_eq_of_mem Φ hq, hEq ⟨q, hq⟩]
  exact UL.Proof_lem_A_5.faceGrad_spec hex

lemma simplexGrad_mem_zeroSum {K : ℕ} {β lam M : ℝ} {Φ : UL.Simplex K → ℝ}
    (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M) {q : EuclideanSpace ℝ (Fin K)}
    (hq : q ∈ UL.Simplex K) :
    UL.simplexGrad Φ q ∈ UL.ZeroSumSubspace K := by
  have h := (hasFaceGradAt_univ_simplexGrad hΦ hq).1
  rwa [UL.Proof_lem_A_5.faceTangentSpace_univ K] at h

/-- Exact Fenchel identity for `finiteCanonicalLoss` on `Simplex K`. -/
lemma finiteCanonicalLoss_eq {K : ℕ} {β lam M : ℝ} {Φ : UL.Simplex K → ℝ}
    (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M) {p : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ UL.Simplex K) (y : Fin K) :
    UL.finiteCanonicalLoss Φ p y =
      -UL.extendSimplex Φ p +
        inner ℝ (p - EuclideanSpace.single y (1 : ℝ)) (UL.simplexGrad Φ p) := by
  have hConv := extendSimplex_convex_of_smooth hΦ
  have hGrad := hasFaceGradAt_univ_simplexGrad hΦ hp
  have hg_zero : UL.simplexGrad Φ p ∈ UL.ZeroSumSubspace K :=
    simplexGrad_mem_zeroSum hΦ hp
  set g := UL.simplexGrad Φ p
  have hp_face : p ∈ UL.SimplexFace K Finset.univ := by
    rwa [UL.Proof_lem_A_5.simplexFace_univ K]
  have h_le : ∀ q : UL.Simplex K,
      inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) g - Φ q ≤
        inner ℝ (p - UL.uniformVec K) g - UL.extendSimplex Φ p := by
    intro q
    have hq_face : (q : EuclideanSpace ℝ (Fin K)) ∈ UL.SimplexFace K Finset.univ := by
      rw [UL.Proof_lem_A_5.simplexFace_univ K]
      exact q.2
    have hsub := UL.Proof_lem_A_1.face_subgrad_ineq hConv hp_face hq_face hGrad.2
    rw [UL.Proof_lem_A_5.extendSimplex_eq_of_mem Φ q.2] at hsub
    have hdiff : ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) - (p - UL.uniformVec K) =
        (q : EuclideanSpace ℝ (Fin K)) - p := by abel
    have hinn : inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) g -
        inner ℝ (p - UL.uniformVec K) g = inner ℝ g ((q : EuclideanSpace ℝ (Fin K)) - p) := by
      rw [← inner_sub_left, hdiff, real_inner_comm]
    linarith
  have h_bdd : BddAbove (Set.range (fun q : UL.Simplex K =>
      inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) g - Φ q)) :=
    ⟨_, Set.forall_mem_range.mpr h_le⟩
  haveI : Nonempty (UL.Simplex K) := ⟨⟨p, hp⟩⟩
  have h_pot : UL.matchingPotential Φ g =
      inner ℝ (p - UL.uniformVec K) g - UL.extendSimplex Φ p := by
    unfold UL.matchingPotential
    refine le_antisymm (ciSup_le h_le) ?_
    have hself : inner ℝ (p - UL.uniformVec K) g - UL.extendSimplex Φ p =
        inner ℝ ((⟨p, hp⟩ : UL.Simplex K).1 - UL.uniformVec K) g - Φ ⟨p, hp⟩ := by
      rw [UL.Proof_lem_A_5.extendSimplex_eq_of_mem Φ hp]
    rw [hself]
    exact le_ciSup h_bdd ⟨p, hp⟩
  unfold UL.finiteCanonicalLoss UL.matchingLoss UL.finiteCanonicalAction
  change UL.matchingPotential Φ g - g y = -UL.extendSimplex Φ p +
    inner ℝ (p - EuclideanSpace.single y (1 : ℝ)) g
  rw [h_pot]
  have hu0 : inner ℝ (UL.uniformVec K) g = 0 := inner_uniformVec_zero_of_mem_zeroSum hg_zero
  have hy_eq : g y = inner ℝ (EuclideanSpace.single y (1 : ℝ)) g := by
    rw [real_inner_comm, UL.Proof_lem_A_1.inner_single_right]
  rw [inner_sub_left, inner_sub_left, hu0, hy_eq]
  ring

/-- Fenchel lower bound on `matchingLoss Φ v y` for any `p ∈ Simplex K` and `v ∈ ZeroSumSubspace K`. -/
lemma matchingLoss_lower_bound {K : ℕ} {Φ : UL.Simplex K → ℝ}
    (hΦ_cont : Continuous Φ) {p : EuclideanSpace ℝ (Fin K)} (hp : p ∈ UL.Simplex K)
    (v : UL.ZeroSumSubspace K) (y : Fin K) :
    -UL.extendSimplex Φ p +
        inner ℝ (p - EuclideanSpace.single y (1 : ℝ)) (v : EuclideanSpace ℝ (Fin K)) ≤
      UL.matchingLoss Φ (v : EuclideanSpace ℝ (Fin K)) y := by
  let a : EuclideanSpace ℝ (Fin K) := v
  have hcont_fn : Continuous (fun q : UL.Simplex K =>
      inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) a - Φ q) :=
    (((continuous_subtype_val.sub continuous_const).inner continuous_const).sub hΦ_cont)
  haveI : CompactSpace (UL.Simplex K) := isCompact_iff_compactSpace.mp (simplex_isCompact K)
  have h_bdd : BddAbove (Set.range (fun q : UL.Simplex K =>
      inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) a - Φ q)) :=
    (isCompact_range hcont_fn).bddAbove
  have h_pot : inner ℝ (p - UL.uniformVec K) a - UL.extendSimplex Φ p ≤
      UL.matchingPotential Φ a := by
    unfold UL.matchingPotential
    rw [UL.Proof_lem_A_5.extendSimplex_eq_of_mem Φ hp]
    exact le_ciSup h_bdd ⟨p, hp⟩
  unfold UL.matchingLoss
  have hu0 : inner ℝ (UL.uniformVec K) a = 0 := inner_uniformVec_zero_of_mem_zeroSum v.2
  have hy_eq : a y = inner ℝ (EuclideanSpace.single y (1 : ℝ)) a := by
    rw [real_inner_comm, UL.Proof_lem_A_1.inner_single_right]
  rw [inner_sub_left, hu0] at h_pot
  rw [inner_sub_left, hy_eq]
  linarith

/-! ### Constrained proximal map on `Simplex K` -/

/-- Shifted objective `J_Δ(q) = extendSimplex Φ q - (1/(2B)) ‖q - u‖^2`. -/
noncomputable def JSimplex {K : ℕ} (Φ : UL.Simplex K → ℝ) (B : ℝ)
    (q : EuclideanSpace ℝ (Fin K)) : ℝ :=
  UL.extendSimplex Φ q - (1 / (2 * B)) * ‖q - UL.uniformVec K‖ ^ 2

/-- Gradient field `g_J(q) = simplexGrad Φ q - (1/B) • (q - u)`. -/
noncomputable def gJSimplex {K : ℕ} (Φ : UL.Simplex K → ℝ) (B : ℝ)
    (q : EuclideanSpace ℝ (Fin K)) : EuclideanSpace ℝ (Fin K) :=
  UL.simplexGrad Φ q - (1 / B) • (q - UL.uniformVec K)

private lemma norm_sq_sub_convexOn {K : ℕ} (u : EuclideanSpace ℝ (Fin K)) :
    ConvexOn ℝ (UL.Simplex K) (fun q => ‖q - u‖ ^ 2) := by
  refine ⟨simplex_convex K, fun x _ y _ a b ha hb hab => ?_⟩
  dsimp only
  simp only [smul_eq_mul]
  have hcomb : (a • x + b • y) - u = a • (x - u) + b • (y - u) := by
    calc (a • x + b • y) - u = a • x + b • y - (a + b) • u := by rw [hab, one_smul]
      _ = a • (x - u) + b • (y - u) := by rw [add_smul, smul_sub, smul_sub]; abel
  rw [hcomb]
  have hdiff : a * ‖x - u‖ ^ 2 + b * ‖y - u‖ ^ 2 - ‖a • (x - u) + b • (y - u)‖ ^ 2 =
      a * b * ‖(x - u) - (y - u)‖ ^ 2 := by
    set dx := x - u
    set dy := y - u
    have ha_sq : ‖a • dx‖ ^ 2 = a ^ 2 * ‖dx‖ ^ 2 := by
      rw [norm_smul, Real.norm_eq_abs, mul_pow, sq_abs]
    have hb_sq : ‖b • dy‖ ^ 2 = b ^ 2 * ‖dy‖ ^ 2 := by
      rw [norm_smul, Real.norm_eq_abs, mul_pow, sq_abs]
    rw [norm_add_sq_real (a • dx) (b • dy), norm_sub_sq_real dx dy, ha_sq, hb_sq,
      inner_smul_left, inner_smul_right, conj_trivial]
    have hb_eq : b = 1 - a := by linarith
    rw [hb_eq]
    ring
  have hnn : 0 ≤ a * b * ‖(x - u) - (y - u)‖ ^ 2 :=
    mul_nonneg (mul_nonneg ha hb) (sq_nonneg _)
  linarith

lemma JSimplex_convexOn {K : ℕ} {β B lam M : ℝ} (hβ : 0 < β) (hB : β ≤ B)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M) :
    ConvexOn ℝ (UL.Simplex K) (JSimplex Φ B) := by
  have hStrong : ConvexOn ℝ (UL.Simplex K)
      (fun q => UL.extendSimplex Φ q - (1 / (2 * β)) * ‖q - UL.uniformVec K‖ ^ 2) :=
    hΦ.1.2.2.2
  have hCoeff : 0 ≤ 1 / (2 * β) - 1 / (2 * B) := by
    have hB_pos : 0 < B := lt_of_lt_of_le hβ hB
    rw [sub_nonneg]
    exact one_div_le_one_div_of_le (by positivity) (by linarith)
  have hQuad := (norm_sq_sub_convexOn (UL.uniformVec K)).smul hCoeff
  have hSum := hStrong.add hQuad
  refine hSum.congr fun q _ => ?_
  dsimp [JSimplex]
  ring

private lemma tendsto_extendSimplex_seq_slope {K : ℕ} {Φ : UL.Simplex K → ℝ}
    {p q g : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ UL.Simplex K) (hq : q ∈ UL.Simplex K)
    (hfderiv : HasFDerivWithinAt (UL.extendSimplex Φ) (innerSL ℝ g) (UL.Simplex K) p) :
    Filter.Tendsto
      (fun m : ℕ => ((m : ℝ) + 2) *
        (UL.extendSimplex Φ (p + ((m : ℝ) + 2)⁻¹ • (q - p)) - UL.extendSimplex Φ p))
      Filter.atTop (nhds (inner ℝ g (q - p))) := by
  by_cases hqp : q = p
  · subst hqp
    simp
  · have hnorm_pos : 0 < ‖q - p‖ := norm_pos_iff.mpr (sub_ne_zero.mpr hqp)
    let θ : ℕ → ℝ := fun m => ((m : ℝ) + 2)⁻¹
    let x : ℕ → EuclideanSpace ℝ (Fin K) := fun m => p + θ m • (q - p)
    have hθ_pos : ∀ m : ℕ, 0 < θ m := fun m => by dsimp [θ]; positivity
    have hθ_lt1 : ∀ m : ℕ, θ m < 1 := fun m => by
      dsimp [θ]
      exact inv_lt_one_of_one_lt₀ (by linarith [(Nat.cast_nonneg m : (0 : ℝ) ≤ m)])
    have hx_mem : ∀ m : ℕ, x m ∈ UL.Simplex K := fun m => by
      have heq : x m = (1 - θ m) • p + θ m • q := by
        dsimp [x]; rw [sub_smul, one_smul, smul_sub]; abel
      rw [heq]
      exact simplex_convex K hp hq (by linarith [hθ_lt1 m]) (hθ_pos m).le (by ring)
    have hθ_tendsto : Filter.Tendsto θ Filter.atTop (nhds 0) :=
      Filter.Tendsto.inv_tendsto_atTop
        (Filter.Tendsto.atTop_add tendsto_natCast_atTop_atTop tendsto_const_nhds)
    have hx_tendsto : Filter.Tendsto x Filter.atTop (nhds p) := by
      simpa [x] using tendsto_const_nhds.add (hθ_tendsto.smul_const (q - p))
    have hx_within : Filter.Tendsto x Filter.atTop (nhdsWithin p (UL.Simplex K)) :=
      tendsto_nhdsWithin_of_tendsto_nhds_of_eventually_within x hx_tendsto
        (Filter.Eventually.of_forall hx_mem)
    have hlim_norm : Filter.Tendsto
        (fun m => ‖x m - p‖⁻¹ *
          ‖UL.extendSimplex Φ (x m) - UL.extendSimplex Φ p - (innerSL ℝ g) (x m - p)‖)
        Filter.atTop (nhds 0) :=
      (hasFDerivWithinAt_iff_tendsto.mp hfderiv).comp hx_within
    have hlim_err : Filter.Tendsto
        (fun m : ℕ => ((m : ℝ) + 2) *
          (UL.extendSimplex Φ (x m) - UL.extendSimplex Φ p) - inner ℝ g (q - p))
        Filter.atTop (nhds 0) := by
      refine squeeze_zero_norm (fun m => ?_) (by simpa using hlim_norm.mul_const ‖q - p‖)
      have hsub : x m - p = θ m • (q - p) := add_sub_cancel_left _ _
      have hxnorm : ‖x m - p‖ = θ m * ‖q - p‖ := by
        rw [hsub, norm_smul, Real.norm_eq_abs, abs_of_pos (hθ_pos m)]
      have hlin : (innerSL ℝ g) (x m - p) = θ m * inner ℝ g (q - p) := by
        rw [hsub, map_smul, smul_eq_mul, innerSL_apply_apply]
      have hm_pos : (0 : ℝ) < (m : ℝ) + 2 := by linarith [(Nat.cast_nonneg m : (0 : ℝ) ≤ m)]
      have hθ_inv : ((m : ℝ) + 2) * θ m = 1 := mul_inv_cancel₀ hm_pos.ne'
      have h_id : ((m : ℝ) + 2) * (UL.extendSimplex Φ (x m) - UL.extendSimplex Φ p) -
          inner ℝ g (q - p) =
          ((m : ℝ) + 2) *
            (UL.extendSimplex Φ (x m) - UL.extendSimplex Φ p - (innerSL ℝ g) (x m - p)) := by
        rw [hlin]
        calc ((m : ℝ) + 2) * (UL.extendSimplex Φ (x m) - UL.extendSimplex Φ p) -
              inner ℝ g (q - p)
            = ((m : ℝ) + 2) * (UL.extendSimplex Φ (x m) - UL.extendSimplex Φ p) -
                1 * inner ℝ g (q - p) := by ring
          _ = ((m : ℝ) + 2) * (UL.extendSimplex Φ (x m) - UL.extendSimplex Φ p) -
                (((m : ℝ) + 2) * θ m) * inner ℝ g (q - p) := by rw [← hθ_inv]
          _ = ((m : ℝ) + 2) *
                (UL.extendSimplex Φ (x m) - UL.extendSimplex Φ p -
                  θ m * inner ℝ g (q - p)) := by ring
      rw [Real.norm_eq_abs]
      rw [h_id, abs_mul, abs_of_pos hm_pos, hxnorm]
      have h_eq : ((m : ℝ) + 2) *
          |UL.extendSimplex Φ (x m) - UL.extendSimplex Φ p - (innerSL ℝ g) (x m - p)| =
          (θ m * ‖q - p‖)⁻¹ *
            |UL.extendSimplex Φ (x m) - UL.extendSimplex Φ p - (innerSL ℝ g) (x m - p)| *
            ‖q - p‖ := by
        dsimp [θ]
        field_simp [hm_pos.ne', hnorm_pos.ne']
      exact le_of_eq h_eq
    simpa [x, θ] using hlim_err.add_const (inner ℝ g (q - p))

/-- First-order subgradient inequality for `JSimplex` on `Simplex K`. -/
lemma JSimplex_subgrad_ineq {K : ℕ} {β B lam M : ℝ} (hβ : 0 < β) (hB : β ≤ B)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    {p q : EuclideanSpace ℝ (Fin K)} (hp : p ∈ UL.Simplex K) (hq : q ∈ UL.Simplex K) :
    JSimplex Φ B p + inner ℝ (gJSimplex Φ B p) (q - p) ≤ JSimplex Φ B q := by
  have hConvJ := JSimplex_convexOn hβ hB hΦ
  have hGradΦ : HasFDerivWithinAt (UL.extendSimplex Φ) (innerSL ℝ (UL.simplexGrad Φ p))
      (UL.Simplex K) p := by
    have h := (hasFaceGradAt_univ_simplexGrad hΦ hp).2
    rwa [UL.Proof_lem_A_5.simplexFace_univ K] at h
  have h_tendsto_Φ := tendsto_extendSimplex_seq_slope hp hq hGradΦ
  let θ : ℕ → ℝ := fun m => ((m : ℝ) + 2)⁻¹
  have hθ_tendsto : Filter.Tendsto θ Filter.atTop (nhds 0) :=
    Filter.Tendsto.inv_tendsto_atTop
      (Filter.Tendsto.atTop_add tendsto_natCast_atTop_atTop tendsto_const_nhds)
  have h_tendsto_J : Filter.Tendsto
      (fun m : ℕ => ((m : ℝ) + 2) *
        (JSimplex Φ B (p + θ m • (q - p)) - JSimplex Φ B p))
      Filter.atTop (nhds (inner ℝ (gJSimplex Φ B p) (q - p))) := by
    have h_eq : ∀ m : ℕ, ((m : ℝ) + 2) * (JSimplex Φ B (p + θ m • (q - p)) - JSimplex Φ B p) =
        ((m : ℝ) + 2) * (UL.extendSimplex Φ (p + θ m • (q - p)) - UL.extendSimplex Φ p) -
          (1 / B) * inner ℝ (p - UL.uniformVec K) (q - p) -
          (1 / (2 * B)) * ‖q - p‖ ^ 2 * θ m := by
      intro m
      have hm_pos : (0 : ℝ) < (m : ℝ) + 2 := by linarith [(Nat.cast_nonneg m : (0 : ℝ) ≤ m)]
      have hsub : (p + θ m • (q - p)) - UL.uniformVec K =
          (p - UL.uniformVec K) + θ m • (q - p) := by abel
      dsimp [JSimplex]
      rw [hsub, norm_add_smul_sq]
      dsimp [θ]
      have hB_ne : B ≠ 0 := ne_of_gt (lt_of_lt_of_le hβ hB)
      field_simp [hm_pos.ne', hB_ne]
      ring
    simp_rw [h_eq]
    have hlim := (h_tendsto_Φ.sub_const ((1 / B) * inner ℝ (p - UL.uniformVec K) (q - p))).sub
      (hθ_tendsto.const_mul ((1 / (2 * B)) * ‖q - p‖ ^ 2))
    convert hlim using 2
    unfold gJSimplex
    rw [inner_sub_left, inner_smul_left, conj_trivial]
    ring
  have h_le : ∀ m : ℕ, ((m : ℝ) + 2) * (JSimplex Φ B (p + θ m • (q - p)) - JSimplex Φ B p) ≤
      JSimplex Φ B q - JSimplex Φ B p := by
    intro m
    have hm_pos : (0 : ℝ) < (m : ℝ) + 2 := by linarith [(Nat.cast_nonneg m : (0 : ℝ) ≤ m)]
    have hθ_pos : 0 < θ m := by dsimp [θ]; positivity
    have hθ_lt1 : θ m < 1 := by
      dsimp [θ]
      exact inv_lt_one_of_one_lt₀ (by linarith [(Nat.cast_nonneg m : (0 : ℝ) ≤ m)])
    have ha_nn : 0 ≤ 1 - θ m := by linarith
    have heq : p + θ m • (q - p) = (1 - θ m) • p + θ m • q := by
      rw [sub_smul, one_smul, smul_sub]; abel
    have hconv := hConvJ.2 hp hq ha_nn hθ_pos.le (by ring)
    simp only [smul_eq_mul] at hconv
    rw [← heq] at hconv
    have h1 : JSimplex Φ B (p + θ m • (q - p)) - JSimplex Φ B p ≤
        θ m * (JSimplex Φ B q - JSimplex Φ B p) := by linarith
    have hmul := mul_le_mul_of_nonneg_left h1 hm_pos.le
    have hθ_inv : ((m : ℝ) + 2) * θ m = 1 := mul_inv_cancel₀ hm_pos.ne'
    linarith [show ((m : ℝ) + 2) * (θ m * (JSimplex Φ B q - JSimplex Φ B p)) =
      JSimplex Φ B q - JSimplex Φ B p by rw [← mul_assoc, hθ_inv, one_mul]]
  have hlim_ineq := le_of_tendsto h_tendsto_J (Filter.Eventually.of_forall h_le)
  linarith

lemma gJSimplex_monotone {K : ℕ} {β B lam M : ℝ} (hβ : 0 < β) (hB : β ≤ B)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    {p q : EuclideanSpace ℝ (Fin K)} (hp : p ∈ UL.Simplex K) (hq : q ∈ UL.Simplex K) :
    0 ≤ inner ℝ (gJSimplex Φ B p - gJSimplex Φ B q) (p - q) := by
  have h1 := JSimplex_subgrad_ineq hβ hB hΦ hp hq
  have h2 := JSimplex_subgrad_ineq hβ hB hΦ hq hp
  have halg : inner ℝ (gJSimplex Φ B p - gJSimplex Φ B q) (p - q) =
      -inner ℝ (gJSimplex Φ B p) (q - p) - inner ℝ (gJSimplex Φ B q) (p - q) := by
    rw [inner_sub_left, ← inner_neg_right (gJSimplex Φ B p), neg_sub]
  linarith

lemma gJSimplex_norm_le {K : ℕ} (hK : 2 ≤ K) {β B lam M : ℝ} (hβ : 0 < β) (hB : β ≤ B)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    {q : EuclideanSpace ℝ (Fin K)} (hq : q ∈ UL.Simplex K) :
    ‖gJSimplex Φ B q‖ ≤ M + 2 / B := by
  have hB_pos : 0 < B := lt_of_lt_of_le hβ hB
  have hM_bound : ‖UL.simplexGrad Φ q‖ ≤ M := hΦ.2.2.2.2.2 q hq
  have hqu : ‖q - UL.uniformVec K‖ ≤ 2 := by
    calc ‖q - UL.uniformVec K‖
        ≤ ‖q‖ + ‖UL.uniformVec K‖ := norm_sub_le _ _
      _ ≤ 1 + 1 := add_le_add (norm_le_one_of_mem_simplex hq)
          (norm_le_one_of_mem_simplex (UL.Proof_lem_A_5.uniformVec_mem_simplex hK))
      _ = 2 := by norm_num
  unfold gJSimplex
  calc ‖UL.simplexGrad Φ q - (1 / B) • (q - UL.uniformVec K)‖
      ≤ ‖UL.simplexGrad Φ q‖ + ‖(1 / B) • (q - UL.uniformVec K)‖ := norm_sub_le _ _
    _ = ‖UL.simplexGrad Φ q‖ + (1 / B) * ‖q - UL.uniformVec K‖ := by
        rw [norm_smul, Real.norm_eq_abs, abs_of_pos (one_div_pos.mpr hB_pos)]
    _ ≤ M + (1 / B) * 2 :=
        add_le_add hM_bound (mul_le_mul_of_nonneg_left hqu (one_div_pos.mpr hB_pos).le)
    _ = M + 2 / B := by ring

lemma gJSimplex_lipschitz {K : ℕ} {β B lam M : ℝ} (hβ : 0 < β) (hB : β ≤ B)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    {q q' : EuclideanSpace ℝ (Fin K)} (hq : q ∈ UL.Simplex K) (hq' : q' ∈ UL.Simplex K) :
    ‖gJSimplex Φ B q - gJSimplex Φ B q'‖ ≤ (lam + 1 / B) * ‖q - q'‖ := by
  have hB_pos : 0 < B := lt_of_lt_of_le hβ hB
  have hlip : ‖UL.simplexGrad Φ q - UL.simplexGrad Φ q'‖ ≤ lam * ‖q - q'‖ :=
    hΦ.2.2.2.2.1 q hq q' hq'
  have hdiff : gJSimplex Φ B q - gJSimplex Φ B q' =
      (UL.simplexGrad Φ q - UL.simplexGrad Φ q') - (1 / B) • (q - q') := by
    unfold gJSimplex
    rw [smul_sub, smul_sub, smul_sub]
    abel
  rw [hdiff]
  calc ‖(UL.simplexGrad Φ q - UL.simplexGrad Φ q') - (1 / B) • (q - q')‖
      ≤ ‖UL.simplexGrad Φ q - UL.simplexGrad Φ q'‖ + ‖(1 / B) • (q - q')‖ := norm_sub_le _ _
    _ = ‖UL.simplexGrad Φ q - UL.simplexGrad Φ q'‖ + (1 / B) * ‖q - q'‖ := by
        rw [norm_smul, Real.norm_eq_abs, abs_of_pos (one_div_pos.mpr hB_pos)]
    _ ≤ lam * ‖q - q'‖ + (1 / B) * ‖q - q'‖ := add_le_add hlip le_rfl
    _ = (lam + 1 / B) * ‖q - q'‖ := by ring

open Classical in
/-- Constrained proximal operator `arg min_{v ∈ Simplex K} (JSimplex Φ B v + (1/(2t)) ‖v - z‖^2)`. -/
noncomputable def proxSimplex {K : ℕ} (Φ : UL.Simplex K → ℝ) (B t : ℝ)
    (z : EuclideanSpace ℝ (Fin K)) : EuclideanSpace ℝ (Fin K) :=
  if h : ∃ v : EuclideanSpace ℝ (Fin K), v ∈ UL.Simplex K ∧
      IsMinOn (fun w => JSimplex Φ B w + (1 / (2 * t)) * ‖w - z‖ ^ 2) (UL.Simplex K) v then
    Classical.choose h
  else
    0

lemma proxSimplex_mem_and_isMinOn {K : ℕ} (hK : 2 ≤ K) {Φ : UL.Simplex K → ℝ}
    (hΦ_cont : Continuous Φ) (B t : ℝ) (z : EuclideanSpace ℝ (Fin K)) :
    proxSimplex Φ B t z ∈ UL.Simplex K ∧
      IsMinOn (fun w => JSimplex Φ B w + (1 / (2 * t)) * ‖w - z‖ ^ 2)
        (UL.Simplex K) (proxSimplex Φ B t z) := by
  classical
  have hcontJ : ContinuousOn (JSimplex Φ B) (UL.Simplex K) :=
    (UL.Proof_lem_A_5.continuousOn_extendSimplex hΦ_cont).sub
      (continuousOn_const.mul (((continuousOn_id.sub continuousOn_const).norm).pow 2))
  have hcont : ContinuousOn (fun w => JSimplex Φ B w + (1 / (2 * t)) * ‖w - z‖ ^ 2)
      (UL.Simplex K) :=
    hcontJ.add (continuousOn_const.mul (((continuousOn_id.sub continuousOn_const).norm).pow 2))
  obtain ⟨v, hv_mem, hv_min⟩ := (simplex_isCompact K).exists_isMinOn (simplex_nonempty hK) hcont
  have hex : ∃ v : EuclideanSpace ℝ (Fin K), v ∈ UL.Simplex K ∧
      IsMinOn (fun w => JSimplex Φ B w + (1 / (2 * t)) * ‖w - z‖ ^ 2) (UL.Simplex K) v :=
    ⟨v, hv_mem, hv_min⟩
  unfold proxSimplex
  rw [dif_pos hex]
  exact Classical.choose_spec hex

lemma proxSimplex_mem {K : ℕ} (hK : 2 ≤ K) {Φ : UL.Simplex K → ℝ}
    (hΦ_cont : Continuous Φ) (B t : ℝ) (z : EuclideanSpace ℝ (Fin K)) :
    proxSimplex Φ B t z ∈ UL.Simplex K :=
  (proxSimplex_mem_and_isMinOn hK hΦ_cont B t z).1

/-- First-order variational inequality for `proxSimplex`. -/
lemma proxSimplex_vi {K : ℕ} (hK : 2 ≤ K) {β B lam M t : ℝ}
    (hβ : 0 < β) (hB : β ≤ B) (ht : 0 < t)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    (z : EuclideanSpace ℝ (Fin K)) {q : EuclideanSpace ℝ (Fin K)} (hq : q ∈ UL.Simplex K) :
    0 ≤ inner ℝ (gJSimplex Φ B (proxSimplex Φ B t z) +
      (1 / t) • (proxSimplex Φ B t z - z)) (q - proxSimplex Φ B t z) := by
  have hB_pos : 0 < B := lt_of_lt_of_le hβ hB
  obtain ⟨hv_mem, hv_min⟩ := proxSimplex_mem_and_isMinOn hK hΦ.1.2.1 B t z
  set v := proxSimplex Φ B t z
  have hGradΦ : HasFDerivWithinAt (UL.extendSimplex Φ) (innerSL ℝ (UL.simplexGrad Φ v))
      (UL.Simplex K) v := by
    have h := (hasFaceGradAt_univ_simplexGrad hΦ hv_mem).2
    rwa [UL.Proof_lem_A_5.simplexFace_univ K] at h
  have h_tendsto_Φ := tendsto_extendSimplex_seq_slope hv_mem hq hGradΦ
  let θ : ℕ → ℝ := fun m => ((m : ℝ) + 2)⁻¹
  have hθ_tendsto : Filter.Tendsto θ Filter.atTop (nhds 0) :=
    Filter.Tendsto.inv_tendsto_atTop
      (Filter.Tendsto.atTop_add tendsto_natCast_atTop_atTop tendsto_const_nhds)
  let ψ : EuclideanSpace ℝ (Fin K) → ℝ :=
    fun w => JSimplex Φ B w + (1 / (2 * t)) * ‖w - z‖ ^ 2
  have h_tendsto_ψ : Filter.Tendsto
      (fun m : ℕ => ((m : ℝ) + 2) * (ψ (v + θ m • (q - v)) - ψ v))
      Filter.atTop (nhds (inner ℝ (gJSimplex Φ B v + (1 / t) • (v - z)) (q - v))) := by
    have h_eq : ∀ m : ℕ, ((m : ℝ) + 2) * (ψ (v + θ m • (q - v)) - ψ v) =
        ((m : ℝ) + 2) * (UL.extendSimplex Φ (v + θ m • (q - v)) - UL.extendSimplex Φ v) -
          (1 / B) * inner ℝ (v - UL.uniformVec K) (q - v) +
          (1 / t) * inner ℝ (v - z) (q - v) +
          (1 / (2 * t) - 1 / (2 * B)) * ‖q - v‖ ^ 2 * θ m := by
      intro m
      have hm_pos : (0 : ℝ) < (m : ℝ) + 2 := by linarith [(Nat.cast_nonneg m : (0 : ℝ) ≤ m)]
      have hsub_u : (v + θ m • (q - v)) - UL.uniformVec K =
          (v - UL.uniformVec K) + θ m • (q - v) := by abel
      have hsub_z : (v + θ m • (q - v)) - z = (v - z) + θ m • (q - v) := by abel
      dsimp [ψ, JSimplex]
      rw [hsub_u, hsub_z, norm_add_smul_sq, norm_add_smul_sq]
      dsimp [θ]
      field_simp [hm_pos.ne', hB_pos.ne', ht.ne']
      ring
    simp_rw [h_eq]
    have hlim := (((h_tendsto_Φ.sub_const ((1 / B) * inner ℝ (v - UL.uniformVec K) (q - v))).add_const
      ((1 / t) * inner ℝ (v - z) (q - v))).add
      (hθ_tendsto.const_mul ((1 / (2 * t) - 1 / (2 * B)) * ‖q - v‖ ^ 2)))
    convert hlim using 2
    unfold gJSimplex
    rw [inner_add_left, inner_sub_left, inner_smul_left, inner_smul_left, conj_trivial, conj_trivial]
    ring
  have h_nonneg : ∀ m : ℕ, 0 ≤ ((m : ℝ) + 2) * (ψ (v + θ m • (q - v)) - ψ v) := by
    intro m
    have hm_pos : (0 : ℝ) < (m : ℝ) + 2 := by linarith [(Nat.cast_nonneg m : (0 : ℝ) ≤ m)]
    have hθ_pos : 0 < θ m := by dsimp [θ]; positivity
    have hθ_lt1 : θ m < 1 := by
      dsimp [θ]
      exact inv_lt_one_of_one_lt₀ (by linarith [(Nat.cast_nonneg m : (0 : ℝ) ≤ m)])
    have ha_nn : 0 ≤ 1 - θ m := by linarith
    have heq : v + θ m • (q - v) = (1 - θ m) • v + θ m • q := by
      rw [sub_smul, one_smul, smul_sub]; abel
    have hmem : v + θ m • (q - v) ∈ UL.Simplex K := by
      rw [heq]
      exact simplex_convex K hv_mem hq ha_nn hθ_pos.le (by ring)
    have hmin_m : ψ v ≤ ψ (v + θ m • (q - v)) := hv_min hmem
    exact mul_nonneg hm_pos.le (sub_nonneg.mpr hmin_m)
  exact ge_of_tendsto' h_tendsto_ψ h_nonneg

/-- Fixed-point projection characterization of `proxSimplex`. -/
lemma proxSimplex_eq_proj {K : ℕ} (hK : 2 ≤ K) {β B lam M t : ℝ}
    (hβ : 0 < β) (hB : β ≤ B) (ht : 0 < t)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    (z : EuclideanSpace ℝ (Fin K)) :
    proxSimplex Φ B t z =
      projSimplexDef K (z - t • gJSimplex Φ B (proxSimplex Φ B t z)) := by
  set v := proxSimplex Φ B t z
  symm
  refine eq_projSimplex_of_inner_le_zero hK (z - t • gJSimplex Φ B v)
    (proxSimplex_mem hK hΦ.1.2.1 B t z) (fun q hq => ?_)
  have hvi := proxSimplex_vi hK hβ hB ht hΦ z hq
  have hvec : (z - t • gJSimplex Φ B v) - v =
      (-t) • (gJSimplex Φ B v + (1 / t) • (v - z)) := by
    rw [smul_add, smul_smul]
    have hmul : (-t) * (1 / t) = -1 := by field_simp [ht.ne']
    rw [hmul, neg_one_smul, neg_smul]
    abel
  rw [hvec, inner_smul_left, conj_trivial]
  nlinarith

/-- Nonexpansiveness (`1`-Lipschitzness) of `proxSimplex`. -/
lemma proxSimplex_nonexpansive {K : ℕ} (hK : 2 ≤ K) {β B lam M t : ℝ}
    (hβ : 0 < β) (hB : β ≤ B) (ht : 0 < t)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    (z₁ z₂ : EuclideanSpace ℝ (Fin K)) :
    ‖proxSimplex Φ B t z₁ - proxSimplex Φ B t z₂‖ ≤ ‖z₁ - z₂‖ := by
  set v₁ := proxSimplex Φ B t z₁
  set v₂ := proxSimplex Φ B t z₂
  have hv₁ : v₁ ∈ UL.Simplex K := proxSimplex_mem hK hΦ.1.2.1 B t z₁
  have hv₂ : v₂ ∈ UL.Simplex K := proxSimplex_mem hK hΦ.1.2.1 B t z₂
  have hvi₁ := proxSimplex_vi hK hβ hB ht hΦ z₁ hv₂
  have hvi₂ := proxSimplex_vi hK hβ hB ht hΦ z₂ hv₁
  have hmono := gJSimplex_monotone hβ hB hΦ hv₁ hv₂
  have halg : inner ℝ (gJSimplex Φ B v₁ - gJSimplex Φ B v₂) (v₁ - v₂) +
      (1 / t) * (‖v₁ - v₂‖ ^ 2 - inner ℝ (z₁ - z₂) (v₁ - v₂)) =
      -inner ℝ (gJSimplex Φ B v₁ + (1 / t) • (v₁ - z₁)) (v₂ - v₁) -
        inner ℝ (gJSimplex Φ B v₂ + (1 / t) • (v₂ - z₂)) (v₁ - v₂) := by
    rw [inner_add_left, inner_add_left, inner_smul_left, inner_smul_left, conj_trivial,
      inner_sub_left, ← real_inner_self_eq_norm_sq]
    have h1 : inner ℝ (gJSimplex Φ B v₁) (v₂ - v₁) = -inner ℝ (gJSimplex Φ B v₁) (v₁ - v₂) := by
      rw [← inner_neg_right, neg_sub]
    have h2 : inner ℝ (v₁ - z₁) (v₂ - v₁) = -inner ℝ (v₁ - z₁) (v₁ - v₂) := by
      rw [← inner_neg_right, neg_sub]
    have h3 : inner ℝ (v₁ - v₂) (v₁ - v₂) - inner ℝ (z₁ - z₂) (v₁ - v₂) =
        inner ℝ (v₁ - z₁) (v₁ - v₂) - inner ℝ (v₂ - z₂) (v₁ - v₂) := by
      rw [← inner_sub_left, ← inner_sub_left]
      congr 1
      abel
    rw [h1, h2, h3]
    ring
  have hle0 : (1 / t) * (‖v₁ - v₂‖ ^ 2 - inner ℝ (z₁ - z₂) (v₁ - v₂)) ≤ 0 := by linarith
  have ht_inv_pos : 0 < 1 / t := one_div_pos.mpr ht
  have hsq_le_inn : ‖v₁ - v₂‖ ^ 2 ≤ inner ℝ (z₁ - z₂) (v₁ - v₂) := by nlinarith
  have hsq_le : ‖v₁ - v₂‖ ^ 2 ≤ ‖z₁ - z₂‖ * ‖v₁ - v₂‖ :=
    le_trans hsq_le_inn (real_inner_le_norm _ _)
  by_cases h0 : ‖v₁ - v₂‖ = 0
  · rw [h0]; exact norm_nonneg _
  · have hpos : 0 < ‖v₁ - v₂‖ := lt_of_le_of_ne (norm_nonneg _) (Ne.symm h0)
    nlinarith

/-- Uniform $O(t^2)$ approximation `proxSimplex Φ B t p = projSimplexDef K (p - t • g_J p) + O(t^2)`
for `p ∈ Simplex K`. -/
lemma proxSimplex_approx {K : ℕ} (hK : 2 ≤ K) {β B lam M t : ℝ}
    (hβ : 0 < β) (hB : β ≤ B) (ht : 0 < t)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    {p : EuclideanSpace ℝ (Fin K)} (hp : p ∈ UL.Simplex K) :
    ‖proxSimplex Φ B t p - projSimplexDef K (p - t • gJSimplex Φ B p)‖ ≤
      (lam + 1 / B) * (M + 2 / B) * t ^ 2 := by
  have hB_pos : 0 < B := lt_of_lt_of_le hβ hB
  have hlam_pos : 0 < lam := hΦ.2.1
  set v := proxSimplex Φ B t p
  have hv_mem : v ∈ UL.Simplex K := proxSimplex_mem hK hΦ.1.2.1 B t p
  have hv_eq : v = projSimplexDef K (p - t • gJSimplex Φ B v) :=
    proxSimplex_eq_proj hK hβ hB ht hΦ p
  have hp_eq : p = projSimplexDef K p := (projSimplex_eq_self hK hp).symm
  have hdisp : ‖v - p‖ ≤ (M + 2 / B) * t := by
    calc ‖v - p‖
        = ‖projSimplexDef K (p - t • gJSimplex Φ B v) - projSimplexDef K p‖ := by
            rw [← hv_eq, ← hp_eq]
      _ ≤ ‖(p - t • gJSimplex Φ B v) - p‖ := projSimplex_nonexpansive hK _ _
      _ = ‖-(t • gJSimplex Φ B v)‖ := by simp
      _ = t * ‖gJSimplex Φ B v‖ := by
            rw [norm_neg, norm_smul, Real.norm_eq_abs, abs_of_pos ht]
      _ ≤ t * (M + 2 / B) :=
            mul_le_mul_of_nonneg_left (gJSimplex_norm_le hK hβ hB hΦ hv_mem) ht.le
      _ = (M + 2 / B) * t := by ring
  calc ‖v - projSimplexDef K (p - t • gJSimplex Φ B p)‖
      = ‖projSimplexDef K (p - t • gJSimplex Φ B v) -
          projSimplexDef K (p - t • gJSimplex Φ B p)‖ := by rw [← hv_eq]
    _ ≤ ‖(p - t • gJSimplex Φ B v) - (p - t • gJSimplex Φ B p)‖ :=
        projSimplex_nonexpansive hK _ _
    _ = ‖t • (gJSimplex Φ B p - gJSimplex Φ B v)‖ := by
        have h : (p - t • gJSimplex Φ B v) - (p - t • gJSimplex Φ B p) =
            t • (gJSimplex Φ B p - gJSimplex Φ B v) := by rw [smul_sub]; abel
        rw [h]
    _ = t * ‖gJSimplex Φ B p - gJSimplex Φ B v‖ := by
        rw [norm_smul, Real.norm_eq_abs, abs_of_pos ht]
    _ ≤ t * ((lam + 1 / B) * ‖p - v‖) :=
        mul_le_mul_of_nonneg_left (gJSimplex_lipschitz hβ hB hΦ hp hv_mem) ht.le
    _ = t * ((lam + 1 / B) * ‖v - p‖) := by rw [norm_sub_rev]
    _ ≤ t * ((lam + 1 / B) * ((M + 2 / B) * t)) :=
        mul_le_mul_of_nonneg_left
          (mul_le_mul_of_nonneg_left hdisp (by positivity)) ht.le
    _ = (lam + 1 / B) * (M + 2 / B) * t ^ 2 := by ring

end SmoothEntropy

end UL.Proof_lem_C_2

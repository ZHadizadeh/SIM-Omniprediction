import UL.Def.def_2_1
set_option autoImplicit false

namespace UL.Proof_lem_C_2

theorem finrank_zeroSumSubspace (K : ℕ) (hK : 2 ≤ K) :
    Module.finrank ℝ (UL.ZeroSumSubspace K) = K - 1 := by
  unfold UL.ZeroSumSubspace
  set f : EuclideanSpace ℝ (Fin K) →ₗ[ℝ] ℝ := (innerSL ℝ (UL.onesVec K)).toLinearMap
  have hf_surj : Function.Surjective f := by
    intro c
    refine ⟨EuclideanSpace.single ⟨0, by omega⟩ c, ?_⟩
    simp [f, UL.onesVec, EuclideanSpace.inner_single_right]
  have h_rk := LinearMap.finrank_range_add_finrank_ker f
  rw [LinearMap.range_eq_top.mpr hf_surj, finrank_top, Module.finrank_self,
    finrank_euclideanSpace_fin] at h_rk
  omega

end UL.Proof_lem_C_2

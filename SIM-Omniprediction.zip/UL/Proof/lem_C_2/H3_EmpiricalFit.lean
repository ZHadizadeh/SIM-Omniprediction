import Mathlib
import UL.Stmt.lem_C_4
import UL.Proof.lem_C_2.ZeroSumDimension
import UL.Proof.lem_C_2.H1_HilbertSchmidt
import UL.Proof.lem_C_2.H2_SmoothEntropy
set_option autoImplicit false

namespace UL.Proof_lem_C_2

section EmpiricalFit

open UL.Proof_lem_A_3

/-- Pointwise shifted simplex membership `u + p ∈ Simplex K`. -/
def isKPred (K : ℕ) (p : UL.ZeroSumSubspace K) : Prop :=
  UL.uniformVec K + (p : EuclideanSpace ℝ (Fin K)) ∈ UL.Simplex K

/-- Ball-restricted `B`-Lipschitz profile into `isKPred K`. -/
def isBLipPred (K : ℕ) (A₀ B : ℝ)
    (ρ : UL.ZeroSumSubspace K → UL.ZeroSumSubspace K) : Prop :=
  (∀ s : UL.ZeroSumSubspace K, ‖s‖ ≤ A₀ → isKPred K (ρ s)) ∧
    (∀ s s' : UL.ZeroSumSubspace K, ‖s‖ ≤ A₀ → ‖s'‖ ≤ A₀ → ‖ρ s - ρ s'‖ ≤ B * ‖s - s'‖)

/-- Least-squares optimality of `P` at sample scores `s : Fin n → ZeroSumSubspace K`. -/
def isOptFitAtScores {K n : ℕ} (A₀ B : ℝ)
    (Z : Fin n → UL.ZeroSumSubspace K)
    (s : Fin n → UL.ZeroSumSubspace K)
    (P : Fin n → UL.ZeroSumSubspace K) : Prop :=
  (∃ ρ : UL.ZeroSumSubspace K → UL.ZeroSumSubspace K,
    isBLipPred K A₀ B ρ ∧ ∀ i : Fin n, P i = ρ (s i)) ∧
  (∀ ρ' : UL.ZeroSumSubspace K → UL.ZeroSumSubspace K, isBLipPred K A₀ B ρ' →
    (1 / (n : ℝ)) * ∑ i : Fin n, ‖P i - Z i‖ ^ 2 ≤
      (1 / (n : ℝ)) * ∑ i : Fin n, ‖ρ' (s i) - Z i‖ ^ 2)

/-- Finite-dimensional feasible sample prediction set. -/
def FeasibleFitSet (K n : ℕ) (B : ℝ) (s : Fin n → UL.ZeroSumSubspace K) :
    Set (Fin n → UL.ZeroSumSubspace K) :=
  {P | (∀ i : Fin n, isKPred K (P i)) ∧
    (∀ i j : Fin n, ‖P i - P j‖ ≤ B * ‖s i - s j‖)}

lemma norm_le_two_of_isKPred {K : ℕ} (hK : 2 ≤ K) {p : UL.ZeroSumSubspace K}
    (hp : isKPred K p) : ‖p‖ ≤ 2 := by
  have heq : (p : EuclideanSpace ℝ (Fin K)) =
      (UL.uniformVec K + (p : EuclideanSpace ℝ (Fin K))) - UL.uniformVec K := by abel
  change ‖(p : EuclideanSpace ℝ (Fin K))‖ ≤ 2
  rw [heq]
  calc ‖(UL.uniformVec K + (p : EuclideanSpace ℝ (Fin K))) - UL.uniformVec K‖
      ≤ ‖UL.uniformVec K + (p : EuclideanSpace ℝ (Fin K))‖ + ‖UL.uniformVec K‖ :=
        norm_sub_le _ _
    _ ≤ 1 + 1 := add_le_add (norm_le_one_of_mem_simplex hp)
        (norm_le_one_of_mem_simplex (UL.Proof_lem_A_5.uniformVec_mem_simplex hK))
    _ = 2 := by norm_num

lemma isBLipPred_convex_comb {K : ℕ} {A₀ B : ℝ}
    {ρ ρ' : UL.ZeroSumSubspace K → UL.ZeroSumSubspace K}
    (hρ : isBLipPred K A₀ B ρ) (hρ' : isBLipPred K A₀ B ρ')
    {t : ℝ} (ht0 : 0 ≤ t) (ht1 : t ≤ 1) :
    isBLipPred K A₀ B (fun s => (1 - t) • ρ s + t • ρ' s) := by
  refine ⟨fun s hs => ?_, fun s s' hs hs' => ?_⟩
  · unfold isKPred
    have ha_nn : 0 ≤ 1 - t := by linarith
    have hcomb : UL.uniformVec K +
        (((1 - t) • ρ s + t • ρ' s : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) =
        (1 - t) • (UL.uniformVec K + (ρ s : EuclideanSpace ℝ (Fin K))) +
          t • (UL.uniformVec K + (ρ' s : EuclideanSpace ℝ (Fin K))) := by
      ext j
      simp only [Submodule.coe_add, Submodule.coe_smul_of_tower,
        PiLp.add_apply, PiLp.smul_apply, smul_eq_mul]
      ring
    rw [hcomb]
    exact simplex_convex K (hρ.1 s hs) (hρ'.1 s hs) ha_nn ht0 (by ring)
  · have hsub : ((1 - t) • ρ s + t • ρ' s) - ((1 - t) • ρ s' + t • ρ' s') =
        (1 - t) • (ρ s - ρ s') + t • (ρ' s - ρ' s') := by
      rw [smul_sub, smul_sub]
      abel
    rw [hsub]
    calc ‖(1 - t) • (ρ s - ρ s') + t • (ρ' s - ρ' s')‖
        ≤ ‖(1 - t) • (ρ s - ρ s')‖ + ‖t • (ρ' s - ρ' s')‖ := norm_add_le _ _
      _ = (1 - t) * ‖ρ s - ρ s'‖ + t * ‖ρ' s - ρ' s'‖ := by
          rw [norm_smul, norm_smul, Real.norm_eq_abs, Real.norm_eq_abs,
            abs_of_nonneg (by linarith), abs_of_nonneg ht0]
      _ ≤ (1 - t) * (B * ‖s - s'‖) + t * (B * ‖s - s'‖) :=
          add_le_add (mul_le_mul_of_nonneg_left (hρ.2 s s' hs hs') (by linarith))
            (mul_le_mul_of_nonneg_left (hρ'.2 s s' hs hs') ht0)
      _ = B * ‖s - s'‖ := by ring

/-- Equivalence between `isBLipPred` interpolability and `FeasibleFitSet` via `S_lem_C_4`. -/
lemma exists_isBLip_iff (h_lem_C_4 : UL.S_lem_C_4)
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n) {A₀ B : ℝ} (hB : 0 < B)
    {s : Fin n → UL.ZeroSumSubspace K} (hs : ∀ i : Fin n, ‖s i‖ ≤ A₀)
    (P : Fin n → UL.ZeroSumSubspace K) :
    (∃ ρ : UL.ZeroSumSubspace K → UL.ZeroSumSubspace K,
      isBLipPred K A₀ B ρ ∧ ∀ i : Fin n, P i = ρ (s i)) ↔
      P ∈ FeasibleFitSet K n B s := by
  constructor
  · rintro ⟨ρ, hρ, hP⟩
    refine ⟨fun i => ?_, fun i j => ?_⟩
    · rw [hP i]
      exact hρ.1 (s i) (hs i)
    · rw [hP i, hP j]
      exact hρ.2 (s i) (s j) (hs i) (hs j)
  · rintro ⟨hPK, hPLip⟩
    let m : ℕ := K - 1
    have hm : 1 ≤ m := by omega
    let bH := stdOrthonormalBasis ℝ (UL.ZeroSumSubspace K)
    let eIdx : Fin (Module.finrank ℝ (UL.ZeroSumSubspace K)) ≃ Fin m :=
      finCongr (UL.Proof_lem_C_2.finrank_zeroSumSubspace K hK)
    let ϕ : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin m) := fun z =>
      (WithLp.equiv 2 (Fin m → ℝ)).symm (fun r => inner ℝ z (bH (eIdx.symm r)))
    have hϕ_sub : ∀ z₁ z₂ : UL.ZeroSumSubspace K, ϕ z₁ - ϕ z₂ = ϕ (z₁ - z₂) := by
      intro z₁ z₂
      ext r
      change inner ℝ z₁ (bH (eIdx.symm r)) - inner ℝ z₂ (bH (eIdx.symm r)) =
        inner ℝ (z₁ - z₂) (bH (eIdx.symm r))
      rw [inner_sub_left]
    have hϕ_norm : ∀ z : UL.ZeroSumSubspace K, ‖ϕ z‖ = ‖z‖ := by
      intro z
      have hsq : ‖ϕ z‖ ^ 2 = ‖z‖ ^ 2 := by
        rw [EuclideanSpace.norm_sq_eq, ← real_inner_self_eq_norm_sq, ← bH.sum_inner_mul_inner z z]
        have h1 : ∑ r : Fin m, ‖(ϕ z) r‖ ^ 2 =
            ∑ r : Fin m, (inner ℝ z (bH (eIdx.symm r))) ^ 2 := by
          refine Finset.sum_congr rfl fun r _ => ?_
          change ‖inner ℝ z (bH (eIdx.symm r))‖ ^ 2 = _
          rw [Real.norm_eq_abs, sq_abs]
        rw [h1, eIdx.symm.sum_comp (fun k => (inner ℝ z (bH k)) ^ 2)]
        refine Finset.sum_congr rfl fun k _ => ?_
        rw [real_inner_comm (bH k) z, sq]
      nlinarith [norm_nonneg (ϕ z), norm_nonneg z]
    let p : Fin n → EuclideanSpace ℝ (Fin K) :=
      fun i => UL.uniformVec K + (P i : EuclideanSpace ℝ (Fin K))
    have hp : ∀ i : Fin n, p i ∈ UL.Simplex K := hPK
    have hLip_p : ∀ i j : Fin n, ‖p i - p j‖ ≤ B * ‖ϕ (s i) - ϕ (s j)‖ := by
      intro i j
      have hpdiff : p i - p j = (P i : EuclideanSpace ℝ (Fin K)) - (P j : EuclideanSpace ℝ (Fin K)) := by
        dsimp [p]; abel
      have hpnorm : ‖p i - p j‖ = ‖P i - P j‖ := by
        rw [hpdiff]; rfl
      rw [hpnorm, hϕ_sub, hϕ_norm]
      exact hPLip i j
    obtain ⟨h_ex, _h_uniq, h_main⟩ := h_lem_C_4 m n K hm hn hK (fun i => ϕ (s i)) p hp B hB hLip_p
    let θ_s : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin n) :=
      fun s₀ => Classical.choose (h_ex s₀)
    have hθ_spec := fun s₀ => Classical.choose_spec (h_ex s₀)
    obtain ⟨h_hull, h_sub_simp, h_interp, h_lip₀, _h_acc⟩ := h_main θ_s hθ_spec
    let ρ₀ : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin K) :=
      fun s₀ => Matrix.toEuclideanLin (Matrix.of (fun k i => p i k)) (θ_s s₀)
    have hρ₀_mem : ∀ s₀ : EuclideanSpace ℝ (Fin m), ρ₀ s₀ ∈ UL.Simplex K :=
      fun s₀ => h_sub_simp (h_hull s₀)
    let ρ : UL.ZeroSumSubspace K → UL.ZeroSumSubspace K := fun z =>
      ⟨ρ₀ (ϕ z) - UL.uniformVec K,
        UL.Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex (hρ₀_mem (ϕ z))
          (UL.Proof_lem_A_5.uniformVec_mem_simplex hK)⟩
    refine ⟨ρ, ⟨fun z _hz => ?_, fun z₁ z₂ _hz₁ _hz₂ => ?_⟩, fun i => ?_⟩
    · unfold isKPred
      change UL.uniformVec K + (ρ₀ (ϕ z) - UL.uniformVec K) ∈ UL.Simplex K
      have hadd : UL.uniformVec K + (ρ₀ (ϕ z) - UL.uniformVec K) = ρ₀ (ϕ z) := by abel
      rw [hadd]
      exact hρ₀_mem (ϕ z)
    · have hlip_dist := (lipschitzWith_iff_dist_le_mul.mp h_lip₀) (ϕ z₁) (ϕ z₂)
      rw [Real.coe_toNNReal B hB.le, dist_eq_norm, dist_eq_norm, hϕ_sub, hϕ_norm] at hlip_dist
      have hdiff_coe : ((ρ z₁ - ρ z₂ : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) =
          ρ₀ (ϕ z₁) - ρ₀ (ϕ z₂) := by
        change (ρ₀ (ϕ z₁) - UL.uniformVec K) - (ρ₀ (ϕ z₂) - UL.uniformVec K) = _
        abel
      change ‖((ρ z₁ - ρ z₂ : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))‖ ≤ B * ‖z₁ - z₂‖
      rwa [hdiff_coe]
    · apply Subtype.ext
      change (P i : EuclideanSpace ℝ (Fin K)) = ρ₀ (ϕ (s i)) - UL.uniformVec K
      have hi : ρ₀ (ϕ (s i)) = UL.uniformVec K + (P i : EuclideanSpace ℝ (Fin K)) := h_interp i
      rw [hi]
      abel

private lemma isCompact_cube2 (K n : ℕ) :
    IsCompact {P : Fin n → UL.ZeroSumSubspace K | ∀ i : Fin n, ‖P i‖ ≤ 2} := by
  have heq : {P : Fin n → UL.ZeroSumSubspace K | ∀ i : Fin n, ‖P i‖ ≤ 2} =
      Set.pi Set.univ (fun _ : Fin n => Metric.closedBall (0 : UL.ZeroSumSubspace K) 2) := by
    ext P
    simp [Metric.mem_closedBall]
  rw [heq]
  exact isCompact_univ_pi (fun _ => isCompact_closedBall (0 : UL.ZeroSumSubspace K) 2)

private lemma isClosed_feasibleFitSet (K n : ℕ) (B : ℝ) (s : Fin n → UL.ZeroSumSubspace K) :
    IsClosed (FeasibleFitSet K n B s) := by
  have heq : FeasibleFitSet K n B s =
      (⋂ i : Fin n, (fun P : Fin n → UL.ZeroSumSubspace K =>
          UL.uniformVec K + (P i : EuclideanSpace ℝ (Fin K))) ⁻¹' UL.Simplex K) ∩
        ⋂ i : Fin n, ⋂ j : Fin n,
          {P : Fin n → UL.ZeroSumSubspace K | ‖P i - P j‖ ≤ B * ‖s i - s j‖} := by
    ext P
    simp [FeasibleFitSet, isKPred]
  rw [heq]
  refine IsClosed.inter ?_ ?_
  · refine isClosed_iInter fun i => (UL.Proof_lem_A_5.isClosed_simplex K).preimage ?_
    exact continuous_const.add (continuous_subtype_val.comp (continuous_apply i))
  · refine isClosed_iInter fun i => isClosed_iInter fun j => ?_
    exact isClosed_le (((continuous_apply i).sub (continuous_apply j)).norm) continuous_const

private lemma isCompact_feasibleFitSet {K n : ℕ} (hK : 2 ≤ K) (B : ℝ)
    (s : Fin n → UL.ZeroSumSubspace K) :
    IsCompact (FeasibleFitSet K n B s) :=
  (isCompact_cube2 K n).of_isClosed_subset (isClosed_feasibleFitSet K n B s)
    (fun _P hP i => norm_le_two_of_isKPred hK (hP.1 i))

private lemma feasibleFitSet_nonempty {K n : ℕ} (hK : 2 ≤ K) {B : ℝ} (hB : 0 ≤ B)
    (s : Fin n → UL.ZeroSumSubspace K) :
    (FeasibleFitSet K n B s).Nonempty := by
  refine ⟨0, fun _i => ?_, fun i j => ?_⟩
  · unfold isKPred
    simpa using UL.Proof_lem_A_5.uniformVec_mem_simplex hK
  · simp only [Pi.zero_apply, sub_self, norm_zero]
    exact mul_nonneg hB (norm_nonneg _)

/-- Uniqueness of optimal sample fit `P`. -/
lemma isOptFitAtScores_unique {K n : ℕ} (hn : 1 ≤ n) {A₀ B : ℝ}
    {Z s P P' : Fin n → UL.ZeroSumSubspace K}
    (hP : isOptFitAtScores A₀ B Z s P) (hP' : isOptFitAtScores A₀ B Z s P') :
    P' = P := by
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  have hn_inv_pos : (0 : ℝ) < 1 / (n : ℝ) := one_div_pos.mpr hn_pos
  rcases hP.1 with ⟨ρ, hρ, hP_eq⟩
  rcases hP'.1 with ⟨ρ', hρ', hP'_eq⟩
  let ρ_mid : UL.ZeroSumSubspace K → UL.ZeroSumSubspace K :=
    fun z => (1 - (1 / 2 : ℝ)) • ρ z + (1 / 2 : ℝ) • ρ' z
  have hmid_lip : isBLipPred K A₀ B ρ_mid :=
    isBLipPred_convex_comb hρ hρ' (by norm_num) (by norm_num)
  have hle₁ := hP.2 ρ_mid hmid_lip
  have hle₂ := hP'.2 ρ_mid hmid_lip
  have hpara : ∀ i : Fin n,
      ‖ρ_mid (s i) - Z i‖ ^ 2 + (1 / 4 : ℝ) * ‖P' i - P i‖ ^ 2 =
        (1 / 2 : ℝ) * ‖P i - Z i‖ ^ 2 + (1 / 2 : ℝ) * ‖P' i - Z i‖ ^ 2 := by
    intro i
    have hmid_i : ρ_mid (s i) - Z i =
        (1 / 2 : ℝ) • (P i - Z i) + (1 / 2 : ℝ) • (P' i - Z i) := by
      dsimp [ρ_mid]
      rw [← hP_eq i, ← hP'_eq i]
      have h1 : (1 - (1 / 2 : ℝ)) = (1 / 2 : ℝ) := by norm_num
      have hZ_split : Z i = (1 / 2 : ℝ) • Z i + (1 / 2 : ℝ) • Z i := by
        rw [← add_smul]
        norm_num
      rw [h1, smul_sub, smul_sub]
      nth_rw 1 [hZ_split]
      abel
    have hdiff_i : P' i - P i = (P' i - Z i) - (P i - Z i) := by abel
    rw [hmid_i, hdiff_i, norm_add_sq_real, norm_sub_sq_real, inner_smul_left, inner_smul_right,
      norm_smul, norm_smul, Real.norm_eq_abs, conj_trivial,
      real_inner_comm (P' i - Z i) (P i - Z i)]
    norm_num
    ring
  have hsum_para :
      (∑ i : Fin n, ‖ρ_mid (s i) - Z i‖ ^ 2) + (1 / 4 : ℝ) * (∑ i : Fin n, ‖P' i - P i‖ ^ 2) =
        (1 / 2 : ℝ) * (∑ i : Fin n, ‖P i - Z i‖ ^ 2) +
          (1 / 2 : ℝ) * (∑ i : Fin n, ‖P' i - Z i‖ ^ 2) := by
    rw [Finset.mul_sum, ← Finset.sum_add_distrib, Finset.mul_sum, Finset.mul_sum,
      ← Finset.sum_add_distrib]
    exact Finset.sum_congr rfl fun i _ => hpara i
  have hsum_le₁ : ∑ i : Fin n, ‖P i - Z i‖ ^ 2 ≤ ∑ i : Fin n, ‖ρ_mid (s i) - Z i‖ ^ 2 :=
    le_of_mul_le_mul_left hle₁ hn_inv_pos
  have hsum_le₂ : ∑ i : Fin n, ‖P' i - Z i‖ ^ 2 ≤ ∑ i : Fin n, ‖ρ_mid (s i) - Z i‖ ^ 2 :=
    le_of_mul_le_mul_left hle₂ hn_inv_pos
  have hsq_le0 : ∑ i : Fin n, ‖P' i - P i‖ ^ 2 ≤ 0 := by linarith
  have hsq_eq0 : ∑ i : Fin n, ‖P' i - P i‖ ^ 2 = 0 :=
    le_antisymm hsq_le0 (Finset.sum_nonneg fun i _ => sq_nonneg _)
  have hall0 := (Finset.sum_eq_zero_iff_of_nonneg (fun i _ => sq_nonneg (‖P' i - P i‖))).mp hsq_eq0
  funext i
  have hi0 : ‖P' i - P i‖ = 0 := sq_eq_zero_iff.mp (hall0 i (Finset.mem_univ i))
  exact sub_eq_zero.mp (norm_eq_zero.mp hi0)

/-- Existence of optimal sample fit `P` at scores `s` with `‖s i‖ ≤ A₀`. -/
lemma exists_isOptFitAtScores (h_lem_C_4 : UL.S_lem_C_4)
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n) {A₀ B : ℝ} (hB : 0 < B)
    (Z : Fin n → UL.ZeroSumSubspace K)
    {s : Fin n → UL.ZeroSumSubspace K} (hs : ∀ i : Fin n, ‖s i‖ ≤ A₀) :
    ∃ P : Fin n → UL.ZeroSumSubspace K, isOptFitAtScores A₀ B Z s P := by
  let obj : (Fin n → UL.ZeroSumSubspace K) → ℝ :=
    fun P => (1 / (n : ℝ)) * ∑ i : Fin n, ‖P i - Z i‖ ^ 2
  have hcont : Continuous obj :=
    continuous_const.mul (continuous_finset_sum _ fun i _ =>
      (((continuous_apply i).sub continuous_const).norm).pow 2)
  obtain ⟨P, hP_mem, hP_min⟩ :=
    (isCompact_feasibleFitSet hK B s).exists_isMinOn
      (feasibleFitSet_nonempty hK hB.le s) hcont.continuousOn
  refine ⟨P, (exists_isBLip_iff h_lem_C_4 hK hn hB hs P).mpr hP_mem, fun ρ' hρ' => ?_⟩
  have hQ_mem : (fun i => ρ' (s i)) ∈ FeasibleFitSet K n B s :=
    (exists_isBLip_iff h_lem_C_4 hK hn hB hs (fun i => ρ' (s i))).mp ⟨ρ', hρ', fun _ => rfl⟩
  exact hP_min hQ_mem

open Classical in
/-- Canonical optimal fit selector as a function of `s`. -/
noncomputable def optFitScores {K n : ℕ} (A₀ B : ℝ)
    (Z : Fin n → UL.ZeroSumSubspace K)
    (s : Fin n → UL.ZeroSumSubspace K) : Fin n → UL.ZeroSumSubspace K :=
  if h : ∃ P : Fin n → UL.ZeroSumSubspace K, isOptFitAtScores A₀ B Z s P then
    Classical.choose h
  else
    0

lemma optFitScores_spec (h_lem_C_4 : UL.S_lem_C_4)
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n) {A₀ B : ℝ} (hB : 0 < B)
    (Z : Fin n → UL.ZeroSumSubspace K)
    {s : Fin n → UL.ZeroSumSubspace K} (hs : ∀ i : Fin n, ‖s i‖ ≤ A₀) :
    isOptFitAtScores A₀ B Z s (optFitScores A₀ B Z s) := by
  classical
  have hex := exists_isOptFitAtScores h_lem_C_4 hK hn hB Z hs
  unfold optFitScores
  rw [dif_pos hex]
  exact Classical.choose_spec hex

/-- Continuity of `s ↦ optFitScores A₀ B Z s` on `{s // ∀ i, ‖s i‖ ≤ A₀}`. -/
lemma continuous_optFitScores (h_lem_C_4 : UL.S_lem_C_4)
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n) {A₀ B : ℝ} (hB : 0 < B)
    (Z : Fin n → UL.ZeroSumSubspace K) :
    Continuous (fun s : {s : Fin n → UL.ZeroSumSubspace K // ∀ i : Fin n, ‖s i‖ ≤ A₀} =>
      optFitScores A₀ B Z s.1) := by
  rw [continuous_iff_seqContinuous]
  intro s_seq s₀ hs_tendsto
  refine Filter.tendsto_of_subseq_tendsto fun ns hns => ?_
  let P_sub : ℕ → Fin n → UL.ZeroSumSubspace K :=
    fun k => optFitScores A₀ B Z (s_seq (ns k)).1
  have hP_spec : ∀ k : ℕ, isOptFitAtScores A₀ B Z (s_seq (ns k)).1 (P_sub k) :=
    fun k => optFitScores_spec h_lem_C_4 hK hn hB Z (s_seq (ns k)).2
  have hP_feas : ∀ k : ℕ, P_sub k ∈ FeasibleFitSet K n B (s_seq (ns k)).1 := fun k =>
    (exists_isBLip_iff h_lem_C_4 hK hn hB (s_seq (ns k)).2 (P_sub k)).mp (hP_spec k).1
  have hP_cube : ∀ k : ℕ, P_sub k ∈ {P : Fin n → UL.ZeroSumSubspace K | ∀ i : Fin n, ‖P i‖ ≤ 2} :=
    fun k i => norm_le_two_of_isKPred hK ((hP_feas k).1 i)
  obtain ⟨pTildeStar, _hP_star_cube, φ, hφ_mono, hP_conv⟩ :=
    (isCompact_cube2 K n).isSeqCompact hP_cube
  have hs_sub_tendsto : Filter.Tendsto (fun m => (s_seq (ns (φ m))).1) Filter.atTop (nhds s₀.1) :=
    (continuous_subtype_val.tendsto s₀).comp (hs_tendsto.comp (hns.comp hφ_mono.tendsto_atTop))
  have hP_star_feas : pTildeStar ∈ FeasibleFitSet K n B s₀.1 := by
    refine ⟨fun i => ?_, fun i j => ?_⟩
    · unfold isKPred
      have hmem_m : ∀ m : ℕ,
          UL.uniformVec K + (P_sub (φ m) i : EuclideanSpace ℝ (Fin K)) ∈ UL.Simplex K :=
        fun m => (hP_feas (φ m)).1 i
      have hconv_i : Filter.Tendsto
          (fun m => UL.uniformVec K + (P_sub (φ m) i : EuclideanSpace ℝ (Fin K)))
          Filter.atTop
          (nhds (UL.uniformVec K + (pTildeStar i : EuclideanSpace ℝ (Fin K)))) :=
        tendsto_const_nhds.add
          ((continuous_subtype_val.tendsto (pTildeStar i)).comp ((tendsto_pi_nhds.mp hP_conv) i))
      exact (UL.Proof_lem_A_5.isClosed_simplex K).mem_of_tendsto hconv_i
        (Filter.Eventually.of_forall hmem_m)
    · have hle_m : ∀ m : ℕ,
          ‖P_sub (φ m) i - P_sub (φ m) j‖ ≤
            B * ‖(s_seq (ns (φ m))).1 i - (s_seq (ns (φ m))).1 j‖ :=
        fun m => (hP_feas (φ m)).2 i j
      have h_lhs : Filter.Tendsto (fun m => ‖P_sub (φ m) i - P_sub (φ m) j‖) Filter.atTop
          (nhds ‖pTildeStar i - pTildeStar j‖) :=
        (((tendsto_pi_nhds.mp hP_conv) i).sub ((tendsto_pi_nhds.mp hP_conv) j)).norm
      have h_rhs : Filter.Tendsto
          (fun m => B * ‖(s_seq (ns (φ m))).1 i - (s_seq (ns (φ m))).1 j‖) Filter.atTop
          (nhds (B * ‖s₀.1 i - s₀.1 j‖)) :=
        (((tendsto_pi_nhds.mp hs_sub_tendsto) i).sub
          ((tendsto_pi_nhds.mp hs_sub_tendsto) j)).norm.const_mul B
      exact le_of_tendsto_of_tendsto h_lhs h_rhs (Filter.Eventually.of_forall hle_m)
  have hP_star_opt : isOptFitAtScores A₀ B Z s₀.1 pTildeStar := by
    refine ⟨(exists_isBLip_iff h_lem_C_4 hK hn hB s₀.2 pTildeStar).mpr hP_star_feas, fun ρ' hρ' => ?_⟩
    let obj : (Fin n → UL.ZeroSumSubspace K) → ℝ :=
      fun P => (1 / (n : ℝ)) * ∑ i : Fin n, ‖P i - Z i‖ ^ 2
    have hcont_obj : Continuous obj :=
      continuous_const.mul (continuous_finset_sum _ fun i _ =>
        (((continuous_apply i).sub continuous_const).norm).pow 2)
    have h_lhs : Filter.Tendsto (fun m => obj (P_sub (φ m))) Filter.atTop (nhds (obj pTildeStar)) :=
      (hcont_obj.tendsto pTildeStar).comp hP_conv
    have hQ_conv : Filter.Tendsto (fun m i => ρ' ((s_seq (ns (φ m))).1 i)) Filter.atTop
        (nhds (fun i => ρ' (s₀.1 i))) := by
      rw [tendsto_pi_nhds]
      intro i
      have h_diff_zero : Filter.Tendsto
          (fun m => ρ' ((s_seq (ns (φ m))).1 i) - ρ' (s₀.1 i)) Filter.atTop (nhds 0) := by
        refine squeeze_zero_norm (fun m => ?_)
          (by simpa using (((tendsto_pi_nhds.mp hs_sub_tendsto) i).sub_const (s₀.1 i)).norm.const_mul B)
        exact hρ'.2 ((s_seq (ns (φ m))).1 i) (s₀.1 i) ((s_seq (ns (φ m))).2 i) (s₀.2 i)
      simpa using h_diff_zero.add_const (ρ' (s₀.1 i))
    have h_rhs : Filter.Tendsto (fun m => obj (fun i => ρ' ((s_seq (ns (φ m))).1 i))) Filter.atTop
        (nhds (obj (fun i => ρ' (s₀.1 i)))) :=
      (hcont_obj.tendsto _).comp hQ_conv
    have h_ineq_m : ∀ m : ℕ, obj (P_sub (φ m)) ≤ obj (fun i => ρ' ((s_seq (ns (φ m))).1 i)) :=
      fun m => (hP_spec (φ m)).2 ρ' hρ'
    exact le_of_tendsto_of_tendsto h_lhs h_rhs (Filter.Eventually.of_forall h_ineq_m)
  have hP_eq : pTildeStar = optFitScores A₀ B Z s₀.1 :=
    isOptFitAtScores_unique hn (optFitScores_spec h_lem_C_4 hK hn hB Z s₀.2) hP_star_opt
  refine ⟨φ, ?_⟩
  dsimp only
  rw [← hP_eq]
  exact hP_conv

/-! ### Empirical Variational Inequality & Comparison Bound -/

/-- Variational inequality for `isOptFitAtScores`: `0 ≤ ∑ i, ⟨P i - Z i, ρ'(s i) - P i⟩`. -/
lemma fit_vi_fin {K n : ℕ} (hn : 1 ≤ n) {A₀ B : ℝ}
    {Z s P : Fin n → UL.ZeroSumSubspace K}
    (hP : isOptFitAtScores A₀ B Z s P)
    {ρ' : UL.ZeroSumSubspace K → UL.ZeroSumSubspace K} (hρ' : isBLipPred K A₀ B ρ') :
    0 ≤ ∑ i : Fin n, inner ℝ (P i - Z i) (ρ' (s i) - P i) := by
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  have hn_inv_pos : (0 : ℝ) < 1 / (n : ℝ) := one_div_pos.mpr hn_pos
  rcases hP.1 with ⟨ρ, hρ, hP_eq⟩
  set I : ℝ := ∑ i : Fin n, inner ℝ (P i - Z i) (ρ' (s i) - P i)
  set M_sq : ℝ := ∑ i : Fin n, ‖ρ' (s i) - P i‖ ^ 2
  have hM_nn : 0 ≤ M_sq := Finset.sum_nonneg fun _ _ => sq_nonneg _
  by_contra hI_neg
  push_neg at hI_neg
  let t : ℝ := min 1 ((-I) / (M_sq + 1))
  have ht_pos : 0 < t := lt_min zero_lt_one (div_pos (by linarith) (by linarith))
  have ht_le1 : t ≤ 1 := min_le_left _ _
  have ht_le_div : t ≤ (-I) / (M_sq + 1) := min_le_right _ _
  let ρ_t := fun z => (1 - t) • ρ z + t • ρ' z
  have hρ_t : isBLipPred K A₀ B ρ_t := isBLipPred_convex_comb hρ hρ' ht_pos.le ht_le1
  have hle := le_of_mul_le_mul_left (hP.2 ρ_t hρ_t) hn_inv_pos
  have h_expand : ∑ i : Fin n, ‖ρ_t (s i) - Z i‖ ^ 2 =
      (∑ i : Fin n, ‖P i - Z i‖ ^ 2) + 2 * t * I + t ^ 2 * M_sq := by
    have hpt : ∀ i : Fin n, ‖ρ_t (s i) - Z i‖ ^ 2 =
        ‖P i - Z i‖ ^ 2 + 2 * t * inner ℝ (P i - Z i) (ρ' (s i) - P i) +
          t ^ 2 * ‖ρ' (s i) - P i‖ ^ 2 := by
      intro i
      have hvec : ρ_t (s i) - Z i = (P i - Z i) + t • (ρ' (s i) - P i) := by
        dsimp [ρ_t]
        rw [← hP_eq i, sub_smul, one_smul, smul_sub]
        abel
      rw [hvec, norm_add_smul_sq]
    simp_rw [hpt, Finset.sum_add_distrib, ← Finset.mul_sum]
    ring
  rw [h_expand] at hle
  have h1 : 0 ≤ 2 * t * I + t ^ 2 * M_sq := by linarith
  have h2 : 0 ≤ 2 * I + t * M_sq := by nlinarith
  have htM : t * M_sq ≤ -I := by
    calc t * M_sq
        ≤ ((-I) / (M_sq + 1)) * M_sq := mul_le_mul_of_nonneg_right ht_le_div hM_nn
      _ = (-I) * (M_sq / (M_sq + 1)) := by ring
      _ ≤ (-I) * 1 := mul_le_mul_of_nonneg_left
          ((div_le_one (by linarith)).mpr (by linarith)) (by linarith)
      _ = -I := mul_one _
  linarith

/-- Residuals vanish on zero-forecast coordinates: `(u + P i) j = 0 → e_{y i} j = 0`. -/
lemma fit_zero_coord_vanish {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {A₀ B : ℝ} {y : Fin n → Fin K}
    {Z s P : Fin n → UL.ZeroSumSubspace K}
    (hZ : ∀ i : Fin n, (Z i : EuclideanSpace ℝ (Fin K)) =
      EuclideanSpace.single (y i) (1 : ℝ) - UL.uniformVec K)
    (hs : ∀ i : Fin n, ‖s i‖ ≤ A₀)
    (hP : isOptFitAtScores A₀ B Z s P) :
    ∀ (i : Fin n) (j : Fin K),
      (UL.uniformVec K + (P i : EuclideanSpace ℝ (Fin K))) j = 0 →
        (EuclideanSpace.single (y i) (1 : ℝ) : EuclideanSpace ℝ (Fin K)) j = 0 := by
  classical
  rcases hP.1 with ⟨ρ, hρ, hP_eq⟩
  let p : Fin n → EuclideanSpace ℝ (Fin K) :=
    fun i => UL.uniformVec K + (P i : EuclideanSpace ℝ (Fin K))
  let e : Fin n → EuclideanSpace ℝ (Fin K) :=
    fun i => EuclideanSpace.single (y i) (1 : ℝ)
  have hp_mem : ∀ i : Fin n, p i ∈ UL.Simplex K := fun i => by
    dsimp [p]; rw [hP_eq i]; exact hρ.1 (s i) (hs i)
  have he_mem : ∀ i : Fin n, e i ∈ UL.Simplex K := fun i =>
    UL.Proof_lem_A_1.single_mem_simplex (y i)
  -- Uniform positive threshold ε across all i : Fin n and j ∈ posSupport (p i)
  have hK_pos : (0 : ℝ) < (K : ℝ) := Nat.cast_pos.mpr (by omega)
  let ε_i : Fin n → ℝ := fun i =>
    let J := Finset.univ.filter (fun k : Fin K => 0 < p i k)
    have hJ : J.Nonempty := posSupport_nonempty (hp_mem i)
    ((J.card : ℝ) / (K : ℝ)) * J.inf' hJ (fun k => p i k)
  have hε_i_pos : ∀ i : Fin n, 0 < ε_i i := by
    intro i
    dsimp [ε_i]
    set J := Finset.univ.filter (fun k : Fin K => 0 < p i k)
    have hJ : J.Nonempty := posSupport_nonempty (hp_mem i)
    have hcard : (0 : ℝ) < (J.card : ℝ) := Nat.cast_pos.mpr (Finset.card_pos.mpr hJ)
    have hinf : 0 < J.inf' hJ (fun k => p i k) :=
      (Finset.lt_inf'_iff hJ).mpr fun k hk => (Finset.mem_filter.mp hk).2
    positivity
  have h_univ_ne : (Finset.univ : Finset (Fin n)).Nonempty :=
    ⟨⟨0, by omega⟩, Finset.mem_univ _⟩
  let ε : ℝ := min (1 / (2 * (K : ℝ))) (Finset.univ.inf' h_univ_ne ε_i)
  have hε_pos : 0 < ε := by
    refine lt_min (by positivity) ?_
    exact (Finset.lt_inf'_iff h_univ_ne).mpr fun i _ => hε_i_pos i
  have hε_lt : (K : ℝ) * ε < 1 := by
    have hle : ε ≤ 1 / (2 * (K : ℝ)) := min_le_left _ _
    have hmul : (K : ℝ) * ε ≤ (K : ℝ) * (1 / (2 * (K : ℝ))) :=
      mul_le_mul_of_nonneg_left hle hK_pos.le
    have hhalf : (K : ℝ) * (1 / (2 * (K : ℝ))) = 1 / 2 := by field_simp [hK_pos.ne']
    linarith
  let ρ' : UL.ZeroSumSubspace K → UL.ZeroSumSubspace K := fun z =>
    ⟨T_eps K ε (UL.uniformVec K + (ρ z : EuclideanSpace ℝ (Fin K))) - UL.uniformVec K,
      UL.Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex
        (T_eps_mem_simplex hK hε_pos hε_lt _)
        (UL.Proof_lem_A_5.uniformVec_mem_simplex hK)⟩
  have hρ'_lip : isBLipPred K A₀ B ρ' := by
    refine ⟨fun z _ => ?_, fun z₁ z₂ hz₁ hz₂ => ?_⟩
    · unfold isKPred
      change UL.uniformVec K +
        (T_eps K ε (UL.uniformVec K + (ρ z : EuclideanSpace ℝ (Fin K))) - UL.uniformVec K) ∈
        UL.Simplex K
      have hadd : UL.uniformVec K +
          (T_eps K ε (UL.uniformVec K + (ρ z : EuclideanSpace ℝ (Fin K))) - UL.uniformVec K) =
          T_eps K ε (UL.uniformVec K + (ρ z : EuclideanSpace ℝ (Fin K))) := by abel
      rw [hadd]
      exact T_eps_mem_simplex hK hε_pos hε_lt _
    · change ‖(T_eps K ε (UL.uniformVec K + (ρ z₁ : EuclideanSpace ℝ (Fin K))) - UL.uniformVec K) -
          (T_eps K ε (UL.uniformVec K + (ρ z₂ : EuclideanSpace ℝ (Fin K))) - UL.uniformVec K)‖ ≤
        B * ‖z₁ - z₂‖
      have hsub :
          (T_eps K ε (UL.uniformVec K + (ρ z₁ : EuclideanSpace ℝ (Fin K))) - UL.uniformVec K) -
            (T_eps K ε (UL.uniformVec K + (ρ z₂ : EuclideanSpace ℝ (Fin K))) - UL.uniformVec K) =
          T_eps K ε (UL.uniformVec K + (ρ z₁ : EuclideanSpace ℝ (Fin K))) -
            T_eps K ε (UL.uniformVec K + (ρ z₂ : EuclideanSpace ℝ (Fin K))) := by abel
      rw [hsub]
      calc ‖T_eps K ε (UL.uniformVec K + (ρ z₁ : EuclideanSpace ℝ (Fin K))) -
            T_eps K ε (UL.uniformVec K + (ρ z₂ : EuclideanSpace ℝ (Fin K)))‖
          ≤ ‖(UL.uniformVec K + (ρ z₁ : EuclideanSpace ℝ (Fin K))) -
              (UL.uniformVec K + (ρ z₂ : EuclideanSpace ℝ (Fin K)))‖ :=
            T_eps_nonexpansive hK hε_lt _ _
        _ = ‖ρ z₁ - ρ z₂‖ := by
            have h1 : (UL.uniformVec K + (ρ z₁ : EuclideanSpace ℝ (Fin K))) -
                (UL.uniformVec K + (ρ z₂ : EuclideanSpace ℝ (Fin K))) =
                (ρ z₁ : EuclideanSpace ℝ (Fin K)) - (ρ z₂ : EuclideanSpace ℝ (Fin K)) := by abel
            rw [h1]; rfl
        _ ≤ B * ‖z₁ - z₂‖ := hρ.2 z₁ z₂ hz₁ hz₂
  have hvi := fit_vi_fin hn hP hρ'_lip
  have hvi_scaled : 0 ≤ ∑ i : Fin n,
      inner ℝ (p i - e i) ((1 / ε) • (T_eps K ε (p i) - p i)) := by
    have hmul := mul_nonneg (one_div_pos.mpr hε_pos).le hvi
    rw [Finset.mul_sum] at hmul
    refine le_trans hmul (le_of_eq (Finset.sum_congr rfl fun i _ => ?_))
    rw [← inner_smul_right]
    have hr_coe : ((P i - Z i : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) = p i - e i := by
      change (P i : EuclideanSpace ℝ (Fin K)) - (Z i : EuclideanSpace ℝ (Fin K)) = _
      rw [hZ i]; dsimp [p, e]; abel
    have hd_coe : ((ρ' (s i) - P i : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) =
        T_eps K ε (p i) - p i := by
      change (T_eps K ε (UL.uniformVec K + (ρ (s i) : EuclideanSpace ℝ (Fin K))) -
          UL.uniformVec K) - (P i : EuclideanSpace ℝ (Fin K)) = _
      rw [← hP_eq i]; dsimp [p]; abel
    change inner ℝ ((P i - Z i : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
      ((1 / ε) • ((ρ' (s i) - P i : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))) = _
    rw [hr_coe, hd_coe]
  have hterm_eq : ∀ i : Fin n,
      inner ℝ (p i - e i) ((1 / ε) • (T_eps K ε (p i) - p i)) =
        -((K : ℝ) / ((Finset.univ.filter (fun k : Fin K => 0 < p i k)).card : ℝ)) *
          ∑ j ∈ Finset.univ.filter (fun k : Fin K => p i k = 0), e i j := by
    intro i
    refine T_eps_inner_eq_of_small hK (hp_mem i) (he_mem i) hε_pos hε_lt (fun j hj => ?_)
    let J := Finset.univ.filter (fun k : Fin K => 0 < p i k)
    have hJ : J.Nonempty := posSupport_nonempty (hp_mem i)
    have hcard_pos : (0 : ℝ) < (J.card : ℝ) := Nat.cast_pos.mpr (Finset.card_pos.mpr hJ)
    have hε_le_i : ε ≤ ε_i i :=
      le_trans (min_le_right _ _) (Finset.inf'_le ε_i (Finset.mem_univ i))
    have hinf_le : J.inf' hJ (fun k => p i k) ≤ p i j := Finset.inf'_le _ hj
    calc ((K : ℝ) / (J.card : ℝ)) * ε
        ≤ ((K : ℝ) / (J.card : ℝ)) * ε_i i :=
          mul_le_mul_of_nonneg_left hε_le_i (by positivity)
      _ = J.inf' hJ (fun k => p i k) := by
          dsimp [ε_i]
          field_simp [hK_pos.ne', hcard_pos.ne']
          ring
      _ ≤ p i j := hinf_le
  simp_rw [hterm_eq] at hvi_scaled
  intro i₀ j₀ hp₀
  have hsum_nonpos :
      ∑ i : Fin n,
        (((K : ℝ) / ((Finset.univ.filter (fun k : Fin K => 0 < p i k)).card : ℝ)) *
          ∑ j ∈ Finset.univ.filter (fun k : Fin K => p i k = 0), e i j) ≤ 0 := by
    have hneg : ∑ i : Fin n,
        (-((K : ℝ) / ((Finset.univ.filter (fun k : Fin K => 0 < p i k)).card : ℝ)) *
          ∑ j ∈ Finset.univ.filter (fun k : Fin K => p i k = 0), e i j) =
        -∑ i : Fin n,
          (((K : ℝ) / ((Finset.univ.filter (fun k : Fin K => 0 < p i k)).card : ℝ)) *
            ∑ j ∈ Finset.univ.filter (fun k : Fin K => p i k = 0), e i j) := by
      simp_rw [neg_mul, Finset.sum_neg_distrib]
    linarith
  have hterm_nn : ∀ i : Fin n,
      0 ≤ ((K : ℝ) / ((Finset.univ.filter (fun k : Fin K => 0 < p i k)).card : ℝ)) *
        ∑ j ∈ Finset.univ.filter (fun k : Fin K => p i k = 0), e i j := by
    intro i
    have hJ : (Finset.univ.filter (fun k : Fin K => 0 < p i k)).Nonempty :=
      posSupport_nonempty (hp_mem i)
    have hcard_pos : (0 : ℝ) < ((Finset.univ.filter (fun k : Fin K => 0 < p i k)).card : ℝ) :=
      Nat.cast_pos.mpr (Finset.card_pos.mpr hJ)
    exact mul_nonneg (by positivity) (Finset.sum_nonneg fun j _ => (he_mem i).1 j)
  have hi₀_le : ((K : ℝ) / ((Finset.univ.filter (fun k : Fin K => 0 < p i₀ k)).card : ℝ)) *
      ∑ j ∈ Finset.univ.filter (fun k : Fin K => p i₀ k = 0), e i₀ j ≤ 0 :=
    le_trans (Finset.single_le_sum (fun i _ => hterm_nn i) (Finset.mem_univ i₀)) hsum_nonpos
  have hJ₀ : (Finset.univ.filter (fun k : Fin K => 0 < p i₀ k)).Nonempty :=
    posSupport_nonempty (hp_mem i₀)
  have hcoeff_pos :
      0 < (K : ℝ) / ((Finset.univ.filter (fun k : Fin K => 0 < p i₀ k)).card : ℝ) := by
    have hcard_pos : (0 : ℝ) < ((Finset.univ.filter (fun k : Fin K => 0 < p i₀ k)).card : ℝ) :=
      Nat.cast_pos.mpr (Finset.card_pos.mpr hJ₀)
    positivity
  have hsum_j_le0 : ∑ j ∈ Finset.univ.filter (fun k : Fin K => p i₀ k = 0), e i₀ j ≤ 0 := by
    nlinarith
  have hj₀_mem : j₀ ∈ Finset.univ.filter (fun k : Fin K => p i₀ k = 0) :=
    Finset.mem_filter.mpr ⟨Finset.mem_univ j₀, hp₀⟩
  have he_le0 : e i₀ j₀ ≤ 0 :=
    le_trans (Finset.single_le_sum (fun j _ => (he_mem i₀).1 j) hj₀_mem) hsum_j_le0
  exact le_antisymm he_le0 ((he_mem i₀).1 j₀)

/-- Own-score inequality: `∑ i, ⟨P i - Z i, P i⟩ ≤ B * ∑ i, ⟨P i - Z i, s i⟩`. -/
lemma own_score_ineq {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {A₀ B : ℝ} (hB : 0 < B) {y : Fin n → Fin K}
    {Z s P : Fin n → UL.ZeroSumSubspace K}
    (hZ : ∀ i : Fin n, (Z i : EuclideanSpace ℝ (Fin K)) =
      EuclideanSpace.single (y i) (1 : ℝ) - UL.uniformVec K)
    (hs : ∀ i : Fin n, ‖s i‖ ≤ A₀)
    (hP : isOptFitAtScores A₀ B Z s P) :
    ∑ i : Fin n, inner ℝ (P i - Z i) (P i) ≤
      B * ∑ i : Fin n, inner ℝ (P i - Z i) (s i) := by
  have hsupp := fit_zero_coord_vanish hK hn hZ hs hP
  rcases hP.1 with ⟨ρ, hρ, hP_eq⟩
  let p : Fin n → EuclideanSpace ℝ (Fin K) :=
    fun i => UL.uniformVec K + (P i : EuclideanSpace ℝ (Fin K))
  let e : Fin n → EuclideanSpace ℝ (Fin K) :=
    fun i => EuclideanSpace.single (y i) (1 : ℝ)
  let w : Fin n → EuclideanSpace ℝ (Fin K) :=
    fun i => B • (s i : EuclideanSpace ℝ (Fin K)) - (P i : EuclideanSpace ℝ (Fin K))
  have hp_mem : ∀ i : Fin n, p i ∈ UL.Simplex K := fun i => by
    dsimp [p]; rw [hP_eq i]; exact hρ.1 (s i) (hs i)
  have he_mem : ∀ i : Fin n, e i ∈ UL.Simplex K := fun i =>
    UL.Proof_lem_A_1.single_mem_simplex (y i)
  have hex_δ : ∀ i : Fin n, ∃ δ : ℝ, 0 < δ ∧ ∀ t : ℝ, 0 < t → t < δ →
      inner ℝ (p i - e i) (((1 : ℝ) / t) • (projSimplexDef K (p i + t • w i) - p i)) =
        inner ℝ (p i - e i) (w i) :=
    fun i => projSimplex_inner_eq_of_small_t hK (hp_mem i) (he_mem i) (hsupp i)
  choose δ_i hδ_pos hδ_eq using hex_δ
  have h_univ_ne : (Finset.univ : Finset (Fin n)).Nonempty :=
    ⟨⟨0, by omega⟩, Finset.mem_univ _⟩
  let δ : ℝ := Finset.univ.inf' h_univ_ne δ_i
  have hδ_all_pos : 0 < δ := (Finset.lt_inf'_iff h_univ_ne).mpr fun i _ => hδ_pos i
  let t : ℝ := min 1 (δ / 2)
  have ht_pos : 0 < t := lt_min zero_lt_one (half_pos hδ_all_pos)
  have ht_le1 : t ≤ 1 := min_le_left _ _
  have ht_lt_δ : ∀ i : Fin n, t < δ_i i := fun i =>
    lt_of_le_of_lt (min_le_right _ _)
      (lt_of_lt_of_le (half_lt_self hδ_all_pos) (Finset.inf'_le δ_i (Finset.mem_univ i)))
  let ρ' : UL.ZeroSumSubspace K → UL.ZeroSumSubspace K := fun z =>
    ⟨projSimplexDef K (UL.uniformVec K + (1 - t) • (ρ z : EuclideanSpace ℝ (Fin K)) +
        (t * B) • (z : EuclideanSpace ℝ (Fin K))) - UL.uniformVec K,
      UL.Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex
        (projSimplex_mem hK _) (UL.Proof_lem_A_5.uniformVec_mem_simplex hK)⟩
  have hρ'_lip : isBLipPred K A₀ B ρ' := by
    refine ⟨fun z _ => ?_, fun z₁ z₂ hz₁ hz₂ => ?_⟩
    · unfold isKPred
      change UL.uniformVec K + (projSimplexDef K _ - UL.uniformVec K) ∈ UL.Simplex K
      have hadd : UL.uniformVec K +
          (projSimplexDef K (UL.uniformVec K + (1 - t) • (ρ z : EuclideanSpace ℝ (Fin K)) +
            (t * B) • (z : EuclideanSpace ℝ (Fin K))) - UL.uniformVec K) =
          projSimplexDef K (UL.uniformVec K + (1 - t) • (ρ z : EuclideanSpace ℝ (Fin K)) +
            (t * B) • (z : EuclideanSpace ℝ (Fin K))) := by abel
      rw [hadd]
      exact projSimplex_mem hK _
    · change ‖(projSimplexDef K _ - UL.uniformVec K) - (projSimplexDef K _ - UL.uniformVec K)‖ ≤
        B * ‖z₁ - z₂‖
      have hsub :
          (projSimplexDef K (UL.uniformVec K + (1 - t) • (ρ z₁ : EuclideanSpace ℝ (Fin K)) +
              (t * B) • (z₁ : EuclideanSpace ℝ (Fin K))) - UL.uniformVec K) -
            (projSimplexDef K (UL.uniformVec K + (1 - t) • (ρ z₂ : EuclideanSpace ℝ (Fin K)) +
              (t * B) • (z₂ : EuclideanSpace ℝ (Fin K))) - UL.uniformVec K) =
          projSimplexDef K (UL.uniformVec K + (1 - t) • (ρ z₁ : EuclideanSpace ℝ (Fin K)) +
              (t * B) • (z₁ : EuclideanSpace ℝ (Fin K))) -
            projSimplexDef K (UL.uniformVec K + (1 - t) • (ρ z₂ : EuclideanSpace ℝ (Fin K)) +
              (t * B) • (z₂ : EuclideanSpace ℝ (Fin K))) := by abel
      rw [hsub]
      have harg :
          (UL.uniformVec K + (1 - t) • (ρ z₁ : EuclideanSpace ℝ (Fin K)) +
              (t * B) • (z₁ : EuclideanSpace ℝ (Fin K))) -
            (UL.uniformVec K + (1 - t) • (ρ z₂ : EuclideanSpace ℝ (Fin K)) +
              (t * B) • (z₂ : EuclideanSpace ℝ (Fin K))) =
          (1 - t) • ((ρ z₁ - ρ z₂ : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) +
            (t * B) • ((z₁ - z₂ : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) := by
        simp only [Submodule.coe_sub]
        rw [smul_sub, smul_sub]
        abel
      calc ‖projSimplexDef K _ - projSimplexDef K _‖
          ≤ ‖(UL.uniformVec K + (1 - t) • (ρ z₁ : EuclideanSpace ℝ (Fin K)) +
                (t * B) • (z₁ : EuclideanSpace ℝ (Fin K))) -
              (UL.uniformVec K + (1 - t) • (ρ z₂ : EuclideanSpace ℝ (Fin K)) +
                (t * B) • (z₂ : EuclideanSpace ℝ (Fin K)))‖ :=
            projSimplex_nonexpansive hK _ _
        _ = ‖(1 - t) • ((ρ z₁ - ρ z₂ : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) +
              (t * B) • ((z₁ - z₂ : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))‖ := by
            rw [harg]
        _ ≤ ‖(1 - t) • ((ρ z₁ - ρ z₂ : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))‖ +
              ‖(t * B) • ((z₁ - z₂ : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))‖ :=
            norm_add_le _ _
        _ = (1 - t) * ‖ρ z₁ - ρ z₂‖ + (t * B) * ‖z₁ - z₂‖ := by
            rw [norm_smul, norm_smul, Real.norm_eq_abs, Real.norm_eq_abs,
              abs_of_nonneg (by linarith), abs_of_nonneg (mul_nonneg ht_pos.le hB.le)]
            rfl
        _ ≤ (1 - t) * (B * ‖z₁ - z₂‖) + (t * B) * ‖z₁ - z₂‖ :=
            add_le_add (mul_le_mul_of_nonneg_left (hρ.2 z₁ z₂ hz₁ hz₂) (by linarith)) le_rfl
        _ = B * ‖z₁ - z₂‖ := by ring
  have hvi := fit_vi_fin hn hP hρ'_lip
  have hvi_scaled : 0 ≤ ∑ i : Fin n, inner ℝ (p i - e i) (w i) := by
    have hmul := mul_nonneg (one_div_pos.mpr ht_pos).le hvi
    rw [Finset.mul_sum] at hmul
    refine le_trans hmul (le_of_eq (Finset.sum_congr rfl fun i _ => ?_))
    rw [← hδ_eq i t ht_pos (ht_lt_δ i), ← inner_smul_right]
    have hr_coe : ((P i - Z i : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) = p i - e i := by
      change (P i : EuclideanSpace ℝ (Fin K)) - (Z i : EuclideanSpace ℝ (Fin K)) = _
      rw [hZ i]; dsimp [p, e]; abel
    have harg_i : UL.uniformVec K + (1 - t) • (ρ (s i) : EuclideanSpace ℝ (Fin K)) +
        (t * B) • (s i : EuclideanSpace ℝ (Fin K)) = p i + t • w i := by
      rw [← hP_eq i]
      dsimp [p, w]
      rw [sub_smul, one_smul, smul_sub, mul_smul]
      abel
    have hd_coe : ((ρ' (s i) - P i : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) =
        projSimplexDef K (p i + t • w i) - p i := by
      change (projSimplexDef K _ - UL.uniformVec K) - (P i : EuclideanSpace ℝ (Fin K)) = _
      rw [harg_i]; dsimp [p]; abel
    change inner ℝ ((P i - Z i : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
      ((1 / t) • ((ρ' (s i) - P i : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))) = _
    rw [hr_coe, hd_coe]
  have hsum_split : ∑ i : Fin n, inner ℝ (p i - e i) (w i) =
      B * (∑ i : Fin n, inner ℝ (P i - Z i) (s i)) -
        ∑ i : Fin n, inner ℝ (P i - Z i) (P i) := by
    rw [Finset.mul_sum, ← Finset.sum_sub_distrib]
    refine Finset.sum_congr rfl fun i _ => ?_
    have hr_coe : p i - e i = ((P i - Z i : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) := by
      change _ = (P i : EuclideanSpace ℝ (Fin K)) - (Z i : EuclideanSpace ℝ (Fin K))
      rw [hZ i]; dsimp [p, e]; abel
    dsimp [w]
    rw [hr_coe, inner_sub_right, inner_smul_right]
    rfl
  linarith

/-- Convex-test inequality via `proxSimplex`:
`∑ i, ⟨p_i - e_i, simplexGrad Φ p_i - (1/B) • P i⟩ ≤ 0`. -/
lemma convex_test_ineq {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {A₀ β B lam M : ℝ} (hβ : 0 < β) (hB : β ≤ B) {y : Fin n → Fin K}
    {Z s P : Fin n → UL.ZeroSumSubspace K}
    (hZ : ∀ i : Fin n, (Z i : EuclideanSpace ℝ (Fin K)) =
      EuclideanSpace.single (y i) (1 : ℝ) - UL.uniformVec K)
    (hs : ∀ i : Fin n, ‖s i‖ ≤ A₀)
    (hP : isOptFitAtScores A₀ B Z s P)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M) :
    ∑ i : Fin n,
      inner ℝ ((UL.uniformVec K + (P i : EuclideanSpace ℝ (Fin K))) -
          EuclideanSpace.single (y i) (1 : ℝ))
        (UL.simplexGrad Φ (UL.uniformVec K + (P i : EuclideanSpace ℝ (Fin K)))) ≤
      (1 / B) * ∑ i : Fin n, inner ℝ (P i - Z i) (P i) := by
  have hB_pos : 0 < B := lt_of_lt_of_le hβ hB
  have hsupp := fit_zero_coord_vanish hK hn hZ hs hP
  rcases hP.1 with ⟨ρ, hρ, hP_eq⟩
  let p : Fin n → EuclideanSpace ℝ (Fin K) :=
    fun i => UL.uniformVec K + (P i : EuclideanSpace ℝ (Fin K))
  let e : Fin n → EuclideanSpace ℝ (Fin K) :=
    fun i => EuclideanSpace.single (y i) (1 : ℝ)
  let w : Fin n → EuclideanSpace ℝ (Fin K) :=
    fun i => -gJSimplex Φ B (p i)
  have hp_mem : ∀ i : Fin n, p i ∈ UL.Simplex K := fun i => by
    dsimp [p]; rw [hP_eq i]; exact hρ.1 (s i) (hs i)
  have he_mem : ∀ i : Fin n, e i ∈ UL.Simplex K := fun i =>
    UL.Proof_lem_A_1.single_mem_simplex (y i)
  have hex_δ : ∀ i : Fin n, ∃ δ : ℝ, 0 < δ ∧ ∀ t : ℝ, 0 < t → t < δ →
      inner ℝ (p i - e i) (((1 : ℝ) / t) • (projSimplexDef K (p i + t • w i) - p i)) =
        inner ℝ (p i - e i) (w i) :=
    fun i => projSimplex_inner_eq_of_small_t hK (hp_mem i) (he_mem i) (hsupp i)
  choose δ_i hδ_pos hδ_eq using hex_δ
  have h_univ_ne : (Finset.univ : Finset (Fin n)).Nonempty :=
    ⟨⟨0, by omega⟩, Finset.mem_univ _⟩
  let δ : ℝ := Finset.univ.inf' h_univ_ne δ_i
  have hδ_all_pos : 0 < δ := (Finset.lt_inf'_iff h_univ_ne).mpr fun i _ => hδ_pos i
  let C_J : ℝ := (lam + 1 / B) * (M + 2 / B)
  have hCJ_nn : 0 ≤ C_J := by
    have hlam : 0 < lam := hΦ.2.1
    have hM : 0 < M := hΦ.2.2.1
    dsimp [C_J]; positivity
  -- Show 0 ≤ ∑ i, inner ℝ (p i - e i) (w i) by bounding error by 2 * n * C_J * t for all t ∈ (0, δ)
  have h_sum_nonneg : 0 ≤ ∑ i : Fin n, inner ℝ (p i - e i) (w i) := by
    set S_val := ∑ i : Fin n, inner ℝ (p i - e i) (w i)
    by_contra hS_neg
    push_neg at hS_neg
    let K_err : ℝ := 2 * (n : ℝ) * C_J + 1
    have hK_err_pos : 0 < K_err := by positivity
    let t : ℝ := min (δ / 2) ((-S_val) / (2 * K_err))
    have ht_pos : 0 < t := lt_min (half_pos hδ_all_pos) (div_pos (by linarith) (by positivity))
    have ht_lt_δ : ∀ i : Fin n, t < δ_i i := fun i =>
      lt_of_le_of_lt (min_le_left _ _)
        (lt_of_lt_of_le (half_lt_self hδ_all_pos) (Finset.inf'_le δ_i (Finset.mem_univ i)))
    have ht_err : t * K_err ≤ -S_val / 2 := by
      have hle : t ≤ (-S_val) / (2 * K_err) := min_le_right _ _
      calc t * K_err ≤ ((-S_val) / (2 * K_err)) * K_err :=
            mul_le_mul_of_nonneg_right hle hK_err_pos.le
        _ = -S_val / 2 := by field_simp [hK_err_pos.ne']
    let ρ' : UL.ZeroSumSubspace K → UL.ZeroSumSubspace K := fun z =>
      ⟨proxSimplex Φ B t (UL.uniformVec K + (ρ z : EuclideanSpace ℝ (Fin K))) - UL.uniformVec K,
        UL.Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex
          (proxSimplex_mem hK hΦ.1.2.1 B t _) (UL.Proof_lem_A_5.uniformVec_mem_simplex hK)⟩
    have hρ'_lip : isBLipPred K A₀ B ρ' := by
      refine ⟨fun z _ => ?_, fun z₁ z₂ hz₁ hz₂ => ?_⟩
      · unfold isKPred
        change UL.uniformVec K + (proxSimplex Φ B t _ - UL.uniformVec K) ∈ UL.Simplex K
        have hadd : UL.uniformVec K +
            (proxSimplex Φ B t (UL.uniformVec K + (ρ z : EuclideanSpace ℝ (Fin K))) -
              UL.uniformVec K) =
            proxSimplex Φ B t (UL.uniformVec K + (ρ z : EuclideanSpace ℝ (Fin K))) := by abel
        rw [hadd]
        exact proxSimplex_mem hK hΦ.1.2.1 B t _
      · change ‖(proxSimplex Φ B t _ - UL.uniformVec K) -
            (proxSimplex Φ B t _ - UL.uniformVec K)‖ ≤ B * ‖z₁ - z₂‖
        have hsub :
            (proxSimplex Φ B t (UL.uniformVec K + (ρ z₁ : EuclideanSpace ℝ (Fin K))) -
                UL.uniformVec K) -
              (proxSimplex Φ B t (UL.uniformVec K + (ρ z₂ : EuclideanSpace ℝ (Fin K))) -
                UL.uniformVec K) =
            proxSimplex Φ B t (UL.uniformVec K + (ρ z₁ : EuclideanSpace ℝ (Fin K))) -
              proxSimplex Φ B t (UL.uniformVec K + (ρ z₂ : EuclideanSpace ℝ (Fin K))) := by abel
        rw [hsub]
        calc ‖proxSimplex Φ B t (UL.uniformVec K + (ρ z₁ : EuclideanSpace ℝ (Fin K))) -
              proxSimplex Φ B t (UL.uniformVec K + (ρ z₂ : EuclideanSpace ℝ (Fin K)))‖
            ≤ ‖(UL.uniformVec K + (ρ z₁ : EuclideanSpace ℝ (Fin K))) -
                (UL.uniformVec K + (ρ z₂ : EuclideanSpace ℝ (Fin K)))‖ :=
              proxSimplex_nonexpansive hK hβ hB ht_pos hΦ _ _
          _ = ‖ρ z₁ - ρ z₂‖ := by
              have h1 : (UL.uniformVec K + (ρ z₁ : EuclideanSpace ℝ (Fin K))) -
                  (UL.uniformVec K + (ρ z₂ : EuclideanSpace ℝ (Fin K))) =
                  (ρ z₁ : EuclideanSpace ℝ (Fin K)) - (ρ z₂ : EuclideanSpace ℝ (Fin K)) := by abel
              rw [h1]; rfl
          _ ≤ B * ‖z₁ - z₂‖ := hρ.2 z₁ z₂ hz₁ hz₂
    have hvi := fit_vi_fin hn hP hρ'_lip
    have hvi_scaled : 0 ≤ ∑ i : Fin n,
        inner ℝ (p i - e i) ((1 / t) • (proxSimplex Φ B t (p i) - p i)) := by
      have hmul := mul_nonneg (one_div_pos.mpr ht_pos).le hvi
      rw [Finset.mul_sum] at hmul
      refine le_trans hmul (le_of_eq (Finset.sum_congr rfl fun i _ => ?_))
      rw [← inner_smul_right]
      have hr_coe : ((P i - Z i : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) =
          p i - e i := by
        change (P i : EuclideanSpace ℝ (Fin K)) - (Z i : EuclideanSpace ℝ (Fin K)) = _
        rw [hZ i]; dsimp [p, e]; abel
      have hd_coe : ((ρ' (s i) - P i : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) =
          proxSimplex Φ B t (p i) - p i := by
        change (proxSimplex Φ B t (UL.uniformVec K + (ρ (s i) : EuclideanSpace ℝ (Fin K))) -
            UL.uniformVec K) - (P i : EuclideanSpace ℝ (Fin K)) = _
        rw [← hP_eq i]; dsimp [p]; abel
      change inner ℝ ((P i - Z i : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
        ((1 / t) • ((ρ' (s i) - P i : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))) = _
      rw [hr_coe, hd_coe]
    have h_ptwise : ∀ i : Fin n,
        inner ℝ (p i - e i) ((1 / t) • (proxSimplex Φ B t (p i) - p i)) ≤
          inner ℝ (p i - e i) (w i) + 2 * C_J * t := by
      intro i
      have h_id := hδ_eq i t ht_pos (ht_lt_δ i)
      have h_arg : p i + t • w i = p i - t • gJSimplex Φ B (p i) := by
        dsimp [w]; rw [smul_neg, sub_eq_add_neg]
      have h_split : (1 / t) • (proxSimplex Φ B t (p i) - p i) =
          ((1 / t) • (projSimplexDef K (p i + t • w i) - p i)) +
            (1 / t) • (proxSimplex Φ B t (p i) - projSimplexDef K (p i - t • gJSimplex Φ B (p i))) := by
        rw [h_arg, ← smul_add]
        congr 1
        abel
      rw [h_split, inner_add_right, h_id]
      have hr_norm : ‖p i - e i‖ ≤ 2 := by
        calc ‖p i - e i‖ ≤ ‖p i‖ + ‖e i‖ := norm_sub_le _ _
          _ ≤ 1 + 1 := add_le_add (norm_le_one_of_mem_simplex (hp_mem i))
              (norm_le_one_of_mem_simplex (he_mem i))
          _ = 2 := by norm_num
      have h_approx := proxSimplex_approx hK hβ hB ht_pos hΦ (hp_mem i)
      have h_err : inner ℝ (p i - e i)
          ((1 / t) • (proxSimplex Φ B t (p i) -
            projSimplexDef K (p i - t • gJSimplex Φ B (p i)))) ≤ 2 * C_J * t := by
        rw [inner_smul_right]
        have hcs := real_inner_le_norm (p i - e i)
          (proxSimplex Φ B t (p i) - projSimplexDef K (p i - t • gJSimplex Φ B (p i)))
        have hprod : ‖p i - e i‖ *
            ‖proxSimplex Φ B t (p i) - projSimplexDef K (p i - t • gJSimplex Φ B (p i))‖ ≤
            2 * (C_J * t ^ 2) :=
          mul_le_mul hr_norm h_approx (norm_nonneg _) (by norm_num)
        calc (1 / t) * inner ℝ (p i - e i) _
            ≤ (1 / t) * (2 * (C_J * t ^ 2)) :=
              mul_le_mul_of_nonneg_left (le_trans hcs hprod) (one_div_pos.mpr ht_pos).le
          _ = 2 * C_J * t := by field_simp [ht_pos.ne']
      linarith
    have h_sum_ub : ∑ i : Fin n,
        inner ℝ (p i - e i) ((1 / t) • (proxSimplex Φ B t (p i) - p i)) ≤
        S_val + (n : ℝ) * (2 * C_J * t) := by
      calc ∑ i : Fin n, inner ℝ (p i - e i) ((1 / t) • (proxSimplex Φ B t (p i) - p i))
          ≤ ∑ i : Fin n, (inner ℝ (p i - e i) (w i) + 2 * C_J * t) :=
            Finset.sum_le_sum fun i _ => h_ptwise i
        _ = S_val + (n : ℝ) * (2 * C_J * t) := by
            rw [Finset.sum_add_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
              nsmul_eq_mul]
    have h_nCJ : (n : ℝ) * (2 * C_J * t) < t * K_err := by
      dsimp [K_err]
      nlinarith
    linarith
  -- Unpack w i = -gJSimplex Φ B (p i)
  have h_unpack : ∑ i : Fin n, inner ℝ (p i - e i) (w i) =
      (1 / B) * (∑ i : Fin n, inner ℝ (P i - Z i) (P i)) -
        ∑ i : Fin n, inner ℝ (p i - e i) (UL.simplexGrad Φ (p i)) := by
    rw [Finset.mul_sum, ← Finset.sum_sub_distrib]
    refine Finset.sum_congr rfl fun i _ => ?_
    have hr_coe : p i - e i = ((P i - Z i : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) := by
      change _ = (P i : EuclideanSpace ℝ (Fin K)) - (Z i : EuclideanSpace ℝ (Fin K))
      rw [hZ i]; dsimp [p, e]; abel
    have hp_sub : p i - UL.uniformVec K = (P i : EuclideanSpace ℝ (Fin K)) := by
      dsimp [p]; abel
    have h_p_inner : inner ℝ (p i - e i) (P i : EuclideanSpace ℝ (Fin K)) =
        inner ℝ (P i - Z i) (P i) := by
      rw [hr_coe]
      rfl
    dsimp only [w]
    unfold gJSimplex
    rw [inner_neg_right, inner_sub_right, hp_sub, inner_smul_right, h_p_inner]
    ring
  dsimp only [p, e] at h_sum_nonneg h_unpack
  linarith

/-- Master empirical simultaneous comparison bound for any `W` with `hilbertSchmidtNorm W ≤ R`. -/
lemma empirical_comparison_bound
    {K : ℕ} (hK : 2 ≤ K)
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X] [CompleteSpace X]
    {n : ℕ} (hn : 1 ≤ n)
    (x : Fin n → X) (y : Fin n → Fin K)
    {L R β B lam M : ℝ}
    (_hL : 0 < L) (hx : ∀ i : Fin n, ‖x i‖ ≤ L)
    (hR : 0 < R) (hβ : 0 < β) (hB : β ≤ B)
    {Z : Fin n → UL.ZeroSumSubspace K}
    (hZ : ∀ i : Fin n, (Z i : EuclideanSpace ℝ (Fin K)) =
      EuclideanSpace.single (y i) (1 : ℝ) - UL.uniformVec K)
    {W : X →L[ℝ] UL.ZeroSumSubspace K} (hW : UL.hilbertSchmidtNorm W ≤ R)
    {P : Fin n → UL.ZeroSumSubspace K}
    (hP : isOptFitAtScores (L * R) B Z (fun i => W (x i)) P)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M) :
    let u := UL.uniformVec K
    let g : X →L[ℝ] UL.ZeroSumSubspace K :=
      (1 / (n : ℝ)) • ∑ i : Fin n, (innerSL ℝ (x i)).smulRight (P i - Z i)
    let gam : ℝ :=
      ((1 : ℝ) / 4) * (UL.hilbertSchmidtNorm (g + W) ^ 2 - UL.hilbertSchmidtNorm (g - W) ^ 2) +
        R * UL.hilbertSchmidtNorm g
    (1 / (n : ℝ)) * ∑ i : Fin n,
        UL.finiteCanonicalLoss Φ (u + (P i : EuclideanSpace ℝ (Fin K))) (y i) ≤
      (⨅ V : {V : X →L[ℝ] UL.ZeroSumSubspace K // UL.hilbertSchmidtNorm V ≤ R},
        (1 / (n : ℝ)) * ∑ i : Fin n,
          UL.matchingLoss Φ ((V.1 (x i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) (y i)) +
        gam := by
  intro u g gam
  have hB_pos : 0 < B := lt_of_lt_of_le hβ hB
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  have hn_inv_nn : 0 ≤ 1 / (n : ℝ) := (one_div_pos.mpr hn_pos).le
  have hs_bound : ∀ i : Fin n, ‖W (x i)‖ ≤ L * R := by
    intro i
    calc ‖W (x i)‖
        ≤ UL.hilbertSchmidtNorm W * ‖x i‖ := norm_apply_le_hilbertSchmidtNorm W (x i)
      _ ≤ R * L := mul_le_mul hW (hx i) (norm_nonneg _) hR.le
      _ = L * R := mul_comm R L
  rcases hP.1 with ⟨ρ, hρ, hP_eq⟩
  have hp_mem : ∀ i : Fin n, u + (P i : EuclideanSpace ℝ (Fin K)) ∈ UL.Simplex K := fun i => by
    dsimp [u]; rw [hP_eq i]; exact hρ.1 (W (x i)) (hs_bound i)
  have h_own := own_score_ineq hK hn hB_pos hZ hs_bound hP
  have h_conv := convex_test_ineq hK hn hβ hB hZ hs_bound hP hΦ
  have h_own_div : (1 / B) * ∑ i : Fin n, inner ℝ (P i - Z i) (P i) ≤
      ∑ i : Fin n, inner ℝ (P i - Z i) (W (x i)) := by
    have hmul := mul_le_mul_of_nonneg_left h_own (one_div_pos.mpr hB_pos).le
    have hcancel : (1 / B) * (B * ∑ i : Fin n, inner ℝ (P i - Z i) (W (x i))) =
        ∑ i : Fin n, inner ℝ (P i - Z i) (W (x i)) := by
      field_simp [hB_pos.ne']
    linarith
  have h_grad_le_W :
      ∑ i : Fin n, inner ℝ ((u + (P i : EuclideanSpace ℝ (Fin K))) -
          EuclideanSpace.single (y i) (1 : ℝ))
        (UL.simplexGrad Φ (u + (P i : EuclideanSpace ℝ (Fin K)))) ≤
      ∑ i : Fin n, inner ℝ (P i - Z i) (W (x i)) :=
    le_trans h_conv h_own_div
  have h_canon_ub :
      (1 / (n : ℝ)) * ∑ i : Fin n,
          UL.finiteCanonicalLoss Φ (u + (P i : EuclideanSpace ℝ (Fin K))) (y i) ≤
        -(1 / (n : ℝ)) * (∑ i : Fin n, UL.extendSimplex Φ (u + (P i : EuclideanSpace ℝ (Fin K)))) +
          (1 / (n : ℝ)) * ∑ i : Fin n, inner ℝ (P i - Z i) (W (x i)) := by
    have h_sum_eq : ∑ i : Fin n,
        UL.finiteCanonicalLoss Φ (u + (P i : EuclideanSpace ℝ (Fin K))) (y i) =
        -(∑ i : Fin n, UL.extendSimplex Φ (u + (P i : EuclideanSpace ℝ (Fin K)))) +
          ∑ i : Fin n, inner ℝ ((u + (P i : EuclideanSpace ℝ (Fin K))) -
            EuclideanSpace.single (y i) (1 : ℝ))
            (UL.simplexGrad Φ (u + (P i : EuclideanSpace ℝ (Fin K)))) := by
      simp_rw [finiteCanonicalLoss_eq hΦ (hp_mem _), Finset.sum_add_distrib, Finset.sum_neg_distrib]
    rw [h_sum_eq]
    have h_sum_le :
        -(∑ i : Fin n, UL.extendSimplex Φ (u + (P i : EuclideanSpace ℝ (Fin K)))) +
            (∑ i : Fin n, inner ℝ ((u + (P i : EuclideanSpace ℝ (Fin K))) -
              EuclideanSpace.single (y i) (1 : ℝ))
              (UL.simplexGrad Φ (u + (P i : EuclideanSpace ℝ (Fin K))))) ≤
          -(∑ i : Fin n, UL.extendSimplex Φ (u + (P i : EuclideanSpace ℝ (Fin K)))) +
            ∑ i : Fin n, inner ℝ (P i - Z i) (W (x i)) := by linarith
    have hmul := mul_le_mul_of_nonneg_left h_sum_le hn_inv_nn
    linarith
  haveI : Nonempty {V : X →L[ℝ] UL.ZeroSumSubspace K // UL.hilbertSchmidtNorm V ≤ R} :=
    ⟨⟨0, by rw [hilbertSchmidtNorm_zero]; exact hR.le⟩⟩
  suffices h_le_inf :
      ((1 / (n : ℝ)) * ∑ i : Fin n,
          UL.finiteCanonicalLoss Φ (u + (P i : EuclideanSpace ℝ (Fin K))) (y i)) - gam ≤
        ⨅ V : {V : X →L[ℝ] UL.ZeroSumSubspace K // UL.hilbertSchmidtNorm V ≤ R},
          (1 / (n : ℝ)) * ∑ i : Fin n,
            UL.matchingLoss Φ ((V.1 (x i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) (y i) by
    linarith
  refine le_ciInf fun V => ?_
  have h_match_lb :
      -(1 / (n : ℝ)) * (∑ i : Fin n, UL.extendSimplex Φ (u + (P i : EuclideanSpace ℝ (Fin K)))) +
          (1 / (n : ℝ)) * ∑ i : Fin n, inner ℝ (P i - Z i) (V.1 (x i)) ≤
        (1 / (n : ℝ)) * ∑ i : Fin n,
          UL.matchingLoss Φ ((V.1 (x i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) (y i) := by
    have h_pt : ∀ i : Fin n,
        -UL.extendSimplex Φ (u + (P i : EuclideanSpace ℝ (Fin K))) +
            inner ℝ (P i - Z i) (V.1 (x i)) ≤
          UL.matchingLoss Φ ((V.1 (x i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) (y i) := by
      intro i
      have hlb := matchingLoss_lower_bound hΦ.1.2.1 (hp_mem i) (V.1 (x i)) (y i)
      have hr_coe : (u + (P i : EuclideanSpace ℝ (Fin K))) - EuclideanSpace.single (y i) (1 : ℝ) =
          ((P i - Z i : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) := by
        change _ = (P i : EuclideanSpace ℝ (Fin K)) - (Z i : EuclideanSpace ℝ (Fin K))
        rw [hZ i]; dsimp [u]; abel
      rw [hr_coe] at hlb
      exact hlb
    have h_sum := Finset.sum_le_sum (s := Finset.univ) fun i _ => h_pt i
    rw [Finset.sum_add_distrib, Finset.sum_neg_distrib] at h_sum
    have hmul := mul_le_mul_of_nonneg_left h_sum hn_inv_nn
    linarith
  have h_gam := empGrad_diff_le_gamma x (fun i => P i - Z i) W V.1 V.2
  dsimp only at h_gam
  dsimp only [gam, g]
  linarith

end EmpiricalFit

end UL.Proof_lem_C_2

import Mathlib
import UL.Def.def_5_smooth
set_option autoImplicit false

namespace UL.Proof_lem_C_2

section HilbertSchmidt

variable {X Y : Type*}
  [NormedAddCommGroup X] [InnerProductSpace ℝ X] [CompleteSpace X]
  [NormedAddCommGroup Y] [InnerProductSpace ℝ Y] [FiniteDimensional ℝ Y]

/-- Riesz representative in `X` of `x ↦ inner ℝ y (W x)`, i.e. `W* y`. -/
noncomputable def adjVec (W : X →L[ℝ] Y) (y : Y) : X :=
  (InnerProductSpace.toDual ℝ X).symm ((innerSL ℝ y).comp W)

lemma inner_adjVec_left (W : X →L[ℝ] Y) (y : Y) (x : X) :
    inner ℝ (adjVec W y) x = inner ℝ y (W x) := by
  unfold adjVec
  rw [InnerProductSpace.toDual_symm_apply]
  rfl

lemma inner_adjVec_right (W : X →L[ℝ] Y) (y : Y) (x : X) :
    inner ℝ x (adjVec W y) = inner ℝ (W x) y := by
  rw [real_inner_comm, inner_adjVec_left, real_inner_comm]

lemma adjVec_add (A B : X →L[ℝ] Y) (y : Y) :
    adjVec (A + B) y = adjVec A y + adjVec B y := by
  refine ext_inner_right ℝ fun x => ?_
  rw [inner_add_left, inner_adjVec_left, inner_adjVec_left, inner_adjVec_left,
    ContinuousLinearMap.add_apply, inner_add_right]

lemma adjVec_sub (A B : X →L[ℝ] Y) (y : Y) :
    adjVec (A - B) y = adjVec A y - adjVec B y := by
  refine ext_inner_right ℝ fun x => ?_
  rw [inner_sub_left, inner_adjVec_left, inner_adjVec_left, inner_adjVec_left,
    ContinuousLinearMap.sub_apply, inner_sub_right]

lemma adjVec_neg (A : X →L[ℝ] Y) (y : Y) :
    adjVec (-A) y = -adjVec A y := by
  refine ext_inner_right ℝ fun x => ?_
  rw [inner_neg_left, inner_adjVec_left, inner_adjVec_left,
    ContinuousLinearMap.neg_apply, inner_neg_right]

lemma adjVec_zero (y : Y) : adjVec (0 : X →L[ℝ] Y) y = 0 := by
  refine ext_inner_right ℝ fun x => ?_
  rw [inner_adjVec_left, ContinuousLinearMap.zero_apply, inner_zero_right, inner_zero_left]

private lemma norm_sq_eq_sum_stdBasis (v : Y) :
    let bY := stdOrthonormalBasis ℝ Y
    ‖v‖ ^ 2 = ∑ j : Fin (Module.finrank ℝ Y), (inner ℝ v (bY j)) ^ 2 := by
  intro bY
  rw [← real_inner_self_eq_norm_sq, ← bY.sum_inner_mul_inner v v]
  refine Finset.sum_congr rfl fun j _ => ?_
  rw [real_inner_comm (bY j) v, sq]

private lemma finite_bessel {s : Finset X}
    (hs : Orthonormal ℝ (Subtype.val : s → X)) (u : X) :
    ∑ x ∈ s, (inner ℝ x u) ^ 2 ≤ ‖u‖ ^ 2 := by
  classical
  have hite := orthonormal_iff_ite.mp hs
  let p : X := ∑ x ∈ s.attach, inner ℝ (x.1 : X) u • (x.1 : X)
  have hup : inner ℝ u p = ∑ x ∈ s.attach, (inner ℝ (x.1 : X) u) ^ 2 := by
    dsimp [p]
    rw [inner_sum]
    refine Finset.sum_congr rfl fun x _ => ?_
    rw [inner_smul_right, real_inner_comm u x.1, sq]
  have hpp : ‖p‖ ^ 2 = ∑ x ∈ s.attach, (inner ℝ (x.1 : X) u) ^ 2 := by
    rw [← real_inner_self_eq_norm_sq]
    dsimp [p]
    rw [sum_inner]
    refine Finset.sum_congr rfl fun x _ => ?_
    rw [inner_smul_left, inner_sum]
    simp only [conj_trivial]
    have hsingle :
        ∑ y ∈ s.attach, inner ℝ x.1 (inner ℝ y.1 u • y.1) = inner ℝ x.1 u := by
      calc ∑ y ∈ s.attach, inner ℝ x.1 (inner ℝ y.1 u • y.1)
          = ∑ y ∈ s.attach, (if y = x then inner ℝ x.1 u else 0) := by
              refine Finset.sum_congr rfl fun y _ => ?_
              rw [inner_smul_right, hite x y]
              by_cases hxy : y = x
              · subst hxy; simp
              · have hne : x ≠ y := fun h => hxy h.symm
                simp [hxy, hne]
        _ = inner ℝ x.1 u := by simp
    rw [hsingle, sq]
  have hdiff : 0 ≤ ‖u - p‖ ^ 2 := sq_nonneg _
  rw [norm_sub_sq_real, hup, hpp] at hdiff
  have hatt : ∑ x ∈ s.attach, (inner ℝ (x.1 : X) u) ^ 2 = ∑ x ∈ s, (inner ℝ x u) ^ 2 :=
    Finset.sum_attach s (fun x => (inner ℝ x u) ^ 2)
  linarith

/-- Exact finite-sum formula for the supremum inside `hilbertSchmidtNorm`. -/
lemma hs_iSup_eq_sum_adjVec (W : X →L[ℝ] Y) :
    let bY := stdOrthonormalBasis ℝ Y
    (⨆ s : {s : Finset X // Orthonormal ℝ (Subtype.val : s → X)}, ∑ x ∈ s.1, ‖W x‖ ^ 2) =
      ∑ j : Fin (Module.finrank ℝ Y), ‖adjVec W (bY j)‖ ^ 2 := by
  classical
  intro bY
  let S : ℝ := ∑ j : Fin (Module.finrank ℝ Y), ‖adjVec W (bY j)‖ ^ 2
  have h_le : ∀ s : {s : Finset X // Orthonormal ℝ (Subtype.val : s → X)},
      ∑ x ∈ s.1, ‖W x‖ ^ 2 ≤ S := by
    intro s
    have h1 : ∀ x : X, ‖W x‖ ^ 2 =
        ∑ j : Fin (Module.finrank ℝ Y), (inner ℝ x (adjVec W (bY j))) ^ 2 := by
      intro x
      rw [norm_sq_eq_sum_stdBasis (W x)]
      refine Finset.sum_congr rfl fun j _ => ?_
      rw [inner_adjVec_right]
    simp_rw [h1]
    rw [Finset.sum_comm]
    exact Finset.sum_le_sum fun j _ => finite_bessel s.2 (adjVec W (bY j))
  have h_bdd : BddAbove
      (Set.range (fun s : {s : Finset X // Orthonormal ℝ (Subtype.val : s → X)} =>
        ∑ x ∈ s.1, ‖W x‖ ^ 2)) :=
    ⟨S, Set.forall_mem_range.mpr h_le⟩
  let F : Submodule ℝ X := Submodule.span ℝ (Set.range (fun j => adjVec W (bY j)))
  haveI : FiniteDimensional ℝ F := FiniteDimensional.span_of_finite ℝ (Set.finite_range _)
  let bF := stdOrthonormalBasis ℝ F
  let e : Fin (Module.finrank ℝ F) → X := fun k => (bF k : X)
  have he_ite : ∀ k₁ k₂ : Fin (Module.finrank ℝ F),
      inner ℝ (e k₁) (e k₂) = if k₁ = k₂ then 1 else 0 := by
    intro k₁ k₂
    exact orthonormal_iff_ite.mp bF.orthonormal k₁ k₂
  have he_inj : Function.Injective e := by
    intro k₁ k₂ h
    by_contra hne
    have h1 := he_ite k₁ k₁
    simp only [ ↓reduceIte] at h1
    have h0 := he_ite k₁ k₂
    rw [if_neg hne, h] at h0
    rw [h] at h1
    linarith
  let s₀ : Finset X := Finset.univ.image e
  have hs₀_ortho : Orthonormal ℝ (Subtype.val : s₀ → X) := by
    rw [orthonormal_iff_ite]
    intro a b
    rcases Finset.mem_image.mp a.2 with ⟨k₁, _, hk₁⟩
    rcases Finset.mem_image.mp b.2 with ⟨k₂, _, hk₂⟩
    change inner ℝ a.1 b.1 = if a = b then 1 else 0
    rw [← hk₁, ← hk₂, he_ite]
    by_cases hk : k₁ = k₂
    · subst hk
      have hab : a = b := Subtype.ext (hk₁.symm.trans hk₂)
      simp [hab]
    · have hab : a ≠ b := fun h => hk (he_inj (hk₁.trans ((congrArg Subtype.val h).trans hk₂.symm)))
      simp [hk, hab]
  have hs₀_eq : ∑ x ∈ s₀, ‖W x‖ ^ 2 = S := by
    dsimp [s₀]
    rw [Finset.sum_image (fun k₁ _ k₂ _ h => he_inj h)]
    have h1 : ∀ k : Fin (Module.finrank ℝ F), ‖W (e k)‖ ^ 2 =
        ∑ j : Fin (Module.finrank ℝ Y), (inner ℝ (e k) (adjVec W (bY j))) ^ 2 := by
      intro k
      rw [norm_sq_eq_sum_stdBasis (W (e k))]
      refine Finset.sum_congr rfl fun j _ => ?_
      rw [inner_adjVec_right]
    simp_rw [h1]
    rw [Finset.sum_comm]
    dsimp [S]
    refine Finset.sum_congr rfl fun j _ => ?_
    let uF : F := ⟨adjVec W (bY j), Submodule.subset_span ⟨j, rfl⟩⟩
    have hparseval := bF.sum_inner_mul_inner uF uF
    have hnormF : inner ℝ uF uF = ‖adjVec W (bY j)‖ ^ 2 := by
      rw [real_inner_self_eq_norm_sq]
      rfl
    rw [← hnormF, ← hparseval]
    refine Finset.sum_congr rfl fun k _ => ?_
    have hcoe : inner ℝ (e k) (adjVec W (bY j)) = inner ℝ (bF k) uF := by
      rfl
    rw [hcoe, real_inner_comm uF (bF k), sq]
  haveI : Nonempty {s : Finset X // Orthonormal ℝ (Subtype.val : s → X)} := ⟨⟨s₀, hs₀_ortho⟩⟩
  refine le_antisymm (ciSup_le h_le) ?_
  change S ≤ _
  rw [← hs₀_eq]
  exact le_ciSup h_bdd ⟨s₀, hs₀_ortho⟩

lemma hilbertSchmidtNorm_eq_sqrt (W : X →L[ℝ] Y) :
    let bY := stdOrthonormalBasis ℝ Y
    UL.hilbertSchmidtNorm W =
      Real.sqrt (∑ j : Fin (Module.finrank ℝ Y), ‖adjVec W (bY j)‖ ^ 2) := by
  intro bY
  unfold UL.hilbertSchmidtNorm
  rw [hs_iSup_eq_sum_adjVec W]

lemma hilbertSchmidtNorm_sq (W : X →L[ℝ] Y) :
    let bY := stdOrthonormalBasis ℝ Y
    UL.hilbertSchmidtNorm W ^ 2 =
      ∑ j : Fin (Module.finrank ℝ Y), ‖adjVec W (bY j)‖ ^ 2 := by
  intro bY
  rw [hilbertSchmidtNorm_eq_sqrt W]
  exact Real.sq_sqrt (Finset.sum_nonneg fun j _ => sq_nonneg _)

lemma hilbertSchmidtNorm_nonneg (W : X →L[ℝ] Y) : 0 ≤ UL.hilbertSchmidtNorm W := by
  rw [hilbertSchmidtNorm_eq_sqrt W]
  exact Real.sqrt_nonneg _

lemma hilbertSchmidtNorm_zero : UL.hilbertSchmidtNorm (0 : X →L[ℝ] Y) = 0 := by
  rw [hilbertSchmidtNorm_eq_sqrt]
  simp [adjVec_zero]

lemma hilbertSchmidtNorm_neg (V : X →L[ℝ] Y) :
    UL.hilbertSchmidtNorm (-V) = UL.hilbertSchmidtNorm V := by
  rw [hilbertSchmidtNorm_eq_sqrt (-V), hilbertSchmidtNorm_eq_sqrt V]
  congr 1
  refine Finset.sum_congr rfl fun j _ => ?_
  rw [adjVec_neg, norm_neg]

lemma norm_apply_le_hilbertSchmidtNorm (W : X →L[ℝ] Y) (x : X) :
    ‖W x‖ ≤ UL.hilbertSchmidtNorm W * ‖x‖ := by
  let bY := stdOrthonormalBasis ℝ Y
  have hsq : ‖W x‖ ^ 2 ≤ (UL.hilbertSchmidtNorm W * ‖x‖) ^ 2 := by
    rw [norm_sq_eq_sum_stdBasis (W x), mul_pow, hilbertSchmidtNorm_sq W, Finset.sum_mul]
    refine Finset.sum_le_sum fun j _ => ?_
    rw [← inner_adjVec_right W (bY j) x]
    have hcs := abs_real_inner_le_norm x (adjVec W (bY j))
    have h1 : (inner ℝ x (adjVec W (bY j))) ^ 2 = |inner ℝ x (adjVec W (bY j))| ^ 2 :=
      (sq_abs _).symm
    rw [h1]
    have h2 : |inner ℝ x (adjVec W (bY j))| ^ 2 ≤ (‖x‖ * ‖adjVec W (bY j)‖) ^ 2 :=
      pow_le_pow_left₀ (abs_nonneg _) hcs 2
    linarith [sq_nonneg (‖x‖ * ‖adjVec W (bY j)‖)]
  have hnn1 : 0 ≤ ‖W x‖ := norm_nonneg _
  have hnn2 : 0 ≤ UL.hilbertSchmidtNorm W * ‖x‖ :=
    mul_nonneg (hilbertSchmidtNorm_nonneg W) (norm_nonneg x)
  nlinarith

/-- Frobenius inner product of Hilbert-Schmidt operators `X →L[ℝ] Y`. -/
noncomputable def hsInner (A B : X →L[ℝ] Y) : ℝ :=
  let bY := stdOrthonormalBasis ℝ Y
  ∑ j : Fin (Module.finrank ℝ Y), inner ℝ (adjVec A (bY j)) (adjVec B (bY j))

lemma hsInner_eq_polarization (A B : X →L[ℝ] Y) :
    ((1 : ℝ) / 4) * (UL.hilbertSchmidtNorm (A + B) ^ 2 - UL.hilbertSchmidtNorm (A - B) ^ 2) =
      hsInner A B := by
  rw [hilbertSchmidtNorm_sq (A + B), hilbertSchmidtNorm_sq (A - B)]
  unfold hsInner
  dsimp only
  rw [← Finset.sum_sub_distrib, Finset.mul_sum]
  refine Finset.sum_congr rfl fun j _ => ?_
  rw [adjVec_add, adjVec_sub, norm_add_sq_real, norm_sub_sq_real]
  ring

lemma abs_hsInner_le (A B : X →L[ℝ] Y) :
    |hsInner A B| ≤ UL.hilbertSchmidtNorm A * UL.hilbertSchmidtNorm B := by
  let bY := stdOrthonormalBasis ℝ Y
  calc |hsInner A B|
      ≤ ∑ j : Fin (Module.finrank ℝ Y),
          |inner ℝ (adjVec A (bY j)) (adjVec B (bY j))| :=
        Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ j : Fin (Module.finrank ℝ Y),
          ‖adjVec A (bY j)‖ * ‖adjVec B (bY j)‖ :=
        Finset.sum_le_sum fun j _ => abs_real_inner_le_norm _ _
    _ ≤ Real.sqrt (∑ j : Fin (Module.finrank ℝ Y), ‖adjVec A (bY j)‖ ^ 2) *
          Real.sqrt (∑ j : Fin (Module.finrank ℝ Y), ‖adjVec B (bY j)‖ ^ 2) :=
        Real.sum_mul_le_sqrt_mul_sqrt Finset.univ _ _
    _ = UL.hilbertSchmidtNorm A * UL.hilbertSchmidtNorm B := by
        rw [← hilbertSchmidtNorm_eq_sqrt A, ← hilbertSchmidtNorm_eq_sqrt B]

/-- Evaluating `hsInner g V` for an empirical gradient `g = (1/n) • ∑ i, r_i ⊗ x_i^*`. -/
lemma hsInner_empGrad {n : ℕ} (x : Fin n → X) (ξ : Fin n → Y) (V : X →L[ℝ] Y) :
    let g : X →L[ℝ] Y := (1 / (n : ℝ)) • ∑ i : Fin n, (innerSL ℝ (x i)).smulRight (ξ i)
    hsInner g V = (1 / (n : ℝ)) * ∑ i : Fin n, inner ℝ (ξ i) (V (x i)) := by
  intro g
  have hadj_g : ∀ j : Fin (Module.finrank ℝ Y),
      adjVec g (stdOrthonormalBasis ℝ Y j) =
        (1 / (n : ℝ)) • ∑ i : Fin n, inner ℝ (ξ i) (stdOrthonormalBasis ℝ Y j) • x i := by
    intro j
    refine ext_inner_right ℝ fun v => ?_
    rw [inner_adjVec_left]
    change inner ℝ (stdOrthonormalBasis ℝ Y j)
        ((1 / (n : ℝ)) • (∑ i : Fin n, (innerSL ℝ (x i)).smulRight (ξ i)) v) =
      inner ℝ ((1 / (n : ℝ)) • ∑ i : Fin n, inner ℝ (ξ i) (stdOrthonormalBasis ℝ Y j) • x i) v
    rw [ContinuousLinearMap.sum_apply, inner_smul_right, inner_sum, inner_smul_left,
      conj_trivial, sum_inner]
    congr 1
    refine Finset.sum_congr rfl fun i _ => ?_
    change inner ℝ (stdOrthonormalBasis ℝ Y j) ((inner ℝ (x i) v) • ξ i) =
      inner ℝ (inner ℝ (ξ i) (stdOrthonormalBasis ℝ Y j) • x i) v
    rw [inner_smul_right, inner_smul_left, conj_trivial,
      real_inner_comm (stdOrthonormalBasis ℝ Y j) (ξ i)]
    ring
  unfold hsInner
  dsimp only
  simp_rw [hadj_g, inner_smul_left, conj_trivial, sum_inner]
  rw [← Finset.mul_sum, Finset.sum_comm]
  congr 1
  refine Finset.sum_congr rfl fun i _ => ?_
  conv_rhs => rw [← (stdOrthonormalBasis ℝ Y).sum_inner_mul_inner (ξ i) (V (x i))]
  refine Finset.sum_congr rfl fun j _ => ?_
  rw [inner_smul_left, conj_trivial, inner_adjVec_right V (stdOrthonormalBasis ℝ Y j) (x i),
    real_inner_comm (stdOrthonormalBasis ℝ Y j) (V (x i))]

/-- Empirical linear score difference bounded by `gamma_n`. -/
lemma empGrad_diff_le_gamma {n : ℕ} (x : Fin n → X) (ξ : Fin n → Y)
    {R : ℝ} (W V : X →L[ℝ] Y) (hV : UL.hilbertSchmidtNorm V ≤ R) :
    let g : X →L[ℝ] Y := (1 / (n : ℝ)) • ∑ i : Fin n, (innerSL ℝ (x i)).smulRight (ξ i)
    (1 / (n : ℝ)) * (∑ i : Fin n, inner ℝ (ξ i) (W (x i))) -
        (1 / (n : ℝ)) * (∑ i : Fin n, inner ℝ (ξ i) (V (x i))) ≤
      ((1 : ℝ) / 4) * (UL.hilbertSchmidtNorm (g + W) ^ 2 - UL.hilbertSchmidtNorm (g - W) ^ 2) +
        R * UL.hilbertSchmidtNorm g := by
  intro g
  rw [← hsInner_empGrad x ξ W, ← hsInner_empGrad x ξ V, hsInner_eq_polarization g W]
  have hcs := abs_hsInner_le g V
  have hneg : -hsInner g V ≤ |hsInner g V| := neg_le_abs _
  have hmul : UL.hilbertSchmidtNorm g * UL.hilbertSchmidtNorm V ≤
      R * UL.hilbertSchmidtNorm g := by
    rw [mul_comm R]
    exact mul_le_mul_of_nonneg_left hV (hilbertSchmidtNorm_nonneg g)
  linarith

/-! ### Isometric parameterization of sample-span operators -/

/-- Sample span `Submodule.span ℝ (Set.range x) ≤ X`. -/
def sampleSpan {n : ℕ} (x : Fin n → X) : Submodule ℝ X :=
  Submodule.span ℝ (Set.range x)

instance sampleSpan_finiteDimensional {n : ℕ} (x : Fin n → X) :
    FiniteDimensional ℝ (sampleSpan x) :=
  FiniteDimensional.span_of_finite ℝ (Set.finite_range x)

/-- Isometric operator embedding from `EuclideanSpace ℝ (Fin (d * m))` into `X →L[ℝ] Y`. -/
noncomputable def toSampleSpanOp {n : ℕ} (x : Fin n → X)
    (w : EuclideanSpace ℝ (Fin (Module.finrank ℝ (sampleSpan x) * Module.finrank ℝ Y))) :
    X →L[ℝ] Y :=
  let bE := stdOrthonormalBasis ℝ (sampleSpan x)
  let bY := stdOrthonormalBasis ℝ Y
  ∑ k : Fin (Module.finrank ℝ (sampleSpan x)),
    ∑ j : Fin (Module.finrank ℝ Y),
      w (finProdFinEquiv (k, j)) • (innerSL ℝ (bE k : X)).smulRight (bY j)

lemma toSampleSpanOp_vanishes_orth {n : ℕ} (x : Fin n → X)
    (w : EuclideanSpace ℝ (Fin (Module.finrank ℝ (sampleSpan x) * Module.finrank ℝ Y)))
    {v : X} (hv : v ∈ (sampleSpan x)ᗮ) :
    toSampleSpanOp x w v = 0 := by
  unfold toSampleSpanOp
  dsimp only
  simp only [ContinuousLinearMap.sum_apply, ContinuousLinearMap.smul_apply,
    ContinuousLinearMap.smulRight_apply, innerSL_apply_apply]
  refine Finset.sum_eq_zero fun k _ => Finset.sum_eq_zero fun j _ => ?_
  have hmem : ((stdOrthonormalBasis ℝ (sampleSpan x) k : sampleSpan x) : X) ∈ sampleSpan x :=
    (stdOrthonormalBasis ℝ (sampleSpan x) k).2
  have h0 : inner ℝ ((stdOrthonormalBasis ℝ (sampleSpan x) k : sampleSpan x) : X) v = 0 :=
    (Submodule.mem_orthogonal (sampleSpan x) v).mp hv _ hmem
  simp [h0]

lemma toSampleSpanOp_add {n : ℕ} (x : Fin n → X)
    (w₁ w₂ : EuclideanSpace ℝ (Fin (Module.finrank ℝ (sampleSpan x) * Module.finrank ℝ Y))) :
    toSampleSpanOp x (w₁ + w₂) = toSampleSpanOp x w₁ + toSampleSpanOp x w₂ := by
  unfold toSampleSpanOp
  dsimp only
  rw [← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun k _ => ?_
  rw [← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun j _ => ?_
  simp [add_smul]

lemma toSampleSpanOp_sub {n : ℕ} (x : Fin n → X)
    (w₁ w₂ : EuclideanSpace ℝ (Fin (Module.finrank ℝ (sampleSpan x) * Module.finrank ℝ Y))) :
    toSampleSpanOp x (w₁ - w₂) = toSampleSpanOp x w₁ - toSampleSpanOp x w₂ := by
  unfold toSampleSpanOp
  dsimp only
  rw [← Finset.sum_sub_distrib]
  refine Finset.sum_congr rfl fun k _ => ?_
  rw [← Finset.sum_sub_distrib]
  refine Finset.sum_congr rfl fun j _ => ?_
  simp [sub_smul]

private lemma adjVec_toSampleSpanOp {n : ℕ} (x : Fin n → X)
    (w : EuclideanSpace ℝ (Fin (Module.finrank ℝ (sampleSpan x) * Module.finrank ℝ Y)))
    (j₀ : Fin (Module.finrank ℝ Y)) :
    adjVec (toSampleSpanOp x w) (stdOrthonormalBasis ℝ Y j₀) =
      ∑ k : Fin (Module.finrank ℝ (sampleSpan x)),
        w (finProdFinEquiv (k, j₀)) • ((stdOrthonormalBasis ℝ (sampleSpan x) k : sampleSpan x) : X) := by
  let bE := stdOrthonormalBasis ℝ (sampleSpan x)
  let bY := stdOrthonormalBasis ℝ Y
  have hY_ite := orthonormal_iff_ite.mp bY.orthonormal
  refine ext_inner_right ℝ fun v => ?_
  rw [inner_adjVec_left]
  unfold toSampleSpanOp
  dsimp only
  simp only [ContinuousLinearMap.sum_apply, ContinuousLinearMap.smul_apply,
    ContinuousLinearMap.smulRight_apply, innerSL_apply_apply]
  rw [inner_sum, sum_inner]
  refine Finset.sum_congr rfl fun k _ => ?_
  rw [inner_sum, inner_smul_left, conj_trivial]
  have hsingle :
      ∑ j : Fin (Module.finrank ℝ Y),
          inner ℝ (bY j₀) (w (finProdFinEquiv (k, j)) • inner ℝ (bE k : X) v • bY j) =
        w (finProdFinEquiv (k, j₀)) * inner ℝ (bE k : X) v := by
    calc ∑ j : Fin (Module.finrank ℝ Y),
          inner ℝ (bY j₀) (w (finProdFinEquiv (k, j)) • inner ℝ (bE k : X) v • bY j)
        = ∑ j : Fin (Module.finrank ℝ Y),
            (if j = j₀ then w (finProdFinEquiv (k, j₀)) * inner ℝ (bE k : X) v else 0) := by
            refine Finset.sum_congr rfl fun j _ => ?_
            rw [inner_smul_right, inner_smul_right, hY_ite j₀ j]
            by_cases hjj : j = j₀
            · subst hjj; simp
            · have hne : j₀ ≠ j := fun h => hjj h.symm
              simp [hjj, hne]
      _ = w (finProdFinEquiv (k, j₀)) * inner ℝ (bE k : X) v := by simp
  exact hsingle

lemma hilbertSchmidtNorm_toSampleSpanOp_sq {n : ℕ} (x : Fin n → X)
    (w : EuclideanSpace ℝ (Fin (Module.finrank ℝ (sampleSpan x) * Module.finrank ℝ Y))) :
    UL.hilbertSchmidtNorm (toSampleSpanOp x w) ^ 2 = ‖w‖ ^ 2 := by
  have hE_ite := orthonormal_iff_ite.mp (stdOrthonormalBasis ℝ (sampleSpan x)).orthonormal
  rw [hilbertSchmidtNorm_sq, EuclideanSpace.norm_sq_eq]
  simp_rw [adjVec_toSampleSpanOp]
  have hterm : ∀ j₀ : Fin (Module.finrank ℝ Y),
      ‖∑ k : Fin (Module.finrank ℝ (sampleSpan x)),
          w (finProdFinEquiv (k, j₀)) •
            ((stdOrthonormalBasis ℝ (sampleSpan x) k : sampleSpan x) : X)‖ ^ 2 =
        ∑ k : Fin (Module.finrank ℝ (sampleSpan x)),
          ‖w (finProdFinEquiv (k, j₀))‖ ^ 2 := by
    intro j₀
    rw [← real_inner_self_eq_norm_sq, sum_inner]
    refine Finset.sum_congr rfl fun k₁ _ => ?_
    rw [inner_smul_left, inner_sum, conj_trivial]
    have h1 :
        ∑ k₂ : Fin (Module.finrank ℝ (sampleSpan x)),
            inner ℝ ((stdOrthonormalBasis ℝ (sampleSpan x) k₁ : sampleSpan x) : X)
              (w (finProdFinEquiv (k₂, j₀)) •
                ((stdOrthonormalBasis ℝ (sampleSpan x) k₂ : sampleSpan x) : X)) =
          w (finProdFinEquiv (k₁, j₀)) := by
      calc ∑ k₂ : Fin (Module.finrank ℝ (sampleSpan x)),
            inner ℝ ((stdOrthonormalBasis ℝ (sampleSpan x) k₁ : sampleSpan x) : X)
              (w (finProdFinEquiv (k₂, j₀)) •
                ((stdOrthonormalBasis ℝ (sampleSpan x) k₂ : sampleSpan x) : X))
          = ∑ k₂ : Fin (Module.finrank ℝ (sampleSpan x)),
              (if k₂ = k₁ then w (finProdFinEquiv (k₁, j₀)) else 0) := by
              refine Finset.sum_congr rfl fun k₂ _ => ?_
              rw [inner_smul_right]
              have horth :
                  inner ℝ ((stdOrthonormalBasis ℝ (sampleSpan x) k₁ : sampleSpan x) : X)
                    ((stdOrthonormalBasis ℝ (sampleSpan x) k₂ : sampleSpan x) : X) =
                    if k₁ = k₂ then 1 else 0 := hE_ite k₁ k₂
              rw [horth]
              by_cases hk : k₂ = k₁
              · subst hk; simp
              · have hne : k₁ ≠ k₂ := fun h => hk h.symm
                simp [hk, hne]
        _ = w (finProdFinEquiv (k₁, j₀)) := by simp
    rw [h1, Real.norm_eq_abs, sq_abs, sq]
  simp_rw [hterm]
  rw [Finset.sum_comm]
  rw [← Fintype.sum_prod_type' (fun k j => ‖w (finProdFinEquiv (k, j))‖ ^ 2)]
  exact finProdFinEquiv.sum_comp (fun idx => ‖w idx‖ ^ 2)

lemma hilbertSchmidtNorm_toSampleSpanOp {n : ℕ} (x : Fin n → X)
    (w : EuclideanSpace ℝ (Fin (Module.finrank ℝ (sampleSpan x) * Module.finrank ℝ Y))) :
    UL.hilbertSchmidtNorm (toSampleSpanOp x w) = ‖w‖ := by
  have hsq := hilbertSchmidtNorm_toSampleSpanOp_sq (Y := Y) x w
  have h1 := hilbertSchmidtNorm_nonneg (toSampleSpanOp (Y := Y) x w)
  have h2 := norm_nonneg w
  nlinarith

lemma continuous_toSampleSpanOp_eval {n : ℕ} (x : Fin n → X) :
    Continuous (fun (w : EuclideanSpace ℝ (Fin (Module.finrank ℝ (sampleSpan x) * Module.finrank ℝ Y)))
      (i : Fin n) => toSampleSpanOp x w (x i)) := by
  refine continuous_pi fun i => ?_
  unfold toSampleSpanOp
  dsimp only
  simp only [ContinuousLinearMap.sum_apply, ContinuousLinearMap.smul_apply,
    ContinuousLinearMap.smulRight_apply, innerSL_apply_apply]
  refine continuous_finset_sum _ fun k _ => continuous_finset_sum _ fun j _ => ?_
  exact ((PiLp.continuous_apply 2 _ (finProdFinEquiv (k, j))).smul continuous_const)

/-- Coordinate vector of empirical gradient `g = (1/n) • ∑ i, r_i ⊗ x_i^*` in `toSampleSpanOp`. -/
noncomputable def empGradVec {n : ℕ} (x : Fin n → X) (ξ : Fin n → Y) :
    EuclideanSpace ℝ (Fin (Module.finrank ℝ (sampleSpan x) * Module.finrank ℝ Y)) :=
  let bE := stdOrthonormalBasis ℝ (sampleSpan x)
  let bY := stdOrthonormalBasis ℝ Y
  (WithLp.equiv 2 _).symm fun idx =>
    let kj := finProdFinEquiv.symm idx
    (1 / (n : ℝ)) * ∑ i : Fin n, inner ℝ ((bE kj.1 : sampleSpan x) : X) (x i) * inner ℝ (ξ i) (bY kj.2)

lemma toSampleSpanOp_empGradVec {n : ℕ} (x : Fin n → X) (ξ : Fin n → Y) :
    toSampleSpanOp x (empGradVec x ξ) =
      (1 / (n : ℝ)) • ∑ i : Fin n, (innerSL ℝ (x i)).smulRight (ξ i) := by
  let bE := stdOrthonormalBasis ℝ (sampleSpan x)
  let bY := stdOrthonormalBasis ℝ Y
  ext v
  refine ext_inner_right ℝ fun y => ?_
  unfold toSampleSpanOp empGradVec
  dsimp only
  simp only [ContinuousLinearMap.sum_apply, ContinuousLinearMap.smul_apply,
    ContinuousLinearMap.smulRight_apply, innerSL_apply_apply, WithLp.equiv_symm_apply,
    finProdFinEquiv.symm_apply_apply]
  have hr_exp : ∀ i : Fin n,
      inner ℝ (ξ i) y = ∑ j : Fin (Module.finrank ℝ Y), inner ℝ (ξ i) (bY j) * inner ℝ (bY j) y :=
    fun i => (bY.sum_inner_mul_inner (ξ i) y).symm
  have hx_exp : ∀ i : Fin n,
      inner ℝ (x i) v = ∑ k : Fin (Module.finrank ℝ (sampleSpan x)),
        inner ℝ ((bE k : sampleSpan x) : X) (x i) * inner ℝ ((bE k : sampleSpan x) : X) v := by
    intro i
    let xiF : sampleSpan x := ⟨x i, Submodule.subset_span ⟨i, rfl⟩⟩
    have hxi_sub : xiF = ∑ k : Fin (Module.finrank ℝ (sampleSpan x)),
        inner ℝ (bE k) xiF • bE k := by
      refine ext_inner_right ℝ fun u => ?_
      rw [sum_inner, ← bE.sum_inner_mul_inner xiF u]
      refine Finset.sum_congr rfl fun k _ => ?_
      rw [inner_smul_left, conj_trivial, real_inner_comm xiF (bE k)]
    have hxi : x i = ∑ k : Fin (Module.finrank ℝ (sampleSpan x)),
        inner ℝ (bE k) xiF • ((bE k : sampleSpan x) : X) := by
      have hcoe := congrArg (Subtype.val : sampleSpan x → X) hxi_sub
      simpa only [Submodule.coe_sum, Submodule.coe_smul_of_tower] using hcoe
    conv_lhs => rw [hxi]
    rw [sum_inner]
    refine Finset.sum_congr rfl fun k _ => ?_
    rw [inner_smul_left, conj_trivial]
    rfl
  have h_lhs_eq :
      inner ℝ
          (∑ k : Fin (Module.finrank ℝ (sampleSpan x)),
            ∑ j : Fin (Module.finrank ℝ Y),
              ((1 / (n : ℝ)) *
                ∑ i : Fin n, inner ℝ ((bE k : sampleSpan x) : X) (x i) * inner ℝ (ξ i) (bY j)) •
                inner ℝ ((bE k : sampleSpan x) : X) v • bY j) y =
        ∑ k : Fin (Module.finrank ℝ (sampleSpan x)),
          ∑ j : Fin (Module.finrank ℝ Y),
            ∑ i : Fin n,
              (1 / (n : ℝ)) *
                (inner ℝ ((bE k : sampleSpan x) : X) (x i) * inner ℝ ((bE k : sampleSpan x) : X) v) *
                (inner ℝ (ξ i) (bY j) * inner ℝ (bY j) y) := by
    rw [sum_inner]
    refine Finset.sum_congr rfl fun k _ => ?_
    rw [sum_inner]
    refine Finset.sum_congr rfl fun j _ => ?_
    rw [inner_smul_left, inner_smul_left, conj_trivial, conj_trivial]
    have h_inner_dist :
        (1 / (n : ℝ)) *
            (∑ i : Fin n, inner ℝ ((bE k : sampleSpan x) : X) (x i) * inner ℝ (ξ i) (bY j)) *
            (inner ℝ ((bE k : sampleSpan x) : X) v * inner ℝ (bY j) y) =
          ((1 / (n : ℝ)) *
            ∑ i : Fin n, inner ℝ ((bE k : sampleSpan x) : X) (x i) * inner ℝ (ξ i) (bY j)) *
            (inner ℝ ((bE k : sampleSpan x) : X) v * inner ℝ (bY j) y) := rfl
    rw [h_inner_dist, Finset.mul_sum, Finset.sum_mul]
    refine Finset.sum_congr rfl fun i _ => by ring
  have h_rhs_eq :
      inner ℝ ((1 / (n : ℝ)) • ∑ i : Fin n, inner ℝ (x i) v • ξ i) y =
        ∑ i : Fin n,
          ∑ k : Fin (Module.finrank ℝ (sampleSpan x)),
            ∑ j : Fin (Module.finrank ℝ Y),
              (1 / (n : ℝ)) *
                (inner ℝ ((bE k : sampleSpan x) : X) (x i) * inner ℝ ((bE k : sampleSpan x) : X) v) *
                (inner ℝ (ξ i) (bY j) * inner ℝ (bY j) y) := by
    rw [inner_smul_left, conj_trivial, sum_inner, Finset.mul_sum]
    refine Finset.sum_congr rfl fun i _ => ?_
    rw [inner_smul_left, conj_trivial, hx_exp i, hr_exp i]
    have h_step1 :
        (1 / (n : ℝ)) *
            ((∑ k : Fin (Module.finrank ℝ (sampleSpan x)),
                inner ℝ ((bE k : sampleSpan x) : X) (x i) * inner ℝ ((bE k : sampleSpan x) : X) v) *
              ∑ j : Fin (Module.finrank ℝ Y), inner ℝ (ξ i) (bY j) * inner ℝ (bY j) y) =
          ∑ k : Fin (Module.finrank ℝ (sampleSpan x)),
            (1 / (n : ℝ)) *
              (inner ℝ ((bE k : sampleSpan x) : X) (x i) * inner ℝ ((bE k : sampleSpan x) : X) v) *
              (∑ j : Fin (Module.finrank ℝ Y), inner ℝ (ξ i) (bY j) * inner ℝ (bY j) y) := by
      rw [Finset.sum_mul, Finset.mul_sum]
      refine Finset.sum_congr rfl fun k _ => by ring
    rw [h_step1]
    refine Finset.sum_congr rfl fun k _ => ?_
    rw [Finset.mul_sum]
  rw [h_lhs_eq, h_rhs_eq]
  calc ∑ k : Fin (Module.finrank ℝ (sampleSpan x)),
        ∑ j : Fin (Module.finrank ℝ Y),
          ∑ i : Fin n,
            (1 / (n : ℝ)) *
              (inner ℝ ((bE k : sampleSpan x) : X) (x i) * inner ℝ ((bE k : sampleSpan x) : X) v) *
              (inner ℝ (ξ i) (bY j) * inner ℝ (bY j) y)
      = ∑ k : Fin (Module.finrank ℝ (sampleSpan x)),
          ∑ i : Fin n,
            ∑ j : Fin (Module.finrank ℝ Y),
              (1 / (n : ℝ)) *
                (inner ℝ ((bE k : sampleSpan x) : X) (x i) * inner ℝ ((bE k : sampleSpan x) : X) v) *
                (inner ℝ (ξ i) (bY j) * inner ℝ (bY j) y) :=
        Finset.sum_congr rfl fun _ _ => Finset.sum_comm
    _ = ∑ i : Fin n,
          ∑ k : Fin (Module.finrank ℝ (sampleSpan x)),
            ∑ j : Fin (Module.finrank ℝ Y),
              (1 / (n : ℝ)) *
                (inner ℝ ((bE k : sampleSpan x) : X) (x i) * inner ℝ ((bE k : sampleSpan x) : X) v) *
                (inner ℝ (ξ i) (bY j) * inner ℝ (bY j) y) :=
        Finset.sum_comm

private lemma sum_apply_eucl {M : ℕ} {α : Type*} (s : Finset α)
    (f : α → EuclideanSpace ℝ (Fin M)) (j : Fin M) :
    (∑ a ∈ s, f a) j = ∑ a ∈ s, f a j := by
  classical
  induction s using Finset.induction_on with
  | empty => rfl
  | @insert a s ha ih => simp [Finset.sum_insert ha, ih]

lemma continuous_empGradVec {n : ℕ} (x : Fin n → X) (Z : Fin n → Y) :
    Continuous (fun P : Fin n → Y => empGradVec x (fun i => P i - Z i)) := by
  let N := Module.finrank ℝ (sampleSpan x) * Module.finrank ℝ Y
  have h_eq : (fun P : Fin n → Y => empGradVec x (fun i => P i - Z i)) =
      fun P : Fin n → Y =>
        ∑ idx : Fin N,
          ((empGradVec x (fun i => P i - Z i)) idx) • EuclideanSpace.single idx (1 : ℝ) := by
    funext P
    ext j
    rw [sum_apply_eucl]
    simp [EuclideanSpace.single_apply]
  rw [h_eq]
  refine continuous_finset_sum _ fun idx _ => ?_
  refine Continuous.smul ?_ continuous_const
  unfold empGradVec
  dsimp only
  simp only [WithLp.equiv_symm_apply]
  refine continuous_const.mul (continuous_finset_sum _ fun i _ => ?_)
  exact continuous_const.mul (((continuous_apply i).sub continuous_const).inner continuous_const)

lemma gamma_toSampleSpanOp_eq {n : ℕ} (x : Fin n → X) (ξ : Fin n → Y) (R : ℝ)
    (w : EuclideanSpace ℝ (Fin (Module.finrank ℝ (sampleSpan x) * Module.finrank ℝ Y))) :
    let g : X →L[ℝ] Y := (1 / (n : ℝ)) • ∑ i : Fin n, (innerSL ℝ (x i)).smulRight (ξ i)
    let W : X →L[ℝ] Y := toSampleSpanOp x w
    ((1 : ℝ) / 4) * (UL.hilbertSchmidtNorm (g + W) ^ 2 - UL.hilbertSchmidtNorm (g - W) ^ 2) +
        R * UL.hilbertSchmidtNorm g =
      inner ℝ (empGradVec x ξ) w + R * ‖empGradVec x ξ‖ := by
  intro g W
  have hg : g = toSampleSpanOp x (empGradVec x ξ) := (toSampleSpanOp_empGradVec x ξ).symm
  have hgw_add : g + W = toSampleSpanOp x (empGradVec x ξ + w) := by
    dsimp [W]; rw [hg, ← toSampleSpanOp_add]
  have hgw_sub : g - W = toSampleSpanOp x (empGradVec x ξ - w) := by
    dsimp [W]; rw [hg, ← toSampleSpanOp_sub]
  rw [hgw_add, hgw_sub, hilbertSchmidtNorm_toSampleSpanOp_sq, hilbertSchmidtNorm_toSampleSpanOp_sq,
    hg, hilbertSchmidtNorm_toSampleSpanOp, norm_add_sq_real, norm_sub_sq_real]
  ring

end HilbertSchmidt

end UL.Proof_lem_C_2

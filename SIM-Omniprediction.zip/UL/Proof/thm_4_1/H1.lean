import Mathlib
import UL.Stmt.thm_4_1
import UL.Stmt.thm_A_9
set_option autoImplicit false

namespace UL.Proof_thm_4_1

open UL

noncomputable def innerCompBilin {K : ℕ}
    (M : EuclideanSpace ℝ (Fin K) →ₗ[ℝ] EuclideanSpace ℝ (Fin K)) :
    EuclideanSpace ℝ (Fin K) →ₗ[ℝ] EuclideanSpace ℝ (Fin K) →ₗ[ℝ] ℝ where
  toFun x := (innerSL ℝ x).toLinearMap.comp M
  map_add' x₁ x₂ := by
    ext y
    simp [inner_add_left]
  map_smul' r x := by
    ext y
    simp [inner_smul_left]

lemma quadratic_decomp {K : ℕ} (Φ : Simplex K → ℝ)
    (M : EuclideanSpace ℝ (Fin K) →ₗ[ℝ] EuclideanSpace ℝ (Fin K))
    (b : EuclideanSpace ℝ (Fin K)) (c₀ : ℝ)
    (hΦ : ∀ q : Simplex K,
      Φ q = inner ℝ (q : EuclideanSpace ℝ (Fin K)) (M (q : EuclideanSpace ℝ (Fin K))) +
        inner ℝ b (q : EuclideanSpace ℝ (Fin K)) + c₀) :
    ∃ (Q : QuadraticForm ℝ (EuclideanSpace ℝ (Fin K)))
      (ℓ : EuclideanSpace ℝ (Fin K) →ₗ[ℝ] ℝ) (c₀' : ℝ),
      ∀ q : Simplex K,
        Φ q = Q (q : EuclideanSpace ℝ (Fin K)) + ℓ (q : EuclideanSpace ℝ (Fin K)) + c₀' := by
  refine ⟨LinearMap.BilinMap.toQuadraticMap (innerCompBilin M),
    (innerSL ℝ b).toLinearMap, c₀, ?_⟩
  intro q
  simpa [LinearMap.BilinMap.toQuadraticMap_apply, innerCompBilin] using hΦ q

lemma finrank_zeroSumSubspace (K : ℕ) (hK : 2 ≤ K) :
    Module.finrank ℝ (ZeroSumSubspace K) = K - 1 := by
  let φ : EuclideanSpace ℝ (Fin K) →ₗ[ℝ] ℝ := (innerSL ℝ (onesVec K)).toLinearMap
  have hker : ZeroSumSubspace K = LinearMap.ker φ := rfl
  have hne : onesVec K ≠ 0 := by
    intro h
    have h0 : (onesVec K) ⟨0, by omega⟩ = (0 : EuclideanSpace ℝ (Fin K)) ⟨0, by omega⟩ :=
      congrArg (fun v => v ⟨0, by omega⟩) h
    simp [onesVec] at h0
  have hc₀ : φ (onesVec K) ≠ 0 := by
    simp [φ, inner_self_eq_zero, hne]
  have hsurj : Function.Surjective φ := fun r =>
    ⟨(r / φ (onesVec K)) • onesVec K, by simp [map_smul, smul_eq_mul, div_mul_cancel₀ _ hc₀]⟩
  have hrange : LinearMap.range φ = ⊤ := LinearMap.range_eq_top.mpr hsurj
  have hrk := LinearMap.finrank_range_add_finrank_ker φ
  rw [hrange, finrank_top, Module.finrank_self, finrank_euclideanSpace_fin, ← hker] at hrk
  omega

noncomputable def coordInclLinear {k m : ℕ} (hkm : k ≤ m) :
    EuclideanSpace ℝ (Fin k) →ₗ[ℝ] EuclideanSpace ℝ (Fin m) where
  toFun y := WithLp.toLp 2 (fun i : Fin m => if hi : i.1 < k then y.ofLp ⟨i.1, hi⟩ else 0)
  map_add' y₁ y₂ := by
    ext i
    change (if hi : i.1 < k then (y₁ + y₂).ofLp ⟨i.1, hi⟩ else 0) =
      (if hi : i.1 < k then y₁.ofLp ⟨i.1, hi⟩ else 0) +
        (if hi : i.1 < k then y₂.ofLp ⟨i.1, hi⟩ else 0)
    by_cases hi : i.1 < k <;> simp [hi]
  map_smul' r y := by
    ext i
    change (if hi : i.1 < k then (r • y).ofLp ⟨i.1, hi⟩ else 0) =
      r * (if hi : i.1 < k then y.ofLp ⟨i.1, hi⟩ else 0)
    by_cases hi : i.1 < k <;> simp [hi]

@[simp]
lemma coordInclLinear_ofLp {k m : ℕ} (hkm : k ≤ m) (y : EuclideanSpace ℝ (Fin k)) (i : Fin m) :
    (coordInclLinear hkm y).ofLp i = if hi : i.1 < k then y.ofLp ⟨i.1, hi⟩ else 0 := rfl

noncomputable def coordIncl {k m : ℕ} (hkm : k ≤ m) :
    EuclideanSpace ℝ (Fin k) →ₗᵢ[ℝ] EuclideanSpace ℝ (Fin m) where
  toLinearMap := coordInclLinear hkm
  norm_map' y := by
    rw [EuclideanSpace.norm_eq, EuclideanSpace.norm_eq]
    congr 1
    let emb : Fin k ↪ Fin m := Fin.castLEEmb hkm
    have hsub : (∑ i : Fin m, ‖(coordInclLinear hkm y).ofLp i‖ ^ 2) =
        ∑ i ∈ Finset.univ.map emb, ‖(coordInclLinear hkm y).ofLp i‖ ^ 2 := by
      symm
      refine Finset.sum_subset (Finset.subset_univ _) ?_
      intro i _ hi
      have hnot : ¬ i.1 < k := by
        intro hlt
        apply hi
        rw [Finset.mem_map]
        exact ⟨⟨i.1, hlt⟩, Finset.mem_univ _, rfl⟩
      simp [hnot]
    rw [hsub, Finset.sum_map]
    refine Finset.sum_congr rfl fun j _ => ?_
    simp [emb]

noncomputable def coordProj {k m : ℕ} (hkm : k ≤ m) :
    EuclideanSpace ℝ (Fin m) →ₗ[ℝ] EuclideanSpace ℝ (Fin k) where
  toFun z := WithLp.toLp 2 (fun j : Fin k => z.ofLp (Fin.castLE hkm j))
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

@[simp]
lemma coordProj_ofLp {k m : ℕ} (hkm : k ≤ m) (z : EuclideanSpace ℝ (Fin m)) (j : Fin k) :
    (coordProj hkm z).ofLp j = z.ofLp (Fin.castLE hkm j) := rfl

lemma coordProj_coordIncl {k m : ℕ} (hkm : k ≤ m) (y : EuclideanSpace ℝ (Fin k)) :
    coordProj hkm (coordIncl hkm y) = y := by
  ext j
  have hj : (Fin.castLE hkm j).1 < k := j.2
  simp [coordIncl, hj]

lemma norm_coordProj_le {k m : ℕ} (hkm : k ≤ m) (z : EuclideanSpace ℝ (Fin m)) :
    ‖coordProj hkm z‖ ≤ ‖z‖ := by
  rw [EuclideanSpace.norm_eq, EuclideanSpace.norm_eq]
  apply Real.sqrt_le_sqrt
  let emb : Fin k ↪ Fin m := Fin.castLEEmb hkm
  have hmap : (∑ j : Fin k, ‖(coordProj hkm z).ofLp j‖ ^ 2) =
      ∑ i ∈ Finset.univ.map emb, ‖z.ofLp i‖ ^ 2 := by
    rw [Finset.sum_map]
    rfl
  rw [hmap]
  exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _) fun _ _ _ => sq_nonneg _

lemma feasible_to_rank {K r k : ℕ} (hK : 2 ≤ K) (hr : r ≤ K - 1) (hk : k ≤ r)
    {R B : ℝ}
    (A : EuclideanSpace ℝ (Fin (K - 1)) →ₗ[ℝ] EuclideanSpace ℝ (Fin k))
    (h : EuclideanSpace ℝ (Fin k) → Simplex K)
    (hA : frobeniusNorm A ≤ R)
    (hh : LipschitzWith (Real.toNNReal B) h) :
    ∃ (W : EuclideanSpace ℝ (Fin (K - 1)) →ₗ[ℝ] ZeroSumSubspace K)
      (ρ : ZeroSumSubspace K → Simplex K),
      Module.finrank ℝ (LinearMap.range W) ≤ r ∧
      frobeniusNorm W ≤ R ∧
      LipschitzWith (Real.toNNReal B) ρ ∧
      ∀ x : EuclideanSpace ℝ (Fin (K - 1)), ρ (W x) = h (A x) := by
  have hm_dim : Module.finrank ℝ (ZeroSumSubspace K) = K - 1 := finrank_zeroSumSubspace K hK
  let b_H : OrthonormalBasis (Fin (K - 1)) ℝ (ZeroSumSubspace K) :=
    (stdOrthonormalBasis ℝ (ZeroSumSubspace K)).reindex (finCongr hm_dim)
  let e_H : ZeroSumSubspace K ≃ₗᵢ[ℝ] EuclideanSpace ℝ (Fin (K - 1)) := b_H.repr
  have hkm : k ≤ K - 1 := le_trans hk hr
  let Q₀ : EuclideanSpace ℝ (Fin k) →ₗᵢ[ℝ] ZeroSumSubspace K :=
    e_H.symm.toLinearIsometry.comp (coordIncl hkm)
  let P₀ : ZeroSumSubspace K →ₗ[ℝ] EuclideanSpace ℝ (Fin k) :=
    (coordProj hkm).comp e_H.toLinearIsometry.toLinearMap
  let W : EuclideanSpace ℝ (Fin (K - 1)) →ₗ[ℝ] ZeroSumSubspace K :=
    Q₀.toLinearMap.comp A
  let ρ : ZeroSumSubspace K → Simplex K := h ∘ P₀
  refine ⟨W, ρ, ?_, ?_, ?_, ?_⟩
  · have hsub : LinearMap.range W ≤ LinearMap.range Q₀.toLinearMap := by
      rintro _ ⟨x, rfl⟩
      exact ⟨A x, rfl⟩
    have h1 : Module.finrank ℝ (LinearMap.range W) ≤
        Module.finrank ℝ (LinearMap.range Q₀.toLinearMap) :=
      Submodule.finrank_mono hsub
    have h2 : Module.finrank ℝ (LinearMap.range Q₀.toLinearMap) ≤
        Module.finrank ℝ (EuclideanSpace ℝ (Fin k)) :=
      LinearMap.finrank_range_le Q₀.toLinearMap
    rw [finrank_euclideanSpace_fin] at h2
    exact le_trans h1 (le_trans h2 hk)
  · have hfrob : frobeniusNorm W = frobeniusNorm A := by
      simp [frobeniusNorm, W, Q₀.norm_map]
    exact hfrob ▸ hA
  · have hP₀_lip : LipschitzWith 1 P₀ := by
      refine LipschitzWith.of_dist_le_mul fun u v => ?_
      rw [NNReal.coe_one, one_mul, dist_eq_norm, dist_eq_norm, ← map_sub]
      exact (norm_coordProj_le hkm (e_H (u - v))).trans_eq (e_H.norm_map (u - v))
    simpa [ρ] using hh.comp hP₀_lip
  · intro x
    change h (coordProj hkm (e_H (e_H.symm (coordIncl hkm (A x))))) = h (A x)
    rw [e_H.apply_symm_apply, coordProj_coordIncl]

lemma rank_to_feasible {K m r : ℕ} {R B : ℝ}
    (W : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] ZeroSumSubspace K)
    (ρ : ZeroSumSubspace K → Simplex K)
    (hW_rk : Module.finrank ℝ (LinearMap.range W) ≤ r)
    (hW_frob : frobeniusNorm W ≤ R)
    (hρ_lip : LipschitzWith (Real.toNNReal B) ρ) :
    ∃ (k : ℕ), k ≤ r ∧
      ∃ (A : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] EuclideanSpace ℝ (Fin k))
        (h : EuclideanSpace ℝ (Fin k) → Simplex K),
        frobeniusNorm A ≤ R ∧
        LipschitzWith (Real.toNNReal B) h ∧
        ∀ x : EuclideanSpace ℝ (Fin m), (ρ ∘ W) x = h (A x) := by
  let S : Submodule ℝ (ZeroSumSubspace K) := LinearMap.range W
  let k : ℕ := Module.finrank ℝ S
  let b_S : OrthonormalBasis (Fin k) ℝ S := stdOrthonormalBasis ℝ S
  let e_S : S ≃ₗᵢ[ℝ] EuclideanSpace ℝ (Fin k) := b_S.repr
  let A : EuclideanSpace ℝ (Fin m) →ₗ[ℝ] EuclideanSpace ℝ (Fin k) :=
    e_S.toLinearIsometry.toLinearMap.comp W.rangeRestrict
  let ι_S : EuclideanSpace ℝ (Fin k) →ₗᵢ[ℝ] ZeroSumSubspace K :=
    S.subtypeₗᵢ.comp e_S.symm.toLinearIsometry
  let h : EuclideanSpace ℝ (Fin k) → Simplex K := ρ ∘ ι_S
  refine ⟨k, hW_rk, A, h, ?_, ?_, ?_⟩
  · have hfrob : frobeniusNorm A = frobeniusNorm W := by
      unfold frobeniusNorm
      congr 1
      refine Finset.sum_congr rfl fun i _ => ?_
      have hn : ‖A (EuclideanSpace.single i 1)‖ = ‖W (EuclideanSpace.single i 1)‖ := by
        change ‖e_S (W.rangeRestrict (EuclideanSpace.single i 1))‖ = ‖W (EuclideanSpace.single i 1)‖
        rw [e_S.norm_map]
        rfl
      rw [hn]
    exact hfrob ▸ hW_frob
  · simpa [h] using hρ_lip.comp ι_S.isometry.lipschitz
  · intro x
    change ρ (W x) = ρ (S.subtypeₗᵢ (e_S.symm (e_S (W.rangeRestrict x))))
    rw [e_S.symm_apply_apply]
    rfl

end UL.Proof_thm_4_1

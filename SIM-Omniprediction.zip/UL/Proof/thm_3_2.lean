import UL.Stmt.thm_3_2
import UL.Stmt.cit_brouwer
import UL.Proof.thm_3_2.H1_Fit
import UL.Proof.thm_3_2.H2_Perturb
import UL.Proof.thm_3_2.H3_LossFixedPoint
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_thm_3_2 (h_cit_brouwer : S_cit_brouwer) : S_thm_3_2 := by
  let _ := h_cit_brouwer
  unfold S_thm_3_2
  intro d Ω _ μ _ X Y hX_meas hY_meas R β hR hβ hX_int
  obtain ⟨ρ_fam, h_opt, h_vi, _, h_cont_g⟩ :=
    Proof_thm_3_2.exists_optProfile_and_continuous_drift
      d Ω μ X Y hX_meas hY_meas β hβ hX_int
  let g : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d) :=
    fun w => ∫ ω, (ρ_fam w (inner ℝ w (X ω)) - Proof_thm_3_2.yReal (Y ω)) • X ω ∂μ
  obtain ⟨w, hw_norm, hw_fp⟩ :=
    Proof_thm_3_2.exists_fixed_point_score d R hR g h_cont_g
  let ρ : ℝ → ℝ := ρ_fam w
  have hρ : Proof_thm_3_2.IsProfile β ρ := (h_opt w).1
  let P : Ω → ℝ := fun ω => ρ (inner ℝ w (X ω))
  have hSw_meas : Measurable (fun ω => inner ℝ w (X ω)) :=
    (continuous_const.inner continuous_id).measurable.comp hX_meas
  have hP_meas : Measurable P := hρ.measurable.comp hSw_meas
  have hP_mem : ∀ ω : Ω, P ω ∈ Set.Icc (0 : ℝ) 1 := fun ω => hρ.2.2 _
  have h_end := Proof_thm_3_2.ae_endpoint_support
    d Ω μ X Y hX_meas hY_meas β hβ w ρ hρ (h_vi w)
  have h_own := Proof_thm_3_2.own_score_ineq
    d Ω μ X Y hX_meas hY_meas β hβ hX_int w ρ hρ (h_vi w)
  have h_conv := fun F hFc hFcv hFd =>
    Proof_thm_3_2.convex_test_ineq
      d Ω μ X Y hX_meas hY_meas β hβ w ρ hρ (h_vi w) F hFc hFcv hFd
  have h_fp_int : ∀ v : EuclideanSpace ℝ (Fin d), ‖v‖ ≤ R →
      ∫ ω, Proof_thm_3_2.fitRes P Y ω * inner ℝ w (X ω) ∂μ ≤
        ∫ ω, Proof_thm_3_2.fitRes P Y ω * inner ℝ v (X ω) ∂μ := by
    intro v hv
    have h_le := hw_fp v hv
    have heq_v := Proof_thm_3_2.inner_drift_eq
      d Ω μ X Y hX_meas hY_meas hX_int P hP_meas hP_mem v
    have heq_w := Proof_thm_3_2.inner_drift_eq
      d Ω μ X Y hX_meas hY_meas hX_int P hP_meas hP_mem w
    change inner ℝ w (g w) ≤ inner ℝ v (g w) at h_le
    dsimp [g] at h_le
    linarith
  refine ⟨w, ρ, hw_norm, hρ.1, hρ.2.1, hρ.2.2, h_end, ?_⟩
  exact Proof_thm_3_2.entropy_loss_comparison
    d Ω μ X Y hX_meas hY_meas R β hR hβ hX_int
    w P hP_meas hP_mem h_end h_own h_fp_int h_conv

end UL

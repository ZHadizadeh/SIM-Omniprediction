import UL.Proof.cor_C_7.UniformTransfer
set_option autoImplicit false

namespace UL

/-- The two statistical conclusions of arXiv Corollary D.5. -/
theorem P_cor_C_7 (h_lem_C_2 : S_lem_C_2) (h_lem_C_3 : S_lem_C_3)
    (h_lem_C_4 : S_lem_C_4) : S_cor_C_7 := by
  unfold S_cor_C_7
  refine ⟨Proof_cor_C_7.cSamp (Proof_cor_C_7.chooseC3 h_lem_C_3),
    fun K _ => Proof_cor_C_7.one_le_cSamp _ K, ?_⟩
  intro K hK m C_K logMatchingLoss L R β lam M T_min T_max
    hL hR hβ hlam hM _hFam_ne hTmin_pos hTmin_le hTmin_lb
    A₀ D₀ τ_of D_τ_of sampleBound
  have hTmax_pos : 0 < T_max := lt_of_lt_of_le hTmin_pos hTmin_le
  constructor
  · -- Part A: Non-asymptotic polylogarithmic rate bound on `sampleBound ε δ`
    intro δ hδ0 hδ1
    exact Proof_cor_C_7.sampleBound_rate_bound K hK C_K
      (Proof_cor_C_7.one_le_cSamp _ K) L R β lam M T_max
      hL hR hβ hlam hM hTmax_pos δ hδ0 hδ1
  · -- Part B: General separable Borel Hilbert space joint PAC learning guarantee
    intro X _instNACG _instIPS _instCS _instSep _instMS _instBS
      ε δ hδ0 hδ1 hε0 hεD₀ τ n hn hn_ge
    exact Proof_cor_C_7.partB_joint_learner h_lem_C_2 h_lem_C_4 hK
      (Proof_cor_C_7.chooseC3_pos h_lem_C_3 K)
      (Proof_cor_C_7.lem_C_3_univ h_lem_C_3 hK)
      hL hR hβ hlam hM hTmin_pos hTmin_le hTmin_lb X hδ0 hδ1 hε0 hεD₀ n hn hn_ge

end UL

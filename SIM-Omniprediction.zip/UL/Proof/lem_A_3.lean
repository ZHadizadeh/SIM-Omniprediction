import UL.Stmt.lem_A_3
import UL.Stmt.lem_A_2
import UL.Proof.lem_A_3.H2_FitVI
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_lem_A_3 (h_lem_A_2 : S_lem_A_2) : S_lem_A_3 := by
  let _ := h_lem_A_2
  unfold S_lem_A_3
  intro Ω _ μ _ K hK B hB S Y hS_meas hY_meas P hFit
  exact ⟨Proof_lem_A_3.support_ae μ hK hB hS_meas hY_meas hFit,
    fun v hv => Proof_lem_A_3.face_derivative μ hK hB hS_meas hY_meas hFit v hv⟩

end UL

import Mathlib
import UL.Def.def_2_1
import UL.Def.def_2_matching
import UL.Def.def_5_smooth
import UL.Def.def_7_dirichlet
import UL.Def.def_A_fit
import UL.Def.def_A_gap
import UL.Proof.lem_A_3.H1_SimplexProj
import UL.Proof.lem_A_6.H1_FitAndTransfer
import UL.Proof.lem_C_2.H1_HilbertSchmidt
set_option autoImplicit false

namespace UL.Proof_thm_7_1

open UL

/-! ### Flattened index equivalence check -/

lemma finProdFinEquiv_val {m n : ℕ} (a : Fin m) (b : Fin n) :
    (finProdFinEquiv (a, b)).1 = b.1 + n * a.1 := rfl

/-! ### Centered simplex `CSet K = Δ_K - u ⊂ ZeroSumSubspace K` and metric projection `projCDef` -/

/-- Centered probability simplex `{z ∈ H | z + u ∈ Δ_K}`, matching `C_set` in `S_thm_7_1` by `rfl`. -/
def CSet (K : ℕ) : Set (ZeroSumSubspace K) :=
  {z | (z : EuclideanSpace ℝ (Fin K)) + uniformVec K ∈ Simplex K}

/-- Metric projection onto `CSet K`, matching `projC` in `S_thm_7_1` by `rfl`. -/
noncomputable def projCDef (K : ℕ) : ZeroSumSubspace K → ZeroSumSubspace K :=
  open Classical in
  fun v =>
    if h : ∃ z ∈ CSet K, IsMinOn (fun z' => ‖v - z'‖) (CSet K) z then
      Classical.choose h
    else 0

/-- Centered one-hot label `e_y - u ∈ ZeroSumSubspace K`. -/
noncomputable def centeredLabel {K : ℕ} (y : Fin K) : ZeroSumSubspace K :=
  ⟨oneHotVec y - uniformVec K,
    UL.Proof_lem_A_6.sub_mem_zeroSumSubspace_of_mem_simplex
      (UL.Proof_lem_A_6.oneHotVec_mem_simplex y)
      (UL.Proof_lem_A_6.uniformVec_mem_simplex (Nat.succ_le_of_lt (Nat.zero_le y.1 |>.trans_lt y.2)))⟩

@[simp]
lemma coe_centeredLabel {K : ℕ} (y : Fin K) :
    (centeredLabel y : EuclideanSpace ℝ (Fin K)) = oneHotVec y - uniformVec K := rfl

lemma centeredLabel_mem_CSet {K : ℕ} (y : Fin K) : centeredLabel y ∈ CSet K := by
  change (oneHotVec y - uniformVec K) + uniformVec K ∈ Simplex K
  rw [sub_add_cancel]
  exact UL.Proof_lem_A_6.oneHotVec_mem_simplex y

lemma zero_mem_CSet {K : ℕ} (hK : 1 ≤ K) : (0 : ZeroSumSubspace K) ∈ CSet K := by
  change (0 : EuclideanSpace ℝ (Fin K)) + uniformVec K ∈ Simplex K
  rw [zero_add]
  exact UL.Proof_lem_A_6.uniformVec_mem_simplex hK

lemma norm_le_one_of_mem_CSet {K : ℕ} {z : ZeroSumSubspace K} (hz : z ∈ CSet K) :
    ‖z‖ ≤ 1 := by
  have hq : (z : EuclideanSpace ℝ (Fin K)) + uniformVec K ∈ Simplex K := hz
  have hq_norm : ‖(z : EuclideanSpace ℝ (Fin K)) + uniformVec K‖ ≤ 1 :=
    UL.Proof_lem_A_3.norm_le_one_of_mem_simplex hq
  have horth : inner ℝ (z : EuclideanSpace ℝ (Fin K)) (uniformVec K) = 0 := by
    rw [real_inner_comm]
    exact UL.Proof_lem_A_6.inner_uniformVec_zero_of_mem_zeroSumSubspace z.2
  have hpyth : ‖(z : EuclideanSpace ℝ (Fin K)) + uniformVec K‖ ^ 2 =
      ‖z‖ ^ 2 + ‖uniformVec K‖ ^ 2 := by
    rw [norm_add_sq_real, horth, Submodule.norm_coe]
    ring
  have hsq : ‖z‖ ^ 2 ≤ 1 := by
    have h1 : ‖(z : EuclideanSpace ℝ (Fin K)) + uniformVec K‖ ^ 2 ≤ 1 := by
      nlinarith [norm_nonneg ((z : EuclideanSpace ℝ (Fin K)) + uniformVec K)]
    nlinarith [sq_nonneg ‖uniformVec K‖]
  nlinarith [norm_nonneg z]

lemma centeredLabel_norm_le_one {K : ℕ} (y : Fin K) : ‖centeredLabel y‖ ≤ 1 :=
  norm_le_one_of_mem_CSet (centeredLabel_mem_CSet y)

lemma convex_CSet (K : ℕ) : Convex ℝ (CSet K) := by
  intro x hx y hy a b ha hb hab
  change ((a • x + b • y : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) + uniformVec K ∈ Simplex K
  have heq : ((a • x + b • y : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) + uniformVec K =
      a • ((x : EuclideanSpace ℝ (Fin K)) + uniformVec K) +
        b • ((y : EuclideanSpace ℝ (Fin K)) + uniformVec K) := by
    calc ((a • x + b • y : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) + uniformVec K
        = a • (x : EuclideanSpace ℝ (Fin K)) + b • (y : EuclideanSpace ℝ (Fin K)) +
            (a + b) • uniformVec K := by rw [hab, one_smul]; rfl
      _ = a • ((x : EuclideanSpace ℝ (Fin K)) + uniformVec K) +
            b • ((y : EuclideanSpace ℝ (Fin K)) + uniformVec K) := by
          rw [add_smul, smul_add, smul_add]; abel
  rw [heq]
  exact UL.Proof_lem_A_3.simplex_convex K hx hy ha hb hab

lemma isCompact_CSet (K : ℕ) : IsCompact (CSet K) := by
  rw [Metric.isCompact_iff_isClosed_bounded]
  refine ⟨?_, ?_⟩
  · have hEq : CSet K = (fun z : ZeroSumSubspace K =>
        (z : EuclideanSpace ℝ (Fin K)) + uniformVec K) ⁻¹' Simplex K := rfl
    rw [hEq]
    exact (UL.Proof_lem_A_3.simplex_isCompact K).isClosed.preimage
      (continuous_subtype_val.add continuous_const)
  · rw [isBounded_iff_forall_norm_le]
    exact ⟨1, fun z hz => norm_le_one_of_mem_CSet hz⟩

/-- Exact shift relation between `projCDef K` and `projSimplexDef K` for `2 ≤ K`. -/
lemma coe_projCDef_add_uniformVec {K : ℕ} (hK : 2 ≤ K) (v : ZeroSumSubspace K) :
    (projCDef K v : EuclideanSpace ℝ (Fin K)) + uniformVec K =
      UL.Proof_lem_A_3.projSimplexDef K ((v : EuclideanSpace ℝ (Fin K)) + uniformVec K) := by
  have hK1 : 1 ≤ K := by omega
  set x : EuclideanSpace ℝ (Fin K) := (v : EuclideanSpace ℝ (Fin K)) + uniformVec K
  set q₀ : EuclideanSpace ℝ (Fin K) := UL.Proof_lem_A_3.projSimplexDef K x
  have hq₀_mem : q₀ ∈ Simplex K := UL.Proof_lem_A_3.projSimplex_mem hK x
  have hq₀_min : IsMinOn (fun q' => ‖x - q'‖) (Simplex K) q₀ :=
    UL.Proof_lem_A_3.projSimplex_isMinOn hK x
  let z₀ : ZeroSumSubspace K :=
    ⟨q₀ - uniformVec K, UL.Proof_lem_A_6.sub_mem_zeroSumSubspace_of_mem_simplex
      hq₀_mem (UL.Proof_lem_A_6.uniformVec_mem_simplex hK1)⟩
  have hz₀_mem : z₀ ∈ CSet K := by
    change (q₀ - uniformVec K) + uniformVec K ∈ Simplex K
    rwa [sub_add_cancel]
  have hz₀_min : IsMinOn (fun z' => ‖v - z'‖) (CSet K) z₀ := by
    intro z' hz'
    change ‖v - z₀‖ ≤ ‖v - z'‖
    rw [← Submodule.norm_coe, ← Submodule.norm_coe]
    have h1 : ((v - z₀ : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) = x - q₀ := by
      dsimp [x, z₀]; abel
    have h2 : ((v - z' : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) =
        x - ((z' : EuclideanSpace ℝ (Fin K)) + uniformVec K) := by
      dsimp [x]; abel
    rw [h1, h2]
    exact hq₀_min hz'
  have hex : ∃ z ∈ CSet K, IsMinOn (fun z' => ‖v - z'‖) (CSet K) z :=
    ⟨z₀, hz₀_mem, hz₀_min⟩
  have hp_spec : projCDef K v ∈ CSet K ∧
      IsMinOn (fun z' => ‖v - z'‖) (CSet K) (projCDef K v) := by
    unfold projCDef
    rw [dif_pos hex]
    exact Classical.choose_spec hex
  set q₁ : EuclideanSpace ℝ (Fin K) := (projCDef K v : EuclideanSpace ℝ (Fin K)) + uniformVec K
  have hq₁_mem : q₁ ∈ Simplex K := hp_spec.1
  have hq₁_min : IsMinOn (fun q' => ‖x - q'‖) (Simplex K) q₁ := by
    intro q' hq'
    let z' : ZeroSumSubspace K :=
      ⟨q' - uniformVec K, UL.Proof_lem_A_6.sub_mem_zeroSumSubspace_of_mem_simplex
        hq' (UL.Proof_lem_A_6.uniformVec_mem_simplex hK1)⟩
    have hz' : z' ∈ CSet K := by
      change (q' - uniformVec K) + uniformVec K ∈ Simplex K
      rwa [sub_add_cancel]
    have hle : ‖v - projCDef K v‖ ≤ ‖v - z'‖ := hp_spec.2 hz'
    rw [← Submodule.norm_coe, ← Submodule.norm_coe] at hle
    have h1 : ((v - projCDef K v : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) = x - q₁ := by
      dsimp [x, q₁]; abel
    have h2 : ((v - z' : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) = x - q' := by
      dsimp [x, z']; abel
    rwa [h1, h2] at hle
  have hvi : ∀ y ∈ Simplex K, inner ℝ (x - q₁) (y - q₁) ≤ 0 :=
    (UL.Proof_lem_A_3.isMinOn_simplex_iff_inner_le_zero x hq₁_mem).mp hq₁_min
  exact (UL.Proof_lem_A_3.eq_projSimplex_of_inner_le_zero hK x hq₁_mem hvi).symm

lemma coe_projCDef {K : ℕ} (hK : 2 ≤ K) (v : ZeroSumSubspace K) :
    (projCDef K v : EuclideanSpace ℝ (Fin K)) =
      UL.Proof_lem_A_3.projSimplexDef K ((v : EuclideanSpace ℝ (Fin K)) + uniformVec K) -
        uniformVec K := by
  rw [← coe_projCDef_add_uniformVec hK v, add_sub_cancel_right]

lemma projCDef_mem {K : ℕ} (hK : 2 ≤ K) (v : ZeroSumSubspace K) :
    projCDef K v ∈ CSet K := by
  change (projCDef K v : EuclideanSpace ℝ (Fin K)) + uniformVec K ∈ Simplex K
  rw [coe_projCDef_add_uniformVec hK v]
  exact UL.Proof_lem_A_3.projSimplex_mem hK _

lemma projCDef_isMinOn {K : ℕ} (hK : 2 ≤ K) (v : ZeroSumSubspace K) :
    IsMinOn (fun z' => ‖v - z'‖) (CSet K) (projCDef K v) := by
  intro z' hz'
  change ‖v - projCDef K v‖ ≤ ‖v - z'‖
  rw [← Submodule.norm_coe, ← Submodule.norm_coe]
  have h1 : ((v - projCDef K v : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) =
      ((v : EuclideanSpace ℝ (Fin K)) + uniformVec K) -
        ((projCDef K v : EuclideanSpace ℝ (Fin K)) + uniformVec K) := by
    rw [Submodule.coe_sub]; abel
  have h2 : ((v - z' : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) =
      ((v : EuclideanSpace ℝ (Fin K)) + uniformVec K) -
        ((z' : EuclideanSpace ℝ (Fin K)) + uniformVec K) := by
    rw [Submodule.coe_sub]; abel
  rw [h1, h2, coe_projCDef_add_uniformVec hK v]
  exact UL.Proof_lem_A_3.projSimplex_isMinOn hK _ hz'

lemma projCDef_inner_le_zero {K : ℕ} (hK : 2 ≤ K) (v : ZeroSumSubspace K)
    {z : ZeroSumSubspace K} (hz : z ∈ CSet K) :
    inner ℝ (v - projCDef K v) (z - projCDef K v) ≤ 0 := by
  change inner ℝ (((v - projCDef K v : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)))
      (((z - projCDef K v : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))) ≤ 0
  have h1 : ((v - projCDef K v : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) =
      ((v : EuclideanSpace ℝ (Fin K)) + uniformVec K) -
        ((projCDef K v : EuclideanSpace ℝ (Fin K)) + uniformVec K) := by
    rw [Submodule.coe_sub]; abel
  have h2 : ((z - projCDef K v : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) =
      ((z : EuclideanSpace ℝ (Fin K)) + uniformVec K) -
        ((projCDef K v : EuclideanSpace ℝ (Fin K)) + uniformVec K) := by
    rw [Submodule.coe_sub]; abel
  rw [h1, h2, coe_projCDef_add_uniformVec hK v]
  exact UL.Proof_lem_A_3.projSimplex_inner_le_zero hK _ hz

lemma projCDef_eq_self {K : ℕ} (hK : 2 ≤ K) {z : ZeroSumSubspace K} (hz : z ∈ CSet K) :
    projCDef K z = z := by
  apply Subtype.ext
  rw [coe_projCDef hK z, UL.Proof_lem_A_3.projSimplex_eq_self hK hz, add_sub_cancel_right]

lemma projCDef_nonexpansive {K : ℕ} (hK : 2 ≤ K) (v₁ v₂ : ZeroSumSubspace K) :
    ‖projCDef K v₁ - projCDef K v₂‖ ≤ ‖v₁ - v₂‖ := by
  rw [← Submodule.norm_coe, ← Submodule.norm_coe]
  have h1 : ((projCDef K v₁ - projCDef K v₂ : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) =
      UL.Proof_lem_A_3.projSimplexDef K ((v₁ : EuclideanSpace ℝ (Fin K)) + uniformVec K) -
        UL.Proof_lem_A_3.projSimplexDef K ((v₂ : EuclideanSpace ℝ (Fin K)) + uniformVec K) := by
    rw [Submodule.coe_sub, coe_projCDef hK, coe_projCDef hK]; abel
  have h2 : (((v₁ : EuclideanSpace ℝ (Fin K)) + uniformVec K) -
      ((v₂ : EuclideanSpace ℝ (Fin K)) + uniformVec K)) =
      ((v₁ - v₂ : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) := by
    rw [Submodule.coe_sub]; abel
  rw [h1, ← h2]
  exact UL.Proof_lem_A_3.projSimplex_nonexpansive hK _ _

/-! ### Isometric Hilbert-Schmidt characterization on `EuclideanSpace ℝ (Fin d) →L[ℝ] Y` -/

private lemma inner_single_left {d : ℕ} (i : Fin d) (x : EuclideanSpace ℝ (Fin d)) :
    inner ℝ (EuclideanSpace.single i (1 : ℝ)) x = x i := by
  rw [UL.Proof_lem_A_3.inner_eq_sum]
  simp [EuclideanSpace.single_apply]

private lemma eucl_eq_sum_single {d : ℕ} (x : EuclideanSpace ℝ (Fin d)) :
    x = ∑ i : Fin d, x i • EuclideanSpace.single i (1 : ℝ) := by
  ext j
  rw [UL.Proof_lem_A_3.sum_apply]
  simp [EuclideanSpace.single_apply]

private lemma eucl_norm_sq_eq_sum_inner_single {d : ℕ} (u : EuclideanSpace ℝ (Fin d)) :
    ‖u‖ ^ 2 = ∑ i : Fin d, (inner ℝ (EuclideanSpace.single i (1 : ℝ)) u) ^ 2 := by
  rw [UL.Proof_lem_A_3.norm_sq_eq_sum]
  refine Finset.sum_congr rfl fun i _ => ?_
  rw [inner_single_left]

/-- Continuous linear equivalence `(ℝ^d →L[ℝ] Y) ≃L[ℝ] PiLp 2 (fun _ : Fin d => Y)` sending
`W` to its column tuple `i ↦ W e_i`. -/
noncomputable def hsPiEquiv (d : ℕ) (Y : Type*)
    [NormedAddCommGroup Y] [InnerProductSpace ℝ Y] [FiniteDimensional ℝ Y] :
    (EuclideanSpace ℝ (Fin d) →L[ℝ] Y) ≃L[ℝ] PiLp 2 (fun _ : Fin d => Y) :=
  LinearEquiv.toContinuousLinearEquiv
    { toFun := fun W => (WithLp.equiv 2 (Fin d → Y)).symm
        (fun i => W (EuclideanSpace.single i (1 : ℝ)))
      map_add' := fun A B => by ext i; rfl
      map_smul' := fun c A => by ext i; rfl
      invFun := fun f => ∑ i : Fin d,
        (innerSL ℝ (EuclideanSpace.single i (1 : ℝ))).smulRight (f i)
      left_inv := fun W => by
        ext x
        simp only [ContinuousLinearMap.sum_apply, ContinuousLinearMap.smulRight_apply,
          innerSL_apply_apply, WithLp.equiv_symm_apply, inner_single_left]
        conv_rhs => rw [eucl_eq_sum_single x]
        rw [map_sum]
        refine Finset.sum_congr rfl fun i _ => ?_
        rw [map_smul]
      right_inv := fun f => by
        ext j
        simp only [WithLp.equiv_symm_apply, ContinuousLinearMap.sum_apply,
          ContinuousLinearMap.smulRight_apply, innerSL_apply_apply, inner_single_left]
        have hsum : ∑ i : Fin d, (EuclideanSpace.single j (1 : ℝ) i) • f i =
            ∑ i : Fin d, if i = j then f j else 0 := by
          refine Finset.sum_congr rfl fun i _ => ?_
          by_cases hij : i = j
          · subst hij; simp [EuclideanSpace.single_apply]
          · have hne : j ≠ i := fun h => hij h.symm
            simp [EuclideanSpace.single_apply, hij, hne]
        rw [hsum, Finset.sum_ite_eq', if_pos (Finset.mem_univ j)] }

section HilbertSchmidtFin

variable {d : ℕ} {Y : Type*}
  [NormedAddCommGroup Y] [InnerProductSpace ℝ Y] [FiniteDimensional ℝ Y]

/-- Exact column-sum formula `‖W‖_HS^2 = ∑_{i : Fin d} ‖W e_i‖^2` (valid for all `d ≥ 0`). -/
lemma hilbertSchmidtNorm_sq_eq_sum_single (W : EuclideanSpace ℝ (Fin d) →L[ℝ] Y) :
    hilbertSchmidtNorm W ^ 2 = ∑ i : Fin d, ‖W (EuclideanSpace.single i (1 : ℝ))‖ ^ 2 := by
  let bY := stdOrthonormalBasis ℝ Y
  rw [UL.Proof_lem_C_2.hilbertSchmidtNorm_sq W]
  dsimp only
  have hadj : ∀ j : Fin (Module.finrank ℝ Y),
      ‖UL.Proof_lem_C_2.adjVec W (bY j)‖ ^ 2 =
        ∑ i : Fin d, (inner ℝ (W (EuclideanSpace.single i (1 : ℝ))) (bY j)) ^ 2 := by
    intro j
    rw [eucl_norm_sq_eq_sum_inner_single]
    refine Finset.sum_congr rfl fun i _ => ?_
    rw [UL.Proof_lem_C_2.inner_adjVec_right]
  have hsum : (∑ j : Fin (Module.finrank ℝ Y),
      ‖UL.Proof_lem_C_2.adjVec W (stdOrthonormalBasis ℝ Y j)‖ ^ 2) =
      ∑ j : Fin (Module.finrank ℝ Y),
        ∑ i : Fin d, (inner ℝ (W (EuclideanSpace.single i (1 : ℝ))) (bY j)) ^ 2 :=
    Finset.sum_congr rfl fun j _ => hadj j
  rw [hsum, Finset.sum_comm]
  refine Finset.sum_congr rfl fun i _ => ?_
  rw [← real_inner_self_eq_norm_sq, ← bY.sum_inner_mul_inner (W (EuclideanSpace.single i (1 : ℝ)))
    (W (EuclideanSpace.single i (1 : ℝ)))]
  refine Finset.sum_congr rfl fun j _ => ?_
  rw [real_inner_comm (bY j), sq]

@[simp]
lemma hsPiEquiv_apply (W : EuclideanSpace ℝ (Fin d) →L[ℝ] Y) (i : Fin d) :
    hsPiEquiv d Y W i = W (EuclideanSpace.single i (1 : ℝ)) := rfl

lemma hsPiEquiv_symm_apply (f : PiLp 2 (fun _ : Fin d => Y)) (x : EuclideanSpace ℝ (Fin d)) :
    (hsPiEquiv d Y).symm f x = ∑ i : Fin d, x i • f i := by
  change (∑ i : Fin d,
    (innerSL ℝ (EuclideanSpace.single i (1 : ℝ))).smulRight (f i)) x = _
  simp only [ContinuousLinearMap.sum_apply, ContinuousLinearMap.smulRight_apply,
    innerSL_apply_apply, inner_single_left]

lemma hilbertSchmidtNorm_eq_norm_hsPiEquiv (W : EuclideanSpace ℝ (Fin d) →L[ℝ] Y) :
    hilbertSchmidtNorm W = ‖hsPiEquiv d Y W‖ := by
  have hsq1 := hilbertSchmidtNorm_sq_eq_sum_single W
  have hsq2 : ‖hsPiEquiv d Y W‖ ^ 2 =
      ∑ i : Fin d, ‖W (EuclideanSpace.single i (1 : ℝ))‖ ^ 2 := by
    rw [PiLp.norm_sq_eq_of_L2]
    rfl
  have hnn1 := UL.Proof_lem_C_2.hilbertSchmidtNorm_nonneg W
  have hnn2 := norm_nonneg (hsPiEquiv d Y W)
  nlinarith

lemma hilbertSchmidtNorm_eq_norm_hsPiEquiv_symm (f : PiLp 2 (fun _ : Fin d => Y)) :
    hilbertSchmidtNorm ((hsPiEquiv d Y).symm f) = ‖f‖ := by
  rw [hilbertSchmidtNorm_eq_norm_hsPiEquiv, ContinuousLinearEquiv.apply_symm_apply]

lemma hilbertSchmidtNorm_add_le (A B : EuclideanSpace ℝ (Fin d) →L[ℝ] Y) :
    hilbertSchmidtNorm (A + B) ≤ hilbertSchmidtNorm A + hilbertSchmidtNorm B := by
  simp_rw [hilbertSchmidtNorm_eq_norm_hsPiEquiv, map_add]
  exact norm_add_le _ _

lemma hilbertSchmidtNorm_sub_le (A B : EuclideanSpace ℝ (Fin d) →L[ℝ] Y) :
    hilbertSchmidtNorm (A - B) ≤ hilbertSchmidtNorm A + hilbertSchmidtNorm B := by
  simp_rw [hilbertSchmidtNorm_eq_norm_hsPiEquiv, map_sub]
  exact norm_sub_le _ _

lemma abs_hilbertSchmidtNorm_sub_le (A B : EuclideanSpace ℝ (Fin d) →L[ℝ] Y) :
    |hilbertSchmidtNorm A - hilbertSchmidtNorm B| ≤ hilbertSchmidtNorm (A - B) := by
  simp_rw [hilbertSchmidtNorm_eq_norm_hsPiEquiv, map_sub]
  exact abs_norm_sub_norm_le _ _

lemma hilbertSchmidtNorm_smul (c : ℝ) (W : EuclideanSpace ℝ (Fin d) →L[ℝ] Y) :
    hilbertSchmidtNorm (c • W) = |c| * hilbertSchmidtNorm W := by
  rw [hilbertSchmidtNorm_eq_norm_hsPiEquiv, map_smul, norm_smul, Real.norm_eq_abs,
    ← hilbertSchmidtNorm_eq_norm_hsPiEquiv]

lemma continuous_hilbertSchmidtNorm :
    Continuous (hilbertSchmidtNorm : (EuclideanSpace ℝ (Fin d) →L[ℝ] Y) → ℝ) := by
  have heq : (hilbertSchmidtNorm : (EuclideanSpace ℝ (Fin d) →L[ℝ] Y) → ℝ) =
      fun W => ‖hsPiEquiv d Y W‖ := funext hilbertSchmidtNorm_eq_norm_hsPiEquiv
  rw [heq]
  exact continuous_norm.comp (hsPiEquiv d Y).continuous

lemma isCompact_hsBall (R : ℝ) :
    IsCompact {W : EuclideanSpace ℝ (Fin d) →L[ℝ] Y | hilbertSchmidtNorm W ≤ R} := by
  have heq : {W : EuclideanSpace ℝ (Fin d) →L[ℝ] Y | hilbertSchmidtNorm W ≤ R} =
      (hsPiEquiv d Y).symm '' Metric.closedBall (0 : PiLp 2 (fun _ : Fin d => Y)) R := by
    ext W
    simp only [Set.mem_setOf_eq, Set.mem_image, Metric.mem_closedBall, dist_zero_right,
      hilbertSchmidtNorm_eq_norm_hsPiEquiv]
    constructor
    · intro h
      exact ⟨hsPiEquiv d Y W, h, (hsPiEquiv d Y).symm_apply_apply W⟩
    · rintro ⟨f, hf, rfl⟩
      simpa using hf
  rw [heq]
  exact (isCompact_closedBall (0 : PiLp 2 (fun _ : Fin d => Y)) R).image
    (hsPiEquiv d Y).symm.continuous

lemma convex_hsBall (R : ℝ) :
    Convex ℝ {W : EuclideanSpace ℝ (Fin d) →L[ℝ] Y | hilbertSchmidtNorm W ≤ R} := by
  intro A hA B hB a b ha hb hab
  simp only [Set.mem_setOf_eq] at hA hB ⊢
  calc hilbertSchmidtNorm (a • A + b • B)
      ≤ hilbertSchmidtNorm (a • A) + hilbertSchmidtNorm (b • B) :=
        hilbertSchmidtNorm_add_le _ _
    _ = a * hilbertSchmidtNorm A + b * hilbertSchmidtNorm B := by
        rw [hilbertSchmidtNorm_smul, hilbertSchmidtNorm_smul, abs_of_nonneg ha, abs_of_nonneg hb]
    _ ≤ a * R + b * R := add_le_add (mul_le_mul_of_nonneg_left hA ha)
          (mul_le_mul_of_nonneg_left hB hb)
    _ = (a + b) * R := by ring
    _ = R := by rw [hab, one_mul]

lemma isCompactConvexScoreSet_hsBall {K : ℕ} {R : ℝ} (hR : 0 ≤ R) :
    IsCompactConvexScoreSet
      {W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K | hilbertSchmidtNorm W ≤ R} := by
  refine ⟨⟨0, ?_⟩, isCompact_hsBall R, convex_hsBall R⟩
  simp [UL.Proof_lem_C_2.hilbertSchmidtNorm_zero, hR]

end HilbertSchmidtFin

/-- Riesz vector in `ℝ^d` of a scalar linear form `L : ℝ^d →L[ℝ] ℝ`. -/
noncomputable def vecOfLinearForm {d : ℕ} (L : EuclideanSpace ℝ (Fin d) →L[ℝ] ℝ) :
    EuclideanSpace ℝ (Fin d) :=
  (WithLp.equiv 2 (Fin d → ℝ)).symm (fun i => L (EuclideanSpace.single i (1 : ℝ)))

lemma inner_vecOfLinearForm {d : ℕ} (L : EuclideanSpace ℝ (Fin d) →L[ℝ] ℝ)
    (x : EuclideanSpace ℝ (Fin d)) :
    inner ℝ (vecOfLinearForm L) x = L x := by
  rw [UL.Proof_lem_A_3.inner_eq_sum]
  conv_rhs => rw [eucl_eq_sum_single x]
  rw [map_sum]
  refine Finset.sum_congr rfl fun i _ => ?_
  rw [map_smul, smul_eq_mul, mul_comm]
  rfl

lemma norm_vecOfLinearForm {d : ℕ} (L : EuclideanSpace ℝ (Fin d) →L[ℝ] ℝ) :
    ‖vecOfLinearForm L‖ = hilbertSchmidtNorm L := by
  have hsq1 : ‖vecOfLinearForm L‖ ^ 2 =
      ∑ i : Fin d, ‖L (EuclideanSpace.single i (1 : ℝ))‖ ^ 2 := by
    rw [UL.Proof_lem_A_3.norm_sq_eq_sum]
    refine Finset.sum_congr rfl fun i _ => ?_
    rw [Real.norm_eq_abs, sq_abs]
    rfl
  have hsq2 := hilbertSchmidtNorm_sq_eq_sum_single L
  have hnn1 := norm_nonneg (vecOfLinearForm L)
  have hnn2 := UL.Proof_lem_C_2.hilbertSchmidtNorm_nonneg L
  nlinarith

/-! ### Matrix representation of score operators `ℝ^d →L[ℝ] ZeroSumSubspace K` -/

/-- `K × d` matrix of `W : ℝ^d →L[ℝ] ZeroSumSubspace K` in standard coordinates. -/
noncomputable def matOfScoreOp {d K : ℕ}
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K) : Matrix (Fin K) (Fin d) ℝ :=
  fun k j => (W (EuclideanSpace.single j (1 : ℝ)) : EuclideanSpace ℝ (Fin K)) k

lemma matOfScoreOp_col_sum {d K : ℕ}
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K) (j : Fin d) :
    ∑ k : Fin K, matOfScoreOp W k j = 0 :=
  (UL.Proof_lem_A_3.zeroSumSubspace_iff _).mp (W (EuclideanSpace.single j (1 : ℝ))).2

lemma matOfScoreOp_apply_vec {d K : ℕ}
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
    (x : EuclideanSpace ℝ (Fin d)) (k : Fin K) :
    (W x : EuclideanSpace ℝ (Fin K)) k = ∑ j : Fin d, matOfScoreOp W k j * x j := by
  have hx : x = ∑ j : Fin d, x j • EuclideanSpace.single j (1 : ℝ) := by
    ext j; rw [UL.Proof_lem_A_3.sum_apply]; simp [EuclideanSpace.single_apply]
  conv_lhs => rw [hx, map_sum]
  rw [Submodule.coe_sum, UL.Proof_lem_A_3.sum_apply]
  refine Finset.sum_congr rfl fun j _ => ?_
  rw [map_smul, Submodule.coe_smul_of_tower, PiLp.smul_apply, smul_eq_mul, mul_comm]
  rfl

lemma hilbertSchmidtNorm_sq_eq_matOfScoreOp {d K : ℕ}
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K) :
    hilbertSchmidtNorm W ^ 2 = ∑ k : Fin K, ∑ j : Fin d, (matOfScoreOp W k j) ^ 2 := by
  rw [hilbertSchmidtNorm_sq_eq_sum_single W]
  have hcol : ∀ j : Fin d, ‖W (EuclideanSpace.single j (1 : ℝ))‖ ^ 2 =
      ∑ k : Fin K, (matOfScoreOp W k j) ^ 2 := by
    intro j
    rw [← Submodule.norm_coe, UL.Proof_lem_A_3.norm_sq_eq_sum]
    rfl
  simp_rw [hcol]
  exact Finset.sum_comm

/-- Score operator `ℝ^d →L[ℝ] ZeroSumSubspace K` built from a zero-column-sum `K × d` matrix. -/
noncomputable def scoreOpOfMat {d K : ℕ} (M : Matrix (Fin K) (Fin d) ℝ)
    (hM : ∀ j : Fin d, ∑ k : Fin K, M k j = 0) :
    EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K :=
  (hsPiEquiv d (ZeroSumSubspace K)).symm
    ((WithLp.equiv 2 (Fin d → ZeroSumSubspace K)).symm fun j =>
      ⟨(WithLp.equiv 2 (Fin K → ℝ)).symm (fun k => M k j),
        (UL.Proof_lem_A_3.zeroSumSubspace_iff _).mpr (hM j)⟩)

@[simp]
lemma matOfScoreOp_scoreOpOfMat {d K : ℕ} (M : Matrix (Fin K) (Fin d) ℝ)
    (hM : ∀ j : Fin d, ∑ k : Fin K, M k j = 0) :
    matOfScoreOp (scoreOpOfMat M hM) = M := by
  ext k j
  unfold matOfScoreOp scoreOpOfMat
  have h := congrArg (fun f : PiLp 2 (fun _ : Fin d => ZeroSumSubspace K) => (f j : EuclideanSpace ℝ (Fin K)) k)
    ((hsPiEquiv d (ZeroSumSubspace K)).apply_symm_apply
      ((WithLp.equiv 2 (Fin d → ZeroSumSubspace K)).symm fun j' =>
        ⟨(WithLp.equiv 2 (Fin K → ℝ)).symm (fun k' => M k' j'),
          (UL.Proof_lem_A_3.zeroSumSubspace_iff _).mpr (hM j')⟩))
  exact h

@[simp]
lemma scoreOpOfMat_matOfScoreOp {d K : ℕ}
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K) :
    scoreOpOfMat (matOfScoreOp W) (matOfScoreOp_col_sum W) = W := by
  apply (hsPiEquiv d (ZeroSumSubspace K)).injective
  ext j k
  change matOfScoreOp (scoreOpOfMat (matOfScoreOp W) (matOfScoreOp_col_sum W)) k j =
    matOfScoreOp W k j
  rw [matOfScoreOp_scoreOpOfMat]

lemma hilbertSchmidtNorm_sq_scoreOpOfMat {d K : ℕ} (M : Matrix (Fin K) (Fin d) ℝ)
    (hM : ∀ j : Fin d, ∑ k : Fin K, M k j = 0) :
    hilbertSchmidtNorm (scoreOpOfMat M hM) ^ 2 = ∑ k : Fin K, ∑ j : Fin d, (M k j) ^ 2 := by
  rw [hilbertSchmidtNorm_sq_eq_matOfScoreOp, matOfScoreOp_scoreOpOfMat]

/-! ### Empirical least-squares objective `F_n(a, W)` and Dirichlet contraction interface -/

/-- Empirical least-squares objective `(1 / (2 n)) ∑_{i : Fin n} ‖a + β W x_i - (e_{y_i} - u)‖^2`. -/
noncomputable def empLSObj {n d K : ℕ} (β : ℝ)
    (x_samp : Fin n → EuclideanSpace ℝ (Fin d)) (y_samp : Fin n → Fin K)
    (a : ZeroSumSubspace K) (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K) : ℝ :=
  (1 / (2 * (n : ℝ))) * ∑ i : Fin n, ‖a + β • W (x_samp i) - centeredLabel (y_samp i)‖ ^ 2

/-- Interface proposition for Dirichlet feature affine Lipschitz contraction (proved in `H2_DirichletEnergy`). -/
def DirichletLipschitzRepProp : Prop :=
  ∀ {N d : ℕ} {x_dict : Fin N → EuclideanSpace ℝ (Fin d)},
    DirichletFeatureCondition x_dict →
    ∀ (E₁ E₂ : Type)
      [NormedAddCommGroup E₁] [InnerProductSpace ℝ E₁] [FiniteDimensional ℝ E₁]
      [NormedAddCommGroup E₂] [InnerProductSpace ℝ E₂] [FiniteDimensional ℝ E₂]
      (b₀ : E₁) (A₀ : EuclideanSpace ℝ (Fin d) →L[ℝ] E₁)
      (g : Fin N → E₂) {C : ℝ}, 0 ≤ C →
      (∀ i j : Fin N,
        ‖g i - g j‖ ≤ C * ‖(b₀ + A₀ (x_dict i)) - (b₀ + A₀ (x_dict j))‖) →
      ∃ (b : E₂) (A : EuclideanSpace ℝ (Fin d) →L[ℝ] E₂),
        (∀ i : Fin N, g i = b + A (x_dict i)) ∧
        hilbertSchmidtNorm A ≤ C * hilbertSchmidtNorm A₀

end UL.Proof_thm_7_1

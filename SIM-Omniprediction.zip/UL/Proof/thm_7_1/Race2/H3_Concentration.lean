import Mathlib
import UL.Def.def_2_1
import UL.Def.def_5_smooth
import UL.Stmt.cit_mcdiarmid1989
import UL.Proof.lem_C_2.H1_HilbertSchmidt
set_option autoImplicit false

namespace UL.Proof_thm_7_1_Race2

section Helpers

private lemma sum_apply_eucl {m : ℕ} {ι : Type*} (s : Finset ι)
    (f : ι → EuclideanSpace ℝ (Fin m)) (r : Fin m) :
    (∑ a ∈ s, f a) r = ∑ a ∈ s, f a r := by
  classical
  induction s using Finset.induction_on with
  | empty => rfl
  | @insert a s ha ih => simp [Finset.sum_insert ha, ih]

private lemma eucl_norm_sq_eq_sum {m : ℕ} (u : EuclideanSpace ℝ (Fin m)) :
    ‖u‖ ^ 2 = ∑ r : Fin m, (u r) ^ 2 := by
  rw [EuclideanSpace.norm_sq_eq]
  refine Finset.sum_congr rfl fun r _ => ?_
  rw [Real.norm_eq_abs, sq_abs]

private lemma eucl_inner_eq_sum {m : ℕ} (u w : EuclideanSpace ℝ (Fin m)) :
    inner ℝ u w = ∑ r : Fin m, u r * w r := by
  have hpol := norm_add_sq_real u w
  rw [eucl_norm_sq_eq_sum, eucl_norm_sq_eq_sum, eucl_norm_sq_eq_sum] at hpol
  have hexp :
      ∑ r : Fin m, ((u + w) r) ^ 2 =
        (∑ r : Fin m, (u r) ^ 2) + 2 * (∑ r : Fin m, u r * w r) + (∑ r : Fin m, (w r) ^ 2) := by
    have h1 : ∀ r : Fin m, ((u + w) r) ^ 2 = (u r) ^ 2 + (2 * (u r * w r) + (w r) ^ 2) := by
      intro r
      change (u r + w r) ^ 2 = _
      ring
    simp_rw [h1, Finset.sum_add_distrib, ← Finset.mul_sum]
    ring
  linarith

private lemma abs_coord_le_norm {m : ℕ} (u : EuclideanSpace ℝ (Fin m)) (r : Fin m) :
    |u r| ≤ ‖u‖ := by
  have hsq : |u r| ^ 2 ≤ ‖u‖ ^ 2 := by
    rw [sq_abs, eucl_norm_sq_eq_sum]
    exact Finset.single_le_sum (fun s _ => sq_nonneg (u s)) (Finset.mem_univ r)
  have h0 : 0 ≤ ‖u‖ := norm_nonneg u
  have h1 : 0 ≤ |u r| := abs_nonneg _
  nlinarith

private lemma eucl_eq_sum_single {m : ℕ} (u : EuclideanSpace ℝ (Fin m)) :
    u = ∑ r : Fin m, (u r) • EuclideanSpace.single r (1 : ℝ) := by
  ext r₀
  rw [sum_apply_eucl]
  simp [EuclideanSpace.single_apply]

private lemma inner_single_right {m : ℕ} (u : EuclideanSpace ℝ (Fin m)) (r : Fin m) :
    inner ℝ u (EuclideanSpace.single r (1 : ℝ)) = u r := by
  rw [eucl_inner_eq_sum]
  simp [EuclideanSpace.single_apply]

/-! ### McDiarmid Bridge on Product Measure (`Type 0`) -/

private theorem mcdiarmid_pi_alpha0.{u₁, u₂}
    (h_mc : UL.S_cit_mcdiarmid1989.{u₁, u₂})
    {α₀ : Type} [MeasurableSpace α₀]
    (ν₀ : MeasureTheory.Measure α₀) [MeasureTheory.IsProbabilityMeasure ν₀]
    (n : ℕ)
    (g : (Fin n → α₀) → ℝ) (hg_meas : Measurable g)
    (d₀ : ℝ) (hd₀ : 0 ≤ d₀)
    (hg_diff : ∀ (i : Fin n) (z : Fin n → α₀) (z' : α₀),
      |g z - g (Function.update z i z')| ≤ d₀)
    (δ' : ℝ) (hδ'0 : 0 < δ') (hδ'1 : δ' < 1) :
    let π := MeasureTheory.Measure.pi (fun _ : Fin n => ν₀)
    (π {z | |g z - (∫ z', g z' ∂π)| ≤
      Real.sqrt ((1 / 2 : ℝ) * ((n : ℝ) * d₀ ^ 2) * Real.log (2 / δ'))}).toReal ≥ 1 - δ' := by
  dsimp only
  unfold UL.S_cit_mcdiarmid1989 at h_mc
  let π : MeasureTheory.Measure (Fin n → α₀) := MeasureTheory.Measure.pi (fun _ : Fin n => ν₀)
  let Ω_mc : Type u₁ := ULift.{u₁} (Fin n → α₀)
  let eΩ : Ω_mc ≃ᵐ (Fin n → α₀) := MeasurableEquiv.ulift
  let μ_mc : MeasureTheory.Measure Ω_mc := MeasureTheory.Measure.map eΩ.symm π
  haveI : MeasureTheory.IsProbabilityMeasure μ_mc :=
    MeasureTheory.Measure.isProbabilityMeasure_map eΩ.symm.measurable.aemeasurable
  let α_mc : Fin n → Type u₂ := fun _ => ULift.{u₂} α₀
  let eα : ULift.{u₂} α₀ ≃ᵐ α₀ := MeasurableEquiv.ulift
  let Z_mc : ∀ i : Fin n, Ω_mc → α_mc i := fun i ω => eα.symm (eΩ ω i)
  have hZ_meas : ∀ i : Fin n, Measurable (Z_mc i) :=
    fun i => eα.symm.measurable.comp ((measurable_pi_apply i).comp eΩ.measurable)
  have hZ_indep : ProbabilityTheory.iIndepFun Z_mc μ_mc := by
    rw [ProbabilityTheory.iIndepFun_iff_map_fun_eq_pi_map (fun i => (hZ_meas i).aemeasurable)]
    have h_lhs : MeasureTheory.Measure.map (fun ω i => Z_mc i ω) μ_mc =
        MeasureTheory.Measure.pi (fun _ : Fin n => MeasureTheory.Measure.map eα.symm ν₀) := by
      have h_meas_vec : Measurable (fun ω : Ω_mc => fun i : Fin n => Z_mc i ω) :=
        measurable_pi_lambda _ hZ_meas
      rw [MeasureTheory.Measure.map_map h_meas_vec eΩ.symm.measurable]
      have h_comp : ((fun ω : Ω_mc => fun i : Fin n => Z_mc i ω) ∘ eΩ.symm) =
          (fun z : Fin n → α₀ => fun i : Fin n => eα.symm (z i)) := by
        funext z i
        simp [Z_mc]
      rw [h_comp, ← MeasureTheory.Measure.pi_map_pi (fun _ => eα.symm.measurable.aemeasurable)]
    have h_rhs : ∀ i : Fin n,
        MeasureTheory.Measure.map (Z_mc i) μ_mc = MeasureTheory.Measure.map eα.symm ν₀ := by
      intro i
      rw [MeasureTheory.Measure.map_map (hZ_meas i) eΩ.symm.measurable]
      have h_comp_i : Z_mc i ∘ eΩ.symm = eα.symm ∘ Function.eval i := by
        funext z
        simp [Z_mc]
      rw [h_comp_i, ← MeasureTheory.Measure.map_map eα.symm.measurable (measurable_pi_apply i),
        (MeasureTheory.measurePreserving_eval (fun _ : Fin n => ν₀) i).map_eq]
    rw [h_lhs]
    simp_rw [h_rhs]
  let g_mc : (∀ i : Fin n, α_mc i) → ℝ := fun w => g (fun i => eα (w i))
  have hg_mc_meas : Measurable g_mc :=
    hg_meas.comp (measurable_pi_lambda _ fun i => eα.measurable.comp (measurable_pi_apply i))
  let c : Fin n → ℝ := fun _ => d₀
  have hc_nonneg : ∀ i : Fin n, 0 ≤ c i := fun _ => hd₀
  have hg_mc_diff : ∀ (i : Fin n) (w : ∀ j : Fin n, α_mc j) (w' : α_mc i),
      |g_mc w - g_mc (Function.update w i w')| ≤ c i := by
    intro i w w'
    have h_upd : (fun j : Fin n => eα (Function.update w i w' j)) =
        Function.update (fun j : Fin n => eα (w j)) i (eα w') := by
      funext j
      by_cases hj : j = i
      · subst hj; simp
      · simp [hj]
    change |g (fun j => eα (w j)) - g (fun j => eα (Function.update w i w' j))| ≤ d₀
    rw [h_upd]
    exact hg_diff i (fun j => eα (w j)) (eα w')
  have h_res := (h_mc Ω_mc μ_mc n α_mc Z_mc hZ_meas hZ_indep g_mc c
    hg_mc_meas hg_mc_diff hc_nonneg).2 δ' hδ'0 hδ'1 |>.1
  have h_eval : ∀ ω : Ω_mc, g_mc (fun i => Z_mc i ω) = g (eΩ ω) := by
    intro ω
    change g (fun i => eα (eα.symm (eΩ ω i))) = g (eΩ ω)
    simp
  have h_int : (∫ ω', g_mc (fun i => Z_mc i ω') ∂μ_mc) = ∫ z', g z' ∂π := by
    simp_rw [h_eval]
    have h1 := MeasureTheory.integral_map (μ := π) eΩ.symm.measurable.aemeasurable
      (f := fun ω' : Ω_mc => g (eΩ ω')) (hg_meas.comp eΩ.measurable).aestronglyMeasurable
    simpa [μ_mc] using h1
  have h_sum_c : (∑ i : Fin n, c i ^ 2) = (n : ℝ) * d₀ ^ 2 := by
    simp [c]
  let R := Real.sqrt ((1 / 2 : ℝ) * ((n : ℝ) * d₀ ^ 2) * Real.log (2 / δ'))
  have hS_meas : MeasurableSet {z : Fin n → α₀ | |g z - (∫ z', g z' ∂π)| ≤ R} :=
    measurableSet_le (continuous_abs.measurable.comp (hg_meas.sub measurable_const)) measurable_const
  have h_mu_eq : μ_mc {ω | |g_mc (fun i => Z_mc i ω) - (∫ ω', g_mc (fun i => Z_mc i ω') ∂μ_mc)| ≤ R} =
      π {z | |g z - (∫ z', g z' ∂π)| ≤ R} := by
    rw [h_int]
    simp_rw [h_eval]
    change MeasureTheory.Measure.map eΩ.symm π (eΩ ⁻¹' {z | |g z - (∫ z', g z' ∂π)| ≤ R}) = _
    rw [MeasureTheory.Measure.map_apply eΩ.symm.measurable (eΩ.measurable hS_meas)]
    congr 1
  simp_rw [h_sum_c] at h_res
  rwa [← h_mu_eq]

/-! ### Euclidean Mean Concentration -/

private noncomputable def euclMean {α₀ : Type} [MeasurableSpace α₀] {m : ℕ}
    (ν : MeasureTheory.Measure α₀) (ξ : α₀ → EuclideanSpace ℝ (Fin m)) :
    EuclideanSpace ℝ (Fin m) :=
  (WithLp.equiv 2 (Fin m → ℝ)).symm (fun r => ∫ q, ξ q r ∂ν)

private noncomputable def euclEmp {α₀ : Type} {m : ℕ} (n : ℕ)
    (ξ : α₀ → EuclideanSpace ℝ (Fin m)) (z : Fin n → α₀) :
    EuclideanSpace ℝ (Fin m) :=
  (1 / (n : ℝ)) • ∑ i : Fin n, ξ (z i)

private noncomputable def euclDev {α₀ : Type} [MeasurableSpace α₀] {m : ℕ} (n : ℕ)
    (ν : MeasureTheory.Measure α₀) (ξ : α₀ → EuclideanSpace ℝ (Fin m))
    (z : Fin n → α₀) : ℝ :=
  ‖euclEmp n ξ z - euclMean ν ξ‖

private lemma measurable_euclDev {α₀ : Type} [MeasurableSpace α₀] {m : ℕ} (n : ℕ)
    (ν : MeasureTheory.Measure α₀) {ξ : α₀ → EuclideanSpace ℝ (Fin m)}
    (hξ_meas : Measurable ξ) :
    Measurable (euclDev n ν ξ) := by
  unfold euclDev euclEmp
  refine Measurable.norm (Measurable.sub ?_ measurable_const)
  refine Measurable.const_smul ?_ (1 / (n : ℝ))
  exact Finset.measurable_sum Finset.univ fun i _ => hξ_meas.comp (measurable_pi_apply i)

private lemma integrable_eucl_coord {α₀ : Type} [MeasurableSpace α₀] {m : ℕ}
    (ν : MeasureTheory.Measure α₀) [MeasureTheory.IsProbabilityMeasure ν]
    {ξ : α₀ → EuclideanSpace ℝ (Fin m)} {B₀ : ℝ}
    (hξ_meas : Measurable ξ) (hξ_norm : ∀ q, ‖ξ q‖ ≤ B₀) (r : Fin m) :
    MeasureTheory.Integrable (fun q => ξ q r) ν := by
  have hm : Measurable (fun q => ξ q r) :=
    (PiLp.continuous_apply 2 (fun _ : Fin m => ℝ) r).measurable.comp hξ_meas
  refine (MeasureTheory.integrable_const B₀).mono' hm.aestronglyMeasurable ?_
  exact Filter.Eventually.of_forall fun q => by
    rw [Real.norm_eq_abs]
    exact (abs_coord_le_norm (ξ q) r).trans (hξ_norm q)

private lemma norm_euclMean_le {α₀ : Type} [MeasurableSpace α₀] {m : ℕ}
    (ν : MeasureTheory.Measure α₀) [MeasureTheory.IsProbabilityMeasure ν]
    {ξ : α₀ → EuclideanSpace ℝ (Fin m)} {B₀ : ℝ} (hB₀ : 0 < B₀)
    (hξ_meas : Measurable ξ) (hξ_norm : ∀ q, ‖ξ q‖ ≤ B₀) :
    ‖euclMean ν ξ‖ ≤ B₀ := by
  let μ_ξ := euclMean ν ξ
  have h_sq : ‖μ_ξ‖ ^ 2 = ∫ q, inner ℝ (ξ q) μ_ξ ∂ν := by
    rw [eucl_norm_sq_eq_sum]
    have h_term : ∀ r : Fin m, (μ_ξ r) ^ 2 = ∫ q, ξ q r * μ_ξ r ∂ν := by
      intro r
      have hμr : μ_ξ r = ∫ q, ξ q r ∂ν := rfl
      rw [sq, hμr]
      exact (MeasureTheory.integral_mul_const (μ_ξ r) (fun q => ξ q r)).symm
    simp_rw [h_term]
    rw [← MeasureTheory.integral_finset_sum Finset.univ
      (fun r _ => (integrable_eucl_coord ν hξ_meas hξ_norm r).mul_const (μ_ξ r))]
    refine MeasureTheory.integral_congr_ae (Filter.Eventually.of_forall fun q => ?_)
    exact (eucl_inner_eq_sum (ξ q) μ_ξ).symm
  have h_int_inner : MeasureTheory.Integrable (fun q => inner ℝ (ξ q) μ_ξ) ν := by
    have h_fn : (fun q => inner ℝ (ξ q) μ_ξ) = fun q => ∑ r : Fin m, ξ q r * μ_ξ r := by
      funext q
      exact eucl_inner_eq_sum (ξ q) μ_ξ
    rw [h_fn]
    exact MeasureTheory.integrable_finset_sum Finset.univ
      fun r _ => (integrable_eucl_coord ν hξ_meas hξ_norm r).mul_const (μ_ξ r)
  have h_le : ∫ q, inner ℝ (ξ q) μ_ξ ∂ν ≤ B₀ * ‖μ_ξ‖ := by
    calc ∫ q, inner ℝ (ξ q) μ_ξ ∂ν
        ≤ ∫ _ : α₀, (B₀ * ‖μ_ξ‖) ∂ν := by
          refine MeasureTheory.integral_mono h_int_inner
            (MeasureTheory.integrable_const (B₀ * ‖μ_ξ‖)) fun q => ?_
          calc inner ℝ (ξ q) μ_ξ
              ≤ |inner ℝ (ξ q) μ_ξ| := le_abs_self _
            _ ≤ ‖ξ q‖ * ‖μ_ξ‖ := abs_real_inner_le_norm _ _
            _ ≤ B₀ * ‖μ_ξ‖ := mul_le_mul_of_nonneg_right (hξ_norm q) (norm_nonneg μ_ξ)
      _ = B₀ * ‖μ_ξ‖ := by simp
  have h_nn : 0 ≤ ‖μ_ξ‖ := norm_nonneg μ_ξ
  nlinarith

private lemma integral_prod_eval_ne {α₀ : Type} [MeasurableSpace α₀]
    (ν : MeasureTheory.Measure α₀) [MeasureTheory.IsProbabilityMeasure ν]
    {n : ℕ} {i j : Fin n} (hij : i ≠ j)
    {φ : α₀ → ℝ} (hφ_meas : Measurable φ) (hφ_zero : ∫ q, φ q ∂ν = 0) :
    let π := MeasureTheory.Measure.pi (fun _ : Fin n => ν)
    ∫ z, φ (z i) * φ (z j) ∂π = 0 := by
  intro π
  haveI : MeasureTheory.IsProbabilityMeasure π :=
    inferInstanceAs (MeasureTheory.IsProbabilityMeasure (MeasureTheory.Measure.pi (fun _ : Fin n => ν)))
  have h_pi_indep : ProbabilityTheory.iIndepFun (fun k (z : Fin n → α₀) => z k) π := by
    rw [ProbabilityTheory.iIndepFun_iff_map_fun_eq_pi_map (fun k => (measurable_pi_apply k).aemeasurable)]
    have hid : (fun (z : Fin n → α₀) (k : Fin n) => z k) = id := rfl
    rw [hid, MeasureTheory.Measure.map_id]
    have h_ev : ∀ k : Fin n, MeasureTheory.Measure.map (fun z : Fin n → α₀ => z k) π = ν :=
      fun k => (MeasureTheory.measurePreserving_eval (fun _ : Fin n => ν) k).map_eq
    simp_rw [h_ev]
    rfl
  have hij_indep : ProbabilityTheory.IndepFun
      (fun z : Fin n → α₀ => z i) (fun z : Fin n → α₀ => z j) π :=
    h_pi_indep.indepFun hij
  have h_map_pair : MeasureTheory.Measure.map (fun z : Fin n → α₀ => (z i, z j)) π =
      ν.prod ν := by
    have hp := (ProbabilityTheory.indepFun_iff_map_prod_eq_prod_map_map
      (measurable_pi_apply i).aemeasurable (measurable_pi_apply j).aemeasurable).mp hij_indep
    rw [(MeasureTheory.measurePreserving_eval (fun _ : Fin n => ν) i).map_eq,
      (MeasureTheory.measurePreserving_eval (fun _ : Fin n => ν) j).map_eq] at hp
    exact hp
  have h_pair_meas : Measurable (fun z : Fin n → α₀ => (z i, z j)) :=
    (measurable_pi_apply i).prodMk (measurable_pi_apply j)
  have h_mul_meas : Measurable (fun p : α₀ × α₀ => φ p.1 * φ p.2) :=
    (hφ_meas.comp measurable_fst).mul (hφ_meas.comp measurable_snd)
  have h_eq1 : ∫ z, φ (z i) * φ (z j) ∂π = ∫ p, φ p.1 * φ p.2 ∂(ν.prod ν) := by
    rw [← h_map_pair, MeasureTheory.integral_map h_pair_meas.aemeasurable h_mul_meas.aestronglyMeasurable]
  rw [h_eq1, MeasureTheory.integral_prod_mul φ φ, hφ_zero, zero_mul]

private lemma integral_euclDev_sq_le {α₀ : Type} [MeasurableSpace α₀] {m : ℕ}
    (ν : MeasureTheory.Measure α₀) [MeasureTheory.IsProbabilityMeasure ν]
    {n : ℕ} (hn : 1 ≤ n) {ξ : α₀ → EuclideanSpace ℝ (Fin m)} {B₀ : ℝ} (hB₀ : 0 < B₀)
    (hξ_meas : Measurable ξ) (hξ_norm : ∀ q, ‖ξ q‖ ≤ B₀) :
    let π := MeasureTheory.Measure.pi (fun _ : Fin n => ν)
    ∫ z, (euclDev n ν ξ z) ^ 2 ∂π ≤ 4 * B₀ ^ 2 / (n : ℝ) := by
  intro π
  haveI : MeasureTheory.IsProbabilityMeasure π :=
    inferInstanceAs (MeasureTheory.IsProbabilityMeasure (MeasureTheory.Measure.pi (fun _ : Fin n => ν)))
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  have hn_ne : (n : ℝ) ≠ 0 := ne_of_gt hn_pos
  let μ_ξ := euclMean ν ξ
  let ξc : α₀ → EuclideanSpace ℝ (Fin m) := fun q => ξ q - μ_ξ
  have hμ_le : ‖μ_ξ‖ ≤ B₀ := norm_euclMean_le ν hB₀ hξ_meas hξ_norm
  have hξc_meas : Measurable ξc := hξ_meas.sub measurable_const
  have hξc_norm : ∀ q, ‖ξc q‖ ≤ 2 * B₀ := by
    intro q
    calc ‖ξ q - μ_ξ‖ ≤ ‖ξ q‖ + ‖μ_ξ‖ := norm_sub_le _ _
      _ ≤ B₀ + B₀ := add_le_add (hξ_norm q) hμ_le
      _ = 2 * B₀ := by ring
  have hξc_zero : ∀ r : Fin m, ∫ q, ξc q r ∂ν = 0 := by
    intro r
    have h_sub : (fun q => ξc q r) = fun q => ξ q r - μ_ξ r := rfl
    rw [h_sub, MeasureTheory.integral_sub (integrable_eucl_coord ν hξ_meas hξ_norm r)
      (MeasureTheory.integrable_const (μ_ξ r))]
    have h_const : ∫ _ : α₀, μ_ξ r ∂ν = μ_ξ r := by simp
    rw [h_const]
    exact sub_self _
  have h_dev_eq : ∀ z : Fin n → α₀,
      (euclDev n ν ξ z) ^ 2 =
        (1 / (n : ℝ) ^ 2) * ∑ r : Fin m, ∑ i : Fin n, ∑ j : Fin n, ξc (z i) r * ξc (z j) r := by
    intro z
    have h_vec : euclEmp n ξ z - μ_ξ = (1 / (n : ℝ)) • ∑ i : Fin n, ξc (z i) := by
      dsimp [euclEmp, ξc]
      rw [Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
        smul_sub, ← Nat.cast_smul_eq_nsmul ℝ, smul_smul, one_div_mul_cancel hn_ne, one_smul]
    unfold euclDev
    rw [h_vec, norm_smul, Real.norm_eq_abs, mul_pow, sq_abs, one_div, inv_pow, ← one_div,
      eucl_norm_sq_eq_sum]
    congr 1
    refine Finset.sum_congr rfl fun r _ => ?_
    rw [sum_apply_eucl, sq, Finset.sum_mul]
    refine Finset.sum_congr rfl fun i _ => ?_
    rw [Finset.mul_sum]
  have h_prod_int : ∀ (r : Fin m) (i j : Fin n),
      MeasureTheory.Integrable (fun z : Fin n → α₀ => ξc (z i) r * ξc (z j) r) π := by
    intro r i j
    have hm_r : Measurable (fun q => ξc q r) :=
      (PiLp.continuous_apply 2 (fun _ : Fin m => ℝ) r).measurable.comp hξc_meas
    have hm_ij : Measurable (fun z : Fin n → α₀ => ξc (z i) r * ξc (z j) r) :=
      (hm_r.comp (measurable_pi_apply i)).mul (hm_r.comp (measurable_pi_apply j))
    refine (MeasureTheory.integrable_const (4 * B₀ ^ 2)).mono' hm_ij.aestronglyMeasurable ?_
    exact Filter.Eventually.of_forall fun z => by
      rw [Real.norm_eq_abs, abs_mul]
      have hi : |ξc (z i) r| ≤ 2 * B₀ := (abs_coord_le_norm _ _).trans (hξc_norm (z i))
      have hj : |ξc (z j) r| ≤ 2 * B₀ := (abs_coord_le_norm _ _).trans (hξc_norm (z j))
      calc |ξc (z i) r| * |ξc (z j) r|
          ≤ (2 * B₀) * (2 * B₀) := mul_le_mul hi hj (abs_nonneg _) (by positivity)
        _ = 4 * B₀ ^ 2 := by ring
  have h_fn_eq : (fun z : Fin n → α₀ => (euclDev n ν ξ z) ^ 2) =
      fun z => (1 / (n : ℝ) ^ 2) *
        ∑ r : Fin m, ∑ i : Fin n, ∑ j : Fin n, ξc (z i) r * ξc (z j) r :=
    funext h_dev_eq
  rw [h_fn_eq, MeasureTheory.integral_const_mul,
    MeasureTheory.integral_finset_sum Finset.univ (fun r _ =>
      MeasureTheory.integrable_finset_sum Finset.univ fun i _ =>
        MeasureTheory.integrable_finset_sum Finset.univ fun j _ => h_prod_int r i j)]
  have h_int_r : ∀ r : Fin m,
      (∫ z, (∑ i : Fin n, ∑ j : Fin n, ξc (z i) r * ξc (z j) r) ∂π) =
        ∑ i : Fin n, ∫ z, (ξc (z i) r) ^ 2 ∂π := by
    intro r
    rw [MeasureTheory.integral_finset_sum Finset.univ (fun i _ =>
      MeasureTheory.integrable_finset_sum Finset.univ fun j _ => h_prod_int r i j)]
    refine Finset.sum_congr rfl fun i _ => ?_
    rw [MeasureTheory.integral_finset_sum Finset.univ (fun j _ => h_prod_int r i j)]
    rw [Finset.sum_eq_single i]
    · simp_rw [sq]
    · intro j _ hji
      have hm_r : Measurable (fun q => ξc q r) :=
        (PiLp.continuous_apply 2 (fun _ : Fin m => ℝ) r).measurable.comp hξc_meas
      exact integral_prod_eval_ne ν hji.symm hm_r (hξc_zero r)
    · intro hi; exact absurd (Finset.mem_univ i) hi
  simp_rw [h_int_r]
  rw [Finset.sum_comm]
  have h_diag : ∀ i : Fin n,
      ∑ r : Fin m, ∫ z, (ξc (z i) r) ^ 2 ∂π ≤ 4 * B₀ ^ 2 := by
    intro i
    have h_ev_r : ∀ r : Fin m, ∫ z, (ξc (z i) r) ^ 2 ∂π = ∫ q, (ξc q r) ^ 2 ∂ν := by
      intro r
      have hm_sq : Measurable (fun q => (ξc q r) ^ 2) :=
        ((PiLp.continuous_apply 2 (fun _ : Fin m => ℝ) r).measurable.comp hξc_meas).pow_const 2
      have hev := (MeasureTheory.measurePreserving_eval (fun _ : Fin n => ν) i).map_eq
      rw [← hev, MeasureTheory.integral_map (measurable_pi_apply i).aemeasurable hm_sq.aestronglyMeasurable]
    simp_rw [h_ev_r]
    have h_sq_int : ∀ r : Fin m, MeasureTheory.Integrable (fun q => (ξc q r) ^ 2) ν := by
      intro r
      have hm_sq : Measurable (fun q => (ξc q r) ^ 2) :=
        ((PiLp.continuous_apply 2 (fun _ : Fin m => ℝ) r).measurable.comp hξc_meas).pow_const 2
      refine (MeasureTheory.integrable_const (4 * B₀ ^ 2)).mono' hm_sq.aestronglyMeasurable ?_
      exact Filter.Eventually.of_forall fun q => by
        rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _), ← sq_abs]
        have h1 : |ξc q r| ≤ 2 * B₀ := (abs_coord_le_norm _ _).trans (hξc_norm q)
        calc |ξc q r| ^ 2 ≤ (2 * B₀) ^ 2 := pow_le_pow_left₀ (abs_nonneg _) h1 2
          _ = 4 * B₀ ^ 2 := by ring
    rw [← MeasureTheory.integral_finset_sum Finset.univ (fun r _ => h_sq_int r)]
    calc ∫ q, (∑ r : Fin m, (ξc q r) ^ 2) ∂ν
        ≤ ∫ _ : α₀, (4 * B₀ ^ 2) ∂ν := by
          refine MeasureTheory.integral_mono
            (MeasureTheory.integrable_finset_sum Finset.univ fun r _ => h_sq_int r)
            (MeasureTheory.integrable_const (4 * B₀ ^ 2)) fun q => ?_
          rw [← eucl_norm_sq_eq_sum]
          calc ‖ξc q‖ ^ 2 ≤ (2 * B₀) ^ 2 := pow_le_pow_left₀ (norm_nonneg _) (hξc_norm q) 2
            _ = 4 * B₀ ^ 2 := by ring
      _ = 4 * B₀ ^ 2 := by simp
  have h_sum_le : ∑ i : Fin n, ∑ r : Fin m, ∫ z, (ξc (z i) r) ^ 2 ∂π ≤
      (n : ℝ) * (4 * B₀ ^ 2) := by
    calc ∑ i : Fin n, ∑ r : Fin m, ∫ z, (ξc (z i) r) ^ 2 ∂π
        ≤ ∑ _ : Fin n, (4 * B₀ ^ 2) := Finset.sum_le_sum fun i _ => h_diag i
      _ = (n : ℝ) * (4 * B₀ ^ 2) := by simp
  calc (1 / (n : ℝ) ^ 2) * ∑ i : Fin n, ∑ r : Fin m, ∫ z, (ξc (z i) r) ^ 2 ∂π
      ≤ (1 / (n : ℝ) ^ 2) * ((n : ℝ) * (4 * B₀ ^ 2)) :=
        mul_le_mul_of_nonneg_left h_sum_le (by positivity)
    _ = 4 * B₀ ^ 2 / (n : ℝ) := by field_simp

private lemma euclDev_le_two_mul {α₀ : Type} [MeasurableSpace α₀] {m : ℕ}
    (ν : MeasureTheory.Measure α₀) [MeasureTheory.IsProbabilityMeasure ν]
    {n : ℕ} (hn : 1 ≤ n) {ξ : α₀ → EuclideanSpace ℝ (Fin m)} {B₀ : ℝ} (hB₀ : 0 < B₀)
    (hξ_meas : Measurable ξ) (hξ_norm : ∀ q, ‖ξ q‖ ≤ B₀) (z : Fin n → α₀) :
    euclDev n ν ξ z ≤ 2 * B₀ := by
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  unfold euclDev euclEmp
  calc ‖(1 / (n : ℝ)) • (∑ i : Fin n, ξ (z i)) - euclMean ν ξ‖
      ≤ ‖(1 / (n : ℝ)) • ∑ i : Fin n, ξ (z i)‖ + ‖euclMean ν ξ‖ := norm_sub_le _ _
    _ ≤ (1 / (n : ℝ)) * (∑ i : Fin n, ‖ξ (z i)‖) + B₀ := by
        refine add_le_add ?_ (norm_euclMean_le ν hB₀ hξ_meas hξ_norm)
        rw [norm_smul, Real.norm_eq_abs, abs_of_pos (one_div_pos.mpr hn_pos)]
        exact mul_le_mul_of_nonneg_left (norm_sum_le _ _) (by positivity)
    _ ≤ (1 / (n : ℝ)) * (∑ _ : Fin n, B₀) + B₀ := by
        gcongr with i
        exact hξ_norm (z i)
    _ = 2 * B₀ := by
        simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
        field_simp
        ring

private lemma integral_euclDev_le {α₀ : Type} [MeasurableSpace α₀] {m : ℕ}
    (ν : MeasureTheory.Measure α₀) [MeasureTheory.IsProbabilityMeasure ν]
    {n : ℕ} (hn : 1 ≤ n) {ξ : α₀ → EuclideanSpace ℝ (Fin m)} {B₀ : ℝ} (hB₀ : 0 < B₀)
    (hξ_meas : Measurable ξ) (hξ_norm : ∀ q, ‖ξ q‖ ≤ B₀) :
    let π := MeasureTheory.Measure.pi (fun _ : Fin n => ν)
    ∫ z, euclDev n ν ξ z ∂π ≤ 2 * B₀ / Real.sqrt (n : ℝ) := by
  intro π
  haveI : MeasureTheory.IsProbabilityMeasure π :=
    inferInstanceAs (MeasureTheory.IsProbabilityMeasure (MeasureTheory.Measure.pi (fun _ : Fin n => ν)))
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  let s : ℝ := 2 * B₀ / Real.sqrt (n : ℝ)
  have hs_pos : 0 < s := by dsimp [s]; positivity
  have hg_meas : Measurable (euclDev n ν ξ) := measurable_euclDev n ν hξ_meas
  have hg_nn : ∀ z : Fin n → α₀, 0 ≤ euclDev n ν ξ z := fun _ => norm_nonneg _
  have hg_int : MeasureTheory.Integrable (euclDev n ν ξ) π := by
    refine (MeasureTheory.integrable_const (2 * B₀)).mono' hg_meas.aestronglyMeasurable ?_
    exact Filter.Eventually.of_forall fun z => by
      rw [Real.norm_eq_abs, abs_of_nonneg (hg_nn z)]
      exact euclDev_le_two_mul ν hn hB₀ hξ_meas hξ_norm z
  have hg2_int : MeasureTheory.Integrable (fun z => (euclDev n ν ξ z) ^ 2) π := by
    refine (MeasureTheory.integrable_const (4 * B₀ ^ 2)).mono'
      (hg_meas.pow_const 2).aestronglyMeasurable ?_
    exact Filter.Eventually.of_forall fun z => by
      rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
      have h1 := euclDev_le_two_mul ν hn hB₀ hξ_meas hξ_norm z
      calc (euclDev n ν ξ z) ^ 2 ≤ (2 * B₀) ^ 2 := pow_le_pow_left₀ (hg_nn z) h1 2
        _ = 4 * B₀ ^ 2 := by ring
  have h_amgm : ∀ z : Fin n → α₀,
      euclDev n ν ξ z ≤ (euclDev n ν ξ z) ^ 2 / (2 * s) + s / 2 := by
    intro z
    have h_rhs_eq : (euclDev n ν ξ z) ^ 2 / (2 * s) + s / 2 =
        ((euclDev n ν ξ z) ^ 2 + s ^ 2) / (2 * s) := by
      field_simp [ne_of_gt hs_pos]
    rw [h_rhs_eq, le_div_iff₀ (by positivity : 0 < 2 * s)]
    nlinarith [sq_nonneg (euclDev n ν ξ z - s)]
  have hs_sq : 4 * B₀ ^ 2 / (n : ℝ) = s ^ 2 := by
    dsimp [s]
    rw [div_pow, mul_pow, Real.sq_sqrt hn_pos.le]
    ring
  calc ∫ z, euclDev n ν ξ z ∂π
      ≤ ∫ z, ((euclDev n ν ξ z) ^ 2 / (2 * s) + s / 2) ∂π :=
        MeasureTheory.integral_mono hg_int
          ((hg2_int.div_const (2 * s)).add (MeasureTheory.integrable_const (s / 2))) h_amgm
    _ = (∫ z, (euclDev n ν ξ z) ^ 2 ∂π) / (2 * s) + s / 2 := by
        rw [MeasureTheory.integral_add (hg2_int.div_const (2 * s))
          (MeasureTheory.integrable_const (s / 2)), MeasureTheory.integral_div]
        simp
    _ ≤ (4 * B₀ ^ 2 / (n : ℝ)) / (2 * s) + s / 2 := by
        gcongr
        exact integral_euclDev_sq_le ν hn hB₀ hξ_meas hξ_norm
    _ = s := by
        rw [hs_sq]
        field_simp [ne_of_gt hs_pos]
        ring

private lemma euclDev_diff_le {α₀ : Type} [MeasurableSpace α₀] {m : ℕ}
    (ν : MeasureTheory.Measure α₀) {n : ℕ} (hn : 1 ≤ n)
    {ξ : α₀ → EuclideanSpace ℝ (Fin m)} {B₀ : ℝ}
    (hξ_norm : ∀ q, ‖ξ q‖ ≤ B₀)
    (i : Fin n) (z : Fin n → α₀) (z' : α₀) :
    |euclDev n ν ξ z - euclDev n ν ξ (Function.update z i z')| ≤ 2 * B₀ / (n : ℝ) := by
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  unfold euclDev
  have h_sub : (euclEmp n ξ z - euclMean ν ξ) -
      (euclEmp n ξ (Function.update z i z') - euclMean ν ξ) =
      (1 / (n : ℝ)) • (ξ (z i) - ξ z') := by
    unfold euclEmp
    rw [sub_sub_sub_cancel_right, ← smul_sub, ← Finset.sum_sub_distrib]
    congr 1
    rw [Finset.sum_eq_single i]
    · simp
    · intro j _ hji
      simp [hji]
    · intro hi; exact absurd (Finset.mem_univ i) hi
  calc |‖euclEmp n ξ z - euclMean ν ξ‖ - ‖euclEmp n ξ (Function.update z i z') - euclMean ν ξ‖|
      ≤ ‖(euclEmp n ξ z - euclMean ν ξ) - (euclEmp n ξ (Function.update z i z') - euclMean ν ξ)‖ :=
        abs_norm_sub_norm_le _ _
    _ = ‖(1 / (n : ℝ)) • (ξ (z i) - ξ z')‖ := by rw [h_sub]
    _ = (1 / (n : ℝ)) * ‖ξ (z i) - ξ z'‖ := by
        rw [norm_smul, Real.norm_eq_abs, abs_of_pos (one_div_pos.mpr hn_pos)]
    _ ≤ (1 / (n : ℝ)) * (‖ξ (z i)‖ + ‖ξ z'‖) :=
        mul_le_mul_of_nonneg_left (norm_sub_le _ _) (by positivity)
    _ ≤ (1 / (n : ℝ)) * (B₀ + B₀) :=
        mul_le_mul_of_nonneg_left (add_le_add (hξ_norm (z i)) (hξ_norm z')) (by positivity)
    _ = 2 * B₀ / (n : ℝ) := by ring

private lemma rad_combine_third {n : ℕ} (hn : 1 ≤ n) {B₀ δ : ℝ}
    (hB₀ : 0 < B₀) (hδ0 : 0 < δ) (hδ1 : δ < (1 : ℝ) / 2)
    {v_val m_val : ℝ}
    (hm : m_val ≤ 2 * B₀ / Real.sqrt (n : ℝ))
    (hv : |v_val - m_val| ≤
      Real.sqrt ((1 / 2 : ℝ) * ((n : ℝ) * (2 * B₀ / (n : ℝ)) ^ 2) * Real.log (2 / (δ / 3)))) :
    v_val ≤ 4 * B₀ * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ)) := by
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  have h4_lt : (4 : ℝ) < (2 : ℝ) / δ := by
    rw [lt_div_iff₀ hδ0]
    linarith
  have hexp1_lt : Real.exp 1 < (2 : ℝ) / δ :=
    lt_trans (lt_trans Real.exp_one_lt_d9 (by norm_num)) h4_lt
  have h1_le_log : (1 : ℝ) ≤ Real.log ((2 : ℝ) / δ) := by
    rw [← Real.log_exp 1]
    exact Real.log_le_log (Real.exp_pos 1) hexp1_lt.le
  have hlog_pos : 0 < Real.log ((2 : ℝ) / δ) := lt_of_lt_of_le zero_lt_one h1_le_log
  have h1_le_sqrt_log : (1 : ℝ) ≤ Real.sqrt (Real.log ((2 : ℝ) / δ)) := by
    rw [← Real.sqrt_one]
    exact Real.sqrt_le_sqrt h1_le_log
  have hm_le : 2 * B₀ / Real.sqrt (n : ℝ) ≤
      2 * B₀ * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ)) := by
    rw [Real.sqrt_div hlog_pos.le (n : ℝ)]
    have h_mul := mul_le_mul_of_nonneg_left h1_le_sqrt_log
      (by positivity : 0 ≤ 2 * B₀ / Real.sqrt (n : ℝ))
    linarith [show (2 * B₀ / Real.sqrt (n : ℝ)) * Real.sqrt (Real.log ((2 : ℝ) / δ)) =
      2 * B₀ * (Real.sqrt (Real.log ((2 : ℝ) / δ)) / Real.sqrt (n : ℝ)) by ring]
  have h_arg_le : 2 / (δ / 3) ≤ ((2 : ℝ) / δ) ^ 2 := by
    have h_eq1 : 2 / (δ / 3) = 6 / δ := by ring
    rw [h_eq1, div_pow, div_le_div_iff₀ hδ0 (pow_pos hδ0 2)]
    nlinarith
  have h_log6 : Real.log (2 / (δ / 3)) ≤ 2 * Real.log ((2 : ℝ) / δ) := by
    calc Real.log (2 / (δ / 3))
        ≤ Real.log (((2 : ℝ) / δ) ^ 2) := Real.log_le_log (by positivity) h_arg_le
      _ = 2 * Real.log ((2 : ℝ) / δ) := by rw [Real.log_pow]; push_cast; ring
  have h_rad_le :
      Real.sqrt ((1 / 2 : ℝ) * ((n : ℝ) * (2 * B₀ / (n : ℝ)) ^ 2) * Real.log (2 / (δ / 3))) ≤
        2 * B₀ * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ)) := by
    have h_in :
        (1 / 2 : ℝ) * ((n : ℝ) * (2 * B₀ / (n : ℝ)) ^ 2) * Real.log (2 / (δ / 3)) ≤
          (2 * B₀ * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ))) ^ 2 := by
      have h_lhs :
          (1 / 2 : ℝ) * ((n : ℝ) * (2 * B₀ / (n : ℝ)) ^ 2) * Real.log (2 / (δ / 3)) =
            (2 * B₀ ^ 2 / (n : ℝ)) * Real.log (2 / (δ / 3)) := by
        field_simp
      have h_rhs :
          (2 * B₀ * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ))) ^ 2 =
            (2 * B₀ ^ 2 / (n : ℝ)) * (2 * Real.log ((2 : ℝ) / δ)) := by
        rw [mul_pow, mul_pow, Real.sq_sqrt (by positivity)]
        ring
      rw [h_lhs, h_rhs]
      exact mul_le_mul_of_nonneg_left h_log6 (by positivity)
    exact (Real.sqrt_le_sqrt h_in).trans (Real.sqrt_sq (by positivity)).le
  have hv_sub : v_val - m_val ≤ |v_val - m_val| := le_abs_self _
  linarith

private theorem eucl_mean_concentration.{u₁, u₂}
    (h_mc : UL.S_cit_mcdiarmid1989.{u₁, u₂})
    {α₀ : Type} [MeasurableSpace α₀]
    (ν : MeasureTheory.Measure α₀) [MeasureTheory.IsProbabilityMeasure ν]
    {n m : ℕ} (hn : 1 ≤ n)
    {B₀ δ : ℝ} (hB₀ : 0 < B₀) (hδ0 : 0 < δ) (hδ1 : δ < (1 : ℝ) / 2)
    (ξ : α₀ → EuclideanSpace ℝ (Fin m))
    (hξ_meas : Measurable ξ) (hξ_norm : ∀ q, ‖ξ q‖ ≤ B₀) :
    let π := MeasureTheory.Measure.pi (fun _ : Fin n => ν)
    let G : Set (Fin n → α₀) :=
      {z | euclDev n ν ξ z ≤ 4 * B₀ * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ))}
    MeasurableSet G ∧ (π G).toReal ≥ 1 - δ / 3 := by
  intro π G
  haveI : MeasureTheory.IsProbabilityMeasure π :=
    inferInstanceAs (MeasureTheory.IsProbabilityMeasure (MeasureTheory.Measure.pi (fun _ : Fin n => ν)))
  have hg_meas : Measurable (euclDev n ν ξ) := measurable_euclDev n ν hξ_meas
  have hG_meas : MeasurableSet G := measurableSet_le hg_meas measurable_const
  refine ⟨hG_meas, ?_⟩
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  have hd₀ : 0 ≤ 2 * B₀ / (n : ℝ) := by positivity
  have h_mc_prob := mcdiarmid_pi_alpha0.{u₁, u₂} h_mc ν n (euclDev n ν ξ) hg_meas
    (2 * B₀ / (n : ℝ)) hd₀ (euclDev_diff_le ν hn hξ_norm) (δ / 3) (by linarith) (by linarith)
  dsimp only at h_mc_prob
  have hm_le : ∫ z', euclDev n ν ξ z' ∂π ≤ 2 * B₀ / Real.sqrt (n : ℝ) :=
    integral_euclDev_le ν hn hB₀ hξ_meas hξ_norm
  have h_sub :
      {z : Fin n → α₀ | |euclDev n ν ξ z - ∫ z', euclDev n ν ξ z' ∂π| ≤
        Real.sqrt ((1 / 2 : ℝ) * ((n : ℝ) * (2 * B₀ / (n : ℝ)) ^ 2) * Real.log (2 / (δ / 3)))} ⊆
      G := by
    intro z hz
    exact rad_combine_third hn hB₀ hδ0 hδ1 hm_le hz
  exact h_mc_prob.trans (ENNReal.toReal_mono (MeasureTheory.measure_ne_top π G)
    (MeasureTheory.measure_mono h_sub))

private lemma integrable_inner_eucl {α₀ : Type} [MeasurableSpace α₀] {m : ℕ}
    (ν : MeasureTheory.Measure α₀) [MeasureTheory.IsProbabilityMeasure ν]
    {ξ : α₀ → EuclideanSpace ℝ (Fin m)} {B₀ : ℝ}
    (hξ_meas : Measurable ξ) (hξ_norm : ∀ q, ‖ξ q‖ ≤ B₀)
    (w : EuclideanSpace ℝ (Fin m)) :
    MeasureTheory.Integrable (fun q => inner ℝ (ξ q) w) ν := by
  have h_fn : (fun q => inner ℝ (ξ q) w) = fun q => ∑ r : Fin m, ξ q r * w r :=
    funext fun q => eucl_inner_eq_sum (ξ q) w
  rw [h_fn]
  exact MeasureTheory.integrable_finset_sum Finset.univ
    fun r _ => (integrable_eucl_coord ν hξ_meas hξ_norm r).mul_const (w r)

private lemma abs_integral_sub_emp_inner_le {α₀ : Type} [MeasurableSpace α₀] {m : ℕ}
    (ν : MeasureTheory.Measure α₀) [MeasureTheory.IsProbabilityMeasure ν]
    (n : ℕ) {ξ : α₀ → EuclideanSpace ℝ (Fin m)} {B₀ : ℝ}
    (hξ_meas : Measurable ξ) (hξ_norm : ∀ q, ‖ξ q‖ ≤ B₀)
    (w : EuclideanSpace ℝ (Fin m)) (z : Fin n → α₀) :
    |(∫ q, inner ℝ (ξ q) w ∂ν) - (1 / (n : ℝ)) * ∑ i : Fin n, inner ℝ (ξ (z i)) w| ≤
      euclDev n ν ξ z * ‖w‖ := by
  have h_int_eq : (∫ q, inner ℝ (ξ q) w ∂ν) = inner ℝ (euclMean ν ξ) w := by
    have h_fn : (fun q => inner ℝ (ξ q) w) = fun q => ∑ r : Fin m, ξ q r * w r :=
      funext fun q => eucl_inner_eq_sum (ξ q) w
    rw [h_fn, MeasureTheory.integral_finset_sum Finset.univ
      (fun r _ => (integrable_eucl_coord ν hξ_meas hξ_norm r).mul_const (w r))]
    have h_term : ∀ r : Fin m, (∫ q, ξ q r * w r ∂ν) = euclMean ν ξ r * w r :=
      fun r => MeasureTheory.integral_mul_const (w r) (fun q => ξ q r)
    simp_rw [h_term]
    exact (eucl_inner_eq_sum (euclMean ν ξ) w).symm
  have h_emp_eq : (1 / (n : ℝ)) * (∑ i : Fin n, inner ℝ (ξ (z i)) w) =
      inner ℝ (euclEmp n ξ z) w := by
    unfold euclEmp
    rw [inner_smul_left, conj_trivial, sum_inner]
  rw [h_int_eq, h_emp_eq]
  have h_diff : inner ℝ (euclMean ν ξ) w - inner ℝ (euclEmp n ξ z) w =
      -inner ℝ (euclEmp n ξ z - euclMean ν ξ) w := by
    rw [inner_sub_left, neg_sub]
  rw [h_diff, abs_neg]
  exact abs_real_inner_le_norm (euclEmp n ξ z - euclMean ν ξ) w

/-! ### Clamped Feature, Centered Label, Tensor Product, and Hilbert-Schmidt Vectorization -/

open Classical in
private noncomputable def xClamp {d : ℕ} (L : ℝ) (x : EuclideanSpace ℝ (Fin d)) :
    EuclideanSpace ℝ (Fin d) :=
  if ‖x‖ ≤ L then x else 0

private lemma measurable_xClamp {d : ℕ} (L : ℝ) : Measurable (xClamp (d := d) L) := by
  classical
  unfold xClamp
  exact Measurable.ite (measurableSet_le measurable_id.norm measurable_const)
    measurable_id measurable_const

private lemma norm_xClamp_le {d : ℕ} {L : ℝ} (hL : 0 < L) (x : EuclideanSpace ℝ (Fin d)) :
    ‖xClamp L x‖ ≤ L := by
  unfold xClamp
  split_ifs with hx
  · exact hx
  · simp [hL.le]

private lemma xClamp_of_le {d : ℕ} {L : ℝ} {x : EuclideanSpace ℝ (Fin d)} (hx : ‖x‖ ≤ L) :
    xClamp L x = x := by
  unfold xClamp
  exact if_pos hx

private noncomputable def zVec (K : ℕ) (y : Fin K) : EuclideanSpace ℝ (Fin K) :=
  EuclideanSpace.single y (1 : ℝ) - UL.uniformVec K

private lemma norm_zVec_le {K : ℕ} (hK : 2 ≤ K) (y : Fin K) :
    ‖zVec K y‖ ≤ 1 := by
  have hK_pos : (0 : ℝ) < (K : ℝ) := Nat.cast_pos.mpr (by omega)
  have hK_ne : (K : ℝ) ≠ 0 := ne_of_gt hK_pos
  have hsq : ‖zVec K y‖ ^ 2 ≤ 1 := by
    rw [eucl_norm_sq_eq_sum]
    have h_coord : ∀ k : Fin K,
        (zVec K y k) ^ 2 =
          (EuclideanSpace.single y (1 : ℝ) k) ^ 2 -
            (2 / (K : ℝ)) * EuclideanSpace.single y (1 : ℝ) k + 1 / (K : ℝ) ^ 2 := by
      intro k
      have hu : UL.uniformVec K k = (1 : ℝ) / (K : ℝ) := by
        simp [UL.uniformVec, UL.onesVec]
      change (EuclideanSpace.single y (1 : ℝ) k - UL.uniformVec K k) ^ 2 = _
      rw [hu]
      ring
    simp_rw [h_coord, Finset.sum_add_distrib, Finset.sum_sub_distrib, ← Finset.mul_sum]
    have hs1 : ∑ k : Fin K, EuclideanSpace.single y (1 : ℝ) k = 1 := by
      simp [EuclideanSpace.single_apply]
    have hs2 : ∑ k : Fin K, (EuclideanSpace.single y (1 : ℝ) k) ^ 2 = 1 := by
      rw [Finset.sum_eq_single y]
      · simp [EuclideanSpace.single_apply]
      · intro k _ hky
        simp [EuclideanSpace.single_apply, hky]
      · intro hy; exact absurd (Finset.mem_univ y) hy
    have hs3 : ∑ _ : Fin K, (1 / (K : ℝ) ^ 2) = 1 / (K : ℝ) := by
      simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
      field_simp
    rw [hs1, hs2, hs3]
    have h_inv_nonneg : 0 ≤ 1 / (K : ℝ) := by positivity
    have h_alg_k : (1 : ℝ) - (2 / (K : ℝ)) * 1 + 1 / (K : ℝ) = 1 - 1 / (K : ℝ) := by ring
    rw [h_alg_k]
    linarith
  have h0 : 0 ≤ ‖zVec K y‖ := norm_nonneg _
  nlinarith

private noncomputable def zxVec {d K : ℕ} (L : ℝ)
    (xy : EuclideanSpace ℝ (Fin d) × Fin K) :
    EuclideanSpace ℝ (Fin (K * d)) :=
  (WithLp.equiv 2 (Fin (K * d) → ℝ)).symm fun q =>
    zVec K xy.2 (finProdFinEquiv.symm q).1 * xClamp L xy.1 (finProdFinEquiv.symm q).2

private lemma measurable_zxVec {d K : ℕ} (L : ℝ) :
    Measurable (zxVec (d := d) (K := K) L) := by
  unfold zxVec
  refine (PiLp.continuous_toLp 2 (fun _ : Fin (K * d) => ℝ)).measurable.comp
    (measurable_pi_lambda _ fun q => ?_)
  have hm1 : Measurable (fun xy : EuclideanSpace ℝ (Fin d) × Fin K =>
      zVec K xy.2 (finProdFinEquiv.symm q).1) :=
    (Measurable.of_discrete (f := fun y : Fin K => zVec K y (finProdFinEquiv.symm q).1)).comp
      measurable_snd
  have hm2 : Measurable (fun xy : EuclideanSpace ℝ (Fin d) × Fin K =>
      xClamp L xy.1 (finProdFinEquiv.symm q).2) :=
    (PiLp.continuous_apply 2 (fun _ : Fin d => ℝ) (finProdFinEquiv.symm q).2).measurable.comp
      ((measurable_xClamp L).comp measurable_fst)
  exact hm1.mul hm2

private lemma norm_zxVec_le {d K : ℕ} {L : ℝ} (hL : 0 < L) (hK : 2 ≤ K)
    (xy : EuclideanSpace ℝ (Fin d) × Fin K) :
    ‖zxVec L xy‖ ≤ L := by
  have hsq : ‖zxVec L xy‖ ^ 2 ≤ L ^ 2 := by
    rw [eucl_norm_sq_eq_sum]
    have h_prod : ∑ q : Fin (K * d), (zxVec L xy q) ^ 2 =
        (∑ k : Fin K, (zVec K xy.2 k) ^ 2) * (∑ j : Fin d, (xClamp L xy.1 j) ^ 2) := by
      have h1 := finProdFinEquiv.symm.sum_comp
        (fun kj : Fin K × Fin d => (zVec K xy.2 kj.1 * xClamp L xy.1 kj.2) ^ 2)
      change ∑ q : Fin (K * d), (zxVec L xy q) ^ 2 = _ at h1
      rw [h1, Fintype.sum_prod_type' (fun k j => (zVec K xy.2 k * xClamp L xy.1 j) ^ 2),
        Finset.sum_mul]
      refine Finset.sum_congr rfl fun k _ => ?_
      rw [Finset.mul_sum]
      refine Finset.sum_congr rfl fun j _ => ?_
      ring
    rw [h_prod, ← eucl_norm_sq_eq_sum, ← eucl_norm_sq_eq_sum]
    have hz : ‖zVec K xy.2‖ ^ 2 ≤ 1 := by
      have h1 := norm_zVec_le hK xy.2
      nlinarith [norm_nonneg (zVec K xy.2)]
    have hx : ‖xClamp L xy.1‖ ^ 2 ≤ L ^ 2 :=
      pow_le_pow_left₀ (norm_nonneg _) (norm_xClamp_le hL xy.1) 2
    nlinarith [sq_nonneg ‖xClamp L xy.1‖]
  have h0 : 0 ≤ ‖zxVec L xy‖ := norm_nonneg _
  nlinarith

private noncomputable def opVec {d K : ℕ}
    (B : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin K)) :
    EuclideanSpace ℝ (Fin (K * d)) :=
  (WithLp.equiv 2 (Fin (K * d) → ℝ)).symm fun q =>
    (B (EuclideanSpace.single (finProdFinEquiv.symm q).2 (1 : ℝ)))
      (finProdFinEquiv.symm q).1

private lemma inner_zVec_apply_eq {d K : ℕ} {L : ℝ}
    (B : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin K))
    {x : EuclideanSpace ℝ (Fin d)} (hx : ‖x‖ ≤ L) (y : Fin K) :
    inner ℝ (zVec K y) (B x) = inner ℝ (zxVec L (x, y)) (opVec B) := by
  have hx_sum : B x = ∑ j : Fin d, (x j) • B (EuclideanSpace.single j (1 : ℝ)) := by
    conv_lhs => rw [eucl_eq_sum_single x]
    rw [map_sum]
    refine Finset.sum_congr rfl fun j _ => ?_
    exact B.map_smul (x j) (EuclideanSpace.single j (1 : ℝ))
  rw [eucl_inner_eq_sum, eucl_inner_eq_sum]
  have h_rhs : ∑ q : Fin (K * d), zxVec L (x, y) q * opVec B q =
      ∑ k : Fin K, ∑ j : Fin d,
        (zVec K y k * x j) * (B (EuclideanSpace.single j (1 : ℝ)) k) := by
    have h_clamp : xClamp L x = x := xClamp_of_le hx
    have h1 := finProdFinEquiv.symm.sum_comp
      (fun kj : Fin K × Fin d =>
        (zVec K y kj.1 * xClamp L x kj.2) * (B (EuclideanSpace.single kj.2 (1 : ℝ)) kj.1))
    change ∑ q : Fin (K * d), zxVec L (x, y) q * opVec B q = _ at h1
    rw [h1, Fintype.sum_prod_type' (fun k j =>
      (zVec K y k * xClamp L x j) * (B (EuclideanSpace.single j (1 : ℝ)) k)), h_clamp]
  rw [h_rhs, hx_sum]
  refine Finset.sum_congr rfl fun k _ => ?_
  rw [sum_apply_eucl, Finset.mul_sum]
  refine Finset.sum_congr rfl fun j _ => ?_
  change zVec K y k * (x j * B (EuclideanSpace.single j (1 : ℝ)) k) = _
  ring

private lemma norm_opVec_eq {d K : ℕ}
    (B : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin K)) :
    ‖opVec B‖ = UL.hilbertSchmidtNorm B := by
  have h1 : ‖opVec B‖ ^ 2 = ∑ j : Fin d, ‖B (EuclideanSpace.single j (1 : ℝ))‖ ^ 2 := by
    rw [eucl_norm_sq_eq_sum]
    have h_eq : ∑ q : Fin (K * d), (opVec B q) ^ 2 =
        ∑ k : Fin K, ∑ j : Fin d, (B (EuclideanSpace.single j (1 : ℝ)) k) ^ 2 := by
      have hc := finProdFinEquiv.symm.sum_comp
        (fun kj : Fin K × Fin d => (B (EuclideanSpace.single kj.2 (1 : ℝ)) kj.1) ^ 2)
      change ∑ q : Fin (K * d), (opVec B q) ^ 2 = _ at hc
      rw [hc, Fintype.sum_prod_type' (fun k j => (B (EuclideanSpace.single j (1 : ℝ)) k) ^ 2)]
    rw [h_eq, Finset.sum_comm]
    refine Finset.sum_congr rfl fun j _ => ?_
    exact (eucl_norm_sq_eq_sum (B (EuclideanSpace.single j (1 : ℝ)))).symm
  have h2 : UL.hilbertSchmidtNorm B ^ 2 =
      ∑ j : Fin d, ‖B (EuclideanSpace.single j (1 : ℝ))‖ ^ 2 := by
    let bY := stdOrthonormalBasis ℝ (EuclideanSpace ℝ (Fin K))
    rw [UL.Proof_lem_C_2.hilbertSchmidtNorm_sq B]
    change (∑ r : Fin (Module.finrank ℝ (EuclideanSpace ℝ (Fin K))),
      ‖UL.Proof_lem_C_2.adjVec B (bY r)‖ ^ 2) = _
    have h_adj : ∀ r : Fin (Module.finrank ℝ (EuclideanSpace ℝ (Fin K))),
        ‖UL.Proof_lem_C_2.adjVec B (bY r)‖ ^ 2 =
          ∑ j : Fin d, (inner ℝ (bY r) (B (EuclideanSpace.single j (1 : ℝ)))) ^ 2 := by
      intro r
      rw [eucl_norm_sq_eq_sum]
      refine Finset.sum_congr rfl fun j _ => ?_
      rw [← inner_single_right (UL.Proof_lem_C_2.adjVec B (bY r)) j,
        UL.Proof_lem_C_2.inner_adjVec_left]
    simp_rw [h_adj]
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun j _ => ?_
    let w := B (EuclideanSpace.single j (1 : ℝ))
    have h_parseval := bY.sum_inner_mul_inner w w
    rw [real_inner_self_eq_norm_sq] at h_parseval
    rw [← h_parseval]
    refine Finset.sum_congr rfl fun r _ => ?_
    rw [real_inner_comm w (bY r), sq]
  have h_nn1 : 0 ≤ ‖opVec B‖ := norm_nonneg _
  have h_nn2 : 0 ≤ UL.hilbertSchmidtNorm B := UL.Proof_lem_C_2.hilbertSchmidtNorm_nonneg B
  nlinarith

private lemma prob_compl_toReal_le {α : Type*} [MeasurableSpace α]
    (π : MeasureTheory.Measure α) [MeasureTheory.IsProbabilityMeasure π]
    {E : Set α} (hE : MeasurableSet E) {t : ℝ} (ht : (π E).toReal ≥ 1 - t) :
    (π Eᶜ).toReal ≤ t := by
  have h_sum : (π E).toReal + (π Eᶜ).toReal = 1 := by
    rw [← ENNReal.toReal_add (MeasureTheory.measure_ne_top π E)
      (MeasureTheory.measure_ne_top π Eᶜ), MeasureTheory.measure_add_measure_compl hE]
    simp
  linarith

end Helpers

theorem exists_good_sample_event.{u₁, u₂, u₃}
    (h_mc : UL.S_cit_mcdiarmid1989.{u₁, u₂})
    {n d K N : ℕ} (hn : 1 ≤ n) (hK : 2 ≤ K) (hN : 1 ≤ N)
    {L δ : ℝ} (hL : 0 < L) (hδ0 : 0 < δ) (hδ1 : δ < (1 : ℝ) / 2)
    (x_dict : Fin N → EuclideanSpace ℝ (Fin d))
    (hx_dict : ∀ j : Fin N, ‖x_dict j‖ ≤ L)
    (ν : MeasureTheory.Measure (EuclideanSpace ℝ (Fin d) × Fin K))
    [MeasureTheory.IsProbabilityMeasure ν]
    (h_supp : ∀ᵐ xy ∂ν, xy.1 ∈ Set.range x_dict)
    (Ω : Type u₃) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (X : Fin n → Ω → EuclideanSpace ℝ (Fin d))
    (Y : Fin n → Ω → Fin K)
    (hX_meas : ∀ i : Fin n, Measurable (X i))
    (hY_meas : ∀ i : Fin n, Measurable (Y i))
    (h_indep : ProbabilityTheory.iIndepFun (fun i ω => (X i ω, Y i ω)) μ)
    (h_map : ∀ i : Fin n, MeasureTheory.Measure.map (fun ω => (X i ω, Y i ω)) μ = ν) :
    ∃ (E_good : Set Ω),
      MeasurableSet E_good ∧
      (μ E_good).toReal ≥ 1 - δ ∧
      ∀ ω ∈ E_good,
        (∀ i : Fin n, X i ω ∈ Set.range x_dict) ∧
        (∀ (b : ℝ) (v : EuclideanSpace ℝ (Fin d))
           (c_vec : EuclideanSpace ℝ (Fin K))
           (B : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin K))
           (f : EuclideanSpace ℝ (Fin d) × Fin K → ℝ),
           MeasureTheory.Integrable f ν →
           (∀ j : Fin N, ∀ y : Fin K,
             f (x_dict j, y) =
               b + inner ℝ v (x_dict j) -
                 inner ℝ (EuclideanSpace.single y (1 : ℝ) - UL.uniformVec K)
                   (c_vec + B (x_dict j))) →
           |(∫ xy, f xy ∂ν) - (1 / (n : ℝ)) * ∑ i : Fin n, f (X i ω, Y i ω)| ≤
             4 * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ)) *
               (L * ‖v‖ + ‖c_vec‖ + L * UL.hilbertSchmidtNorm B)) := by
  let _ := hN
  let α₀ := EuclideanSpace ℝ (Fin d) × Fin K
  let π : MeasureTheory.Measure (Fin n → α₀) := MeasureTheory.Measure.pi (fun _ : Fin n => ν)
  haveI : MeasureTheory.IsProbabilityMeasure π :=
    inferInstanceAs (MeasureTheory.IsProbabilityMeasure (MeasureTheory.Measure.pi (fun _ : Fin n => ν)))
  let ξ_X : α₀ → EuclideanSpace ℝ (Fin d) := fun xy => xClamp L xy.1
  let ξ_Z : α₀ → EuclideanSpace ℝ (Fin K) := fun xy => zVec K xy.2
  let ξ_ZX : α₀ → EuclideanSpace ℝ (Fin (K * d)) := zxVec L
  have hξ_X_meas : Measurable ξ_X := (measurable_xClamp L).comp measurable_fst
  have hξ_X_norm : ∀ xy : α₀, ‖ξ_X xy‖ ≤ L := fun xy => norm_xClamp_le hL xy.1
  have hξ_Z_meas : Measurable ξ_Z := (Measurable.of_discrete (f := zVec K)).comp measurable_snd
  have hξ_Z_norm : ∀ xy : α₀, ‖ξ_Z xy‖ ≤ (1 : ℝ) := fun xy => norm_zVec_le hK xy.2
  have hξ_ZX_meas : Measurable ξ_ZX := measurable_zxVec L
  have hξ_ZX_norm : ∀ xy : α₀, ‖ξ_ZX xy‖ ≤ L := fun xy => norm_zxVec_le hL hK xy
  -- 1. Concentration events on `π`
  obtain ⟨hGX_meas, hGX_prob⟩ := eucl_mean_concentration.{u₁, u₂} h_mc ν hn hL hδ0 hδ1
    ξ_X hξ_X_meas hξ_X_norm
  obtain ⟨hGZ_meas, hGZ_prob⟩ := eucl_mean_concentration.{u₁, u₂} h_mc ν hn zero_lt_one hδ0 hδ1
    ξ_Z hξ_Z_meas hξ_Z_norm
  obtain ⟨hGZX_meas, hGZX_prob⟩ := eucl_mean_concentration.{u₁, u₂} h_mc ν hn hL hδ0 hδ1
    ξ_ZX hξ_ZX_meas hξ_ZX_norm
  let R_δn : ℝ := Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ))
  let G_X : Set (Fin n → α₀) := {z | euclDev n ν ξ_X z ≤ 4 * L * R_δn}
  let G_Z : Set (Fin n → α₀) := {z | euclDev n ν ξ_Z z ≤ 4 * (1 : ℝ) * R_δn}
  let G_ZX : Set (Fin n → α₀) := {z | euclDev n ν ξ_ZX z ≤ 4 * L * R_δn}
  -- 2. Dictionary support event `G_supp`
  let G_supp : Set (Fin n → α₀) := {z | ∀ i : Fin n, (z i).1 ∈ Set.range x_dict}
  have h_range_meas : MeasurableSet (Set.range x_dict) :=
    (Set.finite_range x_dict).isClosed.measurableSet
  have hGsupp_meas : MeasurableSet G_supp := by
    have heq : G_supp = ⋂ i : Fin n, (fun z : Fin n → α₀ => (z i).1) ⁻¹' Set.range x_dict := by
      ext z; simp [G_supp]
    rw [heq]
    exact MeasurableSet.iInter fun i =>
      (measurable_fst.comp (measurable_pi_apply i)) h_range_meas
  have hGsupp_compl : π G_suppᶜ = 0 := by
    have hsub : G_suppᶜ ⊆ ⋃ i : Fin n, (Function.eval i) ⁻¹' {xy : α₀ | xy.1 ∉ Set.range x_dict} := by
      intro z hz
      simp only [G_supp, Set.mem_compl_iff, Set.mem_setOf_eq, not_forall] at hz
      rcases hz with ⟨i, hi⟩
      exact Set.mem_iUnion.mpr ⟨i, hi⟩
    refine MeasureTheory.measure_mono_null hsub (MeasureTheory.measure_iUnion_null fun i => ?_)
    have h_bad_meas : MeasurableSet {xy : α₀ | xy.1 ∉ Set.range x_dict} :=
      (measurable_fst h_range_meas).compl
    have hev := (MeasureTheory.measurePreserving_eval (fun _ : Fin n => ν) i).map_eq
    rw [← MeasureTheory.Measure.map_apply (measurable_pi_apply i) h_bad_meas, hev]
    exact MeasureTheory.ae_iff.mp h_supp
  -- 3. Intersect all four events on `Fin n → α₀`
  let G_all : Set (Fin n → α₀) := G_supp ∩ (G_X ∩ (G_Z ∩ G_ZX))
  have hGall_meas : MeasurableSet G_all :=
    hGsupp_meas.inter (hGX_meas.inter (hGZ_meas.inter hGZX_meas))
  have hGall_prob : (π G_all).toReal ≥ 1 - δ := by
    have hcX : (π G_Xᶜ).toReal ≤ δ / 3 := prob_compl_toReal_le π hGX_meas hGX_prob
    have hcZ : (π G_Zᶜ).toReal ≤ δ / 3 := prob_compl_toReal_le π hGZ_meas hGZ_prob
    have hcZX : (π G_ZXᶜ).toReal ≤ δ / 3 := prob_compl_toReal_le π hGZX_meas hGZX_prob
    have h_compl_le : π G_allᶜ ≤ π G_Xᶜ + (π G_Zᶜ + π G_ZXᶜ) := by
      have h_eq : G_allᶜ = G_suppᶜ ∪ (G_Xᶜ ∪ (G_Zᶜ ∪ G_ZXᶜ)) := by
        ext z
        simp only [G_all, Set.mem_compl_iff, Set.mem_inter_iff, Set.mem_union]
        tauto
      rw [h_eq]
      calc π (G_suppᶜ ∪ (G_Xᶜ ∪ (G_Zᶜ ∪ G_ZXᶜ)))
          ≤ π G_suppᶜ + π (G_Xᶜ ∪ (G_Zᶜ ∪ G_ZXᶜ)) := MeasureTheory.measure_union_le _ _
        _ = π (G_Xᶜ ∪ (G_Zᶜ ∪ G_ZXᶜ)) := by rw [hGsupp_compl, zero_add]
        _ ≤ π G_Xᶜ + π (G_Zᶜ ∪ G_ZXᶜ) := MeasureTheory.measure_union_le _ _
        _ ≤ π G_Xᶜ + (π G_Zᶜ + π G_ZXᶜ) := by
            gcongr
            exact MeasureTheory.measure_union_le _ _
    have h_fin2 : π G_Zᶜ + π G_ZXᶜ ≠ ⊤ :=
      ENNReal.add_ne_top.mpr ⟨MeasureTheory.measure_ne_top π _, MeasureTheory.measure_ne_top π _⟩
    have h_fin3 : π G_Xᶜ + (π G_Zᶜ + π G_ZXᶜ) ≠ ⊤ :=
      ENNReal.add_ne_top.mpr ⟨MeasureTheory.measure_ne_top π _, h_fin2⟩
    have h_compl_toReal : (π G_allᶜ).toReal ≤ δ := by
      have h_mono := ENNReal.toReal_mono h_fin3 h_compl_le
      rw [ENNReal.toReal_add (MeasureTheory.measure_ne_top π _) h_fin2,
        ENNReal.toReal_add (MeasureTheory.measure_ne_top π _)
          (MeasureTheory.measure_ne_top π _)] at h_mono
      linarith
    have h_sum : (π G_all).toReal + (π G_allᶜ).toReal = 1 := by
      rw [← ENNReal.toReal_add (MeasureTheory.measure_ne_top π _)
        (MeasureTheory.measure_ne_top π _), MeasureTheory.measure_add_measure_compl hGall_meas]
      simp
    linarith
  -- 4. Pull back along `Z_map : Ω → Fin n → α₀`
  let Z_map : Ω → (Fin n → α₀) := fun ω i => (X i ω, Y i ω)
  have hZ_meas : Measurable Z_map :=
    measurable_pi_lambda _ fun i => (hX_meas i).prodMk (hY_meas i)
  have hZ_push : MeasureTheory.Measure.map Z_map μ = π := by
    have hpi := (ProbabilityTheory.iIndepFun_iff_map_fun_eq_pi_map
      (fun i => ((hX_meas i).prodMk (hY_meas i)).aemeasurable)).mp h_indep
    simp_rw [h_map] at hpi
    exact hpi
  refine ⟨Z_map ⁻¹' G_all, hZ_meas hGall_meas, ?_, ?_⟩
  · have hμ_eq : μ (Z_map ⁻¹' G_all) = π G_all := by
      rw [← hZ_push, MeasureTheory.Measure.map_apply hZ_meas hGall_meas]
    rw [hμ_eq]
    exact hGall_prob
  · intro ω hω
    rcases hω with ⟨hω_supp, hω_X, hω_Z, hω_ZX⟩
    refine ⟨hω_supp, ?_⟩
    intro b v c_vec B f _hf_int hf_dict
    let m_B : EuclideanSpace ℝ (Fin (K * d)) := opVec B
    let g_aff : α₀ → ℝ := fun xy =>
      b + inner ℝ (ξ_X xy) v - inner ℝ (ξ_Z xy) c_vec - inner ℝ (ξ_ZX xy) m_B
    have hf_eq_on_dict : ∀ xy : α₀, xy.1 ∈ Set.range x_dict → f xy = g_aff xy := by
      intro xy hxy
      rcases hxy with ⟨j, hj⟩
      have h_pair : xy = (x_dict j, xy.2) := Prod.ext hj.symm rfl
      rw [h_pair, hf_dict j xy.2]
      dsimp [g_aff, ξ_X, ξ_Z, ξ_ZX, m_B]
      rw [xClamp_of_le (hx_dict j), real_inner_comm v (x_dict j)]
      change b + inner ℝ v (x_dict j) -
          inner ℝ (zVec K xy.2) (c_vec + B (x_dict j)) =
        b + inner ℝ v (x_dict j) - inner ℝ (zVec K xy.2) c_vec -
          inner ℝ (zxVec L (x_dict j, xy.2)) (opVec B)
      rw [inner_add_right, inner_zVec_apply_eq B (hx_dict j) xy.2]
      ring
    have h_int_f : (∫ xy, f xy ∂ν) = ∫ xy, g_aff xy ∂ν :=
      MeasureTheory.integral_congr_ae (h_supp.mono hf_eq_on_dict)
    have h_sum_f : (∑ i : Fin n, f (X i ω, Y i ω)) =
        ∑ i : Fin n, g_aff (Z_map ω i) :=
      Finset.sum_congr rfl fun i _ => hf_eq_on_dict (Z_map ω i) (hω_supp i)
    have h_int_X := integrable_inner_eucl ν hξ_X_meas hξ_X_norm v
    have h_int_Z := integrable_inner_eucl ν hξ_Z_meas hξ_Z_norm c_vec
    have h_int_ZX := integrable_inner_eucl ν hξ_ZX_meas hξ_ZX_norm m_B
    have h_int_gaff : (∫ xy, g_aff xy ∂ν) =
        b + (∫ xy, inner ℝ (ξ_X xy) v ∂ν) -
          (∫ xy, inner ℝ (ξ_Z xy) c_vec ∂ν) -
          (∫ xy, inner ℝ (ξ_ZX xy) m_B ∂ν) := by
      have hb_int : MeasureTheory.Integrable
          (fun _ : EuclideanSpace ℝ (Fin d) × Fin K => b) ν :=
        MeasureTheory.integrable_const b
      have h12 : MeasureTheory.Integrable
          (fun xy : EuclideanSpace ℝ (Fin d) × Fin K => b + inner ℝ (ξ_X xy) v) ν :=
        hb_int.add h_int_X
      have h123 : MeasureTheory.Integrable
          (fun xy : EuclideanSpace ℝ (Fin d) × Fin K =>
            b + inner ℝ (ξ_X xy) v - inner ℝ (ξ_Z xy) c_vec) ν :=
        h12.sub h_int_Z
      have hb_val : (∫ _ : EuclideanSpace ℝ (Fin d) × Fin K, b ∂ν) = b := by simp
      change (∫ xy : EuclideanSpace ℝ (Fin d) × Fin K,
          (b + inner ℝ (ξ_X xy) v - inner ℝ (ξ_Z xy) c_vec - inner ℝ (ξ_ZX xy) m_B) ∂ν) = _
      rw [MeasureTheory.integral_sub h123 h_int_ZX,
        MeasureTheory.integral_sub h12 h_int_Z,
        MeasureTheory.integral_add hb_int h_int_X, hb_val]
    have hn_ne : (n : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (by omega)
    have h_emp_gaff : (1 / (n : ℝ)) * (∑ i : Fin n, g_aff (Z_map ω i)) =
        b + (1 / (n : ℝ)) * (∑ i : Fin n, inner ℝ (ξ_X (Z_map ω i)) v) -
          (1 / (n : ℝ)) * (∑ i : Fin n, inner ℝ (ξ_Z (Z_map ω i)) c_vec) -
          (1 / (n : ℝ)) * (∑ i : Fin n, inner ℝ (ξ_ZX (Z_map ω i)) m_B) := by
      dsimp [g_aff]
      simp only [Finset.sum_sub_distrib, Finset.sum_add_distrib, Finset.sum_const,
        Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, mul_sub, mul_add]
      rw [← mul_assoc, one_div_mul_cancel hn_ne, one_mul]
    rw [h_int_f, h_sum_f, h_int_gaff, h_emp_gaff]
    let Δ_X := (∫ xy, inner ℝ (ξ_X xy) v ∂ν) -
      (1 / (n : ℝ)) * ∑ i : Fin n, inner ℝ (ξ_X (Z_map ω i)) v
    let Δ_Z := (∫ xy, inner ℝ (ξ_Z xy) c_vec ∂ν) -
      (1 / (n : ℝ)) * ∑ i : Fin n, inner ℝ (ξ_Z (Z_map ω i)) c_vec
    let Δ_ZX := (∫ xy, inner ℝ (ξ_ZX xy) m_B ∂ν) -
      (1 / (n : ℝ)) * ∑ i : Fin n, inner ℝ (ξ_ZX (Z_map ω i)) m_B
    have h_alg :
        (b + (∫ xy, inner ℝ (ξ_X xy) v ∂ν) -
            (∫ xy, inner ℝ (ξ_Z xy) c_vec ∂ν) -
            (∫ xy, inner ℝ (ξ_ZX xy) m_B ∂ν)) -
          (b + (1 / (n : ℝ)) * (∑ i : Fin n, inner ℝ (ξ_X (Z_map ω i)) v) -
            (1 / (n : ℝ)) * (∑ i : Fin n, inner ℝ (ξ_Z (Z_map ω i)) c_vec) -
            (1 / (n : ℝ)) * (∑ i : Fin n, inner ℝ (ξ_ZX (Z_map ω i)) m_B)) =
          Δ_X - Δ_Z - Δ_ZX := by
      dsimp [Δ_X, Δ_Z, Δ_ZX]
      ring
    rw [h_alg]
    have h_tri : |Δ_X - Δ_Z - Δ_ZX| ≤ |Δ_X| + |Δ_Z| + |Δ_ZX| :=
      abs_le.mpr ⟨by linarith [neg_abs_le Δ_X, le_abs_self Δ_Z, le_abs_self Δ_ZX],
        by linarith [le_abs_self Δ_X, neg_abs_le Δ_Z, neg_abs_le Δ_ZX]⟩
    have hb_X : |Δ_X| ≤ (4 * L * R_δn) * ‖v‖ :=
      (abs_integral_sub_emp_inner_le ν n hξ_X_meas hξ_X_norm v (Z_map ω)).trans
        (mul_le_mul_of_nonneg_right hω_X (norm_nonneg v))
    have hb_Z : |Δ_Z| ≤ (4 * (1 : ℝ) * R_δn) * ‖c_vec‖ :=
      (abs_integral_sub_emp_inner_le ν n hξ_Z_meas hξ_Z_norm c_vec (Z_map ω)).trans
        (mul_le_mul_of_nonneg_right hω_Z (norm_nonneg c_vec))
    have hb_ZX : |Δ_ZX| ≤ (4 * L * R_δn) * UL.hilbertSchmidtNorm B := by
      have h1 := (abs_integral_sub_emp_inner_le ν n hξ_ZX_meas hξ_ZX_norm m_B (Z_map ω)).trans
        (mul_le_mul_of_nonneg_right hω_ZX (norm_nonneg m_B))
      rwa [norm_opVec_eq B] at h1
    calc |Δ_X - Δ_Z - Δ_ZX|
        ≤ |Δ_X| + |Δ_Z| + |Δ_ZX| := h_tri
      _ ≤ (4 * L * R_δn) * ‖v‖ + (4 * (1 : ℝ) * R_δn) * ‖c_vec‖ +
          (4 * L * R_δn) * UL.hilbertSchmidtNorm B := by linarith
      _ = 4 * R_δn * (L * ‖v‖ + ‖c_vec‖ + L * UL.hilbertSchmidtNorm B) := by ring

end UL.Proof_thm_7_1_Race2

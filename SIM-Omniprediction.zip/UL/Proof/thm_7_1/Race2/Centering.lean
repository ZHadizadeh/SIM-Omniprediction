import UL.Def.def_7_dirichlet

namespace UL.Proof_thm_7_1_Race2

lemma moorePenrose_unique {m n : Type*} [Fintype m] [Fintype n]
    {A : Matrix m n ℝ} {B₁ B₂ : Matrix n m ℝ}
    (h₁ : UL.IsMoorePenrosePseudoinverse A B₁)
    (h₂ : UL.IsMoorePenrosePseudoinverse A B₂) :
    B₁ = B₂ := by
  have hAB : A * B₁ = A * B₂ := by
    calc A * B₁
        = (A * B₁).transpose := h₁.2.2.1.symm
      _ = B₁.transpose * A.transpose := Matrix.transpose_mul A B₁
      _ = B₁.transpose * (A * B₂ * A).transpose := by rw [h₂.1]
      _ = B₁.transpose * (A.transpose * (A * B₂).transpose) := by
          rw [Matrix.transpose_mul (A * B₂) A]
      _ = (B₁.transpose * A.transpose) * (A * B₂).transpose := (Matrix.mul_assoc _ _ _).symm
      _ = (A * B₁).transpose * (A * B₂).transpose := by rw [← Matrix.transpose_mul A B₁]
      _ = (A * B₁) * (A * B₂) := by rw [h₁.2.2.1, h₂.2.2.1]
      _ = (A * B₁ * A) * B₂ := by simp only [Matrix.mul_assoc]
      _ = A * B₂ := by rw [h₁.1]
  have hA_eq : A = A * (B₂ * A) := by
    rw [← Matrix.mul_assoc, h₂.1]
  have hBA : B₁ * A = B₂ * A := by
    calc B₁ * A
        = (B₁ * A).transpose := h₁.2.2.2.symm
      _ = A.transpose * B₁.transpose := Matrix.transpose_mul B₁ A
      _ = (A * (B₂ * A)).transpose * B₁.transpose := by nth_rw 1 [hA_eq]
      _ = ((B₂ * A).transpose * A.transpose) * B₁.transpose := by
          rw [Matrix.transpose_mul A (B₂ * A)]
      _ = (B₂ * A).transpose * (A.transpose * B₁.transpose) := Matrix.mul_assoc _ _ _
      _ = (B₂ * A).transpose * (B₁ * A).transpose := by rw [← Matrix.transpose_mul B₁ A]
      _ = (B₂ * A) * (B₁ * A) := by rw [h₂.2.2.2, h₁.2.2.2]
      _ = B₂ * (A * B₁ * A) := by simp only [Matrix.mul_assoc]
      _ = B₂ * A := by rw [h₁.1]
  calc B₁
      = B₁ * A * B₁ := h₁.2.1.symm
    _ = B₂ * A * B₁ := by rw [hBA]
    _ = B₂ * (A * B₁) := Matrix.mul_assoc _ _ _
    _ = B₂ * (A * B₂) := by rw [hAB]
    _ = B₂ * A * B₂ := (Matrix.mul_assoc _ _ _).symm
    _ = B₂ := h₂.2.1

lemma centeringMatrix_apply (N : ℕ) (i j : Fin N) :
    UL.centeringMatrix N i j = (if i = j then 1 else 0) - (1 / (N : ℝ)) := by
  simp [UL.centeringMatrix, Matrix.one_apply, Matrix.vecMulVec_apply]

lemma centeringMatrix_transpose (N : ℕ) :
    (UL.centeringMatrix N).transpose = UL.centeringMatrix N := by
  ext i j
  simp [centeringMatrix_apply, eq_comm]

lemma centeringMatrix_mul_self {N : ℕ} (hN : 1 ≤ N) :
    UL.centeringMatrix N * UL.centeringMatrix N = UL.centeringMatrix N := by
  have hN_ne : (N : ℝ) ≠ 0 := by
    exact_mod_cast (Nat.ne_of_gt (Nat.lt_of_lt_of_le Nat.zero_lt_one hN))
  ext i k
  rw [Matrix.mul_apply, centeringMatrix_apply]
  simp_rw [centeringMatrix_apply]
  have hsum :
      ∑ j : Fin N, ((if i = j then (1 : ℝ) else 0) - 1 / (N : ℝ)) *
          ((if j = k then (1 : ℝ) else 0) - 1 / (N : ℝ)) =
        (∑ j : Fin N, if i = j then ((if j = k then (1 : ℝ) else 0) - 1 / (N : ℝ)) else 0) -
          (1 / (N : ℝ)) * ∑ j : Fin N, ((if j = k then (1 : ℝ) else 0) - 1 / (N : ℝ)) := by
    rw [Finset.mul_sum, ← Finset.sum_sub_distrib]
    refine Finset.sum_congr rfl fun j _ => ?_
    by_cases hij : i = j <;> simp [hij, sub_mul]
  rw [hsum]
  have h1 :
      (∑ j : Fin N, if i = j then ((if j = k then (1 : ℝ) else 0) - 1 / (N : ℝ)) else 0) =
        (if i = k then (1 : ℝ) else 0) - 1 / (N : ℝ) := by
    simp
  have h2 :
      (∑ j : Fin N, ((if j = k then (1 : ℝ) else 0) - 1 / (N : ℝ))) = 0 := by
    rw [Finset.sum_sub_distrib]
    simp [hN_ne]
  rw [h1, h2]
  ring

lemma centeringMatrix_mulVec_one {N : ℕ} (hN : 1 ≤ N) :
    (UL.centeringMatrix N).mulVec 1 = 0 := by
  have hN_ne : (N : ℝ) ≠ 0 := by
    exact_mod_cast (Nat.ne_of_gt (Nat.lt_of_lt_of_le Nat.zero_lt_one hN))
  ext i
  simp only [Matrix.mulVec, dotProduct, Pi.one_apply, mul_one, Pi.zero_apply,
    centeringMatrix_apply]
  rw [Finset.sum_sub_distrib]
  simp [hN_ne]

end UL.Proof_thm_7_1_Race2

import UL.Proof.thm_7_1.Race2.Centering
import Mathlib
import UL.Def.def_2_1
import UL.Def.def_5_smooth
import UL.Def.def_7_dirichlet
import UL.Proof.lem_C_2.H1_HilbertSchmidt
set_option autoImplicit false

namespace UL.Proof_thm_7_1_Race2

lemma hilbertSchmidtNorm_subtypeL_comp {d K : ℕ}
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K) :
    UL.hilbertSchmidtNorm ((UL.ZeroSumSubspace K).subtypeL.comp W) = UL.hilbertSchmidtNorm W := by
  unfold UL.hilbertSchmidtNorm
  rfl

/-! ### Moore–Penrose pseudoinverse of symmetric real matrices -/

private lemma star_eq_transpose {n : Type*} [Fintype n] (M : Matrix n n ℝ) :
    star M = M.transpose := by
  rw [Matrix.star_eq_conjTranspose, Matrix.conjTranspose_eq_transpose_of_trivial]

private lemma exists_moorePenrose_of_isSymm {n : Type*} [Fintype n] [DecidableEq n]
    {M : Matrix n n ℝ} (hM : M.transpose = M) :
    ∃ B : Matrix n n ℝ, UL.IsMoorePenrosePseudoinverse M B := by
  have hHerm : M.IsHermitian := by
    rw [Matrix.IsHermitian, Matrix.conjTranspose_eq_transpose_of_trivial, hM]
  let Φ := Unitary.conjStarAlgAut ℝ (Matrix n n ℝ) hHerm.eigenvectorUnitary
  let D : Matrix n n ℝ := Matrix.diagonal hHerm.eigenvalues
  let D_inv : Matrix n n ℝ := Matrix.diagonal (fun i => (hHerm.eigenvalues i)⁻¹)
  have hM_eq : M = Φ D := by
    simpa [Φ, D] using hHerm.spectral_theorem
  have hDD_invD : D * D_inv * D = D := by
    simp only [D, D_inv, Matrix.diagonal_mul_diagonal]
    congr 1
    ext i
    by_cases h : hHerm.eigenvalues i = 0 <;> simp [h]
  have hD_invDD_inv : D_inv * D * D_inv = D_inv := by
    simp only [D, D_inv, Matrix.diagonal_mul_diagonal]
    congr 1
    ext i
    by_cases h : hHerm.eigenvalues i = 0 <;> simp [h]
  have hDD_inv_star : star (D * D_inv) = D * D_inv := by
    rw [star_eq_transpose]
    simp [D, D_inv, Matrix.diagonal_mul_diagonal]
  have hD_invD_star : star (D_inv * D) = D_inv * D := by
    rw [star_eq_transpose]
    simp [D, D_inv, Matrix.diagonal_mul_diagonal]
  refine ⟨Φ D_inv, ?_, ?_, ?_, ?_⟩
  · rw [hM_eq, ← map_mul, ← map_mul, hDD_invD]
  · rw [hM_eq, ← map_mul, ← map_mul, hD_invDD_inv]
  · rw [← star_eq_transpose, hM_eq, ← map_mul, ← map_star, hDD_inv_star]
  · rw [← star_eq_transpose, hM_eq, ← map_mul, ← map_star, hD_invD_star]

lemma moorePenrose_spec_of_isSymm {n : Type*} [Fintype n] [DecidableEq n]
    {M : Matrix n n ℝ} (hM : M.transpose = M) :
    UL.IsMoorePenrosePseudoinverse M (UL.moorePenrosePseudoinverse M) := by
  unfold UL.moorePenrosePseudoinverse
  have hex := exists_moorePenrose_of_isSymm hM
  rw [dif_pos hex]
  exact Classical.choose_spec hex

lemma moorePenrose_transpose_of_isSymm {n : Type*} [Fintype n] [DecidableEq n]
    {M : Matrix n n ℝ} (hM : M.transpose = M) :
    (UL.moorePenrosePseudoinverse M).transpose = UL.moorePenrosePseudoinverse M := by
  let L := UL.moorePenrosePseudoinverse M
  have hMP : UL.IsMoorePenrosePseudoinverse M L := moorePenrose_spec_of_isSymm hM
  have hMPT : UL.IsMoorePenrosePseudoinverse M L.transpose := by
    refine ⟨?_, ?_, ?_, ?_⟩
    · calc M * L.transpose * M
          = M.transpose * L.transpose * M.transpose := by rw [hM]
        _ = (L * M).transpose * M.transpose := by rw [← Matrix.transpose_mul L M]
        _ = (M * (L * M)).transpose := by rw [← Matrix.transpose_mul M (L * M)]
        _ = (M * L * M).transpose := by rw [← Matrix.mul_assoc]
        _ = M.transpose := by rw [hMP.1]
        _ = M := hM
    · calc L.transpose * M * L.transpose
          = L.transpose * M.transpose * L.transpose := by rw [hM]
        _ = (M * L).transpose * L.transpose := by rw [← Matrix.transpose_mul M L]
        _ = (L * (M * L)).transpose := by rw [← Matrix.transpose_mul L (M * L)]
        _ = (L * M * L).transpose := by rw [← Matrix.mul_assoc]
        _ = L.transpose := by rw [hMP.2.1]
    · calc (M * L.transpose).transpose
          = L.transpose.transpose * M.transpose := Matrix.transpose_mul M L.transpose
        _ = L * M := by rw [Matrix.transpose_transpose, hM]
        _ = (L * M).transpose := hMP.2.2.2.symm
        _ = M.transpose * L.transpose := Matrix.transpose_mul L M
        _ = M * L.transpose := by rw [hM]
    · calc (L.transpose * M).transpose
          = M.transpose * L.transpose.transpose := Matrix.transpose_mul L.transpose M
        _ = M * L := by rw [hM, Matrix.transpose_transpose]
        _ = (M * L).transpose := hMP.2.2.1.symm
        _ = L.transpose * M.transpose := Matrix.transpose_mul M L
        _ = L.transpose * M := by rw [hM]
  exact moorePenrose_unique hMPT hMP

private lemma moorePenrose_comm_of_isSymm {n : Type*} [Fintype n] [DecidableEq n]
    {M : Matrix n n ℝ} (hM : M.transpose = M) :
    UL.moorePenrosePseudoinverse M * M = M * UL.moorePenrosePseudoinverse M := by
  let L := UL.moorePenrosePseudoinverse M
  have hMP : UL.IsMoorePenrosePseudoinverse M L := moorePenrose_spec_of_isSymm hM
  have hLT : L.transpose = L := moorePenrose_transpose_of_isSymm hM
  calc L * M
      = L.transpose * M.transpose := by rw [hLT, hM]
    _ = (M * L).transpose := (Matrix.transpose_mul M L).symm
    _ = M * L := hMP.2.2.1

/-! ### Centering matrix and centered Gram matrix -/

lemma centeredGramMatrix_eq_mul_transpose {N d : ℕ}
    (x_dict : Fin N → EuclideanSpace ℝ (Fin d)) :
    UL.centeredGramMatrix x_dict =
      (UL.centeringMatrix N * UL.dictionaryRowMatrix x_dict) *
        (UL.centeringMatrix N * UL.dictionaryRowMatrix x_dict).transpose := by
  unfold UL.centeredGramMatrix
  rw [Matrix.transpose_mul, centeringMatrix_transpose]
  simp only [Matrix.mul_assoc]

lemma centeredGramMatrix_transpose {N d : ℕ}
    (x_dict : Fin N → EuclideanSpace ℝ (Fin d)) :
    (UL.centeredGramMatrix x_dict).transpose = UL.centeredGramMatrix x_dict := by
  rw [centeredGramMatrix_eq_mul_transpose, Matrix.transpose_mul, Matrix.transpose_transpose]

private lemma sum_apply_eucl {M : ℕ} {α : Type*} (s : Finset α)
    (f : α → EuclideanSpace ℝ (Fin M)) (j : Fin M) :
    (∑ a ∈ s, f a) j = ∑ a ∈ s, f a j := by
  classical
  induction s using Finset.induction_on with
  | empty => rfl
  | @insert a s ha ih => simp [Finset.sum_insert ha, ih]

lemma centeredDict_row_apply {N d : ℕ}
    (x_dict : Fin N → EuclideanSpace ℝ (Fin d)) (i : Fin N) (r : Fin d) :
    let x_bar : EuclideanSpace ℝ (Fin d) := (1 / (N : ℝ)) • ∑ s : Fin N, x_dict s
    (UL.centeringMatrix N * UL.dictionaryRowMatrix x_dict) i r = (x_dict i - x_bar) r := by
  intro x_bar
  rw [Matrix.mul_apply]
  simp_rw [centeringMatrix_apply, UL.dictionaryRowMatrix, Matrix.of_apply, sub_mul]
  rw [Finset.sum_sub_distrib, ← Finset.mul_sum]
  have h1 : (∑ s : Fin N, (if i = s then (1 : ℝ) else 0) * x_dict s r) = x_dict i r := by
    simp
  rw [h1]
  dsimp [x_bar]
  simp [sum_apply_eucl]

private lemma centeredGramMatrix_apply_eq_inner {N d : ℕ}
    (x_dict : Fin N → EuclideanSpace ℝ (Fin d)) (i j : Fin N) :
    let x_bar : EuclideanSpace ℝ (Fin d) := (1 / (N : ℝ)) • ∑ s : Fin N, x_dict s
    UL.centeredGramMatrix x_dict i j = inner ℝ (x_dict i - x_bar) (x_dict j - x_bar) := by
  intro x_bar
  rw [centeredGramMatrix_eq_mul_transpose, Matrix.mul_apply]
  simp only [Matrix.transpose_apply, centeredDict_row_apply]
  rw [EuclideanSpace.inner_eq_star_dotProduct, dotProduct]
  refine Finset.sum_congr rfl fun r _ => ?_
  dsimp [x_bar]
  simp [sum_apply_eucl, mul_comm]

private lemma centeredGramMatrix_mulVec_one {N d : ℕ}
    (x_dict : Fin N → EuclideanSpace ℝ (Fin d)) (hN : 1 ≤ N) :
    (UL.centeredGramMatrix x_dict).mulVec 1 = 0 := by
  unfold UL.centeredGramMatrix
  rw [← Matrix.mulVec_mulVec, centeringMatrix_mulVec_one hN, Matrix.mulVec_zero]

private lemma moorePenrose_centeredGramMatrix_mulVec_one {N d : ℕ}
    (x_dict : Fin N → EuclideanSpace ℝ (Fin d)) (hN : 1 ≤ N) :
    (UL.moorePenrosePseudoinverse (UL.centeredGramMatrix x_dict)).mulVec 1 = 0 := by
  let G := UL.centeredGramMatrix x_dict
  let L := UL.moorePenrosePseudoinverse G
  have hGT : G.transpose = G := centeredGramMatrix_transpose x_dict
  have hMP : UL.IsMoorePenrosePseudoinverse G L := moorePenrose_spec_of_isSymm hGT
  have hcomm : L * G = G * L := moorePenrose_comm_of_isSymm hGT
  have hL_eq : L = L * (L * G) := by
    calc L
        = L * G * L := hMP.2.1.symm
      _ = L * (G * L) := Matrix.mul_assoc _ _ _
      _ = L * (L * G) := by rw [hcomm]
  change L.mulVec 1 = 0
  rw [hL_eq, ← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec,
    centeredGramMatrix_mulVec_one x_dict hN, Matrix.mulVec_zero, Matrix.mulVec_zero]

private lemma moorePenrose_centeredGramMatrix_sum_row {N d : ℕ}
    (x_dict : Fin N → EuclideanSpace ℝ (Fin d)) (hN : 1 ≤ N) (i : Fin N) :
    ∑ j : Fin N, UL.moorePenrosePseudoinverse (UL.centeredGramMatrix x_dict) i j = 0 := by
  have h := congrFun (moorePenrose_centeredGramMatrix_mulVec_one x_dict hN) i
  simpa [Matrix.mulVec, dotProduct] using h

/-! ### Projection identity `G * G† = G† * G = J_N` under `DirichletFeatureCondition` -/

private lemma eq_of_symm_idempotent_same_range {N : ℕ} {P J : Matrix (Fin N) (Fin N) ℝ}
    (hPT : P.transpose = P) (hJT : J.transpose = J)
    (hP2 : P * P = P) (hJ2 : J * J = J)
    (hrange : LinearMap.range P.mulVecLin = LinearMap.range J.mulVecLin) :
    P = J := by
  have hJP : J * P = P := by
    ext i j
    have hmem : P.mulVec (Pi.single j 1) ∈ LinearMap.range J.mulVecLin := by
      rw [← hrange]
      exact ⟨Pi.single j 1, rfl⟩
    rcases hmem with ⟨u, hu⟩
    rw [Matrix.mulVecLin_apply] at hu
    have hvec : (J * P).mulVec (Pi.single j 1) = P.mulVec (Pi.single j 1) := by
      rw [← Matrix.mulVec_mulVec, ← hu, Matrix.mulVec_mulVec, hJ2]
    have hi := congrFun hvec i
    simpa [Matrix.mulVec_single_one] using hi
  have hPJ : P * J = J := by
    ext i j
    have hmem : J.mulVec (Pi.single j 1) ∈ LinearMap.range P.mulVecLin := by
      rw [hrange]
      exact ⟨Pi.single j 1, rfl⟩
    rcases hmem with ⟨u, hu⟩
    rw [Matrix.mulVecLin_apply] at hu
    have hvec : (P * J).mulVec (Pi.single j 1) = J.mulVec (Pi.single j 1) := by
      rw [← Matrix.mulVec_mulVec, ← hu, Matrix.mulVec_mulVec, hP2]
    have hi := congrFun hvec i
    simpa [Matrix.mulVec_single_one] using hi
  calc P
      = P.transpose := hPT.symm
    _ = (J * P).transpose := by rw [hJP]
    _ = P.transpose * J.transpose := Matrix.transpose_mul J P
    _ = P * J := by rw [hPT, hJT]
    _ = J := hPJ

lemma centeredGram_mul_pseudoinverse_of_rank {N d : ℕ}
    {x_dict : Fin N → EuclideanSpace ℝ (Fin d)}
    (hN : 1 ≤ N) (hrank : (UL.centeredGramMatrix x_dict).rank = N - 1) :
    UL.centeredGramMatrix x_dict *
        UL.moorePenrosePseudoinverse (UL.centeredGramMatrix x_dict) =
      UL.centeringMatrix N := by
  let G := UL.centeredGramMatrix x_dict
  let L := UL.moorePenrosePseudoinverse G
  let P := G * L
  let J := UL.centeringMatrix N
  have hGT : G.transpose = G := centeredGramMatrix_transpose x_dict
  have hMP : UL.IsMoorePenrosePseudoinverse G L := moorePenrose_spec_of_isSymm hGT
  have hPT : P.transpose = P := hMP.2.2.1
  have hJT : J.transpose = J := centeringMatrix_transpose N
  have hP2 : P * P = P := by
    dsimp [P]
    calc (G * L) * (G * L)
        = (G * L * G) * L := by simp only [Matrix.mul_assoc]
      _ = G * L := by rw [hMP.1]
  have hJ2 : J * J = J := centeringMatrix_mul_self hN
  have hrange_PG : LinearMap.range P.mulVecLin = LinearMap.range G.mulVecLin := by
    refine le_antisymm ?_ ?_
    · rintro _ ⟨u, rfl⟩
      exact ⟨L.mulVec u, by simp [P, Matrix.mulVec_mulVec]⟩
    · rintro _ ⟨u, rfl⟩
      refine ⟨G.mulVec u, ?_⟩
      change (G * L).mulVec (G.mulVec u) = G.mulVec u
      rw [Matrix.mulVec_mulVec, hMP.1]
  have hrange_GJ : LinearMap.range G.mulVecLin ≤ LinearMap.range J.mulVecLin := by
    rintro _ ⟨u, rfl⟩
    refine ⟨(UL.dictionaryRowMatrix x_dict *
        (UL.dictionaryRowMatrix x_dict).transpose * J).mulVec u, ?_⟩
    change J.mulVec ((UL.dictionaryRowMatrix x_dict *
        (UL.dictionaryRowMatrix x_dict).transpose * J).mulVec u) = G.mulVec u
    rw [Matrix.mulVec_mulVec]
    dsimp [G, J, UL.centeredGramMatrix]
    simp only [Matrix.mul_assoc]
  have hker_ne_bot : LinearMap.ker J.mulVecLin ≠ ⊥ := by
    intro hbot
    have hmem : (1 : Fin N → ℝ) ∈ LinearMap.ker J.mulVecLin :=
      centeringMatrix_mulVec_one hN
    rw [hbot, Submodule.mem_bot] at hmem
    have h0 := congrFun hmem ⟨0, Nat.lt_of_lt_of_le Nat.zero_lt_one hN⟩
    norm_num at h0
  have hker_ge_one : 1 ≤ Module.finrank ℝ (LinearMap.ker J.mulVecLin) :=
    Submodule.one_le_finrank_iff.mpr hker_ne_bot
  have hrn :
      Module.finrank ℝ (LinearMap.range J.mulVecLin) +
        Module.finrank ℝ (LinearMap.ker J.mulVecLin) = N := by
    simpa [Module.finrank_fin_fun] using LinearMap.finrank_range_add_finrank_ker J.mulVecLin
  have hfin_G : Module.finrank ℝ (LinearMap.range G.mulVecLin) = N - 1 := hrank
  have hle_GJ :
      Module.finrank ℝ (LinearMap.range G.mulVecLin) ≤
        Module.finrank ℝ (LinearMap.range J.mulVecLin) :=
    Submodule.finrank_mono hrange_GJ
  have hfin_eq :
      Module.finrank ℝ (LinearMap.range P.mulVecLin) =
        Module.finrank ℝ (LinearMap.range J.mulVecLin) := by
    rw [hrange_PG]
    omega
  have hrange_PJ : LinearMap.range P.mulVecLin = LinearMap.range J.mulVecLin :=
    Submodule.eq_of_le_of_finrank_eq (hrange_PG.le.trans hrange_GJ) hfin_eq
  exact eq_of_symm_idempotent_same_range hPT hJT hP2 hJ2 hrange_PJ

private lemma centeredGram_mul_moorePenrose_eq_centering {N d : ℕ}
    {x_dict : Fin N → EuclideanSpace ℝ (Fin d)} (h : UL.DirichletFeatureCondition x_dict) :
    UL.centeredGramMatrix x_dict * UL.moorePenrosePseudoinverse (UL.centeredGramMatrix x_dict) =
      UL.centeringMatrix N :=
  centeredGram_mul_pseudoinverse_of_rank h.1 (by have hr := h.2.1; omega)

private lemma moorePenrose_mul_centeredGram_eq_centering {N d : ℕ}
    {x_dict : Fin N → EuclideanSpace ℝ (Fin d)}
    (h_dir : UL.DirichletFeatureCondition x_dict) :
    UL.moorePenrosePseudoinverse (UL.centeredGramMatrix x_dict) *
        UL.centeredGramMatrix x_dict =
      UL.centeringMatrix N := by
  rw [moorePenrose_comm_of_isSymm (centeredGramMatrix_transpose x_dict)]
  exact centeredGram_mul_pseudoinverse_of_rank h_dir.1 (by have h := h_dir.2.1; omega)

/-! ### Quadratic forms with `G†` and graph Dirichlet energy -/

private lemma norm_sq_sum_mp_centered {N d : ℕ}
    (x_dict : Fin N → EuclideanSpace ℝ (Fin d)) (α : Fin N → ℝ) :
    let x_bar : EuclideanSpace ℝ (Fin d) := (1 / (N : ℝ)) • ∑ s : Fin N, x_dict s
    let z : Fin N → EuclideanSpace ℝ (Fin d) := fun i => x_dict i - x_bar
    let L := UL.moorePenrosePseudoinverse (UL.centeredGramMatrix x_dict)
    ‖∑ i : Fin N, (∑ j : Fin N, L i j * α j) • z i‖ ^ 2 =
      ∑ i : Fin N, ∑ j : Fin N, L i j * (α i * α j) := by
  intro x_bar z L
  let G := UL.centeredGramMatrix x_dict
  have hGT : G.transpose = G := centeredGramMatrix_transpose x_dict
  have hMP : UL.IsMoorePenrosePseudoinverse G L := moorePenrose_spec_of_isSymm hGT
  have hLT : L.transpose = L := moorePenrose_transpose_of_isSymm hGT
  have hLsymm : ∀ a b : Fin N, L a b = L b a := fun a b => by
    have := congrFun (congrFun hLT b) a
    simpa [Matrix.transpose_apply] using this
  have hG_inner : ∀ a b : Fin N, inner ℝ (z a) (z b) = G a b :=
    fun a b => (centeredGramMatrix_apply_eq_inner x_dict a b).symm
  rw [← real_inner_self_eq_norm_sq, sum_inner]
  have h1 :
      (∑ i : Fin N, inner ℝ ((∑ j : Fin N, L i j * α j) • z i)
          (∑ i' : Fin N, (∑ j' : Fin N, L i' j' * α j') • z i')) =
        ∑ i : Fin N, ∑ i' : Fin N,
          (∑ j : Fin N, L j i * α j) * (∑ j' : Fin N, L i' j' * α j') * G i i' := by
    refine Finset.sum_congr rfl fun i _ => ?_
    rw [inner_smul_left, conj_trivial, inner_sum, Finset.mul_sum]
    refine Finset.sum_congr rfl fun i' _ => ?_
    rw [inner_smul_right, hG_inner]
    have hci : (∑ j : Fin N, L i j * α j) = ∑ j : Fin N, L j i * α j :=
      Finset.sum_congr rfl fun j _ => by rw [hLsymm i j]
    rw [hci]
    ring
  rw [h1]
  have h2 :
      (∑ i : Fin N, ∑ i' : Fin N,
          (∑ j : Fin N, L j i * α j) * (∑ j' : Fin N, L i' j' * α j') * G i i') =
        ∑ i : Fin N, ∑ i' : Fin N, ∑ j : Fin N, ∑ j' : Fin N,
          (L j i * G i i' * L i' j') * (α j * α j') := by
    refine Finset.sum_congr rfl fun i _ => Finset.sum_congr rfl fun i' _ => ?_
    rw [Finset.sum_mul, Finset.sum_mul]
    refine Finset.sum_congr rfl fun j _ => ?_
    rw [Finset.mul_sum, Finset.sum_mul]
    refine Finset.sum_congr rfl fun j' _ => by ring
  rw [h2]
  have hswap :
      (∑ i : Fin N, ∑ i' : Fin N, ∑ j : Fin N, ∑ j' : Fin N,
          (L j i * G i i' * L i' j') * (α j * α j')) =
        ∑ j : Fin N, ∑ j' : Fin N, ∑ i : Fin N, ∑ i' : Fin N,
          (L j i * G i i' * L i' j') * (α j * α j') := by
    calc (∑ i : Fin N, ∑ i' : Fin N, ∑ j : Fin N, ∑ j' : Fin N,
            (L j i * G i i' * L i' j') * (α j * α j'))
        = ∑ i : Fin N, ∑ j : Fin N, ∑ i' : Fin N, ∑ j' : Fin N,
            (L j i * G i i' * L i' j') * (α j * α j') :=
          Finset.sum_congr rfl fun _ _ => Finset.sum_comm
      _ = ∑ j : Fin N, ∑ i : Fin N, ∑ i' : Fin N, ∑ j' : Fin N,
            (L j i * G i i' * L i' j') * (α j * α j') := Finset.sum_comm
      _ = ∑ j : Fin N, ∑ i : Fin N, ∑ j' : Fin N, ∑ i' : Fin N,
            (L j i * G i i' * L i' j') * (α j * α j') :=
          Finset.sum_congr rfl fun _ _ => Finset.sum_congr rfl fun _ _ => Finset.sum_comm
      _ = ∑ j : Fin N, ∑ j' : Fin N, ∑ i : Fin N, ∑ i' : Fin N,
            (L j i * G i i' * L i' j') * (α j * α j') :=
          Finset.sum_congr rfl fun _ _ => Finset.sum_comm
  rw [hswap]
  refine Finset.sum_congr rfl fun j _ => Finset.sum_congr rfl fun j' _ => ?_
  have hfactor :
      (∑ i : Fin N, ∑ i' : Fin N, (L j i * G i i' * L i' j') * (α j * α j')) =
        (∑ i : Fin N, ∑ i' : Fin N, L j i * G i i' * L i' j') * (α j * α j') := by
    rw [Finset.sum_mul]
    refine Finset.sum_congr rfl fun i _ => (Finset.sum_mul _ _ _).symm
  rw [hfactor]
  have hLGL : (∑ i : Fin N, ∑ i' : Fin N, L j i * G i i' * L i' j') = L j j' := by
    have hentry : (L * G * L) j j' = L j j' := by rw [hMP.2.1]
    rw [← hentry, Matrix.mul_apply]
    simp_rw [Matrix.mul_apply, Finset.sum_mul]
    rw [Finset.sum_comm]
  rw [hLGL]

private lemma mp_centered_quad_le_norm_sq {N d : ℕ}
    (x_dict : Fin N → EuclideanSpace ℝ (Fin d)) (u : EuclideanSpace ℝ (Fin d)) :
    let x_bar : EuclideanSpace ℝ (Fin d) := (1 / (N : ℝ)) • ∑ s : Fin N, x_dict s
    let z : Fin N → EuclideanSpace ℝ (Fin d) := fun i => x_dict i - x_bar
    let L := UL.moorePenrosePseudoinverse (UL.centeredGramMatrix x_dict)
    ∑ i : Fin N, ∑ j : Fin N, L i j * (inner ℝ (z i) u * inner ℝ (z j) u) ≤ ‖u‖ ^ 2 := by
  intro x_bar z L
  let α : Fin N → ℝ := fun i => inner ℝ (z i) u
  let p : EuclideanSpace ℝ (Fin d) := ∑ i : Fin N, (∑ j : Fin N, L i j * α j) • z i
  have hp_sq : ‖p‖ ^ 2 = ∑ i : Fin N, ∑ j : Fin N, L i j * (α i * α j) :=
    norm_sq_sum_mp_centered x_dict α
  have hup : inner ℝ u p = ∑ i : Fin N, ∑ j : Fin N, L i j * (α i * α j) := by
    dsimp [p]
    rw [inner_sum]
    refine Finset.sum_congr rfl fun i _ => ?_
    rw [inner_smul_right, real_inner_comm (z i) u, Finset.sum_mul]
    refine Finset.sum_congr rfl fun j _ => ?_
    dsimp [α]
    ring
  have hdiff : 0 ≤ ‖u - p‖ ^ 2 := sq_nonneg _
  rw [norm_sub_sq_real, hup, hp_sq] at hdiff
  dsimp [α] at hdiff
  linarith

private lemma dirichlet_energy_eq {N : ℕ} {E : Type*}
    [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    {L : Matrix (Fin N) (Fin N) ℝ}
    (hSymm : L.transpose = L)
    (hZero : ∀ i : Fin N, ∑ j : Fin N, L i j = 0)
    (u : Fin N → E) :
    ∑ i : Fin N, ∑ j : Fin N, L i j * inner ℝ (u i) (u j) =
      (1 / 2 : ℝ) * ∑ i : Fin N, ∑ j : Fin N, (-L i j) * ‖u i - u j‖ ^ 2 := by
  have hL : ∀ i j : Fin N, L i j = L j i := fun i j => by
    have := congrFun (congrFun hSymm j) i
    simpa [Matrix.transpose_apply] using this
  have hterm : ∀ i j : Fin N,
      (-L i j) * ‖u i - u j‖ ^ 2 =
        2 * (L i j * inner ℝ (u i) (u j)) - L i j * ‖u i‖ ^ 2 - L i j * ‖u j‖ ^ 2 := by
    intro i j
    rw [norm_sub_sq_real]
    ring
  simp_rw [hterm, Finset.sum_sub_distrib]
  have hsum1 : ∑ i : Fin N, ∑ j : Fin N, L i j * ‖u i‖ ^ 2 = 0 := by
    refine Finset.sum_eq_zero fun i _ => ?_
    rw [← Finset.sum_mul, hZero i, zero_mul]
  have hsum2 : ∑ i : Fin N, ∑ j : Fin N, L i j * ‖u j‖ ^ 2 = 0 := by
    rw [Finset.sum_comm]
    refine Finset.sum_eq_zero fun j _ => ?_
    have hcol : ∑ i : Fin N, L i j = 0 := by
      calc ∑ i : Fin N, L i j
          = ∑ i : Fin N, L j i := Finset.sum_congr rfl fun i _ => hL i j
        _ = 0 := hZero j
    rw [← Finset.sum_mul, hcol, zero_mul]
  have hsum_mid :
      ∑ i : Fin N, ∑ j : Fin N, 2 * (L i j * inner ℝ (u i) (u j)) =
        2 * ∑ i : Fin N, ∑ j : Fin N, L i j * inner ℝ (u i) (u j) := by
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun i _ => (Finset.mul_sum _ _ _).symm
  rw [hsum1, hsum2, hsum_mid]
  ring

/-! ### General finite-dimensional Hilbert-space Dirichlet contraction -/

private theorem dirichlet_contraction_general {N d : ℕ}
    {Y₁ Y₂ : Type*}
    [NormedAddCommGroup Y₁] [InnerProductSpace ℝ Y₁] [FiniteDimensional ℝ Y₁]
    [NormedAddCommGroup Y₂] [InnerProductSpace ℝ Y₂] [FiniteDimensional ℝ Y₂]
    {x_dict : Fin N → EuclideanSpace ℝ (Fin d)}
    (h_dir : UL.DirichletFeatureCondition x_dict)
    (b₀ : Y₁)
    (A₀ : EuclideanSpace ℝ (Fin d) →L[ℝ] Y₁)
    {Q C : ℝ} (hQ : 0 ≤ Q) (hC : 0 ≤ C)
    (hA₀ : UL.hilbertSchmidtNorm A₀ ≤ Q)
    (t : Fin N → Y₂)
    (ht : ∀ i j : Fin N, ‖t i - t j‖ ≤ C * ‖(b₀ + A₀ (x_dict i)) - (b₀ + A₀ (x_dict j))‖) :
    ∃ (b : Y₂)
      (A : EuclideanSpace ℝ (Fin d) →L[ℝ] Y₂),
      UL.hilbertSchmidtNorm A ≤ C * Q ∧
      ∀ i : Fin N, t i = b + A (x_dict i) := by
  have hN : 1 ≤ N := h_dir.1
  have hoff : ∀ i j : Fin N, i ≠ j →
      UL.moorePenrosePseudoinverse (UL.centeredGramMatrix x_dict) i j ≤ 0 := h_dir.2.2
  let G := UL.centeredGramMatrix x_dict
  let L := UL.moorePenrosePseudoinverse G
  let J := UL.centeringMatrix N
  have hGT : G.transpose = G := centeredGramMatrix_transpose x_dict
  have hLT : L.transpose = L := moorePenrose_transpose_of_isSymm hGT
  have hLsymm : ∀ i j : Fin N, L i j = L j i := fun i j => by
    have := congrFun (congrFun hLT j) i
    simpa [Matrix.transpose_apply] using this
  have hLzero : ∀ i : Fin N, ∑ j : Fin N, L i j = 0 :=
    moorePenrose_centeredGramMatrix_sum_row x_dict hN
  have hLG : L * G = J := moorePenrose_mul_centeredGram_eq_centering h_dir
  let x_bar : EuclideanSpace ℝ (Fin d) := (1 / (N : ℝ)) • ∑ r : Fin N, x_dict r
  let t_bar : Y₂ := (1 / (N : ℝ)) • ∑ r : Fin N, t r
  let z : Fin N → EuclideanSpace ℝ (Fin d) := fun j => x_dict j - x_bar
  let A : EuclideanSpace ℝ (Fin d) →L[ℝ] Y₂ :=
    ∑ i : Fin N, ∑ j : Fin N, (L i j) • (innerSL ℝ (z j)).smulRight (t i)
  let b : Y₂ := t_bar - A x_bar
  -- 1. Interpolation: t k = b + A (x_dict k)
  have h_interp : ∀ k : Fin N, t k = b + A (x_dict k) := by
    intro k
    have hbA : b + A (x_dict k) = t_bar + A (z k) := by
      dsimp [b, z]
      rw [map_sub]
      abel
    rw [hbA]
    have hAzk : A (z k) = ∑ i : Fin N, (J i k) • t i := by
      dsimp [A]
      simp only [ContinuousLinearMap.sum_apply, ContinuousLinearMap.smul_apply,
        ContinuousLinearMap.smulRight_apply, innerSL_apply_apply]
      refine Finset.sum_congr rfl fun i _ => ?_
      have hj :
          ∑ j : Fin N, (L i j) • (inner ℝ (z j) (z k) • t i) =
            (∑ j : Fin N, L i j * G j k) • t i := by
        rw [Finset.sum_smul]
        refine Finset.sum_congr rfl fun j _ => ?_
        have hGjk : inner ℝ (z j) (z k) = G j k :=
          (centeredGramMatrix_apply_eq_inner x_dict j k).symm
        rw [hGjk, smul_smul]
      rw [hj]
      have hLG_ik : (∑ j : Fin N, L i j * G j k) = J i k := by
        rw [← hLG, Matrix.mul_apply]
      rw [hLG_ik]
    rw [hAzk]
    have hsumJ : ∑ i : Fin N, (J i k) • t i = t k - t_bar := by
      dsimp [J]
      simp_rw [centeringMatrix_apply, sub_smul]
      rw [Finset.sum_sub_distrib, ← Finset.smul_sum]
      have hite : (∑ i : Fin N, (if i = k then (1 : ℝ) else 0) • t i) = t k := by
        have hcongr :
            (∑ i : Fin N, (if i = k then (1 : ℝ) else 0) • t i) =
              ∑ i : Fin N, if i = k then t i else 0 := by
          refine Finset.sum_congr rfl fun i _ => ?_
          by_cases hik : i = k <;> simp [hik]
        rw [hcongr]
        simp
      rw [hite]
    rw [hsumJ]
    abel
  -- 2. Compute hilbertSchmidtNorm A ^ 2 = ∑ i, ∑ j, L i j * inner ℝ (t i) (t j)
  have hadj : ∀ y : Y₂,
      UL.Proof_lem_C_2.adjVec A y =
        ∑ i : Fin N, (∑ j : Fin N, L i j * inner ℝ (t j) y) • z i := by
    intro y
    refine ext_inner_right ℝ fun v => ?_
    rw [UL.Proof_lem_C_2.inner_adjVec_left]
    dsimp [A]
    simp only [ContinuousLinearMap.sum_apply, ContinuousLinearMap.smul_apply,
      ContinuousLinearMap.smulRight_apply, innerSL_apply_apply]
    rw [inner_sum, sum_inner]
    have hlhs :
        (∑ i : Fin N, inner ℝ y (∑ j : Fin N, L i j • inner ℝ (z j) v • t i)) =
          ∑ j : Fin N, ∑ i : Fin N, (L j i * inner ℝ (t i) y) * inner ℝ (z j) v := by
      rw [Finset.sum_comm]
      refine Finset.sum_congr rfl fun i _ => ?_
      rw [inner_sum]
      refine Finset.sum_congr rfl fun j _ => ?_
      rw [inner_smul_right, inner_smul_right, real_inner_comm y (t i), hLsymm i j]
      ring
    rw [hlhs]
    refine Finset.sum_congr rfl fun i _ => ?_
    rw [inner_smul_left, conj_trivial, Finset.sum_mul]
  have hHS_A :
      UL.hilbertSchmidtNorm A ^ 2 = ∑ i : Fin N, ∑ j : Fin N, L i j * inner ℝ (t i) (t j) := by
    let bY₂ := stdOrthonormalBasis ℝ Y₂
    rw [UL.Proof_lem_C_2.hilbertSchmidtNorm_sq A]
    have hnorm_r : ∀ r : Fin (Module.finrank ℝ Y₂),
        ‖UL.Proof_lem_C_2.adjVec A (bY₂ r)‖ ^ 2 =
          ∑ i : Fin N, ∑ j : Fin N, L i j * (inner ℝ (t i) (bY₂ r) * inner ℝ (t j) (bY₂ r)) := by
      intro r
      rw [hadj (bY₂ r)]
      exact norm_sq_sum_mp_centered x_dict (fun j => inner ℝ (t j) (bY₂ r))
    refine Eq.trans (Finset.sum_congr rfl fun r _ => hnorm_r r) ?_
    calc (∑ r : Fin (Module.finrank ℝ Y₂),
            ∑ i : Fin N, ∑ j : Fin N, L i j * (inner ℝ (t i) (bY₂ r) * inner ℝ (t j) (bY₂ r)))
        = ∑ i : Fin N, ∑ r : Fin (Module.finrank ℝ Y₂),
            ∑ j : Fin N, L i j * (inner ℝ (t i) (bY₂ r) * inner ℝ (t j) (bY₂ r)) := Finset.sum_comm
      _ = ∑ i : Fin N, ∑ j : Fin N, ∑ r : Fin (Module.finrank ℝ Y₂),
            L i j * (inner ℝ (t i) (bY₂ r) * inner ℝ (t j) (bY₂ r)) :=
          Finset.sum_congr rfl fun _ _ => Finset.sum_comm
      _ = ∑ i : Fin N, ∑ j : Fin N, L i j * inner ℝ (t i) (t j) := by
          refine Finset.sum_congr rfl fun i _ => Finset.sum_congr rfl fun j _ => ?_
          rw [← Finset.mul_sum]
          congr 1
          conv_rhs => rw [← bY₂.sum_inner_mul_inner (t i) (t j)]
          refine Finset.sum_congr rfl fun r _ => ?_
          rw [real_inner_comm (bY₂ r) (t j)]
  -- 3. Contraction via Dirichlet energy
  let s' : Fin N → Y₁ := fun i => A₀ (z i)
  have hdiff_le : ∀ i j : Fin N, ‖t i - t j‖ ^ 2 ≤ C ^ 2 * ‖s' i - s' j‖ ^ 2 := by
    intro i j
    have hs_eq : (b₀ + A₀ (x_dict i)) - (b₀ + A₀ (x_dict j)) = s' i - s' j := by
      dsimp [s', z]
      simp only [map_sub]
      abel
    have hij : ‖t i - t j‖ ≤ C * ‖s' i - s' j‖ := by
      simpa [hs_eq] using ht i j
    have hsq := pow_le_pow_left₀ (norm_nonneg (t i - t j)) hij 2
    simpa [mul_pow] using hsq
  have hdir_le :
      ∑ i : Fin N, ∑ j : Fin N, L i j * inner ℝ (t i) (t j) ≤
        C ^ 2 * ∑ i : Fin N, ∑ j : Fin N, L i j * inner ℝ (s' i) (s' j) := by
    rw [dirichlet_energy_eq hLT hLzero t, dirichlet_energy_eq hLT hLzero s']
    have hsum_le :
        ∑ i : Fin N, ∑ j : Fin N, (-L i j) * ‖t i - t j‖ ^ 2 ≤
          C ^ 2 * ∑ i : Fin N, ∑ j : Fin N, (-L i j) * ‖s' i - s' j‖ ^ 2 := by
      rw [Finset.mul_sum]
      refine Finset.sum_le_sum fun i _ => ?_
      rw [Finset.mul_sum]
      refine Finset.sum_le_sum fun j _ => ?_
      by_cases hij : i = j
      · subst hij; simp
      · have hL_nonneg : 0 ≤ -L i j := neg_nonneg.mpr (hoff i j hij)
        calc (-L i j) * ‖t i - t j‖ ^ 2
            ≤ (-L i j) * (C ^ 2 * ‖s' i - s' j‖ ^ 2) :=
              mul_le_mul_of_nonneg_left (hdiff_le i j) hL_nonneg
          _ = C ^ 2 * ((-L i j) * ‖s' i - s' j‖ ^ 2) := by ring
    linarith
  -- 4. Bound ∑ i, ∑ j, L i j * inner ℝ (s' i) (s' j) ≤ UL.hilbertSchmidtNorm A₀ ^ 2
  have hs'_le_HS :
      ∑ i : Fin N, ∑ j : Fin N, L i j * inner ℝ (s' i) (s' j) ≤
        UL.hilbertSchmidtNorm A₀ ^ 2 := by
    let bY₁ := stdOrthonormalBasis ℝ Y₁
    have hexpand : ∀ i j : Fin N,
        inner ℝ (s' i) (s' j) =
          ∑ r : Fin (Module.finrank ℝ Y₁),
            inner ℝ (z i) (UL.Proof_lem_C_2.adjVec A₀ (bY₁ r)) *
              inner ℝ (z j) (UL.Proof_lem_C_2.adjVec A₀ (bY₁ r)) := by
      intro i j
      dsimp [s']
      rw [← bY₁.sum_inner_mul_inner (A₀ (z i)) (A₀ (z j))]
      refine Finset.sum_congr rfl fun r _ => ?_
      rw [real_inner_comm (A₀ (z j)) (bY₁ r),
        ← UL.Proof_lem_C_2.inner_adjVec_right A₀ (bY₁ r) (z i),
        ← UL.Proof_lem_C_2.inner_adjVec_right A₀ (bY₁ r) (z j)]
    have hlhs :
        (∑ i : Fin N, ∑ j : Fin N, L i j * inner ℝ (s' i) (s' j)) =
          ∑ r : Fin (Module.finrank ℝ Y₁),
            ∑ i : Fin N, ∑ j : Fin N, L i j *
              (inner ℝ (z i) (UL.Proof_lem_C_2.adjVec A₀ (bY₁ r)) *
                inner ℝ (z j) (UL.Proof_lem_C_2.adjVec A₀ (bY₁ r))) := by
      simp_rw [hexpand, Finset.mul_sum]
      calc (∑ i : Fin N, ∑ j : Fin N, ∑ r : Fin (Module.finrank ℝ Y₁),
              L i j * (inner ℝ (z i) (UL.Proof_lem_C_2.adjVec A₀ (bY₁ r)) *
                inner ℝ (z j) (UL.Proof_lem_C_2.adjVec A₀ (bY₁ r))))
          = ∑ i : Fin N, ∑ r : Fin (Module.finrank ℝ Y₁), ∑ j : Fin N,
              L i j * (inner ℝ (z i) (UL.Proof_lem_C_2.adjVec A₀ (bY₁ r)) *
                inner ℝ (z j) (UL.Proof_lem_C_2.adjVec A₀ (bY₁ r))) :=
            Finset.sum_congr rfl fun _ _ => Finset.sum_comm
        _ = ∑ r : Fin (Module.finrank ℝ Y₁), ∑ i : Fin N, ∑ j : Fin N,
              L i j * (inner ℝ (z i) (UL.Proof_lem_C_2.adjVec A₀ (bY₁ r)) *
                inner ℝ (z j) (UL.Proof_lem_C_2.adjVec A₀ (bY₁ r))) := Finset.sum_comm
    rw [hlhs, UL.Proof_lem_C_2.hilbertSchmidtNorm_sq A₀]
    exact Finset.sum_le_sum fun r _ =>
      mp_centered_quad_le_norm_sq x_dict (UL.Proof_lem_C_2.adjVec A₀ (bY₁ r))
  -- 5. Combine bounds to deduce UL.hilbertSchmidtNorm A ≤ C * Q
  have hA₀_sq : UL.hilbertSchmidtNorm A₀ ^ 2 ≤ Q ^ 2 :=
    pow_le_pow_left₀ (UL.Proof_lem_C_2.hilbertSchmidtNorm_nonneg A₀) hA₀ 2
  have hA_sq : UL.hilbertSchmidtNorm A ^ 2 ≤ (C * Q) ^ 2 := by
    calc UL.hilbertSchmidtNorm A ^ 2
        = ∑ i : Fin N, ∑ j : Fin N, L i j * inner ℝ (t i) (t j) := hHS_A
      _ ≤ C ^ 2 * ∑ i : Fin N, ∑ j : Fin N, L i j * inner ℝ (s' i) (s' j) := hdir_le
      _ ≤ C ^ 2 * UL.hilbertSchmidtNorm A₀ ^ 2 :=
          mul_le_mul_of_nonneg_left hs'_le_HS (sq_nonneg C)
      _ ≤ C ^ 2 * Q ^ 2 := mul_le_mul_of_nonneg_left hA₀_sq (sq_nonneg C)
      _ = (C * Q) ^ 2 := (mul_pow C Q 2).symm
  have hA_nn : 0 ≤ UL.hilbertSchmidtNorm A := UL.Proof_lem_C_2.hilbertSchmidtNorm_nonneg A
  have hCQ_nn : 0 ≤ C * Q := mul_nonneg hC hQ
  have hA_le : UL.hilbertSchmidtNorm A ≤ C * Q := by nlinarith
  exact ⟨b, A, hA_le, h_interp⟩

/-! ### Exported contraction theorems -/

theorem dirichlet_contraction_eucl {N d m₁ m₂ : ℕ}
    {x_dict : Fin N → EuclideanSpace ℝ (Fin d)}
    (h_dir : UL.DirichletFeatureCondition x_dict)
    (b₀ : EuclideanSpace ℝ (Fin m₁))
    (A₀ : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin m₁))
    {Q C : ℝ} (hQ : 0 ≤ Q) (hC : 0 ≤ C)
    (hA₀ : UL.hilbertSchmidtNorm A₀ ≤ Q)
    (t : Fin N → EuclideanSpace ℝ (Fin m₂))
    (ht : ∀ i j : Fin N, ‖t i - t j‖ ≤ C * ‖(b₀ + A₀ (x_dict i)) - (b₀ + A₀ (x_dict j))‖) :
    ∃ (b : EuclideanSpace ℝ (Fin m₂))
      (A : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin m₂)),
      UL.hilbertSchmidtNorm A ≤ C * Q ∧
      ∀ i : Fin N, t i = b + A (x_dict i) :=
  dirichlet_contraction_general h_dir b₀ A₀ hQ hC hA₀ t ht

theorem dirichlet_contraction_zeroSum {N d K : ℕ}
    {x_dict : Fin N → EuclideanSpace ℝ (Fin d)}
    (h_dir : UL.DirichletFeatureCondition x_dict)
    (b₀ : UL.ZeroSumSubspace K)
    (A₀ : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K)
    {Q C : ℝ} (hQ : 0 ≤ Q) (hC : 0 ≤ C)
    (hA₀ : UL.hilbertSchmidtNorm A₀ ≤ Q)
    (t : Fin N → UL.ZeroSumSubspace K)
    (ht : ∀ i j : Fin N, ‖t i - t j‖ ≤ C * ‖(b₀ + A₀ (x_dict i)) - (b₀ + A₀ (x_dict j))‖) :
    ∃ (b : UL.ZeroSumSubspace K)
      (A : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K),
      UL.hilbertSchmidtNorm A ≤ C * Q ∧
      ∀ i : Fin N, t i = b + A (x_dict i) :=
  dirichlet_contraction_general h_dir b₀ A₀ hQ hC hA₀ t ht

theorem dirichlet_contraction_scalar {N d K : ℕ}
    {x_dict : Fin N → EuclideanSpace ℝ (Fin d)}
    (h_dir : UL.DirichletFeatureCondition x_dict)
    (b₀ : UL.ZeroSumSubspace K)
    (A₀ : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K)
    {Q C : ℝ} (hQ : 0 ≤ Q) (hC : 0 ≤ C)
    (hA₀ : UL.hilbertSchmidtNorm A₀ ≤ Q)
    (t : Fin N → ℝ)
    (ht : ∀ i j : Fin N, |t i - t j| ≤ C * ‖(b₀ + A₀ (x_dict i)) - (b₀ + A₀ (x_dict j))‖) :
    ∃ (b : ℝ) (v : EuclideanSpace ℝ (Fin d)),
      ‖v‖ ≤ C * Q ∧
      ∀ i : Fin N, t i = b + inner ℝ v (x_dict i) := by
  have ht_norm : ∀ i j : Fin N,
      ‖t i - t j‖ ≤ C * ‖(b₀ + A₀ (x_dict i)) - (b₀ + A₀ (x_dict j))‖ := by
    intro i j
    simpa [Real.norm_eq_abs] using ht i j
  rcases dirichlet_contraction_general h_dir b₀ A₀ hQ hC hA₀ t ht_norm with ⟨b, A, hA, h_interp⟩
  let v : EuclideanSpace ℝ (Fin d) :=
    (InnerProductSpace.toDual ℝ (EuclideanSpace ℝ (Fin d))).symm A
  have hv_apply : ∀ x : EuclideanSpace ℝ (Fin d), inner ℝ v x = A x := by
    intro x
    dsimp [v]
    rw [InnerProductSpace.toDual_symm_apply]
  have hv_sq : ‖v‖ ^ 2 ≤ (C * Q) * ‖v‖ := by
    calc ‖v‖ ^ 2
        = inner ℝ v v := (real_inner_self_eq_norm_sq v).symm
      _ = A v := hv_apply v
      _ ≤ |A v| := le_abs_self (A v)
      _ = ‖A v‖ := (Real.norm_eq_abs (A v)).symm
      _ ≤ UL.hilbertSchmidtNorm A * ‖v‖ :=
          UL.Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm A v
      _ ≤ (C * Q) * ‖v‖ := mul_le_mul_of_nonneg_right hA (norm_nonneg v)
  have hv_nn : 0 ≤ ‖v‖ := norm_nonneg v
  have hCQ_nn : 0 ≤ C * Q := mul_nonneg hC hQ
  have hv_le : ‖v‖ ≤ C * Q := by nlinarith
  refine ⟨b, v, hv_le, fun i => ?_⟩
  rw [hv_apply]
  exact h_interp i

end UL.Proof_thm_7_1_Race2

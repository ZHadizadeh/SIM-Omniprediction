import Mathlib
import UL.Def.def_2_1
import UL.Def.def_2_matching
import UL.Def.def_5_smooth
import UL.Def.def_7_dirichlet
import UL.Proof.lem_A_1.H1_FaceSubgrad
import UL.Proof.lem_A_3.H1_SimplexProj
import UL.Proof.lem_A_5.H1_Simplex
import UL.Proof.lem_A_6.H2_DanskinStrongConv
import UL.Proof.lem_C_2.H1_HilbertSchmidt
import UL.Proof.lem_C_2.H2_SmoothEntropy
set_option autoImplicit false

namespace UL.Proof_thm_7_1_Race2

open UL.Proof_lem_A_3
open UL.Proof_lem_C_2

noncomputable def cSetDef (K : ℕ) : Set (UL.ZeroSumSubspace K) :=
  {z | (z : EuclideanSpace ℝ (Fin K)) + UL.uniformVec K ∈ UL.Simplex K}

open Classical in
noncomputable def projCDef (K : ℕ) (v : UL.ZeroSumSubspace K) : UL.ZeroSumSubspace K :=
  if h : ∃ z ∈ cSetDef K, IsMinOn (fun z' => ‖v - z'‖) (cSetDef K) z then
    Classical.choose h
  else 0

/-! ### Part 1: Subspace Dimension, `projCDef`, and Convex Gradient Link -/

lemma finrank_zeroSumSubspace_eq {K : ℕ} (hK : 2 ≤ K) :
    Module.finrank ℝ (UL.ZeroSumSubspace K) = K - 1 := by
  let f : EuclideanSpace ℝ (Fin K) →ₗ[ℝ] ℝ := (innerSL ℝ (UL.onesVec K)).toLinearMap
  have hker : UL.ZeroSumSubspace K = LinearMap.ker f := rfl
  have hsurj : Function.Surjective f := by
    intro r
    let j₀ : Fin K := ⟨0, by omega⟩
    refine ⟨r • EuclideanSpace.single j₀ (1 : ℝ), ?_⟩
    change inner ℝ (UL.onesVec K) (r • EuclideanSpace.single j₀ (1 : ℝ)) = r
    rw [inner_smul_right, inner_eq_sum]
    simp [onesVec_apply, EuclideanSpace.single_apply]
  have hrange : LinearMap.range f = ⊤ := LinearMap.range_eq_top.mpr hsurj
  have hrn := LinearMap.finrank_range_add_finrank_ker f
  rw [hrange, finrank_top, Module.finrank_self, finrank_euclideanSpace_fin, ← hker] at hrn
  omega

lemma projCDef_mem_and_isMinOn {K : ℕ} (hK : 2 ≤ K) (v : UL.ZeroSumSubspace K) :
    projCDef K v ∈ cSetDef K ∧
      IsMinOn (fun z' => ‖v - z'‖) (cSetDef K) (projCDef K v) := by
  classical
  let u := UL.uniformVec K
  let q₀ := projSimplexDef K (u + (v : EuclideanSpace ℝ (Fin K)))
  have hq₀_mem : q₀ ∈ UL.Simplex K := projSimplex_mem hK _
  have hq₀_min : IsMinOn (fun q' => ‖(u + (v : EuclideanSpace ℝ (Fin K))) - q'‖)
      (UL.Simplex K) q₀ := projSimplex_isMinOn hK _
  let z₀ : UL.ZeroSumSubspace K :=
    ⟨q₀ - u, UL.Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex hq₀_mem
      (UL.Proof_lem_A_5.uniformVec_mem_simplex hK)⟩
  have hz₀_mem : z₀ ∈ cSetDef K := by
    change (q₀ - u) + u ∈ UL.Simplex K
    simpa [sub_add_cancel] using hq₀_mem
  have hz₀_min : IsMinOn (fun z' => ‖v - z'‖) (cSetDef K) z₀ := by
    intro z' hz'
    change ‖v - z₀‖ ≤ ‖v - z'‖
    have h1 : ‖v - z₀‖ = ‖(u + (v : EuclideanSpace ℝ (Fin K))) - q₀‖ := by
      change ‖(v : EuclideanSpace ℝ (Fin K)) - (q₀ - u)‖ = _
      congr 1; abel
    have h2 : ‖v - z'‖ =
        ‖(u + (v : EuclideanSpace ℝ (Fin K))) - ((z' : EuclideanSpace ℝ (Fin K)) + u)‖ := by
      change ‖(v : EuclideanSpace ℝ (Fin K)) - (z' : EuclideanSpace ℝ (Fin K))‖ = _
      congr 1; abel
    rw [h1, h2]
    exact hq₀_min hz'
  have hex : ∃ z ∈ cSetDef K, IsMinOn (fun z' => ‖v - z'‖) (cSetDef K) z :=
    ⟨z₀, hz₀_mem, hz₀_min⟩
  unfold projCDef
  rw [dif_pos hex]
  exact Classical.choose_spec hex

lemma uniformVec_add_projCDef_eq {K : ℕ} (hK : 2 ≤ K) (v : UL.ZeroSumSubspace K) :
    UL.uniformVec K + (projCDef K v : EuclideanSpace ℝ (Fin K)) =
      projSimplexDef K (UL.uniformVec K + (v : EuclideanSpace ℝ (Fin K))) := by
  obtain ⟨hz_mem, hz_min⟩ := projCDef_mem_and_isMinOn hK v
  let u := UL.uniformVec K
  let q := u + (projCDef K v : EuclideanSpace ℝ (Fin K))
  have hq_mem : q ∈ UL.Simplex K := by
    dsimp [q, u]
    rw [add_comm]
    exact hz_mem
  have hq_min : IsMinOn (fun q' => ‖(u + (v : EuclideanSpace ℝ (Fin K))) - q'‖)
      (UL.Simplex K) q := by
    intro y hy
    let zy : UL.ZeroSumSubspace K :=
      ⟨y - u, UL.Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex hy
        (UL.Proof_lem_A_5.uniformVec_mem_simplex hK)⟩
    have hzy_mem : zy ∈ cSetDef K := by
      change (y - u) + u ∈ UL.Simplex K
      simpa [sub_add_cancel] using hy
    have hle : ‖v - projCDef K v‖ ≤ ‖v - zy‖ := hz_min hzy_mem
    have h1 : ‖(u + (v : EuclideanSpace ℝ (Fin K))) - q‖ = ‖v - projCDef K v‖ := by
      change ‖(u + (v : EuclideanSpace ℝ (Fin K))) - (u + (projCDef K v : EuclideanSpace ℝ (Fin K)))‖ =
        ‖(v : EuclideanSpace ℝ (Fin K)) - (projCDef K v : EuclideanSpace ℝ (Fin K))‖
      congr 1; abel
    have h2 : ‖(u + (v : EuclideanSpace ℝ (Fin K))) - y‖ = ‖v - zy‖ := by
      change ‖(u + (v : EuclideanSpace ℝ (Fin K))) - y‖ =
        ‖(v : EuclideanSpace ℝ (Fin K)) - (y - u)‖
      congr 1; abel
    change ‖(u + (v : EuclideanSpace ℝ (Fin K))) - q‖ ≤ ‖(u + (v : EuclideanSpace ℝ (Fin K))) - y‖
    rwa [h1, h2]
  exact (eq_projSimplex_of_inner_le_zero hK (u + (v : EuclideanSpace ℝ (Fin K))) hq_mem
    ((isMinOn_simplex_iff_inner_le_zero (u + (v : EuclideanSpace ℝ (Fin K))) hq_mem).mp hq_min)).symm

lemma uniformVec_add_projCDef_mem_simplex {K : ℕ} (hK : 2 ≤ K) (v : UL.ZeroSumSubspace K) :
    UL.uniformVec K + (projCDef K v : EuclideanSpace ℝ (Fin K)) ∈ UL.Simplex K := by
  rw [uniformVec_add_projCDef_eq hK v]
  exact projSimplex_mem hK _

lemma projCDef_eq_self {K : ℕ} (hK : 2 ≤ K) {z : UL.ZeroSumSubspace K} (hz : z ∈ cSetDef K) :
    projCDef K z = z := by
  apply Subtype.ext
  have hmem : UL.uniformVec K + (z : EuclideanSpace ℝ (Fin K)) ∈ UL.Simplex K := by
    rw [add_comm]; exact hz
  have heq := uniformVec_add_projCDef_eq hK z
  rw [projSimplex_eq_self hK hmem] at heq
  exact add_left_cancel heq

lemma projCDef_nonexpansive {K : ℕ} (hK : 2 ≤ K) (v₁ v₂ : UL.ZeroSumSubspace K) :
    ‖projCDef K v₁ - projCDef K v₂‖ ≤ ‖v₁ - v₂‖ := by
  have h1 : ‖projCDef K v₁ - projCDef K v₂‖ =
      ‖(UL.uniformVec K + (projCDef K v₁ : EuclideanSpace ℝ (Fin K))) -
        (UL.uniformVec K + (projCDef K v₂ : EuclideanSpace ℝ (Fin K)))‖ := by
    change ‖(projCDef K v₁ : EuclideanSpace ℝ (Fin K)) - (projCDef K v₂ : EuclideanSpace ℝ (Fin K))‖ = _
    congr 1; abel
  have h2 : ‖(UL.uniformVec K + (v₁ : EuclideanSpace ℝ (Fin K))) -
      (UL.uniformVec K + (v₂ : EuclideanSpace ℝ (Fin K)))‖ = ‖v₁ - v₂‖ := by
    change _ = ‖(v₁ : EuclideanSpace ℝ (Fin K)) - (v₂ : EuclideanSpace ℝ (Fin K))‖
    congr 1; abel
  rw [h1, uniformVec_add_projCDef_eq hK v₁, uniformVec_add_projCDef_eq hK v₂, ← h2]
  exact projSimplex_nonexpansive hK _ _

lemma projCDef_inner_le_zero {K : ℕ} (hK : 2 ≤ K) (v : UL.ZeroSumSubspace K)
    {z : UL.ZeroSumSubspace K} (hz : z ∈ cSetDef K) :
    inner ℝ (v - projCDef K v) (z - projCDef K v) ≤ 0 := by
  let u := UL.uniformVec K
  have hy : u + (z : EuclideanSpace ℝ (Fin K)) ∈ UL.Simplex K := by
    rw [add_comm]; exact hz
  have hvi := projSimplex_inner_le_zero hK (u + (v : EuclideanSpace ℝ (Fin K))) hy
  rw [← uniformVec_add_projCDef_eq hK v] at hvi
  have h1 : (u + (v : EuclideanSpace ℝ (Fin K))) -
      (u + (projCDef K v : EuclideanSpace ℝ (Fin K))) =
      ((v - projCDef K v : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) := by
    change _ = (v : EuclideanSpace ℝ (Fin K)) - (projCDef K v : EuclideanSpace ℝ (Fin K))
    abel
  have h2 : (u + (z : EuclideanSpace ℝ (Fin K))) -
      (u + (projCDef K v : EuclideanSpace ℝ (Fin K))) =
      ((z - projCDef K v : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) := by
    change _ = (z : EuclideanSpace ℝ (Fin K)) - (projCDef K v : EuclideanSpace ℝ (Fin K))
    abel
  rw [h1, h2] at hvi
  exact hvi

private noncomputable def psiBase {K : ℕ} (v : UL.ZeroSumSubspace K) : ℝ :=
  inner ℝ (v : EuclideanSpace ℝ (Fin K)) (projCDef K v : EuclideanSpace ℝ (Fin K)) -
    (1 / 2 : ℝ) * ‖projCDef K v‖ ^ 2

private lemma psiBase_eq_half_diff {K : ℕ} (v : UL.ZeroSumSubspace K) :
    psiBase v = (1 / 2 : ℝ) * ‖v‖ ^ 2 - (1 / 2 : ℝ) * ‖v - projCDef K v‖ ^ 2 := by
  unfold psiBase
  have h1 : ‖v‖ = ‖(v : EuclideanSpace ℝ (Fin K))‖ := rfl
  have h2 : ‖projCDef K v‖ = ‖(projCDef K v : EuclideanSpace ℝ (Fin K))‖ := rfl
  have h3 : ‖v - projCDef K v‖ =
      ‖(v : EuclideanSpace ℝ (Fin K)) - (projCDef K v : EuclideanSpace ℝ (Fin K))‖ := rfl
  rw [h1, h2, h3, norm_sub_sq_real]
  ring

private lemma psiBase_ge_of_mem {K : ℕ} (hK : 2 ≤ K) (v : UL.ZeroSumSubspace K)
    {z : UL.ZeroSumSubspace K} (hz : z ∈ cSetDef K) :
    inner ℝ (v : EuclideanSpace ℝ (Fin K)) (z : EuclideanSpace ℝ (Fin K)) -
        (1 / 2 : ℝ) * ‖z‖ ^ 2 ≤ psiBase v := by
  obtain ⟨_, hz_min⟩ := projCDef_mem_and_isMinOn hK v
  have hle : ‖v - projCDef K v‖ ≤ ‖v - z‖ := hz_min hz
  have hsq : ‖v - projCDef K v‖ ^ 2 ≤ ‖v - z‖ ^ 2 :=
    pow_le_pow_left₀ (norm_nonneg _) hle 2
  have hident : inner ℝ (v : EuclideanSpace ℝ (Fin K)) (z : EuclideanSpace ℝ (Fin K)) -
      (1 / 2 : ℝ) * ‖z‖ ^ 2 =
      (1 / 2 : ℝ) * ‖v‖ ^ 2 - (1 / 2 : ℝ) * ‖v - z‖ ^ 2 := by
    have h1 : ‖v‖ = ‖(v : EuclideanSpace ℝ (Fin K))‖ := rfl
    have h2 : ‖z‖ = ‖(z : EuclideanSpace ℝ (Fin K))‖ := rfl
    have h3 : ‖v - z‖ = ‖(v : EuclideanSpace ℝ (Fin K)) - (z : EuclideanSpace ℝ (Fin K))‖ := rfl
    rw [h1, h2, h3, norm_sub_sq_real]; ring
  rw [hident, psiBase_eq_half_diff]
  linarith

private noncomputable def psiScaled {K : ℕ} (β : ℝ) (aHat s : UL.ZeroSumSubspace K) : ℝ :=
  (1 / β) * psiBase (aHat + β • s)

private lemma psiScaled_quad_bound {K : ℕ} (hK : 2 ≤ K) {β : ℝ} (hβ : 0 < β)
    (aHat s s' : UL.ZeroSumSubspace K) :
    ‖psiScaled β aHat s' - psiScaled β aHat s -
        inner ℝ (projCDef K (aHat + β • s)) (s' - s)‖ ≤ β * ‖s' - s‖ ^ 2 := by
  set v := aHat + β • s
  set w := aHat + β • s'
  set zv := projCDef K v
  set zw := projCDef K w
  have hzv_mem : zv ∈ cSetDef K := (projCDef_mem_and_isMinOn hK v).1
  have hzw_mem : zw ∈ cSetDef K := (projCDef_mem_and_isMinOn hK w).1
  have hwv : (w : EuclideanSpace ℝ (Fin K)) - (v : EuclideanSpace ℝ (Fin K)) =
      β • ((s' : EuclideanSpace ℝ (Fin K)) - (s : EuclideanSpace ℝ (Fin K))) := by
    dsimp [w, v]; push_cast; rw [smul_sub]; abel
  have hlow_psi : inner ℝ ((w : EuclideanSpace ℝ (Fin K)) - (v : EuclideanSpace ℝ (Fin K)))
      (zv : EuclideanSpace ℝ (Fin K)) ≤ psiBase w - psiBase v := by
    have hge := psiBase_ge_of_mem hK w hzv_mem
    unfold psiBase at *
    rw [inner_sub_left]
    linarith
  have hup_psi : psiBase w - psiBase v ≤
      inner ℝ ((w : EuclideanSpace ℝ (Fin K)) - (v : EuclideanSpace ℝ (Fin K)))
        (zw : EuclideanSpace ℝ (Fin K)) := by
    have hge := psiBase_ge_of_mem hK v hzw_mem
    unfold psiBase at *
    rw [inner_sub_left]
    linarith
  have h_id_low : inner ℝ ((w : EuclideanSpace ℝ (Fin K)) - (v : EuclideanSpace ℝ (Fin K)))
      (zv : EuclideanSpace ℝ (Fin K)) = β * inner ℝ zv (s' - s) := by
    rw [hwv, inner_smul_left, conj_trivial, real_inner_comm]
    rfl
  have h_nonneg : 0 ≤ psiScaled β aHat s' - psiScaled β aHat s - inner ℝ zv (s' - s) := by
    unfold psiScaled
    change 0 ≤ (1 / β) * psiBase w - (1 / β) * psiBase v - inner ℝ zv (s' - s)
    have hmul := mul_le_mul_of_nonneg_left hlow_psi (one_div_pos.mpr hβ).le
    rw [h_id_low] at hmul
    have hc : (1 / β) * (β * inner ℝ zv (s' - s)) = inner ℝ zv (s' - s) := by field_simp [hβ.ne']
    have h1 : (1 / β) * (psiBase w - psiBase v) =
        (1 / β) * psiBase w - (1 / β) * psiBase v := by ring
    linarith
  have h_upper : psiScaled β aHat s' - psiScaled β aHat s - inner ℝ zv (s' - s) ≤
      β * ‖s' - s‖ ^ 2 := by
    unfold psiScaled
    change (1 / β) * psiBase w - (1 / β) * psiBase v - inner ℝ zv (s' - s) ≤ β * ‖s' - s‖ ^ 2
    have hdiff_psi : psiBase w - psiBase v -
        inner ℝ ((w : EuclideanSpace ℝ (Fin K)) - (v : EuclideanSpace ℝ (Fin K)))
          (zv : EuclideanSpace ℝ (Fin K)) ≤
        inner ℝ ((w : EuclideanSpace ℝ (Fin K)) - (v : EuclideanSpace ℝ (Fin K)))
          ((zw : EuclideanSpace ℝ (Fin K)) - (zv : EuclideanSpace ℝ (Fin K))) := by
      rw [inner_sub_right]; linarith
    have hcs : inner ℝ ((w : EuclideanSpace ℝ (Fin K)) - (v : EuclideanSpace ℝ (Fin K)))
        ((zw : EuclideanSpace ℝ (Fin K)) - (zv : EuclideanSpace ℝ (Fin K))) ≤
        β ^ 2 * ‖s' - s‖ ^ 2 := by
      have hn_wv : ‖(w : EuclideanSpace ℝ (Fin K)) - (v : EuclideanSpace ℝ (Fin K))‖ =
          β * ‖s' - s‖ := by
        rw [hwv, norm_smul, Real.norm_of_nonneg hβ.le]
        rfl
      have hn_zwv : ‖(zw : EuclideanSpace ℝ (Fin K)) - (zv : EuclideanSpace ℝ (Fin K))‖ ≤
          β * ‖s' - s‖ := by
        have heq1 : ‖(zw : EuclideanSpace ℝ (Fin K)) - (zv : EuclideanSpace ℝ (Fin K))‖ =
            ‖zw - zv‖ := rfl
        have heq2 : ‖w - v‖ =
            ‖(w : EuclideanSpace ℝ (Fin K)) - (v : EuclideanSpace ℝ (Fin K))‖ := rfl
        rw [heq1, ← hn_wv, ← heq2]
        exact projCDef_nonexpansive hK w v
      calc inner ℝ _ _
          ≤ ‖(w : EuclideanSpace ℝ (Fin K)) - (v : EuclideanSpace ℝ (Fin K))‖ *
              ‖(zw : EuclideanSpace ℝ (Fin K)) - (zv : EuclideanSpace ℝ (Fin K))‖ :=
            real_inner_le_norm _ _
        _ ≤ (β * ‖s' - s‖) * (β * ‖s' - s‖) := by
            rw [hn_wv]
            exact mul_le_mul_of_nonneg_left hn_zwv (by positivity)
        _ = β ^ 2 * ‖s' - s‖ ^ 2 := by ring
    have hmul := mul_le_mul_of_nonneg_left (le_trans hdiff_psi hcs) (one_div_pos.mpr hβ).le
    have halg1 : (1 / β) * (psiBase w - psiBase v -
        inner ℝ ((w : EuclideanSpace ℝ (Fin K)) - (v : EuclideanSpace ℝ (Fin K)))
          (zv : EuclideanSpace ℝ (Fin K))) =
        (1 / β) * psiBase w - (1 / β) * psiBase v - inner ℝ zv (s' - s) := by
      rw [h_id_low]; field_simp [hβ.ne']
    have halg2 : (1 / β) * (β ^ 2 * ‖s' - s‖ ^ 2) = β * ‖s' - s‖ ^ 2 := by field_simp [hβ.ne']
    linarith
  rw [Real.norm_of_nonneg h_nonneg]
  exact h_upper

private lemma psiScaled_hasGradientAt {K : ℕ} (hK : 2 ≤ K) {β : ℝ} (hβ : 0 < β)
    (aHat s : UL.ZeroSumSubspace K) :
    HasGradientAt (psiScaled β aHat) (projCDef K (aHat + β • s)) s := by
  rw [hasGradientAt_iff_tendsto]
  have h_squeeze : ∀ s' : UL.ZeroSumSubspace K,
      ‖s' - s‖⁻¹ * ‖psiScaled β aHat s' - psiScaled β aHat s -
        inner ℝ (projCDef K (aHat + β • s)) (s' - s)‖ ≤ β * ‖s' - s‖ := by
    intro s'
    by_cases hs0 : ‖s' - s‖ = 0
    · simp [hs0]
    · have hpos : 0 < ‖s' - s‖ := lt_of_le_of_ne (norm_nonneg _) (Ne.symm hs0)
      calc ‖s' - s‖⁻¹ * ‖psiScaled β aHat s' - psiScaled β aHat s -
            inner ℝ (projCDef K (aHat + β • s)) (s' - s)‖
          ≤ ‖s' - s‖⁻¹ * (β * ‖s' - s‖ ^ 2) :=
            mul_le_mul_of_nonneg_left (psiScaled_quad_bound hK hβ aHat s s')
              (inv_nonneg.mpr hpos.le)
        _ = β * ‖s' - s‖ := by rw [sq, mul_left_comm, inv_mul_cancel_left₀ hs0]
  have h_tendsto : Filter.Tendsto (fun s' : UL.ZeroSumSubspace K => β * ‖s' - s‖)
      (nhds s) (nhds 0) := by
    have hc : Continuous (fun s' : UL.ZeroSumSubspace K => β * ‖s' - s‖) :=
      continuous_const.mul ((continuous_id.sub continuous_const).norm)
    simpa using hc.tendsto s
  exact squeeze_zero (fun _ => by positivity) h_squeeze h_tendsto

private lemma psiScaled_convexOn {K : ℕ} (hK : 2 ≤ K) {β : ℝ} (hβ : 0 < β)
    (aHat : UL.ZeroSumSubspace K) :
    ConvexOn ℝ Set.univ (psiScaled β aHat) := by
  refine ⟨convex_univ, fun s₁ _ s₂ _ a b ha hb hab => ?_⟩
  set v₁ := aHat + β • s₁
  set v₂ := aHat + β • s₂
  set vc := aHat + β • (a • s₁ + b • s₂)
  change (1 / β) * psiBase vc ≤ a * ((1 / β) * psiBase v₁) + b * ((1 / β) * psiBase v₂)
  have hvc_coe : (vc : EuclideanSpace ℝ (Fin K)) =
      a • (v₁ : EuclideanSpace ℝ (Fin K)) + b • (v₂ : EuclideanSpace ℝ (Fin K)) := by
    dsimp [vc, v₁, v₂]
    push_cast
    calc (aHat : EuclideanSpace ℝ (Fin K)) +
          β • (a • (s₁ : EuclideanSpace ℝ (Fin K)) + b • (s₂ : EuclideanSpace ℝ (Fin K)))
        = (a + b) • (aHat : EuclideanSpace ℝ (Fin K)) +
            (β • (a • (s₁ : EuclideanSpace ℝ (Fin K))) +
              β • (b • (s₂ : EuclideanSpace ℝ (Fin K)))) := by
            rw [hab, one_smul, smul_add]
      _ = a • ((aHat : EuclideanSpace ℝ (Fin K)) + β • (s₁ : EuclideanSpace ℝ (Fin K))) +
            b • ((aHat : EuclideanSpace ℝ (Fin K)) + β • (s₂ : EuclideanSpace ℝ (Fin K))) := by
            rw [add_smul, smul_add, smul_add, smul_comm β a, smul_comm β b]
            abel
  set zc := projCDef K vc
  have hzc_mem : zc ∈ cSetDef K := (projCDef_mem_and_isMinOn hK vc).1
  have h1 := psiBase_ge_of_mem hK v₁ hzc_mem
  have h2 := psiBase_ge_of_mem hK v₂ hzc_mem
  have h_psi_c : psiBase vc =
      a * (inner ℝ (v₁ : EuclideanSpace ℝ (Fin K)) (zc : EuclideanSpace ℝ (Fin K)) -
        (1 / 2 : ℝ) * ‖zc‖ ^ 2) +
      b * (inner ℝ (v₂ : EuclideanSpace ℝ (Fin K)) (zc : EuclideanSpace ℝ (Fin K)) -
        (1 / 2 : ℝ) * ‖zc‖ ^ 2) := by
    unfold psiBase
    change inner ℝ (vc : EuclideanSpace ℝ (Fin K)) (zc : EuclideanSpace ℝ (Fin K)) -
      (1 / 2 : ℝ) * ‖zc‖ ^ 2 = _
    rw [hvc_coe, inner_add_left, inner_smul_left, inner_smul_left, conj_trivial, conj_trivial]
    have hb_eq : b = 1 - a := by linarith
    rw [hb_eq]; ring
  have h_psi_le : psiBase vc ≤ a * psiBase v₁ + b * psiBase v₂ := by
    linarith [mul_le_mul_of_nonneg_left h1 ha, mul_le_mul_of_nonneg_left h2 hb]
  have hmul := mul_le_mul_of_nonneg_left h_psi_le (one_div_pos.mpr hβ).le
  linarith [show (1 / β) * (a * psiBase v₁ + b * psiBase v₂) =
    a * ((1 / β) * psiBase v₁) + b * ((1 / β) * psiBase v₂) by ring]

theorem projC_link_and_rank
    {d K : ℕ} (hK : 2 ≤ K) {β : ℝ} (hβ : 0 < β)
    (aHat : UL.ZeroSumSubspace K)
    (WHat : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K) :
    Module.finrank ℝ (LinearMap.range WHat.toLinearMap) ≤ K - 1 ∧
    (let ρ : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) :=
      fun s => UL.uniformVec K + (projCDef K (aHat + β • s) : EuclideanSpace ℝ (Fin K))
     (∀ s : UL.ZeroSumSubspace K, ρ s ∈ UL.Simplex K) ∧
     LipschitzWith (Real.toNNReal β) ρ ∧
     ∃ Ψ : UL.ZeroSumSubspace K → ℝ,
       ConvexOn ℝ Set.univ Ψ ∧
       Differentiable ℝ Ψ ∧
       ∀ s : UL.ZeroSumSubspace K,
         ρ s - UL.uniformVec K = (↑(gradient Ψ s) : EuclideanSpace ℝ (Fin K))) := by
  refine ⟨?_, ?_⟩
  · rw [← finrank_zeroSumSubspace_eq hK]
    exact Submodule.finrank_le (LinearMap.range WHat.toLinearMap)
  · intro ρ
    refine ⟨fun s => uniformVec_add_projCDef_mem_simplex hK (aHat + β • s), ?_, ?_⟩
    · refine LipschitzWith.of_dist_le_mul fun s₁ s₂ => ?_
      rw [Real.coe_toNNReal β hβ.le, dist_eq_norm, dist_eq_norm]
      have hdiff : ρ s₁ - ρ s₂ =
          ((projCDef K (aHat + β • s₁) - projCDef K (aHat + β • s₂) : UL.ZeroSumSubspace K) :
            EuclideanSpace ℝ (Fin K)) := by
        dsimp [ρ]
        change _ = (projCDef K (aHat + β • s₁) : EuclideanSpace ℝ (Fin K)) -
          (projCDef K (aHat + β • s₂) : EuclideanSpace ℝ (Fin K))
        abel
      have hnorm : ‖ρ s₁ - ρ s₂‖ = ‖projCDef K (aHat + β • s₁) - projCDef K (aHat + β • s₂)‖ := by
        rw [hdiff]; rfl
      rw [hnorm]
      calc ‖projCDef K (aHat + β • s₁) - projCDef K (aHat + β • s₂)‖
          ≤ ‖(aHat + β • s₁) - (aHat + β • s₂)‖ := projCDef_nonexpansive hK _ _
        _ = ‖β • (s₁ - s₂)‖ := by
            congr 1; rw [smul_sub]; abel
        _ = β * ‖s₁ - s₂‖ := by rw [norm_smul, Real.norm_of_nonneg hβ.le]
    · refine ⟨psiScaled β aHat, psiScaled_convexOn hK hβ aHat,
        fun s => (psiScaled_hasGradientAt hK hβ aHat s).differentiableAt, fun s => ?_⟩
      rw [(psiScaled_hasGradientAt hK hβ aHat s).gradient]
      dsimp [ρ]
      abel

/-! ### Part 2: Smooth Entropy Lipschitz, Decomposition, and Integrability -/

private noncomputable def hPhiFun {K : ℕ} (Φ : UL.Simplex K → ℝ)
    (q : EuclideanSpace ℝ (Fin K)) : ℝ :=
  inner ℝ (q - UL.uniformVec K) (UL.simplexGrad Φ q) -
    UL.extendSimplex Φ q - UL.matchingPotential Φ 0

private lemma extendSimplex_subgrad_simplex {K : ℕ} {β lam M : ℝ}
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    {p q : EuclideanSpace ℝ (Fin K)} (hp : p ∈ UL.Simplex K) (hq : q ∈ UL.Simplex K) :
    UL.extendSimplex Φ p + inner ℝ (UL.simplexGrad Φ p) (q - p) ≤ UL.extendSimplex Φ q := by
  have hConv := extendSimplex_convex_of_smooth hΦ
  have hGrad := (hasFaceGradAt_univ_simplexGrad hΦ hp).2
  have hp_f : p ∈ UL.SimplexFace K Finset.univ := by rwa [UL.Proof_lem_A_5.simplexFace_univ K]
  have hq_f : q ∈ UL.SimplexFace K Finset.univ := by rwa [UL.Proof_lem_A_5.simplexFace_univ K]
  exact UL.Proof_lem_A_1.face_subgrad_ineq hConv hp_f hq_f hGrad

private lemma norm_sub_uniformVec_le_one {K : ℕ} (hK : 2 ≤ K)
    {q : EuclideanSpace ℝ (Fin K)} (hq : q ∈ UL.Simplex K) :
    ‖q - UL.uniformVec K‖ ≤ 1 := by
  have hK_pos : (0 : ℝ) < (K : ℝ) := Nat.cast_pos.mpr (by omega)
  have hu_inn : inner ℝ q (UL.uniformVec K) = 1 / (K : ℝ) := by
    rw [inner_eq_sum]
    have h1 : ∑ i : Fin K, q i * UL.uniformVec K i = (1 / (K : ℝ)) * ∑ i : Fin K, q i := by
      rw [Finset.mul_sum]
      refine Finset.sum_congr rfl fun i _ => ?_
      rw [UL.Proof_lem_A_5.uniformVec_apply, mul_comm]
    rw [h1, hq.2, mul_one]
  have hu_sq : ‖UL.uniformVec K‖ ^ 2 = 1 / (K : ℝ) := by
    rw [norm_sq_eq_sum]
    have h1 : ∑ i : Fin K, (UL.uniformVec K i) ^ 2 = ∑ _i : Fin K, (1 / (K : ℝ)) ^ 2 :=
      Finset.sum_congr rfl fun i _ => by rw [UL.Proof_lem_A_5.uniformVec_apply]
    rw [h1, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
    field_simp [hK_pos.ne']
  have hq_sq : ‖q‖ ^ 2 ≤ 1 := by
    have hle := norm_le_one_of_mem_simplex hq
    nlinarith [norm_nonneg q]
  have hsub_sq : ‖q - UL.uniformVec K‖ ^ 2 ≤ 1 := by
    rw [norm_sub_sq_real, hu_inn, hu_sq]
    have hnn : 0 ≤ 1 / (K : ℝ) := by positivity
    linarith
  nlinarith [norm_nonneg (q - UL.uniformVec K)]

private lemma hPhiFun_lipschitz {K : ℕ} (hK : 2 ≤ K) {β lam M : ℝ}
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    {q₁ q₂ : EuclideanSpace ℝ (Fin K)} (hq₁ : q₁ ∈ UL.Simplex K) (hq₂ : q₂ ∈ UL.Simplex K) :
    |hPhiFun Φ q₁ - hPhiFun Φ q₂| ≤ lam * ‖q₁ - q₂‖ := by
  have h_one_dir : ∀ {p₁ p₂ : EuclideanSpace ℝ (Fin K)},
      p₁ ∈ UL.Simplex K → p₂ ∈ UL.Simplex K →
      hPhiFun Φ p₁ - hPhiFun Φ p₂ ≤ lam * ‖p₁ - p₂‖ := by
    intro p₁ p₂ hp₁ hp₂
    have hsub := extendSimplex_subgrad_simplex hΦ hp₂ hp₁
    have h_alg : hPhiFun Φ p₁ - hPhiFun Φ p₂ ≤
        inner ℝ (p₁ - UL.uniformVec K) (UL.simplexGrad Φ p₁ - UL.simplexGrad Φ p₂) := by
      unfold hPhiFun
      have h_inn : inner ℝ (UL.simplexGrad Φ p₂) (p₁ - p₂) =
          inner ℝ (p₁ - UL.uniformVec K) (UL.simplexGrad Φ p₂) -
            inner ℝ (p₂ - UL.uniformVec K) (UL.simplexGrad Φ p₂) := by
        rw [real_inner_comm, ← inner_sub_left]
        congr 1; abel
      rw [inner_sub_right]
      linarith
    calc hPhiFun Φ p₁ - hPhiFun Φ p₂
        ≤ inner ℝ (p₁ - UL.uniformVec K) (UL.simplexGrad Φ p₁ - UL.simplexGrad Φ p₂) := h_alg
      _ ≤ ‖p₁ - UL.uniformVec K‖ * ‖UL.simplexGrad Φ p₁ - UL.simplexGrad Φ p₂‖ :=
          real_inner_le_norm _ _
      _ ≤ 1 * (lam * ‖p₁ - p₂‖) :=
          mul_le_mul (norm_sub_uniformVec_le_one hK hp₁) (hΦ.2.2.2.2.1 p₁ hp₁ p₂ hp₂)
            (norm_nonneg _) zero_le_one
      _ = lam * ‖p₁ - p₂‖ := one_mul _
  rw [abs_sub_le_iff]
  exact ⟨h_one_dir hq₁ hq₂, by simpa [norm_sub_rev] using h_one_dir hq₂ hq₁⟩

private lemma finiteCanonicalLoss_lipschitz {K : ℕ} {β lam M : ℝ}
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    {q₁ q₂ : EuclideanSpace ℝ (Fin K)} (hq₁ : q₁ ∈ UL.Simplex K) (hq₂ : q₂ ∈ UL.Simplex K)
    (y : Fin K) :
    |UL.finiteCanonicalLoss Φ q₁ y - UL.finiteCanonicalLoss Φ q₂ y| ≤ 2 * lam * ‖q₁ - q₂‖ := by
  have hlam : 0 < lam := hΦ.2.1
  have h_one_dir : ∀ {p₁ p₂ : EuclideanSpace ℝ (Fin K)},
      p₁ ∈ UL.Simplex K → p₂ ∈ UL.Simplex K →
      UL.finiteCanonicalLoss Φ p₁ y - UL.finiteCanonicalLoss Φ p₂ y ≤ 2 * lam * ‖p₁ - p₂‖ := by
    intro p₁ p₂ hp₁ hp₂
    rw [finiteCanonicalLoss_eq hΦ hp₁ y, finiteCanonicalLoss_eq hΦ hp₂ y]
    have hsub := extendSimplex_subgrad_simplex hΦ hp₂ hp₁
    set ey : EuclideanSpace ℝ (Fin K) := EuclideanSpace.single y (1 : ℝ)
    have hey_mem : ey ∈ UL.Simplex K := UL.Proof_lem_A_1.single_mem_simplex y
    have hnorm_ey : ‖p₁ - ey‖ ≤ 2 := by
      calc ‖p₁ - ey‖ ≤ ‖p₁‖ + ‖ey‖ := norm_sub_le _ _
        _ ≤ 1 + 1 := add_le_add (norm_le_one_of_mem_simplex hp₁) (norm_le_one_of_mem_simplex hey_mem)
        _ = 2 := by norm_num
    have h_alg : (-UL.extendSimplex Φ p₁ + inner ℝ (p₁ - ey) (UL.simplexGrad Φ p₁)) -
        (-UL.extendSimplex Φ p₂ + inner ℝ (p₂ - ey) (UL.simplexGrad Φ p₂)) ≤
        inner ℝ (p₁ - ey) (UL.simplexGrad Φ p₁ - UL.simplexGrad Φ p₂) := by
      have h_inn : inner ℝ (UL.simplexGrad Φ p₂) (p₁ - p₂) =
          inner ℝ (p₁ - ey) (UL.simplexGrad Φ p₂) - inner ℝ (p₂ - ey) (UL.simplexGrad Φ p₂) := by
        rw [real_inner_comm, ← inner_sub_left]
        congr 1; abel
      rw [inner_sub_right]
      linarith
    calc (-UL.extendSimplex Φ p₁ + inner ℝ (p₁ - ey) (UL.simplexGrad Φ p₁)) -
          (-UL.extendSimplex Φ p₂ + inner ℝ (p₂ - ey) (UL.simplexGrad Φ p₂))
        ≤ inner ℝ (p₁ - ey) (UL.simplexGrad Φ p₁ - UL.simplexGrad Φ p₂) := h_alg
      _ ≤ ‖p₁ - ey‖ * ‖UL.simplexGrad Φ p₁ - UL.simplexGrad Φ p₂‖ := real_inner_le_norm _ _
      _ ≤ 2 * (lam * ‖p₁ - p₂‖) :=
          mul_le_mul hnorm_ey (hΦ.2.2.2.2.1 p₁ hp₁ p₂ hp₂) (norm_nonneg _) (by norm_num)
      _ = 2 * lam * ‖p₁ - p₂‖ := by ring
  rw [abs_sub_le_iff]
  exact ⟨h_one_dir hq₁ hq₂, by simpa [norm_sub_rev] using h_one_dir hq₂ hq₁⟩

private lemma finiteCanonicalLoss_decomp {K : ℕ} {β lam M : ℝ}
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    {q : EuclideanSpace ℝ (Fin K)} (hq : q ∈ UL.Simplex K) (y : Fin K) :
    UL.finiteCanonicalLoss Φ q y - UL.matchingPotential Φ 0 =
      hPhiFun Φ q - inner ℝ (EuclideanSpace.single y (1 : ℝ) - UL.uniformVec K)
        (UL.simplexGrad Φ q) := by
  rw [finiteCanonicalLoss_eq hΦ hq y]
  unfold hPhiFun
  have hsub : q - EuclideanSpace.single y (1 : ℝ) =
      (q - UL.uniformVec K) - (EuclideanSpace.single y (1 : ℝ) - UL.uniformVec K) := by abel
  rw [hsub, inner_sub_left]
  ring

private lemma matchingLoss_decomp {K : ℕ} (Φ : UL.Simplex K → ℝ)
    (a : UL.ZeroSumSubspace K) (y : Fin K) :
    UL.matchingLoss Φ (a : EuclideanSpace ℝ (Fin K)) y - UL.matchingPotential Φ 0 =
      (UL.matchingPotential Φ (a : EuclideanSpace ℝ (Fin K)) - UL.matchingPotential Φ 0) -
        inner ℝ (EuclideanSpace.single y (1 : ℝ) - UL.uniformVec K)
          (a : EuclideanSpace ℝ (Fin K)) := by
  unfold UL.matchingLoss
  have hu0 : inner ℝ (UL.uniformVec K) (a : EuclideanSpace ℝ (Fin K)) = 0 :=
    inner_uniformVec_zero_of_mem_zeroSum a.2
  have hy_eq : (a : EuclideanSpace ℝ (Fin K)) y =
      inner ℝ (EuclideanSpace.single y (1 : ℝ)) (a : EuclideanSpace ℝ (Fin K)) := by
    rw [real_inner_comm, UL.Proof_lem_A_1.inner_single_right]
  rw [inner_sub_left, hu0, hy_eq]
  ring

/-! ### Part 3: Pure-`ℝ` Perturbation Helpers & Exact Empirical Minimizer -/

private lemma quad_perturbation_nonneg {I_val M_sq : ℝ} (hM_nn : 0 ≤ M_sq)
    (h_pert : ∀ θ : ℝ, 0 < θ → θ ≤ 1 / 2 → 0 ≤ 2 * θ * I_val + θ ^ 2 * M_sq) :
    0 ≤ I_val := by
  by_contra hI_neg
  push_neg at hI_neg
  let θ : ℝ := min (1 / 2) ((-I_val) / (M_sq + 1))
  have hθ_pos : 0 < θ := lt_min (by norm_num) (div_pos (by linarith) (by positivity))
  have hθ_le : θ ≤ 1 / 2 := min_le_left _ _
  have hle := h_pert θ hθ_pos hθ_le
  have h1 : 0 ≤ 2 * I_val + θ * M_sq := by nlinarith
  have hθ_bound : θ ≤ (-I_val) / (M_sq + 1) := min_le_right _ _
  have hθM : θ * M_sq ≤ -I_val := by
    calc θ * M_sq ≤ ((-I_val) / (M_sq + 1)) * M_sq := mul_le_mul_of_nonneg_right hθ_bound hM_nn
      _ = (-I_val) * (M_sq / (M_sq + 1)) := by ring
      _ ≤ (-I_val) * 1 := mul_le_mul_of_nonneg_left
          ((div_le_one (by positivity)).mpr (by linarith)) (by linarith)
      _ = -I_val := mul_one _
  linarith

private lemma lin_perturbation_nonneg {S_val K_err δ_min : ℝ}
    (hδ : 0 < δ_min) (hK_nn : 0 ≤ K_err)
    (h_pert : ∀ t : ℝ, 0 < t → t < δ_min → 0 ≤ S_val + K_err * t) :
    0 ≤ S_val := by
  by_contra hS_neg
  push_neg at hS_neg
  let t : ℝ := min (δ_min / 2) ((-S_val) / (2 * (K_err + 1)))
  have ht_pos : 0 < t := lt_min (half_pos hδ) (div_pos (by linarith) (by positivity))
  have ht_lt : t < δ_min := lt_of_le_of_lt (min_le_left _ _) (half_lt_self hδ)
  have hle := h_pert t ht_pos ht_lt
  have ht_b : t ≤ (-S_val) / (2 * (K_err + 1)) := min_le_right _ _
  have htK : K_err * t ≤ -S_val / 2 := by
    have hmul : t * (K_err + 1) ≤ ((-S_val) / (2 * (K_err + 1))) * (K_err + 1) :=
      mul_le_mul_of_nonneg_right ht_b (by positivity)
    have hc : ((-S_val) / (2 * (K_err + 1))) * (K_err + 1) = -S_val / 2 := by
      field_simp [show K_err + 1 ≠ 0 by positivity]
    nlinarith
  linarith

private lemma hilbertSchmidtNorm_eq_sqrt_sum_single {d : ℕ} {Y : Type*}
    [NormedAddCommGroup Y] [InnerProductSpace ℝ Y] [FiniteDimensional ℝ Y]
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] Y) :
    UL.hilbertSchmidtNorm W =
      Real.sqrt (∑ j : Fin d, ‖W (EuclideanSpace.single j (1 : ℝ))‖ ^ 2) := by
  have hsq : UL.hilbertSchmidtNorm W ^ 2 =
      ∑ j : Fin d, ‖W (EuclideanSpace.single j (1 : ℝ))‖ ^ 2 := by
    have hsq0 := hilbertSchmidtNorm_sq W
    dsimp only at hsq0
    rw [hsq0]
    have h_lhs : ∀ r : Fin (Module.finrank ℝ Y),
        ‖adjVec W (stdOrthonormalBasis ℝ Y r)‖ ^ 2 =
          ∑ j : Fin d,
            (inner ℝ (W (EuclideanSpace.single j (1 : ℝ))) (stdOrthonormalBasis ℝ Y r)) ^ 2 := by
      intro r
      rw [norm_sq_eq_sum]
      refine Finset.sum_congr rfl fun j _ => ?_
      have hj : adjVec W (stdOrthonormalBasis ℝ Y r) j =
          inner ℝ (EuclideanSpace.single j (1 : ℝ)) (adjVec W (stdOrthonormalBasis ℝ Y r)) := by
        rw [real_inner_comm, UL.Proof_lem_A_1.inner_single_right]
      rw [hj, inner_adjVec_right]
    simp_rw [h_lhs]
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun j _ => ?_
    rw [← real_inner_self_eq_norm_sq,
      ← (stdOrthonormalBasis ℝ Y).sum_inner_mul_inner (W (EuclideanSpace.single j (1 : ℝ)))]
    refine Finset.sum_congr rfl fun r _ => ?_
    rw [real_inner_comm (stdOrthonormalBasis ℝ Y r), sq]
  rw [← hsq, Real.sqrt_sq (hilbertSchmidtNorm_nonneg W)]

private lemma hilbertSchmidtNorm_smul_nonneg {d : ℕ} {Y : Type*}
    [NormedAddCommGroup Y] [InnerProductSpace ℝ Y] [FiniteDimensional ℝ Y]
    {c : ℝ} (hc : 0 ≤ c) (W : EuclideanSpace ℝ (Fin d) →L[ℝ] Y) :
    UL.hilbertSchmidtNorm (c • W) = c * UL.hilbertSchmidtNorm W := by
  rw [hilbertSchmidtNorm_eq_sqrt_sum_single, hilbertSchmidtNorm_eq_sqrt_sum_single]
  have hsum : (∑ j : Fin d, ‖(c • W) (EuclideanSpace.single j (1 : ℝ))‖ ^ 2) =
      c ^ 2 * ∑ j : Fin d, ‖W (EuclideanSpace.single j (1 : ℝ))‖ ^ 2 := by
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun j _ => ?_
    rw [ContinuousLinearMap.smul_apply, norm_smul, Real.norm_of_nonneg hc, mul_pow]
  rw [hsum, Real.sqrt_mul (sq_nonneg c), Real.sqrt_sq hc]

private lemma hilbertSchmidtNorm_convex_comb {d : ℕ} {Y : Type*}
    [NormedAddCommGroup Y] [InnerProductSpace ℝ Y] [FiniteDimensional ℝ Y]
    {W₁ W₂ : EuclideanSpace ℝ (Fin d) →L[ℝ] Y} {R a b : ℝ}
    (hW₁ : UL.hilbertSchmidtNorm W₁ ≤ R) (hW₂ : UL.hilbertSchmidtNorm W₂ ≤ R)
    (ha : 0 ≤ a) (hb : 0 ≤ b) (hab : a + b = 1) :
    UL.hilbertSchmidtNorm (a • W₁ + b • W₂) ≤ R := by
  have hR_nn : 0 ≤ R := le_trans (hilbertSchmidtNorm_nonneg W₁) hW₁
  rw [hilbertSchmidtNorm_eq_sqrt_sum_single]
  have hsq₁ : ∑ j : Fin d, ‖W₁ (EuclideanSpace.single j (1 : ℝ))‖ ^ 2 ≤ R ^ 2 := by
    have h1 := pow_le_pow_left₀ (hilbertSchmidtNorm_nonneg W₁) hW₁ 2
    rwa [hilbertSchmidtNorm_eq_sqrt_sum_single,
      Real.sq_sqrt (Finset.sum_nonneg fun _ _ => sq_nonneg _)] at h1
  have hsq₂ : ∑ j : Fin d, ‖W₂ (EuclideanSpace.single j (1 : ℝ))‖ ^ 2 ≤ R ^ 2 := by
    have h2 := pow_le_pow_left₀ (hilbertSchmidtNorm_nonneg W₂) hW₂ 2
    rwa [hilbertSchmidtNorm_eq_sqrt_sum_single,
      Real.sq_sqrt (Finset.sum_nonneg fun _ _ => sq_nonneg _)] at h2
  have h_pt : ∀ j : Fin d,
      ‖(a • W₁ + b • W₂) (EuclideanSpace.single j (1 : ℝ))‖ ^ 2 ≤
        a * ‖W₁ (EuclideanSpace.single j (1 : ℝ))‖ ^ 2 +
          b * ‖W₂ (EuclideanSpace.single j (1 : ℝ))‖ ^ 2 := by
    intro j
    set u₁ := W₁ (EuclideanSpace.single j (1 : ℝ))
    set u₂ := W₂ (EuclideanSpace.single j (1 : ℝ))
    have htri : ‖a • u₁ + b • u₂‖ ≤ a * ‖u₁‖ + b * ‖u₂‖ := by
      calc ‖a • u₁ + b • u₂‖ ≤ ‖a • u₁‖ + ‖b • u₂‖ := norm_add_le _ _
        _ = a * ‖u₁‖ + b * ‖u₂‖ := by
            rw [norm_smul, norm_smul, Real.norm_of_nonneg ha, Real.norm_of_nonneg hb]
    have hsq_tri := pow_le_pow_left₀ (norm_nonneg _) htri 2
    have h_diff : a * ‖u₁‖ ^ 2 + b * ‖u₂‖ ^ 2 - (a * ‖u₁‖ + b * ‖u₂‖) ^ 2 =
        a * b * (‖u₁‖ - ‖u₂‖) ^ 2 := by
      have hb_eq : b = 1 - a := by linarith
      rw [hb_eq]; ring
    have hnn : 0 ≤ a * b * (‖u₁‖ - ‖u₂‖) ^ 2 := by positivity
    change ‖a • u₁ + b • u₂‖ ^ 2 ≤ _
    linarith
  have hsum_le : ∑ j : Fin d, ‖(a • W₁ + b • W₂) (EuclideanSpace.single j (1 : ℝ))‖ ^ 2 ≤ R ^ 2 := by
    calc ∑ j : Fin d, ‖(a • W₁ + b • W₂) (EuclideanSpace.single j (1 : ℝ))‖ ^ 2
        ≤ ∑ j : Fin d, (a * ‖W₁ (EuclideanSpace.single j (1 : ℝ))‖ ^ 2 +
            b * ‖W₂ (EuclideanSpace.single j (1 : ℝ))‖ ^ 2) :=
          Finset.sum_le_sum fun j _ => h_pt j
      _ = a * (∑ j : Fin d, ‖W₁ (EuclideanSpace.single j (1 : ℝ))‖ ^ 2) +
            b * (∑ j : Fin d, ‖W₂ (EuclideanSpace.single j (1 : ℝ))‖ ^ 2) := by
          rw [Finset.sum_add_distrib, ← Finset.mul_sum, ← Finset.mul_sum]
      _ ≤ a * R ^ 2 + b * R ^ 2 :=
          add_le_add (mul_le_mul_of_nonneg_left hsq₁ ha) (mul_le_mul_of_nonneg_left hsq₂ hb)
      _ = R ^ 2 := by rw [← add_mul, hab, one_mul]
  exact le_trans (Real.sqrt_le_sqrt hsum_le) (Real.sqrt_sq hR_nn).le

private noncomputable def opOfCoord {d : ℕ} {Y : Type*}
    [NormedAddCommGroup Y] [InnerProductSpace ℝ Y] [FiniteDimensional ℝ Y]
    (w : EuclideanSpace ℝ (Fin (d * Module.finrank ℝ Y))) :
    EuclideanSpace ℝ (Fin d) →L[ℝ] Y :=
  ∑ j : Fin d, ∑ r : Fin (Module.finrank ℝ Y),
    w (finProdFinEquiv (j, r)) •
      (innerSL ℝ (EuclideanSpace.single j (1 : ℝ))).smulRight (stdOrthonormalBasis ℝ Y r)

private noncomputable def coordOfOp {d : ℕ} {Y : Type*}
    [NormedAddCommGroup Y] [InnerProductSpace ℝ Y] [FiniteDimensional ℝ Y]
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] Y) :
    EuclideanSpace ℝ (Fin (d * Module.finrank ℝ Y)) :=
  (WithLp.equiv 2 _).symm fun idx =>
    inner ℝ (stdOrthonormalBasis ℝ Y (finProdFinEquiv.symm idx).2)
      (W (EuclideanSpace.single (finProdFinEquiv.symm idx).1 (1 : ℝ)))

private lemma opOfCoord_single {d : ℕ} {Y : Type*}
    [NormedAddCommGroup Y] [InnerProductSpace ℝ Y] [FiniteDimensional ℝ Y]
    (w : EuclideanSpace ℝ (Fin (d * Module.finrank ℝ Y))) (j₀ : Fin d) :
    opOfCoord w (EuclideanSpace.single j₀ (1 : ℝ)) =
      ∑ r : Fin (Module.finrank ℝ Y),
        w (finProdFinEquiv (j₀, r)) • stdOrthonormalBasis ℝ Y r := by
  unfold opOfCoord
  simp only [ContinuousLinearMap.sum_apply, ContinuousLinearMap.smul_apply,
    ContinuousLinearMap.smulRight_apply, innerSL_apply_apply]
  rw [Finset.sum_eq_single j₀]
  · refine Finset.sum_congr rfl fun r _ => ?_
    have h1 : inner ℝ (EuclideanSpace.single j₀ (1 : ℝ)) (EuclideanSpace.single j₀ (1 : ℝ)) = 1 := by
      rw [UL.Proof_lem_A_1.inner_single_right, EuclideanSpace.single_apply, if_pos rfl]
    rw [h1, one_smul]
  · intro j _ hj
    refine Finset.sum_eq_zero fun r _ => ?_
    have h0 : inner ℝ (EuclideanSpace.single j (1 : ℝ)) (EuclideanSpace.single j₀ (1 : ℝ)) = 0 := by
      rw [UL.Proof_lem_A_1.inner_single_right, EuclideanSpace.single_apply, if_neg (Ne.symm hj)]
    rw [h0, zero_smul, smul_zero]
  · intro h; exact (h (Finset.mem_univ j₀)).elim

private lemma hilbertSchmidtNorm_opOfCoord {d : ℕ} {Y : Type*}
    [NormedAddCommGroup Y] [InnerProductSpace ℝ Y] [FiniteDimensional ℝ Y]
    (w : EuclideanSpace ℝ (Fin (d * Module.finrank ℝ Y))) :
    UL.hilbertSchmidtNorm (opOfCoord (Y := Y) w) = ‖w‖ := by
  rw [hilbertSchmidtNorm_eq_sqrt_sum_single]
  have h_ite := orthonormal_iff_ite.mp (stdOrthonormalBasis ℝ Y).orthonormal
  have hsum : (∑ j : Fin d, ‖opOfCoord (Y := Y) w (EuclideanSpace.single j (1 : ℝ))‖ ^ 2) =
      ‖w‖ ^ 2 := by
    simp_rw [opOfCoord_single]
    have h_j : ∀ j : Fin d,
        ‖∑ r : Fin (Module.finrank ℝ Y),
            w (finProdFinEquiv (j, r)) • stdOrthonormalBasis ℝ Y r‖ ^ 2 =
          ∑ r : Fin (Module.finrank ℝ Y), ‖w (finProdFinEquiv (j, r))‖ ^ 2 := by
      intro j
      rw [← real_inner_self_eq_norm_sq, sum_inner]
      refine Finset.sum_congr rfl fun r₁ _ => ?_
      rw [inner_smul_left, inner_sum, conj_trivial]
      have h_single : ∑ r₂ : Fin (Module.finrank ℝ Y),
          inner ℝ (stdOrthonormalBasis ℝ Y r₁)
            (w (finProdFinEquiv (j, r₂)) • stdOrthonormalBasis ℝ Y r₂) =
          w (finProdFinEquiv (j, r₁)) := by
        calc ∑ r₂ : Fin (Module.finrank ℝ Y), _
            = ∑ r₂ : Fin (Module.finrank ℝ Y),
                (if r₂ = r₁ then w (finProdFinEquiv (j, r₁)) else 0) := by
                refine Finset.sum_congr rfl fun r₂ _ => ?_
                rw [inner_smul_right, h_ite r₁ r₂]
                by_cases hrr : r₂ = r₁
                · subst hrr; simp
                · have hne : r₁ ≠ r₂ := fun h => hrr h.symm
                  simp [hrr, hne]
          _ = w (finProdFinEquiv (j, r₁)) := by simp
      rw [h_single, Real.norm_eq_abs, sq_abs, sq]
    simp_rw [h_j]
    rw [EuclideanSpace.norm_sq_eq, ← Fintype.sum_prod_type' (fun j r => ‖w (finProdFinEquiv (j, r))‖ ^ 2)]
    exact finProdFinEquiv.sum_comp (fun idx => ‖w idx‖ ^ 2)
  rw [hsum, Real.sqrt_sq (norm_nonneg w)]

private lemma opOfCoord_coordOfOp {d : ℕ} {Y : Type*}
    [NormedAddCommGroup Y] [InnerProductSpace ℝ Y] [FiniteDimensional ℝ Y]
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] Y) :
    opOfCoord (coordOfOp W) = W := by
  ext x
  have hx : x = ∑ j : Fin d, x j • EuclideanSpace.single j (1 : ℝ) := by
    ext i
    rw [sum_apply]
    simp [EuclideanSpace.single_apply]
  rw [hx, map_sum, map_sum]
  refine Finset.sum_congr rfl fun j _ => ?_
  rw [map_smul, map_smul, opOfCoord_single]
  congr 1
  unfold coordOfOp
  simp only [WithLp.equiv_symm_apply, finProdFinEquiv.symm_apply_apply]
  exact (stdOrthonormalBasis ℝ Y).sum_repr' (W (EuclideanSpace.single j (1 : ℝ)))

private lemma norm_coordOfOp {d : ℕ} {Y : Type*}
    [NormedAddCommGroup Y] [InnerProductSpace ℝ Y] [FiniteDimensional ℝ Y]
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] Y) :
    ‖coordOfOp W‖ = UL.hilbertSchmidtNorm W := by
  rw [← hilbertSchmidtNorm_opOfCoord (coordOfOp W), opOfCoord_coordOfOp]

private lemma continuous_opOfCoord_apply {d : ℕ} {Y : Type*}
    [NormedAddCommGroup Y] [InnerProductSpace ℝ Y] [FiniteDimensional ℝ Y]
    (x : EuclideanSpace ℝ (Fin d)) :
    Continuous (fun w : EuclideanSpace ℝ (Fin (d * Module.finrank ℝ Y)) => opOfCoord w x) := by
  unfold opOfCoord
  simp only [ContinuousLinearMap.sum_apply, ContinuousLinearMap.smul_apply,
    ContinuousLinearMap.smulRight_apply, innerSL_apply_apply]
  refine continuous_finset_sum _ fun j _ => continuous_finset_sum _ fun r _ => ?_
  exact (PiLp.continuous_apply 2 _ (finProdFinEquiv (j, r))).smul continuous_const

/-- Eliminating the free intercept centers the features and the labels. -/
lemma centeredInterceptOptimal {n d K : ℕ} (hn : 1 ≤ n) (β : ℝ)
    (x_samp : Fin n → EuclideanSpace ℝ (Fin d)) (Z : Fin n → UL.ZeroSumSubspace K) :
    let x_bar := (1 / (n : ℝ)) • ∑ i, x_samp i
    let Z_bar := (1 / (n : ℝ)) • ∑ i, Z i
    let a_of := fun W : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K =>
      Z_bar - β • W x_bar
    (∀ W, ∑ i : Fin n, ((a_of W + β • W (x_samp i) - Z i : UL.ZeroSumSubspace K) :
      EuclideanSpace ℝ (Fin K)) = 0) ∧
    (∀ a W, ∑ i : Fin n, ‖a_of W + β • W (x_samp i) - Z i‖ ^ 2 ≤
      ∑ i : Fin n, ‖a + β • W (x_samp i) - Z i‖ ^ 2) := by
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  let x_bar : EuclideanSpace ℝ (Fin d) := (1 / (n : ℝ)) • ∑ i : Fin n, x_samp i
  let Z_bar : UL.ZeroSumSubspace K := (1 / (n : ℝ)) • ∑ i : Fin n, Z i
  let a_of : (EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K) → UL.ZeroSumSubspace K :=
    fun W => Z_bar - β • W x_bar
  have h_sum_zero : ∀ W : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K,
      ∑ i : Fin n,
        ((a_of W + β • W (x_samp i) - Z i : UL.ZeroSumSubspace K) :
          EuclideanSpace ℝ (Fin K)) = 0 := by
    intro W
    ext k
    rw [sum_apply]
    simp only [PiLp.zero_apply, Submodule.coe_sub, Submodule.coe_add,
      Submodule.coe_smul_of_tower, PiLp.sub_apply, PiLp.add_apply, PiLp.smul_apply, smul_eq_mul]
    have h_aof_k : (a_of W : EuclideanSpace ℝ (Fin K)) k =
        (1 / (n : ℝ)) * (∑ i : Fin n, (Z i : EuclideanSpace ℝ (Fin K)) k) -
          β * ((1 / (n : ℝ)) * ∑ i : Fin n, (W (x_samp i) : EuclideanSpace ℝ (Fin K)) k) := by
      dsimp [a_of, Z_bar, x_bar]
      have hZ_sum : ((∑ i : Fin n, Z i : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) k =
          ∑ i : Fin n, (Z i : EuclideanSpace ℝ (Fin K)) k := by
        rw [Submodule.coe_sum, sum_apply]
      have hW_sum : (W (∑ i : Fin n, x_samp i) : EuclideanSpace ℝ (Fin K)) k =
          ∑ i : Fin n, (W (x_samp i) : EuclideanSpace ℝ (Fin K)) k := by
        rw [map_sum, Submodule.coe_sum, sum_apply]
      simp only [Submodule.coe_smul_of_tower, map_smul, PiLp.smul_apply, smul_eq_mul, hZ_sum,
        hW_sum]
    simp_rw [h_aof_k]
    rw [Finset.sum_sub_distrib, Finset.sum_add_distrib, Finset.sum_const, Finset.card_univ,
      Fintype.card_fin, nsmul_eq_mul, ← Finset.mul_sum]
    field_simp [hn_pos.ne']
    ring
  have h_min_a : ∀ (a : UL.ZeroSumSubspace K)
      (W : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K),
      ∑ i : Fin n, ‖a_of W + β • W (x_samp i) - Z i‖ ^ 2 ≤
        ∑ i : Fin n, ‖a + β • W (x_samp i) - Z i‖ ^ 2 := by
    intro a W
    let ξ : Fin n → EuclideanSpace ℝ (Fin K) :=
      fun i => ((a_of W + β • W (x_samp i) - Z i : UL.ZeroSumSubspace K) :
        EuclideanSpace ℝ (Fin K))
    let da : EuclideanSpace ℝ (Fin K) :=
      ((a - a_of W : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
    have hr0 : ∑ i : Fin n, ξ i = 0 := h_sum_zero W
    have h_exp : ∀ i : Fin n, ‖a + β • W (x_samp i) - Z i‖ ^ 2 =
        ‖ξ i‖ ^ 2 + 2 * inner ℝ da (ξ i) + ‖da‖ ^ 2 := by
      intro i
      have hn1 : ‖a + β • W (x_samp i) - Z i‖ = ‖da + ξ i‖ := by
        change ‖((a + β • W (x_samp i) - Z i : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))‖ = _
        congr 1
        simp only [da, ξ, Submodule.coe_add, Submodule.coe_sub]
        abel
      rw [hn1, norm_add_sq_real]
      ring
    have hr_norm : ∀ i : Fin n, ‖a_of W + β • W (x_samp i) - Z i‖ ^ 2 = ‖ξ i‖ ^ 2 :=
      fun _ => rfl
    simp_rw [h_exp, hr_norm, Finset.sum_add_distrib, ← Finset.mul_sum, ← inner_sum, hr0,
      inner_zero_right, mul_zero, add_zero]
    have hnn : 0 ≤ ∑ _i : Fin n, ‖da‖ ^ 2 := Finset.sum_nonneg fun _ _ => sq_nonneg _
    linarith
  exact ⟨h_sum_zero, h_min_a⟩

lemma exists_exact_emp_minimizer {n d K : ℕ} (hn : 1 ≤ n)
    {R β : ℝ} (hR : 0 < R)
    (x_samp : Fin n → EuclideanSpace ℝ (Fin d))
    (Z : Fin n → UL.ZeroSumSubspace K) :
    ∃ (a_star : UL.ZeroSumSubspace K)
      (W_star : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K),
      UL.hilbertSchmidtNorm W_star ≤ R ∧
      (∑ i : Fin n,
        ((a_star + β • W_star (x_samp i) - Z i : UL.ZeroSumSubspace K) :
          EuclideanSpace ℝ (Fin K)) = 0) ∧
      (∀ (a : UL.ZeroSumSubspace K)
         (W : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K),
         UL.hilbertSchmidtNorm W ≤ R →
         ∑ i : Fin n, ‖a_star + β • W_star (x_samp i) - Z i‖ ^ 2 ≤
           ∑ i : Fin n, ‖a + β • W (x_samp i) - Z i‖ ^ 2) := by
  let x_bar : EuclideanSpace ℝ (Fin d) := (1 / (n : ℝ)) • ∑ i : Fin n, x_samp i
  let Z_bar : UL.ZeroSumSubspace K := (1 / (n : ℝ)) • ∑ i : Fin n, Z i
  let a_of : (EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K) → UL.ZeroSumSubspace K :=
    fun W => Z_bar - β • W x_bar
  obtain ⟨h_sum_zero,h_min_a⟩ := centeredInterceptOptimal hn β x_samp Z
  let M_dim := d * Module.finrank ℝ (UL.ZeroSumSubspace K)
  let B_vec : Set (EuclideanSpace ℝ (Fin M_dim)) := Metric.closedBall 0 R
  have hB_comp : IsCompact B_vec := isCompact_closedBall 0 R
  have hB_ne : B_vec.Nonempty := ⟨0, by simp [B_vec, hR.le]⟩
  let obj_vec : EuclideanSpace ℝ (Fin M_dim) → ℝ := fun w =>
    ∑ i : Fin n,
      ‖((a_of (opOfCoord w) + β • opOfCoord w (x_samp i) - Z i : UL.ZeroSumSubspace K) :
        EuclideanSpace ℝ (Fin K))‖ ^ 2
  have h_obj_cont : Continuous obj_vec := by
    refine continuous_finset_sum _ fun i _ => ?_
    have hc_bar : Continuous (fun w : EuclideanSpace ℝ (Fin M_dim) =>
        (a_of (opOfCoord w) : EuclideanSpace ℝ (Fin K))) := by
      dsimp [a_of]
      exact continuous_const.sub (continuous_const.smul
        (continuous_subtype_val.comp (continuous_opOfCoord_apply x_bar)))
    have hc_i : Continuous (fun w : EuclideanSpace ℝ (Fin M_dim) =>
        (opOfCoord (Y := UL.ZeroSumSubspace K) w (x_samp i) : EuclideanSpace ℝ (Fin K))) :=
      continuous_subtype_val.comp (continuous_opOfCoord_apply (x_samp i))
    have hc_vec : Continuous (fun w : EuclideanSpace ℝ (Fin M_dim) =>
        ((a_of (opOfCoord w) + β • opOfCoord w (x_samp i) - Z i : UL.ZeroSumSubspace K) :
          EuclideanSpace ℝ (Fin K))) := by
      simpa only [Submodule.coe_sub, Submodule.coe_add, Submodule.coe_smul_of_tower] using
        (hc_bar.add (continuous_const.smul hc_i)).sub continuous_const
    exact (hc_vec.norm).pow 2
  obtain ⟨w_star, hw_mem, hw_min⟩ := hB_comp.exists_isMinOn hB_ne h_obj_cont.continuousOn
  let W_star := opOfCoord (Y := UL.ZeroSumSubspace K) w_star
  have hW_star : UL.hilbertSchmidtNorm W_star ≤ R := by
    rw [hilbertSchmidtNorm_opOfCoord]
    simpa [B_vec, Metric.mem_closedBall, dist_zero_right] using hw_mem
  refine ⟨a_of W_star, W_star, hW_star, h_sum_zero W_star, fun a W hW => ?_⟩
  have hw_W_mem : coordOfOp W ∈ B_vec := by
    rw [Metric.mem_closedBall, dist_zero_right, norm_coordOfOp]
    exact hW
  have h_le_vec : obj_vec w_star ≤ obj_vec (coordOfOp W) := hw_min hw_W_mem
  have h_eq_W : obj_vec (coordOfOp W) = ∑ i : Fin n, ‖a_of W + β • W (x_samp i) - Z i‖ ^ 2 := by
    dsimp [obj_vec]
    rw [opOfCoord_coordOfOp]
  exact le_trans h_le_vec (by rw [h_eq_W]; exact h_min_a a W)

/-! ### Part 4: Empirical Approximate Omniprediction -/

private lemma emp_minimizer_vi_W {n d K : ℕ} {R β : ℝ} (hβ : 0 < β)
    (x_samp : Fin n → EuclideanSpace ℝ (Fin d))
    (Z : Fin n → UL.ZeroSumSubspace K)
    {a_star : UL.ZeroSumSubspace K}
    {W_star : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K}
    (hW_star : UL.hilbertSchmidtNorm W_star ≤ R)
    (h_min_emp : ∀ (a : UL.ZeroSumSubspace K)
       (W : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K),
       UL.hilbertSchmidtNorm W ≤ R →
       ∑ i : Fin n, ‖a_star + β • W_star (x_samp i) - Z i‖ ^ 2 ≤
         ∑ i : Fin n, ‖a + β • W (x_samp i) - Z i‖ ^ 2)
    {V' : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K}
    (hV' : UL.hilbertSchmidtNorm V' ≤ R) :
    let ξ : Fin n → EuclideanSpace ℝ (Fin K) :=
      fun i => ((a_star + β • W_star (x_samp i) - Z i : UL.ZeroSumSubspace K) :
        EuclideanSpace ℝ (Fin K))
    ∑ i : Fin n, inner ℝ (ξ i) (W_star (x_samp i) : EuclideanSpace ℝ (Fin K)) ≤
      ∑ i : Fin n, inner ℝ (ξ i) (V' (x_samp i) : EuclideanSpace ℝ (Fin K)) := by
  intro ξ
  let pTildeStar : Fin n → UL.ZeroSumSubspace K := fun i => a_star + β • W_star (x_samp i)
  have h_diff_nn : 0 ≤ β * ∑ i : Fin n,
      inner ℝ (ξ i) (((V' - W_star) (x_samp i) : UL.ZeroSumSubspace K) :
        EuclideanSpace ℝ (Fin K)) := by
    refine quad_perturbation_nonneg
      (M_sq := ∑ i : Fin n,
        ‖β • (((V' - W_star) (x_samp i) : UL.ZeroSumSubspace K) :
          EuclideanSpace ℝ (Fin K))‖ ^ 2)
      (Finset.sum_nonneg fun _ _ => sq_nonneg _) (fun θ hθ0 hθ_half => ?_)
    let W_θ := (1 - θ) • W_star + θ • V'
    have hW_θ : UL.hilbertSchmidtNorm W_θ ≤ R :=
      hilbertSchmidtNorm_convex_comb hW_star hV' (by linarith) hθ0.le (by ring)
    have hle : ∑ i : Fin n, ‖pTildeStar i - Z i‖ ^ 2 ≤
        ∑ i : Fin n, ‖a_star + β • W_θ (x_samp i) - Z i‖ ^ 2 := h_min_emp a_star W_θ hW_θ
    have h_exp : ∑ i : Fin n, ‖a_star + β • W_θ (x_samp i) - Z i‖ ^ 2 =
        (∑ i : Fin n, ‖pTildeStar i - Z i‖ ^ 2) +
          2 * θ * (β * ∑ i : Fin n,
            inner ℝ (ξ i) (((V' - W_star) (x_samp i) : UL.ZeroSumSubspace K) :
              EuclideanSpace ℝ (Fin K))) +
          θ ^ 2 * ∑ i : Fin n,
            ‖β • (((V' - W_star) (x_samp i) : UL.ZeroSumSubspace K) :
              EuclideanSpace ℝ (Fin K))‖ ^ 2 := by
      have hpt : ∀ i : Fin n, ‖a_star + β • W_θ (x_samp i) - Z i‖ ^ 2 =
          ‖pTildeStar i - Z i‖ ^ 2 +
            2 * θ * (β * inner ℝ (ξ i)
              (((V' - W_star) (x_samp i) : UL.ZeroSumSubspace K) :
                EuclideanSpace ℝ (Fin K))) +
            θ ^ 2 * ‖β • (((V' - W_star) (x_samp i) : UL.ZeroSumSubspace K) :
              EuclideanSpace ℝ (Fin K))‖ ^ 2 := by
        intro i
        have hn_eq : ‖a_star + β • W_θ (x_samp i) - Z i‖ =
            ‖ξ i + θ • (β • (((V' - W_star) (x_samp i) : UL.ZeroSumSubspace K) :
              EuclideanSpace ℝ (Fin K)))‖ := by
          change ‖((a_star + β • W_θ (x_samp i) - Z i : UL.ZeroSumSubspace K) :
            EuclideanSpace ℝ (Fin K))‖ = _
          congr 1
          ext k
          simp only [W_θ, ξ, Submodule.coe_add, Submodule.coe_sub,
            Submodule.coe_smul_of_tower, ContinuousLinearMap.add_apply,
            ContinuousLinearMap.sub_apply, ContinuousLinearMap.smul_apply,
            PiLp.add_apply, PiLp.sub_apply, PiLp.smul_apply, smul_eq_mul]
          ring
        have hn_base : ‖pTildeStar i - Z i‖ = ‖ξ i‖ := rfl
        rw [hn_eq, hn_base, norm_add_smul_sq, inner_smul_right]
      simp_rw [hpt, Finset.sum_add_distrib, ← Finset.mul_sum]
    linarith only [hle, h_exp]
  have h_inner_nn : 0 ≤ ∑ i : Fin n,
      inner ℝ (ξ i) (((V' - W_star) (x_samp i) : UL.ZeroSumSubspace K) :
        EuclideanSpace ℝ (Fin K)) := by nlinarith only [hβ, h_diff_nn]
  have h_split : ∑ i : Fin n,
      inner ℝ (ξ i) (((V' - W_star) (x_samp i) : UL.ZeroSumSubspace K) :
        EuclideanSpace ℝ (Fin K)) =
      (∑ i : Fin n, inner ℝ (ξ i) (V' (x_samp i) : EuclideanSpace ℝ (Fin K))) -
        ∑ i : Fin n, inner ℝ (ξ i) (W_star (x_samp i) : EuclideanSpace ℝ (Fin K)) := by
    rw [← Finset.sum_sub_distrib]
    refine Finset.sum_congr rfl fun i _ => ?_
    change inner ℝ (ξ i)
      ((V' (x_samp i) : EuclideanSpace ℝ (Fin K)) -
        (W_star (x_samp i) : EuclideanSpace ℝ (Fin K))) = _
    rw [inner_sub_right]
  linarith only [h_inner_nn, h_split]

private lemma pyth_of_inner_le_zero {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    (u₁ u₂ : E) (hvi : inner ℝ u₁ u₂ ≤ 0) :
    ‖u₂‖ ^ 2 + ‖u₁‖ ^ 2 ≤ ‖u₁ - u₂‖ ^ 2 := by
  rw [norm_sub_sq_real]
  linarith

private lemma projCDef_pyth {K : ℕ} (hK : 2 ≤ K) (v : UL.ZeroSumSubspace K)
    {z : UL.ZeroSumSubspace K} (hz : z ∈ cSetDef K) :
    ‖projCDef K v - z‖ ^ 2 + ‖v - projCDef K v‖ ^ 2 ≤ ‖v - z‖ ^ 2 := by
  have h := pyth_of_inner_le_zero (v - projCDef K v) (z - projCDef K v)
    (projCDef_inner_le_zero hK v hz)
  rwa [norm_sub_rev z (projCDef K v), sub_sub_sub_cancel_right] at h

private lemma emp_minimizer_mem_cSetDef
    (h_contr_zeroSum : ∀ {N d K : ℕ} {x_dict : Fin N → EuclideanSpace ℝ (Fin d)},
      UL.DirichletFeatureCondition x_dict →
      ∀ (b₀ : UL.ZeroSumSubspace K)
        (A₀ : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K)
        {Q C : ℝ}, 0 ≤ Q → 0 ≤ C → UL.hilbertSchmidtNorm A₀ ≤ Q →
        ∀ (t : Fin N → UL.ZeroSumSubspace K),
        (∀ i j : Fin N, ‖t i - t j‖ ≤ C * ‖(b₀ + A₀ (x_dict i)) - (b₀ + A₀ (x_dict j))‖) →
        ∃ (b : UL.ZeroSumSubspace K)
          (A : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K),
          UL.hilbertSchmidtNorm A ≤ C * Q ∧ ∀ i : Fin N, t i = b + A (x_dict i))
    {n d K N : ℕ} (hK : 2 ≤ K) {R β : ℝ} (hR : 0 < R) (hβ : 0 < β)
    {x_dict : Fin N → EuclideanSpace ℝ (Fin d)}
    (h_dir : UL.DirichletFeatureCondition x_dict)
    (x_samp : Fin n → EuclideanSpace ℝ (Fin d))
    (hx_mem_dict : ∀ i : Fin n, x_samp i ∈ Set.range x_dict)
    {Z : Fin n → UL.ZeroSumSubspace K} (hZ_mem_C : ∀ i : Fin n, Z i ∈ cSetDef K)
    {a_star : UL.ZeroSumSubspace K}
    {W_star : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K}
    (hW_star : UL.hilbertSchmidtNorm W_star ≤ R)
    (h_min_emp : ∀ (a : UL.ZeroSumSubspace K)
       (W : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K),
       UL.hilbertSchmidtNorm W ≤ R →
       ∑ i : Fin n, ‖a_star + β • W_star (x_samp i) - Z i‖ ^ 2 ≤
         ∑ i : Fin n, ‖a + β • W (x_samp i) - Z i‖ ^ 2) :
    ∀ i : Fin n, a_star + β • W_star (x_samp i) ∈ cSetDef K := by
  let pTildeStar : Fin n → UL.ZeroSumSubspace K := fun i => a_star + β • W_star (x_samp i)
  obtain ⟨b₁, W₁, hW₁_raw, h_interp₁⟩ :=
    h_contr_zeroSum h_dir 0 W_star hR.le zero_le_one hW_star
      (fun j => (1 / β) • projCDef K (a_star + β • W_star (x_dict j)))
      (fun j₁ j₂ => by
        rw [one_mul, zero_add, zero_add, ← smul_sub, norm_smul,
          Real.norm_of_nonneg (one_div_pos.mpr hβ).le]
        have h1 := projCDef_nonexpansive hK (a_star + β • W_star (x_dict j₁))
          (a_star + β • W_star (x_dict j₂))
        have h2 : ‖(a_star + β • W_star (x_dict j₁)) - (a_star + β • W_star (x_dict j₂))‖ =
            β * ‖W_star (x_dict j₁) - W_star (x_dict j₂)‖ := by
          have hsub : (a_star + β • W_star (x_dict j₁)) - (a_star + β • W_star (x_dict j₂)) =
              β • (W_star (x_dict j₁) - W_star (x_dict j₂)) := by rw [smul_sub]; abel
          rw [hsub, norm_smul, Real.norm_of_nonneg hβ.le]
        rw [h2] at h1
        have hmul := mul_le_mul_of_nonneg_left h1 (one_div_pos.mpr hβ).le
        have hc : (1 / β) * (β * ‖W_star (x_dict j₁) - W_star (x_dict j₂)‖) =
            ‖W_star (x_dict j₁) - W_star (x_dict j₂)‖ := by field_simp [hβ.ne']
        rwa [hc] at hmul)
  have hW₁ : UL.hilbertSchmidtNorm W₁ ≤ R := by simpa only [one_mul] using hW₁_raw
  have h_on_samp : ∀ i : Fin n, (β • b₁) + β • W₁ (x_samp i) = projCDef K (pTildeStar i) := by
    intro i
    rcases hx_mem_dict i with ⟨j, hj⟩
    have hj_eq := congrArg (fun v : UL.ZeroSumSubspace K => β • v) (h_interp₁ j)
    dsimp only at hj_eq
    rw [hj, smul_smul, mul_one_div_cancel hβ.ne', one_smul, smul_add] at hj_eq
    exact hj_eq.symm
  have hmin₁ : ∑ i : Fin n, ‖pTildeStar i - Z i‖ ^ 2 ≤
      ∑ i : Fin n, ‖(β • b₁) + β • W₁ (x_samp i) - Z i‖ ^ 2 := h_min_emp (β • b₁) W₁ hW₁
  simp_rw [h_on_samp] at hmin₁
  have h_pyth : ∀ i : Fin n,
      ‖projCDef K (pTildeStar i) - Z i‖ ^ 2 + ‖pTildeStar i - projCDef K (pTildeStar i)‖ ^ 2 ≤
        ‖pTildeStar i - Z i‖ ^ 2 :=
    fun i => projCDef_pyth hK (pTildeStar i) (hZ_mem_C i)
  have hsum_pyth := Finset.sum_le_sum (s := Finset.univ) fun i _ => h_pyth i
  rw [Finset.sum_add_distrib] at hsum_pyth
  have hsq_le0 : ∑ i : Fin n, ‖pTildeStar i - projCDef K (pTildeStar i)‖ ^ 2 ≤ 0 := by
    linarith only [hmin₁, hsum_pyth]
  have hsq_eq0 : ∑ i : Fin n, ‖pTildeStar i - projCDef K (pTildeStar i)‖ ^ 2 = 0 :=
    le_antisymm hsq_le0 (Finset.sum_nonneg fun _ _ => sq_nonneg _)
  have hall0 := (Finset.sum_eq_zero_iff_of_nonneg (fun i _ => sq_nonneg _)).mp hsq_eq0
  intro i
  have hi0 : pTildeStar i = projCDef K (pTildeStar i) :=
    sub_eq_zero.mp (norm_eq_zero.mp (sq_eq_zero_iff.mp (hall0 i (Finset.mem_univ i))))
  change pTildeStar i ∈ cSetDef K
  rw [hi0]
  exact (projCDef_mem_and_isMinOn hK (pTildeStar i)).1

private lemma emp_minimizer_vi_lip
    (h_contr_zeroSum : ∀ {N d K : ℕ} {x_dict : Fin N → EuclideanSpace ℝ (Fin d)},
      UL.DirichletFeatureCondition x_dict →
      ∀ (b₀ : UL.ZeroSumSubspace K)
        (A₀ : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K)
        {Q C : ℝ}, 0 ≤ Q → 0 ≤ C → UL.hilbertSchmidtNorm A₀ ≤ Q →
        ∀ (t : Fin N → UL.ZeroSumSubspace K),
        (∀ i j : Fin N, ‖t i - t j‖ ≤ C * ‖(b₀ + A₀ (x_dict i)) - (b₀ + A₀ (x_dict j))‖) →
        ∃ (b : UL.ZeroSumSubspace K)
          (A : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K),
          UL.hilbertSchmidtNorm A ≤ C * Q ∧ ∀ i : Fin N, t i = b + A (x_dict i))
    {n d K N : ℕ} (hK : 2 ≤ K) {R β : ℝ} (hR : 0 < R) (hβ : 0 < β)
    {x_dict : Fin N → EuclideanSpace ℝ (Fin d)}
    (h_dir : UL.DirichletFeatureCondition x_dict)
    (x_samp : Fin n → EuclideanSpace ℝ (Fin d))
    (hx_mem_dict : ∀ i : Fin n, x_samp i ∈ Set.range x_dict)
    (Z : Fin n → UL.ZeroSumSubspace K)
    {a_star : UL.ZeroSumSubspace K}
    {W_star : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K}
    (hW_star : UL.hilbertSchmidtNorm W_star ≤ R)
    (h_min_emp : ∀ (a : UL.ZeroSumSubspace K)
       (W : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K),
       UL.hilbertSchmidtNorm W ≤ R →
       ∑ i : Fin n, ‖a_star + β • W_star (x_samp i) - Z i‖ ^ 2 ≤
         ∑ i : Fin n, ‖a + β • W (x_samp i) - Z i‖ ^ 2)
    (hP_star_mem : ∀ i : Fin n, a_star + β • W_star (x_samp i) ∈ cSetDef K)
    (ρ' : UL.ZeroSumSubspace K → UL.ZeroSumSubspace K)
    (_hρ'_mem : ∀ z, ρ' z ∈ cSetDef K)
    (hρ'_lip : ∀ z₁ z₂, ‖ρ' z₁ - ρ' z₂‖ ≤ β * ‖z₁ - z₂‖) :
    let pTildeStar : Fin n → UL.ZeroSumSubspace K := fun i => a_star + β • W_star (x_samp i)
    let ξ : Fin n → EuclideanSpace ℝ (Fin K) :=
      fun i => ((pTildeStar i - Z i : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
    0 ≤ ∑ i : Fin n,
      inner ℝ (ξ i)
        (((ρ' (W_star (x_samp i)) - pTildeStar i : UL.ZeroSumSubspace K) :
          EuclideanSpace ℝ (Fin K))) := by
  intro pTildeStar ξ
  have h_ls_opt : ∀ ρ'' : UL.ZeroSumSubspace K → UL.ZeroSumSubspace K,
      (∀ z₁ z₂, ‖ρ'' z₁ - ρ'' z₂‖ ≤ β * ‖z₁ - z₂‖) →
      ∑ i : Fin n, ‖pTildeStar i - Z i‖ ^ 2 ≤ ∑ i : Fin n, ‖ρ'' (W_star (x_samp i)) - Z i‖ ^ 2 := by
    intro ρ'' hρ''_lip
    obtain ⟨b₂, W₂, hW₂_raw, h_interp₂⟩ :=
      h_contr_zeroSum h_dir 0 W_star hR.le zero_le_one hW_star
        (fun j => (1 / β) • ρ'' (W_star (x_dict j)))
        (fun j₁ j₂ => by
          rw [one_mul, zero_add, zero_add, ← smul_sub, norm_smul,
            Real.norm_of_nonneg (one_div_pos.mpr hβ).le]
          have h1 := hρ''_lip (W_star (x_dict j₁)) (W_star (x_dict j₂))
          have hmul := mul_le_mul_of_nonneg_left h1 (one_div_pos.mpr hβ).le
          have hc : (1 / β) * (β * ‖W_star (x_dict j₁) - W_star (x_dict j₂)‖) =
              ‖W_star (x_dict j₁) - W_star (x_dict j₂)‖ := by field_simp [hβ.ne']
          rwa [hc] at hmul)
    have hW₂ : UL.hilbertSchmidtNorm W₂ ≤ R := by simpa only [one_mul] using hW₂_raw
    have h_on_samp : ∀ i : Fin n, (β • b₂) + β • W₂ (x_samp i) = ρ'' (W_star (x_samp i)) := by
      intro i
      rcases hx_mem_dict i with ⟨j, hj⟩
      have hj_eq := congrArg (fun v : UL.ZeroSumSubspace K => β • v) (h_interp₂ j)
      dsimp only at hj_eq
      rw [hj, smul_smul, mul_one_div_cancel hβ.ne', one_smul, smul_add] at hj_eq
      exact hj_eq.symm
    have hmin₂ : ∑ i : Fin n, ‖pTildeStar i - Z i‖ ^ 2 ≤
        ∑ i : Fin n, ‖(β • b₂) + β • W₂ (x_samp i) - Z i‖ ^ 2 := h_min_emp (β • b₂) W₂ hW₂
    simpa only [h_on_samp] using hmin₂
  let ρ_star : UL.ZeroSumSubspace K → UL.ZeroSumSubspace K :=
    fun z => projCDef K (a_star + β • z)
  have hρ_star_on : ∀ i : Fin n, ρ_star (W_star (x_samp i)) = pTildeStar i := fun i =>
    projCDef_eq_self hK (hP_star_mem i)
  have hρ_star_lip : ∀ z₁ z₂, ‖ρ_star z₁ - ρ_star z₂‖ ≤ β * ‖z₁ - z₂‖ := by
    intro z₁ z₂
    calc ‖projCDef K (a_star + β • z₁) - projCDef K (a_star + β • z₂)‖
        ≤ ‖(a_star + β • z₁) - (a_star + β • z₂)‖ := projCDef_nonexpansive hK _ _
      _ = ‖β • (z₁ - z₂)‖ := by congr 1; rw [smul_sub]; abel
      _ = β * ‖z₁ - z₂‖ := by rw [norm_smul, Real.norm_of_nonneg hβ.le]
  refine quad_perturbation_nonneg
    (M_sq := ∑ i : Fin n,
      ‖((ρ' (W_star (x_samp i)) - pTildeStar i : UL.ZeroSumSubspace K) :
        EuclideanSpace ℝ (Fin K))‖ ^ 2)
    (Finset.sum_nonneg fun _ _ => sq_nonneg _) (fun θ hθ0 hθ_half => ?_)
  let ρ_θ := fun z => (1 - θ) • ρ_star z + θ • ρ' z
  have hρθ_lip : ∀ z₁ z₂, ‖ρ_θ z₁ - ρ_θ z₂‖ ≤ β * ‖z₁ - z₂‖ := by
    intro z₁ z₂
    have hsub : ρ_θ z₁ - ρ_θ z₂ = (1 - θ) • (ρ_star z₁ - ρ_star z₂) + θ • (ρ' z₁ - ρ' z₂) := by
      dsimp [ρ_θ]; rw [smul_sub, smul_sub]; abel
    rw [hsub]
    calc ‖(1 - θ) • (ρ_star z₁ - ρ_star z₂) + θ • (ρ' z₁ - ρ' z₂)‖
        ≤ ‖(1 - θ) • (ρ_star z₁ - ρ_star z₂)‖ + ‖θ • (ρ' z₁ - ρ' z₂)‖ := norm_add_le _ _
      _ = (1 - θ) * ‖ρ_star z₁ - ρ_star z₂‖ + θ * ‖ρ' z₁ - ρ' z₂‖ := by
          rw [norm_smul, norm_smul, Real.norm_of_nonneg (by linarith),
            Real.norm_of_nonneg hθ0.le]
      _ ≤ (1 - θ) * (β * ‖z₁ - z₂‖) + θ * (β * ‖z₁ - z₂‖) :=
          add_le_add (mul_le_mul_of_nonneg_left (hρ_star_lip z₁ z₂) (by linarith))
            (mul_le_mul_of_nonneg_left (hρ'_lip z₁ z₂) hθ0.le)
      _ = β * ‖z₁ - z₂‖ := by ring
  have hle := h_ls_opt ρ_θ hρθ_lip
  have h_exp : ∑ i : Fin n, ‖ρ_θ (W_star (x_samp i)) - Z i‖ ^ 2 =
      (∑ i : Fin n, ‖pTildeStar i - Z i‖ ^ 2) +
        2 * θ * (∑ i : Fin n,
          inner ℝ (ξ i)
            (((ρ' (W_star (x_samp i)) - pTildeStar i : UL.ZeroSumSubspace K) :
              EuclideanSpace ℝ (Fin K)))) +
        θ ^ 2 * ∑ i : Fin n,
          ‖((ρ' (W_star (x_samp i)) - pTildeStar i : UL.ZeroSumSubspace K) :
            EuclideanSpace ℝ (Fin K))‖ ^ 2 := by
    have hpt : ∀ i : Fin n, ‖ρ_θ (W_star (x_samp i)) - Z i‖ ^ 2 =
        ‖pTildeStar i - Z i‖ ^ 2 +
          2 * θ * inner ℝ (ξ i)
            (((ρ' (W_star (x_samp i)) - pTildeStar i : UL.ZeroSumSubspace K) :
              EuclideanSpace ℝ (Fin K))) +
          θ ^ 2 * ‖((ρ' (W_star (x_samp i)) - pTildeStar i : UL.ZeroSumSubspace K) :
            EuclideanSpace ℝ (Fin K))‖ ^ 2 := by
      intro i
      have hn_eq : ‖ρ_θ (W_star (x_samp i)) - Z i‖ =
          ‖ξ i + θ • (((ρ' (W_star (x_samp i)) - pTildeStar i : UL.ZeroSumSubspace K) :
            EuclideanSpace ℝ (Fin K)))‖ := by
        change ‖((ρ_θ (W_star (x_samp i)) - Z i : UL.ZeroSumSubspace K) :
          EuclideanSpace ℝ (Fin K))‖ = _
        congr 1
        dsimp only [ρ_θ]
        rw [hρ_star_on i]
        ext k
        simp only [ξ, Submodule.coe_add, Submodule.coe_sub, Submodule.coe_smul_of_tower,
          PiLp.add_apply, PiLp.sub_apply, PiLp.smul_apply, smul_eq_mul]
        ring
      have hn_base : ‖pTildeStar i - Z i‖ = ‖ξ i‖ := rfl
      rw [hn_eq, hn_base, norm_add_smul_sq]
    simp_rw [hpt, Finset.sum_add_distrib, ← Finset.mul_sum]
  linarith only [hle, h_exp]

private lemma emp_minimizer_posSupport {n d K : ℕ} (hn : 1 ≤ n) (hK : 2 ≤ K)
    {β : ℝ} (hβ : 0 < β)
    (x_samp : Fin n → EuclideanSpace ℝ (Fin d))
    (y_samp : Fin n → Fin K)
    {a_star : UL.ZeroSumSubspace K}
    {W_star : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K}
    (hP_star_mem : ∀ i : Fin n, a_star + β • W_star (x_samp i) ∈ cSetDef K)
    (h_vi_lip : ∀ ρ' : UL.ZeroSumSubspace K → UL.ZeroSumSubspace K,
      (∀ z, ρ' z ∈ cSetDef K) →
      (∀ z₁ z₂, ‖ρ' z₁ - ρ' z₂‖ ≤ β * ‖z₁ - z₂‖) →
      0 ≤ ∑ i : Fin n,
        inner ℝ ((UL.uniformVec K + ((a_star + β • W_star (x_samp i) : UL.ZeroSumSubspace K) :
            EuclideanSpace ℝ (Fin K))) - EuclideanSpace.single (y_samp i) (1 : ℝ))
          (((ρ' (W_star (x_samp i)) - (a_star + β • W_star (x_samp i)) : UL.ZeroSumSubspace K) :
            EuclideanSpace ℝ (Fin K)))) :
    let p_star : Fin n → EuclideanSpace ℝ (Fin K) :=
      fun i => UL.uniformVec K + ((a_star + β • W_star (x_samp i) : UL.ZeroSumSubspace K) :
        EuclideanSpace ℝ (Fin K))
    ∀ (i : Fin n) (j : Fin K),
      p_star i j = 0 →
        (EuclideanSpace.single (y_samp i) (1 : ℝ) : EuclideanSpace ℝ (Fin K)) j = 0 := by
  intro p_star
  classical
  have hK_pos : (0 : ℝ) < (K : ℝ) := Nat.cast_pos.mpr (by omega)
  let u := UL.uniformVec K
  let pTildeStar : Fin n → UL.ZeroSumSubspace K := fun i => a_star + β • W_star (x_samp i)
  have hp_star_mem : ∀ i : Fin n, p_star i ∈ UL.Simplex K := fun i => by
    dsimp [p_star]; rw [add_comm]; exact hP_star_mem i
  let ρ_star : UL.ZeroSumSubspace K → UL.ZeroSumSubspace K :=
    fun z => projCDef K (a_star + β • z)
  have hρ_star_on : ∀ i : Fin n, ρ_star (W_star (x_samp i)) = pTildeStar i := fun i =>
    projCDef_eq_self hK (hP_star_mem i)
  have hρ_star_lip : ∀ z₁ z₂, ‖ρ_star z₁ - ρ_star z₂‖ ≤ β * ‖z₁ - z₂‖ := by
    intro z₁ z₂
    calc ‖projCDef K (a_star + β • z₁) - projCDef K (a_star + β • z₂)‖
        ≤ ‖(a_star + β • z₁) - (a_star + β • z₂)‖ := projCDef_nonexpansive hK _ _
      _ = ‖β • (z₁ - z₂)‖ := by congr 1; rw [smul_sub]; abel
      _ = β * ‖z₁ - z₂‖ := by rw [norm_smul, Real.norm_of_nonneg hβ.le]
  let ε_i : Fin n → ℝ := fun i =>
    let J := Finset.univ.filter (fun k : Fin K => 0 < p_star i k)
    have hJ : J.Nonempty := posSupport_nonempty (hp_star_mem i)
    ((J.card : ℝ) / (K : ℝ)) * J.inf' hJ (fun k => p_star i k)
  have hε_i_pos : ∀ i : Fin n, 0 < ε_i i := fun i => by
    dsimp [ε_i]
    set J := Finset.univ.filter (fun k : Fin K => 0 < p_star i k)
    have hJ : J.Nonempty := posSupport_nonempty (hp_star_mem i)
    have hcard : (0 : ℝ) < (J.card : ℝ) := Nat.cast_pos.mpr (Finset.card_pos.mpr hJ)
    have hinf : 0 < J.inf' hJ (fun k => p_star i k) :=
      (Finset.lt_inf'_iff hJ).mpr fun k hk => (Finset.mem_filter.mp hk).2
    exact mul_pos (div_pos hcard hK_pos) hinf
  have h_univ_ne : (Finset.univ : Finset (Fin n)).Nonempty := ⟨⟨0, by omega⟩, Finset.mem_univ _⟩
  let ε₀ : ℝ := min (1 / (2 * (K : ℝ))) (Finset.univ.inf' h_univ_ne ε_i)
  have hε₀_pos : 0 < ε₀ :=
    lt_min (div_pos zero_lt_one (mul_pos zero_lt_two hK_pos))
      ((Finset.lt_inf'_iff h_univ_ne).mpr fun i _ => hε_i_pos i)
  have hε₀_lt : (K : ℝ) * ε₀ < 1 := by
    have hle : ε₀ ≤ 1 / (2 * (K : ℝ)) := min_le_left _ _
    have hmul := mul_le_mul_of_nonneg_left hle hK_pos.le
    have hhalf : (K : ℝ) * (1 / (2 * (K : ℝ))) = 1 / 2 := by field_simp [hK_pos.ne']
    linarith only [hmul, hhalf]
  let ρ' : UL.ZeroSumSubspace K → UL.ZeroSumSubspace K := fun z =>
    ⟨T_eps K ε₀ (u + (ρ_star z : EuclideanSpace ℝ (Fin K))) - u,
      UL.Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex
        (T_eps_mem_simplex hK hε₀_pos hε₀_lt _) (UL.Proof_lem_A_5.uniformVec_mem_simplex hK)⟩
  have hvi := h_vi_lip ρ'
    (fun z => by
      change (T_eps K ε₀ _ - u) + u ∈ UL.Simplex K
      simpa [sub_add_cancel] using T_eps_mem_simplex hK hε₀_pos hε₀_lt _)
    (fun z₁ z₂ => by
      change ‖(T_eps K ε₀ _ - u) - (T_eps K ε₀ _ - u)‖ ≤ β * ‖z₁ - z₂‖
      have hsub : (T_eps K ε₀ (u + (ρ_star z₁ : EuclideanSpace ℝ (Fin K))) - u) -
          (T_eps K ε₀ (u + (ρ_star z₂ : EuclideanSpace ℝ (Fin K))) - u) =
          T_eps K ε₀ (u + (ρ_star z₁ : EuclideanSpace ℝ (Fin K))) -
            T_eps K ε₀ (u + (ρ_star z₂ : EuclideanSpace ℝ (Fin K))) := by abel
      rw [hsub]
      calc ‖T_eps K ε₀ (u + (ρ_star z₁ : EuclideanSpace ℝ (Fin K))) -
            T_eps K ε₀ (u + (ρ_star z₂ : EuclideanSpace ℝ (Fin K)))‖
          ≤ ‖(u + (ρ_star z₁ : EuclideanSpace ℝ (Fin K))) -
              (u + (ρ_star z₂ : EuclideanSpace ℝ (Fin K)))‖ := T_eps_nonexpansive hK hε₀_lt _ _
        _ = ‖ρ_star z₁ - ρ_star z₂‖ := by
            change _ = ‖(ρ_star z₁ : EuclideanSpace ℝ (Fin K)) -
              (ρ_star z₂ : EuclideanSpace ℝ (Fin K))‖
            congr 1; abel
        _ ≤ β * ‖z₁ - z₂‖ := hρ_star_lip z₁ z₂)
  have hvi_sc : 0 ≤ ∑ i : Fin n,
      inner ℝ (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ))
        ((1 / ε₀) • (T_eps K ε₀ (p_star i) - p_star i)) := by
    have hmul := mul_nonneg (one_div_pos.mpr hε₀_pos).le hvi
    rw [Finset.mul_sum] at hmul
    refine le_trans hmul (le_of_eq (Finset.sum_congr rfl fun i _ => ?_))
    rw [← inner_smul_right]
    congr 2
    change (T_eps K ε₀ (u + (ρ_star (W_star (x_samp i)) : EuclideanSpace ℝ (Fin K))) - u) -
      (pTildeStar i : EuclideanSpace ℝ (Fin K)) = _
    rw [hρ_star_on i]; dsimp [p_star, u, pTildeStar]; abel
  have hterm_eq : ∀ i : Fin n,
      inner ℝ (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ))
          ((1 / ε₀) • (T_eps K ε₀ (p_star i) - p_star i)) =
        -((K : ℝ) / ((Finset.univ.filter (fun k : Fin K => 0 < p_star i k)).card : ℝ)) *
          ∑ j ∈ Finset.univ.filter (fun k : Fin K => p_star i k = 0),
            (EuclideanSpace.single (y_samp i) (1 : ℝ) : EuclideanSpace ℝ (Fin K)) j := by
    intro i
    refine T_eps_inner_eq_of_small hK (hp_star_mem i)
      (UL.Proof_lem_A_1.single_mem_simplex (y_samp i)) hε₀_pos hε₀_lt fun j hj => ?_
    let J := Finset.univ.filter (fun k : Fin K => 0 < p_star i k)
    have hJ : J.Nonempty := posSupport_nonempty (hp_star_mem i)
    have hcard_pos : (0 : ℝ) < (J.card : ℝ) := Nat.cast_pos.mpr (Finset.card_pos.mpr hJ)
    have hε_le : ε₀ ≤ ε_i i :=
      le_trans (min_le_right _ _) (Finset.inf'_le ε_i (Finset.mem_univ i))
    calc ((K : ℝ) / (J.card : ℝ)) * ε₀
        ≤ ((K : ℝ) / (J.card : ℝ)) * ε_i i :=
          mul_le_mul_of_nonneg_left hε_le (div_nonneg hK_pos.le (Nat.cast_nonneg _))
      _ = J.inf' hJ (fun k => p_star i k) := by
          dsimp [ε_i, J]; field_simp [hK_pos.ne', hcard_pos.ne']
      _ ≤ p_star i j := Finset.inf'_le _ hj
  simp_rw [hterm_eq] at hvi_sc
  intro i₀ j₀ hp₀
  have he_nn : ∀ (i : Fin n) (j : Fin K),
      0 ≤ (EuclideanSpace.single (y_samp i) (1 : ℝ) : EuclideanSpace ℝ (Fin K)) j :=
    fun i j => (UL.Proof_lem_A_1.single_mem_simplex (y_samp i)).1 j
  have hsum_nonpos :
      ∑ i : Fin n, (((K : ℝ) / ((Finset.univ.filter (fun k : Fin K => 0 < p_star i k)).card : ℝ)) *
        ∑ j ∈ Finset.univ.filter (fun k : Fin K => p_star i k = 0),
          (EuclideanSpace.single (y_samp i) (1 : ℝ) : EuclideanSpace ℝ (Fin K)) j) ≤ 0 := by
    have hneg : ∑ i : Fin n,
        (-((K : ℝ) / ((Finset.univ.filter (fun k : Fin K => 0 < p_star i k)).card : ℝ)) *
          ∑ j ∈ Finset.univ.filter (fun k : Fin K => p_star i k = 0),
            (EuclideanSpace.single (y_samp i) (1 : ℝ) : EuclideanSpace ℝ (Fin K)) j) =
        -∑ i : Fin n,
          (((K : ℝ) / ((Finset.univ.filter (fun k : Fin K => 0 < p_star i k)).card : ℝ)) *
            ∑ j ∈ Finset.univ.filter (fun k : Fin K => p_star i k = 0),
              (EuclideanSpace.single (y_samp i) (1 : ℝ) : EuclideanSpace ℝ (Fin K)) j) := by
      simp_rw [neg_mul, Finset.sum_neg_distrib]
    linarith only [hvi_sc, hneg]
  have hterm_nn : ∀ i : Fin n,
      0 ≤ ((K : ℝ) / ((Finset.univ.filter (fun k : Fin K => 0 < p_star i k)).card : ℝ)) *
        ∑ j ∈ Finset.univ.filter (fun k : Fin K => p_star i k = 0),
          (EuclideanSpace.single (y_samp i) (1 : ℝ) : EuclideanSpace ℝ (Fin K)) j := by
    intro i
    exact mul_nonneg (div_nonneg hK_pos.le (Nat.cast_nonneg _))
      (Finset.sum_nonneg fun j _ => he_nn i j)
  have hi₀_le := le_trans (Finset.single_le_sum (fun i _ => hterm_nn i) (Finset.mem_univ i₀))
    hsum_nonpos
  have hJ₀ := posSupport_nonempty (hp_star_mem i₀)
  have hcoeff_pos :
      0 < (K : ℝ) / ((Finset.univ.filter (fun k : Fin K => 0 < p_star i₀ k)).card : ℝ) := by
    have hc : (0 : ℝ) < ((Finset.univ.filter (fun k : Fin K => 0 < p_star i₀ k)).card : ℝ) :=
      Nat.cast_pos.mpr (Finset.card_pos.mpr hJ₀)
    exact div_pos hK_pos hc
  have hsum_j_le0 : ∑ j ∈ Finset.univ.filter (fun k : Fin K => p_star i₀ k = 0),
      (EuclideanSpace.single (y_samp i₀) (1 : ℝ) : EuclideanSpace ℝ (Fin K)) j ≤ 0 := by
    nlinarith only [hi₀_le, hcoeff_pos]
  have hj₀_mem : j₀ ∈ Finset.univ.filter (fun k : Fin K => p_star i₀ k = 0) :=
    Finset.mem_filter.mpr ⟨Finset.mem_univ j₀, hp₀⟩
  exact le_antisymm
    (le_trans (Finset.single_le_sum (fun j _ => he_nn i₀ j) hj₀_mem) hsum_j_le0)
    (he_nn i₀ j₀)

private lemma emp_minimizer_convex_test {n d K : ℕ} (hn : 1 ≤ n) (hK : 2 ≤ K)
    {β lam M : ℝ} (hβ : 0 < β) (hlam : 0 < lam) (hM : 0 < M)
    (x_samp : Fin n → EuclideanSpace ℝ (Fin d))
    (y_samp : Fin n → Fin K)
    {a_star : UL.ZeroSumSubspace K}
    {W_star : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K}
    (hP_star_mem : ∀ i : Fin n, a_star + β • W_star (x_samp i) ∈ cSetDef K)
    (hr_star_sum0 : ∑ i : Fin n,
      ((UL.uniformVec K + ((a_star + β • W_star (x_samp i) : UL.ZeroSumSubspace K) :
          EuclideanSpace ℝ (Fin K))) - EuclideanSpace.single (y_samp i) (1 : ℝ)) = 0)
    (h_supp_star : ∀ (i : Fin n) (j : Fin K),
      (UL.uniformVec K + ((a_star + β • W_star (x_samp i) : UL.ZeroSumSubspace K) :
        EuclideanSpace ℝ (Fin K))) j = 0 →
        (EuclideanSpace.single (y_samp i) (1 : ℝ) : EuclideanSpace ℝ (Fin K)) j = 0)
    (h_vi_lip : ∀ ρ' : UL.ZeroSumSubspace K → UL.ZeroSumSubspace K,
      (∀ z, ρ' z ∈ cSetDef K) →
      (∀ z₁ z₂, ‖ρ' z₁ - ρ' z₂‖ ≤ β * ‖z₁ - z₂‖) →
      0 ≤ ∑ i : Fin n,
        inner ℝ ((UL.uniformVec K + ((a_star + β • W_star (x_samp i) : UL.ZeroSumSubspace K) :
            EuclideanSpace ℝ (Fin K))) - EuclideanSpace.single (y_samp i) (1 : ℝ))
          (((ρ' (W_star (x_samp i)) - (a_star + β • W_star (x_samp i)) : UL.ZeroSumSubspace K) :
            EuclideanSpace ℝ (Fin K))))
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M) :
    let p_star : Fin n → EuclideanSpace ℝ (Fin K) :=
      fun i => UL.uniformVec K + ((a_star + β • W_star (x_samp i) : UL.ZeroSumSubspace K) :
        EuclideanSpace ℝ (Fin K))
    ∑ i : Fin n,
      inner ℝ (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ))
        (UL.simplexGrad Φ (p_star i)) ≤
      ∑ i : Fin n,
        inner ℝ (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ))
          (W_star (x_samp i) : EuclideanSpace ℝ (Fin K)) := by
  intro p_star
  let u := UL.uniformVec K
  let pTildeStar : Fin n → UL.ZeroSumSubspace K := fun i => a_star + β • W_star (x_samp i)
  have hp_star_mem : ∀ i : Fin n, p_star i ∈ UL.Simplex K := fun i => by
    dsimp [p_star]; rw [add_comm]; exact hP_star_mem i
  let ρ_star : UL.ZeroSumSubspace K → UL.ZeroSumSubspace K :=
    fun z => projCDef K (a_star + β • z)
  have hρ_star_on : ∀ i : Fin n, ρ_star (W_star (x_samp i)) = pTildeStar i := fun i =>
    projCDef_eq_self hK (hP_star_mem i)
  have hρ_star_lip : ∀ z₁ z₂, ‖ρ_star z₁ - ρ_star z₂‖ ≤ β * ‖z₁ - z₂‖ := by
    intro z₁ z₂
    calc ‖projCDef K (a_star + β • z₁) - projCDef K (a_star + β • z₂)‖
        ≤ ‖(a_star + β • z₁) - (a_star + β • z₂)‖ := projCDef_nonexpansive hK _ _
      _ = ‖β • (z₁ - z₂)‖ := by congr 1; rw [smul_sub]; abel
      _ = β * ‖z₁ - z₂‖ := by rw [norm_smul, Real.norm_of_nonneg hβ.le]
  let w_dir : Fin n → EuclideanSpace ℝ (Fin K) := fun i => -gJSimplex Φ β (p_star i)
  have hex_δ : ∀ i : Fin n, ∃ δ_t : ℝ, 0 < δ_t ∧ ∀ t : ℝ, 0 < t → t < δ_t →
      inner ℝ (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ))
          (((1 : ℝ) / t) • (projSimplexDef K (p_star i + t • w_dir i) - p_star i)) =
        inner ℝ (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ)) (w_dir i) :=
    fun i => projSimplex_inner_eq_of_small_t hK (hp_star_mem i)
      (UL.Proof_lem_A_1.single_mem_simplex (y_samp i)) (h_supp_star i)
  choose δ_i hδ_pos hδ_eq using hex_δ
  have h_univ_ne : (Finset.univ : Finset (Fin n)).Nonempty := ⟨⟨0, by omega⟩, Finset.mem_univ _⟩
  let δ_min : ℝ := Finset.univ.inf' h_univ_ne δ_i
  have hδ_min_pos : 0 < δ_min := (Finset.lt_inf'_iff h_univ_ne).mpr fun i _ => hδ_pos i
  let C_J : ℝ := (lam + 1 / β) * (M + 2 / β)
  have hCJ_nn : 0 ≤ C_J := by dsimp [C_J]; positivity
  have h_sum_w_nn : 0 ≤ ∑ i : Fin n,
      inner ℝ (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ)) (w_dir i) := by
    refine lin_perturbation_nonneg hδ_min_pos (K_err := 2 * (n : ℝ) * C_J) (by positivity)
      (fun t ht_pos ht_lt_min => ?_)
    have ht_lt_δ : ∀ i : Fin n, t < δ_i i := fun i =>
      lt_of_lt_of_le ht_lt_min (Finset.inf'_le δ_i (Finset.mem_univ i))
    let ρ' : UL.ZeroSumSubspace K → UL.ZeroSumSubspace K := fun z =>
      ⟨proxSimplex Φ β t (u + (ρ_star z : EuclideanSpace ℝ (Fin K))) - u,
        UL.Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex
          (proxSimplex_mem hK hΦ.1.2.1 β t _) (UL.Proof_lem_A_5.uniformVec_mem_simplex hK)⟩
    have hvi := h_vi_lip ρ'
      (fun z => by
        change (proxSimplex Φ β t _ - u) + u ∈ UL.Simplex K
        simpa [sub_add_cancel] using proxSimplex_mem hK hΦ.1.2.1 β t _)
      (fun z₁ z₂ => by
        change ‖(proxSimplex Φ β t _ - u) - (proxSimplex Φ β t _ - u)‖ ≤ β * ‖z₁ - z₂‖
        have hsub : (proxSimplex Φ β t (u + (ρ_star z₁ : EuclideanSpace ℝ (Fin K))) - u) -
            (proxSimplex Φ β t (u + (ρ_star z₂ : EuclideanSpace ℝ (Fin K))) - u) =
            proxSimplex Φ β t (u + (ρ_star z₁ : EuclideanSpace ℝ (Fin K))) -
              proxSimplex Φ β t (u + (ρ_star z₂ : EuclideanSpace ℝ (Fin K))) := by abel
        rw [hsub]
        calc ‖proxSimplex Φ β t (u + (ρ_star z₁ : EuclideanSpace ℝ (Fin K))) -
              proxSimplex Φ β t (u + (ρ_star z₂ : EuclideanSpace ℝ (Fin K)))‖
            ≤ ‖(u + (ρ_star z₁ : EuclideanSpace ℝ (Fin K))) -
                (u + (ρ_star z₂ : EuclideanSpace ℝ (Fin K)))‖ :=
              proxSimplex_nonexpansive hK hβ le_rfl ht_pos hΦ _ _
          _ = ‖ρ_star z₁ - ρ_star z₂‖ := by
              change _ = ‖(ρ_star z₁ : EuclideanSpace ℝ (Fin K)) -
                (ρ_star z₂ : EuclideanSpace ℝ (Fin K))‖
              congr 1; abel
          _ ≤ β * ‖z₁ - z₂‖ := hρ_star_lip z₁ z₂)
    have hvi_sc : 0 ≤ ∑ i : Fin n,
        inner ℝ (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ))
          ((1 / t) • (proxSimplex Φ β t (p_star i) - p_star i)) := by
      have hmul := mul_nonneg (one_div_pos.mpr ht_pos).le hvi
      rw [Finset.mul_sum] at hmul
      refine le_trans hmul (le_of_eq (Finset.sum_congr rfl fun i _ => ?_))
      rw [← inner_smul_right]
      congr 2
      change (proxSimplex Φ β t
        (u + (ρ_star (W_star (x_samp i)) : EuclideanSpace ℝ (Fin K))) - u) -
        (pTildeStar i : EuclideanSpace ℝ (Fin K)) = _
      rw [hρ_star_on i]; dsimp [p_star, u, pTildeStar]; abel
    have h_pt : ∀ i : Fin n,
        inner ℝ (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ))
            ((1 / t) • (proxSimplex Φ β t (p_star i) - p_star i)) ≤
          inner ℝ (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ)) (w_dir i) +
            2 * C_J * t := by
      intro i
      have h_id := hδ_eq i t ht_pos (ht_lt_δ i)
      have h_arg : p_star i + t • w_dir i = p_star i - t • gJSimplex Φ β (p_star i) := by
        dsimp [w_dir]; rw [smul_neg, sub_eq_add_neg]
      have h_split : (1 / t) • (proxSimplex Φ β t (p_star i) - p_star i) =
          ((1 / t) • (projSimplexDef K (p_star i + t • w_dir i) - p_star i)) +
            (1 / t) • (proxSimplex Φ β t (p_star i) -
              projSimplexDef K (p_star i - t • gJSimplex Φ β (p_star i))) := by
        rw [h_arg, ← smul_add]; congr 1; abel
      rw [h_split, inner_add_right, h_id]
      have hr_norm : ‖p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ)‖ ≤ 2 := by
        calc ‖p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ)‖
            ≤ ‖p_star i‖ + ‖(EuclideanSpace.single (y_samp i) (1 : ℝ) : EuclideanSpace ℝ (Fin K))‖ :=
              norm_sub_le _ _
          _ ≤ 1 + 1 := add_le_add (norm_le_one_of_mem_simplex (hp_star_mem i))
              (norm_le_one_of_mem_simplex (UL.Proof_lem_A_1.single_mem_simplex (y_samp i)))
          _ = 2 := by norm_num
      have h_approx := proxSimplex_approx hK hβ le_rfl ht_pos hΦ (hp_star_mem i)
      rw [inner_smul_right]
      have hcs := real_inner_le_norm (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ))
        (proxSimplex Φ β t (p_star i) - projSimplexDef K (p_star i - t • gJSimplex Φ β (p_star i)))
      have hprod : ‖p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ)‖ *
          ‖proxSimplex Φ β t (p_star i) -
            projSimplexDef K (p_star i - t • gJSimplex Φ β (p_star i))‖ ≤ 2 * (C_J * t ^ 2) :=
        mul_le_mul hr_norm h_approx (norm_nonneg _) (by norm_num)
      have h_err : (1 / t) * inner ℝ (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ))
          (proxSimplex Φ β t (p_star i) -
            projSimplexDef K (p_star i - t • gJSimplex Φ β (p_star i))) ≤ 2 * C_J * t := by
        calc (1 / t) * inner ℝ _ _
            ≤ (1 / t) * (2 * (C_J * t ^ 2)) :=
              mul_le_mul_of_nonneg_left (le_trans hcs hprod) (one_div_pos.mpr ht_pos).le
          _ = 2 * C_J * t := by field_simp [ht_pos.ne']
      linarith only [h_err]
    have h_sum_ub := Finset.sum_le_sum (s := Finset.univ) fun i _ => h_pt i
    rw [Finset.sum_add_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
      nsmul_eq_mul] at h_sum_ub
    have h_alg : (n : ℝ) * (2 * C_J * t) = (2 * (n : ℝ) * C_J) * t := by ring
    linarith only [hvi_sc, h_sum_ub, h_alg]
  have h_unpack : ∑ i : Fin n,
      inner ℝ (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ)) (w_dir i) =
      (1 / β) * (∑ i : Fin n,
          inner ℝ (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ))
            (pTildeStar i : EuclideanSpace ℝ (Fin K))) -
        ∑ i : Fin n,
          inner ℝ (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ))
            (UL.simplexGrad Φ (p_star i)) := by
    rw [Finset.mul_sum, ← Finset.sum_sub_distrib]
    refine Finset.sum_congr rfl fun i _ => ?_
    have hp_sub : p_star i - u = (pTildeStar i : EuclideanSpace ℝ (Fin K)) := by
      dsimp [p_star, u, pTildeStar]; abel
    dsimp only [w_dir]
    unfold gJSimplex
    rw [inner_neg_right, inner_sub_right, hp_sub, inner_smul_right]
    ring
  have h_own_eq : (1 / β) * (∑ i : Fin n,
      inner ℝ (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ))
        (pTildeStar i : EuclideanSpace ℝ (Fin K))) =
      ∑ i : Fin n,
        inner ℝ (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ))
          (W_star (x_samp i) : EuclideanSpace ℝ (Fin K)) := by
    have h1 : ∑ i : Fin n,
        inner ℝ (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ))
          (pTildeStar i : EuclideanSpace ℝ (Fin K)) =
        inner ℝ (∑ i : Fin n, (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ)))
          (a_star : EuclideanSpace ℝ (Fin K)) +
          β * ∑ i : Fin n,
            inner ℝ (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ))
              (W_star (x_samp i) : EuclideanSpace ℝ (Fin K)) := by
      rw [sum_inner, Finset.mul_sum, ← Finset.sum_add_distrib]
      refine Finset.sum_congr rfl fun i _ => ?_
      change inner ℝ _
        ((a_star : EuclideanSpace ℝ (Fin K)) + β • (W_star (x_samp i) : EuclideanSpace ℝ (Fin K))) = _
      rw [inner_add_right, inner_smul_right]
    rw [h1, hr_star_sum0, inner_zero_left, zero_add]
    field_simp [hβ.ne']
  linarith only [h_sum_w_nn, h_unpack, h_own_eq]

private lemma emp_approx_transfer {n d K : ℕ} (hn : 1 ≤ n) (hK : 2 ≤ K)
    {β lam M ε : ℝ} (hβ : 0 < β) (hlam : 0 < lam) (hε : 0 < ε)
    (x_samp : Fin n → EuclideanSpace ℝ (Fin d))
    (y_samp : Fin n → Fin K)
    {a_star aHat : UL.ZeroSumSubspace K}
    {W_star WHat : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K}
    (hP_star_mem : ∀ i : Fin n, a_star + β • W_star (x_samp i) ∈ cSetDef K)
    (hr_star_sum0 : ∑ i : Fin n,
      (((a_star + β • W_star (x_samp i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) -
        (EuclideanSpace.single (y_samp i) (1 : ℝ) - UL.uniformVec K)) = 0)
    (h_vi_WHat :
      ∑ i : Fin n,
        inner ℝ (((a_star + β • W_star (x_samp i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) -
            (EuclideanSpace.single (y_samp i) (1 : ℝ) - UL.uniformVec K))
          (W_star (x_samp i) : EuclideanSpace ℝ (Fin K)) ≤
      ∑ i : Fin n,
        inner ℝ (((a_star + β • W_star (x_samp i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) -
            (EuclideanSpace.single (y_samp i) (1 : ℝ) - UL.uniformVec K))
          (WHat (x_samp i) : EuclideanSpace ℝ (Fin K)))
    (h_opt_star :
      (1 / (2 * (n : ℝ))) * ∑ i : Fin n,
          ‖((aHat + β • WHat (x_samp i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) -
            (EuclideanSpace.single (y_samp i) (1 : ℝ) - UL.uniformVec K)‖ ^ 2 ≤
        (1 / (2 * (n : ℝ))) * ∑ i : Fin n,
          ‖((a_star + β • W_star (x_samp i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) -
            (EuclideanSpace.single (y_samp i) (1 : ℝ) - UL.uniformVec K)‖ ^ 2 +
          ε ^ 2 / (32 * lam ^ 2))
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M) :
    let pHat : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin K) :=
      fun x => UL.uniformVec K + (projCDef K (aHat + β • WHat x) : EuclideanSpace ℝ (Fin K))
    let p_star : Fin n → EuclideanSpace ℝ (Fin K) :=
      fun i => UL.uniformVec K + ((a_star + β • W_star (x_samp i) : UL.ZeroSumSubspace K) :
        EuclideanSpace ℝ (Fin K))
    (1 / (n : ℝ)) * ∑ i : Fin n, UL.finiteCanonicalLoss Φ (pHat (x_samp i)) (y_samp i) ≤
      (1 / (n : ℝ)) * ∑ i : Fin n, UL.finiteCanonicalLoss Φ (p_star i) (y_samp i) + ε / 2 := by
  intro pHat p_star
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  let u := UL.uniformVec K
  let pTildeStar : Fin n → UL.ZeroSumSubspace K := fun i => a_star + β • W_star (x_samp i)
  let T_hat : Fin n → UL.ZeroSumSubspace K := fun i => aHat + β • WHat (x_samp i)
  let ξ : Fin n → EuclideanSpace ℝ (Fin K) :=
    fun i => ((pTildeStar i : EuclideanSpace ℝ (Fin K)) - (EuclideanSpace.single (y_samp i) (1 : ℝ) - u))
  let d_vec : Fin n → EuclideanSpace ℝ (Fin K) :=
    fun i => ((T_hat i - pTildeStar i : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
  have hp_star_mem : ∀ i : Fin n, p_star i ∈ UL.Simplex K := fun i => by
    dsimp [p_star]; rw [add_comm]; exact hP_star_mem i
  have h_cross_nn : 0 ≤ ∑ i : Fin n, inner ℝ (ξ i) (d_vec i) := by
    have h_split : ∑ i : Fin n, inner ℝ (ξ i) (d_vec i) =
        inner ℝ (∑ i : Fin n, ξ i)
          ((aHat - a_star : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) +
          β * ((∑ i : Fin n, inner ℝ (ξ i) (WHat (x_samp i) : EuclideanSpace ℝ (Fin K))) -
            ∑ i : Fin n, inner ℝ (ξ i) (W_star (x_samp i) : EuclideanSpace ℝ (Fin K))) := by
      rw [sum_inner, mul_sub, Finset.mul_sum, Finset.mul_sum, ← Finset.sum_sub_distrib,
        ← Finset.sum_add_distrib]
      refine Finset.sum_congr rfl fun i _ => ?_
      have hd : d_vec i =
          ((aHat - a_star : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) +
            β • ((WHat (x_samp i) : EuclideanSpace ℝ (Fin K)) -
              (W_star (x_samp i) : EuclideanSpace ℝ (Fin K))) := by
        dsimp [d_vec, T_hat, pTildeStar]; rw [smul_sub]; abel
      rw [hd, inner_add_right, inner_smul_right, inner_sub_right, mul_sub]
    have hr0 : ∑ i : Fin n, ξ i = 0 := hr_star_sum0
    rw [h_split, hr0, inner_zero_left, zero_add]
    have hvi : ∑ i : Fin n, inner ℝ (ξ i) (W_star (x_samp i) : EuclideanSpace ℝ (Fin K)) ≤
        ∑ i : Fin n, inner ℝ (ξ i) (WHat (x_samp i) : EuclideanSpace ℝ (Fin K)) := h_vi_WHat
    nlinarith only [hβ, hvi]
  have h_quad_exp :
      ∑ i : Fin n,
          ‖((aHat + β • WHat (x_samp i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) -
            (EuclideanSpace.single (y_samp i) (1 : ℝ) - u)‖ ^ 2 =
        (∑ i : Fin n,
          ‖((a_star + β • W_star (x_samp i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) -
            (EuclideanSpace.single (y_samp i) (1 : ℝ) - u)‖ ^ 2) +
          2 * (∑ i : Fin n, inner ℝ (ξ i) (d_vec i)) +
          ∑ i : Fin n, ‖d_vec i‖ ^ 2 := by
    have hpt : ∀ i : Fin n,
        ‖((aHat + β • WHat (x_samp i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) -
            (EuclideanSpace.single (y_samp i) (1 : ℝ) - u)‖ ^ 2 =
          ‖ξ i‖ ^ 2 + 2 * inner ℝ (ξ i) (d_vec i) + ‖d_vec i‖ ^ 2 := by
      intro i
      have hsplit : ((aHat + β • WHat (x_samp i) : UL.ZeroSumSubspace K) :
          EuclideanSpace ℝ (Fin K)) - (EuclideanSpace.single (y_samp i) (1 : ℝ) - u) =
          ξ i + d_vec i := by
        dsimp [ξ, d_vec, T_hat, pTildeStar]; abel
      rw [hsplit, norm_add_sq_real]
    have hbase : ∀ i : Fin n,
        ‖((a_star + β • W_star (x_samp i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) -
          (EuclideanSpace.single (y_samp i) (1 : ℝ) - u)‖ ^ 2 = ‖ξ i‖ ^ 2 := fun _ => rfl
    simp_rw [hpt, hbase, Finset.sum_add_distrib, ← Finset.mul_sum]
  have h_l2_sq : (1 / (n : ℝ)) * ∑ i : Fin n, ‖d_vec i‖ ^ 2 ≤ (ε / (4 * lam)) ^ 2 := by
    have hmul := mul_le_mul_of_nonneg_left h_opt_star (by norm_num : (0 : ℝ) ≤ 2)
    change 2 * ((1 / (2 * (n : ℝ))) * ∑ i : Fin n,
        ‖((aHat + β • WHat (x_samp i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) -
          (EuclideanSpace.single (y_samp i) (1 : ℝ) - u)‖ ^ 2) ≤
      2 * ((1 / (2 * (n : ℝ))) * ∑ i : Fin n,
        ‖((a_star + β • W_star (x_samp i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) -
          (EuclideanSpace.single (y_samp i) (1 : ℝ) - u)‖ ^ 2 + ε ^ 2 / (32 * lam ^ 2)) at hmul
    rw [h_quad_exp] at hmul
    set A_sum := ∑ i : Fin n,
      ‖((a_star + β • W_star (x_samp i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) -
        (EuclideanSpace.single (y_samp i) (1 : ℝ) - u)‖ ^ 2
    set B_sum := ∑ i : Fin n, inner ℝ (ξ i) (d_vec i)
    set C_sum := ∑ i : Fin n, ‖d_vec i‖ ^ 2
    have h1 : 2 * ((1 / (2 * (n : ℝ))) * (A_sum + 2 * B_sum + C_sum)) =
        (1 / (n : ℝ)) * A_sum + (2 / (n : ℝ)) * B_sum + (1 / (n : ℝ)) * C_sum := by
      field_simp [hn_pos.ne']
    have h2 : 2 * ((1 / (2 * (n : ℝ))) * A_sum + ε ^ 2 / (32 * lam ^ 2)) =
        (1 / (n : ℝ)) * A_sum + (ε / (4 * lam)) ^ 2 := by
      field_simp [hn_pos.ne', hlam.ne']; ring
    have hB_nn : 0 ≤ (2 / (n : ℝ)) * B_sum := mul_nonneg (by positivity) h_cross_nn
    linarith only [hmul, h1, h2, hB_nn]
  let s₀ : ℝ := ε / (4 * lam)
  have hs₀_pos : 0 < s₀ := by dsimp [s₀]; positivity
  have h_l1 : (1 / (n : ℝ)) * ∑ i : Fin n, ‖pHat (x_samp i) - p_star i‖ ≤ s₀ := by
    have h_p_le_d : ∀ i : Fin n, ‖pHat (x_samp i) - p_star i‖ ≤ ‖d_vec i‖ := by
      intro i
      have hp_eq : p_star i = u + (projCDef K (pTildeStar i) : EuclideanSpace ℝ (Fin K)) :=
        congrArg (fun v : UL.ZeroSumSubspace K => u + (v : EuclideanSpace ℝ (Fin K)))
          (projCDef_eq_self hK (hP_star_mem i)).symm
      have hdiff : pHat (x_samp i) - p_star i =
          ((projCDef K (T_hat i) - projCDef K (pTildeStar i) : UL.ZeroSumSubspace K) :
            EuclideanSpace ℝ (Fin K)) := by
        rw [hp_eq]
        change (u + (projCDef K (T_hat i) : EuclideanSpace ℝ (Fin K))) -
          (u + (projCDef K (pTildeStar i) : EuclideanSpace ℝ (Fin K))) =
          (projCDef K (T_hat i) : EuclideanSpace ℝ (Fin K)) -
            (projCDef K (pTildeStar i) : EuclideanSpace ℝ (Fin K))
        abel
      have hn_eq : ‖pHat (x_samp i) - p_star i‖ =
          ‖projCDef K (T_hat i) - projCDef K (pTildeStar i)‖ := by rw [hdiff]; rfl
      rw [hn_eq]
      exact projCDef_nonexpansive hK _ _
    have h_amgm : ∀ i : Fin n,
        ‖pHat (x_samp i) - p_star i‖ ≤ ‖d_vec i‖ ^ 2 / (2 * s₀) + s₀ / 2 := by
      intro i
      have hle := h_p_le_d i
      have h1 : ‖d_vec i‖ ≤ ‖d_vec i‖ ^ 2 / (2 * s₀) + s₀ / 2 := by
        rw [← sub_nonneg]
        have h_id : ‖d_vec i‖ ^ 2 / (2 * s₀) + s₀ / 2 - ‖d_vec i‖ =
            (‖d_vec i‖ - s₀) ^ 2 / (2 * s₀) := by
          field_simp [hs₀_pos.ne']; ring
        rw [h_id]; positivity
      linarith only [hle, h1]
    have hsum_amgm := Finset.sum_le_sum (s := Finset.univ) fun i _ => h_amgm i
    rw [Finset.sum_add_distrib, ← Finset.sum_div, Finset.sum_const, Finset.card_univ,
      Fintype.card_fin, nsmul_eq_mul] at hsum_amgm
    have hmul := mul_le_mul_of_nonneg_left hsum_amgm (one_div_pos.mpr hn_pos).le
    have h_alg1 : (1 / (n : ℝ)) * ((∑ i : Fin n, ‖d_vec i‖ ^ 2) / (2 * s₀) + (n : ℝ) * (s₀ / 2)) =
        ((1 / (n : ℝ)) * ∑ i : Fin n, ‖d_vec i‖ ^ 2) / (2 * s₀) + s₀ / 2 := by
      field_simp [hn_pos.ne', hs₀_pos.ne']
    rw [h_alg1] at hmul
    have h_div_s : ((1 / (n : ℝ)) * ∑ i : Fin n, ‖d_vec i‖ ^ 2) / (2 * s₀) ≤ s₀ ^ 2 / (2 * s₀) :=
      div_le_div_of_nonneg_right h_l2_sq (by positivity)
    have h_half : s₀ ^ 2 / (2 * s₀) = s₀ / 2 := by field_simp [hs₀_pos.ne']
    linarith only [hmul, h_div_s, h_half]
  have hpHat_mem : ∀ x : EuclideanSpace ℝ (Fin d), pHat x ∈ UL.Simplex K :=
    fun x => uniformVec_add_projCDef_mem_simplex hK (aHat + β • WHat x)
  have h_diff_sum :
      (∑ i : Fin n, UL.finiteCanonicalLoss Φ (pHat (x_samp i)) (y_samp i)) -
        (∑ i : Fin n, UL.finiteCanonicalLoss Φ (p_star i) (y_samp i)) ≤
        2 * lam * ∑ i : Fin n, ‖pHat (x_samp i) - p_star i‖ := by
    rw [← Finset.sum_sub_distrib, Finset.mul_sum]
    refine Finset.sum_le_sum fun i _ => ?_
    exact le_trans (le_abs_self _)
      (finiteCanonicalLoss_lipschitz hΦ (hpHat_mem (x_samp i)) (hp_star_mem i) (y_samp i))
  have hmul := mul_le_mul_of_nonneg_left h_diff_sum (one_div_pos.mpr hn_pos).le
  have h_alg : (1 / (n : ℝ)) * (2 * lam * ∑ i : Fin n, ‖pHat (x_samp i) - p_star i‖) =
      2 * lam * ((1 / (n : ℝ)) * ∑ i : Fin n, ‖pHat (x_samp i) - p_star i‖) := by ring
  rw [mul_sub, h_alg] at hmul
  have h_2lam_s₀ : 2 * lam * s₀ = ε / 2 := by dsimp [s₀]; field_simp [hlam.ne']; ring
  have h_prod_le := mul_le_mul_of_nonneg_left h_l1 (show (0 : ℝ) ≤ 2 * lam by positivity)
  linarith only [hmul, h_2lam_s₀, h_prod_le]

private lemma empirical_approx_omniprediction
    (h_contr_zeroSum : ∀ {N d K : ℕ} {x_dict : Fin N → EuclideanSpace ℝ (Fin d)},
      UL.DirichletFeatureCondition x_dict →
      ∀ (b₀ : UL.ZeroSumSubspace K)
        (A₀ : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K)
        {Q C : ℝ}, 0 ≤ Q → 0 ≤ C → UL.hilbertSchmidtNorm A₀ ≤ Q →
        ∀ (t : Fin N → UL.ZeroSumSubspace K),
        (∀ i j : Fin N, ‖t i - t j‖ ≤ C * ‖(b₀ + A₀ (x_dict i)) - (b₀ + A₀ (x_dict j))‖) →
        ∃ (b : UL.ZeroSumSubspace K)
          (A : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K),
          UL.hilbertSchmidtNorm A ≤ C * Q ∧ ∀ i : Fin N, t i = b + A (x_dict i))
    {n d K N : ℕ} (hn : 1 ≤ n) (hK : 2 ≤ K)
    {R β lam M ε : ℝ}
    (hR : 0 < R) (hβ : 0 < β) (hlam : 0 < lam) (hM : 0 < M) (hε : 0 < ε)
    {x_dict : Fin N → EuclideanSpace ℝ (Fin d)}
    (h_dir : UL.DirichletFeatureCondition x_dict)
    (x_samp : Fin n → EuclideanSpace ℝ (Fin d))
    (y_samp : Fin n → Fin K)
    (hx_mem_dict : ∀ i : Fin n, x_samp i ∈ Set.range x_dict)
    {aHat : UL.ZeroSumSubspace K}
    {WHat : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K}
    (hWHat : UL.hilbertSchmidtNorm WHat ≤ R)
    (h_opt : ∀ (a : UL.ZeroSumSubspace K)
       (W : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K),
       UL.hilbertSchmidtNorm W ≤ R →
       (1 / (2 * (n : ℝ))) * ∑ i : Fin n,
           ‖((aHat + β • WHat (x_samp i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) -
             (EuclideanSpace.single (y_samp i) (1 : ℝ) - UL.uniformVec K)‖ ^ 2 ≤
         (1 / (2 * (n : ℝ))) * ∑ i : Fin n,
           ‖((a + β • W (x_samp i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) -
             (EuclideanSpace.single (y_samp i) (1 : ℝ) - UL.uniformVec K)‖ ^ 2 +
           ε ^ 2 / (32 * lam ^ 2))
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K}
    (hV : UL.hilbertSchmidtNorm V ≤ R) :
    let pHat : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin K) :=
      fun x => UL.uniformVec K + (projCDef K (aHat + β • WHat x) : EuclideanSpace ℝ (Fin K))
    (1 / (n : ℝ)) * ∑ i : Fin n, UL.finiteCanonicalLoss Φ (pHat (x_samp i)) (y_samp i) ≤
      (1 / (n : ℝ)) * ∑ i : Fin n,
        UL.matchingLoss Φ (V (x_samp i) : EuclideanSpace ℝ (Fin K)) (y_samp i) + ε / 2 := by
  intro pHat
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  let u := UL.uniformVec K
  let Z : Fin n → UL.ZeroSumSubspace K := fun i =>
    ⟨EuclideanSpace.single (y_samp i) (1 : ℝ) - u,
      UL.Proof_lem_A_5.sub_mem_zeroSumSubspace_of_mem_simplex
        (UL.Proof_lem_A_1.single_mem_simplex (y_samp i))
        (UL.Proof_lem_A_5.uniformVec_mem_simplex hK)⟩
  have hZ_mem_C : ∀ i : Fin n, Z i ∈ cSetDef K := fun i => by
    change (EuclideanSpace.single (y_samp i) (1 : ℝ) - u) + u ∈ UL.Simplex K
    simpa [sub_add_cancel] using UL.Proof_lem_A_1.single_mem_simplex (y_samp i)
  obtain ⟨a_star, W_star, hW_star, h_res_sum0, h_min_emp⟩ :=
    exists_exact_emp_minimizer (β := β) hn hR x_samp Z
  let p_star : Fin n → EuclideanSpace ℝ (Fin K) :=
    fun i => u + ((a_star + β • W_star (x_samp i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
  have hr_eq : ∀ i : Fin n,
      ((a_star + β • W_star (x_samp i) - Z i : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) =
        p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ) := by
    intro i
    change ((a_star + β • W_star (x_samp i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) -
      (EuclideanSpace.single (y_samp i) (1 : ℝ) - u) = _
    dsimp [p_star, u]; abel
  have hr_p_sum0 : ∑ i : Fin n, (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ)) = 0 := by
    simpa only [hr_eq] using h_res_sum0
  have hP_star_mem := emp_minimizer_mem_cSetDef h_contr_zeroSum hK hR hβ h_dir x_samp
    hx_mem_dict hZ_mem_C hW_star h_min_emp
  have hp_star_mem : ∀ i : Fin n, p_star i ∈ UL.Simplex K := fun i => by
    dsimp [p_star]; rw [add_comm]; exact hP_star_mem i
  have h_vi_lip_p : ∀ ρ' : UL.ZeroSumSubspace K → UL.ZeroSumSubspace K,
      (∀ z, ρ' z ∈ cSetDef K) →
      (∀ z₁ z₂, ‖ρ' z₁ - ρ' z₂‖ ≤ β * ‖z₁ - z₂‖) →
      0 ≤ ∑ i : Fin n,
        inner ℝ (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ))
          (((ρ' (W_star (x_samp i)) - (a_star + β • W_star (x_samp i)) : UL.ZeroSumSubspace K) :
            EuclideanSpace ℝ (Fin K))) := by
    intro ρ' hρ'_mem hρ'_lip
    have hvi := emp_minimizer_vi_lip h_contr_zeroSum hK hR hβ h_dir x_samp hx_mem_dict Z
      hW_star h_min_emp hP_star_mem ρ' hρ'_mem hρ'_lip
    dsimp only at hvi
    simpa only [hr_eq] using hvi
  have h_supp_star := emp_minimizer_posSupport hn hK hβ x_samp y_samp hP_star_mem h_vi_lip_p
  have h_conv_test := emp_minimizer_convex_test hn hK hβ hlam hM x_samp y_samp hP_star_mem
    hr_p_sum0 h_supp_star h_vi_lip_p hΦ
  dsimp only at h_conv_test
  have h_vi_V : ∑ i : Fin n,
      inner ℝ (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ))
        (W_star (x_samp i) : EuclideanSpace ℝ (Fin K)) ≤
      ∑ i : Fin n,
        inner ℝ (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ))
          (V (x_samp i) : EuclideanSpace ℝ (Fin K)) := by
    have hvi := emp_minimizer_vi_W hβ x_samp Z hW_star h_min_emp hV
    dsimp only at hvi
    simpa only [hr_eq] using hvi
  have h_emp_V : (1 / (n : ℝ)) * ∑ i : Fin n, UL.finiteCanonicalLoss Φ (p_star i) (y_samp i) ≤
      (1 / (n : ℝ)) * ∑ i : Fin n,
        UL.matchingLoss Φ (V (x_samp i) : EuclideanSpace ℝ (Fin K)) (y_samp i) := by
    have h_lhs : ∑ i : Fin n, UL.finiteCanonicalLoss Φ (p_star i) (y_samp i) =
        -(∑ i : Fin n, UL.extendSimplex Φ (p_star i)) +
          ∑ i : Fin n,
            inner ℝ (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ))
              (UL.simplexGrad Φ (p_star i)) := by
      simp_rw [finiteCanonicalLoss_eq hΦ (hp_star_mem _), Finset.sum_add_distrib,
        Finset.sum_neg_distrib]
    have h_rhs : -(∑ i : Fin n, UL.extendSimplex Φ (p_star i)) +
          (∑ i : Fin n,
            inner ℝ (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ))
              (V (x_samp i) : EuclideanSpace ℝ (Fin K))) ≤
        ∑ i : Fin n, UL.matchingLoss Φ (V (x_samp i) : EuclideanSpace ℝ (Fin K)) (y_samp i) := by
      have hpt : ∀ i : Fin n,
          -UL.extendSimplex Φ (p_star i) +
              inner ℝ (p_star i - EuclideanSpace.single (y_samp i) (1 : ℝ))
                (V (x_samp i) : EuclideanSpace ℝ (Fin K)) ≤
            UL.matchingLoss Φ (V (x_samp i) : EuclideanSpace ℝ (Fin K)) (y_samp i) :=
        fun i => matchingLoss_lower_bound hΦ.1.2.1 (hp_star_mem i) (V (x_samp i)) (y_samp i)
      have hsum := Finset.sum_le_sum (s := Finset.univ) fun i _ => hpt i
      rwa [Finset.sum_add_distrib, Finset.sum_neg_distrib] at hsum
    have h_mid := le_trans h_conv_test h_vi_V
    exact mul_le_mul_of_nonneg_left (by linarith only [h_lhs, h_rhs, h_mid])
      (one_div_pos.mpr hn_pos).le
  have h_vi_WHat := emp_minimizer_vi_W hβ x_samp Z hW_star h_min_emp hWHat
  dsimp only at h_vi_WHat
  have h_transfer := emp_approx_transfer hn hK hβ hlam hε x_samp y_samp hP_star_mem
    h_res_sum0 h_vi_WHat (h_opt a_star W_star hW_star) hΦ
  dsimp only at h_transfer
  linarith only [h_emp_V, h_transfer]

/-! ### Part 5: Core Omniprediction Assembly -/

private lemma learned_forecast_stat_transfer
    (h_contr_eucl : ∀ {N d m₁ m₂ : ℕ} {x_dict : Fin N → EuclideanSpace ℝ (Fin d)},
      UL.DirichletFeatureCondition x_dict →
      ∀ (b₀ : EuclideanSpace ℝ (Fin m₁))
        (A₀ : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin m₁))
        {Q C : ℝ}, 0 ≤ Q → 0 ≤ C → UL.hilbertSchmidtNorm A₀ ≤ Q →
        ∀ (t : Fin N → EuclideanSpace ℝ (Fin m₂)),
        (∀ i j : Fin N, ‖t i - t j‖ ≤ C * ‖(b₀ + A₀ (x_dict i)) - (b₀ + A₀ (x_dict j))‖) →
        ∃ (b : EuclideanSpace ℝ (Fin m₂))
          (A : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin m₂)),
          UL.hilbertSchmidtNorm A ≤ C * Q ∧ ∀ i : Fin N, t i = b + A (x_dict i))
    (h_contr_scalar : ∀ {N d K : ℕ} {x_dict : Fin N → EuclideanSpace ℝ (Fin d)},
      UL.DirichletFeatureCondition x_dict →
      ∀ (b₀ : UL.ZeroSumSubspace K)
        (A₀ : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K)
        {Q C : ℝ}, 0 ≤ Q → 0 ≤ C → UL.hilbertSchmidtNorm A₀ ≤ Q →
        ∀ (t : Fin N → ℝ),
        (∀ i j : Fin N, |t i - t j| ≤ C * ‖(b₀ + A₀ (x_dict i)) - (b₀ + A₀ (x_dict j))‖) →
        ∃ (b : ℝ) (v : EuclideanSpace ℝ (Fin d)),
          ‖v‖ ≤ C * Q ∧ ∀ i : Fin N, t i = b + inner ℝ v (x_dict i))
    {n d K N : ℕ} (hn : 1 ≤ n) (hK : 2 ≤ K)
    {L R β lam M ε δ : ℝ}
    (hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) (hlam : 0 < lam)
    (h_rate_quarter :
      12 * (M + L * R + β * lam * L * R) * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ)) ≤ ε / 4)
    {x_dict : Fin N → EuclideanSpace ℝ (Fin d)}
    (h_dir : UL.DirichletFeatureCondition x_dict)
    (hx_dict : ∀ j : Fin N, ‖x_dict j‖ ≤ L)
    (ν : MeasureTheory.Measure (EuclideanSpace ℝ (Fin d) × Fin K))
    [MeasureTheory.IsProbabilityMeasure ν]
    (x_samp : Fin n → EuclideanSpace ℝ (Fin d))
    (y_samp : Fin n → Fin K)
    (h_conc : ∀ (b : ℝ) (v : EuclideanSpace ℝ (Fin d))
       (c_vec : EuclideanSpace ℝ (Fin K))
       (B : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin K))
       (f : EuclideanSpace ℝ (Fin d) × Fin K → ℝ),
       MeasureTheory.Integrable f ν →
       (∀ j : Fin N, ∀ y : Fin K,
         f (x_dict j, y) =
           b + inner ℝ v (x_dict j) -
             inner ℝ (EuclideanSpace.single y (1 : ℝ) - UL.uniformVec K)
               (c_vec + B (x_dict j))) →
       |(∫ xy, f xy ∂ν) - (1 / (n : ℝ)) * ∑ i : Fin n, f (x_samp i, y_samp i)| ≤
         4 * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ)) *
           (L * ‖v‖ + ‖c_vec‖ + L * UL.hilbertSchmidtNorm B))
    {aHat : UL.ZeroSumSubspace K}
    {WHat : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K}
    (hWHat : UL.hilbertSchmidtNorm WHat ≤ R)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M) :
    let pHat : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin K) :=
      fun x => UL.uniformVec K + (projCDef K (aHat + β • WHat x) : EuclideanSpace ℝ (Fin K))
    (∫ xy, UL.finiteCanonicalLoss Φ (pHat xy.1) xy.2 ∂ν) -
      (1 / (n : ℝ)) * ∑ i : Fin n, UL.finiteCanonicalLoss Φ (pHat (x_samp i)) (y_samp i) ≤
      ε / 4 := by
  intro pHat
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  let u := UL.uniformVec K
  have hpHat_mem : ∀ x : EuclideanSpace ℝ (Fin d), pHat x ∈ UL.Simplex K :=
    fun x => uniformVec_add_projCDef_mem_simplex hK (aHat + β • WHat x)
  have hpHat_cont : Continuous pHat := by
    refine continuous_const.add (continuous_subtype_val.comp ?_)
    have h_lip_proj : LipschitzWith 1 (projCDef K) :=
      LipschitzWith.of_dist_le_mul fun v₁ v₂ => by
        simpa [dist_eq_norm] using projCDef_nonexpansive hK v₁ v₂
    exact h_lip_proj.continuous.comp (continuous_const.add (continuous_const.smul WHat.continuous))
  have h_fcl_contOn : ∀ y : Fin K,
      ContinuousOn (fun q => UL.finiteCanonicalLoss Φ q y) (UL.Simplex K) := by
    intro y
    rw [Metric.continuousOn_iff]
    intro q hq ε_c hε_c
    refine ⟨ε_c / (2 * lam + 1), div_pos hε_c (by positivity), fun q' hq' hdist => ?_⟩
    rw [Real.dist_eq]
    rw [dist_eq_norm] at hdist
    have hlip := finiteCanonicalLoss_lipschitz hΦ hq' hq y
    have hlt : (2 * lam) * ‖q' - q‖ < (2 * lam + 1) * (ε_c / (2 * lam + 1)) := by
      calc (2 * lam) * ‖q' - q‖
          ≤ (2 * lam + 1) * ‖q' - q‖ :=
            mul_le_mul_of_nonneg_right (by linarith only [hlam]) (norm_nonneg _)
        _ < (2 * lam + 1) * (ε_c / (2 * lam + 1)) :=
            mul_lt_mul_of_pos_left hdist (by positivity)
    have h_cancel : (2 * lam + 1) * (ε_c / (2 * lam + 1)) = ε_c :=
      mul_div_cancel₀ ε_c (by positivity)
    linarith only [hlip, hlt, h_cancel]
  have h_learned_cont : Continuous
      (fun xy : EuclideanSpace ℝ (Fin d) × Fin K => UL.finiteCanonicalLoss Φ (pHat xy.1) xy.2) := by
    rw [continuous_iff_continuousAt]
    intro xy₀
    have hc_y : Continuous (fun xy : EuclideanSpace ℝ (Fin d) × Fin K =>
        UL.finiteCanonicalLoss Φ (pHat xy.1) xy₀.2) :=
      (h_fcl_contOn xy₀.2).comp_continuous (hpHat_cont.comp continuous_fst) (fun xy => hpHat_mem xy.1)
    refine hc_y.continuousAt.congr ?_
    have h_open : IsOpen ((Prod.snd : EuclideanSpace ℝ (Fin d) × Fin K → Fin K) ⁻¹' {xy₀.2}) :=
      (isOpen_discrete ({xy₀.2} : Set (Fin K))).preimage continuous_snd
    filter_upwards [h_open.mem_nhds rfl] with xy hxy
    rw [Set.mem_preimage, Set.mem_singleton_iff] at hxy
    rw [hxy]
  have h_learned_int : MeasureTheory.Integrable
      (fun xy : EuclideanSpace ℝ (Fin d) × Fin K => UL.finiteCanonicalLoss Φ (pHat xy.1) xy.2) ν := by
    let B_fcl : ℝ := (∑ y : Fin K, |UL.finiteCanonicalLoss Φ u y|) + 4 * lam
    refine (MeasureTheory.integrable_const B_fcl).mono' h_learned_cont.aestronglyMeasurable ?_
    refine Filter.Eventually.of_forall fun xy => ?_
    rw [Real.norm_eq_abs]
    have hlip := finiteCanonicalLoss_lipschitz hΦ (hpHat_mem xy.1)
      (UL.Proof_lem_A_5.uniformVec_mem_simplex hK) xy.2
    have hnorm_le2 : ‖pHat xy.1 - u‖ ≤ 2 := by
      calc ‖pHat xy.1 - u‖ ≤ ‖pHat xy.1‖ + ‖u‖ := norm_sub_le _ _
        _ ≤ 1 + 1 := add_le_add (norm_le_one_of_mem_simplex (hpHat_mem xy.1))
            (norm_le_one_of_mem_simplex (UL.Proof_lem_A_5.uniformVec_mem_simplex hK))
        _ = 2 := by norm_num
    have h_y_le : |UL.finiteCanonicalLoss Φ u xy.2| ≤ ∑ y : Fin K, |UL.finiteCanonicalLoss Φ u y| :=
      Finset.single_le_sum (f := fun y => |UL.finiteCanonicalLoss Φ u y|)
        (fun y _ => abs_nonneg _) (Finset.mem_univ xy.2)
    have h_abs : |UL.finiteCanonicalLoss Φ (pHat xy.1) xy.2| ≤
        |UL.finiteCanonicalLoss Φ u xy.2| +
          |UL.finiteCanonicalLoss Φ (pHat xy.1) xy.2 - UL.finiteCanonicalLoss Φ u xy.2| := by
      simpa using norm_add_le (UL.finiteCanonicalLoss Φ u xy.2)
        (UL.finiteCanonicalLoss Φ (pHat xy.1) xy.2 - UL.finiteCanonicalLoss Φ u xy.2)
    dsimp [B_fcl]
    nlinarith only [hlip, hnorm_le2, h_y_le, h_abs, hlam]
  have hpHat_diff_le : ∀ j₁ j₂ : Fin N,
      ‖pHat (x_dict j₁) - pHat (x_dict j₂)‖ ≤
        β * ‖WHat (x_dict j₁) - WHat (x_dict j₂)‖ := by
    intro j₁ j₂
    have hd : pHat (x_dict j₁) - pHat (x_dict j₂) =
        ((projCDef K (aHat + β • WHat (x_dict j₁)) -
          projCDef K (aHat + β • WHat (x_dict j₂)) : UL.ZeroSumSubspace K) :
          EuclideanSpace ℝ (Fin K)) := by
      dsimp [pHat]
      change (u + (projCDef K _ : EuclideanSpace ℝ (Fin K))) -
        (u + (projCDef K _ : EuclideanSpace ℝ (Fin K))) =
        (projCDef K _ : EuclideanSpace ℝ (Fin K)) - (projCDef K _ : EuclideanSpace ℝ (Fin K))
      abel
    have hn_eq : ‖pHat (x_dict j₁) - pHat (x_dict j₂)‖ =
        ‖projCDef K (aHat + β • WHat (x_dict j₁)) - projCDef K (aHat + β • WHat (x_dict j₂))‖ := by
      rw [hd]; rfl
    rw [hn_eq]
    calc ‖projCDef K (aHat + β • WHat (x_dict j₁)) - projCDef K (aHat + β • WHat (x_dict j₂))‖
        ≤ ‖(aHat + β • WHat (x_dict j₁)) - (aHat + β • WHat (x_dict j₂))‖ :=
          projCDef_nonexpansive hK _ _
      _ = ‖β • (WHat (x_dict j₁) - WHat (x_dict j₂))‖ := by congr 1; rw [smul_sub]; abel
      _ = β * ‖WHat (x_dict j₁) - WHat (x_dict j₂)‖ := by
          rw [norm_smul, Real.norm_of_nonneg hβ.le]
  let WHat_eucl : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin K) :=
    (UL.ZeroSumSubspace K).subtypeL.comp WHat
  have hWHat_eucl : UL.hilbertSchmidtNorm WHat_eucl ≤ R := hWHat
  obtain ⟨c_vec, B_op, hB_op, h_interp_A⟩ :=
    h_contr_eucl h_dir 0 WHat_eucl hR.le (mul_nonneg hlam.le hβ.le) hWHat_eucl
      (fun j => UL.simplexGrad Φ (pHat (x_dict j)))
      (fun j₁ j₂ => by
        rw [zero_add, zero_add]
        calc ‖UL.simplexGrad Φ (pHat (x_dict j₁)) - UL.simplexGrad Φ (pHat (x_dict j₂))‖
            ≤ lam * ‖pHat (x_dict j₁) - pHat (x_dict j₂)‖ :=
              hΦ.2.2.2.2.1 _ (hpHat_mem _) _ (hpHat_mem _)
          _ ≤ lam * (β * ‖WHat (x_dict j₁) - WHat (x_dict j₂)‖) :=
              mul_le_mul_of_nonneg_left (hpHat_diff_le j₁ j₂) hlam.le
          _ = (lam * β) * ‖WHat_eucl (x_dict j₁) - WHat_eucl (x_dict j₂)‖ := by
              rw [mul_assoc]; rfl)
  obtain ⟨b_sc, v_sc, hv_sc, h_interp_h⟩ :=
    h_contr_scalar h_dir 0 WHat hR.le (mul_nonneg hlam.le hβ.le) hWHat
      (fun j => hPhiFun Φ (pHat (x_dict j)))
      (fun j₁ j₂ => by
        rw [zero_add, zero_add]
        calc |hPhiFun Φ (pHat (x_dict j₁)) - hPhiFun Φ (pHat (x_dict j₂))|
            ≤ lam * ‖pHat (x_dict j₁) - pHat (x_dict j₂)‖ :=
              hPhiFun_lipschitz hK hΦ (hpHat_mem _) (hpHat_mem _)
          _ ≤ lam * (β * ‖WHat (x_dict j₁) - WHat (x_dict j₂)‖) :=
              mul_le_mul_of_nonneg_left (hpHat_diff_le j₁ j₂) hlam.le
          _ = (lam * β) * ‖WHat (x_dict j₁) - WHat (x_dict j₂)‖ := (mul_assoc _ _ _).symm)
  have hc_vec_norm : ‖c_vec‖ ≤ M + (lam * β * R) * L := by
    have hN1 := h_dir.1
    let j₀ : Fin N := ⟨0, by omega⟩
    have hj₀ := h_interp_A j₀
    have hc_eq : c_vec = UL.simplexGrad Φ (pHat (x_dict j₀)) - B_op (x_dict j₀) := by
      rw [hj₀]; abel
    rw [hc_eq]
    calc ‖UL.simplexGrad Φ (pHat (x_dict j₀)) - B_op (x_dict j₀)‖
        ≤ ‖UL.simplexGrad Φ (pHat (x_dict j₀))‖ + ‖B_op (x_dict j₀)‖ := norm_sub_le _ _
      _ ≤ M + UL.hilbertSchmidtNorm B_op * ‖x_dict j₀‖ :=
          add_le_add (hΦ.2.2.2.2.2 _ (hpHat_mem _)) (norm_apply_le_hilbertSchmidtNorm B_op _)
      _ ≤ M + ((lam * β) * R) * L :=
          add_le_add le_rfl (mul_le_mul hB_op (hx_dict j₀) (norm_nonneg _) (by positivity))
  let f_hat : EuclideanSpace ℝ (Fin d) × Fin K → ℝ :=
    fun xy => UL.finiteCanonicalLoss Φ (pHat xy.1) xy.2 - UL.matchingPotential Φ 0
  have hf_hat_int : MeasureTheory.Integrable f_hat ν :=
    h_learned_int.sub (MeasureTheory.integrable_const _)
  have h_dev_hat := h_conc b_sc v_sc c_vec B_op f_hat hf_hat_int (fun j y => by
    dsimp [f_hat]
    rw [finiteCanonicalLoss_decomp hΦ (hpHat_mem (x_dict j)) y, h_interp_h j, h_interp_A j])
  have h_int_sub : (∫ xy, f_hat xy ∂ν) =
      (∫ xy, UL.finiteCanonicalLoss Φ (pHat xy.1) xy.2 ∂ν) - UL.matchingPotential Φ 0 := by
    dsimp [f_hat]
    rw [MeasureTheory.integral_sub h_learned_int (MeasureTheory.integrable_const _)]
    simp
  have h_sum_sub : (1 / (n : ℝ)) * (∑ i : Fin n, f_hat (x_samp i, y_samp i)) =
      ((1 / (n : ℝ)) * ∑ i : Fin n, UL.finiteCanonicalLoss Φ (pHat (x_samp i)) (y_samp i)) -
        UL.matchingPotential Φ 0 := by
    dsimp [f_hat]
    rw [Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
    field_simp [hn_pos.ne']
  have h_cancel : (∫ xy, f_hat xy ∂ν) -
      (1 / (n : ℝ)) * (∑ i : Fin n, f_hat (x_samp i, y_samp i)) =
      (∫ xy, UL.finiteCanonicalLoss Φ (pHat xy.1) xy.2 ∂ν) -
        (1 / (n : ℝ)) * ∑ i : Fin n, UL.finiteCanonicalLoss Φ (pHat (x_samp i)) (y_samp i) := by
    rw [h_int_sub, h_sum_sub]; ring
  let D : ℝ := M + L * R + β * lam * L * R
  have h_coeff : L * ‖v_sc‖ + ‖c_vec‖ + L * UL.hilbertSchmidtNorm B_op ≤ 3 * D := by
    have h1 : L * ‖v_sc‖ ≤ L * ((lam * β) * R) := mul_le_mul_of_nonneg_left hv_sc hL.le
    have h2 : L * UL.hilbertSchmidtNorm B_op ≤ L * ((lam * β) * R) :=
      mul_le_mul_of_nonneg_left hB_op hL.le
    have hM_pos : 0 < M := hΦ.2.2.1
    dsimp [D]
    nlinarith only [h1, h2, hc_vec_norm, hL, hR, hM_pos]
  have h_rhs_le : 4 * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ)) *
      (L * ‖v_sc‖ + ‖c_vec‖ + L * UL.hilbertSchmidtNorm B_op) ≤
      12 * D * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ)) := by
    have hmul := mul_le_mul_of_nonneg_left h_coeff
      (show 0 ≤ 4 * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ)) by positivity)
    have halg : 4 * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ)) * (3 * D) =
        12 * D * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ)) := by ring
    linarith only [hmul, halg]
  have h_le_abs := le_abs_self ((∫ xy, f_hat xy ∂ν) -
    (1 / (n : ℝ)) * ∑ i : Fin n, f_hat (x_samp i, y_samp i))
  rw [h_cancel] at h_le_abs h_dev_hat
  exact le_trans h_le_abs (le_trans h_dev_hat (le_trans h_rhs_le h_rate_quarter))

private lemma comparator_integrable_and_lb {d K N : ℕ} (hK : 2 ≤ K)
    {L R β lam M : ℝ} (hR : 0 < R)
    {x_dict : Fin N → EuclideanSpace ℝ (Fin d)}
    (hx_dict : ∀ j : Fin N, ‖x_dict j‖ ≤ L)
    (ν : MeasureTheory.Measure (EuclideanSpace ℝ (Fin d) × Fin K))
    [MeasureTheory.IsProbabilityMeasure ν]
    (h_supp : ∀ᵐ xy ∂ν, xy.1 ∈ Set.range x_dict)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    (V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K)
    (hV : UL.hilbertSchmidtNorm V ≤ R) :
    MeasureTheory.Integrable
      (fun xy : EuclideanSpace ℝ (Fin d) × Fin K =>
        UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2) ν ∧
    UL.matchingPotential Φ 0 - 3 * R * L ≤
      ∫ xy, UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 ∂ν := by
  have h1K : 1 ≤ K := by omega
  have h_ml_cont : Continuous (fun xy : EuclideanSpace ℝ (Fin d) × Fin K =>
      UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2) := by
    rw [continuous_iff_continuousAt]
    intro xy₀
    have hc_pot : Continuous (fun xy : EuclideanSpace ℝ (Fin d) × Fin K =>
        UL.matchingPotential Φ (V xy.1 : EuclideanSpace ℝ (Fin K))) :=
      (UL.Proof_lem_A_6.matchingPotential_continuous h1K hΦ.1.2.1).comp
        (continuous_subtype_val.comp (V.continuous.comp continuous_fst))
    have hc_coord : Continuous (fun xy : EuclideanSpace ℝ (Fin d) × Fin K =>
        (V xy.1 : EuclideanSpace ℝ (Fin K)) xy₀.2) :=
      (PiLp.continuous_apply 2 (fun _ : Fin K => ℝ) xy₀.2).comp
        (continuous_subtype_val.comp (V.continuous.comp continuous_fst))
    refine (hc_pot.sub hc_coord).continuousAt.congr ?_
    have h_open : IsOpen ((Prod.snd : EuclideanSpace ℝ (Fin d) × Fin K → Fin K) ⁻¹' {xy₀.2}) :=
      (isOpen_discrete ({xy₀.2} : Set (Fin K))).preimage continuous_snd
    filter_upwards [h_open.mem_nhds rfl] with xy hxy
    rw [Set.mem_preimage, Set.mem_singleton_iff] at hxy
    dsimp [UL.matchingLoss]; rw [hxy]
  have h_ae_bdd : ∀ᵐ xy ∂ν,
      |UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 - UL.matchingPotential Φ 0| ≤
        3 * R * L := by
    filter_upwards [h_supp] with xy hxy
    rcases hxy with ⟨j, hj⟩
    rw [← hj]
    have hVx : ‖(V (x_dict j) : EuclideanSpace ℝ (Fin K))‖ ≤ R * L := by
      calc ‖V (x_dict j)‖
          ≤ UL.hilbertSchmidtNorm V * ‖x_dict j‖ := norm_apply_le_hilbertSchmidtNorm V _
        _ ≤ R * L := mul_le_mul hV (hx_dict j) (norm_nonneg _) hR.le
    have hpot := UL.Proof_lem_A_6.matchingPotential_lipschitz_bound h1K hΦ.1.2.1
      (V (x_dict j) : EuclideanSpace ℝ (Fin K)) 0
    rw [sub_zero] at hpot
    have hcoord : |(V (x_dict j) : EuclideanSpace ℝ (Fin K)) xy.2| ≤ R * L :=
      le_trans (coord_abs_le_norm _ _) hVx
    unfold UL.matchingLoss
    have hsplit : (UL.matchingPotential Φ (V (x_dict j) : EuclideanSpace ℝ (Fin K)) -
        (V (x_dict j) : EuclideanSpace ℝ (Fin K)) xy.2) - UL.matchingPotential Φ 0 =
        (UL.matchingPotential Φ (V (x_dict j) : EuclideanSpace ℝ (Fin K)) -
          UL.matchingPotential Φ 0) -
          (V (x_dict j) : EuclideanSpace ℝ (Fin K)) xy.2 := by ring
    rw [hsplit]
    have htri : |(UL.matchingPotential Φ (V (x_dict j) : EuclideanSpace ℝ (Fin K)) -
          UL.matchingPotential Φ 0) -
          (V (x_dict j) : EuclideanSpace ℝ (Fin K)) xy.2| ≤
        |UL.matchingPotential Φ (V (x_dict j) : EuclideanSpace ℝ (Fin K)) -
          UL.matchingPotential Φ 0| +
          |(V (x_dict j) : EuclideanSpace ℝ (Fin K)) xy.2| := by
      simpa using norm_sub_le
        (UL.matchingPotential Φ (V (x_dict j) : EuclideanSpace ℝ (Fin K)) -
          UL.matchingPotential Φ 0)
        ((V (x_dict j) : EuclideanSpace ℝ (Fin K)) xy.2)
    linarith only [hVx, hpot, hcoord, htri]
  have h_int : MeasureTheory.Integrable
      (fun xy : EuclideanSpace ℝ (Fin d) × Fin K =>
        UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2) ν := by
    refine (MeasureTheory.integrable_const (|UL.matchingPotential Φ 0| + 3 * R * L)).mono'
      h_ml_cont.aestronglyMeasurable ?_
    filter_upwards [h_ae_bdd] with xy hxy
    rw [Real.norm_eq_abs]
    have htri : |UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2| ≤
        |UL.matchingPotential Φ 0| +
          |UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 -
            UL.matchingPotential Φ 0| := by
      simpa using norm_add_le (UL.matchingPotential Φ 0)
        (UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 - UL.matchingPotential Φ 0)
    linarith only [hxy, htri]
  refine ⟨h_int, ?_⟩
  have h_ae_low : ∀ᵐ xy ∂ν,
      UL.matchingPotential Φ 0 - 3 * R * L ≤
        UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 := by
    filter_upwards [h_ae_bdd] with xy hxy
    have hlow := (abs_le.mp hxy).1
    linarith only [hlow]
  have h_int_mono := MeasureTheory.integral_mono_ae
    (MeasureTheory.integrable_const (UL.matchingPotential Φ 0 - 3 * R * L)) h_int h_ae_low
  simpa using h_int_mono

private lemma comparator_stat_transfer
    (h_contr_scalar : ∀ {N d K : ℕ} {x_dict : Fin N → EuclideanSpace ℝ (Fin d)},
      UL.DirichletFeatureCondition x_dict →
      ∀ (b₀ : UL.ZeroSumSubspace K)
        (A₀ : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K)
        {Q C : ℝ}, 0 ≤ Q → 0 ≤ C → UL.hilbertSchmidtNorm A₀ ≤ Q →
        ∀ (t : Fin N → ℝ),
        (∀ i j : Fin N, |t i - t j| ≤ C * ‖(b₀ + A₀ (x_dict i)) - (b₀ + A₀ (x_dict j))‖) →
        ∃ (b : ℝ) (v : EuclideanSpace ℝ (Fin d)),
          ‖v‖ ≤ C * Q ∧ ∀ i : Fin N, t i = b + inner ℝ v (x_dict i))
    {n d K N : ℕ} (hn : 1 ≤ n) (hK : 2 ≤ K)
    {L R β lam M ε δ : ℝ}
    (hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) (hlam : 0 < lam)
    (h_rate_quarter :
      12 * (M + L * R + β * lam * L * R) * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ)) ≤ ε / 4)
    {x_dict : Fin N → EuclideanSpace ℝ (Fin d)}
    (h_dir : UL.DirichletFeatureCondition x_dict)
    (ν : MeasureTheory.Measure (EuclideanSpace ℝ (Fin d) × Fin K))
    [MeasureTheory.IsProbabilityMeasure ν]
    (x_samp : Fin n → EuclideanSpace ℝ (Fin d))
    (y_samp : Fin n → Fin K)
    (h_conc : ∀ (b : ℝ) (v : EuclideanSpace ℝ (Fin d))
       (c_vec : EuclideanSpace ℝ (Fin K))
       (B : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin K))
       (f : EuclideanSpace ℝ (Fin d) × Fin K → ℝ),
       MeasureTheory.Integrable f ν →
       (∀ j : Fin N, ∀ y : Fin K,
         f (x_dict j, y) =
           b + inner ℝ v (x_dict j) -
             inner ℝ (EuclideanSpace.single y (1 : ℝ) - UL.uniformVec K)
               (c_vec + B (x_dict j))) →
       |(∫ xy, f xy ∂ν) - (1 / (n : ℝ)) * ∑ i : Fin n, f (x_samp i, y_samp i)| ≤
         4 * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ)) *
           (L * ‖v‖ + ‖c_vec‖ + L * UL.hilbertSchmidtNorm B))
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    (V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K)
    (hV : UL.hilbertSchmidtNorm V ≤ R)
    (hV_int : MeasureTheory.Integrable
      (fun xy : EuclideanSpace ℝ (Fin d) × Fin K =>
        UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2) ν) :
    (1 / (n : ℝ)) * (∑ i : Fin n, UL.matchingLoss Φ (V (x_samp i) : EuclideanSpace ℝ (Fin K)) (y_samp i)) -
      (∫ xy, UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 ∂ν) ≤ ε / 4 := by
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  have h1K : 1 ≤ K := by omega
  obtain ⟨b_c, v_c, hv_c, h_interp_c⟩ :=
    h_contr_scalar h_dir 0 V hR.le (by norm_num : (0 : ℝ) ≤ 2) hV
      (fun j => UL.matchingPotential Φ (V (x_dict j) : EuclideanSpace ℝ (Fin K)) -
        UL.matchingPotential Φ 0)
      (fun j₁ j₂ => by
        have hlip := UL.Proof_lem_A_6.matchingPotential_lipschitz_bound h1K hΦ.1.2.1
          (V (x_dict j₁) : EuclideanSpace ℝ (Fin K)) (V (x_dict j₂) : EuclideanSpace ℝ (Fin K))
        simpa [zero_add] using hlip)
  let B_V : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin K) :=
    (UL.ZeroSumSubspace K).subtypeL.comp V
  have hBV_norm : UL.hilbertSchmidtNorm B_V ≤ R := hV
  let f_V : EuclideanSpace ℝ (Fin d) × Fin K → ℝ :=
    fun xy => UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 - UL.matchingPotential Φ 0
  have hf_V_int : MeasureTheory.Integrable f_V ν :=
    hV_int.sub (MeasureTheory.integrable_const _)
  have h_dev_V := h_conc b_c v_c 0 B_V f_V hf_V_int (fun j y => by
    dsimp [f_V, B_V]
    rw [matchingLoss_decomp Φ (V (x_dict j)) y, h_interp_c j, zero_add])
  have h_int_sub : (∫ xy, f_V xy ∂ν) =
      (∫ xy, UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 ∂ν) -
        UL.matchingPotential Φ 0 := by
    dsimp [f_V]
    rw [MeasureTheory.integral_sub hV_int (MeasureTheory.integrable_const _)]
    simp
  have h_sum_sub : (1 / (n : ℝ)) * (∑ i : Fin n, f_V (x_samp i, y_samp i)) =
      ((1 / (n : ℝ)) * ∑ i : Fin n,
        UL.matchingLoss Φ (V (x_samp i) : EuclideanSpace ℝ (Fin K)) (y_samp i)) -
        UL.matchingPotential Φ 0 := by
    dsimp [f_V]
    rw [Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
    field_simp [hn_pos.ne']
  have h_cancel : (1 / (n : ℝ)) * (∑ i : Fin n, f_V (x_samp i, y_samp i)) -
      (∫ xy, f_V xy ∂ν) =
      ((1 / (n : ℝ)) * ∑ i : Fin n,
        UL.matchingLoss Φ (V (x_samp i) : EuclideanSpace ℝ (Fin K)) (y_samp i)) -
        (∫ xy, UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 ∂ν) := by
    rw [h_int_sub, h_sum_sub]; ring
  let D : ℝ := M + L * R + β * lam * L * R
  have h_coeff : L * ‖v_c‖ + ‖(0 : EuclideanSpace ℝ (Fin K))‖ + L * UL.hilbertSchmidtNorm B_V ≤
      3 * D := by
    rw [norm_zero, add_zero]
    have h1 : L * ‖v_c‖ ≤ L * (2 * R) := mul_le_mul_of_nonneg_left hv_c hL.le
    have h2 : L * UL.hilbertSchmidtNorm B_V ≤ L * R := mul_le_mul_of_nonneg_left hBV_norm hL.le
    have hM_pos : 0 < M := hΦ.2.2.1
    have h4 : 0 ≤ β * lam * L * R := by positivity
    have h_alg : 3 * D - (L * (2 * R) + L * R) = 3 * M + 3 * (β * lam * L * R) := by
      dsimp [D]; ring
    linarith only [h1, h2, hM_pos, h4, h_alg]
  have h_rhs_le : 4 * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ)) *
      (L * ‖v_c‖ + ‖(0 : EuclideanSpace ℝ (Fin K))‖ + L * UL.hilbertSchmidtNorm B_V) ≤
      12 * D * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ)) := by
    have hmul := mul_le_mul_of_nonneg_left h_coeff
      (show 0 ≤ 4 * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ)) by positivity)
    have halg : 4 * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ)) * (3 * D) =
        12 * D * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ)) := by ring
    linarith only [hmul, halg]
  have h_le_abs : (1 / (n : ℝ)) * (∑ i : Fin n, f_V (x_samp i, y_samp i)) -
      (∫ xy, f_V xy ∂ν) ≤
      |(∫ xy, f_V xy ∂ν) - (1 / (n : ℝ)) * ∑ i : Fin n, f_V (x_samp i, y_samp i)| := by
    rw [abs_sub_comm]; exact le_abs_self _
  rw [h_cancel] at h_le_abs
  exact le_trans h_le_abs (le_trans h_dev_V (le_trans h_rhs_le h_rate_quarter))

theorem population_omniprediction_core
    (h_contr_eucl : ∀ {N d m₁ m₂ : ℕ} {x_dict : Fin N → EuclideanSpace ℝ (Fin d)},
      UL.DirichletFeatureCondition x_dict →
      ∀ (b₀ : EuclideanSpace ℝ (Fin m₁))
        (A₀ : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin m₁))
        {Q C : ℝ}, 0 ≤ Q → 0 ≤ C → UL.hilbertSchmidtNorm A₀ ≤ Q →
        ∀ (t : Fin N → EuclideanSpace ℝ (Fin m₂)),
        (∀ i j : Fin N, ‖t i - t j‖ ≤ C * ‖(b₀ + A₀ (x_dict i)) - (b₀ + A₀ (x_dict j))‖) →
        ∃ (b : EuclideanSpace ℝ (Fin m₂))
          (A : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin m₂)),
          UL.hilbertSchmidtNorm A ≤ C * Q ∧ ∀ i : Fin N, t i = b + A (x_dict i))
    (h_contr_zeroSum : ∀ {N d K : ℕ} {x_dict : Fin N → EuclideanSpace ℝ (Fin d)},
      UL.DirichletFeatureCondition x_dict →
      ∀ (b₀ : UL.ZeroSumSubspace K)
        (A₀ : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K)
        {Q C : ℝ}, 0 ≤ Q → 0 ≤ C → UL.hilbertSchmidtNorm A₀ ≤ Q →
        ∀ (t : Fin N → UL.ZeroSumSubspace K),
        (∀ i j : Fin N, ‖t i - t j‖ ≤ C * ‖(b₀ + A₀ (x_dict i)) - (b₀ + A₀ (x_dict j))‖) →
        ∃ (b : UL.ZeroSumSubspace K)
          (A : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K),
          UL.hilbertSchmidtNorm A ≤ C * Q ∧ ∀ i : Fin N, t i = b + A (x_dict i))
    (h_contr_scalar : ∀ {N d K : ℕ} {x_dict : Fin N → EuclideanSpace ℝ (Fin d)},
      UL.DirichletFeatureCondition x_dict →
      ∀ (b₀ : UL.ZeroSumSubspace K)
        (A₀ : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K)
        {Q C : ℝ}, 0 ≤ Q → 0 ≤ C → UL.hilbertSchmidtNorm A₀ ≤ Q →
        ∀ (t : Fin N → ℝ),
        (∀ i j : Fin N, |t i - t j| ≤ C * ‖(b₀ + A₀ (x_dict i)) - (b₀ + A₀ (x_dict j))‖) →
        ∃ (b : ℝ) (v : EuclideanSpace ℝ (Fin d)),
          ‖v‖ ≤ C * Q ∧ ∀ i : Fin N, t i = b + inner ℝ v (x_dict i))
    {n d K N : ℕ} (hn : 1 ≤ n) (hK : 2 ≤ K)
    {L R β lam M ε δ : ℝ}
    (hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) (hlam : 0 < lam) (hM : 0 < M)
    (hε : 0 < ε) (hδ0 : 0 < δ) (hδ1 : δ < (1 : ℝ) / 2)
    (hn_samples :
      (n : ℝ) ≥ 4096 * ((M + L * R + β * lam * L * R) ^ 2 / ε ^ 2) * Real.log ((2 : ℝ) / δ))
    {x_dict : Fin N → EuclideanSpace ℝ (Fin d)}
    (h_dir : UL.DirichletFeatureCondition x_dict)
    (hx_dict : ∀ j : Fin N, ‖x_dict j‖ ≤ L)
    (ν : MeasureTheory.Measure (EuclideanSpace ℝ (Fin d) × Fin K))
    [MeasureTheory.IsProbabilityMeasure ν]
    (h_supp : ∀ᵐ xy ∂ν, xy.1 ∈ Set.range x_dict)
    (x_samp : Fin n → EuclideanSpace ℝ (Fin d))
    (y_samp : Fin n → Fin K)
    (hx_mem_dict : ∀ i : Fin n, x_samp i ∈ Set.range x_dict)
    (h_conc : ∀ (b : ℝ) (v : EuclideanSpace ℝ (Fin d))
       (c_vec : EuclideanSpace ℝ (Fin K))
       (B : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin K))
       (f : EuclideanSpace ℝ (Fin d) × Fin K → ℝ),
       MeasureTheory.Integrable f ν →
       (∀ j : Fin N, ∀ y : Fin K,
         f (x_dict j, y) =
           b + inner ℝ v (x_dict j) -
             inner ℝ (EuclideanSpace.single y (1 : ℝ) - UL.uniformVec K)
               (c_vec + B (x_dict j))) →
       |(∫ xy, f xy ∂ν) - (1 / (n : ℝ)) * ∑ i : Fin n, f (x_samp i, y_samp i)| ≤
         4 * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ)) *
           (L * ‖v‖ + ‖c_vec‖ + L * UL.hilbertSchmidtNorm B))
    {aHat : UL.ZeroSumSubspace K}
    {WHat : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K}
    (hWHat : UL.hilbertSchmidtNorm WHat ≤ R)
    (h_opt : ∀ (a : UL.ZeroSumSubspace K)
       (W : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K),
       UL.hilbertSchmidtNorm W ≤ R →
       (1 / (2 * (n : ℝ))) * ∑ i : Fin n,
           ‖((aHat + β • WHat (x_samp i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) -
             (EuclideanSpace.single (y_samp i) (1 : ℝ) - UL.uniformVec K)‖ ^ 2 ≤
         (1 / (2 * (n : ℝ))) * ∑ i : Fin n,
           ‖((a + β • W (x_samp i) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) -
             (EuclideanSpace.single (y_samp i) (1 : ℝ) - UL.uniformVec K)‖ ^ 2 +
           ε ^ 2 / (32 * lam ^ 2)) :
    let pHat : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin K) :=
      fun x => UL.uniformVec K + (projCDef K (aHat + β • WHat x) : EuclideanSpace ℝ (Fin K))
    ∀ Φ ∈ UL.SmoothEntropyFamily K β lam M,
      (∫ xy, UL.finiteCanonicalLoss Φ (pHat xy.1) xy.2 ∂ν) ≤
        sInf ((fun V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K =>
          ∫ xy, UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 ∂ν) ''
          {V | UL.hilbertSchmidtNorm V ≤ R}) + ε := by
  intro pHat Φ hΦ
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  let D : ℝ := M + L * R + β * lam * L * R
  have hD_pos : 0 < D := by dsimp [D]; positivity
  have h_log_pos : 0 < Real.log ((2 : ℝ) / δ) :=
    Real.log_pos ((one_lt_div hδ0).mpr (by linarith only [hδ1]))
  have h_rate_quarter : 12 * D * Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ)) ≤ ε / 4 := by
    have h_div : Real.log ((2 : ℝ) / δ) / (n : ℝ) ≤ (ε / (64 * D)) ^ 2 := by
      rw [div_le_iff₀ hn_pos]
      have hsq : (ε / (64 * D)) ^ 2 * (4096 * (D ^ 2 / ε ^ 2) * Real.log ((2 : ℝ) / δ)) =
          Real.log ((2 : ℝ) / δ) := by
        field_simp [hD_pos.ne', hε.ne']; ring
      have hmul := mul_le_mul_of_nonneg_left hn_samples (sq_nonneg (ε / (64 * D)))
      linarith only [hsq, hmul]
    have h_sqrt : Real.sqrt (Real.log ((2 : ℝ) / δ) / (n : ℝ)) ≤ ε / (64 * D) :=
      le_trans (Real.sqrt_le_sqrt h_div) (Real.sqrt_sq (by positivity)).le
    have hmul := mul_le_mul_of_nonneg_left h_sqrt (show (0 : ℝ) ≤ 12 * D by positivity)
    have h_alg : 12 * D * (ε / (64 * D)) = (3 / 16 : ℝ) * ε := by
      field_simp [hD_pos.ne']; ring
    linarith only [hmul, h_alg, hε]
  have h_dev_hat_quarter := learned_forecast_stat_transfer h_contr_eucl h_contr_scalar hn hK
    hL hR hβ hlam h_rate_quarter h_dir hx_dict ν x_samp y_samp h_conc (aHat := aHat) hWHat hΦ
  dsimp only at h_dev_hat_quarter
  let S_comp := (fun V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K =>
    ∫ xy, UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 ∂ν) ''
    {V | UL.hilbertSchmidtNorm V ≤ R}
  have hS_ne : S_comp.Nonempty :=
    ⟨_, ⟨0, by change UL.hilbertSchmidtNorm _ ≤ R; rw [hilbertSchmidtNorm_zero]; exact hR.le, rfl⟩⟩
  suffices h_le_inf :
      (∫ xy, UL.finiteCanonicalLoss Φ (pHat xy.1) xy.2 ∂ν) - ε ≤ sInf S_comp by
    dsimp [S_comp] at h_le_inf
    linarith only [h_le_inf]
  refine le_csInf hS_ne ?_
  rintro _ ⟨V, hV, rfl⟩
  have hV_int := (comparator_integrable_and_lb hK hR hx_dict ν h_supp hΦ V hV).1
  have h_dev_V_quarter := comparator_stat_transfer h_contr_scalar hn hK hL hR hβ hlam
    h_rate_quarter h_dir ν x_samp y_samp h_conc hΦ V hV hV_int
  have h_emp_approx := empirical_approx_omniprediction h_contr_zeroSum hn hK hR hβ hlam hM hε
    h_dir x_samp y_samp hx_mem_dict hWHat h_opt hΦ hV
  dsimp only at h_emp_approx
  linarith only [h_dev_hat_quarter, h_dev_V_quarter, h_emp_approx]

end UL.Proof_thm_7_1_Race2

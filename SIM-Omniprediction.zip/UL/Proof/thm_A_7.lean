import UL.Stmt.thm_A_7
import UL.Stmt.cit_brouwer
import UL.Stmt.lem_A_2
import UL.Stmt.lem_A_3
import UL.Stmt.lem_A_6
import UL.Proof.thm_A_7.H1_Law
import UL.Proof.thm_A_7.H2_FixedPoint
import UL.Proof.thm_A_7.H3_Factorization
set_option autoImplicit false

namespace UL

open MeasureTheory
open UL.Proof_thm_A_7

private lemma risk_bounds_of_profile.{u₂, u₄, u}
    (h_lem_A_6 : S_lem_A_6.{u₄})
    {Ω : Type u} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    {d K : ℕ} (hK : 1 ≤ K) {β : ℝ} (hβ : 0 < β)
    {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin K}
    (hX : Measurable X) (hY : Measurable Y)
    (hX_int : Integrable (fun ω => ‖X ω‖) μ)
    {𝒲 : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)}
    (h𝒲 : IsCompactConvexScoreSet 𝒲)
    {W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K} (hW : W ∈ 𝒲)
    {ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hρ_prof₂ : IsLipschitzLSFitProfile (lawMeas.{u₂, u} μ X Y) β
      (linearScore W (@lawX.{u₂} d K)) (@lawY.{u₂} d K) ρ)
    (hle_gap : ∀ V ∈ 𝒲,
      ∫ ω, inner ℝ (ρ (W (X ω)) - oneHotLabel Y ω)
        (((W - V) (X ω)) : EuclideanSpace ℝ (Fin K)) ∂μ ≤ 0)
    {Φ : Simplex K → ℝ} (hΦ : Φ ∈ EntropyFamily K β) :
    (∀ᵐ ω ∂μ, extendedCanonicalLoss Φ (ρ (W (X ω))) (Y ω) ≠ ⊤) ∧
    Integrable (fun ω => (extendedCanonicalLoss Φ (ρ (W (X ω))) (Y ω)).toReal) μ ∧
    (∀ V ∈ 𝒲, Integrable (fun ω => matchingLoss Φ (V (X ω)) (Y ω)) μ) ∧
    BddBelow ((fun V => ∫ ω, matchingLoss Φ (V (X ω)) (Y ω) ∂μ) '' 𝒲) ∧
    (∫ ω, (extendedCanonicalLoss Φ (ρ (W (X ω))) (Y ω)).toReal ∂μ) ≤
      sInf ((fun V => ∫ ω, matchingLoss Φ (V (X ω)) (Y ω) ∂μ) '' 𝒲) := by
  let μ₄ : Measure (LawSpace.{u₄} d K) := lawMeas.{u₄, u} μ X Y
  haveI : IsProbabilityMeasure μ₄ := isProbabilityMeasure_lawMeas.{u₄, u} μ hX hY
  have hf₄_aem : AEMeasurable (lawMap.{u₄, u} X Y) μ :=
    (measurable_lawMap.{u₄, u} hX hY).aemeasurable
  have hX₄ : Measurable (@lawX.{u₄} d K) := measurable_lawX.{u₄} d K
  have hY₄ : Measurable (@lawY.{u₄} d K) := measurable_lawY.{u₄} d K
  have hX₄_int : Integrable (fun z : LawSpace.{u₄} d K => ‖lawX.{u₄} z‖) μ₄ :=
    integrable_norm_lawX.{u₄, u} hX hY hX_int
  have hρ_prof₄ : IsLipschitzLSFitProfile μ₄ β
      (linearScore W (@lawX.{u₄} d K)) (@lawY.{u₄} d K) ρ :=
    (isLipschitzLSFitProfile_lawMeas_iff.{u₂, u₄, u} hX hY W ρ).mp hρ_prof₂
  have hP₄_ae : linearFittedPrediction μ₄ β W (@lawX.{u₄} d K) (@lawY.{u₄} d K) =ᵐ[μ₄]
      fun z => ρ (W (lawX.{u₄} z)) :=
    linearFittedPrediction_ae_eq_of_profile hX₄ hY₄ hρ_prof₄
  have hGap0 : certificateGap μ₄ β 𝒲 (@lawX.{u₄} d K) (@lawY.{u₄} d K) W = 0 :=
    certificateGap_lawMeas_eq_zero.{u₄, u} hX hY hW hρ_prof₄ hle_gap
  obtain ⟨h_ne_top₄, h_int_can₄, _, _, _⟩ :=
    h_lem_A_6 (LawSpace.{u₄} d K) μ₄ d K hK β β hβ (le_refl β)
      (@lawX.{u₄} d K) (@lawY.{u₄} d K) hX₄ hY₄ hX₄_int 𝒲 h𝒲 W W hW hW Φ hΦ
  have h_ne_top₄' : ∀ᵐ z ∂μ₄,
      extendedCanonicalLoss Φ (ρ (W (lawX.{u₄} z))) (lawY.{u₄} z) ≠ ⊤ := by
    filter_upwards [h_ne_top₄, hP₄_ae] with z hz hPz
    rwa [← hPz]
  have h_ne_top : ∀ᵐ ω ∂μ, extendedCanonicalLoss Φ (ρ (W (X ω))) (Y ω) ≠ ⊤ := by
    have hset_eq : {z : LawSpace.{u₄} d K |
        extendedCanonicalLoss Φ (ρ (W (lawX.{u₄} z))) (lawY.{u₄} z) ≠ ⊤} =
        {z : LawSpace.{u₄} d K | 0 < ρ (W (lawX.{u₄} z)) (lawY.{u₄} z)} := by
      ext z
      exact extendedCanonicalLoss_ne_top_iff Φ (ρ (W (lawX.{u₄} z))) (lawY.{u₄} z)
    have hmeas_set : MeasurableSet {z : LawSpace.{u₄} d K |
        extendedCanonicalLoss Φ (ρ (W (lawX.{u₄} z))) (lawY.{u₄} z) ≠ ⊤} := by
      rw [hset_eq]
      have hp_meas : Measurable (fun z : LawSpace.{u₄} d K => ρ (W (lawX.{u₄} z))) :=
        hρ_prof₄.2.1.2.1.continuous.measurable.comp (W.continuous.measurable.comp hX₄)
      exact measurableSet_lt measurable_const (measurable_eval_fin hp_meas hY₄)
    exact (ae_map_iff hf₄_aem hmeas_set).mp h_ne_top₄'
  let g_can : LawSpace.{u₄} d K → ℝ :=
    fun z => (extendedCanonicalLoss Φ (ρ (W (lawX.{u₄} z))) (lawY.{u₄} z)).toReal
  have h_int_can₄' : Integrable g_can μ₄ := by
    refine h_int_can₄.congr ?_
    filter_upwards [hP₄_ae] with z hPz
    dsimp [g_can]
    rw [hPz]
  have h_int_can : Integrable
      (fun ω => (extendedCanonicalLoss Φ (ρ (W (X ω))) (Y ω)).toReal) μ :=
    (integrable_map_measure h_int_can₄'.aestronglyMeasurable hf₄_aem).mp h_int_can₄'
  have h_eq_can : ∫ z, g_can z ∂μ₄ =
      ∫ ω, (extendedCanonicalLoss Φ (ρ (W (X ω))) (Y ω)).toReal ∂μ := by
    change ∫ z, g_can z ∂(μ.map (lawMap.{u₄, u} X Y)) = _
    rw [integral_map hf₄_aem h_int_can₄'.aestronglyMeasurable]
    rfl
  have hV_prop : ∀ V ∈ 𝒲,
      Integrable (fun ω => matchingLoss Φ (V (X ω)) (Y ω)) μ ∧
      (∫ ω, (extendedCanonicalLoss Φ (ρ (W (X ω))) (Y ω)).toReal ∂μ) ≤
        ∫ ω, matchingLoss Φ (V (X ω)) (Y ω) ∂μ := by
    intro V hV
    obtain ⟨_, _, h_int_mat₄, h_le1, h_le2⟩ :=
      h_lem_A_6 (LawSpace.{u₄} d K) μ₄ d K hK β β hβ (le_refl β)
        (@lawX.{u₄} d K) (@lawY.{u₄} d K) hX₄ hY₄ hX₄_int 𝒲 h𝒲 W V hW hV Φ hΦ
    let g_mat : LawSpace.{u₄} d K → ℝ :=
      fun z => matchingLoss Φ (V (lawX.{u₄} z)) (lawY.{u₄} z)
    have h_int_mat₄' : Integrable g_mat μ₄ := h_int_mat₄
    have h_int_mat : Integrable (fun ω => matchingLoss Φ (V (X ω)) (Y ω)) μ :=
      (integrable_map_measure h_int_mat₄'.aestronglyMeasurable hf₄_aem).mp h_int_mat₄'
    have h_eq_mat : ∫ z, g_mat z ∂μ₄ = ∫ ω, matchingLoss Φ (V (X ω)) (Y ω) ∂μ := by
      change ∫ z, g_mat z ∂(μ.map (lawMap.{u₄, u} X Y)) = _
      rw [integral_map hf₄_aem h_int_mat₄'.aestronglyMeasurable]
      rfl
    have h_congr_can : ∫ z, (extendedCanonicalLoss Φ
          (linearFittedPrediction μ₄ β W (@lawX.{u₄} d K) (@lawY.{u₄} d K) z)
          (lawY.{u₄} z)).toReal ∂μ₄ = ∫ z, g_can z ∂μ₄ := by
      refine integral_congr_ae ?_
      filter_upwards [hP₄_ae] with z hPz
      dsimp [g_can]
      rw [hPz]
    have h_le12 := le_trans h_le1 h_le2
    rw [h_congr_can, h_eq_can, hGap0] at h_le12
    change (∫ ω, (extendedCanonicalLoss Φ (ρ (W (X ω))) (Y ω)).toReal ∂μ) -
        ∫ z, g_mat z ∂μ₄ ≤ 0 - _ at h_le12
    rw [h_eq_mat] at h_le12
    have h_nonneg : 0 ≤ (1 / (2 * β)) * ∫ z,
        ‖linearFittedPrediction μ₄ β W (@lawX.{u₄} d K) (@lawY.{u₄} d K) z -
          (uniformVec K +
            ((gradient (fun s : ZeroSumSubspace K => matchingPotential Φ s)
              (V (lawX.{u₄} z)) : ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)))‖ ^ 2 ∂μ₄ :=
      mul_nonneg (by positivity) (integral_nonneg fun _ => sq_nonneg _)
    refine ⟨h_int_mat, by linarith⟩
  refine ⟨h_ne_top, h_int_can, fun V hV => (hV_prop V hV).1, ?_, ?_⟩
  · refine ⟨∫ ω, (extendedCanonicalLoss Φ (ρ (W (X ω))) (Y ω)).toReal ∂μ, ?_⟩
    rintro _ ⟨V, hV, rfl⟩
    exact (hV_prop V hV).2
  · refine le_csInf (h𝒲.1.image _) ?_
    rintro _ ⟨V, hV, rfl⟩
    exact (hV_prop V hV).2

private lemma support_exclusion_of_profile.{u₂, u₃, u}
    (h_lem_A_3 : S_lem_A_3.{u₃})
    {Ω : Type u} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    {d K : ℕ} (hK : 1 ≤ K) {β : ℝ} (hβ : 0 < β)
    {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin K}
    (hX : Measurable X) (hY : Measurable Y)
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
    {ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hρ_prof₂ : IsLipschitzLSFitProfile (lawMeas.{u₂, u} μ X Y) β
      (linearScore W (@lawX.{u₂} d K)) (@lawY.{u₂} d K) ρ)
    (j : Fin K) :
    ∀ᵐ ω ∂μ, ρ (W (X ω)) j = 0 → Y ω ≠ j := by
  by_cases hK1 : K = 1
  · refine Filter.Eventually.of_forall (fun ω h0 => ?_)
    have h1 : ρ (W (X ω)) j = 1 :=
      simplex_apply_eq_one_of_eq_one hK1 (hρ_prof₂.2.1.2.2 (W (X ω))) j
    linarith
  · have hK2 : 2 ≤ K := by omega
    let μ₃ : Measure (LawSpace.{u₃} d K) := lawMeas.{u₃, u} μ X Y
    haveI : IsProbabilityMeasure μ₃ := isProbabilityMeasure_lawMeas.{u₃, u} μ hX hY
    have hf₃_aem : AEMeasurable (lawMap.{u₃, u} X Y) μ :=
      (measurable_lawMap.{u₃, u} hX hY).aemeasurable
    have hX₃ : Measurable (@lawX.{u₃} d K) := measurable_lawX.{u₃} d K
    have hY₃ : Measurable (@lawY.{u₃} d K) := measurable_lawY.{u₃} d K
    have hρ_prof₃ : IsLipschitzLSFitProfile μ₃ β
        (linearScore W (@lawX.{u₃} d K)) (@lawY.{u₃} d K) ρ :=
      (isLipschitzLSFitProfile_lawMeas_iff.{u₂, u₃, u} hX hY W ρ).mp hρ_prof₂
    have hS₃ : Measurable (linearScore W (@lawX.{u₃} d K)) :=
      W.continuous.measurable.comp hX₃
    have hFit₃ : IsLipschitzLSFit μ₃ β
        (linearScore W (@lawX.{u₃} d K)) (@lawY.{u₃} d K)
        (fun z => ρ (W (lawX.{u₃} z))) :=
      ⟨ρ, hρ_prof₃, rfl⟩
    have h_supp₃ :=
      (h_lem_A_3 (LawSpace.{u₃} d K) μ₃ K hK2 β hβ
        (linearScore W (@lawX.{u₃} d K)) (@lawY.{u₃} d K)
        hS₃ hY₃ (fun z => ρ (W (lawX.{u₃} z))) hFit₃).1 j
    have h_imp₃ : ∀ᵐ z ∂μ₃, ρ (W (lawX.{u₃} z)) j = 0 → lawY.{u₃} z ≠ j := by
      filter_upwards [h_supp₃] with z hz h0 hy
      have hz0 : oneHotLabel (@lawY.{u₃} d K) z j = 0 := hz h0
      have hz1 : oneHotLabel (@lawY.{u₃} d K) z j = 1 := by
        simp [oneHotLabel, oneHotVec, hy, EuclideanSpace.single_apply]
      linarith
    have hmeas_imp : MeasurableSet
        {z : LawSpace.{u₃} d K | ρ (W (lawX.{u₃} z)) j = 0 → lawY.{u₃} z ≠ j} := by
      have heq_set : {z : LawSpace.{u₃} d K | ρ (W (lawX.{u₃} z)) j = 0 → lawY.{u₃} z ≠ j} =
          {z : LawSpace.{u₃} d K | ρ (W (lawX.{u₃} z)) j = 0}ᶜ ∪
            {z : LawSpace.{u₃} d K | lawY.{u₃} z = j}ᶜ := by
        ext z
        simp [imp_iff_not_or]
      rw [heq_set]
      have hm1 : MeasurableSet {z : LawSpace.{u₃} d K | ρ (W (lawX.{u₃} z)) j = 0} :=
        measurableSet_eq_fun
          ((EuclideanSpace.proj j).continuous.measurable.comp
            (hρ_prof₃.2.1.2.1.continuous.measurable.comp hS₃))
          measurable_const
      have hm2 : MeasurableSet {z : LawSpace.{u₃} d K | lawY.{u₃} z = j} :=
        measurableSet_eq_fun hY₃ measurable_const
      exact hm1.compl.union hm2.compl
    exact (ae_map_iff hf₃_aem hmeas_imp).mp h_imp₃

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_thm_A_7 (h_cit_brouwer : S_cit_brouwer) (h_lem_A_2 : S_lem_A_2) (h_lem_A_3 : S_lem_A_3) (h_lem_A_6 : S_lem_A_6) : S_thm_A_7 := by
  intro Ω _ μ _ d K hK β hβ X Y hX hY hX_int 𝒲 h𝒲
  obtain ⟨W, hW_mem, ρ, hρ_prof₂, hle_gap⟩ :=
    exists_fixedPoint_and_profile h_cit_brouwer h_lem_A_2 μ hβ hX hY hX_int h𝒲
  refine ⟨W, hW_mem, ρ, hρ_prof₂.2.1, ?_, ?_, ?_⟩
  · intro Φ hΦ
    exact risk_bounds_of_profile h_lem_A_6 μ hK hβ hX hY hX_int h𝒲 hW_mem hρ_prof₂ hle_gap hΦ
  · intro j
    exact support_exclusion_of_profile h_lem_A_3 μ hK hβ hX hY W hρ_prof₂ j
  · exact exists_score_factorization hK W hρ_prof₂.2.1

end UL

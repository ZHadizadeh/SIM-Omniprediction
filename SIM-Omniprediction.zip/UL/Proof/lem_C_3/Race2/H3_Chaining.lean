import Mathlib
import UL.Proof.lem_C_2.H1_HilbertSchmidt
import UL.Proof.lem_C_3.Race2.H2_ProfileCover
set_option autoImplicit false

namespace UL.Proof_lem_C_3_Race2

def radSign (b : Bool) : ℝ :=
  if b then 1 else -1

noncomputable def radSupSample
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    (K n : ℕ) (L R C M₀ : ℝ)
    (σ : Fin n → Bool) (z : Fin n → Metric.closedBall (0 : X) L × Fin K) : ℝ :=
  sSup ((fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
    |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * f (z i)|) ''
    UL.ScoreProfileClass X K L R C M₀)

noncomputable def chainConst (K : ℕ) : ℝ :=
  4 + 32 * Real.sqrt (2 * (1 + 8 * kappaK K)) * (2 : ℝ) ^ K

theorem chainConst_pos (K : ℕ) : 0 < chainConst K := by
  unfold chainConst
  have h1 : 0 ≤ Real.sqrt (2 * (1 + 8 * kappaK K)) * (2 : ℝ) ^ K :=
    mul_nonneg (Real.sqrt_nonneg _) (by positivity)
  linarith

/-! ### Step 1: Basic properties of `ScoreProfileClass` and `radSupSample` -/

private lemma radSign_abs (b : Bool) : |radSign b| = 1 := by
  cases b <;> simp [radSign]

private lemma zero_mem_scoreProfileClass
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {K : ℕ} (hK : 2 ≤ K) {L R C M₀ : ℝ}
    (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀) :
    (fun _ => (0 : ℝ)) ∈ UL.ScoreProfileClass X K L R C M₀ := by
  refine ⟨hK, hL, hR, hC, hM₀, 0, fun _ _ => 0, ?_, ?_, ?_⟩
  · rw [UL.Proof_lem_C_2.hilbertSchmidtNorm_zero]
    exact hR.le
  · intro y
    refine ⟨?_, ?_⟩
    · intro u _ v _
      simp
    · intro u _
      exact ⟨by linarith, by linarith⟩
  · intro x y
    rfl

private lemma abs_apply_le_of_mem_scoreProfileClass
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {K : ℕ} {L R C M₀ : ℝ}
    {f : Metric.closedBall (0 : X) L × Fin K → ℝ}
    (hf : f ∈ UL.ScoreProfileClass X K L R C M₀)
    (p : Metric.closedBall (0 : X) L × Fin K) :
    |f p| ≤ M₀ := by
  rcases hf with ⟨_, hL, hR, _, _, W, a, hW, ha, hfeq⟩
  have hxp : ‖(p.1 : X)‖ ≤ L := mem_closedBall_zero_iff.mp p.1.2
  have hWp : ‖W (p.1 : X)‖ ≤ L * R := by
    calc ‖W (p.1 : X)‖
        ≤ UL.hilbertSchmidtNorm W * ‖(p.1 : X)‖ :=
          UL.Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm W (p.1 : X)
      _ ≤ R * L := mul_le_mul hW hxp (norm_nonneg _) hR.le
      _ = L * R := mul_comm R L
  have hmem : W (p.1 : X) ∈ Metric.closedBall (0 : UL.ZeroSumSubspace K) (L * R) := by
    simpa [Metric.mem_closedBall, dist_zero_right] using hWp
  have hIcc : a p.2 (W (p.1 : X)) ∈ Set.Icc (-M₀) M₀ := (ha p.2).2 hmem
  have hp : f p = a p.2 (W (p.1 : X)) := hfeq p.1 p.2
  rw [hp]
  exact abs_le.mpr hIcc

private lemma radSupSample_le_of_forall
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {K n : ℕ} (hK : 2 ≤ K) {L R C M₀ : ℝ}
    (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀)
    (σ : Fin n → Bool) (z : Fin n → Metric.closedBall (0 : X) L × Fin K)
    {B : ℝ}
    (hB : ∀ f ∈ UL.ScoreProfileClass X K L R C M₀,
      |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * f (z i)| ≤ B) :
    radSupSample K n L R C M₀ σ z ≤ B := by
  unfold radSupSample
  have hne : (UL.ScoreProfileClass X K L R C M₀).Nonempty :=
    ⟨fun _ => 0, zero_mem_scoreProfileClass hK hL hR hC hM₀⟩
  refine csSup_le (hne.image _) ?_
  rintro _ ⟨f, hf, rfl⟩
  exact hB f hf

/-! ### Step 2: Rademacher MGF and Finite Massart Lemma -/

private lemma exp_add_exp_neg_div_two_le (x : ℝ) :
    (Real.exp x + Real.exp (-x)) / 2 ≤ Real.exp (x ^ 2 / 2) := by
  rw [← Real.cosh_eq]
  exact Real.cosh_le_exp_half_sq x

private lemma rademacher_mgf_le (n : ℕ) (v : Fin n → ℝ) (s : ℝ) :
    ((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool, Real.exp (s * ∑ i : Fin n, radSign (σ i) * v i) ≤
      Real.exp (s ^ 2 * (∑ i : Fin n, v i ^ 2) / 2) := by
  induction n with
  | zero =>
      simp
  | succ m ih =>
      have hsplit :
          ∑ σ : Fin (m + 1) → Bool, Real.exp (s * ∑ i : Fin (m + 1), radSign (σ i) * v i) =
            (∑ b : Bool, Real.exp (s * (radSign b * v 0))) *
              ∑ τ : Fin m → Bool,
                Real.exp (s * ∑ i : Fin m, radSign (τ i) * v (Fin.succ i)) := by
        rw [← (Fin.consEquiv (fun _ : Fin (m + 1) => Bool)).sum_comp]
        rw [Fintype.sum_prod_type]
        simp_rw [Fin.consEquiv_apply, Fin.sum_univ_succ, Fin.cons_zero, Fin.cons_succ,
          mul_add, Real.exp_add, ← Finset.mul_sum, ← Finset.sum_mul]
      rw [hsplit, pow_succ', mul_inv]
      have hfactor :
          (2 : ℝ)⁻¹ * ((2 : ℝ) ^ m)⁻¹ *
              ((∑ b : Bool, Real.exp (s * (radSign b * v 0))) *
                ∑ τ : Fin m → Bool,
                  Real.exp (s * ∑ i : Fin m, radSign (τ i) * v (Fin.succ i))) =
            ((∑ b : Bool, Real.exp (s * (radSign b * v 0))) / 2) *
              (((2 : ℝ) ^ m)⁻¹ *
                ∑ τ : Fin m → Bool,
                  Real.exp (s * ∑ i : Fin m, radSign (τ i) * v (Fin.succ i))) := by
        ring
      rw [hfactor]
      have hhead :
          (∑ b : Bool, Real.exp (s * (radSign b * v 0))) / 2 ≤
            Real.exp ((s * v 0) ^ 2 / 2) := by
        rw [Fintype.sum_bool]
        have h1 : s * (radSign true * v 0) = s * v 0 := by simp [radSign]
        have h2 : s * (radSign false * v 0) = -(s * v 0) := by simp [radSign]
        rw [h1, h2]
        exact exp_add_exp_neg_div_two_le (s * v 0)
      have htail := ih (fun i => v (Fin.succ i))
      have hmul := mul_le_mul hhead htail
        (mul_nonneg (by positivity) (Finset.sum_nonneg fun _ _ => Real.exp_nonneg _))
        (Real.exp_nonneg _)
      refine hmul.trans ?_
      rw [← Real.exp_add]
      refine Real.exp_le_exp.mpr (le_of_eq ?_)
      rw [Fin.sum_univ_succ]
      ring

private lemma card_bool_pi (n : ℕ) :
    (∑ _σ : Fin n → Bool, (1 : ℝ)) = (2 : ℝ) ^ n := by
  simp

private lemma rademacher_finset_le
    {n : ℕ} (hn : 1 ≤ n)
    (S : Finset (Fin n → ℝ)) (hS : S.Nonempty)
    {r B : ℝ} (hr : 0 ≤ r) (hB : 0 ≤ B)
    (hcard : (S.card : ℝ) ≤ Real.exp B)
    (hnorm : ∀ v ∈ S, ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, v i ^ 2 ≤ r ^ 2) :
    (((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool,
      S.sup' hS (fun v => |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * v i|)) ≤
      r * Real.sqrt (2 * (1 + B) / (n : ℝ)) := by
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  rcases eq_or_lt_of_le hr with rfl | hr_pos
  · have hzero : ∀ σ : Fin n → Bool,
        S.sup' hS (fun v => |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * v i|) ≤ 0 := by
      intro σ
      refine Finset.sup'_le hS _ fun v hv => ?_
      have hv0 : ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, v i ^ 2 ≤ 0 := by
        simpa using hnorm v hv
      have hsum_le : ∑ i : Fin n, v i ^ 2 ≤ 0 := by
        have hpos : (0 : ℝ) < (1 : ℝ) / (n : ℝ) := by positivity
        nlinarith
      have hvi : ∀ i : Fin n, v i = 0 := by
        intro i
        have hi : v i ^ 2 ≤ ∑ j : Fin n, v j ^ 2 :=
          Finset.single_le_sum (fun j _ => sq_nonneg (v j)) (Finset.mem_univ i)
        have hsq0 : v i ^ 2 = 0 := le_antisymm (hi.trans hsum_le) (sq_nonneg _)
        exact sq_eq_zero_iff.mp hsq0
      simp [hvi]
    have hsum : ∑ σ : Fin n → Bool,
        S.sup' hS (fun v => |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * v i|) ≤ 0 :=
      (Finset.sum_le_sum fun σ _ => hzero σ).trans (by simp)
    have hinv_nonneg : 0 ≤ ((2 : ℝ) ^ n)⁻¹ := by positivity
    calc (((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool,
            S.sup' hS (fun v => |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * v i|))
        ≤ 0 := mul_nonpos_of_nonneg_of_nonpos hinv_nonneg hsum
      _ = 0 * Real.sqrt (2 * (1 + B) / (n : ℝ)) := by simp
  · let Y : (Fin n → Bool) → ℝ := fun σ =>
      S.sup' hS (fun v => |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * v i|)
    let lam : ℝ := Real.sqrt (2 * (n : ℝ) * (1 + B)) / r
    have hlam_pos : 0 < lam := by
      dsimp [lam]
      exact div_pos (Real.sqrt_pos.mpr (by positivity)) hr_pos
    let M : ℝ := 2 * (1 + B)
    have hlam_sq : lam ^ 2 * r ^ 2 / (2 * (n : ℝ)) = 1 + B := by
      have hlr : lam * r = Real.sqrt (2 * (n : ℝ) * (1 + B)) := div_mul_cancel₀ _ hr_pos.ne'
      have hsq : lam ^ 2 * r ^ 2 = 2 * (n : ℝ) * (1 + B) := by
        calc lam ^ 2 * r ^ 2 = (lam * r) ^ 2 := (mul_pow lam r 2).symm
          _ = 2 * (n : ℝ) * (1 + B) := by
            rw [hlr, Real.sq_sqrt (by positivity)]
      rw [hsq]
      field_simp
    have hexp_sup : ∀ σ : Fin n → Bool,
        Real.exp (lam * Y σ) ≤
          ∑ v ∈ S,
            (Real.exp ((lam / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * v i) +
              Real.exp ((-(lam / (n : ℝ))) * ∑ i : Fin n, radSign (σ i) * v i)) := by
      intro σ
      obtain ⟨v₀, hv₀, hv₀_eq⟩ := Finset.exists_mem_eq_sup' hS
        (fun v => |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * v i|)
      have hle1 : Real.exp (lam * Y σ) ≤
          Real.exp ((lam / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * v₀ i) +
            Real.exp ((-(lam / (n : ℝ))) * ∑ i : Fin n, radSign (σ i) * v₀ i) := by
        dsimp [Y]
        rw [hv₀_eq]
        set q : ℝ := ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * v₀ i
        have hqpos : lam * q = (lam / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * v₀ i := by
          dsimp [q]; ring
        have hqneg : lam * (-q) = (-(lam / (n : ℝ))) * ∑ i : Fin n, radSign (σ i) * v₀ i := by
          dsimp [q]; ring
        rcases abs_choice q with hq | hq
        · rw [hq, hqpos]
          linarith [Real.exp_pos ((-(lam / (n : ℝ))) * ∑ i : Fin n, radSign (σ i) * v₀ i)]
        · rw [hq, hqneg]
          linarith [Real.exp_pos ((lam / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * v₀ i)]
      exact hle1.trans (Finset.single_le_sum
        (f := fun v =>
          Real.exp ((lam / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * v i) +
            Real.exp ((-(lam / (n : ℝ))) * ∑ i : Fin n, radSign (σ i) * v i))
        (fun _ _ => by positivity) hv₀)
    have hmgf_v : ∀ v ∈ S,
        ((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool,
          (Real.exp ((lam / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * v i) +
            Real.exp ((-(lam / (n : ℝ))) * ∑ i : Fin n, radSign (σ i) * v i)) ≤
          2 * Real.exp (1 + B) := by
      intro v hv
      have hsum_v : ∑ i : Fin n, v i ^ 2 ≤ (n : ℝ) * r ^ 2 := by
        have hnv := hnorm v hv
        have : (n : ℝ) * (((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, v i ^ 2) ≤ (n : ℝ) * r ^ 2 :=
          mul_le_mul_of_nonneg_left hnv hn_pos.le
        have hcancel : (n : ℝ) * (((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, v i ^ 2) =
            ∑ i : Fin n, v i ^ 2 := by
          field_simp
        linarith
      have hexp_arg : (lam / (n : ℝ)) ^ 2 * (∑ i : Fin n, v i ^ 2) / 2 ≤ 1 + B := by
        calc (lam / (n : ℝ)) ^ 2 * (∑ i : Fin n, v i ^ 2) / 2
            ≤ (lam / (n : ℝ)) ^ 2 * ((n : ℝ) * r ^ 2) / 2 := by
              gcongr
          _ = lam ^ 2 * r ^ 2 / (2 * (n : ℝ)) := by
              field_simp
          _ = 1 + B := hlam_sq
      have hm1 := (rademacher_mgf_le n v (lam / (n : ℝ))).trans (Real.exp_le_exp.mpr hexp_arg)
      have hm2 : ((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool,
          Real.exp ((-(lam / (n : ℝ))) * ∑ i : Fin n, radSign (σ i) * v i) ≤
            Real.exp (1 + B) := by
        refine (rademacher_mgf_le n v (-(lam / (n : ℝ)))).trans ?_
        rw [neg_sq]
        exact Real.exp_le_exp.mpr hexp_arg
      rw [Finset.sum_add_distrib, mul_add]
      linarith
    have hexp_avg :
        ((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool, Real.exp (lam * Y σ) ≤ Real.exp M := by
      calc ((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool, Real.exp (lam * Y σ)
          ≤ ((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool,
              ∑ v ∈ S,
                (Real.exp ((lam / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * v i) +
                  Real.exp ((-(lam / (n : ℝ))) * ∑ i : Fin n, radSign (σ i) * v i)) := by
            gcongr with σ
            exact hexp_sup σ
        _ = ∑ v ∈ S, ((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool,
              (Real.exp ((lam / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * v i) +
                Real.exp ((-(lam / (n : ℝ))) * ∑ i : Fin n, radSign (σ i) * v i)) := by
            rw [Finset.sum_comm, Finset.mul_sum]
        _ ≤ ∑ _v ∈ S, (2 * Real.exp (1 + B)) :=
            Finset.sum_le_sum hmgf_v
        _ = (S.card : ℝ) * (2 * Real.exp (1 + B)) := by simp
        _ ≤ Real.exp B * (Real.exp 1 * Real.exp (1 + B)) := by
            have h2e : (2 : ℝ) ≤ Real.exp 1 := by
              have h1 := Real.add_one_le_exp 1
              linarith
            have hmul2 : 2 * Real.exp (1 + B) ≤ Real.exp 1 * Real.exp (1 + B) :=
              mul_le_mul_of_nonneg_right h2e (Real.exp_nonneg _)
            exact mul_le_mul hcard hmul2 (by positivity) (Real.exp_nonneg _)
        _ = Real.exp M := by
            rw [← Real.exp_add, ← Real.exp_add]
            dsimp [M]
            ring_nf
    let avg : ℝ := ((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool, Y σ
    have hpoint : ∀ σ : Fin n → Bool,
        lam * Y σ - M + 1 ≤ Real.exp (-M) * Real.exp (lam * Y σ) := by
      intro σ
      calc lam * Y σ - M + 1
          ≤ Real.exp (lam * Y σ - M) := Real.add_one_le_exp (lam * Y σ - M)
        _ = Real.exp (-M + lam * Y σ) := by ring_nf
        _ = Real.exp (-M) * Real.exp (lam * Y σ) := Real.exp_add (-M) (lam * Y σ)
    have hsum_point :
        ((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool, (lam * Y σ - M + 1) ≤
          ((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool, (Real.exp (-M) * Real.exp (lam * Y σ)) := by
      gcongr with σ
      exact hpoint σ
    have hlhs : ((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool, (lam * Y σ - M + 1) =
        lam * avg - M + 1 := by
      have hrew : ∀ σ : Fin n → Bool, lam * Y σ - M + 1 = lam * Y σ + (-M + 1) * (1 : ℝ) :=
        fun _ => by ring
      simp_rw [hrew, Finset.sum_add_distrib, ← Finset.mul_sum, card_bool_pi]
      dsimp [avg]
      have h2ne : (2 : ℝ) ^ n ≠ 0 := by positivity
      field_simp
      ring
    have hrhs : ((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool, (Real.exp (-M) * Real.exp (lam * Y σ)) ≤ 1 := by
      rw [← Finset.mul_sum, mul_left_comm]
      calc Real.exp (-M) * (((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool, Real.exp (lam * Y σ))
          ≤ Real.exp (-M) * Real.exp M :=
            mul_le_mul_of_nonneg_left hexp_avg (Real.exp_nonneg _)
        _ = Real.exp (-M + M) := (Real.exp_add (-M) M).symm
        _ = 1 := by simp
    have hlam_avg : lam * avg ≤ M := by linarith
    have htarget : M = lam * (r * Real.sqrt (2 * (1 + B) / (n : ℝ))) := by
      dsimp [lam, M]
      have h1 : (Real.sqrt (2 * (n : ℝ) * (1 + B)) / r) *
          (r * Real.sqrt (2 * (1 + B) / (n : ℝ))) =
          Real.sqrt (2 * (n : ℝ) * (1 + B)) * Real.sqrt (2 * (1 + B) / (n : ℝ)) := by
        have hr0 : r ≠ 0 := hr_pos.ne'
        field_simp
      rw [h1, ← Real.sqrt_mul (by positivity)]
      have h2 : (2 * (n : ℝ) * (1 + B)) * (2 * (1 + B) / (n : ℝ)) = (2 * (1 + B)) ^ 2 := by
        field_simp
      rw [h2, Real.sqrt_sq (by positivity)]
    rw [htarget] at hlam_avg
    exact le_of_mul_le_mul_left hlam_avg hlam_pos

/-! ### Step 3: Finite Dyadic Dudley Chaining -/

private noncomputable def tScale (M₀ : ℝ) (j : ℕ) : ℝ :=
  M₀ / (2 : ℝ) ^ j

private lemma tScale_pos {M₀ : ℝ} (hM₀ : 0 < M₀) (j : ℕ) : 0 < tScale M₀ j := by
  unfold tScale
  positivity

private lemma tScale_zero (M₀ : ℝ) : tScale M₀ 0 = M₀ := by
  simp [tScale]

private lemma tScale_succ (M₀ : ℝ) (j : ℕ) : tScale M₀ (j + 1) = tScale M₀ j / 2 := by
  unfold tScale
  rw [pow_succ, div_div]

private lemma tScale_succ_le {M₀ : ℝ} (hM₀ : 0 < M₀) (j : ℕ) :
    tScale M₀ (j + 1) ≤ tScale M₀ j := by
  rw [tScale_succ]
  linarith [tScale_pos hM₀ j]

private lemma tScale_le_self {M₀ : ℝ} (hM₀ : 0 < M₀) (j : ℕ) :
    tScale M₀ j ≤ M₀ := by
  unfold tScale
  exact div_le_self hM₀.le (one_le_pow₀ (by norm_num : (1 : ℝ) ≤ 2))

private lemma coverExp_nonneg {K : ℕ} (hK : 2 ≤ K)
    {A₀ C M₀ t : ℝ} (hA₀ : 0 ≤ A₀) (hC : 0 ≤ C) (hM₀ : 0 ≤ M₀) (ht : 0 < t) :
    0 ≤ coverExp K A₀ C M₀ t := by
  unfold coverExp
  have hk : 0 < kappaK K := kappaK_pos hK
  have hlog : 0 ≤ Real.log (1 + M₀ / t) := by
    refine Real.log_nonneg ?_
    have : 0 ≤ M₀ / t := div_nonneg hM₀ ht.le
    linarith
  have hca : 0 ≤ C * A₀ / t := div_nonneg (mul_nonneg hC hA₀) ht.le
  exact mul_nonneg hk.le (by positivity)

private lemma coverExp_anti {K : ℕ} (hK : 2 ≤ K)
    {A₀ C M₀ t₁ t₂ : ℝ} (hA₀ : 0 ≤ A₀) (hC : 0 ≤ C) (hM₀ : 0 ≤ M₀)
    (ht₁ : 0 < t₁) (ht₁₂ : t₁ ≤ t₂) :
    coverExp K A₀ C M₀ t₂ ≤ coverExp K A₀ C M₀ t₁ := by
  unfold coverExp
  refine mul_le_mul_of_nonneg_left ?_ (kappaK_pos hK).le
  have ht₂ : 0 < t₂ := ht₁.trans_le ht₁₂
  have hm_le : M₀ / t₂ ≤ M₀ / t₁ := div_le_div_of_nonneg_left hM₀ ht₁ ht₁₂
  have hlog : Real.log (1 + M₀ / t₂) ≤ Real.log (1 + M₀ / t₁) := by
    refine Real.log_le_log ?_ (by linarith)
    have : 0 ≤ M₀ / t₂ := div_nonneg hM₀ ht₂.le
    linarith
  have hca_le : C * A₀ / t₂ ≤ C * A₀ / t₁ :=
    div_le_div_of_nonneg_left (mul_nonneg hC hA₀) ht₁ ht₁₂
  have hca_nn : 0 ≤ C * A₀ / t₂ := div_nonneg (mul_nonneg hC hA₀) ht₂.le
  have hp2 : (C * A₀ / t₂) ^ 2 ≤ (C * A₀ / t₁) ^ 2 := pow_le_pow_left₀ hca_nn hca_le 2
  have hpm : (C * A₀ / t₂) ^ (K - 1) ≤ (C * A₀ / t₁) ^ (K - 1) :=
    pow_le_pow_left₀ hca_nn hca_le (K - 1)
  linarith

private lemma radSupSample_chaining_le
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R C M₀ : ℝ} (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀)
    (z : Fin n → Metric.closedBall (0 : X) L × Fin K) (J : ℕ) :
    (((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool, radSupSample K n L R C M₀ σ z) ≤
      tScale M₀ J +
        ∑ j ∈ Finset.range J,
          2 * tScale M₀ j *
            Real.sqrt (2 * (1 + 2 * coverExp K (L * R) C M₀ (tScale M₀ (j + 1))) / (n : ℝ)) := by
  classical
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  have hcov : ∀ j : ℕ, ∃ G : Finset (Fin n → ℝ),
      (j = 0 → G = {0}) ∧
      G.Nonempty ∧
      (G.card : ℝ) ≤ Real.exp (if j = 0 then 0 else coverExp K (L * R) C M₀ (tScale M₀ j)) ∧
      ∀ f ∈ UL.ScoreProfileClass X K L R C M₀,
        ∃ g ∈ G, ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f (z i) - g i) ^ 2 ≤ (tScale M₀ j) ^ 2 := by
    intro j
    cases j with
    | zero =>
        refine ⟨{0}, fun _ => rfl, Finset.singleton_nonempty 0, by simp, ?_⟩
        intro f hf
        refine ⟨0, Finset.mem_singleton_self 0, ?_⟩
        rw [tScale_zero]
        have hterm : ∀ i : Fin n, (f (z i) - (0 : Fin n → ℝ) i) ^ 2 ≤ M₀ ^ 2 := by
          intro i
          simp only [Pi.zero_apply, sub_zero, ← sq_abs (f (z i))]
          exact pow_le_pow_left₀ (abs_nonneg _)
            (abs_apply_le_of_mem_scoreProfileClass hf (z i)) 2
        calc ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f (z i) - (0 : Fin n → ℝ) i) ^ 2
            ≤ ((1 : ℝ) / (n : ℝ)) * ∑ _i : Fin n, M₀ ^ 2 :=
              mul_le_mul_of_nonneg_left (Finset.sum_le_sum fun i _ => hterm i) (by positivity)
          _ = M₀ ^ 2 := by
              simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
              field_simp
    | succ k =>
        obtain ⟨G, hGne, _, hGcard, hGapprox⟩ :=
          exists_empirical_cover_scoreProfileClass hK hn hL hR hC hM₀ (tScale_pos hM₀ (k + 1)) z
        exact ⟨G, (fun h => nomatch h), hGne, by simpa using hGcard, hGapprox⟩
  let G : ℕ → Finset (Fin n → ℝ) := fun j => Classical.choose (hcov j)
  have hG_spec : ∀ j : ℕ,
      (j = 0 → G j = {0}) ∧
      (G j).Nonempty ∧
      ((G j).card : ℝ) ≤ Real.exp (if j = 0 then 0 else coverExp K (L * R) C M₀ (tScale M₀ j)) ∧
      ∀ f ∈ UL.ScoreProfileClass X K L R C M₀,
        ∃ g ∈ G j, ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f (z i) - g i) ^ 2 ≤ (tScale M₀ j) ^ 2 :=
    fun j => Classical.choose_spec (hcov j)
  have hG_card_next : ∀ j : ℕ,
      ((G j).card : ℝ) ≤ Real.exp (coverExp K (L * R) C M₀ (tScale M₀ (j + 1))) := by
    intro j
    have hcard := (hG_spec j).2.2.1
    refine hcard.trans (Real.exp_le_exp.mpr ?_)
    cases j with
    | zero =>
        simp only [↓reduceIte]
        exact coverExp_nonneg hK (by positivity) hC.le hM₀.le (tScale_pos hM₀ 1)
    | succ k =>
        simp only [Nat.succ_ne_zero, ↓reduceIte]
        exact coverExp_anti hK (by positivity) hC.le hM₀.le
          (tScale_pos hM₀ (k + 2)) (tScale_succ_le hM₀ (k + 1))
  let D : ℕ → Finset (Fin n → ℝ) := fun j =>
    (Finset.image₂ (· - ·) (G (j + 1)) (G j)).filter
      (fun d => ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, d i ^ 2 ≤ (2 * tScale M₀ j) ^ 2)
  have hD_card : ∀ j : ℕ,
      ((D j).card : ℝ) ≤ Real.exp (2 * coverExp K (L * R) C M₀ (tScale M₀ (j + 1))) := by
    intro j
    have hc1 : (D j).card ≤ (G (j + 1)).card * (G j).card :=
      (Finset.card_filter_le _ _).trans (Finset.card_image₂_le _ _ _)
    have hc2 : ((D j).card : ℝ) ≤ ((G (j + 1)).card : ℝ) * ((G j).card : ℝ) := by
      exact_mod_cast hc1
    have h1 : ((G (j + 1)).card : ℝ) ≤ Real.exp (coverExp K (L * R) C M₀ (tScale M₀ (j + 1))) := by
      simpa using (hG_spec (j + 1)).2.2.1
    have h2 : ((G j).card : ℝ) ≤ Real.exp (coverExp K (L * R) C M₀ (tScale M₀ (j + 1))) :=
      hG_card_next j
    calc ((D j).card : ℝ)
        ≤ ((G (j + 1)).card : ℝ) * ((G j).card : ℝ) := hc2
      _ ≤ Real.exp (coverExp K (L * R) C M₀ (tScale M₀ (j + 1))) *
            Real.exp (coverExp K (L * R) C M₀ (tScale M₀ (j + 1))) :=
          mul_le_mul h1 h2 (Nat.cast_nonneg _) (Real.exp_nonneg _)
      _ = Real.exp (2 * coverExp K (L * R) C M₀ (tScale M₀ (j + 1))) := by
          rw [← Real.exp_add, two_mul]
  have h_chain_f : ∀ f ∈ UL.ScoreProfileClass X K L R C M₀,
      ∃ πf : ℕ → (Fin n → ℝ),
        πf 0 = 0 ∧
        (∀ j : ℕ, πf (j + 1) - πf j ∈ D j) ∧
        ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f (z i) - πf J i) ^ 2 ≤ (tScale M₀ J) ^ 2 := by
    intro f hf
    let πf : ℕ → (Fin n → ℝ) := fun j => Classical.choose ((hG_spec j).2.2.2 f hf)
    have hπ_mem : ∀ j : ℕ, πf j ∈ G j :=
      fun j => (Classical.choose_spec ((hG_spec j).2.2.2 f hf)).1
    have hπ_err : ∀ j : ℕ,
        ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f (z i) - πf j i) ^ 2 ≤ (tScale M₀ j) ^ 2 :=
      fun j => (Classical.choose_spec ((hG_spec j).2.2.2 f hf)).2
    have hπ0 : πf 0 = 0 := by
      have hm0 := hπ_mem 0
      rw [(hG_spec 0).1 rfl] at hm0
      exact Finset.mem_singleton.mp hm0
    refine ⟨πf, hπ0, ?_, hπ_err J⟩
    intro j
    refine Finset.mem_filter.mpr ⟨Finset.mem_image₂.mpr ⟨πf (j + 1), hπ_mem (j + 1),
      πf j, hπ_mem j, rfl⟩, ?_⟩
    have hpt : ∀ i : Fin n,
        (πf (j + 1) i - πf j i) ^ 2 ≤
          2 * (f (z i) - πf (j + 1) i) ^ 2 + 2 * (f (z i) - πf j i) ^ 2 := by
      intro i
      have hnn : 0 ≤ ((f (z i) - πf (j + 1) i) + (f (z i) - πf j i)) ^ 2 := sq_nonneg _
      nlinarith
    have hsum_le :
        ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (πf (j + 1) i - πf j i) ^ 2 ≤
          2 * (((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f (z i) - πf (j + 1) i) ^ 2) +
            2 * (((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f (z i) - πf j i) ^ 2) := by
      calc ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (πf (j + 1) i - πf j i) ^ 2
          ≤ ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
              (2 * (f (z i) - πf (j + 1) i) ^ 2 + 2 * (f (z i) - πf j i) ^ 2) := by
            gcongr with i
            exact hpt i
        _ = 2 * (((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f (z i) - πf (j + 1) i) ^ 2) +
              2 * (((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f (z i) - πf j i) ^ 2) := by
            rw [Finset.sum_add_distrib, ← Finset.mul_sum, ← Finset.mul_sum]
            ring
    have he1 := hπ_err (j + 1)
    have he2 := hπ_err j
    have ht_le : (tScale M₀ (j + 1)) ^ 2 ≤ (tScale M₀ j) ^ 2 :=
      pow_le_pow_left₀ (tScale_pos hM₀ (j + 1)).le (tScale_succ_le hM₀ j) 2
    simp only [Pi.sub_apply]
    nlinarith
  have hD_ne : ∀ j : ℕ, (D j).Nonempty := by
    intro j
    obtain ⟨π0, _, hπ0D, _⟩ := h_chain_f (fun _ => 0)
      (zero_mem_scoreProfileClass hK hL hR hC hM₀)
    exact ⟨π0 (j + 1) - π0 j, hπ0D j⟩
  have hσ_bound : ∀ σ : Fin n → Bool,
      radSupSample K n L R C M₀ σ z ≤
        tScale M₀ J + ∑ j ∈ Finset.range J,
          (D j).sup' (hD_ne j) (fun d => |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * d i|) := by
    intro σ
    refine radSupSample_le_of_forall hK hL hR hC hM₀ σ z fun f hf => ?_
    obtain ⟨πf, hπ0, hπD, hπJ⟩ := h_chain_f f hf
    have htele : ∀ i : Fin n,
        f (z i) = (f (z i) - πf J i) + ∑ j ∈ Finset.range J, (πf (j + 1) i - πf j i) := by
      intro i
      rw [Finset.sum_range_sub (fun j => πf j i) J, hπ0, Pi.zero_apply, sub_zero, sub_add_cancel]
    have hdecomp :
        ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * f (z i) =
          ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * (f (z i) - πf J i) +
            ∑ j ∈ Finset.range J,
              ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * (πf (j + 1) i - πf j i) := by
      have h1 : ∑ i : Fin n, radSign (σ i) * f (z i) =
          ∑ i : Fin n, (radSign (σ i) * (f (z i) - πf J i) +
            ∑ j ∈ Finset.range J, radSign (σ i) * (πf (j + 1) i - πf j i)) := by
        refine Finset.sum_congr rfl fun i _ => ?_
        conv_lhs => rw [htele]
        rw [mul_add, Finset.mul_sum]
      rw [h1, Finset.sum_add_distrib, mul_add, Finset.sum_comm]
      congr 1
      exact Finset.mul_sum _ _ _
    have hrem :
        |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * (f (z i) - πf J i)| ≤ tScale M₀ J := by
      set t : ℝ := tScale M₀ J
      have ht_pos : 0 < t := tScale_pos hM₀ J
      have h_amgm : ∀ w : ℝ, |w| ≤ w ^ 2 / (2 * t) + t / 2 := by
        intro w
        have hsq : 0 ≤ (|w| - t) ^ 2 := sq_nonneg _
        have habs : |w| ^ 2 = w ^ 2 := sq_abs w
        have hmul : |w| * (2 * t) ≤ (w ^ 2 / (2 * t) + t / 2) * (2 * t) := by
          have h1 : (w ^ 2 / (2 * t) + t / 2) * (2 * t) = w ^ 2 + t ^ 2 := by
            field_simp
          rw [h1]
          nlinarith
        exact le_of_mul_le_mul_right hmul (by positivity)
      calc |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * (f (z i) - πf J i)|
          = ((1 : ℝ) / (n : ℝ)) * |∑ i : Fin n, radSign (σ i) * (f (z i) - πf J i)| := by
              rw [abs_mul, abs_of_pos (by positivity)]
        _ ≤ ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, |radSign (σ i) * (f (z i) - πf J i)| := by
              gcongr
              exact Finset.abs_sum_le_sum_abs _ _
        _ = ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, |f (z i) - πf J i| := by
              congr 1
              refine Finset.sum_congr rfl fun i _ => ?_
              rw [abs_mul, radSign_abs, one_mul]
        _ ≤ ((1 : ℝ) / (n : ℝ)) *
              ∑ i : Fin n, ((f (z i) - πf J i) ^ 2 / (2 * t) + t / 2) := by
              gcongr with i
              exact h_amgm (f (z i) - πf J i)
        _ = (((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f (z i) - πf J i) ^ 2) / (2 * t) + t / 2 := by
              rw [Finset.sum_add_distrib, ← Finset.sum_div, Finset.sum_const, Finset.card_univ,
                Fintype.card_fin, nsmul_eq_mul]
              field_simp
        _ ≤ t ^ 2 / (2 * t) + t / 2 := by
              gcongr
        _ = t := by
              field_simp
              ring
    have hsteps :
        |∑ j ∈ Finset.range J,
            ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * (πf (j + 1) i - πf j i)| ≤
          ∑ j ∈ Finset.range J,
            (D j).sup' (hD_ne j)
              (fun d => |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * d i|) := by
      refine (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum fun j _ => ?_)
      exact Finset.le_sup'
        (fun d : Fin n → ℝ => |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * d i|) (hπD j)
    rw [hdecomp]
    exact (abs_add_le _ _).trans (add_le_add hrem hsteps)
  calc (((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool, radSupSample K n L R C M₀ σ z)
      ≤ ((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool,
          (tScale M₀ J + ∑ j ∈ Finset.range J,
            (D j).sup' (hD_ne j)
              (fun d => |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * d i|)) := by
          gcongr with σ
          exact hσ_bound σ
    _ = tScale M₀ J + ∑ j ∈ Finset.range J,
          (((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool,
            (D j).sup' (hD_ne j)
              (fun d => |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * d i|)) := by
          rw [Finset.sum_add_distrib, mul_add, Finset.sum_const, Finset.card_univ,
            Fintype.card_fun, Fintype.card_bool, Fintype.card_fin, nsmul_eq_mul, Nat.cast_pow,
            Nat.cast_ofNat, inv_mul_cancel_left₀ (by positivity), Finset.sum_comm, Finset.mul_sum]
    _ ≤ tScale M₀ J + ∑ j ∈ Finset.range J,
          2 * tScale M₀ j *
            Real.sqrt (2 * (1 + 2 * coverExp K (L * R) C M₀ (tScale M₀ (j + 1))) / (n : ℝ)) := by
          refine add_le_add le_rfl (Finset.sum_le_sum fun j _ => ?_)
          exact rademacher_finset_le hn (D j) (hD_ne j)
            (mul_nonneg zero_le_two (tScale_pos hM₀ j).le)
            (mul_nonneg zero_le_two
              (coverExp_nonneg hK (by positivity) hC.le hM₀.le (tScale_pos hM₀ (j + 1))))
            (hD_card j)
            (fun d hd => (Finset.mem_filter.mp hd).2)

/-! ### Step 4: Regime evaluation (`m ≤ 2` and `3 ≤ m`) -/

private lemma coverExp_bound_le_two
    {K : ℕ} (hK : 2 ≤ K) (hm : K - 1 ≤ 2)
    {A₀ C M₀ t : ℝ} (hA₀ : 0 < A₀) (hC : 0 < C) (hM₀ : 0 < M₀)
    (ht : 0 < t) (htM : t ≤ M₀) :
    1 + 2 * coverExp K A₀ C M₀ t ≤ (1 + 8 * kappaK K) * ((M₀ + C * A₀) / t) ^ 2 := by
  set D₀ : ℝ := M₀ + C * A₀
  set u : ℝ := D₀ / t
  have hD₀ : M₀ < D₀ := by dsimp [D₀]; linarith [mul_pos hC hA₀]
  have hu1 : 1 ≤ u := by
    dsimp [u]
    rw [one_le_div ht]
    linarith
  have hlog : Real.log (1 + M₀ / t) ≤ u := by
    have hpos : 0 < 1 + M₀ / t := by positivity
    have h1 := Real.log_le_sub_one_of_pos hpos
    have h2 : M₀ / t ≤ u := div_le_div_of_nonneg_right hD₀.le ht.le
    linarith
  have hca : C * A₀ / t ≤ u := by
    dsimp [u, D₀]
    exact div_le_div_of_nonneg_right (by linarith) ht.le
  have hca_nn : 0 ≤ C * A₀ / t := by positivity
  have hu_sq1 : u ≤ u ^ 2 := by nlinarith
  have hu_sq0 : 1 ≤ u ^ 2 := by nlinarith
  have hca2 : (C * A₀ / t) ^ 2 ≤ u ^ 2 := pow_le_pow_left₀ hca_nn hca 2
  have hcam : (C * A₀ / t) ^ (K - 1) ≤ u ^ 2 :=
    (pow_le_pow_left₀ hca_nn hca (K - 1)).trans (pow_le_pow_right₀ hu1 hm)
  have hinner : 1 + Real.log (1 + M₀ / t) + (C * A₀ / t) ^ 2 + (C * A₀ / t) ^ (K - 1) ≤
      4 * u ^ 2 := by linarith
  have hk_pos : 0 < kappaK K := kappaK_pos hK
  unfold coverExp
  nlinarith

private lemma avg_radSupSample_le_case_small
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n) (hm : K - 1 ≤ 2)
    {L R C M₀ : ℝ} (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀)
    (z : Fin n → Metric.closedBall (0 : X) L × Fin K) :
    let D₀ : ℝ := M₀ + C * (L * R)
    (((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool, radSupSample K n L R C M₀ σ z) ≤
      chainConst K * D₀ * Real.log (2 * (n : ℝ)) / Real.sqrt (n : ℝ) := by
  intro D₀
  have hn1 : (1 : ℝ) ≤ (n : ℝ) := Nat.one_le_cast.mpr hn
  have hn_pos : (0 : ℝ) < (n : ℝ) := by positivity
  have hA₀ : 0 < L * R := mul_pos hL hR
  have hD₀_pos : 0 < D₀ := by dsimp [D₀]; positivity
  have hlog2_half : (1 : ℝ) / 2 < Real.log 2 := by
    linarith [Real.log_two_gt_d9]
  have hlog2_pos : 0 < Real.log 2 := by linarith
  have hlog2n_ge : Real.log 2 ≤ Real.log (2 * (n : ℝ)) :=
    Real.log_le_log (by norm_num) (by linarith)
  have hquot_ge_one : 1 ≤ Real.log (2 * (n : ℝ)) / Real.log 2 :=
    (one_le_div hlog2_pos).mpr hlog2n_ge
  let zJ : ℤ := ⌊Real.log (2 * (n : ℝ)) / Real.log 2⌋
  have hzJ_nn : 0 ≤ zJ := Int.floor_nonneg.mpr (by linarith)
  let J : ℕ := Int.toNat zJ
  have hJ_cast : (J : ℝ) = (zJ : ℝ) := by
    have hz : (J : ℤ) = zJ := Int.toNat_of_nonneg hzJ_nn
    exact_mod_cast hz
  have hJ_le : (J : ℝ) ≤ 2 * Real.log (2 * (n : ℝ)) := by
    have hf : (J : ℝ) ≤ Real.log (2 * (n : ℝ)) / Real.log 2 := by
      rw [hJ_cast]
      exact Int.floor_le _
    refine hf.trans ?_
    have hlog2n_pos : 0 < Real.log (2 * (n : ℝ)) := lt_of_lt_of_le hlog2_pos hlog2n_ge
    calc Real.log (2 * (n : ℝ)) / Real.log 2
        ≤ Real.log (2 * (n : ℝ)) / ((1 : ℝ) / 2) :=
          div_le_div_of_nonneg_left hlog2n_pos.le (by norm_num) hlog2_half.le
      _ = 2 * Real.log (2 * (n : ℝ)) := by ring
  have hpowJ : Real.sqrt (n : ℝ) ≤ (2 : ℝ) ^ J := by
    have hlt1 : Real.log (2 * (n : ℝ)) / Real.log 2 < ((J + 1 : ℕ) : ℝ) := by
      push_cast
      rw [hJ_cast]
      exact Int.lt_floor_add_one _
    have hlt2 : Real.log (2 * (n : ℝ)) < Real.log ((2 : ℝ) ^ (J + 1)) := by
      rw [Real.log_pow]
      exact (div_lt_iff₀ hlog2_pos).mp hlt1
    have h2n_lt : 2 * (n : ℝ) < (2 : ℝ) ^ (J + 1) := by
      have hexp := Real.exp_lt_exp.mpr hlt2
      rwa [Real.exp_log (by positivity), Real.exp_log (by positivity)] at hexp
    have hn_lt : (n : ℝ) < (2 : ℝ) ^ J := by
      rw [pow_succ'] at h2n_lt
      linarith
    have hsqrt_le_n : Real.sqrt (n : ℝ) ≤ (n : ℝ) := by
      refine Real.sqrt_le_iff.mpr ⟨hn_pos.le, ?_⟩
      nlinarith
    exact hsqrt_le_n.trans hn_lt.le
  have hrem : tScale M₀ J ≤ 2 * D₀ * Real.log (2 * (n : ℝ)) / Real.sqrt (n : ℝ) := by
    have ht1 : tScale M₀ J ≤ M₀ / Real.sqrt (n : ℝ) := by
      unfold tScale
      exact div_le_div_of_nonneg_left hM₀.le (Real.sqrt_pos.mpr hn_pos) hpowJ
    refine ht1.trans ?_
    refine div_le_div_of_nonneg_right ?_ (Real.sqrt_nonneg _)
    have h1log : 1 ≤ 2 * Real.log (2 * (n : ℝ)) := by linarith
    have hMD : M₀ ≤ D₀ := by dsimp [D₀]; linarith [mul_pos hC hA₀]
    nlinarith
  set C₁ : ℝ := Real.sqrt (2 * (1 + 8 * kappaK K))
  have hC₁_nn : 0 ≤ C₁ := Real.sqrt_nonneg _
  have hterm : ∀ j ∈ Finset.range J,
      2 * tScale M₀ j *
          Real.sqrt (2 * (1 + 2 * coverExp K (L * R) C M₀ (tScale M₀ (j + 1))) / (n : ℝ)) ≤
        4 * C₁ * D₀ / Real.sqrt (n : ℝ) := by
    intro j _
    set t : ℝ := tScale M₀ (j + 1)
    have ht_pos : 0 < t := tScale_pos hM₀ (j + 1)
    have ht_le : t ≤ M₀ := tScale_le_self hM₀ (j + 1)
    have hcov_le := coverExp_bound_le_two hK hm hA₀ hC hM₀ ht_pos ht_le
    have hrad :
        Real.sqrt (2 * (1 + 2 * coverExp K (L * R) C M₀ t) / (n : ℝ)) ≤
          C₁ * (D₀ / t) / Real.sqrt (n : ℝ) := by
      refine Real.sqrt_le_iff.mpr ⟨by positivity, ?_⟩
      have hC₁_sq : C₁ ^ 2 = 2 * (1 + 8 * kappaK K) :=
        Real.sq_sqrt (by have := kappaK_pos hK; positivity)
      have hsq_n : Real.sqrt (n : ℝ) ^ 2 = (n : ℝ) := Real.sq_sqrt hn_pos.le
      calc 2 * (1 + 2 * coverExp K (L * R) C M₀ t) / (n : ℝ)
          ≤ 2 * ((1 + 8 * kappaK K) * (D₀ / t) ^ 2) / (n : ℝ) := by
            gcongr
        _ = (C₁ * (D₀ / t) / Real.sqrt (n : ℝ)) ^ 2 := by
            rw [div_pow (C₁ * (D₀ / t)), mul_pow, hC₁_sq, hsq_n]
            ring
    have ht_rel : tScale M₀ j = 2 * t := by
      dsimp [t]
      rw [tScale_succ]
      ring
    calc 2 * tScale M₀ j *
            Real.sqrt (2 * (1 + 2 * coverExp K (L * R) C M₀ t) / (n : ℝ))
        ≤ 2 * (2 * t) * (C₁ * (D₀ / t) / Real.sqrt (n : ℝ)) := by
            rw [ht_rel]
            exact mul_le_mul_of_nonneg_left hrad (by positivity)
      _ = 4 * C₁ * D₀ / Real.sqrt (n : ℝ) := by
            have ht0 : t ≠ 0 := ht_pos.ne'
            field_simp
            ring
  have hsum :
      ∑ j ∈ Finset.range J,
          2 * tScale M₀ j *
            Real.sqrt (2 * (1 + 2 * coverExp K (L * R) C M₀ (tScale M₀ (j + 1))) / (n : ℝ)) ≤
        8 * C₁ * D₀ * Real.log (2 * (n : ℝ)) / Real.sqrt (n : ℝ) := by
    calc ∑ j ∈ Finset.range J,
            2 * tScale M₀ j *
              Real.sqrt (2 * (1 + 2 * coverExp K (L * R) C M₀ (tScale M₀ (j + 1))) / (n : ℝ))
        ≤ ∑ _j ∈ Finset.range J, (4 * C₁ * D₀ / Real.sqrt (n : ℝ)) :=
            Finset.sum_le_sum hterm
      _ = (J : ℝ) * (4 * C₁ * D₀ / Real.sqrt (n : ℝ)) := by simp
      _ ≤ (2 * Real.log (2 * (n : ℝ))) * (4 * C₁ * D₀ / Real.sqrt (n : ℝ)) :=
            mul_le_mul_of_nonneg_right hJ_le (by positivity)
      _ = 8 * C₁ * D₀ * Real.log (2 * (n : ℝ)) / Real.sqrt (n : ℝ) := by ring
  have hchain := radSupSample_chaining_le hK hn hL hR hC hM₀ z J
  refine (hchain.trans (add_le_add hrem hsum)).trans ?_
  rw [← add_div]
  refine div_le_div_of_nonneg_right ?_ (Real.sqrt_nonneg _)
  have h2K : (1 : ℝ) ≤ (2 : ℝ) ^ K := one_le_pow₀ (by norm_num)
  have hconst : 2 + 8 * C₁ ≤ chainConst K := by
    unfold chainConst
    change 2 + 8 * C₁ ≤ 4 + 32 * C₁ * (2 : ℝ) ^ K
    nlinarith
  have hfactor_nn : 0 ≤ D₀ * Real.log (2 * (n : ℝ)) := by
    have : 0 < Real.log (2 * (n : ℝ)) := lt_of_lt_of_le hlog2_pos hlog2n_ge
    positivity
  calc 2 * D₀ * Real.log (2 * (n : ℝ)) + 8 * C₁ * D₀ * Real.log (2 * (n : ℝ))
      = (2 + 8 * C₁) * (D₀ * Real.log (2 * (n : ℝ))) := by ring
    _ ≤ chainConst K * (D₀ * Real.log (2 * (n : ℝ))) :=
        mul_le_mul_of_nonneg_right hconst hfactor_nn
    _ = chainConst K * D₀ * Real.log (2 * (n : ℝ)) := by ring

private lemma coverExp_bound_gt_two
    {K : ℕ} (hK : 2 ≤ K) (hm3 : 3 ≤ K - 1)
    {A₀ C M₀ t : ℝ} (hA₀ : 0 < A₀) (hC : 0 < C) (hM₀ : 0 < M₀)
    (ht : 0 < t) (htM : t ≤ M₀) :
    1 + 2 * coverExp K A₀ C M₀ t ≤ (1 + 8 * kappaK K) * ((M₀ + C * A₀) / t) ^ (K - 1) := by
  set m : ℕ := K - 1
  set D₀ : ℝ := M₀ + C * A₀
  set u : ℝ := D₀ / t
  have hD₀ : M₀ < D₀ := by dsimp [D₀]; linarith [mul_pos hC hA₀]
  have hu1 : 1 ≤ u := by
    dsimp [u]
    rw [one_le_div ht]
    linarith
  have hlog : Real.log (1 + M₀ / t) ≤ u := by
    have hpos : 0 < 1 + M₀ / t := by positivity
    have h1 := Real.log_le_sub_one_of_pos hpos
    have h2 : M₀ / t ≤ u := div_le_div_of_nonneg_right hD₀.le ht.le
    linarith
  have hca : C * A₀ / t ≤ u := by
    dsimp [u, D₀]
    exact div_le_div_of_nonneg_right (by linarith) ht.le
  have hca_nn : 0 ≤ C * A₀ / t := by positivity
  have hum0 : 1 ≤ u ^ m := one_le_pow₀ hu1
  have hum1 : u ≤ u ^ m := by
    simpa using pow_le_pow_right₀ hu1 (by omega : 1 ≤ m)
  have hum2 : u ^ 2 ≤ u ^ m := pow_le_pow_right₀ hu1 (by omega : 2 ≤ m)
  have hca2 : (C * A₀ / t) ^ 2 ≤ u ^ m := (pow_le_pow_left₀ hca_nn hca 2).trans hum2
  have hcam : (C * A₀ / t) ^ m ≤ u ^ m := pow_le_pow_left₀ hca_nn hca m
  have hinner : 1 + Real.log (1 + M₀ / t) + (C * A₀ / t) ^ 2 + (C * A₀ / t) ^ m ≤
      4 * u ^ m := by linarith
  have hk_pos : 0 < kappaK K := kappaK_pos hK
  unfold coverExp
  change 1 + 2 * (kappaK K * (1 + Real.log (1 + M₀ / t) + (C * A₀ / t) ^ 2 + (C * A₀ / t) ^ m)) ≤
    (1 + 8 * kappaK K) * u ^ m
  nlinarith

private lemma four_thirds_le_two_rpow {p : ℝ} (hp : (1 : ℝ) / 2 ≤ p) :
    (4 : ℝ) / 3 ≤ (2 : ℝ) ^ p := by
  have h1 : (4 : ℝ) / 3 ≤ Real.sqrt 2 := by
    rw [Real.le_sqrt (by norm_num) (by norm_num)]
    norm_num
  have h2 : Real.sqrt 2 = (2 : ℝ) ^ ((1 : ℝ) / 2) := Real.sqrt_eq_rpow 2
  rw [h2] at h1
  exact h1.trans (Real.rpow_le_rpow_of_exponent_le (by norm_num) hp)

private lemma geom_three_fourths_le (J : ℕ) :
    ∑ k ∈ Finset.range J, ((3 : ℝ) / 4) ^ k ≤ 4 := by
  rw [geom_sum_eq (by norm_num : ((3 : ℝ) / 4) ≠ 1)]
  have h1 : (((3 : ℝ) / 4) ^ J - 1) / ((3 : ℝ) / 4 - 1) = 4 - 4 * ((3 : ℝ) / 4) ^ J := by ring
  rw [h1]
  have hnn : 0 ≤ ((3 : ℝ) / 4) ^ J := by positivity
  linarith

private lemma avg_radSupSample_le_case_large
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n) (hm3 : 3 ≤ K - 1)
    {L R C M₀ : ℝ} (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀)
    (z : Fin n → Metric.closedBall (0 : X) L × Fin K) :
    let m : ℕ := K - 1
    let D₀ : ℝ := M₀ + C * (L * R)
    (((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool, radSupSample K n L R C M₀ σ z) ≤
      chainConst K * D₀ * ((n : ℝ) ^ (-(1 : ℝ) / (m : ℝ))) := by
  intro m D₀
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  have hm_real : (3 : ℝ) ≤ (m : ℝ) := by exact_mod_cast hm3
  have hm_pos : (0 : ℝ) < (m : ℝ) := by linarith
  have hA₀ : 0 < L * R := mul_pos hL hR
  have hD₀_pos : 0 < D₀ := by dsimp [D₀]; positivity
  let α : ℝ := D₀ * ((n : ℝ) ^ (-(1 : ℝ) / (m : ℝ)))
  have hα_pos : 0 < α := mul_pos hD₀_pos (Real.rpow_pos_of_pos hn_pos _)
  set C₁ : ℝ := Real.sqrt (2 * (1 + 8 * kappaK K))
  have hC₁_nn : 0 ≤ C₁ := Real.sqrt_nonneg _
  rcases le_or_gt M₀ α with hMα | hαM
  · have hchain0 := radSupSample_chaining_le hK hn hL hR hC hM₀ z 0
    simp only [tScale_zero, Finset.range_zero, Finset.sum_empty, add_zero] at hchain0
    have h1c : (1 : ℝ) ≤ chainConst K := by
      unfold chainConst
      have : 0 ≤ Real.sqrt (2 * (1 + 8 * kappaK K)) * (2 : ℝ) ^ K :=
        mul_nonneg (Real.sqrt_nonneg _) (by positivity)
      linarith
    calc (((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool, radSupSample K n L R C M₀ σ z)
        ≤ M₀ := hchain0
      _ ≤ 1 * α := by linarith
      _ ≤ chainConst K * α := mul_le_mul_of_nonneg_right h1c hα_pos.le
      _ = chainConst K * D₀ * ((n : ℝ) ^ (-(1 : ℝ) / (m : ℝ))) := by
          dsimp [α]; ring
  · have hlog2_pos : 0 < Real.log 2 := Real.log_pos (by norm_num)
    have hquot_gt1 : 1 < M₀ / α := (one_lt_div hα_pos).mpr hαM
    have hx₀_pos : 0 < Real.log (M₀ / α) / Real.log 2 :=
      div_pos (Real.log_pos hquot_gt1) hlog2_pos
    let zK : ℤ := ⌊Real.log (M₀ / α) / Real.log 2⌋
    have hzK_nn : 0 ≤ zK := Int.floor_nonneg.mpr hx₀_pos.le
    let K₀ : ℕ := Int.toNat zK
    let J : ℕ := K₀ + 1
    have hK₀_cast : (K₀ : ℝ) = (zK : ℝ) := by
      have hz : (K₀ : ℤ) = zK := Int.toNat_of_nonneg hzK_nn
      exact_mod_cast hz
    have htJ_ge : α / 2 ≤ tScale M₀ J := by
      have hf : (K₀ : ℝ) ≤ Real.log (M₀ / α) / Real.log 2 := by
        rw [hK₀_cast]
        exact Int.floor_le _
      have hlog_le : Real.log ((2 : ℝ) ^ K₀) ≤ Real.log (M₀ / α) := by
        rw [Real.log_pow]
        exact ( le_div_iff₀ hlog2_pos ).mp hf
      have hpow_le : (2 : ℝ) ^ K₀ ≤ M₀ / α := by
        have hexp := Real.exp_le_exp.mpr hlog_le
        rwa [Real.exp_log (by positivity), Real.exp_log (by positivity)] at hexp
      have hα_le : α ≤ tScale M₀ K₀ := by
        unfold tScale
        rw [le_div_iff₀ (by positivity)]
        have := (le_div_iff₀ hα_pos).mp hpow_le
        linarith
      dsimp [J]
      rw [tScale_succ]
      linarith
    have htJ_le : tScale M₀ J ≤ α := by
      have hf : Real.log (M₀ / α) / Real.log 2 < (J : ℝ) := by
        dsimp [J]
        push_cast
        rw [hK₀_cast]
        exact Int.lt_floor_add_one _
      have hlog_lt : Real.log (M₀ / α) < Real.log ((2 : ℝ) ^ J) := by
        rw [Real.log_pow]
        exact (div_lt_iff₀ hlog2_pos).mp hf
      have hpow_gt : M₀ / α < (2 : ℝ) ^ J := by
        have hexp := Real.exp_lt_exp.mpr hlog_lt
        rwa [Real.exp_log (by positivity), Real.exp_log (by positivity)] at hexp
      unfold tScale
      rw [div_le_iff₀ (by positivity)]
      have := (div_lt_iff₀ hα_pos).mp hpow_gt
      linarith
    let p : ℝ := (m : ℝ) / 2 - 1
    have hp_half : (1 : ℝ) / 2 ≤ p := by dsimp [p]; linarith
    have hp_pos : 0 < p := by linarith
    let β : ℝ := (n : ℝ) ^ ((1 : ℝ) / (m : ℝ))
    have hβ_pos : 0 < β := Real.rpow_pos_of_pos hn_pos _
    have hD_eq : D₀ = α * β := by
      dsimp [α, β]
      rw [mul_assoc, ← Real.rpow_add hn_pos]
      have hzero : -(1 : ℝ) / (m : ℝ) + (1 : ℝ) / (m : ℝ) = 0 := by ring
      rw [hzero, Real.rpow_zero, mul_one]
    have hβ_pow : β ^ ((m : ℝ) / 2) = Real.sqrt (n : ℝ) := by
      dsimp [β]
      rw [← Real.rpow_mul hn_pos.le]
      have hexp : ((1 : ℝ) / (m : ℝ)) * ((m : ℝ) / 2) = (1 : ℝ) / 2 := by
        field_simp
      rw [hexp, ← Real.sqrt_eq_rpow]
    have hD_ratio : D₀ ^ ((m : ℝ) / 2) / Real.sqrt (n : ℝ) = α * α ^ p := by
      rw [hD_eq, Real.mul_rpow hα_pos.le hβ_pos.le, hβ_pow,
        mul_div_cancel_right₀ _ (Real.sqrt_pos.mpr hn_pos).ne']
      calc α ^ ((m : ℝ) / 2) = α ^ (1 + p) := by
            congr 1; dsimp [p]; ring
        _ = α ^ (1 : ℝ) * α ^ p := Real.rpow_add hα_pos 1 p
        _ = α * α ^ p := by rw [Real.rpow_one]
    have hα_cancel : (α * α ^ p) / (α / 2) ^ p = (2 : ℝ) ^ p * α := by
      rw [Real.div_rpow hα_pos.le zero_le_two]
      have hαp_ne : α ^ p ≠ 0 := (Real.rpow_pos_of_pos hα_pos p).ne'
      have h2p_ne : (2 : ℝ) ^ p ≠ 0 := (Real.rpow_pos_of_pos zero_lt_two p).ne'
      field_simp
    have hterm : ∀ j ∈ Finset.range J,
        2 * tScale M₀ j *
            Real.sqrt (2 * (1 + 2 * coverExp K (L * R) C M₀ (tScale M₀ (j + 1))) / (n : ℝ)) ≤
          4 * C₁ * (2 : ℝ) ^ p * α * ((3 : ℝ) / 4) ^ (J - 1 - j) := by
      intro j hj
      have hjJ : j < J := Finset.mem_range.mp hj
      let k : ℕ := J - 1 - j
      have hjk : (j + 1) + k = J := by omega
      set t : ℝ := tScale M₀ (j + 1)
      have ht_pos : 0 < t := tScale_pos hM₀ (j + 1)
      have ht_le : t ≤ M₀ := tScale_le_self hM₀ (j + 1)
      have hcov_le := coverExp_bound_gt_two hK hm3 hA₀ hC hM₀ ht_pos ht_le
      have hu_pos : 0 < D₀ / t := div_pos hD₀_pos ht_pos
      have hu_pow : (D₀ / t) ^ m = ((D₀ / t) ^ ((m : ℝ) / 2)) ^ 2 := by
        rw [← Real.rpow_natCast, sq, ← Real.rpow_add hu_pos, add_halves]
      have hrad :
          Real.sqrt (2 * (1 + 2 * coverExp K (L * R) C M₀ t) / (n : ℝ)) ≤
            C₁ * (D₀ / t) ^ ((m : ℝ) / 2) / Real.sqrt (n : ℝ) := by
        refine Real.sqrt_le_iff.mpr ⟨by positivity, ?_⟩
        have hC₁_sq : C₁ ^ 2 = 2 * (1 + 8 * kappaK K) :=
          Real.sq_sqrt (by have := kappaK_pos hK; positivity)
        have hsq_n : Real.sqrt (n : ℝ) ^ 2 = (n : ℝ) := Real.sq_sqrt hn_pos.le
        calc 2 * (1 + 2 * coverExp K (L * R) C M₀ t) / (n : ℝ)
            ≤ 2 * ((1 + 8 * kappaK K) * (D₀ / t) ^ m) / (n : ℝ) := by
              gcongr
          _ = (C₁ * (D₀ / t) ^ ((m : ℝ) / 2) / Real.sqrt (n : ℝ)) ^ 2 := by
              rw [hu_pow, div_pow, mul_pow, hC₁_sq, hsq_n]
              ring
      have ht_rel : tScale M₀ j = 2 * t := by
        dsimp [t]
        rw [tScale_succ]
        ring
      have ht_pow : t ^ ((m : ℝ) / 2) = t * t ^ p := by
        calc t ^ ((m : ℝ) / 2) = t ^ (1 + p) := by
              congr 1; dsimp [p]; ring
          _ = t ^ (1 : ℝ) * t ^ p := Real.rpow_add ht_pos 1 p
          _ = t * t ^ p := by rw [Real.rpow_one]
      have ht_lower : (2 : ℝ) ^ k * (α / 2) ≤ t := by
        have hscale_eq : t = (2 : ℝ) ^ k * tScale M₀ J := by
          dsimp [t]
          unfold tScale
          rw [← hjk, pow_add]
          field_simp
          rw [pow_add, pow_succ]
        rw [hscale_eq]
        exact mul_le_mul_of_nonneg_left htJ_ge (by positivity)
      have h2k_pow : ((2 : ℝ) ^ k) ^ p = ((2 : ℝ) ^ p) ^ k := by
        rw [← Real.rpow_natCast (2 : ℝ) k, ← Real.rpow_mul zero_le_two,
          ← Real.rpow_natCast ((2 : ℝ) ^ p) k, ← Real.rpow_mul zero_le_two, mul_comm]
      have hdecay : 1 / ((2 : ℝ) ^ k) ^ p ≤ ((3 : ℝ) / 4) ^ k := by
        rw [h2k_pow]
        have h43 : (4 : ℝ) / 3 ≤ (2 : ℝ) ^ p := four_thirds_le_two_rpow hp_half
        have hpow_le : ((4 : ℝ) / 3) ^ k ≤ ((2 : ℝ) ^ p) ^ k :=
          pow_le_pow_left₀ (by norm_num) h43 k
        calc 1 / ((2 : ℝ) ^ p) ^ k
            ≤ 1 / ((4 : ℝ) / 3) ^ k :=
              one_div_le_one_div_of_le (by positivity) hpow_le
          _ = ((3 : ℝ) / 4) ^ k := by
              rw [one_div, ← inv_pow]
              norm_num
      have htp_inv :
          1 / t ^ p ≤ ((3 : ℝ) / 4) ^ k * (1 / (α / 2) ^ p) := by
        have hrpow_le : ((2 : ℝ) ^ k * (α / 2)) ^ p ≤ t ^ p :=
          Real.rpow_le_rpow (by positivity) ht_lower hp_pos.le
        have h1 : 1 / t ^ p ≤ 1 / ((2 : ℝ) ^ k * (α / 2)) ^ p :=
          one_div_le_one_div_of_le (Real.rpow_pos_of_pos (by positivity) p) hrpow_le
        refine h1.trans ?_
        rw [Real.mul_rpow (by positivity) (by positivity)]
        simp only [one_div, mul_inv]
        exact mul_le_mul_of_nonneg_right (by simpa only [one_div] using hdecay) (by positivity)
      calc 2 * tScale M₀ j *
              Real.sqrt (2 * (1 + 2 * coverExp K (L * R) C M₀ t) / (n : ℝ))
          ≤ 2 * (2 * t) * (C₁ * (D₀ / t) ^ ((m : ℝ) / 2) / Real.sqrt (n : ℝ)) := by
              rw [ht_rel]
              exact mul_le_mul_of_nonneg_left hrad (by positivity)
        _ = 4 * C₁ * (D₀ ^ ((m : ℝ) / 2) / Real.sqrt (n : ℝ)) * (t / t ^ ((m : ℝ) / 2)) := by
              rw [Real.div_rpow hD₀_pos.le ht_pos.le]
              ring
        _ = 4 * C₁ * (α * α ^ p) * (1 / t ^ p) := by
              rw [hD_ratio, ht_pow]
              have ht0 : t ≠ 0 := ht_pos.ne'
              field_simp
        _ ≤ 4 * C₁ * (α * α ^ p) * (((3 : ℝ) / 4) ^ k * (1 / (α / 2) ^ p)) :=
              mul_le_mul_of_nonneg_left htp_inv (by positivity)
        _ = 4 * C₁ * ((α * α ^ p) / (α / 2) ^ p) * ((3 : ℝ) / 4) ^ k := by ring
        _ = 4 * C₁ * (2 : ℝ) ^ p * α * ((3 : ℝ) / 4) ^ k := by
              rw [hα_cancel]
              ring
    have hsum :
        ∑ j ∈ Finset.range J,
            2 * tScale M₀ j *
              Real.sqrt (2 * (1 + 2 * coverExp K (L * R) C M₀ (tScale M₀ (j + 1))) / (n : ℝ)) ≤
          16 * C₁ * (2 : ℝ) ^ p * α := by
      calc ∑ j ∈ Finset.range J,
              2 * tScale M₀ j *
                Real.sqrt (2 * (1 + 2 * coverExp K (L * R) C M₀ (tScale M₀ (j + 1))) / (n : ℝ))
          ≤ ∑ j ∈ Finset.range J,
              4 * C₁ * (2 : ℝ) ^ p * α * ((3 : ℝ) / 4) ^ (J - 1 - j) :=
              Finset.sum_le_sum hterm
        _ = 4 * C₁ * (2 : ℝ) ^ p * α *
              ∑ j ∈ Finset.range J, ((3 : ℝ) / 4) ^ (J - 1 - j) := by
              rw [← Finset.mul_sum]
        _ = 4 * C₁ * (2 : ℝ) ^ p * α * ∑ k ∈ Finset.range J, ((3 : ℝ) / 4) ^ k := by
              rw [Finset.sum_range_reflect (fun k => ((3 : ℝ) / 4) ^ k) J]
        _ ≤ 4 * C₁ * (2 : ℝ) ^ p * α * 4 :=
              mul_le_mul_of_nonneg_left (geom_three_fourths_le J) (by positivity)
        _ = 16 * C₁ * (2 : ℝ) ^ p * α := by ring
    have hp_le_K : (2 : ℝ) ^ p ≤ (2 : ℝ) ^ K := by
      have hmK : (m : ℝ) ≤ (K : ℝ) := by
        dsimp [m]
        exact_mod_cast Nat.sub_le K 1
      have hpK : p ≤ (K : ℝ) := by dsimp [p]; linarith
      simpa [Real.rpow_natCast] using
        Real.rpow_le_rpow_of_exponent_le (by norm_num : (1 : ℝ) ≤ 2) hpK
    have hchain := radSupSample_chaining_le hK hn hL hR hC hM₀ z J
    refine (hchain.trans (add_le_add htJ_le hsum)).trans ?_
    have hconst : 1 + 16 * C₁ * (2 : ℝ) ^ p ≤ chainConst K := by
      unfold chainConst
      change 1 + 16 * C₁ * (2 : ℝ) ^ p ≤ 4 + 32 * C₁ * (2 : ℝ) ^ K
      have hmul : C₁ * (2 : ℝ) ^ p ≤ C₁ * (2 : ℝ) ^ K :=
        mul_le_mul_of_nonneg_left hp_le_K hC₁_nn
      have hnn : 0 ≤ C₁ * (2 : ℝ) ^ K := mul_nonneg hC₁_nn (by positivity)
      linarith
    calc α + 16 * C₁ * (2 : ℝ) ^ p * α
        = (1 + 16 * C₁ * (2 : ℝ) ^ p) * α := by ring
      _ ≤ chainConst K * α := mul_le_mul_of_nonneg_right hconst hα_pos.le
      _ = chainConst K * D₀ * ((n : ℝ) ^ (-(1 : ℝ) / (m : ℝ))) := by
          dsimp [α]; ring

/-- Pointwise empirical Rademacher complexity bound via finite Massart + dyadic Dudley chaining. -/
theorem avg_radSupSample_le
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R C M₀ : ℝ} (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀)
    (z : Fin n → Metric.closedBall (0 : X) L × Fin K) :
    let m : ℕ := K - 1
    let D₀ : ℝ := M₀ + C * (L * R)
    (((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool, radSupSample K n L R C M₀ σ z) ≤
      if m ≤ 2 then
        chainConst K * D₀ * Real.log (2 * (n : ℝ)) / Real.sqrt (n : ℝ)
      else
        chainConst K * D₀ * ((n : ℝ) ^ (-(1 : ℝ) / (m : ℝ))) := by
  dsimp only
  by_cases hm : K - 1 ≤ 2
  · rw [if_pos hm]
    exact avg_radSupSample_le_case_small hK hn hm hL hR hC hM₀ z
  · rw [if_neg hm]
    exact avg_radSupSample_le_case_large hK hn (by omega) hL hR hC hM₀ z

end UL.Proof_lem_C_3_Race2

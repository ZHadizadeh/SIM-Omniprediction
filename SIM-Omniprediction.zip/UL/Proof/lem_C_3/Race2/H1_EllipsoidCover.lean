import Mathlib
import UL.Def.def_2_1
import UL.Def.def_5_smooth
import UL.Proof.lem_C_2.H1_HilbertSchmidt
import UL.Proof.lem_C_2.ZeroSumDimension
set_option autoImplicit false

namespace UL.Proof_lem_C_3_Race2

section Helpers

/-- Radial clamping onto the closed ball of radius `A₀` around `0`. -/
private noncomputable def clampH {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]
    (A₀ : ℝ) (u : H) : H :=
  (A₀ / max A₀ ‖u‖) • u

private lemma norm_clampH_le {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]
    {A₀ : ℝ} (hA₀ : 0 < A₀) (u : H) :
    ‖clampH A₀ u‖ ≤ A₀ := by
  unfold clampH
  have hmax_pos : 0 < max A₀ ‖u‖ := lt_of_lt_of_le hA₀ (le_max_left _ _)
  have hdiv_nonneg : 0 ≤ A₀ / max A₀ ‖u‖ := div_nonneg hA₀.le hmax_pos.le
  rw [norm_smul, Real.norm_eq_abs, abs_of_nonneg hdiv_nonneg, div_mul_eq_mul_div,
    div_le_iff₀ hmax_pos]
  exact mul_le_mul_of_nonneg_left (le_max_right A₀ ‖u‖) hA₀.le

private lemma norm_sub_clampH_sq_le {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]
    {A₀ : ℝ} (hA₀ : 0 < A₀) {y : H} (hy : ‖y‖ ≤ A₀) (u : H) :
    ‖y - clampH A₀ u‖ ^ 2 ≤ ‖y - u‖ ^ 2 := by
  unfold clampH
  by_cases hu : ‖u‖ ≤ A₀
  · rw [max_eq_left hu, div_self hA₀.ne', one_smul]
  · push_neg at hu
    have hu_pos : 0 < ‖u‖ := lt_trans hA₀ hu
    rw [max_eq_right hu.le]
    set θ : ℝ := A₀ / ‖u‖
    have hθ_pos : 0 < θ := div_pos hA₀ hu_pos
    have hθ_lt : θ < 1 := (div_lt_one hu_pos).mpr hu
    have hθ_mul : θ * ‖u‖ = A₀ := div_mul_cancel₀ A₀ hu_pos.ne'
    have hcs : inner ℝ y u ≤ θ * ‖u‖ ^ 2 := by
      calc inner ℝ y u
          ≤ ‖y‖ * ‖u‖ := real_inner_le_norm y u
        _ ≤ A₀ * ‖u‖ := mul_le_mul_of_nonneg_right hy hu_pos.le
        _ = θ * ‖u‖ ^ 2 := by rw [← hθ_mul]; ring
    have hsmul_norm : ‖θ • u‖ ^ 2 = θ ^ 2 * ‖u‖ ^ 2 := by
      rw [norm_smul, Real.norm_eq_abs, abs_of_pos hθ_pos, mul_pow]
    have h1 := norm_sub_sq_real y u
    have h2 := norm_sub_sq_real y (θ • u)
    rw [inner_smul_right, hsmul_norm] at h2
    have hdiff : 0 ≤ (1 - θ) * ((1 + θ) * ‖u‖ ^ 2 - 2 * inner ℝ y u) := by
      refine mul_nonneg (by linarith) ?_
      nlinarith [sq_nonneg ‖u‖]
    nlinarith

private lemma factor_le_exp_twelve_sq {u : ℝ} (hu : 1 / 2 < u) :
    Real.sqrt 2 * (1 + 4 * u) ≤ Real.exp (12 * u ^ 2) := by
  have hsqrt2_le : Real.sqrt 2 ≤ Real.exp 1 := by
    have h2 : Real.sqrt 2 ≤ 2 := Real.sqrt_le_iff.mpr ⟨by norm_num, by norm_num⟩
    have hexp1 : (2 : ℝ) ≤ Real.exp 1 := by
      have h := Real.add_one_le_exp 1
      linarith
    exact le_trans h2 hexp1
  have hlin_le : 1 + 4 * u ≤ Real.exp (4 * u) := by
    have h := Real.add_one_le_exp (4 * u)
    linarith
  have hprod : Real.sqrt 2 * (1 + 4 * u) ≤ Real.exp (1 + 4 * u) := by
    rw [Real.exp_add]
    exact mul_le_mul hsqrt2_le hlin_le (by linarith) (Real.exp_pos 1).le
  have hquad : 1 + 4 * u ≤ 12 * u ^ 2 := by
    have hpos : 0 < (2 * u - 1) * (6 * u + 1) := mul_pos (by linarith) (by linarith)
    nlinarith
  exact le_trans hprod (Real.exp_le_exp.mpr hquad)

private lemma pointwise_ellipsoid_minkowski_sq {b s z w : ℝ} (hb : 0 < b) (hs : 0 < s) :
    ((b * z + s * w) / (Real.sqrt 2 * (b + s))) ^ 2 ≤ (z ^ 2 + w ^ 2) / 2 := by
  have hbs : 0 < b + s := add_pos hb hs
  have hden_sq : (Real.sqrt 2 * (b + s)) ^ 2 = 2 * (b + s) ^ 2 := by
    rw [mul_pow, Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)]
  rw [div_pow, hden_sq, div_le_div_iff₀ (by positivity) (by norm_num : (0 : ℝ) < 2)]
  have hnonneg : 0 ≤ (b * w - s * z) ^ 2 + 2 * b * s * (z ^ 2 + w ^ 2) :=
    add_nonneg (sq_nonneg _) (mul_nonneg (by positivity) (add_nonneg (sq_nonneg _) (sq_nonneg _)))
  nlinarith

/-- Volume-packing construction of an `(ε₁ / 2)`-net for the `N`-dimensional coordinate ellipsoid
`{u : ∃ z, ‖z‖ ≤ 1 ∧ ∀ r, u r = b r * z r}` when `b r > ε₁ / 2` and `∑ r, b r ^ 2 ≤ B_sq`. -/
private lemma exists_finite_ellipsoid_net
    {N : ℕ} (hN : 1 ≤ N)
    {ε₁ B_sq : ℝ} (hε₁ : 0 < ε₁) (hB : 0 ≤ B_sq)
    (b : Fin N → ℝ) (hb : ∀ r : Fin N, ε₁ / 2 < b r)
    (hb_sum : ∑ r : Fin N, b r ^ 2 ≤ B_sq) :
    ∃ F : Finset (EuclideanSpace ℝ (Fin N)),
      F.Nonempty ∧
      (F.card : ℝ) ≤ Real.exp (12 * (B_sq / ε₁ ^ 2)) ∧
      ∀ u : EuclideanSpace ℝ (Fin N),
        (∃ z : EuclideanSpace ℝ (Fin N), ‖z‖ ≤ 1 ∧ ∀ r : Fin N, u r = b r * z r) →
        ∃ c ∈ F, dist u c ≤ ε₁ / 2 := by
  classical
  haveI : Nonempty (Fin N) := ⟨⟨0, by omega⟩⟩
  let E_N : Set (EuclideanSpace ℝ (Fin N)) :=
    {u | ∃ z : EuclideanSpace ℝ (Fin N), ‖z‖ ≤ 1 ∧ ∀ r : Fin N, u r = b r * z r}
  let IsSep : Finset (EuclideanSpace ℝ (Fin N)) → Prop := fun F =>
    (∀ x ∈ F, x ∈ E_N) ∧ ∀ x ∈ F, ∀ y ∈ F, x ≠ y → ε₁ / 2 ≤ dist x y
  let s : ℝ := ε₁ / 4
  have hs : 0 < s := by dsimp [s]; positivity
  have hb_pos : ∀ r : Fin N, 0 < b r := fun r => lt_trans (by positivity) (hb r)
  let d_vec : Fin N → ℝ := fun r => Real.sqrt 2 * (b r + s)
  have hd_pos : ∀ r : Fin N, 0 < d_vec r := fun r =>
    mul_pos (Real.sqrt_pos.mpr (by norm_num)) (add_pos (hb_pos r) hs)
  let D : EuclideanSpace ℝ (Fin N) →ₗ[ℝ] EuclideanSpace ℝ (Fin N) :=
    Matrix.toEuclideanLin (Matrix.diagonal d_vec)
  have hD_apply : ∀ (q : EuclideanSpace ℝ (Fin N)) (r : Fin N), D q r = d_vec r * q r := by
    intro q r
    change Matrix.mulVec (Matrix.diagonal d_vec) (WithLp.ofLp q) r = d_vec r * q r
    rw [Matrix.mulVec_diagonal]
  have hD_det : |LinearMap.det D| = ∏ r : Fin N, d_vec r := by
    have hdet : LinearMap.det D = ∏ r : Fin N, d_vec r := by
      dsimp [D]
      rw [Matrix.toEuclideanLin_eq_toLin, LinearMap.det_toLin, Matrix.det_diagonal]
    rw [hdet, abs_of_nonneg (Finset.prod_nonneg fun r _ => (hd_pos r).le)]
  have h_sep_bound : ∀ F : Finset (EuclideanSpace ℝ (Fin N)), IsSep F →
      (F.card : ℝ) ≤ Real.exp (12 * (B_sq / ε₁ ^ 2)) := by
    intro F hF
    have h_disj : Set.PairwiseDisjoint (↑F : Set (EuclideanSpace ℝ (Fin N)))
        (fun c => Metric.ball c s) := by
      intro x hx y hy hxy
      change Disjoint (Metric.ball x s) (Metric.ball y s)
      rw [Set.disjoint_left]
      intro p hpx hpy
      rw [Metric.mem_ball] at hpx hpy
      have hsep := hF.2 x hx y hy hxy
      have htri := dist_triangle_left x y p
      dsimp [s] at hpx hpy
      linarith
    have h_sub : (⋃ c ∈ F, Metric.ball c s) ⊆ D '' Metric.closedBall 0 1 := by
      refine Set.iUnion₂_subset fun c hc p hp => ?_
      rcases hF.1 c hc with ⟨z, hz_norm, hcz⟩
      rw [Metric.mem_ball, dist_eq_norm] at hp
      let w : EuclideanSpace ℝ (Fin N) := (1 / s) • (p - c)
      have hw_norm : ‖w‖ ≤ 1 := by
        dsimp [w]
        rw [norm_smul, Real.norm_eq_abs, abs_of_pos (one_div_pos.mpr hs), one_div_mul_eq_div,
          div_le_one hs]
        exact hp.le
      let q : EuclideanSpace ℝ (Fin N) := WithLp.toLp 2 (fun r : Fin N => p r / d_vec r)
      refine ⟨q, ?_, ?_⟩
      · rw [Metric.mem_closedBall, dist_zero_right]
        have hq_sq : ‖q‖ ^ 2 ≤ 1 := by
          rw [EuclideanSpace.norm_sq_eq]
          have hpw : ∀ r : Fin N, ‖q r‖ ^ 2 ≤ (‖z r‖ ^ 2 + ‖w r‖ ^ 2) / 2 := by
            intro r
            simp only [Real.norm_eq_abs, sq_abs]
            have hq_r : q r = (b r * z r + s * w r) / (Real.sqrt 2 * (b r + s)) := by
              have hw_r : s * w r = p r - c r := by
                dsimp [w]
                change s * ((1 / s) * (p r - c r)) = p r - c r
                field_simp [hs.ne']
              have hp_r : p r = b r * z r + s * w r := by linarith [hcz r]
              change p r / d_vec r = _
              rw [hp_r]
            rw [hq_r]
            exact pointwise_ellipsoid_minkowski_sq (hb_pos r) hs
          calc ∑ r : Fin N, ‖q r‖ ^ 2
              ≤ ∑ r : Fin N, (‖z r‖ ^ 2 + ‖w r‖ ^ 2) / 2 :=
                Finset.sum_le_sum fun r _ => hpw r
            _ = ((∑ r : Fin N, ‖z r‖ ^ 2) + (∑ r : Fin N, ‖w r‖ ^ 2)) / 2 := by
                rw [← Finset.sum_div, Finset.sum_add_distrib]
            _ = (‖z‖ ^ 2 + ‖w‖ ^ 2) / 2 := by
                rw [← EuclideanSpace.norm_sq_eq, ← EuclideanSpace.norm_sq_eq]
            _ ≤ 1 := by
                have hz2 : ‖z‖ ^ 2 ≤ 1 := by nlinarith [norm_nonneg z]
                have hw2 : ‖w‖ ^ 2 ≤ 1 := by nlinarith [norm_nonneg w]
                linarith
        nlinarith [norm_nonneg q]
      · ext r
        rw [hD_apply]
        change d_vec r * (p r / d_vec r) = p r
        exact mul_div_cancel₀ (p r) (hd_pos r).ne'
    let μ : MeasureTheory.Measure (EuclideanSpace ℝ (Fin N)) := MeasureTheory.volume
    have I : (F.card : ENNReal) *
        ENNReal.ofReal (s ^ Module.finrank ℝ (EuclideanSpace ℝ (Fin N))) * μ (Metric.ball 0 1) ≤
        ENNReal.ofReal |LinearMap.det D| * μ (Metric.ball 0 1) :=
      calc (F.card : ENNReal) *
          ENNReal.ofReal (s ^ Module.finrank ℝ (EuclideanSpace ℝ (Fin N))) *
          μ (Metric.ball 0 1)
          = μ (⋃ c ∈ F, Metric.ball c s) := by
              rw [MeasureTheory.measure_biUnion_finset h_disj fun _ _ => measurableSet_ball]
              simp only [μ.addHaar_ball_of_pos _ hs, Finset.sum_const, nsmul_eq_mul, mul_assoc]
        _ ≤ μ (D '' Metric.closedBall 0 1) := MeasureTheory.measure_mono h_sub
        _ = ENNReal.ofReal |LinearMap.det D| * μ (Metric.ball 0 1) := by
              rw [μ.addHaar_image_linearMap, μ.addHaar_unitClosedBall_eq_addHaar_unitBall]
    have J : (F.card : ENNReal) *
        ENNReal.ofReal (s ^ Module.finrank ℝ (EuclideanSpace ℝ (Fin N))) ≤
        ENNReal.ofReal |LinearMap.det D| :=
      (ENNReal.mul_le_mul_iff_left (Metric.measure_ball_pos _ _ zero_lt_one).ne'
        MeasureTheory.measure_ball_lt_top.ne).mp I
    have hfinrank : Module.finrank ℝ (EuclideanSpace ℝ (Fin N)) = N := finrank_euclideanSpace_fin
    rw [hfinrank] at J
    have K := ENNReal.toReal_le_of_le_ofReal (abs_nonneg _) J
    rw [ENNReal.toReal_mul, ENNReal.toReal_natCast, ENNReal.toReal_ofReal (pow_nonneg hs.le N),
      hD_det] at K
    have hprod_eq : ∏ r : Fin N, d_vec r =
        (∏ r : Fin N, (Real.sqrt 2 * (1 + 4 * (b r / ε₁)))) * s ^ N := by
      have hs_pow : s ^ N = ∏ _ : Fin N, s := by simp
      rw [hs_pow, ← Finset.prod_mul_distrib]
      refine Finset.prod_congr rfl fun r _ => ?_
      dsimp [d_vec, s]
      field_simp [hε₁.ne']
      ring
    rw [hprod_eq] at K
    have hcard_prod : (F.card : ℝ) ≤ ∏ r : Fin N, (Real.sqrt 2 * (1 + 4 * (b r / ε₁))) :=
      le_of_mul_le_mul_right K (pow_pos hs N)
    have hprod_exp : ∏ r : Fin N, (Real.sqrt 2 * (1 + 4 * (b r / ε₁))) ≤
        Real.exp (12 * (B_sq / ε₁ ^ 2)) := by
      calc ∏ r : Fin N, (Real.sqrt 2 * (1 + 4 * (b r / ε₁)))
          ≤ ∏ r : Fin N, Real.exp (12 * (b r / ε₁) ^ 2) := by
              refine Finset.prod_le_prod (fun r _ => ?_) (fun r _ => ?_)
              · have hbr := hb_pos r
                positivity
              · refine factor_le_exp_twelve_sq ?_
                rw [lt_div_iff₀ hε₁]
                linarith [hb r]
        _ = Real.exp (∑ r : Fin N, 12 * (b r / ε₁) ^ 2) := (Real.exp_sum _ _).symm
        _ ≤ Real.exp (12 * (B_sq / ε₁ ^ 2)) := by
              apply Real.exp_le_exp.mpr
              have hsum_eq : ∑ r : Fin N, 12 * (b r / ε₁) ^ 2 =
                  (12 / ε₁ ^ 2) * ∑ r : Fin N, b r ^ 2 := by
                rw [Finset.mul_sum]
                refine Finset.sum_congr rfl fun r _ => ?_
                ring
              rw [hsum_eq, show 12 * (B_sq / ε₁ ^ 2) = (12 / ε₁ ^ 2) * B_sq by ring]
              exact mul_le_mul_of_nonneg_left hb_sum (by positivity)
    exact le_trans hcard_prod hprod_exp
  let B_nat : ℕ := Nat.floor (Real.exp (12 * (B_sq / ε₁ ^ 2)))
  have h_card_le_B : ∀ F : Finset (EuclideanSpace ℝ (Fin N)), IsSep F → F.card ≤ B_nat :=
    fun F hF => Nat.le_floor (h_sep_bound F hF)
  let cards : Finset ℕ := (Finset.range (B_nat + 1)).filter (fun k => ∃ F, IsSep F ∧ F.card = k)
  have h0_mem_E : (0 : EuclideanSpace ℝ (Fin N)) ∈ E_N :=
    ⟨0, by simp, fun r => by simp⟩
  have hF0_sep : IsSep ({0} : Finset (EuclideanSpace ℝ (Fin N))) := by
    refine ⟨fun x hx => ?_, fun x hx y hy hxy => ?_⟩
    · rw [Finset.mem_singleton] at hx
      rwa [hx]
    · rw [Finset.mem_singleton] at hx hy
      exact False.elim (hxy (hx.trans hy.symm))
  have h1_mem : 1 ∈ cards := by
    rw [Finset.mem_filter, Finset.mem_range]
    refine ⟨Nat.lt_succ_of_le (by simpa using h_card_le_B {0} hF0_sep), ⟨{0}, hF0_sep, by simp⟩⟩
  let k_max : ℕ := cards.max' ⟨1, h1_mem⟩
  have hk_max_mem : k_max ∈ cards := Finset.max'_mem cards ⟨1, h1_mem⟩
  rcases (Finset.mem_filter.mp hk_max_mem).2 with ⟨F_star, hF_star_sep, hF_star_card⟩
  refine ⟨F_star, ?_, h_sep_bound F_star hF_star_sep, ?_⟩
  · rw [Finset.nonempty_iff_ne_empty]
    intro hemp
    have hk_ge_1 : 1 ≤ k_max := Finset.le_max' cards 1 h1_mem
    rw [← hF_star_card, hemp, Finset.card_empty] at hk_ge_1
    omega
  · intro u hu
    by_cases hu_mem : u ∈ F_star
    · exact ⟨u, hu_mem, by rw [dist_self]; positivity⟩
    · by_contra! h_far
      have hF'_sep : IsSep (insert u F_star) := by
        refine ⟨fun x hx => ?_, fun x hx y hy hxy => ?_⟩
        · rcases Finset.mem_insert.mp hx with rfl | hx'
          · exact hu
          · exact hF_star_sep.1 x hx'
        · rcases Finset.mem_insert.mp hx with rfl | hx' <;>
            rcases Finset.mem_insert.mp hy with rfl | hy'
          · exact False.elim (hxy rfl)
          · exact (h_far y hy').le
          · rw [dist_comm]
            exact (h_far x hx').le
          · exact hF_star_sep.2 x hx' y hy' hxy
      have hF'_mem : (insert u F_star).card ∈ cards := by
        rw [Finset.mem_filter, Finset.mem_range]
        exact ⟨Nat.lt_succ_of_le (h_card_le_B _ hF'_sep), ⟨insert u F_star, hF'_sep, rfl⟩⟩
      have hle : (insert u F_star).card ≤ k_max := Finset.le_max' cards _ hF'_mem
      rw [Finset.card_insert_of_notMem hu_mem, hF_star_card] at hle
      omega

/-- Scalar 1-row empirical `L²` covering bound on `EuclideanSpace ℝ (Fin d)`. -/
private lemma exists_scalar_ellipsoid_cover
    {d n : ℕ} (hn : 1 ≤ n)
    {L R ε₁ : ℝ} (hL : 0 < L) (hR : 0 < R) (hε₁ : 0 < ε₁)
    (ξ : Fin n → EuclideanSpace ℝ (Fin d)) (hξ : ∀ i : Fin n, ‖ξ i‖ ≤ L) :
    ∃ G₁ : Finset (Fin n → ℝ),
      G₁.Nonempty ∧
      (G₁.card : ℝ) ≤ Real.exp (12 * (L * R / ε₁) ^ 2) ∧
      ∀ v : EuclideanSpace ℝ (Fin d), ‖v‖ ≤ R →
        ∃ g ∈ G₁, ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (inner ℝ v (ξ i) - g i) ^ 2 ≤ ε₁ ^ 2 := by
  classical
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  let U : EuclideanSpace ℝ (Fin d) →ₗ[ℝ] EuclideanSpace ℝ (Fin n) :=
    { toFun := fun v => WithLp.toLp 2 (fun i : Fin n => (1 / Real.sqrt (n : ℝ)) * inner ℝ v (ξ i))
      map_add' := fun v w => by
        ext i
        simp [inner_add_left, mul_add]
      map_smul' := fun c v => by
        ext i
        simp [inner_smul_left, mul_left_comm] }
  have hU_apply : ∀ (v : EuclideanSpace ℝ (Fin d)) (i : Fin n),
      U v i = (1 / Real.sqrt (n : ℝ)) * inner ℝ v (ξ i) := fun _ _ => rfl
  have hU_dist_sq : ∀ v w : EuclideanSpace ℝ (Fin d),
      ‖U v - U w‖ ^ 2 = ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (inner ℝ v (ξ i) - inner ℝ w (ξ i)) ^ 2 := by
    intro v w
    rw [EuclideanSpace.norm_sq_eq, Finset.mul_sum]
    refine Finset.sum_congr rfl fun i _ => ?_
    change ‖U v i - U w i‖ ^ 2 = _
    rw [Real.norm_eq_abs, sq_abs, hU_apply, hU_apply, ← mul_sub, mul_pow, div_pow, one_pow,
      Real.sq_sqrt hn_pos.le]
  let S : EuclideanSpace ℝ (Fin d) →ₗ[ℝ] EuclideanSpace ℝ (Fin d) := U.adjoint.comp U
  have hS : S.IsSymmetric := by
    intro v w
    dsimp [S]
    rw [LinearMap.adjoint_inner_left, LinearMap.adjoint_inner_right]
  have hfin : Module.finrank ℝ (EuclideanSpace ℝ (Fin d)) = d := finrank_euclideanSpace_fin
  let e : OrthonormalBasis (Fin d) ℝ (EuclideanSpace ℝ (Fin d)) := hS.eigenvectorBasis hfin
  let lam : Fin d → ℝ := hS.eigenvalues hfin
  have hlam_eq : ∀ k : Fin d, lam k = ‖U (e k)‖ ^ 2 := by
    intro k
    have h1 : inner ℝ (S (e k)) (e k) = lam k := by
      dsimp [e, lam]
      rw [hS.apply_eigenvectorBasis hfin k, inner_smul_left]
      simp [(hS.eigenvectorBasis hfin).orthonormal.1 k]
    have h2 : inner ℝ (S (e k)) (e k) = ‖U (e k)‖ ^ 2 := by
      dsimp [S]
      rw [LinearMap.adjoint_inner_left, real_inner_self_eq_norm_sq]
    linarith
  have hlam_nonneg : ∀ k : Fin d, 0 ≤ lam k := fun k => by rw [hlam_eq k]; exact sq_nonneg _
  have hlam_sum : ∑ k : Fin d, lam k ≤ L ^ 2 := by
    have htr : ∑ k : Fin d, lam k = ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, ‖ξ i‖ ^ 2 := by
      simp_rw [hlam_eq]
      conv_lhs => simp only [EuclideanSpace.norm_sq_eq]
      rw [Finset.sum_comm, Finset.mul_sum]
      refine Finset.sum_congr rfl fun i _ => ?_
      have hparseval : ∑ k : Fin d, (inner ℝ (e k) (ξ i)) ^ 2 = ‖ξ i‖ ^ 2 := by
        rw [← real_inner_self_eq_norm_sq, ← e.sum_inner_mul_inner (ξ i) (ξ i)]
        refine Finset.sum_congr rfl fun k _ => ?_
        rw [real_inner_comm (ξ i) (e k), sq]
      rw [← hparseval, Finset.mul_sum]
      refine Finset.sum_congr rfl fun k _ => ?_
      change ‖(1 / Real.sqrt (n : ℝ)) * inner ℝ (e k) (ξ i)‖ ^ 2 = _
      rw [Real.norm_eq_abs, sq_abs, mul_pow, div_pow, one_pow, Real.sq_sqrt hn_pos.le]
    rw [htr]
    have hsum_le : ∑ i : Fin n, ‖ξ i‖ ^ 2 ≤ (n : ℝ) * L ^ 2 := by
      calc ∑ i : Fin n, ‖ξ i‖ ^ 2
          ≤ ∑ _ : Fin n, L ^ 2 :=
            Finset.sum_le_sum fun i _ => pow_le_pow_left₀ (norm_nonneg _) (hξ i) 2
        _ = (n : ℝ) * L ^ 2 := by simp
    calc ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, ‖ξ i‖ ^ 2
        ≤ ((1 : ℝ) / (n : ℝ)) * ((n : ℝ) * L ^ 2) :=
          mul_le_mul_of_nonneg_left hsum_le (by positivity)
      _ = L ^ 2 := by field_simp [hn_pos.ne']
  let a : Fin d → ℝ := fun k => R * Real.sqrt (lam k)
  have ha_nonneg : ∀ k : Fin d, 0 ≤ a k := fun k => mul_nonneg hR.le (Real.sqrt_nonneg _)
  have ha_sum : ∑ k : Fin d, a k ^ 2 ≤ (L * R) ^ 2 := by
    have hsum_a : ∑ k : Fin d, a k ^ 2 = R ^ 2 * ∑ k : Fin d, lam k := by
      rw [Finset.mul_sum]
      refine Finset.sum_congr rfl fun k _ => ?_
      dsimp [a]
      rw [mul_pow, Real.sq_sqrt (hlam_nonneg k)]
    calc ∑ k : Fin d, a k ^ 2
        = R ^ 2 * ∑ k : Fin d, lam k := hsum_a
      _ ≤ R ^ 2 * L ^ 2 := mul_le_mul_of_nonneg_left hlam_sum (sq_nonneg R)
      _ = (L * R) ^ 2 := by ring
  have h_diag_dist : ∀ z z' : EuclideanSpace ℝ (Fin d),
      ‖U (R • e.repr.symm z) - U (R • e.repr.symm z')‖ ^ 2 =
        ∑ k : Fin d, (a k * z k - a k * z' k) ^ 2 := by
    intro z z'
    let w : EuclideanSpace ℝ (Fin d) := R • e.repr.symm (z - z')
    have hw_sub : U (R • e.repr.symm z) - U (R • e.repr.symm z') = U w := by
      dsimp [w]
      rw [map_sub, smul_sub, map_sub]
    have hw_repr : e.repr w = R • (z - z') := by
      dsimp [w]
      rw [map_smul, LinearIsometryEquiv.apply_symm_apply]
    rw [hw_sub, ← real_inner_self_eq_norm_sq, ← LinearMap.adjoint_inner_left,
      show U.adjoint (U w) = S w from rfl, ← e.repr.inner_map_map (S w) w, PiLp.inner_apply]
    refine Finset.sum_congr rfl fun k _ => ?_
    have heig : e.repr (S w) k = lam k * e.repr w k :=
      hS.eigenvectorBasis_apply_self_apply hfin w k
    have hw_k : e.repr w k = R * (z k - z' k) := by
      simp [hw_repr]
    have ha_sq : a k ^ 2 = R ^ 2 * lam k := by
      dsimp [a]
      rw [mul_pow, Real.sq_sqrt (hlam_nonneg k)]
    simp only [RCLike.inner_apply, conj_trivial]
    calc e.repr w k * e.repr (S w) k
        = R * (z k - z' k) * (lam k * (R * (z k - z' k))) := by rw [heig, hw_k]
      _ = (R ^ 2 * lam k) * (z k - z' k) ^ 2 := by ring
      _ = a k ^ 2 * (z k - z' k) ^ 2 := by rw [← ha_sq]
      _ = (a k * z k - a k * z' k) ^ 2 := by ring
  let J_ax : Finset (Fin d) := Finset.univ.filter (fun k : Fin d => ε₁ / 2 < a k)
  by_cases hN0 : J_ax.card = 0
  · refine ⟨{0}, Finset.singleton_nonempty 0, ?_, ?_⟩
    · rw [Finset.card_singleton, Nat.cast_one]
      exact Real.one_le_exp (by positivity)
    · intro v hv
      refine ⟨0, Finset.mem_singleton_self 0, ?_⟩
      let z : EuclideanSpace ℝ (Fin d) := (1 / R) • e.repr v
      have hz_norm : ‖z‖ ≤ 1 := by
        dsimp [z]
        rw [norm_smul, Real.norm_eq_abs, abs_of_pos (one_div_pos.mpr hR), e.repr.norm_map,
          one_div_mul_eq_div, div_le_one hR]
        exact hv
      have hv_eq : R • e.repr.symm z = v := by
        dsimp [z]
        rw [map_smul, LinearIsometryEquiv.symm_apply_apply, smul_smul,
          mul_one_div_cancel hR.ne', one_smul]
      have h0_eq : R • e.repr.symm (0 : EuclideanSpace ℝ (Fin d)) = 0 := by simp
      have h_eq := h_diag_dist z 0
      rw [hv_eq, h0_eq, hU_dist_sq v 0] at h_eq
      simp only [inner_zero_left] at h_eq
      have hJ_empty : J_ax = ∅ := Finset.card_eq_zero.mp hN0
      have ha_small : ∀ k : Fin d, a k ≤ ε₁ / 2 := by
        intro k
        by_contra! hlt
        have hk : k ∈ J_ax := Finset.mem_filter.mpr ⟨Finset.mem_univ k, hlt⟩
        rw [hJ_empty] at hk
        exact Finset.notMem_empty k hk
      simp only [Pi.zero_apply]
      calc ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (inner ℝ v (ξ i) - 0) ^ 2
          = ∑ k : Fin d, (a k * z k - a k * (0 : EuclideanSpace ℝ (Fin d)) k) ^ 2 := h_eq
        _ = ∑ k : Fin d, (a k * z k) ^ 2 := by simp
        _ ≤ ∑ k : Fin d, ((ε₁ / 2) ^ 2 * ‖z k‖ ^ 2) := by
            refine Finset.sum_le_sum fun k _ => ?_
            rw [Real.norm_eq_abs, sq_abs, mul_pow]
            exact mul_le_mul_of_nonneg_right
              (pow_le_pow_left₀ (ha_nonneg k) (ha_small k) 2) (sq_nonneg _)
        _ = (ε₁ / 2) ^ 2 * ‖z‖ ^ 2 := by rw [← Finset.mul_sum, ← EuclideanSpace.norm_sq_eq]
        _ ≤ (ε₁ / 2) ^ 2 * 1 := by
            refine mul_le_mul_of_nonneg_left ?_ (sq_nonneg _)
            nlinarith [norm_nonneg z]
        _ ≤ ε₁ ^ 2 := by nlinarith
  · have hN1 : 1 ≤ J_ax.card := Nat.one_le_iff_ne_zero.mpr hN0
    let idx : Fin J_ax.card ≃ J_ax := J_ax.equivFin.symm
    let b : Fin J_ax.card → ℝ := fun r => a (idx r)
    have hb_gt : ∀ r : Fin J_ax.card, ε₁ / 2 < b r :=
      fun r => (Finset.mem_filter.mp (idx r).2).2
    have hb_pos : ∀ r : Fin J_ax.card, 0 < b r :=
      fun r => lt_trans (by positivity) (hb_gt r)
    have hb_sum : ∑ r : Fin J_ax.card, b r ^ 2 ≤ (L * R) ^ 2 := by
      have h1 : ∑ r : Fin J_ax.card, b r ^ 2 = ∑ x : J_ax, a x.1 ^ 2 :=
        Equiv.sum_comp idx (fun x : J_ax => a x.1 ^ 2)
      have h2 : ∑ x : J_ax, a x.1 ^ 2 = ∑ k ∈ J_ax, a k ^ 2 :=
        Finset.sum_coe_sort J_ax (fun k => a k ^ 2)
      calc ∑ r : Fin J_ax.card, b r ^ 2
          = ∑ k ∈ J_ax, a k ^ 2 := h1.trans h2
        _ ≤ ∑ k : Fin d, a k ^ 2 :=
            Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _) fun _ _ _ => sq_nonneg _
        _ ≤ (L * R) ^ 2 := ha_sum
    rcases exists_finite_ellipsoid_net hN1 hε₁ (sq_nonneg (L * R)) b hb_gt hb_sum with
      ⟨F, hF_ne, hF_card, hF_cov⟩
    let liftZ : EuclideanSpace ℝ (Fin J_ax.card) → EuclideanSpace ℝ (Fin d) := fun c =>
      WithLp.toLp 2 (fun k : Fin d =>
        if hk : k ∈ J_ax then c (idx.symm ⟨k, hk⟩) / b (idx.symm ⟨k, hk⟩) else 0)
    let vecOf : EuclideanSpace ℝ (Fin J_ax.card) → EuclideanSpace ℝ (Fin d) :=
      fun c => R • e.repr.symm (liftZ c)
    let gOf : EuclideanSpace ℝ (Fin J_ax.card) → (Fin n → ℝ) :=
      fun c i => inner ℝ (vecOf c) (ξ i)
    let G₁ : Finset (Fin n → ℝ) := F.image gOf
    refine ⟨G₁, hF_ne.image gOf, ?_, ?_⟩
    · calc (G₁.card : ℝ)
          ≤ (F.card : ℝ) := Nat.cast_le.mpr Finset.card_image_le
        _ ≤ Real.exp (12 * ((L * R) ^ 2 / ε₁ ^ 2)) := hF_card
        _ = Real.exp (12 * (L * R / ε₁) ^ 2) := by rw [div_pow]
    · intro v hv
      let z : EuclideanSpace ℝ (Fin d) := (1 / R) • e.repr v
      have hz_norm : ‖z‖ ≤ 1 := by
        dsimp [z]
        rw [norm_smul, Real.norm_eq_abs, abs_of_pos (one_div_pos.mpr hR), e.repr.norm_map,
          one_div_mul_eq_div, div_le_one hR]
        exact hv
      have hv_eq : R • e.repr.symm z = v := by
        dsimp [z]
        rw [map_smul, LinearIsometryEquiv.symm_apply_apply, smul_smul,
          mul_one_div_cancel hR.ne', one_smul]
      let z_N : EuclideanSpace ℝ (Fin J_ax.card) :=
        WithLp.toLp 2 (fun r : Fin J_ax.card => z (idx r))
      have hz_N_norm : ‖z_N‖ ≤ 1 := by
        have hsq : ‖z_N‖ ^ 2 ≤ 1 := by
          rw [EuclideanSpace.norm_sq_eq]
          have h1 : ∑ r : Fin J_ax.card, ‖z_N r‖ ^ 2 = ∑ x : J_ax, ‖z x.1‖ ^ 2 :=
            Equiv.sum_comp idx (fun x : J_ax => ‖z x.1‖ ^ 2)
          have h2 : ∑ x : J_ax, ‖z x.1‖ ^ 2 = ∑ k ∈ J_ax, ‖z k‖ ^ 2 :=
            Finset.sum_coe_sort J_ax (fun k => ‖z k‖ ^ 2)
          calc ∑ r : Fin J_ax.card, ‖z_N r‖ ^ 2
              = ∑ k ∈ J_ax, ‖z k‖ ^ 2 := h1.trans h2
            _ ≤ ∑ k : Fin d, ‖z k‖ ^ 2 :=
                Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _) fun _ _ _ => sq_nonneg _
            _ = ‖z‖ ^ 2 := (EuclideanSpace.norm_sq_eq z).symm
            _ ≤ 1 := by nlinarith [norm_nonneg z]
        nlinarith [norm_nonneg z_N]
      let u_J : EuclideanSpace ℝ (Fin J_ax.card) :=
        WithLp.toLp 2 (fun r : Fin J_ax.card => b r * z_N r)
      rcases hF_cov u_J ⟨z_N, hz_N_norm, fun r => rfl⟩ with ⟨c, hc_mem, hdist⟩
      refine ⟨gOf c, Finset.mem_image_of_mem gOf hc_mem, ?_⟩
      have h_eq := h_diag_dist z (liftZ c)
      rw [hv_eq, show R • e.repr.symm (liftZ c) = vecOf c from rfl, hU_dist_sq v (vecOf c)] at h_eq
      dsimp only [gOf]
      rw [h_eq]
      have hsplit := (Finset.sum_filter_add_sum_filter_not (Finset.univ : Finset (Fin d))
        (fun k : Fin d => ε₁ / 2 < a k)
        (fun k : Fin d => (a k * z k - a k * liftZ c k) ^ 2)).symm
      change ∑ k : Fin d, (a k * z k - a k * liftZ c k) ^ 2 ≤ ε₁ ^ 2
      rw [hsplit]
      have hhead : ∑ k ∈ J_ax, (a k * z k - a k * liftZ c k) ^ 2 ≤ (ε₁ / 2) ^ 2 := by
        have h1 : ∑ k ∈ J_ax, (a k * z k - a k * liftZ c k) ^ 2 =
            ∑ x : J_ax, (a x.1 * z x.1 - a x.1 * liftZ c x.1) ^ 2 :=
          (Finset.sum_coe_sort J_ax _).symm
        have h2 : ∑ x : J_ax, (a x.1 * z x.1 - a x.1 * liftZ c x.1) ^ 2 =
            ∑ r : Fin J_ax.card, (a (idx r) * z (idx r) - a (idx r) * liftZ c (idx r)) ^ 2 :=
          (Equiv.sum_comp idx _).symm
        have h3 : ∑ r : Fin J_ax.card,
            (a (idx r) * z (idx r) - a (idx r) * liftZ c (idx r)) ^ 2 = dist u_J c ^ 2 := by
          rw [EuclideanSpace.dist_sq_eq]
          refine Finset.sum_congr rfl fun r _ => ?_
          have h_lift : a (idx r) * liftZ c (idx r) = c r := by
            have hk : (idx r).1 ∈ J_ax := (idx r).2
            have hlz : liftZ c (idx r) = c (idx.symm ⟨(idx r).1, hk⟩) /
                b (idx.symm ⟨(idx r).1, hk⟩) := dif_pos hk
            have hsymm : idx.symm ⟨(idx r).1, hk⟩ = r := idx.symm_apply_apply r
            rw [hlz, hsymm]
            exact mul_div_cancel₀ (c r) (hb_pos r).ne'
          rw [h_lift, Real.dist_eq, sq_abs]
        rw [h1, h2, h3]
        exact pow_le_pow_left₀ dist_nonneg hdist 2
      have htail : ∑ k ∈ Finset.univ.filter (fun k : Fin d => ¬ ε₁ / 2 < a k),
          (a k * z k - a k * liftZ c k) ^ 2 ≤ (ε₁ / 2) ^ 2 := by
        calc ∑ k ∈ Finset.univ.filter (fun k : Fin d => ¬ ε₁ / 2 < a k),
            (a k * z k - a k * liftZ c k) ^ 2
            = ∑ k ∈ Finset.univ.filter (fun k : Fin d => ¬ ε₁ / 2 < a k), (a k * z k) ^ 2 := by
                refine Finset.sum_congr rfl fun k hk => ?_
                have hnot : k ∉ J_ax := by
                  intro hmem
                  exact (Finset.mem_filter.mp hk).2 (Finset.mem_filter.mp hmem).2
                have hlz : liftZ c k = 0 := dif_neg hnot
                rw [hlz, mul_zero, sub_zero]
          _ ≤ ∑ k ∈ Finset.univ.filter (fun k : Fin d => ¬ ε₁ / 2 < a k),
              ((ε₁ / 2) ^ 2 * ‖z k‖ ^ 2) := by
                refine Finset.sum_le_sum fun k hk => ?_
                have hle : a k ≤ ε₁ / 2 := not_lt.mp (Finset.mem_filter.mp hk).2
                rw [Real.norm_eq_abs, sq_abs, mul_pow]
                exact mul_le_mul_of_nonneg_right
                  (pow_le_pow_left₀ (ha_nonneg k) hle 2) (sq_nonneg _)
          _ ≤ ∑ k : Fin d, ((ε₁ / 2) ^ 2 * ‖z k‖ ^ 2) :=
                Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _) fun _ _ _ => by
                  positivity
          _ = (ε₁ / 2) ^ 2 * ‖z‖ ^ 2 := by rw [← Finset.mul_sum, ← EuclideanSpace.norm_sq_eq]
          _ ≤ (ε₁ / 2) ^ 2 := by
                have hz2 : ‖z‖ ^ 2 ≤ 1 := by nlinarith [norm_nonneg z]
                nlinarith [sq_nonneg (ε₁ / 2)]
      linarith [sq_nonneg ε₁]

end Helpers

/-- Empirical `L²` covering number of the Frobenius-ball linear score class
`{ (W (x i))_{i=1}^n : hilbertSchmidtNorm W ≤ R }` with net vectors clamped to `B_H(0, L * R)`. -/
theorem exists_score_ball_cover
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X] [CompleteSpace X]
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R ε : ℝ} (hL : 0 < L) (hR : 0 < R) (hε : 0 < ε)
    (x : Fin n → X) (hx : ∀ i : Fin n, ‖x i‖ ≤ L) :
    ∃ G : Finset (Fin n → UL.ZeroSumSubspace K),
      G.Nonempty ∧
      (∀ s ∈ G, ∀ i : Fin n, ‖s i‖ ≤ L * R) ∧
      (G.card : ℝ) ≤ Real.exp (12 * ((K - 1 : ℕ) : ℝ) ^ 2 * (L * R / ε) ^ 2) ∧
      ∀ W : X →L[ℝ] UL.ZeroSumSubspace K, UL.hilbertSchmidtNorm W ≤ R →
        ∃ s ∈ G, ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, ‖W (x i) - s i‖ ^ 2 ≤ ε ^ 2 := by
  classical
  let m : ℕ := K - 1
  have hm_ge : 1 ≤ m := by omega
  have hm_pos : (0 : ℝ) < (m : ℝ) := Nat.cast_pos.mpr hm_ge
  have hm_finrank : Module.finrank ℝ (UL.ZeroSumSubspace K) = m :=
    UL.Proof_lem_C_2.finrank_zeroSumSubspace K hK
  let bH : OrthonormalBasis (Fin m) ℝ (UL.ZeroSumSubspace K) :=
    (stdOrthonormalBasis ℝ (UL.ZeroSumSubspace K)).reindex (finCongr hm_finrank)
  let E_n : Submodule ℝ X := Submodule.span ℝ (Set.range x)
  haveI : FiniteDimensional ℝ E_n := FiniteDimensional.span_of_finite ℝ (Set.finite_range x)
  let d : ℕ := Module.finrank ℝ E_n
  let bE : OrthonormalBasis (Fin d) ℝ E_n := stdOrthonormalBasis ℝ E_n
  let xE : Fin n → E_n := fun i => ⟨x i, Submodule.subset_span ⟨i, rfl⟩⟩
  let ξ : Fin n → EuclideanSpace ℝ (Fin d) := fun i => bE.repr (xE i)
  have hξ : ∀ i : Fin n, ‖ξ i‖ ≤ L := by
    intro i
    dsimp [ξ]
    rw [bE.repr.norm_map]
    exact hx i
  let ε₁ : ℝ := ε / Real.sqrt (m : ℝ)
  have hε₁ : 0 < ε₁ := div_pos hε (Real.sqrt_pos.mpr hm_pos)
  rcases exists_scalar_ellipsoid_cover hn hL hR hε₁ ξ hξ with ⟨G₁, hG₁_ne, hG₁_card, hG₁_cov⟩
  let P : Finset (Fin m → Fin n → ℝ) := Fintype.piFinset (fun _ : Fin m => G₁)
  let unclamped : (Fin m → Fin n → ℝ) → (Fin n → UL.ZeroSumSubspace K) :=
    fun g i => bH.repr.symm (WithLp.toLp 2 (fun j : Fin m => g j i))
  let mkScore : (Fin m → Fin n → ℝ) → (Fin n → UL.ZeroSumSubspace K) :=
    fun g i => clampH (L * R) (unclamped g i)
  let G : Finset (Fin n → UL.ZeroSumSubspace K) := P.image mkScore
  have hLR_pos : 0 < L * R := mul_pos hL hR
  refine ⟨G, ?_, ?_, ?_, ?_⟩
  · rcases hG₁_ne with ⟨g₀, hg₀⟩
    have hP_ne : P.Nonempty := ⟨fun _ => g₀, Fintype.mem_piFinset.mpr fun _ => hg₀⟩
    exact hP_ne.image mkScore
  · intro s hs i
    rcases Finset.mem_image.mp hs with ⟨g, _, rfl⟩
    exact norm_clampH_le hLR_pos (unclamped g i)
  · have hP_card : P.card = G₁.card ^ m := by
      dsimp [P]
      rw [Fintype.card_piFinset]
      simp
    calc (G.card : ℝ)
        ≤ (P.card : ℝ) := Nat.cast_le.mpr Finset.card_image_le
      _ = (G₁.card : ℝ) ^ m := by rw [hP_card, Nat.cast_pow]
      _ ≤ (Real.exp (12 * (L * R / ε₁) ^ 2)) ^ m :=
          pow_le_pow_left₀ (Nat.cast_nonneg _) hG₁_card m
      _ = Real.exp ((m : ℝ) * (12 * (L * R / ε₁) ^ 2)) := (Real.exp_nat_mul _ m).symm
      _ = Real.exp (12 * ((K - 1 : ℕ) : ℝ) ^ 2 * (L * R / ε) ^ 2) := by
          congr 1
          have hdiv : (L * R / ε₁) ^ 2 = (L * R / ε) ^ 2 * (m : ℝ) := by
            dsimp [ε₁]
            have hsqrt_ne : Real.sqrt (m : ℝ) ≠ 0 := (Real.sqrt_pos.mpr hm_pos).ne'
            field_simp [hε.ne', hsqrt_ne]
            rw [Real.sq_sqrt hm_pos.le]
          rw [hdiv]
          dsimp [m]
          ring
  · intro W hW
    let bE_X : Fin d → X := fun k => (bE k : X)
    have hbE_ortho : Orthonormal ℝ bE_X := by
      rw [orthonormal_iff_ite]
      intro k₁ k₂
      exact orthonormal_iff_ite.mp bE.orthonormal k₁ k₂
    let w : Fin m → EuclideanSpace ℝ (Fin d) :=
      fun j => WithLp.toLp 2 (fun k : Fin d => inner ℝ (W (bE k : X)) (bH j))
    have hw_inner : ∀ (j : Fin m) (i : Fin n),
        inner ℝ (w j) (ξ i) = inner ℝ (W (x i)) (bH j) := by
      intro j i
      have hx_sum : x i = ∑ k : Fin d, (ξ i k) • (bE k : X) := by
        have hE_sum : xE i = ∑ k : Fin d, (ξ i k) • bE k := (bE.sum_repr (xE i)).symm
        simpa [xE, Submodule.coe_sum, Submodule.coe_smul] using congrArg Subtype.val hE_sum
      rw [hx_sum, map_sum, sum_inner]
      simp_rw [map_smul, inner_smul_left, conj_trivial]
      rw [PiLp.inner_apply]
      refine Finset.sum_congr rfl fun k _ => ?_
      simp only [w, RCLike.inner_apply, conj_trivial]
    have hw_norm : ∀ j : Fin m, ‖w j‖ ≤ R := by
      intro j
      have hsq : ‖w j‖ ^ 2 ≤ R ^ 2 := by
        rw [EuclideanSpace.norm_sq_eq]
        have h_eq_adj : ∑ k : Fin d, ‖w j k‖ ^ 2 =
            ∑ k : Fin d, ‖inner ℝ (bE_X k) (UL.Proof_lem_C_2.adjVec W (bH j))‖ ^ 2 := by
          refine Finset.sum_congr rfl fun k _ => ?_
          congr 2
          exact (UL.Proof_lem_C_2.inner_adjVec_right W (bH j) (bE_X k)).symm
        have hbessel : ∑ k : Fin d,
            ‖inner ℝ (bE_X k) (UL.Proof_lem_C_2.adjVec W (bH j))‖ ^ 2 ≤
            ‖UL.Proof_lem_C_2.adjVec W (bH j)‖ ^ 2 :=
          hbE_ortho.sum_inner_products_le (s := Finset.univ)
            (UL.Proof_lem_C_2.adjVec W (bH j))
        have h_bH_eq : bH j =
            (stdOrthonormalBasis ℝ (UL.ZeroSumSubspace K)) ((finCongr hm_finrank).symm j) :=
          OrthonormalBasis.reindex_apply
            (stdOrthonormalBasis ℝ (UL.ZeroSumSubspace K)) (finCongr hm_finrank) j
        have hadj_le_hs : ‖UL.Proof_lem_C_2.adjVec W (bH j)‖ ^ 2 ≤
            UL.hilbertSchmidtNorm W ^ 2 := by
          rw [h_bH_eq, UL.Proof_lem_C_2.hilbertSchmidtNorm_sq W]
          dsimp only
          exact Finset.single_le_sum
            (f := fun j' => ‖UL.Proof_lem_C_2.adjVec W
              ((stdOrthonormalBasis ℝ (UL.ZeroSumSubspace K)) j')‖ ^ 2)
            (fun _ _ => sq_nonneg _)
            (Finset.mem_univ ((finCongr hm_finrank).symm j))
        have hhs_le : UL.hilbertSchmidtNorm W ^ 2 ≤ R ^ 2 :=
          pow_le_pow_left₀ (UL.Proof_lem_C_2.hilbertSchmidtNorm_nonneg W) hW 2
        linarith
      nlinarith [norm_nonneg (w j)]
    have hg_ex : ∀ j : Fin m, ∃ g ∈ G₁,
        ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (inner ℝ (w j) (ξ i) - g i) ^ 2 ≤ ε₁ ^ 2 :=
      fun j => hG₁_cov (w j) (hw_norm j)
    let g : Fin m → Fin n → ℝ := fun j => Classical.choose (hg_ex j)
    have hg_mem : ∀ j : Fin m, g j ∈ G₁ := fun j => (Classical.choose_spec (hg_ex j)).1
    have hg_err : ∀ j : Fin m,
        ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (inner ℝ (w j) (ξ i) - g j i) ^ 2 ≤ ε₁ ^ 2 :=
      fun j => (Classical.choose_spec (hg_ex j)).2
    have hg_P : g ∈ P := Fintype.mem_piFinset.mpr fun j => hg_mem j
    refine ⟨mkScore g, Finset.mem_image_of_mem mkScore hg_P, ?_⟩
    have h_ptwise : ∀ i : Fin n,
        ‖W (x i) - mkScore g i‖ ^ 2 ≤ ∑ j : Fin m, (inner ℝ (w j) (ξ i) - g j i) ^ 2 := by
      intro i
      have hWx_norm : ‖W (x i)‖ ≤ L * R := by
        calc ‖W (x i)‖
            ≤ UL.hilbertSchmidtNorm W * ‖x i‖ :=
              UL.Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm W (x i)
          _ ≤ R * L := mul_le_mul hW (hx i) (norm_nonneg _) hR.le
          _ = L * R := mul_comm R L
      have hclamp := norm_sub_clampH_sq_le hLR_pos hWx_norm (unclamped g i)
      have hunclamped_sq : ‖W (x i) - unclamped g i‖ ^ 2 =
          ∑ j : Fin m, (inner ℝ (w j) (ξ i) - g j i) ^ 2 := by
        rw [← bH.repr.norm_map (W (x i) - unclamped g i), map_sub, EuclideanSpace.norm_sq_eq]
        refine Finset.sum_congr rfl fun j _ => ?_
        have hrepr_W : bH.repr (W (x i)) j = inner ℝ (w j) (ξ i) := by
          rw [bH.repr_apply_apply, real_inner_comm (W (x i)) (bH j), hw_inner j i]
        have hrepr_u : bH.repr (unclamped g i) j = g j i := by
          simp [unclamped]
        change ‖bH.repr (W (x i)) j - bH.repr (unclamped g i) j‖ ^ 2 = _
        rw [hrepr_W, hrepr_u, Real.norm_eq_abs, sq_abs]
      exact hunclamped_sq ▸ hclamp
    have hn_nonneg : 0 ≤ (1 : ℝ) / (n : ℝ) := by positivity
    calc ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, ‖W (x i) - mkScore g i‖ ^ 2
        ≤ ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, ∑ j : Fin m, (inner ℝ (w j) (ξ i) - g j i) ^ 2 :=
          mul_le_mul_of_nonneg_left (Finset.sum_le_sum fun i _ => h_ptwise i) hn_nonneg
      _ = ∑ j : Fin m, ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (inner ℝ (w j) (ξ i) - g j i) ^ 2 := by
          rw [Finset.sum_comm, Finset.mul_sum]
      _ ≤ ∑ _ : Fin m, ε₁ ^ 2 := Finset.sum_le_sum fun j _ => hg_err j
      _ = (m : ℝ) * ε₁ ^ 2 := by simp
      _ = ε ^ 2 := by
          dsimp [ε₁]
          rw [div_pow, Real.sq_sqrt hm_pos.le, mul_div_cancel₀ _ hm_pos.ne']

end UL.Proof_lem_C_3_Race2

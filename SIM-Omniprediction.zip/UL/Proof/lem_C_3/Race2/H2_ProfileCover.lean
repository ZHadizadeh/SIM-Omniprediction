import Mathlib
import UL.Def.def_C_profiles
import UL.Proof.lem_C_3.Race2.H1_EllipsoidCover
set_option autoImplicit false

namespace UL.Proof_lem_C_3_Race2

noncomputable def kappaK (K : ℕ) : ℝ :=
  48 * (K : ℝ) ^ 2 + 6 * (K : ℝ) * (16 * (K : ℝ)) ^ K

theorem kappaK_pos {K : ℕ} (hK : 2 ≤ K) : 0 < kappaK K := by
  unfold kappaK
  have hK0 : (0 : ℝ) < (K : ℝ) := Nat.cast_pos.mpr (by omega)
  positivity

noncomputable def coverExp (K : ℕ) (A₀ C M₀ t : ℝ) : ℝ :=
  kappaK K * (1 + Real.log (1 + M₀ / t) + (C * A₀ / t) ^ 2 + (C * A₀ / t) ^ (K - 1))

/-! ### Clamping and global Lipschitz extension -/

private noncomputable def clampM (M₀ u : ℝ) : ℝ :=
  max (-M₀) (min M₀ u)

private lemma abs_clampM_le {M₀ : ℝ} (hM₀ : 0 ≤ M₀) (u : ℝ) :
    |clampM M₀ u| ≤ M₀ := by
  unfold clampM
  rw [abs_le]
  exact ⟨le_max_left _ _, max_le (by linarith) (min_le_left _ _)⟩

private lemma clampM_eq_self {M₀ u : ℝ} (hu : u ∈ Set.Icc (-M₀) M₀) :
    clampM M₀ u = u := by
  rcases hu with ⟨h1, h2⟩
  unfold clampM
  rw [min_eq_right h2, max_eq_right h1]

private lemma abs_min_sub_le (a u v : ℝ) :
    |min a u - min a v| ≤ |u - v| := by
  have h1 := le_abs_self (u - v)
  have h2 := neg_le_abs (u - v)
  rcases le_total a u with hau | hua <;> rcases le_total a v with hav | hva
  · simp [min_eq_left hau, min_eq_left hav]
  · rw [min_eq_left hau, min_eq_right hva, abs_le]
    exact ⟨by linarith, by linarith⟩
  · rw [min_eq_right hua, min_eq_left hav, abs_le]
    exact ⟨by linarith, by linarith⟩
  · rw [min_eq_right hua, min_eq_right hva]

private lemma abs_max_sub_le (a u v : ℝ) :
    |max a u - max a v| ≤ |u - v| := by
  have h1 := le_abs_self (u - v)
  have h2 := neg_le_abs (u - v)
  rcases le_total a u with hau | hua <;> rcases le_total a v with hav | hva
  · rw [max_eq_right hau, max_eq_right hav]
  · rw [max_eq_right hau, max_eq_left hva, abs_le]
    exact ⟨by linarith, by linarith⟩
  · rw [max_eq_left hua, max_eq_right hav, abs_le]
    exact ⟨by linarith, by linarith⟩
  · simp [max_eq_left hua, max_eq_left hva]

private lemma abs_clampM_sub_le (M₀ u v : ℝ) :
    |clampM M₀ u - clampM M₀ v| ≤ |u - v| :=
  (abs_max_sub_le (-M₀) (min M₀ u) (min M₀ v)).trans (abs_min_sub_le M₀ u v)

private lemma exists_clamped_lip_ext {K m : ℕ}
    (isoH : UL.ZeroSumSubspace K ≃ₗᵢ[ℝ] EuclideanSpace ℝ (Fin m))
    {A₀ C M₀ : ℝ} (hC : 0 < C) (hM₀ : 0 < M₀)
    (ay : UL.ZeroSumSubspace K → ℝ)
    (h_lip : LipschitzOnWith (Real.toNNReal C) ay
      (Metric.closedBall (0 : UL.ZeroSumSubspace K) A₀))
    (h_map : Set.MapsTo ay
      (Metric.closedBall (0 : UL.ZeroSumSubspace K) A₀) (Set.Icc (-M₀) M₀)) :
    ∃ h : EuclideanSpace ℝ (Fin m) → ℝ,
      (∀ u, |h u| ≤ M₀) ∧
      (∀ u v, |h u - h v| ≤ C * ‖u - v‖) ∧
      (∀ s : UL.ZeroSumSubspace K, ‖s‖ ≤ A₀ → h (isoH s) = ay s) := by
  obtain ⟨g₀, hg₀_lip, hg₀_eq⟩ := h_lip.extend_real
  refine ⟨fun u => clampM M₀ (g₀ (isoH.symm u)), ?_, ?_, ?_⟩
  · intro u
    exact abs_clampM_le hM₀.le _
  · intro u v
    calc |clampM M₀ (g₀ (isoH.symm u)) - clampM M₀ (g₀ (isoH.symm v))|
        ≤ |g₀ (isoH.symm u) - g₀ (isoH.symm v)| := abs_clampM_sub_le M₀ _ _
      _ = dist (g₀ (isoH.symm u)) (g₀ (isoH.symm v)) := (Real.dist_eq _ _).symm
      _ ≤ (Real.toNNReal C : ℝ) * dist (isoH.symm u) (isoH.symm v) := hg₀_lip.dist_le_mul _ _
      _ = C * ‖u - v‖ := by
          rw [Real.coe_toNNReal C hC.le, isoH.symm.dist_map, dist_eq_norm]
  · intro s hs
    have hs_mem : s ∈ Metric.closedBall (0 : UL.ZeroSumSubspace K) A₀ := by
      rwa [Metric.mem_closedBall, dist_zero_right]
    dsimp only
    rw [isoH.symm_apply_apply, ← hg₀_eq hs_mem]
    exact clampM_eq_self (h_map hs_mem)

/-! ### Grid predecessor tree and telescoping integer table codes -/

private def coordSum {m P : ℕ} (v : Fin m → Fin P) : ℕ :=
  ∑ r : Fin m, (v r).1

private def predV {m P : ℕ} (v : Fin m → Fin P) : Fin m → Fin P :=
  if h : (Finset.univ.filter (fun r : Fin m => 0 < (v r).1)).Nonempty then
    let r₀ := (Finset.univ.filter (fun r : Fin m => 0 < (v r).1)).min' h
    Function.update v r₀ ⟨(v r₀).1 - 1, by omega⟩
  else
    v

private lemma coordSum_eq_zero_iff {m P : ℕ} (hP : 0 < P) (v : Fin m → Fin P) :
    coordSum v = 0 ↔ v = (fun _ => ⟨0, hP⟩) := by
  constructor
  · intro hv
    unfold coordSum at hv
    funext r
    apply Fin.ext
    dsimp only
    have hle : (v r).1 ≤ ∑ r' : Fin m, (v r').1 :=
      Finset.single_le_sum (f := fun r' : Fin m => (v r').1)
        (fun _ _ => Nat.zero_le _) (Finset.mem_univ r)
    omega
  · rintro rfl
    simp [coordSum]

private lemma coordSum_predV {m P : ℕ} (v : Fin m → Fin P) :
    coordSum (predV v) = coordSum v - 1 := by
  unfold predV
  split_ifs with h
  · dsimp only
    unfold coordSum
    let r₀ := (Finset.univ.filter (fun r : Fin m => 0 < (v r).1)).min' h
    let w : Fin m → Fin P := Function.update v r₀ ⟨(v r₀).1 - 1, by omega⟩
    change ∑ r : Fin m, (w r).1 = (∑ r : Fin m, (v r).1) - 1
    have hr₀_pos : 0 < (v r₀).1 :=
      (Finset.mem_filter.mp (Finset.min'_mem _ h)).2
    have h1 := Finset.add_sum_erase Finset.univ (fun r : Fin m => (w r).1) (Finset.mem_univ r₀)
    have h2 := Finset.add_sum_erase Finset.univ (fun r : Fin m => (v r).1) (Finset.mem_univ r₀)
    dsimp only at h1 h2
    have hw_self : (w r₀).1 = (v r₀).1 - 1 := by
      dsimp [w]
      rw [Function.update_self]
    have herase :
        ∑ r ∈ Finset.univ.erase r₀, (w r).1 = ∑ r ∈ Finset.univ.erase r₀, (v r).1 := by
      refine Finset.sum_congr rfl fun r hr => ?_
      dsimp [w]
      rw [Function.update_of_ne (Finset.ne_of_mem_erase hr)]
    rw [← h1, ← h2, hw_self, herase]
    omega
  · have hzero : coordSum v = 0 := by
      unfold coordSum
      refine Finset.sum_eq_zero fun r _ => ?_
      by_contra hne
      apply h
      exact ⟨r, Finset.mem_filter.mpr ⟨Finset.mem_univ r, Nat.pos_of_ne_zero hne⟩⟩
    omega

private lemma coordSum_iterate_predV {m P : ℕ} (v : Fin m → Fin P) (k : ℕ) :
    coordSum (predV^[k] v) = coordSum v - k := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [Function.iterate_succ_apply', coordSum_predV, ih]
    omega

private lemma iterate_coordSum_predV {m P : ℕ} (hP : 0 < P) (v : Fin m → Fin P) :
    predV^[coordSum v] v = (fun _ => ⟨0, hP⟩) := by
  rw [← coordSum_eq_zero_iff hP, coordSum_iterate_predV]
  omega

private def decTable {m P : ℕ} (p : ℤ × ((Fin m → Fin P) → ℤ)) (v : Fin m → Fin P) : ℤ :=
  p.1 + ∑ k ∈ Finset.range (coordSum v), p.2 (predV^[k] v)

private lemma telescope_predV {m P : ℕ} (q : (Fin m → Fin P) → ℤ) (v : Fin m → Fin P) (L : ℕ) :
    ∑ k ∈ Finset.range L, (q (predV^[k] v) - q (predV (predV^[k] v))) =
      q v - q (predV^[L] v) := by
  induction L with
  | zero => simp
  | succ L ih =>
    rw [Finset.sum_range_succ, ih, ← Function.iterate_succ_apply' predV L v]
    ring

private lemma decTable_enc {m P : ℕ} (hP : 0 < P) (q : (Fin m → Fin P) → ℤ) :
    decTable (q (fun _ => ⟨0, hP⟩), fun u => q u - q (predV u)) = q := by
  funext v
  unfold decTable
  dsimp only
  rw [telescope_predV, iterate_coordSum_predV hP v]
  ring

open Classical in
private noncomputable def validTables (m P B_root : ℕ) : Finset ((Fin m → Fin P) → ℤ) :=
  ((Finset.Icc (-(B_root : ℤ)) (B_root : ℤ)) ×ˢ
    Fintype.piFinset (fun _ : (Fin m → Fin P) => Finset.Icc (-2 : ℤ) 2)).image decTable

private lemma validTables_nonempty (m P B_root : ℕ) :
    (validTables m P B_root).Nonempty := by
  classical
  unfold validTables
  refine Finset.Nonempty.image ⟨(0, fun _ => 0), ?_⟩ decTable
  rw [Finset.mem_product]
  dsimp only
  refine ⟨Finset.mem_Icc.mpr ⟨by omega, by omega⟩, ?_⟩
  rw [Fintype.mem_piFinset]
  intro _
  exact Finset.mem_Icc.mpr ⟨by omega, by omega⟩

private lemma card_validTables_le (m P B_root : ℕ) :
    (validTables m P B_root).card ≤ (2 * B_root + 1) * 5 ^ (P ^ m) := by
  classical
  unfold validTables
  have h1 := Finset.card_image_le
    (s := (Finset.Icc (-(B_root : ℤ)) (B_root : ℤ)) ×ˢ
      Fintype.piFinset (fun _ : (Fin m → Fin P) => Finset.Icc (-2 : ℤ) 2))
    (f := decTable)
  rw [Finset.card_product, Int.card_Icc, Fintype.card_piFinset, Finset.prod_const,
    Int.card_Icc, Finset.card_univ, Fintype.card_fun, Fintype.card_fin, Fintype.card_fin] at h1
  have hroot : ((B_root : ℤ) + 1 - -(B_root : ℤ)).toNat = 2 * B_root + 1 := by omega
  have hfive : ((2 : ℤ) + 1 - -2).toNat = 5 := by omega
  rw [hroot, hfive] at h1
  exact h1

private lemma mem_validTables {m P B_root : ℕ} (hP : 0 < P)
    {q : (Fin m → Fin P) → ℤ}
    (h0 : q (fun _ => ⟨0, hP⟩) ∈ Finset.Icc (-(B_root : ℤ)) (B_root : ℤ))
    (hd : ∀ u, q u - q (predV u) ∈ Finset.Icc (-2 : ℤ) 2) :
    q ∈ validTables m P B_root := by
  classical
  unfold validTables
  refine Finset.mem_image.mpr ⟨(q (fun _ => ⟨0, hP⟩), fun u => q u - q (predV u)), ?_,
    decTable_enc hP q⟩
  rw [Finset.mem_product]
  exact ⟨h0, Fintype.mem_piFinset.mpr hd⟩

/-! ### Cube grid approximation for scalar Lipschitz profiles -/

private noncomputable def gridPt {m P : ℕ} (A₀ Δ : ℝ) (v : Fin m → Fin P) :
    EuclideanSpace ℝ (Fin m) :=
  (WithLp.equiv 2 (Fin m → ℝ)).symm (fun r => -A₀ + ((v r).1 : ℝ) * Δ)

private lemma norm_gridPt_sub_predV_le {m P : ℕ} (A₀ : ℝ) {Δ : ℝ} (hΔ : 0 ≤ Δ)
    (v : Fin m → Fin P) :
    ‖gridPt A₀ Δ v - gridPt A₀ Δ (predV v)‖ ≤ Δ := by
  have hsq : ‖gridPt A₀ Δ v - gridPt A₀ Δ (predV v)‖ ^ 2 ≤ Δ ^ 2 := by
    rw [← dist_eq_norm, EuclideanSpace.dist_sq_eq]
    unfold predV
    split_ifs with h
    · set S := Finset.univ.filter (fun r : Fin m => 0 < (v r).1)
      set r₀ := S.min' h
      have hr₀_pos : 1 ≤ (v r₀).1 := (Finset.mem_filter.mp (Finset.min'_mem S h)).2
      have hsplit := Finset.add_sum_erase Finset.univ
        (fun r : Fin m =>
          dist (gridPt A₀ Δ v r)
            (gridPt A₀ Δ (Function.update v r₀ ⟨(v r₀).1 - 1, by omega⟩) r) ^ 2)
        (Finset.mem_univ r₀)
      rw [← hsplit]
      have herase :
          ∑ r ∈ Finset.univ.erase r₀,
              dist (gridPt A₀ Δ v r)
                (gridPt A₀ Δ (Function.update v r₀ ⟨(v r₀).1 - 1, by omega⟩) r) ^ 2 = 0 := by
        refine Finset.sum_eq_zero fun r hr => ?_
        unfold gridPt
        simp only [WithLp.equiv_symm_apply, Function.update_of_ne (Finset.ne_of_mem_erase hr),
          dist_self, ne_eq, OfNat.ofNat_ne_zero, not_false_eq_true, zero_pow]
      have hr₀_eq :
          dist (gridPt A₀ Δ v r₀)
              (gridPt A₀ Δ (Function.update v r₀ ⟨(v r₀).1 - 1, by omega⟩) r₀) ^ 2 = Δ ^ 2 := by
        unfold gridPt
        simp only [WithLp.equiv_symm_apply, Function.update_self, Real.dist_eq, sq_abs]
        rw [Nat.cast_sub hr₀_pos, Nat.cast_one]
        ring
      linarith
    · simp [sq_nonneg Δ]
  nlinarith [norm_nonneg (gridPt A₀ Δ v - gridPt A₀ Δ (predV v))]

private noncomputable def cellIdx {m : ℕ} (P : ℕ) (hP : 1 ≤ P) (A₀ Δ : ℝ)
    (u : EuclideanSpace ℝ (Fin m)) : Fin m → Fin P :=
  fun r => ⟨min (P - 1) (Int.toNat (Int.floor ((u r + A₀) / Δ))), by omega⟩

private lemma coord_sub_gridPt_cellIdx_le {m P : ℕ} (hP : 1 ≤ P) {A₀ : ℝ} (hA₀ : 0 < A₀)
    {u : EuclideanSpace ℝ (Fin m)} (hu : ∀ r : Fin m, |u r| ≤ A₀) (r : Fin m) :
    |u r - gridPt A₀ (2 * A₀ / (P : ℝ)) (cellIdx P hP A₀ (2 * A₀ / (P : ℝ)) u) r| ≤
      2 * A₀ / (P : ℝ) := by
  set Δ : ℝ := 2 * A₀ / (P : ℝ)
  have hP_pos : (0 : ℝ) < (P : ℝ) := Nat.cast_pos.mpr (by omega)
  have hΔ_pos : 0 < Δ := div_pos (by linarith) hP_pos
  have hPΔ : (P : ℝ) * Δ = 2 * A₀ := mul_div_cancel₀ (2 * A₀) hP_pos.ne'
  rcases abs_le.mp (hu r) with ⟨hur_lo, hur_hi⟩
  set x : ℝ := (u r + A₀) / Δ
  have hx_nonneg : 0 ≤ x := div_nonneg (by linarith) hΔ_pos.le
  have hx_le_P : x ≤ (P : ℝ) := by
    rw [div_le_iff₀ hΔ_pos, hPΔ]
    linarith
  set k : ℤ := Int.floor x
  have hk_nonneg : 0 ≤ k := Int.floor_nonneg.mpr hx_nonneg
  have hk_le_real : (k : ℝ) ≤ x := Int.floor_le x
  have hx_lt_k1 : x < (k : ℝ) + 1 := Int.lt_floor_add_one x
  have hk_le_P_int : k ≤ (P : ℤ) := by exact_mod_cast hk_le_real.trans hx_le_P
  set k_nat : ℕ := Int.toNat k
  have hk_nat_int : (k_nat : ℤ) = k := Int.toNat_of_nonneg hk_nonneg
  have hk_nat_real : (k_nat : ℝ) = (k : ℝ) := by exact_mod_cast hk_nat_int
  have hk_nat_le_P : k_nat ≤ P := by omega
  set j : ℕ := min (P - 1) k_nat
  have hj_diff : 0 ≤ x - (j : ℝ) ∧ x - (j : ℝ) ≤ 1 := by
    by_cases hkn : k_nat ≤ P - 1
    · have hj_eq : j = k_nat := min_eq_right hkn
      rw [hj_eq, hk_nat_real]
      exact ⟨by linarith, by linarith⟩
    · have hkn_eq : k_nat = P := by omega
      have hj_eq : j = P - 1 := min_eq_left (by omega)
      have hx_eq_P : x = (P : ℝ) := by
        have hP_le_x : (P : ℝ) ≤ x := by
          rw [← hkn_eq, hk_nat_real]
          exact hk_le_real
        linarith
      rw [hj_eq, Nat.cast_sub hP, Nat.cast_one, hx_eq_P]
      exact ⟨by linarith, by linarith⟩
  have h_rewrite :
      u r - gridPt A₀ Δ (cellIdx P hP A₀ Δ u) r = (x - (j : ℝ)) * Δ := by
    unfold gridPt cellIdx
    simp only [WithLp.equiv_symm_apply]
    have hxΔ : x * Δ = u r + A₀ := div_mul_cancel₀ (u r + A₀) hΔ_pos.ne'
    change u r - (-A₀ + (j : ℝ) * Δ) = (x - (j : ℝ)) * Δ
    linarith
  rw [h_rewrite, abs_le]
  exact ⟨by nlinarith [hj_diff.1, hΔ_pos], by nlinarith [hj_diff.2, hΔ_pos]⟩

private lemma norm_sub_gridPt_cellIdx_le {m P : ℕ} (hP : 1 ≤ P) {A₀ : ℝ} (hA₀ : 0 < A₀)
    {u : EuclideanSpace ℝ (Fin m)} (hu : ‖u‖ ≤ A₀) :
    ‖u - gridPt A₀ (2 * A₀ / (P : ℝ)) (cellIdx P hP A₀ (2 * A₀ / (P : ℝ)) u)‖ ≤
      Real.sqrt (m : ℝ) * (2 * A₀ / (P : ℝ)) := by
  set Δ : ℝ := 2 * A₀ / (P : ℝ)
  have hP_pos : (0 : ℝ) < (P : ℝ) := Nat.cast_pos.mpr (by omega)
  have hΔ_nonneg : 0 ≤ Δ := div_nonneg (by linarith) hP_pos.le
  have hu_coord : ∀ r : Fin m, |u r| ≤ A₀ := by
    intro r
    have h1 : ‖u r‖ ^ 2 ≤ ‖u‖ ^ 2 := by
      rw [EuclideanSpace.norm_sq_eq]
      exact Finset.single_le_sum (fun r' _ => sq_nonneg ‖u r'‖) (Finset.mem_univ r)
    rw [Real.norm_eq_abs] at h1
    have h2 : ‖u‖ ^ 2 ≤ A₀ ^ 2 := pow_le_pow_left₀ (norm_nonneg u) hu 2
    nlinarith [abs_nonneg (u r)]
  have hsq :
      ‖u - gridPt A₀ Δ (cellIdx P hP A₀ Δ u)‖ ^ 2 ≤
        (Real.sqrt (m : ℝ) * Δ) ^ 2 := by
    rw [← dist_eq_norm, EuclideanSpace.dist_sq_eq, mul_pow, Real.sq_sqrt (Nat.cast_nonneg m)]
    calc ∑ r : Fin m, dist (u r) (gridPt A₀ Δ (cellIdx P hP A₀ Δ u) r) ^ 2
        ≤ ∑ _ : Fin m, Δ ^ 2 := by
          refine Finset.sum_le_sum fun r _ => ?_
          rw [Real.dist_eq]
          exact pow_le_pow_left₀ (abs_nonneg _) (coord_sub_gridPt_cellIdx_le hP hA₀ hu_coord r) 2
      _ = (m : ℝ) * Δ ^ 2 := by
          rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
  have hrhs_nonneg : 0 ≤ Real.sqrt (m : ℝ) * Δ := mul_nonneg (Real.sqrt_nonneg _) hΔ_nonneg
  nlinarith [norm_nonneg (u - gridPt A₀ Δ (cellIdx P hP A₀ Δ u))]

private noncomputable def approxProfile {K m P : ℕ} (hP : 1 ≤ P)
    (isoH : UL.ZeroSumSubspace K ≃ₗᵢ[ℝ] EuclideanSpace ℝ (Fin m))
    (A₀ Δ η M₀ : ℝ) (q : (Fin m → Fin P) → ℤ) (s : UL.ZeroSumSubspace K) : ℝ :=
  clampM M₀ ((q (cellIdx P hP A₀ Δ (isoH s)) : ℝ) * η)

private lemma abs_approxProfile_le {K m P : ℕ} (hP : 1 ≤ P)
    (isoH : UL.ZeroSumSubspace K ≃ₗᵢ[ℝ] EuclideanSpace ℝ (Fin m))
    (A₀ Δ η : ℝ) {M₀ : ℝ} (hM₀ : 0 ≤ M₀)
    (q : (Fin m → Fin P) → ℤ) (s : UL.ZeroSumSubspace K) :
    |approxProfile hP isoH A₀ Δ η M₀ q s| ≤ M₀ :=
  abs_clampM_le hM₀ _

private lemma exists_table_approx_profile {K m : ℕ} (hm : 1 ≤ m)
    (isoH : UL.ZeroSumSubspace K ≃ₗᵢ[ℝ] EuclideanSpace ℝ (Fin m))
    {A₀ C M₀ t : ℝ} (hA₀ : 0 < A₀) (hC : 0 < C) (hM₀ : 0 < M₀) (ht : 0 < t)
    (ay : UL.ZeroSumSubspace K → ℝ)
    (h_lip : LipschitzOnWith (Real.toNNReal C) ay
      (Metric.closedBall (0 : UL.ZeroSumSubspace K) A₀))
    (h_map : Set.MapsTo ay
      (Metric.closedBall (0 : UL.ZeroSumSubspace K) A₀) (Set.Icc (-M₀) M₀)) :
    let η : ℝ := t / 4
    let P : ℕ := max 1 (Nat.ceil (8 * Real.sqrt (m : ℝ) * C * A₀ / t))
    let hP : 1 ≤ P := le_max_left 1 _
    let Δ : ℝ := 2 * A₀ / (P : ℝ)
    let B_root : ℕ := Nat.ceil (M₀ / η) + 1
    ∃ q ∈ validTables m P B_root,
      ∀ s : UL.ZeroSumSubspace K, ‖s‖ ≤ A₀ →
        |ay s - approxProfile hP isoH A₀ Δ η M₀ q s| ≤ t / 2 := by
  intro η P hP Δ B_root
  have hη_pos : 0 < η := by dsimp [η]; linarith
  have hP_pos_nat : 0 < P := by omega
  have hP_pos : (0 : ℝ) < (P : ℝ) := Nat.cast_pos.mpr hP_pos_nat
  have hΔ_pos : 0 < Δ := div_pos (by linarith) hP_pos
  have hC_sqrt_Δ : C * Real.sqrt (m : ℝ) * Δ ≤ η := by
    have hceil : 8 * Real.sqrt (m : ℝ) * C * A₀ / t ≤ (P : ℝ) := by
      calc 8 * Real.sqrt (m : ℝ) * C * A₀ / t
          ≤ (Nat.ceil (8 * Real.sqrt (m : ℝ) * C * A₀ / t) : ℝ) := Nat.le_ceil _
        _ ≤ (P : ℝ) := Nat.cast_le.mpr (le_max_right 1 _)
    have hmul : 8 * Real.sqrt (m : ℝ) * C * A₀ ≤ (P : ℝ) * t :=
      (div_le_iff₀ ht).mp hceil
    have hrew : C * Real.sqrt (m : ℝ) * Δ = (2 * Real.sqrt (m : ℝ) * C * A₀) / (P : ℝ) := by
      dsimp [Δ]; ring
    rw [hrew, div_le_iff₀ hP_pos]
    dsimp [η]
    linarith
  have hC_Δ : C * Δ ≤ η := by
    have hm1 : (1 : ℝ) ≤ (m : ℝ) := Nat.one_le_cast.mpr hm
    have hsqrt1 : (1 : ℝ) ≤ Real.sqrt (m : ℝ) := by
      rw [← Real.sqrt_one]
      exact Real.sqrt_le_sqrt hm1
    have h1 : C * Δ ≤ C * Real.sqrt (m : ℝ) * Δ := by
      have hCΔ_nonneg : 0 ≤ C * Δ := mul_nonneg hC.le hΔ_pos.le
      nlinarith
    exact h1.trans hC_sqrt_Δ
  obtain ⟨h, hh_bdd, hh_lip, hh_eq⟩ := exists_clamped_lip_ext isoH hC hM₀ ay h_lip h_map
  let q_h : (Fin m → Fin P) → ℤ := fun v => Int.floor (h (gridPt A₀ Δ v) / η)
  have hq0 : q_h (fun _ => ⟨0, hP_pos_nat⟩) ∈ Finset.Icc (-(B_root : ℤ)) (B_root : ℤ) := by
    set v₀ : Fin m → Fin P := fun _ => ⟨0, hP_pos_nat⟩
    set r_val : ℝ := h (gridPt A₀ Δ v₀) / η
    have hr_abs : |r_val| ≤ M₀ / η := by
      dsimp [r_val]
      rw [abs_div, abs_of_pos hη_pos]
      exact div_le_div_of_nonneg_right (hh_bdd _) hη_pos.le
    rcases abs_le.mp hr_abs with ⟨hr_lo, hr_hi⟩
    have hceil_M : M₀ / η ≤ (Nat.ceil (M₀ / η) : ℝ) := Nat.le_ceil _
    have hB_real : ((B_root : ℤ) : ℝ) = (Nat.ceil (M₀ / η) : ℝ) + 1 := by
      dsimp [B_root]
      push_cast
      ring
    have hfl_le : (Int.floor r_val : ℝ) ≤ r_val := Int.floor_le r_val
    have hr_lt_fl : r_val < (Int.floor r_val : ℝ) + 1 := Int.lt_floor_add_one r_val
    have h_up_real : (Int.floor r_val : ℝ) ≤ ((B_root : ℤ) : ℝ) := by linarith
    have h_lo_real : (-((B_root : ℤ) : ℝ)) ≤ (Int.floor r_val : ℝ) := by linarith
    rw [Finset.mem_Icc]
    refine ⟨?_, ?_⟩
    · exact_mod_cast h_lo_real
    · exact_mod_cast h_up_real
  have hqd : ∀ v : Fin m → Fin P, q_h v - q_h (predV v) ∈ Finset.Icc (-2 : ℤ) 2 := by
    intro v
    set x_val : ℝ := h (gridPt A₀ Δ v) / η
    set y_val : ℝ := h (gridPt A₀ Δ (predV v)) / η
    have hxy_abs : |x_val - y_val| ≤ 1 := by
      have hdiff : x_val - y_val = (h (gridPt A₀ Δ v) - h (gridPt A₀ Δ (predV v))) / η := by
        dsimp [x_val, y_val]; ring
      rw [hdiff, abs_div, abs_of_pos hη_pos, div_le_iff₀ hη_pos, one_mul]
      calc |h (gridPt A₀ Δ v) - h (gridPt A₀ Δ (predV v))|
          ≤ C * ‖gridPt A₀ Δ v - gridPt A₀ Δ (predV v)‖ := hh_lip _ _
        _ ≤ C * Δ := mul_le_mul_of_nonneg_left (norm_gridPt_sub_predV_le A₀ hΔ_pos.le v) hC.le
        _ ≤ η := hC_Δ
    rcases abs_le.mp hxy_abs with ⟨hxy_lo, hxy_hi⟩
    have hx1 := Int.floor_le x_val
    have hx2 := Int.lt_floor_add_one x_val
    have hy1 := Int.floor_le y_val
    have hy2 := Int.lt_floor_add_one y_val
    set d : ℤ := q_h v - q_h (predV v)
    have hd_real : (d : ℝ) = (Int.floor x_val : ℝ) - (Int.floor y_val : ℝ) := by
      dsimp [d, q_h, x_val, y_val]
      push_cast
      rfl
    have hd_lt : (d : ℝ) < (2 : ℝ) := by linarith
    have hd_gt : (-2 : ℝ) < (d : ℝ) := by linarith
    have hd_lt_int : d < 2 := by exact_mod_cast hd_lt
    have hd_gt_int : -2 < d := by exact_mod_cast hd_gt
    exact Finset.mem_Icc.mpr ⟨by omega, by omega⟩
  refine ⟨q_h, mem_validTables hP_pos_nat hq0 hqd, ?_⟩
  intro s hs
  have hs_mem : s ∈ Metric.closedBall (0 : UL.ZeroSumSubspace K) A₀ := by
    rwa [Metric.mem_closedBall, dist_zero_right]
  have hay_clamp : ay s = clampM M₀ (h (isoH s)) := by
    rw [hh_eq s hs]
    exact (clampM_eq_self (h_map hs_mem)).symm
  rw [hay_clamp]
  unfold approxProfile
  set u : EuclideanSpace ℝ (Fin m) := isoH s
  set v : Fin m → Fin P := cellIdx P hP A₀ Δ u
  have hu_norm : ‖u‖ ≤ A₀ := by
    dsimp [u]
    rwa [isoH.norm_map]
  have hcell_norm : ‖u - gridPt A₀ Δ v‖ ≤ Real.sqrt (m : ℝ) * Δ :=
    norm_sub_gridPt_cellIdx_le hP hA₀ hu_norm
  have hlip_err : |h u - h (gridPt A₀ Δ v)| ≤ η := by
    calc |h u - h (gridPt A₀ Δ v)|
        ≤ C * ‖u - gridPt A₀ Δ v‖ := hh_lip u (gridPt A₀ Δ v)
      _ ≤ C * (Real.sqrt (m : ℝ) * Δ) := mul_le_mul_of_nonneg_left hcell_norm hC.le
      _ = C * Real.sqrt (m : ℝ) * Δ := by ring
      _ ≤ η := hC_sqrt_Δ
  have hquant_err : |h (gridPt A₀ Δ v) - (q_h v : ℝ) * η| ≤ η := by
    set w : ℝ := h (gridPt A₀ Δ v) / η
    have hw_eq : h (gridPt A₀ Δ v) = w * η := (div_mul_cancel₀ _ hη_pos.ne').symm
    have hfl1 : (q_h v : ℝ) ≤ w := Int.floor_le w
    have hfl2 : w < (q_h v : ℝ) + 1 := Int.lt_floor_add_one w
    rw [hw_eq, abs_le]
    exact ⟨by nlinarith [hη_pos], by nlinarith [hη_pos]⟩
  calc |clampM M₀ (h u) - clampM M₀ ((q_h v : ℝ) * η)|
      ≤ |h u - (q_h v : ℝ) * η| := abs_clampM_sub_le M₀ _ _
    _ ≤ |h u - h (gridPt A₀ Δ v)| + |h (gridPt A₀ Δ v) - (q_h v : ℝ) * η| :=
        abs_sub_le _ _ _
    _ ≤ η + η := add_le_add hlip_err hquant_err
    _ = t / 2 := by dsimp [η]; ring

/-! ### Cardinality estimates -/

private lemma add_pow_le_two_pow_mul {a b : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b) (m : ℕ) :
    (a + b) ^ m ≤ (2 : ℝ) ^ m * (a ^ m + b ^ m) := by
  have ha_pow : 0 ≤ a ^ m := pow_nonneg ha m
  have hb_pow : 0 ≤ b ^ m := pow_nonneg hb m
  have h2_pow : (0 : ℝ) ≤ (2 : ℝ) ^ m := by positivity
  rcases le_total a b with hab | hba
  · calc (a + b) ^ m
        ≤ (2 * b) ^ m := pow_le_pow_left₀ (by linarith) (by linarith) m
      _ = (2 : ℝ) ^ m * b ^ m := mul_pow 2 b m
      _ ≤ (2 : ℝ) ^ m * (a ^ m + b ^ m) := by nlinarith
  · calc (a + b) ^ m
        ≤ (2 * a) ^ m := pow_le_pow_left₀ (by linarith) (by linarith) m
      _ = (2 : ℝ) ^ m * a ^ m := mul_pow 2 a m
      _ ≤ (2 : ℝ) ^ m * (a ^ m + b ^ m) := by nlinarith

private lemma eight_le_exp_three : (8 : ℝ) ≤ Real.exp 3 := by
  have h2 : (2 : ℝ) ≤ Real.exp 1 := by
    have h := Real.add_one_le_exp (1 : ℝ)
    linarith
  calc (8 : ℝ) = (2 : ℝ) ^ 3 := by norm_num
    _ ≤ (Real.exp 1) ^ 3 := pow_le_pow_left₀ (by norm_num) h2 3
    _ = Real.exp ((3 : ℕ) * (1 : ℝ)) := (Real.exp_nat_mul 1 3).symm
    _ = Real.exp 3 := by norm_num

private lemma combined_card_le_exp_coverExp {K : ℕ} (hK : 2 ≤ K)
    {A₀ C M₀ t : ℝ} (hA₀ : 0 < A₀) (hC : 0 < C) (hM₀ : 0 < M₀) (ht : 0 < t) :
    let m : ℕ := K - 1
    let η : ℝ := t / 4
    let P : ℕ := max 1 (Nat.ceil (8 * Real.sqrt (m : ℝ) * C * A₀ / t))
    let B_root : ℕ := Nat.ceil (M₀ / η) + 1
    let ε : ℝ := t / (2 * C)
    Real.exp (12 * (m : ℝ) ^ 2 * (A₀ / ε) ^ 2) *
        (((2 * B_root + 1) * 5 ^ (P ^ m) : ℕ) : ℝ) ^ K ≤
      Real.exp (coverExp K A₀ C M₀ t) := by
  intro m η P B_root ε
  have hK_real : (2 : ℝ) ≤ (K : ℝ) := by exact_mod_cast hK
  have hm_le_K : (m : ℝ) ≤ (K : ℝ) := Nat.cast_le.mpr (by omega)
  have hm_nonneg : (0 : ℝ) ≤ (m : ℝ) := Nat.cast_nonneg m
  set u : ℝ := C * A₀ / t
  have hu_pos : 0 < u := by dsimp [u]; positivity
  have hexpA :
      12 * (m : ℝ) ^ 2 * (A₀ / ε) ^ 2 ≤ 48 * (K : ℝ) ^ 2 * u ^ 2 := by
    have hdiv : A₀ / ε = 2 * u := by
      dsimp [ε, u]
      field_simp
    rw [hdiv]
    have hm_sq : (m : ℝ) ^ 2 ≤ (K : ℝ) ^ 2 := pow_le_pow_left₀ hm_nonneg hm_le_K 2
    nlinarith [sq_nonneg u]
  have hB_factor :
      ((2 * B_root + 1 : ℕ) : ℝ) ≤ Real.exp (3 + Real.log (1 + M₀ / t)) := by
    have hMη_nonneg : 0 ≤ M₀ / η := by dsimp [η]; positivity
    have hceil_lt : (Nat.ceil (M₀ / η) : ℝ) < M₀ / η + 1 := Nat.ceil_lt_add_one hMη_nonneg
    have hMη_eq : M₀ / η = 4 * (M₀ / t) := by dsimp [η]; ring
    have h2B1 : ((2 * B_root + 1 : ℕ) : ℝ) ≤ 8 * (1 + M₀ / t) := by
      dsimp [B_root]
      push_cast
      linarith
    have h1Mt_pos : 0 < 1 + M₀ / t := by positivity
    calc ((2 * B_root + 1 : ℕ) : ℝ)
        ≤ 8 * (1 + M₀ / t) := h2B1
      _ = 8 * Real.exp (Real.log (1 + M₀ / t)) := by rw [Real.exp_log h1Mt_pos]
      _ ≤ Real.exp 3 * Real.exp (Real.log (1 + M₀ / t)) :=
          mul_le_mul_of_nonneg_right eight_le_exp_three (Real.exp_pos _).le
      _ = Real.exp (3 + Real.log (1 + M₀ / t)) := (Real.exp_add _ _).symm
  have h5_factor :
      (((5 ^ (P ^ m) : ℕ) : ℝ)) ≤ Real.exp (3 * (P : ℝ) ^ m) := by
    have h5_le : (5 : ℝ) ≤ Real.exp 3 := by linarith [eight_le_exp_three]
    calc (((5 ^ (P ^ m) : ℕ) : ℝ))
        = (5 : ℝ) ^ (P ^ m) := by push_cast; rfl
      _ ≤ (Real.exp 3) ^ (P ^ m) := pow_le_pow_left₀ (by norm_num) h5_le (P ^ m)
      _ = Real.exp (((P ^ m : ℕ) : ℝ) * 3) := (Real.exp_nat_mul 3 (P ^ m)).symm
      _ = Real.exp (3 * (P : ℝ) ^ m) := by congr 1; push_cast; ring
  have hPm_le :
      (P : ℝ) ^ m ≤ (16 * (K : ℝ)) ^ K * (1 + u ^ m) := by
    have hsqrt_le_K : Real.sqrt (m : ℝ) ≤ (K : ℝ) := by
      have hm_le_Ksq : (m : ℝ) ≤ (K : ℝ) ^ 2 := by nlinarith
      calc Real.sqrt (m : ℝ)
          ≤ Real.sqrt ((K : ℝ) ^ 2) := Real.sqrt_le_sqrt hm_le_Ksq
        _ = (K : ℝ) := Real.sqrt_sq (by linarith)
    set X_val : ℝ := 8 * Real.sqrt (m : ℝ) * C * A₀ / t
    have hX_nonneg : 0 ≤ X_val := by dsimp [X_val]; positivity
    have hX_le : X_val ≤ 8 * (K : ℝ) * u := by
      have hrew : X_val = 8 * Real.sqrt (m : ℝ) * u := by dsimp [X_val, u]; ring
      rw [hrew]
      nlinarith [hu_pos]
    have hP_le : (P : ℝ) ≤ 8 * (K : ℝ) * (1 + u) := by
      have hceil_X : (Nat.ceil X_val : ℝ) < X_val + 1 := Nat.ceil_lt_add_one hX_nonneg
      dsimp [P]
      rcases max_choice 1 (Nat.ceil X_val) with hP_eq | hP_eq
      · rw [hP_eq]
        push_cast
        nlinarith
      · rw [hP_eq]
        linarith
    have h16K_ge1 : (1 : ℝ) ≤ 16 * (K : ℝ) := by linarith
    have h16K_pow : (16 * (K : ℝ)) ^ m ≤ (16 * (K : ℝ)) ^ K :=
      pow_le_pow_right₀ h16K_ge1 (by omega)
    calc (P : ℝ) ^ m
        ≤ (8 * (K : ℝ) * (1 + u)) ^ m := pow_le_pow_left₀ (Nat.cast_nonneg P) hP_le m
      _ = (8 * (K : ℝ)) ^ m * (1 + u) ^ m := mul_pow _ _ m
      _ ≤ (8 * (K : ℝ)) ^ m * ((2 : ℝ) ^ m * (1 ^ m + u ^ m)) :=
          mul_le_mul_of_nonneg_left (add_pow_le_two_pow_mul zero_le_one hu_pos.le m)
            (by positivity)
      _ = (16 * (K : ℝ)) ^ m * (1 + u ^ m) := by
          rw [one_pow, ← mul_assoc, ← mul_pow]
          ring
      _ ≤ (16 * (K : ℝ)) ^ K * (1 + u ^ m) :=
          mul_le_mul_of_nonneg_right h16K_pow (by positivity)
  have hprod_K :
      (((2 * B_root + 1) * 5 ^ (P ^ m) : ℕ) : ℝ) ^ K ≤
        Real.exp ((K : ℝ) * (3 + Real.log (1 + M₀ / t) + 3 * (P : ℝ) ^ m)) := by
    have hsingle :
        (((2 * B_root + 1) * 5 ^ (P ^ m) : ℕ) : ℝ) ≤
          Real.exp (3 + Real.log (1 + M₀ / t) + 3 * (P : ℝ) ^ m) := by
      calc (((2 * B_root + 1) * 5 ^ (P ^ m) : ℕ) : ℝ)
          = ((2 * B_root + 1 : ℕ) : ℝ) * (((5 ^ (P ^ m) : ℕ) : ℝ)) := Nat.cast_mul _ _
        _ ≤ Real.exp (3 + Real.log (1 + M₀ / t)) * Real.exp (3 * (P : ℝ) ^ m) :=
            mul_le_mul hB_factor h5_factor (Nat.cast_nonneg _) (Real.exp_pos _).le
        _ = Real.exp (3 + Real.log (1 + M₀ / t) + 3 * (P : ℝ) ^ m) := (Real.exp_add _ _).symm
    calc (((2 * B_root + 1) * 5 ^ (P ^ m) : ℕ) : ℝ) ^ K
        ≤ (Real.exp (3 + Real.log (1 + M₀ / t) + 3 * (P : ℝ) ^ m)) ^ K :=
          pow_le_pow_left₀ (Nat.cast_nonneg _) hsingle K
      _ = Real.exp ((K : ℝ) * (3 + Real.log (1 + M₀ / t) + 3 * (P : ℝ) ^ m)) :=
          (Real.exp_nat_mul _ K).symm
  calc Real.exp (12 * (m : ℝ) ^ 2 * (A₀ / ε) ^ 2) *
        (((2 * B_root + 1) * 5 ^ (P ^ m) : ℕ) : ℝ) ^ K
      ≤ Real.exp (48 * (K : ℝ) ^ 2 * u ^ 2) *
          Real.exp ((K : ℝ) * (3 + Real.log (1 + M₀ / t) + 3 * (P : ℝ) ^ m)) :=
        mul_le_mul (Real.exp_le_exp.mpr hexpA) hprod_K
          (by positivity) (Real.exp_pos _).le
    _ = Real.exp (48 * (K : ℝ) ^ 2 * u ^ 2 +
          (K : ℝ) * (3 + Real.log (1 + M₀ / t) + 3 * (P : ℝ) ^ m)) := (Real.exp_add _ _).symm
    _ ≤ Real.exp (coverExp K A₀ C M₀ t) := by
        apply Real.exp_le_exp.mpr
        unfold coverExp kappaK
        change 48 * (K : ℝ) ^ 2 * u ^ 2 +
            (K : ℝ) * (3 + Real.log (1 + M₀ / t) + 3 * (P : ℝ) ^ m) ≤
          (48 * (K : ℝ) ^ 2 + 6 * (K : ℝ) * (16 * (K : ℝ)) ^ K) *
            (1 + Real.log (1 + M₀ / t) + u ^ 2 + u ^ m)
        set E_K : ℝ := (16 * (K : ℝ)) ^ K
        set L_term : ℝ := Real.log (1 + M₀ / t)
        have hEK_ge1 : (1 : ℝ) ≤ E_K := one_le_pow₀ (by linarith)
        have hlog_nonneg : 0 ≤ L_term :=
          Real.log_nonneg (by linarith [div_pos hM₀ ht])
        have hu2_nonneg : 0 ≤ u ^ 2 := sq_nonneg u
        have hum_nonneg : 0 ≤ u ^ m := pow_nonneg hu_pos.le m
        have hKEK_nonneg : 0 ≤ (K : ℝ) * E_K := by positivity
        have h1 : 48 * (K : ℝ) ^ 2 * u ^ 2 ≤
            48 * (K : ℝ) ^ 2 * (1 + L_term + u ^ 2 + u ^ m) :=
          mul_le_mul_of_nonneg_left (by linarith) (by positivity)
        have h2 : 3 * (K : ℝ) ≤ 3 * ((K : ℝ) * E_K) := by nlinarith
        have h3 : (K : ℝ) * L_term ≤ 6 * ((K : ℝ) * E_K) * L_term :=
          mul_le_mul_of_nonneg_right (by nlinarith) hlog_nonneg
        have h4 : 3 * (K : ℝ) * (P : ℝ) ^ m ≤
            3 * ((K : ℝ) * E_K) + 3 * ((K : ℝ) * E_K) * u ^ m := by
          have h0 : 0 ≤ 3 * (K : ℝ) := by linarith
          calc 3 * (K : ℝ) * (P : ℝ) ^ m
              ≤ 3 * (K : ℝ) * (E_K * (1 + u ^ m)) := mul_le_mul_of_nonneg_left hPm_le h0
            _ = 3 * ((K : ℝ) * E_K) + 3 * ((K : ℝ) * E_K) * u ^ m := by ring
        have h5 : 0 ≤ 6 * ((K : ℝ) * E_K) * u ^ 2 := mul_nonneg (by positivity) hu2_nonneg
        have h6 : 0 ≤ 3 * ((K : ℝ) * E_K) * u ^ m := mul_nonneg (by positivity) hum_nonneg
        linarith

/-- Empirical `L²` `t`-covering number of `ScoreProfileClass X K L R C M₀` on any sample
`z : Fin n → Metric.closedBall (0 : X) L × Fin K`. -/
theorem exists_empirical_cover_scoreProfileClass
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R C M₀ t : ℝ} (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀) (ht : 0 < t)
    (z : Fin n → Metric.closedBall (0 : X) L × Fin K) :
    ∃ G : Finset (Fin n → ℝ),
      G.Nonempty ∧
      (∀ g ∈ G, ∀ i : Fin n, |g i| ≤ M₀) ∧
      (G.card : ℝ) ≤ Real.exp (coverExp K (L * R) C M₀ t) ∧
      ∀ f ∈ UL.ScoreProfileClass X K L R C M₀,
        ∃ g ∈ G, ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f (z i) - g i) ^ 2 ≤ t ^ 2 := by
  classical
  set m : ℕ := K - 1
  have hm : 1 ≤ m := by omega
  set A₀ : ℝ := L * R
  have hA₀ : 0 < A₀ := mul_pos hL hR
  let isoH : UL.ZeroSumSubspace K ≃ₗᵢ[ℝ] EuclideanSpace ℝ (Fin m) :=
    ((stdOrthonormalBasis ℝ (UL.ZeroSumSubspace K)).reindex
      (finCongr (UL.Proof_lem_C_2.finrank_zeroSumSubspace K hK))).repr
  set η : ℝ := t / 4
  set P : ℕ := max 1 (Nat.ceil (8 * Real.sqrt (m : ℝ) * C * A₀ / t))
  have hP : 1 ≤ P := le_max_left 1 _
  set Δ : ℝ := 2 * A₀ / (P : ℝ)
  set B_root : ℕ := Nat.ceil (M₀ / η) + 1
  set ε : ℝ := t / (2 * C)
  have hε : 0 < ε := by dsimp [ε]; positivity
  let x : Fin n → X := fun i => ((z i).1 : X)
  have hx : ∀ i : Fin n, ‖x i‖ ≤ L := by
    intro i
    have hmem := (z i).1.2
    rwa [Metric.mem_closedBall, dist_zero_right] at hmem
  obtain ⟨G_score, hG_score_ne, hG_score_norm, hG_score_card, hG_score_cov⟩ :=
    exists_score_ball_cover hK hn hL hR hε x hx
  set Q_valid := validTables m P B_root
  set Q_prof : Finset (Fin K → ((Fin m → Fin P) → ℤ)) :=
    Fintype.piFinset (fun _ : Fin K => Q_valid)
  have hQ_prof_ne : Q_prof.Nonempty := by
    rcases validTables_nonempty m P B_root with ⟨q₀, hq₀⟩
    exact ⟨fun _ => q₀, Fintype.mem_piFinset.mpr fun _ => hq₀⟩
  let evalNet :
      (Fin n → UL.ZeroSumSubspace K) × (Fin K → ((Fin m → Fin P) → ℤ)) → (Fin n → ℝ) :=
    fun sp i => approxProfile hP isoH A₀ Δ η M₀ (sp.2 (z i).2) (sp.1 i)
  let G : Finset (Fin n → ℝ) := (G_score ×ˢ Q_prof).image evalNet
  refine ⟨G, ?_, ?_, ?_, ?_⟩
  · exact (hG_score_ne.product hQ_prof_ne).image evalNet
  · intro g hg i
    rcases Finset.mem_image.mp hg with ⟨sp, _, rfl⟩
    exact abs_approxProfile_le hP isoH A₀ Δ η hM₀.le (sp.2 (z i).2) (sp.1 i)
  · have hcard_nat :
        G.card ≤ G_score.card * ((2 * B_root + 1) * 5 ^ (P ^ m)) ^ K := by
      calc G.card
          ≤ (G_score ×ˢ Q_prof).card := Finset.card_image_le
        _ = G_score.card * Q_prof.card := Finset.card_product _ _
        _ = G_score.card * Q_valid.card ^ K := by
            dsimp [Q_prof]
            rw [Fintype.card_piFinset, Finset.prod_const, Finset.card_univ, Fintype.card_fin]
        _ ≤ G_score.card * ((2 * B_root + 1) * 5 ^ (P ^ m)) ^ K :=
            Nat.mul_le_mul_left _ (Nat.pow_le_pow_left (card_validTables_le m P B_root) K)
    have hcard_real :
        (G.card : ℝ) ≤
          (G_score.card : ℝ) * (((2 * B_root + 1) * 5 ^ (P ^ m) : ℕ) : ℝ) ^ K := by
      exact_mod_cast hcard_nat
    calc (G.card : ℝ)
        ≤ (G_score.card : ℝ) * (((2 * B_root + 1) * 5 ^ (P ^ m) : ℕ) : ℝ) ^ K := hcard_real
      _ ≤ Real.exp (12 * ((K - 1 : ℕ) : ℝ) ^ 2 * (L * R / ε) ^ 2) *
            (((2 * B_root + 1) * 5 ^ (P ^ m) : ℕ) : ℝ) ^ K :=
          mul_le_mul_of_nonneg_right hG_score_card (by positivity)
      _ ≤ Real.exp (coverExp K (L * R) C M₀ t) :=
          combined_card_le_exp_coverExp hK hA₀ hC hM₀ ht
  · intro f hf
    rcases hf with ⟨_, _, _, _, _, W, a, hW, ha, hf_eq⟩
    obtain ⟨s, hs_mem, hs_err⟩ := hG_score_cov W hW
    have hex_q : ∀ y : Fin K,
        ∃ q ∈ Q_valid, ∀ u : UL.ZeroSumSubspace K, ‖u‖ ≤ A₀ →
          |a y u - approxProfile hP isoH A₀ Δ η M₀ q u| ≤ t / 2 :=
      fun y => exists_table_approx_profile hm isoH hA₀ hC hM₀ ht (a y) (ha y).1 (ha y).2
    choose p hp_mem hp_err using hex_q
    have hp_prof : p ∈ Q_prof := Fintype.mem_piFinset.mpr hp_mem
    let g : Fin n → ℝ := evalNet (s, p)
    have hg_mem : g ∈ G :=
      Finset.mem_image.mpr ⟨(s, p), Finset.mem_product.mpr ⟨hs_mem, hp_prof⟩, rfl⟩
    refine ⟨g, hg_mem, ?_⟩
    have hpt_sq : ∀ i : Fin n,
        (f (z i) - g i) ^ 2 ≤ 2 * C ^ 2 * ‖W (x i) - s i‖ ^ 2 + t ^ 2 / 2 := by
      intro i
      have hzi : f (z i) = a (z i).2 (W (x i)) := by
        have heq := hf_eq (z i).1 (z i).2
        simpa only [Prod.mk.eta] using heq
      have hWxi_norm : ‖W (x i)‖ ≤ A₀ := by
        calc ‖W (x i)‖
            ≤ UL.hilbertSchmidtNorm W * ‖x i‖ :=
              UL.Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm W (x i)
          _ ≤ R * L := mul_le_mul hW (hx i) (norm_nonneg _) hR.le
          _ = A₀ := mul_comm R L
      have hsi_norm : ‖s i‖ ≤ A₀ := hG_score_norm s hs_mem i
      have hWxi_ball : W (x i) ∈ Metric.closedBall (0 : UL.ZeroSumSubspace K) (L * R) := by
        rw [Metric.mem_closedBall, dist_zero_right]
        exact hWxi_norm
      have hsi_ball : s i ∈ Metric.closedBall (0 : UL.ZeroSumSubspace K) (L * R) := by
        rw [Metric.mem_closedBall, dist_zero_right]
        exact hsi_norm
      have hlip_i : |a (z i).2 (W (x i)) - a (z i).2 (s i)| ≤ C * ‖W (x i) - s i‖ := by
        calc |a (z i).2 (W (x i)) - a (z i).2 (s i)|
            = dist (a (z i).2 (W (x i))) (a (z i).2 (s i)) := (Real.dist_eq _ _).symm
          _ ≤ (Real.toNNReal C : ℝ) * dist (W (x i)) (s i) :=
              (ha (z i).2).1.dist_le_mul (W (x i)) hWxi_ball (s i) hsi_ball
          _ = C * ‖W (x i) - s i‖ := by
              rw [Real.coe_toNNReal C hC.le, dist_eq_norm]
      have hprof_i : |a (z i).2 (s i) - g i| ≤ t / 2 :=
        hp_err (z i).2 (s i) hsi_norm
      have habs_i : |f (z i) - g i| ≤ C * ‖W (x i) - s i‖ + t / 2 := by
        rw [hzi]
        calc |a (z i).2 (W (x i)) - g i|
            ≤ |a (z i).2 (W (x i)) - a (z i).2 (s i)| + |a (z i).2 (s i) - g i| :=
              abs_sub_le _ _ _
          _ ≤ C * ‖W (x i) - s i‖ + t / 2 := add_le_add hlip_i hprof_i
      have hsq1 : (f (z i) - g i) ^ 2 ≤ (C * ‖W (x i) - s i‖ + t / 2) ^ 2 := by
        rw [← sq_abs (f (z i) - g i)]
        exact pow_le_pow_left₀ (abs_nonneg _) habs_i 2
      have hsq2 :
          (C * ‖W (x i) - s i‖ + t / 2) ^ 2 ≤
            2 * C ^ 2 * ‖W (x i) - s i‖ ^ 2 + t ^ 2 / 2 := by
        nlinarith [sq_nonneg (C * ‖W (x i) - s i‖ - t / 2)]
      exact hsq1.trans hsq2
    have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
    have hsum_le :
        ∑ i : Fin n, (f (z i) - g i) ^ 2 ≤
          2 * C ^ 2 * (∑ i : Fin n, ‖W (x i) - s i‖ ^ 2) + (n : ℝ) * (t ^ 2 / 2) := by
      calc ∑ i : Fin n, (f (z i) - g i) ^ 2
          ≤ ∑ i : Fin n, (2 * C ^ 2 * ‖W (x i) - s i‖ ^ 2 + t ^ 2 / 2) :=
            Finset.sum_le_sum fun i _ => hpt_sq i
        _ = (∑ i : Fin n, 2 * C ^ 2 * ‖W (x i) - s i‖ ^ 2) +
              ∑ _ : Fin n, (t ^ 2 / 2) := Finset.sum_add_distrib
        _ = 2 * C ^ 2 * (∑ i : Fin n, ‖W (x i) - s i‖ ^ 2) + (n : ℝ) * (t ^ 2 / 2) := by
            rw [← Finset.mul_sum, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
              nsmul_eq_mul]
    have havg_le :
        ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f (z i) - g i) ^ 2 ≤
          2 * C ^ 2 * (((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, ‖W (x i) - s i‖ ^ 2) + t ^ 2 / 2 := by
      calc ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f (z i) - g i) ^ 2
          ≤ ((1 : ℝ) / (n : ℝ)) *
              (2 * C ^ 2 * (∑ i : Fin n, ‖W (x i) - s i‖ ^ 2) + (n : ℝ) * (t ^ 2 / 2)) :=
            mul_le_mul_of_nonneg_left hsum_le (by positivity)
        _ = 2 * C ^ 2 * (((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, ‖W (x i) - s i‖ ^ 2) +
              t ^ 2 / 2 := by
            field_simp [hn_pos.ne']
    have h2C2_eps : 2 * C ^ 2 * ε ^ 2 = t ^ 2 / 2 := by
      dsimp [ε]
      field_simp [hC.ne']
    calc ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f (z i) - g i) ^ 2
        ≤ 2 * C ^ 2 * (((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, ‖W (x i) - s i‖ ^ 2) + t ^ 2 / 2 :=
          havg_le
      _ ≤ 2 * C ^ 2 * ε ^ 2 + t ^ 2 / 2 := by
          nlinarith [sq_nonneg C, hs_err]
      _ = t ^ 2 := by linarith [h2C2_eps]

end UL.Proof_lem_C_3_Race2

import Mathlib
import UL.Stmt.lem_C_3
import UL.Stmt.cit_mcdiarmid1989
import UL.Proof.lem_C_3.Race2.H3_Chaining
set_option autoImplicit false

namespace UL.Proof_lem_C_3_Race2

noncomputable def totalConst (K : ℕ) : ℝ :=
  2 * chainConst K + 4

theorem totalConst_pos (K : ℕ) : 0 < totalConst K := by
  unfold totalConst
  linarith [chainConst_pos K]

/-! ### Helper inequalities and measurability of suprema -/

private theorem abs_add_le_add_abs (x y : ℝ) : |x + y| ≤ |x| + |y| := by
  simpa only [Real.norm_eq_abs] using norm_add_le x y

private theorem abs_sub_le_add_abs (x y : ℝ) : |x - y| ≤ |x| + |y| := by
  simpa only [Real.norm_eq_abs] using norm_sub_le x y

private theorem abs_sum_le_sum_abs {ι : Type*} (s : Finset ι) (f : ι → ℝ) :
    |∑ i ∈ s, f i| ≤ ∑ i ∈ s, |f i| := by
  simpa only [Real.norm_eq_abs] using norm_sum_le s f

private theorem measurable_sSup_of_continuous
    {E ι : Type*} [TopologicalSpace E] [MeasurableSpace E] [OpensMeasurableSpace E]
    {S : Set ι} (hS : S.Nonempty) {M : ℝ} {F : ι → E → ℝ}
    (hcont : ∀ a ∈ S, Continuous (F a))
    (hbdd : ∀ a ∈ S, ∀ z : E, F a z ≤ M) :
    Measurable (fun z : E => sSup ((fun a => F a z) '' S)) := by
  refine measurable_of_Ioi fun c => ?_
  have h_eq : (fun z : E => sSup ((fun a => F a z) '' S)) ⁻¹' Set.Ioi c =
      ⋃ a ∈ S, F a ⁻¹' Set.Ioi c := by
    ext z
    have hbdd_z : BddAbove ((fun a => F a z) '' S) :=
      ⟨M, by rintro _ ⟨a, ha, rfl⟩; exact hbdd a ha z⟩
    simp only [Set.mem_preimage, Set.mem_Ioi, Set.mem_iUnion, exists_prop]
    rw [lt_csSup_iff hbdd_z (hS.image _)]
    constructor
    · rintro ⟨_, ⟨a, ha, rfl⟩, hc⟩
      exact ⟨a, ha, hc⟩
    · rintro ⟨a, ha, hc⟩
      exact ⟨F a z, ⟨a, ha, rfl⟩, hc⟩
  rw [h_eq]
  exact (isOpen_biUnion fun a ha => isOpen_Ioi.preimage (hcont a ha)).measurableSet

private theorem mp_integral_comp
    {α β : Type*} [MeasurableSpace α] [MeasurableSpace β]
    {μa : MeasureTheory.Measure α} {μb : MeasureTheory.Measure β}
    {f : α → β} (hf : MeasureTheory.MeasurePreserving f μa μb)
    {g : β → ℝ} (hg : Measurable g) :
    (∫ x, g (f x) ∂μa) = ∫ y, g y ∂μb := by
  rw [← hf.map_eq, MeasureTheory.integral_map hf.measurable.aemeasurable hg.aestronglyMeasurable]

private theorem bounded_measurable_integrable
    {α : Type*} [MeasurableSpace α]
    (μ : MeasureTheory.Measure α) [MeasureTheory.IsProbabilityMeasure μ]
    {g : α → ℝ} (hg : Measurable g) {M : ℝ}
    (h0 : ∀ x, 0 ≤ g x) (hM : ∀ x, g x ≤ M) :
    MeasureTheory.Integrable g μ := by
  refine (MeasureTheory.integrable_const M).mono' hg.aestronglyMeasurable ?_
  exact Filter.Eventually.of_forall fun x => by
    rw [Real.norm_eq_abs, abs_of_nonneg (h0 x)]
    exact hM x

/-! ### Basic properties of `ScoreProfileClass` -/

private theorem zero_mem_scoreProfileClass
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {K : ℕ} (hK : 2 ≤ K) {L R C M₀ : ℝ}
    (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀) :
    (fun _ : Metric.closedBall (0 : X) L × Fin K => (0 : ℝ)) ∈
      UL.ScoreProfileClass X K L R C M₀ := by
  refine ⟨hK, hL, hR, hC, hM₀, 0, fun _ _ => 0, ?_, ?_, ?_⟩
  · rw [UL.Proof_lem_C_2.hilbertSchmidtNorm_zero]
    exact hR.le
  · intro y
    refine ⟨fun _ _ _ _ => by simp, fun _ _ => ?_⟩
    simp [hM₀.le]
  · intro _ _
    rfl

private theorem score_mem_closedBall_of_op
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X] [CompleteSpace X]
    {K : ℕ} {L R : ℝ} (hR : 0 < R)
    {W : X →L[ℝ] UL.ZeroSumSubspace K} (hW : UL.hilbertSchmidtNorm W ≤ R)
    (x : Metric.closedBall (0 : X) L) :
    W (x : X) ∈ Metric.closedBall (0 : UL.ZeroSumSubspace K) (L * R) := by
  rw [Metric.mem_closedBall, dist_zero_right]
  have hx : ‖(x : X)‖ ≤ L := by
    simpa only [Metric.mem_closedBall, dist_zero_right] using x.2
  calc
    ‖W (x : X)‖ ≤ UL.hilbertSchmidtNorm W * ‖(x : X)‖ :=
      UL.Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm W (x : X)
    _ ≤ R * L := mul_le_mul hW hx (norm_nonneg _) hR.le
    _ = L * R := mul_comm R L

private theorem abs_le_of_mem_scoreProfileClass
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {K : ℕ} {L R C M₀ : ℝ}
    {f : Metric.closedBall (0 : X) L × Fin K → ℝ}
    (hf : f ∈ UL.ScoreProfileClass X K L R C M₀)
    (q : Metric.closedBall (0 : X) L × Fin K) :
    |f q| ≤ M₀ := by
  rcases hf with ⟨_, _, hR, _, _, W, a, hW, ha, hfeq⟩
  rw [hfeq q.1 q.2]
  have hmem := (ha q.2).2 (score_mem_closedBall_of_op hR hW q.1)
  exact abs_le.mpr ⟨hmem.1, hmem.2⟩

private theorem continuous_of_mem_scoreProfileClass
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {K : ℕ} {L R C M₀ : ℝ}
    {f : Metric.closedBall (0 : X) L × Fin K → ℝ}
    (hf : f ∈ UL.ScoreProfileClass X K L R C M₀) :
    Continuous f := by
  rcases hf with ⟨_, _, hR, _, _, W, a, hW, ha, hfeq⟩
  rw [continuous_iff_continuousAt]
  intro q
  have h_gy : Continuous (fun x : Metric.closedBall (0 : X) L => a q.2 (W (x : X))) :=
    ((ha q.2).1.continuousOn).comp_continuous
      (W.continuous.comp continuous_subtype_val)
      (fun x => score_mem_closedBall_of_op hR hW x)
  have h_cont : ContinuousAt (fun p : Metric.closedBall (0 : X) L × Fin K => a q.2 (W (p.1 : X))) q :=
    (h_gy.comp continuous_fst).continuousAt
  refine h_cont.congr ?_
  have h_open : IsOpen
      ((Prod.snd : Metric.closedBall (0 : X) L × Fin K → Fin K) ⁻¹' ({q.2} : Set (Fin K))) :=
    (isOpen_discrete ({q.2} : Set (Fin K))).preimage continuous_snd
  filter_upwards [h_open.mem_nhds (Set.mem_singleton q.2)] with p hp
  simp only [Set.mem_preimage, Set.mem_singleton_iff] at hp
  rw [hfeq p.1 p.2, hp]

/-! ### Empirical deviation `dev₀`, `ghostSup`, measurability, and bounded differences -/

private noncomputable def dev₀
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    [MeasurableSpace X] [BorelSpace X]
    {K : ℕ} {L : ℝ}
    (ν₀ : MeasureTheory.Measure (Metric.closedBall (0 : X) L × Fin K))
    (n : ℕ) (R C M₀ : ℝ)
    (z : Fin n → Metric.closedBall (0 : X) L × Fin K) : ℝ :=
  sSup ((fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
    |(∫ q, f q ∂ν₀) - ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, f (z i)|) ''
    UL.ScoreProfileClass X K L R C M₀)

private noncomputable def ghostSup
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    (K n : ℕ) (L R C M₀ : ℝ)
    (zz' : (Fin n → Metric.closedBall (0 : X) L × Fin K) ×
      (Fin n → Metric.closedBall (0 : X) L × Fin K)) : ℝ :=
  sSup ((fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
    |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f (zz'.2 i) - f (zz'.1 i))|) ''
    UL.ScoreProfileClass X K L R C M₀)

private theorem integrable_profile_ν₀
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    [MeasurableSpace X] [BorelSpace X]
    {K : ℕ} {L R C M₀ : ℝ}
    (ν₀ : MeasureTheory.Measure (Metric.closedBall (0 : X) L × Fin K))
    [MeasureTheory.IsProbabilityMeasure ν₀]
    {f : Metric.closedBall (0 : X) L × Fin K → ℝ}
    (hf : f ∈ UL.ScoreProfileClass X K L R C M₀) :
    MeasureTheory.Integrable f ν₀ := by
  refine (MeasureTheory.integrable_const M₀).mono'
    (continuous_of_mem_scoreProfileClass hf).aestronglyMeasurable ?_
  exact Filter.Eventually.of_forall fun q => by
    rw [Real.norm_eq_abs]
    exact abs_le_of_mem_scoreProfileClass hf q

private theorem abs_integral_profile_le
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    [MeasurableSpace X] [BorelSpace X]
    {K : ℕ} {L R C M₀ : ℝ}
    (ν₀ : MeasureTheory.Measure (Metric.closedBall (0 : X) L × Fin K))
    [MeasureTheory.IsProbabilityMeasure ν₀]
    {f : Metric.closedBall (0 : X) L × Fin K → ℝ}
    (hf : f ∈ UL.ScoreProfileClass X K L R C M₀) :
    |∫ q, f q ∂ν₀| ≤ M₀ := by
  calc
    |∫ q, f q ∂ν₀|
        = ‖∫ q, f q ∂ν₀‖ := (Real.norm_eq_abs _).symm
    _ ≤ ∫ q, ‖f q‖ ∂ν₀ := MeasureTheory.norm_integral_le_integral_norm _
    _ ≤ ∫ _ : Metric.closedBall (0 : X) L × Fin K, M₀ ∂ν₀ := by
        refine MeasureTheory.integral_mono (integrable_profile_ν₀ ν₀ hf).norm
          (MeasureTheory.integrable_const M₀) fun q => ?_
        rw [Real.norm_eq_abs]
        exact abs_le_of_mem_scoreProfileClass hf q
    _ = M₀ := by simp

private theorem abs_emp_profile_le
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {K n : ℕ} (hn : 1 ≤ n) {L R C M₀ : ℝ}
    {f : Metric.closedBall (0 : X) L × Fin K → ℝ}
    (hf : f ∈ UL.ScoreProfileClass X K L R C M₀)
    (z : Fin n → Metric.closedBall (0 : X) L × Fin K) :
    |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, f (z i)| ≤ M₀ := by
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  rw [abs_mul, abs_of_pos (one_div_pos.mpr hn_pos)]
  calc
    (1 : ℝ) / (n : ℝ) * |∑ i : Fin n, f (z i)|
        ≤ (1 : ℝ) / (n : ℝ) * ∑ i : Fin n, |f (z i)| := by
          gcongr
          exact abs_sum_le_sum_abs _ _
    _ ≤ (1 : ℝ) / (n : ℝ) * ∑ _i : Fin n, M₀ := by
          gcongr with i
          exact abs_le_of_mem_scoreProfileClass hf (z i)
    _ = M₀ := by
          simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, one_div,
            inv_mul_cancel_left₀ hn_pos.ne']

private theorem dev₀_term_le
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    [MeasurableSpace X] [BorelSpace X]
    {K n : ℕ} (hn : 1 ≤ n) {L R C M₀ : ℝ}
    (ν₀ : MeasureTheory.Measure (Metric.closedBall (0 : X) L × Fin K))
    [MeasureTheory.IsProbabilityMeasure ν₀]
    {f : Metric.closedBall (0 : X) L × Fin K → ℝ}
    (hf : f ∈ UL.ScoreProfileClass X K L R C M₀)
    (z : Fin n → Metric.closedBall (0 : X) L × Fin K) :
    |(∫ q, f q ∂ν₀) - ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, f (z i)| ≤ 2 * M₀ := by
  calc
    |(∫ q, f q ∂ν₀) - ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, f (z i)|
        ≤ |∫ q, f q ∂ν₀| + |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, f (z i)| :=
          abs_sub_le_add_abs _ _
    _ ≤ M₀ + M₀ := add_le_add (abs_integral_profile_le ν₀ hf) (abs_emp_profile_le hn hf z)
    _ = 2 * M₀ := by ring

private theorem ghostSup_term_le
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {K n : ℕ} (hn : 1 ≤ n) {L R C M₀ : ℝ}
    {f : Metric.closedBall (0 : X) L × Fin K → ℝ}
    (hf : f ∈ UL.ScoreProfileClass X K L R C M₀)
    (zz' : (Fin n → Metric.closedBall (0 : X) L × Fin K) ×
      (Fin n → Metric.closedBall (0 : X) L × Fin K)) :
    |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f (zz'.2 i) - f (zz'.1 i))| ≤ 2 * M₀ := by
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  rw [abs_mul, abs_of_pos (one_div_pos.mpr hn_pos)]
  calc
    (1 : ℝ) / (n : ℝ) * |∑ i : Fin n, (f (zz'.2 i) - f (zz'.1 i))|
        ≤ (1 : ℝ) / (n : ℝ) * ∑ i : Fin n, |f (zz'.2 i) - f (zz'.1 i)| := by
          gcongr
          exact abs_sum_le_sum_abs _ _
    _ ≤ (1 : ℝ) / (n : ℝ) * ∑ _i : Fin n, (2 * M₀) := by
          gcongr with i
          calc
            |f (zz'.2 i) - f (zz'.1 i)| ≤ |f (zz'.2 i)| + |f (zz'.1 i)| := abs_sub_le_add_abs _ _
            _ ≤ M₀ + M₀ := add_le_add (abs_le_of_mem_scoreProfileClass hf (zz'.2 i))
                (abs_le_of_mem_scoreProfileClass hf (zz'.1 i))
            _ = 2 * M₀ := by ring
    _ = 2 * M₀ := by
          simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, one_div,
            inv_mul_cancel_left₀ hn_pos.ne']

private theorem radSupSample_term_le
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {K n : ℕ} (hn : 1 ≤ n) {L R C M₀ : ℝ}
    (σ : Fin n → Bool)
    {f : Metric.closedBall (0 : X) L × Fin K → ℝ}
    (hf : f ∈ UL.ScoreProfileClass X K L R C M₀)
    (z : Fin n → Metric.closedBall (0 : X) L × Fin K) :
    |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * f (z i)| ≤ M₀ := by
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  rw [abs_mul, abs_of_pos (one_div_pos.mpr hn_pos)]
  calc
    (1 : ℝ) / (n : ℝ) * |∑ i : Fin n, radSign (σ i) * f (z i)|
        ≤ (1 : ℝ) / (n : ℝ) * ∑ i : Fin n, |radSign (σ i) * f (z i)| := by
          gcongr
          exact abs_sum_le_sum_abs _ _
    _ ≤ (1 : ℝ) / (n : ℝ) * ∑ _i : Fin n, M₀ := by
          gcongr with i
          have hrad : |radSign (σ i)| = 1 := by
            unfold radSign
            cases σ i <;> norm_num
          rw [abs_mul, hrad, one_mul]
          exact abs_le_of_mem_scoreProfileClass hf (z i)
    _ = M₀ := by
          simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, one_div,
            inv_mul_cancel_left₀ hn_pos.ne']

private theorem measurable_dev₀
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    [MeasurableSpace X] [BorelSpace X]
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R C M₀ : ℝ} (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀)
    (ν₀ : MeasureTheory.Measure (Metric.closedBall (0 : X) L × Fin K))
    [MeasureTheory.IsProbabilityMeasure ν₀] :
    Measurable (dev₀ ν₀ n R C M₀) := by
  have hS : (UL.ScoreProfileClass X K L R C M₀).Nonempty :=
    ⟨_, zero_mem_scoreProfileClass hK hL hR hC hM₀⟩
  refine measurable_sSup_of_continuous hS ?_ (fun f hf z => dev₀_term_le hn ν₀ hf z)
  intro f hf
  refine continuous_abs.comp (continuous_const.sub (continuous_const.mul ?_))
  refine continuous_finset_sum _ fun i _ => ?_
  exact (continuous_of_mem_scoreProfileClass hf).comp (continuous_apply i)

private theorem measurable_ghostSup
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    [MeasurableSpace X] [BorelSpace X]
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R C M₀ : ℝ} (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀) :
    Measurable (ghostSup (X := X) K n L R C M₀) := by
  have hS : (UL.ScoreProfileClass X K L R C M₀).Nonempty :=
    ⟨_, zero_mem_scoreProfileClass hK hL hR hC hM₀⟩
  refine measurable_sSup_of_continuous hS ?_ (fun f hf zz' => ghostSup_term_le hn hf zz')
  intro f hf
  have hf_cont := continuous_of_mem_scoreProfileClass hf
  refine continuous_abs.comp (continuous_const.mul ?_)
  refine continuous_finset_sum _ fun i _ => ?_
  exact (hf_cont.comp ((continuous_apply i).comp continuous_snd)).sub
    (hf_cont.comp ((continuous_apply i).comp continuous_fst))

private theorem measurable_radSupSample
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    [MeasurableSpace X] [BorelSpace X]
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R C M₀ : ℝ} (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀)
    (σ : Fin n → Bool) :
    Measurable (radSupSample (X := X) K n L R C M₀ σ) := by
  have hS : (UL.ScoreProfileClass X K L R C M₀).Nonempty :=
    ⟨_, zero_mem_scoreProfileClass hK hL hR hC hM₀⟩
  refine measurable_sSup_of_continuous hS ?_ (fun f hf z => radSupSample_term_le hn σ hf z)
  intro f hf
  have hf_cont := continuous_of_mem_scoreProfileClass hf
  refine continuous_abs.comp (continuous_const.mul ?_)
  refine continuous_finset_sum _ fun i _ => ?_
  exact continuous_const.mul (hf_cont.comp (continuous_apply i))

private theorem dev₀_nonneg
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    [MeasurableSpace X] [BorelSpace X]
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R C M₀ : ℝ} (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀)
    (ν₀ : MeasureTheory.Measure (Metric.closedBall (0 : X) L × Fin K))
    [MeasureTheory.IsProbabilityMeasure ν₀]
    (z : Fin n → Metric.closedBall (0 : X) L × Fin K) :
    0 ≤ dev₀ ν₀ n R C M₀ z := by
  have hbdd : BddAbove ((fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
      |(∫ q, f q ∂ν₀) - ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, f (z i)|) ''
      UL.ScoreProfileClass X K L R C M₀) :=
    ⟨2 * M₀, by rintro _ ⟨f, hf, rfl⟩; exact dev₀_term_le hn ν₀ hf z⟩
  have hmem : (0 : ℝ) ∈ (fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
      |(∫ q, f q ∂ν₀) - ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, f (z i)|) ''
      UL.ScoreProfileClass X K L R C M₀ :=
    ⟨_, zero_mem_scoreProfileClass hK hL hR hC hM₀, by simp⟩
  exact le_csSup hbdd hmem

private theorem dev₀_le
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    [MeasurableSpace X] [BorelSpace X]
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R C M₀ : ℝ} (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀)
    (ν₀ : MeasureTheory.Measure (Metric.closedBall (0 : X) L × Fin K))
    [MeasureTheory.IsProbabilityMeasure ν₀]
    (z : Fin n → Metric.closedBall (0 : X) L × Fin K) :
    dev₀ ν₀ n R C M₀ z ≤ 2 * M₀ := by
  have hne : ((fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
      |(∫ q, f q ∂ν₀) - ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, f (z i)|) ''
      UL.ScoreProfileClass X K L R C M₀).Nonempty :=
    ⟨_, ⟨_, zero_mem_scoreProfileClass hK hL hR hC hM₀, rfl⟩⟩
  refine csSup_le hne ?_
  rintro _ ⟨f, hf, rfl⟩
  exact dev₀_term_le hn ν₀ hf z

private theorem ghostSup_nonneg
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R C M₀ : ℝ} (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀)
    (zz' : (Fin n → Metric.closedBall (0 : X) L × Fin K) ×
      (Fin n → Metric.closedBall (0 : X) L × Fin K)) :
    0 ≤ ghostSup K n L R C M₀ zz' := by
  have hbdd : BddAbove ((fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
      |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f (zz'.2 i) - f (zz'.1 i))|) ''
      UL.ScoreProfileClass X K L R C M₀) :=
    ⟨2 * M₀, by rintro _ ⟨f, hf, rfl⟩; exact ghostSup_term_le hn hf zz'⟩
  have hmem : (0 : ℝ) ∈ (fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
      |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f (zz'.2 i) - f (zz'.1 i))|) ''
      UL.ScoreProfileClass X K L R C M₀ :=
    ⟨_, zero_mem_scoreProfileClass hK hL hR hC hM₀, by simp⟩
  exact le_csSup hbdd hmem

private theorem ghostSup_le
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R C M₀ : ℝ} (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀)
    (zz' : (Fin n → Metric.closedBall (0 : X) L × Fin K) ×
      (Fin n → Metric.closedBall (0 : X) L × Fin K)) :
    ghostSup K n L R C M₀ zz' ≤ 2 * M₀ := by
  have hne : ((fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
      |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f (zz'.2 i) - f (zz'.1 i))|) ''
      UL.ScoreProfileClass X K L R C M₀).Nonempty :=
    ⟨_, ⟨_, zero_mem_scoreProfileClass hK hL hR hC hM₀, rfl⟩⟩
  refine csSup_le hne ?_
  rintro _ ⟨f, hf, rfl⟩
  exact ghostSup_term_le hn hf zz'

private theorem radSupSample_nonneg
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R C M₀ : ℝ} (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀)
    (σ : Fin n → Bool) (z : Fin n → Metric.closedBall (0 : X) L × Fin K) :
    0 ≤ radSupSample K n L R C M₀ σ z := by
  have hbdd : BddAbove ((fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
      |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * f (z i)|) ''
      UL.ScoreProfileClass X K L R C M₀) :=
    ⟨M₀, by rintro _ ⟨f, hf, rfl⟩; exact radSupSample_term_le hn σ hf z⟩
  have hmem : (0 : ℝ) ∈ (fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
      |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * f (z i)|) ''
      UL.ScoreProfileClass X K L R C M₀ :=
    ⟨_, zero_mem_scoreProfileClass hK hL hR hC hM₀, by simp⟩
  exact le_csSup hbdd hmem

private theorem radSupSample_le
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R C M₀ : ℝ} (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀)
    (σ : Fin n → Bool) (z : Fin n → Metric.closedBall (0 : X) L × Fin K) :
    radSupSample K n L R C M₀ σ z ≤ M₀ := by
  have hne : ((fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
      |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * f (z i)|) ''
      UL.ScoreProfileClass X K L R C M₀).Nonempty :=
    ⟨_, ⟨_, zero_mem_scoreProfileClass hK hL hR hC hM₀, rfl⟩⟩
  refine csSup_le hne ?_
  rintro _ ⟨f, hf, rfl⟩
  exact radSupSample_term_le hn σ hf z

private theorem dev₀_sub_le_of_eq_off
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    [MeasurableSpace X] [BorelSpace X]
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R C M₀ : ℝ} (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀)
    (ν₀ : MeasureTheory.Measure (Metric.closedBall (0 : X) L × Fin K))
    [MeasureTheory.IsProbabilityMeasure ν₀]
    (i : Fin n) {z₁ z₂ : Fin n → Metric.closedBall (0 : X) L × Fin K}
    (hz : ∀ j : Fin n, j ≠ i → z₁ j = z₂ j) :
    dev₀ ν₀ n R C M₀ z₁ - dev₀ ν₀ n R C M₀ z₂ ≤ 2 * M₀ / (n : ℝ) := by
  rw [sub_le_iff_le_add]
  have hne : ((fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
      |(∫ q, f q ∂ν₀) - ((1 : ℝ) / (n : ℝ)) * ∑ j : Fin n, f (z₁ j)|) ''
      UL.ScoreProfileClass X K L R C M₀).Nonempty :=
    ⟨_, ⟨_, zero_mem_scoreProfileClass hK hL hR hC hM₀, rfl⟩⟩
  have hbdd₂ : BddAbove ((fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
      |(∫ q, f q ∂ν₀) - ((1 : ℝ) / (n : ℝ)) * ∑ j : Fin n, f (z₂ j)|) ''
      UL.ScoreProfileClass X K L R C M₀) :=
    ⟨2 * M₀, by rintro _ ⟨f, hf, rfl⟩; exact dev₀_term_le hn ν₀ hf z₂⟩
  refine csSup_le hne ?_
  rintro _ ⟨f, hf, rfl⟩
  have h_le_sup :
      |(∫ q, f q ∂ν₀) - ((1 : ℝ) / (n : ℝ)) * ∑ j : Fin n, f (z₂ j)| ≤
        dev₀ ν₀ n R C M₀ z₂ :=
    le_csSup hbdd₂ ⟨f, hf, rfl⟩
  have h_sum_diff :
      (∑ j : Fin n, f (z₂ j)) - (∑ j : Fin n, f (z₁ j)) =
        f (z₂ i) - f (z₁ i) := by
    rw [← Finset.sum_sub_distrib]
    refine Finset.sum_eq_single i (fun j _ hji => ?_) (fun hi => absurd (Finset.mem_univ i) hi)
    rw [hz j hji, sub_self]
  have hn_nonneg : (0 : ℝ) ≤ 1 / (n : ℝ) := by positivity
  have h_emp_diff :
      |((1 : ℝ) / (n : ℝ)) * ∑ j : Fin n, f (z₂ j) -
        ((1 : ℝ) / (n : ℝ)) * ∑ j : Fin n, f (z₁ j)| ≤ 2 * M₀ / (n : ℝ) := by
    rw [← mul_sub, h_sum_diff, abs_mul, abs_of_nonneg hn_nonneg]
    calc
      (1 : ℝ) / (n : ℝ) * |f (z₂ i) - f (z₁ i)|
          ≤ (1 : ℝ) / (n : ℝ) * (|f (z₂ i)| + |f (z₁ i)|) := by
            gcongr
            exact abs_sub_le_add_abs _ _
      _ ≤ (1 : ℝ) / (n : ℝ) * (M₀ + M₀) := by
            gcongr
            · exact abs_le_of_mem_scoreProfileClass hf (z₂ i)
            · exact abs_le_of_mem_scoreProfileClass hf (z₁ i)
      _ = 2 * M₀ / (n : ℝ) := by ring
  have h_split :
      (∫ q, f q ∂ν₀) - ((1 : ℝ) / (n : ℝ)) * ∑ j : Fin n, f (z₁ j) =
        ((∫ q, f q ∂ν₀) - ((1 : ℝ) / (n : ℝ)) * ∑ j : Fin n, f (z₂ j)) +
        (((1 : ℝ) / (n : ℝ)) * ∑ j : Fin n, f (z₂ j) -
          ((1 : ℝ) / (n : ℝ)) * ∑ j : Fin n, f (z₁ j)) := by ring
  calc
    |(∫ q, f q ∂ν₀) - ((1 : ℝ) / (n : ℝ)) * ∑ j : Fin n, f (z₁ j)|
        = |((∫ q, f q ∂ν₀) - ((1 : ℝ) / (n : ℝ)) * ∑ j : Fin n, f (z₂ j)) +
            (((1 : ℝ) / (n : ℝ)) * ∑ j : Fin n, f (z₂ j) -
              ((1 : ℝ) / (n : ℝ)) * ∑ j : Fin n, f (z₁ j))| := by rw [h_split]
    _ ≤ |(∫ q, f q ∂ν₀) - ((1 : ℝ) / (n : ℝ)) * ∑ j : Fin n, f (z₂ j)| +
          |((1 : ℝ) / (n : ℝ)) * ∑ j : Fin n, f (z₂ j) -
            ((1 : ℝ) / (n : ℝ)) * ∑ j : Fin n, f (z₁ j)| := abs_add_le_add_abs _ _
    _ ≤ dev₀ ν₀ n R C M₀ z₂ + 2 * M₀ / (n : ℝ) := add_le_add h_le_sup h_emp_diff
    _ = 2 * M₀ / (n : ℝ) + dev₀ ν₀ n R C M₀ z₂ := add_comm _ _

private theorem dev₀_bdd_diff
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    [MeasurableSpace X] [BorelSpace X]
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R C M₀ : ℝ} (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀)
    (ν₀ : MeasureTheory.Measure (Metric.closedBall (0 : X) L × Fin K))
    [MeasureTheory.IsProbabilityMeasure ν₀]
    (i : Fin n) (z : Fin n → Metric.closedBall (0 : X) L × Fin K)
    (z' : Metric.closedBall (0 : X) L × Fin K) :
    |dev₀ ν₀ n R C M₀ z - dev₀ ν₀ n R C M₀ (Function.update z i z')| ≤ 2 * M₀ / (n : ℝ) := by
  refine abs_sub_le_iff.mpr ⟨?_, ?_⟩
  · exact dev₀_sub_le_of_eq_off hK hn hL hR hC hM₀ ν₀ i fun j hj => by simp [Function.update, hj]
  · exact dev₀_sub_le_of_eq_off hK hn hL hR hC hM₀ ν₀ i fun j hj => by simp [Function.update, hj]

/-! ### Symmetrization on `Measure.pi (fun _ : Fin n => ν₀)` -/

private theorem dev₀_le_integral_ghostSup
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    [MeasurableSpace X] [BorelSpace X]
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R C M₀ : ℝ} (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀)
    (ν₀ : MeasureTheory.Measure (Metric.closedBall (0 : X) L × Fin K))
    [MeasureTheory.IsProbabilityMeasure ν₀]
    (z : Fin n → Metric.closedBall (0 : X) L × Fin K) :
    dev₀ ν₀ n R C M₀ z ≤
      ∫ z', ghostSup K n L R C M₀ (z, z') ∂MeasureTheory.Measure.pi (fun _ : Fin n => ν₀) := by
  let β := Metric.closedBall (0 : X) L × Fin K
  let π := MeasureTheory.Measure.pi (fun _ : Fin n => ν₀)
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  have hn_ne : (n : ℝ) ≠ 0 := hn_pos.ne'
  have hne : ((fun f : β → ℝ =>
      |(∫ q, f q ∂ν₀) - ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, f (z i)|) ''
      UL.ScoreProfileClass X K L R C M₀).Nonempty :=
    ⟨_, ⟨_, zero_mem_scoreProfileClass hK hL hR hC hM₀, rfl⟩⟩
  refine csSup_le hne ?_
  rintro _ ⟨f, hf, rfl⟩
  have hf_meas : Measurable f := (continuous_of_mem_scoreProfileClass hf).measurable
  have h_coord_int : ∀ i : Fin n, MeasureTheory.Integrable (fun z' : Fin n → β => f (z' i)) π := by
    intro i
    refine (MeasureTheory.integrable_const M₀).mono'
      (hf_meas.comp (measurable_pi_apply i)).aestronglyMeasurable ?_
    exact Filter.Eventually.of_forall fun z' => by
      rw [Real.norm_eq_abs]
      exact abs_le_of_mem_scoreProfileClass hf (z' i)
  have h_emp_int : MeasureTheory.Integrable
      (fun z' : Fin n → β => ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, f (z' i)) π :=
    (MeasureTheory.integrable_finset_sum _ fun i _ => h_coord_int i).const_mul _
  have h_ghost_exp :
      (∫ q, f q ∂ν₀) = ∫ z', (((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, f (z' i)) ∂π := by
    rw [MeasureTheory.integral_const_mul,
      MeasureTheory.integral_finset_sum _ fun i _ => h_coord_int i]
    have h_each : ∀ i : Fin n, (∫ z' : Fin n → β, f (z' i) ∂π) = ∫ q, f q ∂ν₀ := by
      intro i
      have h_mp_eval : MeasureTheory.MeasurePreserving (Function.eval i) π ν₀ :=
        MeasureTheory.measurePreserving_eval _ i
      exact mp_integral_comp h_mp_eval hf_meas
    simp only [h_each, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, one_div,
      inv_mul_cancel_left₀ hn_ne]
  have h_diff_eq :
      (∫ q, f q ∂ν₀) - ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, f (z i) =
        ∫ z', (((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f (z' i) - f (z i))) ∂π := by
    have h_const_int :
        ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, f (z i) =
          ∫ _z' : Fin n → β, (((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, f (z i)) ∂π := by
      rw [MeasureTheory.integral_const]
      dsimp [π]
      simp
    rw [h_ghost_exp, h_const_int, ← MeasureTheory.integral_sub h_emp_int
      (MeasureTheory.integrable_const _)]
    refine MeasureTheory.integral_congr_ae (Filter.Eventually.of_forall fun z' => ?_)
    dsimp only
    rw [← mul_sub, ← Finset.sum_sub_distrib]
  have h_diff_int : MeasureTheory.Integrable
      (fun z' : Fin n → β => ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f (z' i) - f (z i))) π := by
    have h_eq_fn :
        (fun z' : Fin n → β => ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f (z' i) - f (z i))) =
        fun z' => (((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, f (z' i)) -
          (((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, f (z i)) := by
      ext z'
      rw [← mul_sub, ← Finset.sum_sub_distrib]
    rw [h_eq_fn]
    exact h_emp_int.sub (MeasureTheory.integrable_const _)
  have h_ghost_slice_int :
      MeasureTheory.Integrable (fun z' => ghostSup K n L R C M₀ (z, z')) π :=
    bounded_measurable_integrable π
      ((measurable_ghostSup hK hn hL hR hC hM₀).comp (measurable_const.prodMk measurable_id))
      (fun z' => ghostSup_nonneg hK hn hL hR hC hM₀ (z, z'))
      (fun z' => ghostSup_le hK hn hL hR hC hM₀ (z, z'))
  calc
    |(∫ q, f q ∂ν₀) - ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, f (z i)|
        = ‖∫ z', (((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f (z' i) - f (z i))) ∂π‖ := by
          rw [h_diff_eq, Real.norm_eq_abs]
    _ ≤ ∫ z', ‖((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f (z' i) - f (z i))‖ ∂π :=
          MeasureTheory.norm_integral_le_integral_norm _
    _ ≤ ∫ z', ghostSup K n L R C M₀ (z, z') ∂π := by
          refine MeasureTheory.integral_mono h_diff_int.norm h_ghost_slice_int fun z' => ?_
          rw [Real.norm_eq_abs]
          have hbdd_z' : BddAbove ((fun f' : β → ℝ =>
              |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, (f' (z' i) - f' (z i))|) ''
              UL.ScoreProfileClass X K L R C M₀) :=
            ⟨2 * M₀, by rintro _ ⟨f', hf', rfl⟩; exact ghostSup_term_le hn hf' (z, z')⟩
          exact le_csSup hbdd_z' ⟨f, hf, rfl⟩

private theorem ghostSup_swap_le_radSupSample
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R C M₀ : ℝ} (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀)
    (σ : Fin n → Bool)
    (w : Fin n → (Metric.closedBall (0 : X) L × Fin K) × (Metric.closedBall (0 : X) L × Fin K)) :
    ghostSup K n L R C M₀
      ((fun i => (if σ i then w i else (w i).swap).1),
       (fun i => (if σ i then w i else (w i).swap).2)) ≤
      radSupSample K n L R C M₀ σ (fun i => (w i).2) +
        radSupSample K n L R C M₀ σ (fun i => (w i).1) := by
  let β := Metric.closedBall (0 : X) L × Fin K
  have hne : ((fun f : β → ℝ =>
      |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
        (f ((if σ i then w i else (w i).swap).2) -
         f ((if σ i then w i else (w i).swap).1))|) ''
      UL.ScoreProfileClass X K L R C M₀).Nonempty :=
    ⟨_, ⟨_, zero_mem_scoreProfileClass hK hL hR hC hM₀, rfl⟩⟩
  have hbdd₂ : BddAbove ((fun f : β → ℝ =>
      |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * f ((w i).2)|) ''
      UL.ScoreProfileClass X K L R C M₀) :=
    ⟨M₀, by rintro _ ⟨f, hf, rfl⟩; exact radSupSample_term_le hn σ hf (fun i => (w i).2)⟩
  have hbdd₁ : BddAbove ((fun f : β → ℝ =>
      |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * f ((w i).1)|) ''
      UL.ScoreProfileClass X K L R C M₀) :=
    ⟨M₀, by rintro _ ⟨f, hf, rfl⟩; exact radSupSample_term_le hn σ hf (fun i => (w i).1)⟩
  refine csSup_le hne ?_
  rintro _ ⟨f, hf, rfl⟩
  have h_term : ∀ i : Fin n,
      f ((if σ i then w i else (w i).swap).2) - f ((if σ i then w i else (w i).swap).1) =
        radSign (σ i) * f ((w i).2) - radSign (σ i) * f ((w i).1) := by
    intro i
    generalize w i = p
    rcases p with ⟨q₁, q₂⟩
    generalize σ i = bσ
    cases bσ <;> simp only [Bool.false_eq_true, ↓reduceIte, radSign, Prod.swap] <;> ring
  have h_sum_eq :
      ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
        (f ((if σ i then w i else (w i).swap).2) -
         f ((if σ i then w i else (w i).swap).1)) =
      (((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * f ((w i).2)) -
      (((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * f ((w i).1)) := by
    have h1 :
        (∑ i : Fin n,
          (f ((if σ i then w i else (w i).swap).2) -
           f ((if σ i then w i else (w i).swap).1))) =
        (∑ i : Fin n, radSign (σ i) * f ((w i).2)) -
        (∑ i : Fin n, radSign (σ i) * f ((w i).1)) := by
      rw [← Finset.sum_sub_distrib]
      exact Finset.sum_congr rfl fun i _ => h_term i
    rw [h1, mul_sub]
  dsimp only
  rw [h_sum_eq]
  calc
    |(((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * f ((w i).2)) -
      (((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * f ((w i).1))|
        ≤ |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * f ((w i).2)| +
          |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, radSign (σ i) * f ((w i).1)| :=
          abs_sub_le_add_abs _ _
    _ ≤ radSupSample K n L R C M₀ σ (fun i => (w i).2) +
          radSupSample K n L R C M₀ σ (fun i => (w i).1) :=
          add_le_add (le_csSup hbdd₂ ⟨f, hf, rfl⟩) (le_csSup hbdd₁ ⟨f, hf, rfl⟩)

private theorem sfinite_of_prob {α : Type*} [MeasurableSpace α]
    (μ : MeasureTheory.Measure α) [MeasureTheory.IsProbabilityMeasure μ] :
    MeasureTheory.SFinite μ :=
  inferInstance

private theorem integral_dev₀_le
    {X : Type*} [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    [MeasurableSpace X] [BorelSpace X]
    {K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R C M₀ : ℝ} (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀)
    (ν₀ : MeasureTheory.Measure (Metric.closedBall (0 : X) L × Fin K))
    [MeasureTheory.IsProbabilityMeasure ν₀] :
    let m : ℕ := K - 1
    let D₀ : ℝ := M₀ + C * (L * R)
    let rBound : ℝ :=
      if m ≤ 2 then
        chainConst K * D₀ * Real.log (2 * (n : ℝ)) / Real.sqrt (n : ℝ)
      else
        chainConst K * D₀ * ((n : ℝ) ^ (-(1 : ℝ) / (m : ℝ)))
    (∫ z, dev₀ ν₀ n R C M₀ z ∂MeasureTheory.Measure.pi (fun _ : Fin n => ν₀)) ≤
      2 * rBound := by
  intro m D₀ rBound
  let β := Metric.closedBall (0 : X) L × Fin K
  let π := MeasureTheory.Measure.pi (fun _ : Fin n => ν₀)
  let ρ := MeasureTheory.Measure.pi (fun _ : Fin n => ν₀.prod ν₀)
  haveI : MeasureTheory.IsProbabilityMeasure π :=
    inferInstanceAs (MeasureTheory.IsProbabilityMeasure (MeasureTheory.Measure.pi (fun _ : Fin n => ν₀)))
  haveI : MeasureTheory.SFinite π :=
    sfinite_of_prob (MeasureTheory.Measure.pi (fun _ : Fin n => ν₀))
  haveI : MeasureTheory.IsProbabilityMeasure ρ :=
    inferInstanceAs (MeasureTheory.IsProbabilityMeasure
      (MeasureTheory.Measure.pi (fun _ : Fin n => ν₀.prod ν₀)))
  let proj₁ : (Fin n → β × β) → (Fin n → β) := fun w i => (w i).1
  let proj₂ : (Fin n → β × β) → (Fin n → β) := fun w i => (w i).2
  have h_mp_pair :
      MeasureTheory.MeasurePreserving
        (MeasurableEquiv.arrowProdEquivProdArrow β β (Fin n))
        ρ (π.prod π) := by
    apply MeasureTheory.measurePreserving_arrowProdEquivProdArrow
  have h_mp_proj₁ : MeasureTheory.MeasurePreserving proj₁ ρ π :=
    MeasureTheory.measurePreserving_fst.comp h_mp_pair
  have h_mp_proj₂ : MeasureTheory.MeasurePreserving proj₂ ρ π :=
    MeasureTheory.measurePreserving_snd.comp h_mp_pair
  have h_dev_int : MeasureTheory.Integrable (dev₀ ν₀ n R C M₀) π :=
    bounded_measurable_integrable π (measurable_dev₀ hK hn hL hR hC hM₀ ν₀)
      (dev₀_nonneg hK hn hL hR hC hM₀ ν₀) (dev₀_le hK hn hL hR hC hM₀ ν₀)
  have h_ghost_int : MeasureTheory.Integrable (ghostSup (X := X) K n L R C M₀) (π.prod π) :=
    bounded_measurable_integrable (π.prod π) (measurable_ghostSup hK hn hL hR hC hM₀)
      (ghostSup_nonneg hK hn hL hR hC hM₀) (ghostSup_le hK hn hL hR hC hM₀)
  have h_step1 :
      (∫ z, dev₀ ν₀ n R C M₀ z ∂π) ≤
        ∫ w, ghostSup K n L R C M₀ (proj₁ w, proj₂ w) ∂ρ := by
    calc
      (∫ z, dev₀ ν₀ n R C M₀ z ∂π)
          ≤ ∫ z, (∫ z', ghostSup K n L R C M₀ (z, z') ∂π) ∂π :=
            MeasureTheory.integral_mono h_dev_int h_ghost_int.integral_prod_left
              (dev₀_le_integral_ghostSup hK hn hL hR hC hM₀ ν₀)
      _ = ∫ p, ghostSup K n L R C M₀ p ∂(π.prod π) :=
            (MeasureTheory.integral_prod _ h_ghost_int).symm
      _ = ∫ w, ghostSup K n L R C M₀ (proj₁ w, proj₂ w) ∂ρ :=
            (mp_integral_comp h_mp_pair (measurable_ghostSup hK hn hL hR hC hM₀)).symm
  have h_rad_int_π :
      ∀ σ : Fin n → Bool, MeasureTheory.Integrable (radSupSample (X := X) K n L R C M₀ σ) π :=
    fun σ => bounded_measurable_integrable π (measurable_radSupSample hK hn hL hR hC hM₀ σ)
      (radSupSample_nonneg hK hn hL hR hC hM₀ σ) (radSupSample_le hK hn hL hR hC hM₀ σ)
  have h_per_σ : ∀ σ : Fin n → Bool,
      (∫ w, ghostSup K n L R C M₀ (proj₁ w, proj₂ w) ∂ρ) ≤
        2 * ∫ u, radSupSample K n L R C M₀ σ u ∂π := by
    intro σ
    let f_coord : Fin n → β × β → β × β :=
      fun i => if σ i then id else Prod.swap
    have h_mp_swap :
        MeasureTheory.MeasurePreserving (fun w i => f_coord i (w i)) ρ ρ := by
      apply MeasureTheory.measurePreserving_pi
      intro i
      dsimp [f_coord]
      split_ifs
      · exact MeasureTheory.MeasurePreserving.id (ν₀.prod ν₀)
      · exact MeasureTheory.Measure.measurePreserving_swap
    have h_meas_ghost_ρ :
        Measurable (fun w : Fin n → β × β => ghostSup K n L R C M₀ (proj₁ w, proj₂ w)) :=
      (measurable_ghostSup hK hn hL hR hC hM₀).comp
        (h_mp_proj₁.measurable.prodMk h_mp_proj₂.measurable)
    have h_swap_int :
        MeasureTheory.Integrable
          (fun w => ghostSup K n L R C M₀
            (proj₁ (fun i => f_coord i (w i)), proj₂ (fun i => f_coord i (w i)))) ρ :=
      bounded_measurable_integrable ρ (h_meas_ghost_ρ.comp h_mp_swap.measurable)
        (fun _ => ghostSup_nonneg hK hn hL hR hC hM₀ _)
        (fun _ => ghostSup_le hK hn hL hR hC hM₀ _)
    have h_rad2_int :
        MeasureTheory.Integrable (fun w => radSupSample K n L R C M₀ σ (proj₂ w)) ρ :=
      bounded_measurable_integrable ρ
        ((measurable_radSupSample hK hn hL hR hC hM₀ σ).comp h_mp_proj₂.measurable)
        (fun w => radSupSample_nonneg hK hn hL hR hC hM₀ σ (proj₂ w))
        (fun w => radSupSample_le hK hn hL hR hC hM₀ σ (proj₂ w))
    have h_rad1_int :
        MeasureTheory.Integrable (fun w => radSupSample K n L R C M₀ σ (proj₁ w)) ρ :=
      bounded_measurable_integrable ρ
        ((measurable_radSupSample hK hn hL hR hC hM₀ σ).comp h_mp_proj₁.measurable)
        (fun w => radSupSample_nonneg hK hn hL hR hC hM₀ σ (proj₁ w))
        (fun w => radSupSample_le hK hn hL hR hC hM₀ σ (proj₁ w))
    calc
      (∫ w, ghostSup K n L R C M₀ (proj₁ w, proj₂ w) ∂ρ)
          = ∫ w, ghostSup K n L R C M₀
              (proj₁ (fun i => f_coord i (w i)), proj₂ (fun i => f_coord i (w i))) ∂ρ :=
            (mp_integral_comp h_mp_swap h_meas_ghost_ρ).symm
      _ ≤ ∫ w, (radSupSample K n L R C M₀ σ (proj₂ w) +
            radSupSample K n L R C M₀ σ (proj₁ w)) ∂ρ := by
            refine MeasureTheory.integral_mono h_swap_int (h_rad2_int.add h_rad1_int) fun w => ?_
            dsimp only
            have h_f : (fun i => f_coord i (w i)) = fun i => if σ i then w i else (w i).swap := by
              funext i; dsimp [f_coord]; split_ifs <;> rfl
            rw [h_f]
            exact ghostSup_swap_le_radSupSample hK hn hL hR hC hM₀ σ w
      _ = (∫ w, radSupSample K n L R C M₀ σ (proj₂ w) ∂ρ) +
            (∫ w, radSupSample K n L R C M₀ σ (proj₁ w) ∂ρ) :=
            MeasureTheory.integral_add h_rad2_int h_rad1_int
      _ = (∫ u, radSupSample K n L R C M₀ σ u ∂π) +
            (∫ u, radSupSample K n L R C M₀ σ u ∂π) := by
            rw [mp_integral_comp h_mp_proj₂ (measurable_radSupSample hK hn hL hR hC hM₀ σ),
              mp_integral_comp h_mp_proj₁ (measurable_radSupSample hK hn hL hR hC hM₀ σ)]
      _ = 2 * ∫ u, radSupSample K n L R C M₀ σ u ∂π := by ring
  have h_sum_σ :
      ((2 : ℝ) ^ n) * (∫ w, ghostSup K n L R C M₀ (proj₁ w, proj₂ w) ∂ρ) ≤
        2 * ∫ u, (∑ σ : Fin n → Bool, radSupSample K n L R C M₀ σ u) ∂π := by
    calc
      ((2 : ℝ) ^ n) * (∫ w, ghostSup K n L R C M₀ (proj₁ w, proj₂ w) ∂ρ)
          = ∑ _σ : Fin n → Bool, (∫ w, ghostSup K n L R C M₀ (proj₁ w, proj₂ w) ∂ρ) := by
            simp
      _ ≤ ∑ σ : Fin n → Bool, (2 * ∫ u, radSupSample K n L R C M₀ σ u ∂π) :=
            Finset.sum_le_sum fun σ _ => h_per_σ σ
      _ = 2 * ∑ σ : Fin n → Bool, ∫ u, radSupSample K n L R C M₀ σ u ∂π := by
            rw [← Finset.mul_sum]
      _ = 2 * ∫ u, (∑ σ : Fin n → Bool, radSupSample K n L R C M₀ σ u) ∂π := by
            rw [MeasureTheory.integral_finset_sum _ fun σ _ => h_rad_int_π σ]
  have h_avg_int :
      MeasureTheory.Integrable
        (fun u => ((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool, radSupSample K n L R C M₀ σ u) π :=
    (MeasureTheory.integrable_finset_sum _ fun σ _ => h_rad_int_π σ).const_mul _
  have h_step2 :
      (∫ w, ghostSup K n L R C M₀ (proj₁ w, proj₂ w) ∂ρ) ≤ 2 * rBound := by
    have h2n_pos : (0 : ℝ) < (2 : ℝ) ^ n := by positivity
    have h_div :
        (∫ w, ghostSup K n L R C M₀ (proj₁ w, proj₂ w) ∂ρ) ≤
          2 * ∫ u, (((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool, radSupSample K n L R C M₀ σ u) ∂π := by
      have h_mul := mul_le_mul_of_nonneg_left h_sum_σ (inv_nonneg.mpr h2n_pos.le)
      rw [inv_mul_cancel_left₀ h2n_pos.ne'] at h_mul
      calc
        (∫ w, ghostSup K n L R C M₀ (proj₁ w, proj₂ w) ∂ρ)
            ≤ ((2 : ℝ) ^ n)⁻¹ *
                (2 * ∫ u, (∑ σ : Fin n → Bool, radSupSample K n L R C M₀ σ u) ∂π) := h_mul
        _ = 2 * (((2 : ℝ) ^ n)⁻¹ *
                ∫ u, (∑ σ : Fin n → Bool, radSupSample K n L R C M₀ σ u) ∂π) := by ring
        _ = 2 * ∫ u, (((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool, radSupSample K n L R C M₀ σ u) ∂π := by
              rw [MeasureTheory.integral_const_mul]
    have h_emp_bound :
        (∫ u, (((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool, radSupSample K n L R C M₀ σ u) ∂π) ≤
          rBound := by
      calc
        (∫ u, (((2 : ℝ) ^ n)⁻¹ * ∑ σ : Fin n → Bool, radSupSample K n L R C M₀ σ u) ∂π)
            ≤ ∫ _u : Fin n → β, rBound ∂π := by
              refine MeasureTheory.integral_mono h_avg_int
                (MeasureTheory.integrable_const _) fun u => ?_
              exact avg_radSupSample_le hK hn hL hR hC hM₀ u
        _ = rBound := by
              rw [MeasureTheory.integral_const]
              dsimp [π]
              simp
    linarith
  exact h_step1.trans h_step2

/-! ### Universe-polymorphic McDiarmid bridge via `Type 0` equivalence (Kuratowski) -/

private theorem mcdiarmid_pi_of_equiv_type0.{u₁, u₂, uβ}
    (h_mc : UL.S_cit_mcdiarmid1989.{u₁, u₂})
    {β : Type uβ} [mβ : MeasurableSpace β]
    {β₀ : Type} (e₀ : β ≃ β₀)
    (n : ℕ) (_hn : 1 ≤ n)
    (ν₀ : MeasureTheory.Measure β) [MeasureTheory.IsProbabilityMeasure ν₀]
    (g : (Fin n → β) → ℝ)
    (hg_meas : Measurable g)
    (d : ℝ) (hd : 0 ≤ d)
    (hg_diff : ∀ (i : Fin n) (z : Fin n → β) (z' : β),
      |g z - g (Function.update z i z')| ≤ d)
    (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1) :
    let π := MeasureTheory.Measure.pi (fun _ : Fin n => ν₀)
    (π {z | |g z - (∫ z', g z' ∂π)| ≤
      Real.sqrt ((1 / 2 : ℝ) * ((n : ℝ) * d ^ 2) * Real.log (2 / δ))}).toReal ≥ 1 - δ := by
  dsimp only
  unfold UL.S_cit_mcdiarmid1989 at h_mc
  letI mβ₀ : MeasurableSpace β₀ := MeasurableSpace.map e₀ mβ
  let e₀m : β ≃ᵐ β₀ :=
    { toEquiv := e₀
      measurable_toFun := fun _ hs => hs
      measurable_invFun := fun s hs => by
        change MeasurableSet (e₀ ⁻¹' (e₀.symm ⁻¹' s))
        convert hs using 1
        ext x
        simp }
  let e_pi : (Fin n → β₀) ≃ᵐ (Fin n → β) :=
    { toEquiv :=
        { toFun := fun z i => e₀.symm (z i)
          invFun := fun z i => e₀ (z i)
          left_inv := fun z => by funext i; exact e₀.apply_symm_apply (z i)
          right_inv := fun z => by funext i; exact e₀.symm_apply_apply (z i) }
      measurable_toFun :=
        measurable_pi_lambda _ fun i => e₀m.symm.measurable.comp (measurable_pi_apply i)
      measurable_invFun :=
        measurable_pi_lambda _ fun i => e₀m.measurable.comp (measurable_pi_apply i) }
  let π : MeasureTheory.Measure (Fin n → β) := MeasureTheory.Measure.pi (fun _ : Fin n => ν₀)
  let Ω_mc : Type u₁ := ULift.{u₁} (Fin n → β₀)
  let eΩ : Ω_mc ≃ᵐ (Fin n → β) := MeasurableEquiv.ulift.trans e_pi
  let μ_mc : MeasureTheory.Measure Ω_mc := MeasureTheory.Measure.map eΩ.symm π
  haveI : MeasureTheory.IsProbabilityMeasure μ_mc :=
    MeasureTheory.Measure.isProbabilityMeasure_map eΩ.symm.measurable.aemeasurable
  let α_mc : Fin n → Type u₂ := fun _ => ULift.{u₂} β₀
  let eβ : ULift.{u₂} β₀ ≃ᵐ β := MeasurableEquiv.ulift.trans e₀m.symm
  let Z_mc : ∀ i : Fin n, Ω_mc → α_mc i := fun i ω => eβ.symm (eΩ ω i)
  have hZ_meas : ∀ i : Fin n, Measurable (Z_mc i) :=
    fun i => eβ.symm.measurable.comp ((measurable_pi_apply i).comp eΩ.measurable)
  have hZ_indep : ProbabilityTheory.iIndepFun Z_mc μ_mc := by
    rw [ProbabilityTheory.iIndepFun_iff_map_fun_eq_pi_map (fun i => (hZ_meas i).aemeasurable)]
    have h_lhs : MeasureTheory.Measure.map (fun ω i => Z_mc i ω) μ_mc =
        MeasureTheory.Measure.pi (fun _ : Fin n => MeasureTheory.Measure.map eβ.symm ν₀) := by
      have h_meas_vec : Measurable (fun ω : Ω_mc => fun i : Fin n => Z_mc i ω) :=
        measurable_pi_lambda _ hZ_meas
      rw [MeasureTheory.Measure.map_map h_meas_vec eΩ.symm.measurable]
      have h_comp : ((fun ω : Ω_mc => fun i : Fin n => Z_mc i ω) ∘ eΩ.symm) =
          (fun z : Fin n → β => fun i : Fin n => eβ.symm (z i)) := by
        funext z i
        simp [Z_mc]
      rw [h_comp, ← MeasureTheory.Measure.pi_map_pi (fun _ => eβ.symm.measurable.aemeasurable)]
    have h_rhs : ∀ i : Fin n,
        MeasureTheory.Measure.map (Z_mc i) μ_mc = MeasureTheory.Measure.map eβ.symm ν₀ := by
      intro i
      rw [MeasureTheory.Measure.map_map (hZ_meas i) eΩ.symm.measurable]
      have h_comp_i : Z_mc i ∘ eΩ.symm = eβ.symm ∘ Function.eval i := by
        funext z
        simp [Z_mc]
      rw [h_comp_i, ← MeasureTheory.Measure.map_map eβ.symm.measurable (measurable_pi_apply i),
        (MeasureTheory.measurePreserving_eval (fun _ : Fin n => ν₀) i).map_eq]
    rw [h_lhs]
    simp_rw [h_rhs]
  let g_mc : (∀ i : Fin n, α_mc i) → ℝ := fun w => g (fun i => eβ (w i))
  have hg_mc_meas : Measurable g_mc :=
    hg_meas.comp (measurable_pi_lambda _ fun i => eβ.measurable.comp (measurable_pi_apply i))
  let c : Fin n → ℝ := fun _ => d
  have hc_nonneg : ∀ i : Fin n, 0 ≤ c i := fun _ => hd
  have hg_mc_diff : ∀ (i : Fin n) (w : ∀ j : Fin n, α_mc j) (w' : α_mc i),
      |g_mc w - g_mc (Function.update w i w')| ≤ c i := by
    intro i w w'
    have h_upd : (fun j : Fin n => eβ (Function.update w i w' j)) =
        Function.update (fun j : Fin n => eβ (w j)) i (eβ w') := by
      funext j
      by_cases hj : j = i
      · subst hj; simp
      · simp [hj]
    change |g (fun j => eβ (w j)) - g (fun j => eβ (Function.update w i w' j))| ≤ d
    rw [h_upd]
    exact hg_diff i (fun j => eβ (w j)) (eβ w')
  have h_res := (h_mc Ω_mc μ_mc n α_mc Z_mc hZ_meas hZ_indep g_mc c
    hg_mc_meas hg_mc_diff hc_nonneg).2 δ hδ0 hδ1 |>.1
  have h_eval : ∀ ω : Ω_mc, g_mc (fun i => Z_mc i ω) = g (eΩ ω) := by
    intro ω
    change g (fun i => eβ (eβ.symm (eΩ ω i))) = g (eΩ ω)
    simp
  have h_int : (∫ ω', g_mc (fun i => Z_mc i ω') ∂μ_mc) = ∫ z', g z' ∂π := by
    simp_rw [h_eval]
    have h1 := MeasureTheory.integral_map (μ := π) eΩ.symm.measurable.aemeasurable
      (f := fun ω' : Ω_mc => g (eΩ ω')) (hg_meas.comp eΩ.measurable).aestronglyMeasurable
    simpa [μ_mc] using h1
  have h_sum_c : (∑ i : Fin n, c i ^ 2) = (n : ℝ) * d ^ 2 := by
    simp [c]
  let rad := Real.sqrt ((1 / 2 : ℝ) * ((n : ℝ) * d ^ 2) * Real.log (2 / δ))
  have hS_meas : MeasurableSet {z : Fin n → β | |g z - (∫ z', g z' ∂π)| ≤ rad} :=
    measurableSet_le (continuous_abs.measurable.comp (hg_meas.sub measurable_const)) measurable_const
  have h_mu_eq :
      μ_mc {ω | |g_mc (fun i => Z_mc i ω) - (∫ ω', g_mc (fun i => Z_mc i ω') ∂μ_mc)| ≤ rad} =
        π {z | |g z - (∫ z', g z' ∂π)| ≤ rad} := by
    rw [h_int]
    simp_rw [h_eval]
    change MeasureTheory.Measure.map eΩ.symm π (eΩ ⁻¹' {z | |g z - (∫ z', g z' ∂π)| ≤ rad}) = _
    rw [MeasureTheory.Measure.map_apply eΩ.symm.measurable (eΩ.measurable hS_meas)]
    congr 1
    ext z
    simp
  simp_rw [h_sum_c] at h_res
  rwa [← h_mu_eq]

private noncomputable def kuratowskiPairInj
    {X : Type*} [NormedAddCommGroup X] [TopologicalSpace.SeparableSpace X]
    {K : ℕ} {L : ℝ} (p : Metric.closedBall (0 : X) L × Fin K) :
    lp (fun _ : ℕ => ℝ) ⊤ × Fin K :=
  (kuratowskiEmbedding X (p.1 : X), p.2)

private theorem kuratowskiPairInj_injective
    {X : Type*} [NormedAddCommGroup X] [TopologicalSpace.SeparableSpace X]
    {K : ℕ} {L : ℝ} :
    Function.Injective (kuratowskiPairInj (X := X) (K := K) (L := L)) := by
  intro p q hpq
  have h1 : kuratowskiEmbedding X (p.1 : X) = kuratowskiEmbedding X (q.1 : X) :=
    congrArg Prod.fst hpq
  have h2 : (kuratowskiPairInj p).2 = (kuratowskiPairInj q).2 :=
    congrArg Prod.snd hpq
  have hx : (p.1 : X) = (q.1 : X) := (kuratowskiEmbedding.isometry X).injective h1
  exact Prod.ext (Subtype.ext hx) h2

/-! ### Clamping to `closedBall 0 L` and combining mean + McDiarmid deviation -/

open Classical in
private noncomputable def clampBallVec {X : Type*} [NormedAddCommGroup X] (L : ℝ) (x : X) : X :=
  if x ∈ Metric.closedBall (0 : X) L then x else 0

private theorem measurable_clampBallVec
    {X : Type*} [NormedAddCommGroup X] [MeasurableSpace X] [BorelSpace X] (L : ℝ) :
    Measurable (clampBallVec (X := X) L) :=
  Measurable.ite Metric.isClosed_closedBall.measurableSet measurable_id measurable_const

private noncomputable def clampBall
    {X : Type*} [NormedAddCommGroup X] (L : ℝ) (hL : 0 < L) (x : X) :
    Metric.closedBall (0 : X) L :=
  ⟨clampBallVec L x, by
    unfold clampBallVec
    split_ifs with hx
    · exact hx
    · exact Metric.mem_closedBall_self hL.le⟩

private theorem measurable_clampBall
    {X : Type*} [NormedAddCommGroup X] [MeasurableSpace X] [BorelSpace X]
    (L : ℝ) (hL : 0 < L) :
    Measurable (clampBall (X := X) L hL) :=
  (measurable_clampBallVec L).subtype_mk

private theorem clampBall_eq_of_mem
    {X : Type*} [NormedAddCommGroup X] {L : ℝ} (hL : 0 < L) {x : X}
    (hx : x ∈ Metric.closedBall (0 : X) L) :
    clampBall L hL x = ⟨x, hx⟩ := by
  apply Subtype.ext
  change clampBallVec L x = x
  unfold clampBallVec
  exact if_pos hx

private theorem bound_combine_K
    (K n : ℕ) (hn : 1 ≤ n)
    (L R C M₀ : ℝ) (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀)
    (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1)
    (v mean : ℝ)
    (hmean : mean ≤ 2 * (if K - 1 ≤ 2 then
        chainConst K * (M₀ + C * (L * R)) * Real.log (2 * (n : ℝ)) / Real.sqrt (n : ℝ)
      else
        chainConst K * (M₀ + C * (L * R)) * ((n : ℝ) ^ (-(1 : ℝ) / ((K - 1 : ℕ) : ℝ)))))
    (hv : |v - mean| ≤
      Real.sqrt ((1 / 2 : ℝ) * ((n : ℝ) * (2 * M₀ / (n : ℝ)) ^ 2) * Real.log (2 / δ))) :
    v ≤ (if K - 1 ≤ 2 then
        totalConst K * ((M₀ + C * (L * R)) * Real.log (2 * (n : ℝ)) +
          M₀ * Real.sqrt (Real.log (2 / δ))) / Real.sqrt (n : ℝ)
      else
        totalConst K * (M₀ + C * (L * R)) * ((n : ℝ) ^ (-(1 : ℝ) / ((K - 1 : ℕ) : ℝ))) +
          totalConst K * M₀ * Real.sqrt (Real.log (2 / δ) / (n : ℝ))) := by
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega)
  have h_two_div : 2 < 2 / δ := by
    rw [lt_div_iff₀ hδ0]
    linarith
  have h_log_pos : 0 < Real.log (2 / δ) :=
    lt_trans (Real.log_pos (by norm_num)) (Real.log_lt_log (by norm_num) h_two_div)
  have h_rad_le :
      Real.sqrt ((1 / 2 : ℝ) * ((n : ℝ) * (2 * M₀ / (n : ℝ)) ^ 2) * Real.log (2 / δ)) ≤
        2 * M₀ * Real.sqrt (Real.log (2 / δ) / (n : ℝ)) := by
    have h_inside :
        (1 / 2 : ℝ) * ((n : ℝ) * (2 * M₀ / (n : ℝ)) ^ 2) * Real.log (2 / δ) ≤
          (2 * M₀ * Real.sqrt (Real.log (2 / δ) / (n : ℝ))) ^ 2 := by
      have h_sq : (2 * M₀ * Real.sqrt (Real.log (2 / δ) / (n : ℝ))) ^ 2 =
          4 * M₀ ^ 2 * (Real.log (2 / δ) / (n : ℝ)) := by
        rw [mul_pow, mul_pow, Real.sq_sqrt (by positivity)]
        ring
      rw [h_sq]
      have h_eq : (1 / 2 : ℝ) * ((n : ℝ) * (2 * M₀ / (n : ℝ)) ^ 2) * Real.log (2 / δ) =
          2 * M₀ ^ 2 * (Real.log (2 / δ) / (n : ℝ)) := by
        field_simp
      rw [h_eq]
      nlinarith [sq_nonneg M₀, div_pos h_log_pos hn_pos]
    exact le_trans (Real.sqrt_le_sqrt h_inside) (Real.sqrt_sq (by positivity)).le
  have hv_le : v ≤ mean + 2 * M₀ * Real.sqrt (Real.log (2 / δ) / (n : ℝ)) := by
    have h1 : v - mean ≤ |v - mean| := le_abs_self (v - mean)
    linarith
  have hD₀_pos : 0 < M₀ + C * (L * R) := by positivity
  have hcc_pos : 0 < chainConst K := chainConst_pos K
  have htc_ge_2cc : 2 * chainConst K ≤ totalConst K := by
    unfold totalConst; linarith
  have htc_ge_2 : (2 : ℝ) ≤ totalConst K := by
    unfold totalConst; linarith
  by_cases hm : K - 1 ≤ 2
  · simp only [hm, ↓reduceIte] at hmean ⊢
    have h2n : (1 : ℝ) < 2 * (n : ℝ) := by
      have hn1 : (1 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
      linarith
    have hlog2n_pos : 0 < Real.log (2 * (n : ℝ)) := Real.log_pos h2n
    have hsqrt_div : Real.sqrt (Real.log (2 / δ) / (n : ℝ)) =
        Real.sqrt (Real.log (2 / δ)) / Real.sqrt (n : ℝ) :=
      Real.sqrt_div h_log_pos.le (n : ℝ)
    rw [hsqrt_div] at hv_le
    have h_num1 :
        2 * chainConst K * (M₀ + C * (L * R)) * Real.log (2 * (n : ℝ)) ≤
          totalConst K * (M₀ + C * (L * R)) * Real.log (2 * (n : ℝ)) :=
      mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_right htc_ge_2cc hD₀_pos.le) hlog2n_pos.le
    have h_num2 :
        2 * M₀ * Real.sqrt (Real.log (2 / δ)) ≤
          totalConst K * M₀ * Real.sqrt (Real.log (2 / δ)) :=
      mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_right htc_ge_2 hM₀.le) (Real.sqrt_nonneg _)
    have h_div_le :
        (2 * chainConst K * (M₀ + C * (L * R)) * Real.log (2 * (n : ℝ)) +
          2 * M₀ * Real.sqrt (Real.log (2 / δ))) / Real.sqrt (n : ℝ) ≤
        totalConst K * ((M₀ + C * (L * R)) * Real.log (2 * (n : ℝ)) +
          M₀ * Real.sqrt (Real.log (2 / δ))) / Real.sqrt (n : ℝ) := by
      refine div_le_div_of_nonneg_right ?_ (Real.sqrt_nonneg _)
      linarith
    have h_lhs_eq :
        2 * (chainConst K * (M₀ + C * (L * R)) * Real.log (2 * (n : ℝ)) / Real.sqrt (n : ℝ)) +
          2 * M₀ * (Real.sqrt (Real.log (2 / δ)) / Real.sqrt (n : ℝ)) =
        (2 * chainConst K * (M₀ + C * (L * R)) * Real.log (2 * (n : ℝ)) +
          2 * M₀ * Real.sqrt (Real.log (2 / δ))) / Real.sqrt (n : ℝ) := by
      ring
    linarith
  · simp only [hm, ↓reduceIte] at hmean ⊢
    have hrpow_nonneg : 0 ≤ (n : ℝ) ^ (-(1 : ℝ) / ((K - 1 : ℕ) : ℝ)) :=
      Real.rpow_nonneg (Nat.cast_nonneg n) _
    have h_t1 :
        2 * (chainConst K * (M₀ + C * (L * R)) * ((n : ℝ) ^ (-(1 : ℝ) / ((K - 1 : ℕ) : ℝ)))) ≤
          totalConst K * (M₀ + C * (L * R)) * ((n : ℝ) ^ (-(1 : ℝ) / ((K - 1 : ℕ) : ℝ))) := by
      calc
        2 * (chainConst K * (M₀ + C * (L * R)) * ((n : ℝ) ^ (-(1 : ℝ) / ((K - 1 : ℕ) : ℝ))))
            = (2 * chainConst K) * (M₀ + C * (L * R)) *
                ((n : ℝ) ^ (-(1 : ℝ) / ((K - 1 : ℕ) : ℝ))) := by ring
        _ ≤ totalConst K * (M₀ + C * (L * R)) *
              ((n : ℝ) ^ (-(1 : ℝ) / ((K - 1 : ℕ) : ℝ))) :=
            mul_le_mul_of_nonneg_right
              (mul_le_mul_of_nonneg_right htc_ge_2cc hD₀_pos.le) hrpow_nonneg
    have h_t2 :
        2 * M₀ * Real.sqrt (Real.log (2 / δ) / (n : ℝ)) ≤
          totalConst K * M₀ * Real.sqrt (Real.log (2 / δ) / (n : ℝ)) :=
      mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_right htc_ge_2 hM₀.le) (Real.sqrt_nonneg _)
    linarith

/-! ### Main high-probability dimension-free bound for fixed `K ≥ 2` -/

theorem main_bound_for_K.{u₁, u₂, uX, uΩ}
    (h_mc : UL.S_cit_mcdiarmid1989.{u₁, u₂})
    (K : ℕ) (hK : 2 ≤ K)
    (X : Type uX) [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    [MeasurableSpace X] [BorelSpace X]
    (L R C M₀ : ℝ)
    (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀)
    (n : ℕ) (hn : 1 ≤ n)
    (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1)
    (ν : MeasureTheory.Measure (X × Fin K)) [MeasureTheory.IsProbabilityMeasure ν]
    (hX_bound : ∀ᵐ xy ∂ν, ‖xy.1‖ ≤ L)
    (Ω : Type uΩ) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (X_samp : Fin n → Ω → X) (Y_samp : Fin n → Ω → Fin K)
    (hX_meas : ∀ i : Fin n, Measurable (X_samp i))
    (hY_meas : ∀ i : Fin n, Measurable (Y_samp i))
    (hindep : ProbabilityTheory.iIndepFun (fun i ω => (X_samp i ω, Y_samp i ω)) μ)
    (hident : ∀ i : Fin n, MeasureTheory.Measure.map (fun ω => (X_samp i ω, Y_samp i ω)) μ = ν) :
    let m : ℕ := K - 1
    let A₀ : ℝ := L * R
    let D₀ : ℝ := M₀ + C * A₀
    let evalProfile : (Metric.closedBall (0 : X) L × Fin K → ℝ) → X → Fin K → ℝ :=
      open Classical in
      fun f x y => if hx : x ∈ Metric.closedBall (0 : X) L then f (⟨x, hx⟩, y) else 0
    let bound : ℝ :=
      if m ≤ 2 then
        totalConst K * (D₀ * Real.log (2 * (n : ℝ)) + M₀ * Real.sqrt (Real.log (2 / δ))) /
          Real.sqrt (n : ℝ)
      else
        totalConst K * D₀ * ((n : ℝ) ^ (-(1 : ℝ) / (m : ℝ))) +
          totalConst K * M₀ * Real.sqrt (Real.log (2 / δ) / (n : ℝ))
    ∃ E : Set Ω, MeasurableSet E ∧ (μ E).toReal ≥ 1 - δ ∧
      ∀ ω ∈ E,
        sSup ((fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
          |(∫ xy, evalProfile f xy.1 xy.2 ∂ν) -
            ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalProfile f (X_samp i ω) (Y_samp i ω)|) ''
          UL.ScoreProfileClass X K L R C M₀) ≤ bound := by
  intro m A₀ D₀ evalProfile bound
  let β := Metric.closedBall (0 : X) L × Fin K
  let φ : X × Fin K → β := fun xy => (clampBall L hL xy.1, xy.2)
  have hφ_meas : Measurable φ :=
    ((measurable_clampBall L hL).comp measurable_fst).prodMk measurable_snd
  let ν₀ : MeasureTheory.Measure β := MeasureTheory.Measure.map φ ν
  haveI : MeasureTheory.IsProbabilityMeasure ν₀ :=
    MeasureTheory.Measure.isProbabilityMeasure_map hφ_meas.aemeasurable
  let Z₀ : Fin n → Ω → β := fun i ω => φ (X_samp i ω, Y_samp i ω)
  have hZ₀_meas : ∀ i : Fin n, Measurable (Z₀ i) :=
    fun i => hφ_meas.comp ((hX_meas i).prodMk (hY_meas i))
  let Z_vec : Ω → (Fin n → β) := fun ω i => Z₀ i ω
  have hZ_vec_meas : Measurable Z_vec := measurable_pi_lambda _ hZ₀_meas
  have hZ₀_indep : ProbabilityTheory.iIndepFun Z₀ μ :=
    hindep.comp (fun _ => φ) (fun _ => hφ_meas)
  have hZ₀_ident : ∀ i : Fin n, MeasureTheory.Measure.map (Z₀ i) μ = ν₀ := by
    intro i
    have h1 : Z₀ i = φ ∘ (fun ω => (X_samp i ω, Y_samp i ω)) := rfl
    rw [h1, ← MeasureTheory.Measure.map_map hφ_meas ((hX_meas i).prodMk (hY_meas i)), hident i]
  let π : MeasureTheory.Measure (Fin n → β) := MeasureTheory.Measure.pi (fun _ : Fin n => ν₀)
  have hmap_pi : MeasureTheory.Measure.map Z_vec μ = π := by
    have h1 := (ProbabilityTheory.iIndepFun_iff_map_fun_eq_pi_map (μ := μ)
      (f := Z₀) (fun i => (hZ₀_meas i).aemeasurable)).mp hZ₀_indep
    simpa only [hZ₀_ident] using h1
  let e₀ : β ≃ Set.range (kuratowskiPairInj (X := X) (K := K) (L := L)) :=
    Equiv.ofInjective _ (kuratowskiPairInj_injective (X := X) (K := K) (L := L))
  have hdev_meas_0 : Measurable (dev₀ ν₀ n R C M₀) :=
    measurable_dev₀ hK hn hL hR hC hM₀ ν₀
  have h_mc_conc := mcdiarmid_pi_of_equiv_type0.{u₁, u₂, uX} h_mc e₀ n hn ν₀
    (dev₀ ν₀ n R C M₀) hdev_meas_0 (2 * M₀ / (n : ℝ)) (by positivity)
    (dev₀_bdd_diff hK hn hL hR hC hM₀ ν₀) δ hδ0 hδ1
  have h_mean := integral_dev₀_le hK hn hL hR hC hM₀ ν₀
  let S_good : Set (Fin n → β) := {z | dev₀ ν₀ n R C M₀ z ≤ bound}
  have hS_good_meas : MeasurableSet S_good :=
    measurableSet_le hdev_meas_0 measurable_const
  have hπ_good : (π S_good).toReal ≥ 1 - δ := by
    rw [ge_iff_le]
    refine le_trans h_mc_conc ?_
    refine ENNReal.toReal_mono (MeasureTheory.measure_ne_top π _) (MeasureTheory.measure_mono ?_)
    intro z hz
    exact bound_combine_K K n hn L R C M₀ hL hR hC hM₀ δ hδ0 hδ1
      (dev₀ ν₀ n R C M₀ z) (∫ z', dev₀ ν₀ n R C M₀ z' ∂π) h_mean hz
  let E_ball : Set Ω := ⋂ i : Fin n, {ω : Ω | X_samp i ω ∈ Metric.closedBall (0 : X) L}
  have hE_ball_meas : MeasurableSet E_ball :=
    MeasurableSet.iInter fun i => (hX_meas i) Metric.isClosed_closedBall.measurableSet
  have hE_ball_compl_null : μ E_ballᶜ = 0 := by
    have h_compl : E_ballᶜ = ⋃ i : Fin n, {ω : Ω | X_samp i ω ∉ Metric.closedBall (0 : X) L} := by
      ext ω
      simp [E_ball]
    rw [h_compl]
    refine MeasureTheory.measure_iUnion_null fun i => ?_
    let B_bad : Set (X × Fin K) := {xy | xy.1 ∉ Metric.closedBall (0 : X) L}
    have hB_bad_meas : MeasurableSet B_bad :=
      (Metric.isClosed_closedBall.measurableSet.preimage measurable_fst).compl
    have h_pre_bad :
        {ω : Ω | X_samp i ω ∉ Metric.closedBall (0 : X) L} =
          (fun ω => (X_samp i ω, Y_samp i ω)) ⁻¹' B_bad := rfl
    rw [h_pre_bad, ← MeasureTheory.Measure.map_apply ((hX_meas i).prodMk (hY_meas i)) hB_bad_meas,
      hident i]
    have h_ae_ball : ∀ᵐ xy ∂ν, xy.1 ∈ Metric.closedBall (0 : X) L := by
      filter_upwards [hX_bound] with xy hxy
      simpa only [Metric.mem_closedBall, dist_zero_right] using hxy
    exact MeasureTheory.ae_iff.mp h_ae_ball
  let E : Set Ω := (Z_vec ⁻¹' S_good) ∩ E_ball
  have hE_meas : MeasurableSet E := (hZ_vec_meas hS_good_meas).inter hE_ball_meas
  have hμ_E_eq : μ E = π S_good := by
    have h_le1 : μ E ≤ μ (Z_vec ⁻¹' S_good) := MeasureTheory.measure_mono Set.inter_subset_left
    have h_le2 : μ (Z_vec ⁻¹' S_good) ≤ μ E := by
      have h_sub : Z_vec ⁻¹' S_good ⊆ E ∪ E_ballᶜ := by
        intro ω hω
        by_cases hb : ω ∈ E_ball
        · exact Or.inl ⟨hω, hb⟩
        · exact Or.inr hb
      calc
        μ (Z_vec ⁻¹' S_good) ≤ μ (E ∪ E_ballᶜ) := MeasureTheory.measure_mono h_sub
        _ ≤ μ E + μ E_ballᶜ := MeasureTheory.measure_union_le E E_ballᶜ
        _ = μ E := by rw [hE_ball_compl_null, add_zero]
    rw [le_antisymm h_le1 h_le2, ← hmap_pi,
      MeasureTheory.Measure.map_apply hZ_vec_meas hS_good_meas]
  refine ⟨E, hE_meas, ?_, ?_⟩
  · rw [hμ_E_eq]
    exact hπ_good
  · intro ω hω
    rcases hω with ⟨hω_good, hω_ball⟩
    have h_eq_set :
        ((fun f : β → ℝ =>
          |(∫ xy, evalProfile f xy.1 xy.2 ∂ν) -
            ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalProfile f (X_samp i ω) (Y_samp i ω)|) ''
          UL.ScoreProfileClass X K L R C M₀) =
        ((fun f : β → ℝ =>
          |(∫ q, f q ∂ν₀) - ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, f (Z_vec ω i)|) ''
          UL.ScoreProfileClass X K L R C M₀) := by
      refine Set.image_congr fun f hf => ?_
      have h_int_eq : (∫ xy, evalProfile f xy.1 xy.2 ∂ν) = ∫ q, f q ∂ν₀ := by
        have h_ae_eq : (fun xy : X × Fin K => evalProfile f xy.1 xy.2) =ᵐ[ν]
            (fun xy : X × Fin K => f (φ xy)) := by
          filter_upwards [hX_bound] with xy hxy
          have hx_mem : xy.1 ∈ Metric.closedBall (0 : X) L := by
            simpa only [Metric.mem_closedBall, dist_zero_right] using hxy
          dsimp [evalProfile, φ]
          rw [dif_pos hx_mem, clampBall_eq_of_mem hL hx_mem]
        rw [MeasureTheory.integral_congr_ae h_ae_eq,
          ← MeasureTheory.integral_map hφ_meas.aemeasurable
            (continuous_of_mem_scoreProfileClass hf).measurable.aestronglyMeasurable]
      have h_sum_eq :
          (∑ i : Fin n, evalProfile f (X_samp i ω) (Y_samp i ω)) =
            ∑ i : Fin n, f (Z_vec ω i) := by
        refine Finset.sum_congr rfl fun i _ => ?_
        have hx_i : X_samp i ω ∈ Metric.closedBall (0 : X) L :=
          Set.mem_iInter.mp hω_ball i
        dsimp [evalProfile, Z_vec, Z₀, φ]
        rw [dif_pos hx_i, clampBall_eq_of_mem hL hx_i]
      rw [h_int_eq, h_sum_eq]
    change sSup _ ≤ bound
    rw [h_eq_set]
    exact hω_good

end UL.Proof_lem_C_3_Race2

import UL.Stmt.cit_brouwer
import UL.Proof.cit_brouwer.Race2.H1_Sperner
import UL.Proof.cit_brouwer.Race2.H2_Cube
import UL.Proof.cit_brouwer.Race2.H3_Projection
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_cit_brouwer : S_cit_brouwer := by
  unfold S_cit_brouwer
  exact UL.Proof_cit_brouwer_Race2.brouwer_of_cube
    (fun n f hf => UL.Proof_cit_brouwer_Race2.brouwer_cube_of_sperner
      (fun M c hl hh => UL.Proof_cit_brouwer_Race2.cubical_sperner M c hl hh) n f hf)

end UL

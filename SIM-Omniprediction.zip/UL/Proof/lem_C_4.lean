import UL.Stmt.lem_C_4
set_option autoImplicit false

namespace UL

namespace LemC4Helpers

private lemma sum_apply {N : ℕ} {α : Type*} [DecidableEq α] (s : Finset α)
    (f : α → EuclideanSpace ℝ (Fin N)) (j : Fin N) :
    (∑ a ∈ s, f a) j = ∑ a ∈ s, f a j := by
  induction s using Finset.induction_on with
  | empty => rfl
  | @insert a s ha ih => simp [Finset.sum_insert ha, ih]

private noncomputable def eVec {n : ℕ} (j : Fin n) : EuclideanSpace ℝ (Fin n) :=
  (WithLp.equiv 2 (Fin n → ℝ)).symm (fun i => if i = j then 1 else 0)

private lemma eVec_apply {n : ℕ} (j i : Fin n) :
    eVec j i = if i = j then 1 else 0 := rfl

private lemma eVec_mem_simplex {n : ℕ} (j : Fin n) : eVec j ∈ Simplex n := by
  refine ⟨fun i => ?_, ?_⟩
  · simp only [eVec_apply]
    split_ifs <;> norm_num
  · simp [eVec_apply]

private lemma simplex_convex (N : ℕ) : Convex ℝ (Simplex N) := by
  intro x hx y hy a b ha hb hab
  refine ⟨fun j => ?_, ?_⟩
  · change 0 ≤ a * x j + b * y j
    exact add_nonneg (mul_nonneg ha (hx.1 j)) (mul_nonneg hb (hy.1 j))
  · have h : ∑ j : Fin N, (a • x + b • y) j = a * (∑ j : Fin N, x j) + b * (∑ j : Fin N, y j) := by
      calc ∑ j : Fin N, (a • x + b • y) j
          = ∑ j : Fin N, (a * x j + b * y j) := rfl
        _ = (∑ j : Fin N, a * x j) + ∑ j : Fin N, b * y j := Finset.sum_add_distrib
        _ = a * (∑ j : Fin N, x j) + b * (∑ j : Fin N, y j) := by
              rw [← Finset.mul_sum, ← Finset.mul_sum]
    rw [h, hx.2, hy.2]
    linarith

private lemma inner_eq_sum {N : ℕ} (x y : EuclideanSpace ℝ (Fin N)) :
    inner ℝ x y = ∑ i : Fin N, x i * y i := by
  rw [PiLp.inner_apply]
  refine Finset.sum_congr rfl (fun i _ => ?_)
  simp [mul_comm]

private lemma norm_sq_eq_sum {N : ℕ} (x : EuclideanSpace ℝ (Fin N)) :
    ‖x‖ ^ 2 = ∑ i : Fin N, (x i) ^ 2 := by
  rw [← real_inner_self_eq_norm_sq, inner_eq_sum]
  refine Finset.sum_congr rfl (fun i _ => ?_)
  ring

private lemma simplex_isCompact (n : ℕ) : IsCompact (Simplex n) := by
  rw [Metric.isCompact_iff_isClosed_bounded]
  constructor
  · have hEq : Simplex n = (⋂ j : Fin n, {q : EuclideanSpace ℝ (Fin n) | 0 ≤ q j}) ∩
        {q : EuclideanSpace ℝ (Fin n) | ∑ j : Fin n, q j = 1} := by
      ext q
      simp [Simplex]
    rw [hEq]
    have hcont : ∀ j : Fin n, Continuous (fun q : EuclideanSpace ℝ (Fin n) => q j) := by
      intro j
      exact PiLp.continuous_apply 2 (fun _ : Fin n => ℝ) j
    refine IsClosed.inter ?_ ?_
    · exact isClosed_iInter (fun j => isClosed_le continuous_const (hcont j))
    · exact isClosed_eq (continuous_finset_sum Finset.univ (fun j _ => hcont j)) continuous_const
  · rw [Metric.isBounded_iff_subset_closedBall 0]
    refine ⟨(n : ℝ) + 1, fun q hq => ?_⟩
    rw [Metric.mem_closedBall, dist_zero_right]
    have hcoord : ∀ j : Fin n, q j ≤ 1 := by
      intro j
      have hsub : q j ≤ ∑ i : Fin n, q i :=
        Finset.single_le_sum (fun i _ => hq.1 i) (Finset.mem_univ j)
      linarith [hq.2]
    have h1 : ‖q‖ ^ 2 ≤ (n : ℝ) := by
      rw [norm_sq_eq_sum]
      calc ∑ i : Fin n, (q i) ^ 2
          ≤ ∑ _i : Fin n, (1 : ℝ) := by
            refine Finset.sum_le_sum (fun i _ => ?_)
            nlinarith [hq.1 i, hcoord i]
        _ = (n : ℝ) := by simp
    have hn0 : (0 : ℝ) ≤ (n : ℝ) := Nat.cast_nonneg n
    nlinarith [norm_nonneg q]

private lemma toEuclideanLin_eq_sum {M n : ℕ} (v : Fin n → EuclideanSpace ℝ (Fin M))
    (θ : EuclideanSpace ℝ (Fin n)) :
    Matrix.toEuclideanLin (Matrix.of (fun r i => v i r)) θ = ∑ i : Fin n, θ i • v i := by
  ext r
  rw [sum_apply]
  simp [Matrix.toEuclideanLin_apply, Matrix.mulVec, dotProduct, mul_comm]

private lemma norm_add_smul_sq {E : Type*} [SeminormedAddCommGroup E] [InnerProductSpace ℝ E]
    (u v : E) (t : ℝ) :
    ‖u + t • v‖ ^ 2 = ‖u‖ ^ 2 + 2 * t * inner ℝ u v + t ^ 2 * ‖v‖ ^ 2 := by
  rw [norm_add_sq_real, inner_smul_right, norm_smul, Real.norm_eq_abs]
  have h : |t| ^ 2 = t ^ 2 := sq_abs t
  calc ‖u‖ ^ 2 + 2 * (t * inner ℝ u v) + (|t| * ‖v‖) ^ 2
      = ‖u‖ ^ 2 + 2 * t * inner ℝ u v + |t| ^ 2 * ‖v‖ ^ 2 := by ring
    _ = ‖u‖ ^ 2 + 2 * t * inner ℝ u v + t ^ 2 * ‖v‖ ^ 2 := by rw [h]

private lemma le_of_sq_le_sq_nonneg {x y : ℝ} (hx : 0 ≤ x) (hy : 0 ≤ y) (h : x ^ 2 ≤ y ^ 2) :
    x ≤ y := by
  nlinarith

section QuadModel

variable {m n K : ℕ}
  (B : ℝ)
  (A : EuclideanSpace ℝ (Fin n) →ₗ[ℝ] EuclideanSpace ℝ (Fin m))
  (C : EuclideanSpace ℝ (Fin n) →ₗ[ℝ] EuclideanSpace ℝ (Fin K))
  (d : EuclideanSpace ℝ (Fin n))

private noncomputable def QFn (s₀ : EuclideanSpace ℝ (Fin m)) (θ : EuclideanSpace ℝ (Fin n)) : ℝ :=
  B ^ 2 * ‖A θ - (2 : ℝ) • s₀‖ ^ 2 + ‖C θ‖ ^ 2 + inner ℝ d θ

private noncomputable def GFn (s₀ : EuclideanSpace ℝ (Fin m))
    (θ δ : EuclideanSpace ℝ (Fin n)) : ℝ :=
  2 * B ^ 2 * inner ℝ (A θ - (2 : ℝ) • s₀) (A δ) + 2 * inner ℝ (C θ) (C δ) + inner ℝ d δ

private noncomputable def MFn (δ : EuclideanSpace ℝ (Fin n)) : ℝ :=
  B ^ 2 * ‖A δ‖ ^ 2 + ‖C δ‖ ^ 2

private lemma MFn_nonneg (δ : EuclideanSpace ℝ (Fin n)) : 0 ≤ MFn B A C δ := by
  unfold MFn
  positivity

private lemma QFn_taylor (s₀ : EuclideanSpace ℝ (Fin m)) (θ δ : EuclideanSpace ℝ (Fin n)) (t : ℝ) :
    QFn B A C d s₀ (θ + t • δ) =
      QFn B A C d s₀ θ + t * GFn B A C d s₀ θ δ + t ^ 2 * MFn B A C δ := by
  have h1 : A (θ + t • δ) - (2 : ℝ) • s₀ = (A θ - (2 : ℝ) • s₀) + t • (A δ) := by
    rw [map_add, map_smul]
    abel
  have h2 : C (θ + t • δ) = C θ + t • (C δ) := by
    rw [map_add, map_smul]
  have h3 : inner ℝ d (θ + t • δ) = inner ℝ d θ + t * inner ℝ d δ := by
    rw [inner_add_right, inner_smul_right]
  unfold QFn GFn MFn
  rw [h1, h2, h3, norm_add_smul_sq, norm_add_smul_sq]
  ring

private lemma GFn_nonneg_of_isMinOn {s₀ : EuclideanSpace ℝ (Fin m)}
    {θ η : EuclideanSpace ℝ (Fin n)}
    (hθ : θ ∈ Simplex n) (hmin : IsMinOn (QFn B A C d s₀) (Simplex n) θ) (hη : η ∈ Simplex n) :
    0 ≤ GFn B A C d s₀ θ (η - θ) := by
  by_contra hneg
  push_neg at hneg
  set g := GFn B A C d s₀ θ (η - θ)
  set μ := MFn B A C (η - θ)
  have hμ0 : 0 ≤ μ := MFn_nonneg B A C (η - θ)
  set t : ℝ := min 1 (-g / (2 * (μ + 1)))
  have ht_pos : 0 < t := lt_min zero_lt_one (div_pos (by linarith) (by linarith))
  have ht_le_one : t ≤ 1 := min_le_left _ _
  have ht_bound : t * (μ + 1) ≤ -g / 2 := by
    have hle : t ≤ -g / (2 * (μ + 1)) := min_le_right _ _
    have hpos : 0 < μ + 1 := by linarith
    calc t * (μ + 1) ≤ (-g / (2 * (μ + 1))) * (μ + 1) :=
          mul_le_mul_of_nonneg_right hle hpos.le
      _ = -g / 2 := by field_simp [hpos.ne']
  have hmem : θ + t • (η - θ) ∈ Simplex n := by
    have heq : θ + t • (η - θ) = (1 - t) • θ + t • η := by
      ext i
      change θ i + t * (η i - θ i) = (1 - t) * θ i + t * η i
      ring
    rw [heq]
    exact simplex_convex n hθ hη (by linarith) ht_pos.le (by ring)
  have hmin_ineq : QFn B A C d s₀ θ ≤ QFn B A C d s₀ (θ + t • (η - θ)) := hmin hmem
  rw [QFn_taylor] at hmin_ineq
  have hpoly : 0 ≤ t * g + t ^ 2 * μ := by linarith
  have hdiv : 0 ≤ g + t * μ := by nlinarith
  have htm : t * μ ≤ t * (μ + 1) := by nlinarith
  linarith

private lemma quad_growth_of_isMinOn {s₀ : EuclideanSpace ℝ (Fin m)}
    {θ η : EuclideanSpace ℝ (Fin n)}
    (hθ : θ ∈ Simplex n) (hmin : IsMinOn (QFn B A C d s₀) (Simplex n) θ) (hη : η ∈ Simplex n) :
    ‖C η - C θ‖ ^ 2 ≤ QFn B A C d s₀ η - QFn B A C d s₀ θ := by
  have h1 := QFn_taylor B A C d s₀ θ (η - θ) 1
  have heq : θ + (1 : ℝ) • (η - θ) = η := by simp
  rw [heq, one_mul, one_pow, one_mul] at h1
  have hvi := GFn_nonneg_of_isMinOn B A C d hθ hmin hη
  have hm : ‖C η - C θ‖ ^ 2 ≤ MFn B A C (η - θ) := by
    unfold MFn
    rw [← map_sub]
    have hBsq : 0 ≤ B ^ 2 * ‖A (η - θ)‖ ^ 2 := by positivity
    linarith
  linarith

private lemma isMinOn_of_GFn_nonneg {s₀ : EuclideanSpace ℝ (Fin m)}
    {θ : EuclideanSpace ℝ (Fin n)}
    (hG : ∀ η ∈ Simplex n, 0 ≤ GFn B A C d s₀ θ (η - θ)) :
    IsMinOn (QFn B A C d s₀) (Simplex n) θ := by
  intro η hη
  change QFn B A C d s₀ θ ≤ QFn B A C d s₀ η
  have h1 := QFn_taylor B A C d s₀ θ (η - θ) 1
  have heq : θ + (1 : ℝ) • (η - θ) = η := by simp
  rw [heq, one_mul, one_pow, one_mul] at h1
  have hvi := hG η hη
  have hm := MFn_nonneg B A C (η - θ)
  linarith

private lemma exists_min (hn : 1 ≤ n) (s₀ : EuclideanSpace ℝ (Fin m)) :
    ∃ θ ∈ Simplex n, IsMinOn (QFn B A C d s₀) (Simplex n) θ := by
  have hne : (Simplex n).Nonempty := ⟨eVec ⟨0, by omega⟩, eVec_mem_simplex _⟩
  have hcontA : Continuous A := LinearMap.continuous_of_finiteDimensional A
  have hcontC : Continuous C := LinearMap.continuous_of_finiteDimensional C
  have hcontQ : Continuous (QFn B A C d s₀) := by
    unfold QFn
    fun_prop
  exact (simplex_isCompact n).exists_isMinOn hne hcontQ.continuousOn

private lemma uniq_C {s₀ : EuclideanSpace ℝ (Fin m)} {θ θ' : EuclideanSpace ℝ (Fin n)}
    (hθ : θ ∈ Simplex n) (hmin : IsMinOn (QFn B A C d s₀) (Simplex n) θ)
    (hθ' : θ' ∈ Simplex n) (hmin' : IsMinOn (QFn B A C d s₀) (Simplex n) θ') :
    C θ = C θ' := by
  have hg := quad_growth_of_isMinOn B A C d hθ hmin hθ'
  have hle : QFn B A C d s₀ θ' ≤ QFn B A C d s₀ θ := hmin' hθ
  have hsq0 : ‖C θ' - C θ‖ ^ 2 ≤ 0 := by linarith
  have hnorm0 : ‖C θ' - C θ‖ = 0 := by
    have hnn := norm_nonneg (C θ' - C θ)
    nlinarith
  exact (sub_eq_zero.mp (norm_eq_zero.mp hnorm0)).symm

private lemma vertex_isMinOn
    {s : Fin n → EuclideanSpace ℝ (Fin m)}
    {p : Fin n → EuclideanSpace ℝ (Fin K)}
    (hB : 0 < B)
    (hLip : ∀ i j : Fin n, ‖p i - p j‖ ≤ B * ‖s i - s j‖)
    (hA : ∀ θ : EuclideanSpace ℝ (Fin n), A θ = ∑ i : Fin n, θ i • s i)
    (hC : ∀ θ : EuclideanSpace ℝ (Fin n), C θ = ∑ i : Fin n, θ i • p i)
    (hd : ∀ δ : EuclideanSpace ℝ (Fin n),
      inner ℝ d δ = ∑ i : Fin n, δ i * (B ^ 2 * ‖s i‖ ^ 2 - ‖p i‖ ^ 2))
    (j : Fin n) :
    IsMinOn (QFn B A C d (s j)) (Simplex n) (eVec j) := by
  refine isMinOn_of_GFn_nonneg B A C d (fun η hη => ?_)
  set δ := η - eVec j
  have hsum_δ : ∑ i : Fin n, δ i = 0 := by
    have h1 : ∑ i : Fin n, δ i = (∑ i : Fin n, η i) - ∑ i : Fin n, eVec j i := by
      calc ∑ i : Fin n, δ i = ∑ i : Fin n, (η i - eVec j i) := rfl
        _ = (∑ i : Fin n, η i) - ∑ i : Fin n, eVec j i := Finset.sum_sub_distrib _ _
    rw [h1, hη.2, (eVec_mem_simplex j).2, sub_self]
  have heA : A (eVec j) = s j := by
    rw [hA]
    simp [eVec_apply]
  have heC : C (eVec j) = p j := by
    rw [hC]
    simp [eVec_apply]
  have hAe : A (eVec j) - (2 : ℝ) • s j = -s j := by
    rw [heA]
    ext r
    change s j r - 2 * s j r = -(s j r)
    ring
  have hinnerA : inner ℝ (A (eVec j) - (2 : ℝ) • s j) (A δ) =
      -∑ i : Fin n, δ i * inner ℝ (s j) (s i) := by
    rw [hAe, hA, inner_neg_left, inner_sum]
    congr 1
    refine Finset.sum_congr rfl (fun i _ => ?_)
    rw [inner_smul_right]
  have hinnerC : inner ℝ (C (eVec j)) (C δ) =
      ∑ i : Fin n, δ i * inner ℝ (p j) (p i) := by
    rw [heC, hC, inner_sum]
    refine Finset.sum_congr rfl (fun i _ => ?_)
    rw [inner_smul_right]
  have hG_eq : GFn B A C d (s j) (eVec j) δ =
      ∑ i : Fin n, η i * (B ^ 2 * ‖s i - s j‖ ^ 2 - ‖p i - p j‖ ^ 2) := by
    have hzero : (∑ i : Fin n, δ i) * (B ^ 2 * ‖s j‖ ^ 2 - ‖p j‖ ^ 2) = 0 := by
      rw [hsum_δ, zero_mul]
    have hlin :
        2 * B ^ 2 * (-∑ i : Fin n, δ i * inner ℝ (s j) (s i)) +
          2 * (∑ i : Fin n, δ i * inner ℝ (p j) (p i)) +
          (∑ i : Fin n, δ i * (B ^ 2 * ‖s i‖ ^ 2 - ‖p i‖ ^ 2)) +
          (∑ i : Fin n, δ i) * (B ^ 2 * ‖s j‖ ^ 2 - ‖p j‖ ^ 2) =
        ∑ i : Fin n, δ i * (B ^ 2 * ‖s i - s j‖ ^ 2 - ‖p i - p j‖ ^ 2) := by
      rw [mul_neg, Finset.mul_sum, Finset.mul_sum, Finset.sum_mul, ← Finset.sum_neg_distrib,
        ← Finset.sum_add_distrib, ← Finset.sum_add_distrib, ← Finset.sum_add_distrib]
      refine Finset.sum_congr rfl (fun i _ => ?_)
      rw [norm_sub_sq_real (s i) (s j), norm_sub_sq_real (p i) (p j),
        real_inner_comm (s i) (s j), real_inner_comm (p i) (p j)]
      ring
    have hG1 : GFn B A C d (s j) (eVec j) δ =
        ∑ i : Fin n, δ i * (B ^ 2 * ‖s i - s j‖ ^ 2 - ‖p i - p j‖ ^ 2) := by
      unfold GFn
      rw [hinnerA, hinnerC, hd]
      linarith
    rw [hG1]
    refine Finset.sum_congr rfl (fun i _ => ?_)
    have he0 : eVec j i * (B ^ 2 * ‖s i - s j‖ ^ 2 - ‖p i - p j‖ ^ 2) = 0 := by
      by_cases hij : i = j
      · subst hij; simp
      · simp [eVec_apply, hij]
    have hδi : δ i = η i - eVec j i := rfl
    rw [hδi]
    linarith
  rw [hG_eq]
  refine Finset.sum_nonneg (fun i _ => ?_)
  have hlip_ij := hLip i j
  have hsq_ij : ‖p i - p j‖ ^ 2 ≤ B ^ 2 * ‖s i - s j‖ ^ 2 := by
    have h1 : 0 ≤ ‖p i - p j‖ := norm_nonneg _
    have h2 : 0 ≤ B * ‖s i - s j‖ := mul_nonneg hB.le (norm_nonneg _)
    nlinarith
  exact mul_nonneg (hη.1 i) (by linarith)

private lemma rho_lipschitz
    (hB : 0 < B)
    {θ_s : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin n)}
    (hθ_s : ∀ s₀ : EuclideanSpace ℝ (Fin m),
      θ_s s₀ ∈ Simplex n ∧ IsMinOn (QFn B A C d s₀) (Simplex n) (θ_s s₀)) :
    LipschitzWith (Real.toNNReal B) (fun s₀ => C (θ_s s₀)) := by
  rw [lipschitzWith_iff_dist_le_mul]
  intro s₁ s₂
  rw [Real.coe_toNNReal B hB.le, dist_eq_norm, dist_eq_norm]
  set θ₁ := θ_s s₁
  set θ₂ := θ_s s₂
  set δ := θ₁ - θ₂
  have hvi1 : 0 ≤ GFn B A C d s₁ θ₁ (θ₂ - θ₁) :=
    GFn_nonneg_of_isMinOn B A C d (hθ_s s₁).1 (hθ_s s₁).2 (hθ_s s₂).1
  have hvi2 : 0 ≤ GFn B A C d s₂ θ₂ (θ₁ - θ₂) :=
    GFn_nonneg_of_isMinOn B A C d (hθ_s s₂).1 (hθ_s s₂).2 (hθ_s s₁).1
  have hG_neg : GFn B A C d s₁ θ₁ (θ₂ - θ₁) = -GFn B A C d s₁ θ₁ δ := by
    have hsub : θ₂ - θ₁ = -δ := by simp [δ]
    rw [hsub]
    unfold GFn
    rw [map_neg, map_neg, inner_neg_right, inner_neg_right, inner_neg_right]
    ring
  have hsumG : 0 ≤ GFn B A C d s₂ θ₂ δ - GFn B A C d s₁ θ₁ δ := by linarith
  have hdiffG : GFn B A C d s₂ θ₂ δ - GFn B A C d s₁ θ₁ δ =
      -2 * B ^ 2 * ‖A δ‖ ^ 2 + 4 * B ^ 2 * inner ℝ (s₁ - s₂) (A δ) - 2 * ‖C δ‖ ^ 2 := by
    have hA_diff : (A θ₂ - (2 : ℝ) • s₂) - (A θ₁ - (2 : ℝ) • s₁) =
        -A δ + (2 : ℝ) • (s₁ - s₂) := by
      have hδ : A δ = A θ₁ - A θ₂ := map_sub A θ₁ θ₂
      rw [hδ, smul_sub]
      abel
    have hC_diff : C θ₂ - C θ₁ = -C δ := by
      have hδ : C δ = C θ₁ - C θ₂ := map_sub C θ₁ θ₂
      rw [hδ]
      abel
    have h1 : inner ℝ (A θ₂ - (2 : ℝ) • s₂) (A δ) - inner ℝ (A θ₁ - (2 : ℝ) • s₁) (A δ) =
        -‖A δ‖ ^ 2 + 2 * inner ℝ (s₁ - s₂) (A δ) := by
      rw [← inner_sub_left, hA_diff, inner_add_left, inner_neg_left, inner_smul_left,
        real_inner_self_eq_norm_sq]
      simp
    have h2 : inner ℝ (C θ₂) (C δ) - inner ℝ (C θ₁) (C δ) = -‖C δ‖ ^ 2 := by
      rw [← inner_sub_left, hC_diff, inner_neg_left, real_inner_self_eq_norm_sq]
    unfold GFn
    linear_combination 2 * B ^ 2 * h1 + 2 * h2
  have hcomplete : ‖A δ - (s₁ - s₂)‖ ^ 2 =
      ‖A δ‖ ^ 2 - 2 * inner ℝ (s₁ - s₂) (A δ) + ‖s₁ - s₂‖ ^ 2 := by
    rw [norm_sub_sq_real, real_inner_comm (s₁ - s₂) (A δ)]
  have hsq_nonneg : 0 ≤ B ^ 2 * ‖A δ - (s₁ - s₂)‖ ^ 2 := by positivity
  have hCδ_sq : ‖C δ‖ ^ 2 ≤ (B * ‖s₁ - s₂‖) ^ 2 := by
    have hId : 2 * ‖C δ‖ ^ 2 + 2 * (B ^ 2 * ‖A δ - (s₁ - s₂)‖ ^ 2) +
        (GFn B A C d s₂ θ₂ δ - GFn B A C d s₁ θ₁ δ) =
        2 * (B * ‖s₁ - s₂‖) ^ 2 := by
      rw [hdiffG, hcomplete]
      ring
    linarith
  have hρ_eq : C θ₁ - C θ₂ = C δ := (map_sub C θ₁ θ₂).symm
  rw [hρ_eq]
  exact le_of_sq_le_sq_nonneg (norm_nonneg _) (mul_nonneg hB.le (norm_nonneg _)) hCδ_sq

private lemma rho_accuracy
    {θ_s : EuclideanSpace ℝ (Fin m) → EuclideanSpace ℝ (Fin n)}
    (hθ_s : ∀ s₀ : EuclideanSpace ℝ (Fin m),
      θ_s s₀ ∈ Simplex n ∧ IsMinOn (QFn B A C d s₀) (Simplex n) (θ_s s₀))
    (s₀ : EuclideanSpace ℝ (Fin m)) (θ_hat : EuclideanSpace ℝ (Fin n)) (ζ : ℝ)
    (hθ_hat : θ_hat ∈ Simplex n)
    (hQ_hat : QFn B A C d s₀ θ_hat ≤ sInf (QFn B A C d s₀ '' Simplex n) + ζ) :
    ‖C θ_hat - C (θ_s s₀)‖ ≤ Real.sqrt ζ := by
  have hθ₀ := hθ_s s₀
  have hLeast : IsLeast (QFn B A C d s₀ '' Simplex n) (QFn B A C d s₀ (θ_s s₀)) := by
    refine ⟨⟨θ_s s₀, hθ₀.1, rfl⟩, ?_⟩
    rintro _ ⟨η, hη, rfl⟩
    exact hθ₀.2 hη
  rw [hLeast.csInf_eq] at hQ_hat
  have hg := quad_growth_of_isMinOn B A C d hθ₀.1 hθ₀.2 hθ_hat
  have hsq : ‖C θ_hat - C (θ_s s₀)‖ ^ 2 ≤ ζ := by linarith
  exact Real.le_sqrt_of_sq_le hsq

end QuadModel

end LemC4Helpers

open LemC4Helpers in
theorem simplexExtensionAllDimensions : SimplexExtensionAllDimensions := by
  intro m n K hn _hK s p hp B hB hLip
  let S : Matrix (Fin m) (Fin n) ℝ := Matrix.of (fun r i => s i r)
  let P : Matrix (Fin K) (Fin n) ℝ := Matrix.of (fun k i => p i k)
  let d : EuclideanSpace ℝ (Fin n) :=
    (WithLp.equiv 2 (Fin n → ℝ)).symm (fun i => B ^ 2 * ‖s i‖ ^ 2 - ‖p i‖ ^ 2)
  have hA : ∀ θ : EuclideanSpace ℝ (Fin n),
      Matrix.toEuclideanLin S θ = ∑ i : Fin n, θ i • s i :=
    toEuclideanLin_eq_sum s
  have hC : ∀ θ : EuclideanSpace ℝ (Fin n),
      Matrix.toEuclideanLin P θ = ∑ i : Fin n, θ i • p i :=
    toEuclideanLin_eq_sum p
  have hd : ∀ δ : EuclideanSpace ℝ (Fin n),
      inner ℝ d δ = ∑ i : Fin n, δ i * (B ^ 2 * ‖s i‖ ^ 2 - ‖p i‖ ^ 2) := by
    intro δ
    rw [inner_eq_sum]
    refine Finset.sum_congr rfl (fun i _ => ?_)
    change (B ^ 2 * ‖s i‖ ^ 2 - ‖p i‖ ^ 2) * δ i = δ i * (B ^ 2 * ‖s i‖ ^ 2 - ‖p i‖ ^ 2)
    ring
  refine ⟨exists_min B (Matrix.toEuclideanLin S) (Matrix.toEuclideanLin P) d hn,
    fun s₀ θ θ' hθ hmin hθ' hmin' =>
      uniq_C B (Matrix.toEuclideanLin S) (Matrix.toEuclideanLin P) d hθ hmin hθ' hmin',
    ?_⟩
  intro θ_s hθ_s
  refine ⟨?_, ?_, ?_,
    rho_lipschitz B (Matrix.toEuclideanLin S) (Matrix.toEuclideanLin P) d hB hθ_s,
    fun s₀ θ_hat ζ hθ_hat _hζ hQ_hat =>
      rho_accuracy B (Matrix.toEuclideanLin S) (Matrix.toEuclideanLin P) d hθ_s s₀ θ_hat ζ
        hθ_hat hQ_hat⟩
  · intro s₀
    change Matrix.toEuclideanLin P (θ_s s₀) ∈ convexHull ℝ (Set.range p)
    rw [hC]
    have hθ := (hθ_s s₀).1
    exact (convex_convexHull ℝ (Set.range p)).sum_mem
      (fun i _ => hθ.1 i) hθ.2
      (fun i _ => subset_convexHull ℝ (Set.range p) ⟨i, rfl⟩)
  · refine convexHull_min ?_ (simplex_convex K)
    rintro _ ⟨i, rfl⟩
    exact hp i
  · intro j
    have heMin := vertex_isMinOn B (Matrix.toEuclideanLin S) (Matrix.toEuclideanLin P) d
      hB hLip hA hC hd j
    have heC : Matrix.toEuclideanLin P (eVec j) = p j := by
      rw [hC]
      simp [eVec_apply]
    have hθj := hθ_s (s j)
    calc Matrix.toEuclideanLin P (θ_s (s j))
        = Matrix.toEuclideanLin P (eVec j) :=
          uniq_C B (Matrix.toEuclideanLin S) (Matrix.toEuclideanLin P) d
            hθj.1 hθj.2 (eVec_mem_simplex j) heMin
      _ = p j := heC

theorem P_lem_C_4 : S_lem_C_4 := by
  intro m n K _ hn hK
  exact simplexExtensionAllDimensions m n K hn hK

end UL

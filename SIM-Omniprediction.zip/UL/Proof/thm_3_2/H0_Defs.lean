import Mathlib
import UL.Def.def_3_binary
set_option autoImplicit false

namespace UL.Proof_thm_3_2

/-- Feasible scalar profile: monotone nondecreasing, `β`-Lipschitz, and `[0, 1]`-valued. -/
def IsProfile (β : ℝ) (ρ : ℝ → ℝ) : Prop :=
  Monotone ρ ∧ LipschitzWith (Real.toNNReal β) ρ ∧ ∀ t : ℝ, ρ t ∈ Set.Icc (0 : ℝ) 1

/-- Clamping of a real number to `[a, b]`. -/
def clampIcc (a b x : ℝ) : ℝ :=
  max a (min b x)

lemma clampIcc_mem {a b : ℝ} (hab : a ≤ b) (x : ℝ) :
    clampIcc a b x ∈ Set.Icc a b := by
  unfold clampIcc
  refine ⟨le_max_left _ _, max_le hab (min_le_left _ _)⟩

lemma clampIcc_of_mem {a b x : ℝ} (hx : x ∈ Set.Icc a b) :
    clampIcc a b x = x := by
  unfold clampIcc
  rw [min_eq_right hx.2, max_eq_right hx.1]

lemma clampIcc_mono (a b : ℝ) : Monotone (clampIcc a b) := by
  intro x y hxy
  unfold clampIcc
  exact max_le_max_left a (min_le_min_left b hxy)

lemma abs_min_sub_min_le (b x y : ℝ) : |min b x - min b y| ≤ |x - y| := by
  rcases le_total b x with hbx | hxb <;> rcases le_total b y with hby | hyb
  · simp [min_eq_left hbx, min_eq_left hby]
  · rw [min_eq_left hbx, min_eq_right hyb, abs_le]
    have hxy := le_abs_self (x - y)
    have hyx := neg_le_abs (x - y)
    constructor <;> linarith
  · rw [min_eq_right hxb, min_eq_left hby, abs_le]
    have hxy := le_abs_self (x - y)
    have hyx := neg_le_abs (x - y)
    constructor <;> linarith
  · simp [min_eq_right hxb, min_eq_right hyb]

lemma abs_max_sub_max_le (a x y : ℝ) : |max a x - max a y| ≤ |x - y| := by
  rcases le_total a x with hax | hxa <;> rcases le_total a y with hay | hya
  · simp [max_eq_right hax, max_eq_right hay]
  · rw [max_eq_right hax, max_eq_left hya, abs_le]
    have hxy := le_abs_self (x - y)
    have hyx := neg_le_abs (x - y)
    constructor <;> linarith
  · rw [max_eq_left hxa, max_eq_right hay, abs_le]
    have hxy := le_abs_self (x - y)
    have hyx := neg_le_abs (x - y)
    constructor <;> linarith
  · simp [max_eq_left hxa, max_eq_left hya]

lemma abs_clampIcc_sub_le (a b x y : ℝ) :
    |clampIcc a b x - clampIcc a b y| ≤ |x - y| :=
  le_trans (abs_max_sub_max_le a (min b x) (min b y)) (abs_min_sub_min_le b x y)

lemma lipschitzWith_toNNReal_iff {β : ℝ} (hβ : 0 ≤ β) (ρ : ℝ → ℝ) :
    LipschitzWith (Real.toNNReal β) ρ ↔ ∀ x y : ℝ, |ρ x - ρ y| ≤ β * |x - y| := by
  rw [lipschitzWith_iff_dist_le_mul]
  simp only [Real.dist_eq, Real.coe_toNNReal β hβ]

lemma IsProfile.continuous {β : ℝ} {ρ : ℝ → ℝ} (hρ : IsProfile β ρ) : Continuous ρ :=
  hρ.2.1.continuous

lemma IsProfile.measurable {β : ℝ} {ρ : ℝ → ℝ} (hρ : IsProfile β ρ) : Measurable ρ :=
  hρ.continuous.measurable

lemma IsProfile.nonneg {β : ℝ} {ρ : ℝ → ℝ} (hρ : IsProfile β ρ) (t : ℝ) : 0 ≤ ρ t :=
  (hρ.2.2 t).1

lemma IsProfile.le_one {β : ℝ} {ρ : ℝ → ℝ} (hρ : IsProfile β ρ) (t : ℝ) : ρ t ≤ 1 :=
  (hρ.2.2 t).2

lemma isProfile_zero (β : ℝ) : IsProfile β (fun _ => 0) := by
  refine ⟨monotone_const, (LipschitzWith.const 0).weaken (zero_le _),
    fun _ => ⟨le_rfl, zero_le_one⟩⟩

lemma IsProfile.convex_comb {β : ℝ} (hβ : 0 ≤ β) {ρ₀ ρ₁ : ℝ → ℝ}
    (h₀ : IsProfile β ρ₀) (h₁ : IsProfile β ρ₁) {t : ℝ} (ht0 : 0 ≤ t) (ht1 : t ≤ 1) :
    IsProfile β (fun x => (1 - t) * ρ₀ x + t * ρ₁ x) := by
  have ht1' : 0 ≤ 1 - t := sub_nonneg.mpr ht1
  refine ⟨?_, ?_, ?_⟩
  · intro x y hxy
    have h0xy := h₀.1 hxy
    have h1xy := h₁.1 hxy
    nlinarith
  · rw [lipschitzWith_toNNReal_iff hβ]
    have hL0 := (lipschitzWith_toNNReal_iff hβ ρ₀).mp h₀.2.1
    have hL1 := (lipschitzWith_toNNReal_iff hβ ρ₁).mp h₁.2.1
    intro x y
    have heq : ((1 - t) * ρ₀ x + t * ρ₁ x) - ((1 - t) * ρ₀ y + t * ρ₁ y) =
        (1 - t) * (ρ₀ x - ρ₀ y) + t * (ρ₁ x - ρ₁ y) := by ring
    rw [heq]
    calc
      |(1 - t) * (ρ₀ x - ρ₀ y) + t * (ρ₁ x - ρ₁ y)|
        ≤ |(1 - t) * (ρ₀ x - ρ₀ y)| + |t * (ρ₁ x - ρ₁ y)| := abs_add_le _ _
      _ = (1 - t) * |ρ₀ x - ρ₀ y| + t * |ρ₁ x - ρ₁ y| := by
        rw [abs_mul, abs_mul, abs_of_nonneg ht1', abs_of_nonneg ht0]
      _ ≤ (1 - t) * (β * |x - y|) + t * (β * |x - y|) := by
        gcongr
        · exact hL0 x y
        · exact hL1 x y
      _ = β * |x - y| := by ring
  · intro x
    have h0x := h₀.2.2 x
    have h1x := h₁.2.2 x
    refine ⟨by nlinarith [h0x.1, h1x.1], by nlinarith [h0x.2, h1x.2]⟩

/-- Real embedding of a binary label `y : Fin 2` (`0` or `1`). -/
def yReal (y : Fin 2) : ℝ :=
  (y.val : ℝ)

lemma yReal_eq_zero_or_one (y : Fin 2) : yReal y = 0 ∨ yReal y = 1 := by
  fin_cases y <;> simp [yReal]

lemma yReal_mem_Icc (y : Fin 2) : yReal y ∈ Set.Icc (0 : ℝ) 1 := by
  rcases yReal_eq_zero_or_one y with h | h <;> simp [h]

lemma eq_zero_of_yReal_eq_zero {y : Fin 2} (h : yReal y = 0) : y = 0 := by
  fin_cases y <;> simp [yReal] at h ⊢

lemma eq_one_of_yReal_eq_one {y : Fin 2} (h : yReal y = 1) : y = 1 := by
  fin_cases y <;> simp [yReal] at h ⊢

lemma measurable_yReal {Ω : Type*} [MeasurableSpace Ω] {Y : Ω → Fin 2}
    (hY : Measurable Y) : Measurable (fun ω => yReal (Y ω)) := by
  have hc : Measurable yReal := measurable_of_finite yReal
  exact hc.comp hY

/-- Squared-error profile risk at score vector `w`. -/
noncomputable def fitRisk {d : ℕ} {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω)
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin 2)
    (w : EuclideanSpace ℝ (Fin d)) (ρ : ℝ → ℝ) : ℝ :=
  ∫ ω, (ρ (inner ℝ w (X ω)) - yReal (Y ω)) ^ 2 ∂μ

/-- `ρ` is a profile minimizer of `fitRisk μ X Y w` over `IsProfile β`. -/
def IsOptProfile {d : ℕ} {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) (β : ℝ)
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin 2)
    (w : EuclideanSpace ℝ (Fin d)) (ρ : ℝ → ℝ) : Prop :=
  IsProfile β ρ ∧ ∀ ρ' : ℝ → ℝ, IsProfile β ρ' → fitRisk μ X Y w ρ ≤ fitRisk μ X Y w ρ'

/-- Residual `P ω - Y ω` of a scalar prediction `P`. -/
def fitRes {Ω : Type*} (P : Ω → ℝ) (Y : Ω → Fin 2) (ω : Ω) : ℝ :=
  P ω - yReal (Y ω)

lemma abs_fitRes_le_one {Ω : Type*} {P : Ω → ℝ}
    (hP : ∀ ω : Ω, P ω ∈ Set.Icc (0 : ℝ) 1) (Y : Ω → Fin 2) (ω : Ω) :
    |fitRes P Y ω| ≤ 1 := by
  unfold fitRes
  have hp := hP ω
  have hy := yReal_mem_Icc (Y ω)
  rw [abs_le]
  exact ⟨by linarith [hp.1, hy.2], by linarith [hp.2, hy.1]⟩

end UL.Proof_thm_3_2

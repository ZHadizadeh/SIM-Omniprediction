import UL.Proof.thm_3_2.H0_Defs
set_option autoImplicit false

namespace UL.Proof_thm_3_2

private lemma abs_sub_le_one_of_mem_Icc {a b : ℝ}
    (ha : a ∈ Set.Icc (0 : ℝ) 1) (hb : b ∈ Set.Icc (0 : ℝ) 1) :
    |a - b| ≤ 1 := by
  rw [abs_le]
  exact ⟨by linarith [ha.1, hb.2], by linarith [ha.2, hb.1]⟩

private lemma sq_le_one_of_abs_le_one {a : ℝ} (ha : |a| ≤ 1) :
    a ^ 2 ≤ 1 := by
  have h := abs_le.mp ha
  nlinarith

private lemma isProfile_seqCompact {β : ℝ} (hβ : 0 < β) (ρ_seq : ℕ → (ℝ → ℝ))
    (hρ : ∀ n, IsProfile β (ρ_seq n)) :
    ∃ (ρ_lim : ℝ → ℝ) (φ : ℕ → ℕ), StrictMono φ ∧ IsProfile β ρ_lim ∧
      (∀ t : ℝ, Filter.Tendsto (fun k => ρ_seq (φ k) t) Filter.atTop (nhds (ρ_lim t))) ∧
      (∀ (t_seq : ℕ → ℝ) (t : ℝ),
        Filter.Tendsto t_seq Filter.atTop (nhds t) →
        Filter.Tendsto (fun k => ρ_seq (φ k) (t_seq k)) Filter.atTop (nhds (ρ_lim t))) := by
  let f : ℕ → (ℚ → ℝ) := fun n q => ρ_seq n q
  let K : Set (ℚ → ℝ) := Set.pi Set.univ (fun _ : ℚ => Set.Icc (0 : ℝ) 1)
  have hK : IsCompact K := isCompact_univ_pi (fun _ => isCompact_Icc)
  have hf_mem : ∀ n, f n ∈ K := fun n q _ => (hρ n).2.2 q
  obtain ⟨g, _, φ, hφ_mono, hφ_lim⟩ := hK.tendsto_subseq hf_mem
  have hq_lim : ∀ q : ℚ, Filter.Tendsto (fun k => ρ_seq (φ k) q) Filter.atTop (nhds (g q)) :=
    tendsto_pi_nhds.mp hφ_lim
  have hLip : ∀ n x y, |ρ_seq n x - ρ_seq n y| ≤ β * |x - y| :=
    fun n => (lipschitzWith_toNNReal_iff hβ.le (ρ_seq n)).mp (hρ n).2.1
  have hcauchy : ∀ t : ℝ, CauchySeq (fun k => ρ_seq (φ k) t) := by
    intro t
    rw [Metric.cauchySeq_iff]
    intro ε hε
    let δ : ℝ := ε / (4 * β)
    have hδ : 0 < δ := by positivity
    obtain ⟨q, hq1, hq2⟩ := exists_rat_btwn (by linarith : t - δ < t + δ)
    have hq_abs : |t - (q : ℝ)| < δ := abs_lt.mpr ⟨by linarith, by linarith⟩
    have hq_mul : β * |t - (q : ℝ)| < ε / 4 := by
      have h1 : β * |t - (q : ℝ)| < β * δ := mul_lt_mul_of_pos_left hq_abs hβ
      have h2 : β * δ = ε / 4 := by
        dsimp [δ]
        field_simp
      linarith
    obtain ⟨N, hN⟩ := Metric.tendsto_atTop.mp (hq_lim q) (ε / 4) (by positivity)
    refine ⟨N, fun m hm n hn => ?_⟩
    rw [Real.dist_eq]
    have hm_q : |ρ_seq (φ m) q - g q| < ε / 4 := by simpa [Real.dist_eq] using hN m hm
    have hn_q : |ρ_seq (φ n) q - g q| < ε / 4 := by simpa [Real.dist_eq] using hN n hn
    have hm_t : |ρ_seq (φ m) t - ρ_seq (φ m) q| ≤ β * |t - q| := hLip (φ m) t q
    have hn_t : |ρ_seq (φ n) q - ρ_seq (φ n) t| ≤ β * |t - q| := by
      rw [abs_sub_comm]
      exact hLip (φ n) t q
    have htri : |ρ_seq (φ m) t - ρ_seq (φ n) t| ≤
        |ρ_seq (φ m) t - ρ_seq (φ m) q| + |ρ_seq (φ m) q - g q| +
        |g q - ρ_seq (φ n) q| + |ρ_seq (φ n) q - ρ_seq (φ n) t| := by
      have heq : ρ_seq (φ m) t - ρ_seq (φ n) t =
          ((ρ_seq (φ m) t - ρ_seq (φ m) q) + (ρ_seq (φ m) q - g q)) +
          ((g q - ρ_seq (φ n) q) + (ρ_seq (φ n) q - ρ_seq (φ n) t)) := by ring
      rw [heq]
      linarith [abs_add_le ((ρ_seq (φ m) t - ρ_seq (φ m) q) + (ρ_seq (φ m) q - g q))
          ((g q - ρ_seq (φ n) q) + (ρ_seq (φ n) q - ρ_seq (φ n) t)),
        abs_add_le (ρ_seq (φ m) t - ρ_seq (φ m) q) (ρ_seq (φ m) q - g q),
        abs_add_le (g q - ρ_seq (φ n) q) (ρ_seq (φ n) q - ρ_seq (φ n) t)]
    rw [abs_sub_comm (g q) (ρ_seq (φ n) q)] at htri
    linarith
  choose ρ_lim hρ_lim using fun t => cauchySeq_tendsto_of_complete (hcauchy t)
  have h_prof_lim : IsProfile β ρ_lim := by
    refine ⟨?_, ?_, ?_⟩
    · intro x y hxy
      exact le_of_tendsto_of_tendsto (hρ_lim x) (hρ_lim y)
        (Filter.Eventually.of_forall fun k => (hρ (φ k)).1 hxy)
    · rw [lipschitzWith_toNNReal_iff hβ.le]
      intro x y
      exact le_of_tendsto (((hρ_lim x).sub (hρ_lim y)).abs)
        (Filter.Eventually.of_forall fun k => hLip (φ k) x y)
    · intro x
      exact ⟨le_of_tendsto_of_tendsto tendsto_const_nhds (hρ_lim x)
          (Filter.Eventually.of_forall fun k => (hρ (φ k)).nonneg x),
        le_of_tendsto (hρ_lim x)
          (Filter.Eventually.of_forall fun k => (hρ (φ k)).le_one x)⟩
  refine ⟨ρ_lim, φ, hφ_mono, h_prof_lim, hρ_lim, ?_⟩
  intro t_seq t ht
  rw [tendsto_iff_norm_sub_tendsto_zero]
  have hg_lim : Filter.Tendsto
      (fun k => β * |t_seq k - t| + |ρ_seq (φ k) t - ρ_lim t|) Filter.atTop (nhds 0) := by
    have h1 : Filter.Tendsto (fun k => β * |t_seq k - t|) Filter.atTop (nhds (β * |t - t|)) :=
      ((ht.sub tendsto_const_nhds).abs).const_mul β
    have h2 : Filter.Tendsto (fun k => |ρ_seq (φ k) t - ρ_lim t|) Filter.atTop
        (nhds |ρ_lim t - ρ_lim t|) :=
      ((hρ_lim t).sub tendsto_const_nhds).abs
    simpa using h1.add h2
  refine squeeze_zero (fun _ => norm_nonneg _) (fun k => ?_) hg_lim
  rw [Real.norm_eq_abs]
  have heq : ρ_seq (φ k) (t_seq k) - ρ_lim t =
      (ρ_seq (φ k) (t_seq k) - ρ_seq (φ k) t) + (ρ_seq (φ k) t - ρ_lim t) := by ring
  rw [heq]
  linarith [abs_add_le (ρ_seq (φ k) (t_seq k) - ρ_seq (φ k) t) (ρ_seq (φ k) t - ρ_lim t),
    hLip (φ k) (t_seq k) t]

private lemma measurable_score {d : ℕ} {Ω : Type*} [MeasurableSpace Ω]
    {X : Ω → EuclideanSpace ℝ (Fin d)} (hX : Measurable X) (w : EuclideanSpace ℝ (Fin d)) :
    Measurable (fun ω => inner ℝ w (X ω)) :=
  (continuous_const.inner continuous_id).measurable.comp hX

private lemma measurable_profile_score {d : ℕ} {Ω : Type*} [MeasurableSpace Ω]
    {X : Ω → EuclideanSpace ℝ (Fin d)} (hX : Measurable X)
    {β : ℝ} {ρ : ℝ → ℝ} (hρ : IsProfile β ρ) (w : EuclideanSpace ℝ (Fin d)) :
    Measurable (fun ω => ρ (inner ℝ w (X ω))) :=
  hρ.measurable.comp (measurable_score hX w)

private lemma integrable_of_measurable_abs_le {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ]
    {f : Ω → ℝ} (hf : Measurable f) (C : ℝ) (hC : ∀ ω, |f ω| ≤ C) :
    MeasureTheory.Integrable f μ :=
  (MeasureTheory.integrable_const C).mono' hf.aestronglyMeasurable
    (Filter.Eventually.of_forall fun ω => by simpa [Real.norm_eq_abs] using hC ω)

private lemma integrable_fitRisk_integrand {d : ℕ} {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ]
    {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin 2}
    (hX : Measurable X) (hY : Measurable Y)
    {β : ℝ} {ρ : ℝ → ℝ} (hρ : IsProfile β ρ) (w : EuclideanSpace ℝ (Fin d)) :
    MeasureTheory.Integrable (fun ω => (ρ (inner ℝ w (X ω)) - yReal (Y ω)) ^ 2) μ := by
  refine integrable_of_measurable_abs_le μ
    (((measurable_profile_score hX hρ w).sub (measurable_yReal hY)).pow_const 2) 1 ?_
  intro ω
  rw [abs_of_nonneg (sq_nonneg _)]
  exact sq_le_one_of_abs_le_one (abs_sub_le_one_of_mem_Icc (hρ.2.2 _) (yReal_mem_Icc (Y ω)))

private lemma tendsto_fitRisk {d : ℕ} {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ]
    {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin 2}
    (hX : Measurable X) (hY : Measurable Y)
    {β : ℝ} {w_seq : ℕ → EuclideanSpace ℝ (Fin d)} {w : EuclideanSpace ℝ (Fin d)}
    {ρ_seq : ℕ → (ℝ → ℝ)} (hρ : ∀ k, IsProfile β (ρ_seq k))
    {ρ_lim : ℝ → ℝ}
    (h_pt : ∀ ω : Ω, Filter.Tendsto (fun k => ρ_seq k (inner ℝ (w_seq k) (X ω)))
      Filter.atTop (nhds (ρ_lim (inner ℝ w (X ω))))) :
    Filter.Tendsto (fun k => fitRisk μ X Y (w_seq k) (ρ_seq k))
      Filter.atTop (nhds (fitRisk μ X Y w ρ_lim)) := by
  unfold fitRisk
  refine MeasureTheory.tendsto_integral_of_dominated_convergence (fun _ : Ω => (1 : ℝ))
    (fun k => (((measurable_profile_score hX (hρ k) (w_seq k)).sub
      (measurable_yReal hY)).pow_const 2).aestronglyMeasurable)
    (MeasureTheory.integrable_const (1 : ℝ)) ?_ ?_
  · intro k
    refine Filter.Eventually.of_forall fun ω => ?_
    rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
    exact sq_le_one_of_abs_le_one
      (abs_sub_le_one_of_mem_Icc ((hρ k).2.2 _) (yReal_mem_Icc (Y ω)))
  · refine Filter.Eventually.of_forall fun ω => ?_
    exact ((h_pt ω).sub tendsto_const_nhds).pow 2

private lemma exists_optProfile {d : ℕ} {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ]
    {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin 2}
    (hX : Measurable X) (hY : Measurable Y)
    {β : ℝ} (hβ : 0 < β) (w : EuclideanSpace ℝ (Fin d)) :
    ∃ ρ : ℝ → ℝ, IsOptProfile μ β X Y w ρ := by
  let S : Set ℝ := (fitRisk μ X Y w) '' {ρ : ℝ → ℝ | IsProfile β ρ}
  have hS_ne : S.Nonempty := ⟨fitRisk μ X Y w (fun _ => 0), (fun _ => 0), isProfile_zero β, rfl⟩
  have hS_bdd : BddBelow S := by
    refine ⟨0, ?_⟩
    rintro _ ⟨ρ, _, rfl⟩
    exact MeasureTheory.integral_nonneg (fun _ => sq_nonneg _)
  have hex : ∀ n : ℕ, ∃ ρ : ℝ → ℝ,
      IsProfile β ρ ∧ fitRisk μ X Y w ρ < sInf S + 1 / (n + 1 : ℝ) := by
    intro n
    have hlt : sInf S < sInf S + 1 / (n + 1 : ℝ) := by
      have hpos : (0 : ℝ) < 1 / (n + 1 : ℝ) := by positivity
      linarith
    obtain ⟨_, ⟨ρ, hρ, rfl⟩, hρ_lt⟩ := exists_lt_of_csInf_lt hS_ne hlt
    exact ⟨ρ, hρ, hρ_lt⟩
  choose ρ_seq hρ_prof hρ_lt using hex
  obtain ⟨ρ_w, φ, hφ_mono, hρ_w, h_pt, _⟩ := isProfile_seqCompact hβ ρ_seq hρ_prof
  have h_risk_lim : Filter.Tendsto (fun k => fitRisk μ X Y w (ρ_seq (φ k)))
      Filter.atTop (nhds (fitRisk μ X Y w ρ_w)) :=
    tendsto_fitRisk μ hX hY (w_seq := fun _ => w) (fun k => hρ_prof (φ k))
      (fun ω => h_pt (inner ℝ w (X ω)))
  have h_upper_lim : Filter.Tendsto (fun k : ℕ => sInf S + 1 / (k + 1 : ℝ))
      Filter.atTop (nhds (sInf S + 0)) :=
    tendsto_const_nhds.add tendsto_one_div_add_atTop_nhds_zero_nat
  have h_le_sInf : fitRisk μ X Y w ρ_w ≤ sInf S := by
    have h_le : fitRisk μ X Y w ρ_w ≤ sInf S + 0 := by
      refine le_of_tendsto_of_tendsto h_risk_lim h_upper_lim
        (Filter.Eventually.of_forall fun k => ?_)
      have hk : (k : ℝ) + 1 ≤ (φ k : ℝ) + 1 := by
        exact_mod_cast Nat.add_le_add_right (hφ_mono.id_le k) 1
      have hdiv : 1 / ((φ k : ℝ) + 1) ≤ 1 / ((k : ℝ) + 1) :=
        one_div_le_one_div_of_le (by positivity) hk
      linarith [hρ_lt (φ k)]
    linarith
  refine ⟨ρ_w, hρ_w, fun ρ' hρ' => ?_⟩
  exact le_trans h_le_sInf (csInf_le hS_bdd ⟨ρ', hρ', rfl⟩)

private lemma optProfile_vi_and_gap {d : ℕ} {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ]
    {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin 2}
    (hX : Measurable X) (hY : Measurable Y)
    {β : ℝ} (hβ : 0 < β) {w : EuclideanSpace ℝ (Fin d)}
    {ρ ρ' : ℝ → ℝ} (h_opt : IsOptProfile μ β X Y w ρ) (hρ' : IsProfile β ρ') :
    (0 ≤ ∫ ω, fitRes (fun ω' => ρ (inner ℝ w (X ω'))) Y ω *
      (ρ' (inner ℝ w (X ω)) - ρ (inner ℝ w (X ω))) ∂μ) ∧
    (∫ ω, (ρ' (inner ℝ w (X ω)) - ρ (inner ℝ w (X ω))) ^ 2 ∂μ ≤
      fitRisk μ X Y w ρ' - fitRisk μ X Y w ρ) := by
  let P : Ω → ℝ := fun ω => ρ (inner ℝ w (X ω))
  let Q : Ω → ℝ := fun ω => ρ' (inner ℝ w (X ω))
  have hP_meas : Measurable P := measurable_profile_score hX h_opt.1 w
  have hQ_meas : Measurable Q := measurable_profile_score hX hρ' w
  have hP_mem : ∀ ω, P ω ∈ Set.Icc (0 : ℝ) 1 := fun _ => h_opt.1.2.2 _
  have hQ_mem : ∀ ω, Q ω ∈ Set.Icc (0 : ℝ) 1 := fun _ => hρ'.2.2 _
  have hg1_int : MeasureTheory.Integrable (fun ω => fitRes P Y ω * (Q ω - P ω)) μ := by
    refine integrable_of_measurable_abs_le μ
      ((hP_meas.sub (measurable_yReal hY)).mul (hQ_meas.sub hP_meas)) 1 ?_
    intro ω
    rw [abs_mul]
    have h1 : |fitRes P Y ω| ≤ 1 := abs_fitRes_le_one hP_mem Y ω
    have h2 : |Q ω - P ω| ≤ 1 := abs_sub_le_one_of_mem_Icc (hQ_mem ω) (hP_mem ω)
    nlinarith [abs_nonneg (fitRes P Y ω), abs_nonneg (Q ω - P ω)]
  have hg2_int : MeasureTheory.Integrable (fun ω => (Q ω - P ω) ^ 2) μ := by
    refine integrable_of_measurable_abs_le μ ((hQ_meas.sub hP_meas).pow_const 2) 1 ?_
    intro ω
    rw [abs_of_nonneg (sq_nonneg _)]
    exact sq_le_one_of_abs_le_one (abs_sub_le_one_of_mem_Icc (hQ_mem ω) (hP_mem ω))
  let A : ℝ := ∫ ω, fitRes P Y ω * (Q ω - P ω) ∂μ
  let B : ℝ := ∫ ω, (Q ω - P ω) ^ 2 ∂μ
  have h_quad : ∀ {t : ℝ}, 0 ≤ t → t ≤ 1 → 0 ≤ (2 * t) * A + t ^ 2 * B := by
    intro t ht0 ht1
    let ρ_t : ℝ → ℝ := fun x => (1 - t) * ρ x + t * ρ' x
    have hρ_t : IsProfile β ρ_t := IsProfile.convex_comb hβ.le h_opt.1 hρ' ht0 ht1
    have h_min : fitRisk μ X Y w ρ ≤ fitRisk μ X Y w ρ_t := h_opt.2 ρ_t hρ_t
    have hf0_int := integrable_fitRisk_integrand μ hX hY h_opt.1 w
    have hft_int := integrable_fitRisk_integrand μ hX hY hρ_t w
    have h_diff : fitRisk μ X Y w ρ_t - fitRisk μ X Y w ρ = (2 * t) * A + t ^ 2 * B := by
      unfold fitRisk
      rw [← MeasureTheory.integral_sub hft_int hf0_int]
      have h_pt : (fun ω => (ρ_t (inner ℝ w (X ω)) - yReal (Y ω)) ^ 2 -
          (ρ (inner ℝ w (X ω)) - yReal (Y ω)) ^ 2) =
          (fun ω => (2 * t) * (fitRes P Y ω * (Q ω - P ω)) + t ^ 2 * (Q ω - P ω) ^ 2) := by
        ext ω
        dsimp [ρ_t, P, Q, fitRes]
        ring
      rw [h_pt, MeasureTheory.integral_add (hg1_int.const_mul (2 * t)) (hg2_int.const_mul (t ^ 2)),
        MeasureTheory.integral_const_mul, MeasureTheory.integral_const_mul]
    linarith
  have hA : 0 ≤ A := by
    by_contra hA_neg
    push_neg at hA_neg
    have hdenom : 0 < |B| + 1 := by positivity
    let t : ℝ := min 1 (-A / (|B| + 1))
    have ht0 : 0 < t := lt_min zero_lt_one (div_pos (by linarith) hdenom)
    have ht1 : t ≤ 1 := min_le_left _ _
    have ht_bound : t ≤ -A / (|B| + 1) := min_le_right _ _
    have ht_mul : t * (|B| + 1) ≤ -A := (le_div_iff₀ hdenom).mp ht_bound
    have htB : t * B ≤ -A := by
      have hB_le : B ≤ |B| + 1 := by linarith [le_abs_self B]
      have h1 : t * B ≤ t * (|B| + 1) := mul_le_mul_of_nonneg_left hB_le ht0.le
      linarith
    have h_neg : (2 * t) * A + t ^ 2 * B < 0 := by
      have heq : (2 * t) * A + t ^ 2 * B = t * (2 * A + t * B) := by ring
      rw [heq]
      exact mul_neg_of_pos_of_neg ht0 (by linarith)
    linarith [h_quad ht0.le ht1]
  refine ⟨hA, ?_⟩
  have hf0_int := integrable_fitRisk_integrand μ hX hY h_opt.1 w
  have hf1_int := integrable_fitRisk_integrand μ hX hY hρ' w
  have h_gap_eq : fitRisk μ X Y w ρ' - fitRisk μ X Y w ρ = 2 * A + B := by
    unfold fitRisk
    rw [← MeasureTheory.integral_sub hf1_int hf0_int]
    have h_pt : (fun ω => (ρ' (inner ℝ w (X ω)) - yReal (Y ω)) ^ 2 -
        (ρ (inner ℝ w (X ω)) - yReal (Y ω)) ^ 2) =
        (fun ω => 2 * (fitRes P Y ω * (Q ω - P ω)) + (Q ω - P ω) ^ 2) := by
      ext ω
      dsimp [P, Q, fitRes]
      ring
    rw [h_pt, MeasureTheory.integral_add (hg1_int.const_mul 2) hg2_int,
      MeasureTheory.integral_const_mul]
  dsimp [B] at h_gap_eq
  linarith

private lemma integrable_drift_integrand {d : ℕ} {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω)
    {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin 2}
    (hX_meas : Measurable X) (hY_meas : Measurable Y)
    (hX_int : MeasureTheory.Integrable (fun ω => ‖X ω‖) μ)
    {β : ℝ} {ρ : ℝ → ℝ} (hρ : IsProfile β ρ) (w : EuclideanSpace ℝ (Fin d)) :
    MeasureTheory.Integrable
      (fun ω => (ρ (inner ℝ w (X ω)) - yReal (Y ω)) • X ω) μ := by
  have hc_meas : Measurable (fun ω => ρ (inner ℝ w (X ω)) - yReal (Y ω)) :=
    (measurable_profile_score hX_meas hρ w).sub (measurable_yReal hY_meas)
  refine hX_int.mono' (hc_meas.smul hX_meas).aestronglyMeasurable
    (Filter.Eventually.of_forall fun ω => ?_)
  rw [norm_smul, Real.norm_eq_abs]
  have habs : |ρ (inner ℝ w (X ω)) - yReal (Y ω)| ≤ 1 :=
    abs_sub_le_one_of_mem_Icc (hρ.2.2 _) (yReal_mem_Icc (Y ω))
  calc
    |ρ (inner ℝ w (X ω)) - yReal (Y ω)| * ‖X ω‖ ≤ 1 * ‖X ω‖ :=
      mul_le_mul_of_nonneg_right habs (norm_nonneg _)
    _ = ‖X ω‖ := one_mul _

theorem exists_optProfile_and_continuous_drift
    (d : ℕ) (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin 2)
    (hX_meas : Measurable X) (hY_meas : Measurable Y)
    (β : ℝ) (hβ : 0 < β)
    (hX_int : MeasureTheory.Integrable (fun ω => ‖X ω‖) μ) :
    ∃ ρ_fam : EuclideanSpace ℝ (Fin d) → (ℝ → ℝ),
      (∀ w : EuclideanSpace ℝ (Fin d), IsOptProfile μ β X Y w (ρ_fam w)) ∧
      (∀ (w : EuclideanSpace ℝ (Fin d)) (ρ' : ℝ → ℝ),
        IsProfile β ρ' →
        0 ≤ ∫ ω, fitRes (fun ω' => ρ_fam w (inner ℝ w (X ω'))) Y ω *
          (ρ' (inner ℝ w (X ω)) - ρ_fam w (inner ℝ w (X ω))) ∂μ) ∧
      (∀ w : EuclideanSpace ℝ (Fin d),
        MeasureTheory.Integrable
          (fun ω => (ρ_fam w (inner ℝ w (X ω)) - yReal (Y ω)) • X ω) μ) ∧
      Continuous (fun w : EuclideanSpace ℝ (Fin d) =>
        ∫ ω, (ρ_fam w (inner ℝ w (X ω)) - yReal (Y ω)) • X ω ∂μ) := by
  let ρ_fam : EuclideanSpace ℝ (Fin d) → (ℝ → ℝ) :=
    fun w => Classical.choose (exists_optProfile μ hX_meas hY_meas hβ w)
  have h_opt : ∀ w : EuclideanSpace ℝ (Fin d), IsOptProfile μ β X Y w (ρ_fam w) :=
    fun w => Classical.choose_spec (exists_optProfile μ hX_meas hY_meas hβ w)
  have h_drift_int : ∀ w : EuclideanSpace ℝ (Fin d),
      MeasureTheory.Integrable
        (fun ω => (ρ_fam w (inner ℝ w (X ω)) - yReal (Y ω)) • X ω) μ :=
    fun w => integrable_drift_integrand μ hX_meas hY_meas hX_int (h_opt w).1 w
  refine ⟨ρ_fam, h_opt,
    fun w ρ' hρ' => (optProfile_vi_and_gap μ hX_meas hY_meas hβ (h_opt w) hρ').1,
    h_drift_int, ?_⟩
  let g : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d) :=
    fun w => ∫ ω, (ρ_fam w (inner ℝ w (X ω)) - yReal (Y ω)) • X ω ∂μ
  change Continuous g
  refine SeqContinuous.continuous ?_
  intro w_seq w hw
  change Filter.Tendsto (fun n => g (w_seq n)) Filter.atTop (nhds (g w))
  refine Filter.tendsto_of_subseq_tendsto fun ns hns => ?_
  obtain ⟨ρ_lim, φ, hφ_mono, hρ_lim, _, h_diag⟩ :=
    isProfile_seqCompact hβ (fun n => ρ_fam (w_seq (ns n))) (fun n => (h_opt (w_seq (ns n))).1)
  let u : ℕ → EuclideanSpace ℝ (Fin d) := fun k => w_seq (ns (φ k))
  have hu : Filter.Tendsto u Filter.atTop (nhds w) :=
    hw.comp (hns.comp hφ_mono.tendsto_atTop)
  have hu_score : ∀ ω : Ω,
      Filter.Tendsto (fun k => inner ℝ (u k) (X ω)) Filter.atTop (nhds (inner ℝ w (X ω))) :=
    fun ω => hu.inner tendsto_const_nhds
  have hu_pred : ∀ ω : Ω,
      Filter.Tendsto (fun k => ρ_fam (u k) (inner ℝ (u k) (X ω)))
        Filter.atTop (nhds (ρ_lim (inner ℝ w (X ω)))) :=
    fun ω => h_diag (fun k => inner ℝ (u k) (X ω)) (inner ℝ w (X ω)) (hu_score ω)
  have hw_pred : ∀ ω : Ω,
      Filter.Tendsto (fun k => ρ_fam w (inner ℝ (u k) (X ω)))
        Filter.atTop (nhds (ρ_fam w (inner ℝ w (X ω)))) :=
    fun ω => ((h_opt w).1.continuous.tendsto (inner ℝ w (X ω))).comp (hu_score ω)
  have h_risk_u : Filter.Tendsto (fun k => fitRisk μ X Y (u k) (ρ_fam (u k)))
      Filter.atTop (nhds (fitRisk μ X Y w ρ_lim)) :=
    tendsto_fitRisk μ hX_meas hY_meas (fun k => (h_opt (u k)).1) hu_pred
  have h_risk_w : Filter.Tendsto (fun k => fitRisk μ X Y (u k) (ρ_fam w))
      Filter.atTop (nhds (fitRisk μ X Y w (ρ_fam w))) :=
    tendsto_fitRisk μ hX_meas hY_meas (fun _ => (h_opt w).1) hw_pred
  have h_risk_le : fitRisk μ X Y w ρ_lim ≤ fitRisk μ X Y w (ρ_fam w) :=
    le_of_tendsto_of_tendsto h_risk_u h_risk_w
      (Filter.Eventually.of_forall fun k => (h_opt (u k)).2 (ρ_fam w) (h_opt w).1)
  have h_gap := (optProfile_vi_and_gap μ hX_meas hY_meas hβ (h_opt w) hρ_lim).2
  have h_sq_nonneg : 0 ≤ ∫ ω, (ρ_lim (inner ℝ w (X ω)) - ρ_fam w (inner ℝ w (X ω))) ^ 2 ∂μ :=
    MeasureTheory.integral_nonneg (fun _ => sq_nonneg _)
  have h_sq_zero : ∫ ω, (ρ_lim (inner ℝ w (X ω)) - ρ_fam w (inner ℝ w (X ω))) ^ 2 ∂μ = 0 :=
    le_antisymm (by linarith) h_sq_nonneg
  have h_sq_int : MeasureTheory.Integrable
      (fun ω => (ρ_lim (inner ℝ w (X ω)) - ρ_fam w (inner ℝ w (X ω))) ^ 2) μ := by
    refine integrable_of_measurable_abs_le μ
      (((measurable_profile_score hX_meas hρ_lim w).sub
        (measurable_profile_score hX_meas (h_opt w).1 w)).pow_const 2) 1 ?_
    intro ω
    rw [abs_of_nonneg (sq_nonneg _)]
    exact sq_le_one_of_abs_le_one
      (abs_sub_le_one_of_mem_Icc (hρ_lim.2.2 _) ((h_opt w).1.2.2 _))
  have h_ae_sq_zero :
      (fun ω => (ρ_lim (inner ℝ w (X ω)) - ρ_fam w (inner ℝ w (X ω))) ^ 2) =ᵐ[μ] 0 :=
    (MeasureTheory.integral_eq_zero_iff_of_nonneg (fun _ => sq_nonneg _) h_sq_int).mp h_sq_zero
  have h_ae_eq : ∀ᵐ ω ∂μ, ρ_lim (inner ℝ w (X ω)) = ρ_fam w (inner ℝ w (X ω)) := by
    refine h_ae_sq_zero.mono fun ω hω => ?_
    exact sub_eq_zero.mp (sq_eq_zero_iff.mp hω)
  refine ⟨φ, ?_⟩
  dsimp [g]
  refine MeasureTheory.tendsto_integral_of_dominated_convergence (fun ω => ‖X ω‖)
    (fun k => (h_drift_int (u k)).aestronglyMeasurable) hX_int ?_ ?_
  · intro k
    refine Filter.Eventually.of_forall fun ω => ?_
    rw [norm_smul, Real.norm_eq_abs]
    have habs : |ρ_fam (u k) (inner ℝ (u k) (X ω)) - yReal (Y ω)| ≤ 1 :=
      abs_sub_le_one_of_mem_Icc ((h_opt (u k)).1.2.2 _) (yReal_mem_Icc (Y ω))
    calc
      |ρ_fam (u k) (inner ℝ (u k) (X ω)) - yReal (Y ω)| * ‖X ω‖ ≤ 1 * ‖X ω‖ :=
        mul_le_mul_of_nonneg_right habs (norm_nonneg _)
      _ = ‖X ω‖ := one_mul _
  · refine h_ae_eq.mono fun ω hω => ?_
    have h_lim_u : Filter.Tendsto (fun k => ρ_fam (u k) (inner ℝ (u k) (X ω)))
        Filter.atTop (nhds (ρ_fam w (inner ℝ w (X ω)))) := by
      simpa [hω] using hu_pred ω
    exact (h_lim_u.sub tendsto_const_nhds).smul tendsto_const_nhds

end UL.Proof_thm_3_2

import UL.Proof.thm_3_2.H0_Defs
import UL.Proof.cit_brouwer.H3_Projection
set_option autoImplicit false

namespace UL.Proof_thm_3_2

theorem choose_score {d : ℕ} (C : Set (EuclideanSpace ℝ (Fin d)))
    (hCne : C.Nonempty) (hCcomp : IsCompact C) (hCconv : Convex ℝ C)
    (g : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d)) (hg : Continuous g) :
    ∃ w ∈ C, ∀ v ∈ C, inner ℝ w (g w) ≤ inner ℝ v (g w) := by
  let E := EuclideanSpace ℝ (Fin d)
  obtain ⟨π, hπcont, hπvi⟩ :=
    UL.Proof_cit_brouwer.exists_metric_projection_on_compact_convex E C hCne hCcomp hCconv
  let f : C → C := fun x => π ((x : E) - g x)
  have hf : Continuous f :=
    hπcont.comp (continuous_subtype_val.sub (hg.comp continuous_subtype_val))
  obtain ⟨w, hfixed⟩ :=
    UL.Proof_cit_brouwer.brouwer_of_compact_convex E C hCne hCcomp hCconv f hf
  have hproj : (π ((w : E) - g w) : E) = (w : E) := congrArg Subtype.val hfixed
  refine ⟨w.1, w.2, ?_⟩
  intro v hv
  have h := hπvi ((w : E) - g w) v hv
  rw [hproj] at h
  have hstep : (w : E) - g w - w = -g w := by abel
  rw [hstep, inner_neg_left, inner_sub_right] at h
  simpa only [real_inner_comm (g w) v, real_inner_comm (g w) (w : E)]
    using (sub_nonneg.mp (neg_nonpos.mp h))

theorem exists_fixed_point_score
    (d : ℕ) (R : ℝ) (hR : 0 < R)
    (g : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d)) (hg : Continuous g) :
    ∃ w : EuclideanSpace ℝ (Fin d), ‖w‖ ≤ R ∧
      ∀ v : EuclideanSpace ℝ (Fin d), ‖v‖ ≤ R → inner ℝ w (g w) ≤ inner ℝ v (g w) := by
  simpa only [Metric.mem_closedBall, dist_zero_right] using
    choose_score (Metric.closedBall 0 R) ⟨0, Metric.mem_closedBall_self hR.le⟩
      (isCompact_closedBall _ _) (convex_closedBall _ _) g hg

lemma integrable_res_inner
    (d : ℕ) {Ω : Type*} [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    {X : Ω → EuclideanSpace ℝ (Fin d)} {Y : Ω → Fin 2}
    (hX_meas : Measurable X) (hY_meas : Measurable Y)
    (hX_int : MeasureTheory.Integrable (fun ω => ‖X ω‖) μ)
    {P : Ω → ℝ} (hP_meas : Measurable P) (hP_mem : ∀ ω : Ω, P ω ∈ Set.Icc (0 : ℝ) 1)
    (v : EuclideanSpace ℝ (Fin d)) :
    MeasureTheory.Integrable (fun ω => fitRes P Y ω * inner ℝ v (X ω)) μ := by
  have hSv_meas : Measurable (fun ω => inner ℝ v (X ω)) :=
    (continuous_const.inner continuous_id).measurable.comp hX_meas
  have hres_meas : Measurable (fun ω => fitRes P Y ω) :=
    hP_meas.sub (measurable_yReal hY_meas)
  refine (hX_int.const_mul ‖v‖).mono' (hres_meas.mul hSv_meas).aestronglyMeasurable ?_
  filter_upwards with ω
  rw [Real.norm_eq_abs, abs_mul]
  calc
    |fitRes P Y ω| * |inner ℝ v (X ω)|
      ≤ 1 * (‖v‖ * ‖X ω‖) := by
        gcongr
        · exact abs_fitRes_le_one hP_mem Y ω
        · exact abs_real_inner_le_norm v (X ω)
    _ = ‖v‖ * ‖X ω‖ := one_mul _

theorem inner_drift_eq
    (d : ℕ) (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin 2)
    (hX_meas : Measurable X) (hY_meas : Measurable Y)
    (hX_int : MeasureTheory.Integrable (fun ω => ‖X ω‖) μ)
    (P : Ω → ℝ) (hP_meas : Measurable P) (hP_mem : ∀ ω : Ω, P ω ∈ Set.Icc (0 : ℝ) 1)
    (v : EuclideanSpace ℝ (Fin d)) :
    inner ℝ v (∫ ω, (P ω - yReal (Y ω)) • X ω ∂μ) =
      ∫ ω, fitRes P Y ω * inner ℝ v (X ω) ∂μ := by
  have h_int_vec : MeasureTheory.Integrable (fun ω => (P ω - yReal (Y ω)) • X ω) μ := by
    refine hX_int.mono' ((hP_meas.sub (measurable_yReal hY_meas)).smul hX_meas).aestronglyMeasurable ?_
    filter_upwards with ω
    rw [norm_smul, Real.norm_eq_abs]
    simpa only [one_mul] using
      mul_le_mul_of_nonneg_right (abs_fitRes_le_one hP_mem Y ω) (norm_nonneg (X ω))
  simpa only [innerSL_apply, inner_smul_right, fitRes] using
    ((innerSL ℝ v).integral_comp_comm h_int_vec).symm

private lemma bddAbove_potential_integrand
    {φ : Set.Icc (0 : ℝ) 1 → ℝ} (hφ : Continuous φ) (a : ℝ) :
    BddAbove (Set.range (fun q : Set.Icc (0 : ℝ) 1 => (q : ℝ) * a - φ q)) := by
  have hc : Continuous (fun q : Set.Icc (0 : ℝ) 1 => (q : ℝ) * a - φ q) :=
    (continuous_subtype_val.mul continuous_const).sub hφ
  exact (isCompact_range hc).bddAbove

lemma fenchel_binaryMatchingLoss
    {φ : Set.Icc (0 : ℝ) 1 → ℝ} (hφ : Continuous φ)
    (q : Set.Icc (0 : ℝ) 1) (a : ℝ) (y : Fin 2) :
    -φ q + ((q : ℝ) - yReal y) * a ≤ binaryMatchingLoss φ a y := by
  have hle : (q : ℝ) * a - φ q ≤ binaryMatchingPotential φ a :=
    le_ciSup (bddAbove_potential_integrand hφ a) q
  unfold binaryMatchingLoss yReal
  linarith

private lemma abs_binaryMatchingPotential_sub_le
    {φ : Set.Icc (0 : ℝ) 1 → ℝ} (hφ : Continuous φ) (a₁ a₂ : ℝ) :
    |binaryMatchingPotential φ a₁ - binaryMatchingPotential φ a₂| ≤ |a₁ - a₂| := by
  haveI : Nonempty (Set.Icc (0 : ℝ) 1) := ⟨⟨0, Set.left_mem_Icc.mpr zero_le_one⟩⟩
  have hbound : ∀ b₁ b₂ : ℝ,
      binaryMatchingPotential φ b₁ ≤ binaryMatchingPotential φ b₂ + |b₁ - b₂| := by
    intro b₁ b₂
    unfold binaryMatchingPotential
    refine ciSup_le fun q => ?_
    have hq2 : (q : ℝ) * b₂ - φ q ≤ ⨆ q' : Set.Icc (0 : ℝ) 1, ((q' : ℝ) * b₂ - φ q') :=
      le_ciSup (bddAbove_potential_integrand hφ b₂) q
    have hq_diff : (q : ℝ) * (b₁ - b₂) ≤ |b₁ - b₂| := by
      calc
        (q : ℝ) * (b₁ - b₂) ≤ |(q : ℝ) * (b₁ - b₂)| := le_abs_self _
        _ = (q : ℝ) * |b₁ - b₂| := by rw [abs_mul, abs_of_nonneg q.2.1]
        _ ≤ 1 * |b₁ - b₂| := mul_le_mul_of_nonneg_right q.2.2 (abs_nonneg _)
        _ = |b₁ - b₂| := one_mul _
    linarith
  have h1 := hbound a₁ a₂
  have h2 := hbound a₂ a₁
  rw [abs_sub_comm a₂ a₁] at h2
  rw [abs_le]
  exact ⟨by linarith, by linarith⟩

lemma continuous_binaryMatchingPotential
    {φ : Set.Icc (0 : ℝ) 1 → ℝ} (hφ : Continuous φ) :
    Continuous (binaryMatchingPotential φ) := by
  have hlip : LipschitzWith 1 (binaryMatchingPotential φ) := by
    rw [lipschitzWith_iff_dist_le_mul]
    intro x y
    simpa [Real.dist_eq] using abs_binaryMatchingPotential_sub_le hφ x y
  exact hlip.continuous

private lemma canonicalLoss_pointwise
    {β : ℝ} (hβ : 0 < β)
    {φ : Set.Icc (0 : ℝ) 1 → ℝ}
    (hφ_diff : ∀ q ∈ Set.Ioo (0 : ℝ) 1, DifferentiableAt ℝ (extendUnitInterval φ) q)
    (F : ℝ → ℝ)
    (hF_def : F = fun q => extendUnitInterval φ q - (1 / (2 * β)) * q ^ 2)
    (p : ℝ) (hp_mem : p ∈ Set.Icc (0 : ℝ) 1) (y : Fin 2)
    (hend : (p = 0 → y = 0) ∧ (p = 1 → y = 1)) :
    (binaryExtendedCanonicalLoss φ p y ≠ ⊥ ∧ binaryExtendedCanonicalLoss φ p y ≠ ⊤) ∧
    (binaryExtendedCanonicalLoss φ p y).toReal =
      -φ ⟨p, hp_mem⟩ +
        (if p ∈ Set.Ioo (0 : ℝ) 1 then (p - yReal y) * deriv F p else 0) +
        (1 / β) * ((p - yReal y) * p) := by
  rcases eq_or_lt_of_le hp_mem.1 with hp0 | hp0
  · have hp0' : p = 0 := hp0.symm
    have hy0 : y = 0 := hend.1 hp0'
    have hnot_ioo : p ∉ Set.Ioo (0 : ℝ) 1 := by simp [hp0']
    have hval : binaryExtendedCanonicalLoss φ p y =
        ((-φ ⟨0, Set.left_mem_Icc.mpr zero_le_one⟩ : ℝ) : EReal) := by
      unfold binaryExtendedCanonicalLoss
      rw [dif_neg hnot_ioo, if_pos ⟨hp0', hy0⟩]
    rw [hval]
    refine ⟨⟨EReal.coe_ne_bot _, EReal.coe_ne_top _⟩, ?_⟩
    rw [EReal.toReal_coe, if_neg hnot_ioo]
    have hsub : (⟨p, hp_mem⟩ : Set.Icc (0 : ℝ) 1) = ⟨0, Set.left_mem_Icc.mpr zero_le_one⟩ := by
      ext
      exact hp0'
    have hyr : yReal y = 0 := by simp [hy0, yReal]
    rw [hsub, hp0', hyr]
    ring
  · rcases lt_or_eq_of_le hp_mem.2 with hp1 | hp1
    · have hioo : p ∈ Set.Ioo (0 : ℝ) 1 := ⟨hp0, hp1⟩
      have hval : binaryExtendedCanonicalLoss φ p y =
          (((-φ ⟨p, hp_mem⟩ + deriv (extendUnitInterval φ) p * (p - (y.val : ℝ))) : ℝ) : EReal) := by
        unfold binaryExtendedCanonicalLoss
        rw [dif_pos hioo]
      rw [hval]
      refine ⟨⟨EReal.coe_ne_bot _, EReal.coe_ne_top _⟩, ?_⟩
      rw [EReal.toReal_coe, if_pos hioo]
      have hquad : HasDerivAt (fun x : ℝ => (1 / (2 * β)) * x ^ 2) (p / β) p := by
        have hpow : HasDerivAt (fun x : ℝ => x ^ 2) (2 * p ^ 1) p := hasDerivAt_pow 2 p
        have hmul := hpow.const_mul (1 / (2 * β))
        convert hmul using 1
        field_simp [hβ.ne']
      have hderivF : deriv F p = deriv (extendUnitInterval φ) p - p / β := by
        rw [hF_def]
        exact ((hφ_diff p hioo).hasDerivAt.sub hquad).deriv
      rw [hderivF]
      unfold yReal
      field_simp [hβ.ne']
      ring
    · have hy1 : y = 1 := hend.2 hp1
      have hnot_ioo : p ∉ Set.Ioo (0 : ℝ) 1 := by simp [hp1]
      have hnot_0 : ¬(p = 0 ∧ y = 0) := by
        rw [hp1]
        norm_num
      have hval : binaryExtendedCanonicalLoss φ p y =
          ((-φ ⟨1, Set.right_mem_Icc.mpr zero_le_one⟩ : ℝ) : EReal) := by
        unfold binaryExtendedCanonicalLoss
        rw [dif_neg hnot_ioo, if_neg hnot_0, if_pos ⟨hp1, hy1⟩]
      rw [hval]
      refine ⟨⟨EReal.coe_ne_bot _, EReal.coe_ne_top _⟩, ?_⟩
      rw [EReal.toReal_coe, if_neg hnot_ioo]
      have hsub : (⟨p, hp_mem⟩ : Set.Icc (0 : ℝ) 1) = ⟨1, Set.right_mem_Icc.mpr zero_le_one⟩ := by
        ext
        exact hp1
      have hyr : yReal y = 1 := by simp [hy1, yReal]
      rw [hsub, hp1, hyr]
      ring

theorem entropy_loss_comparison_on_weights
    (d : ℕ) (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin 2)
    (hX_meas : Measurable X) (hY_meas : Measurable Y)
    (C : Set (EuclideanSpace ℝ (Fin d))) (hC : C.Nonempty)
    (β : ℝ) (hβ : 0 < β)
    (hX_int : MeasureTheory.Integrable (fun ω => ‖X ω‖) μ)
    (w : EuclideanSpace ℝ (Fin d))
    (P : Ω → ℝ) (hP_meas : Measurable P) (hP_mem : ∀ ω : Ω, P ω ∈ Set.Icc (0 : ℝ) 1)
    (h_end : ∀ᵐ ω ∂μ, (P ω = 0 → Y ω = 0) ∧ (P ω = 1 → Y ω = 1))
    (h_own : ∫ ω, fitRes P Y ω * P ω ∂μ ≤ β * ∫ ω, fitRes P Y ω * inner ℝ w (X ω) ∂μ)
    (h_fp : ∀ v : EuclideanSpace ℝ (Fin d), v ∈ C →
      ∫ ω, fitRes P Y ω * inner ℝ w (X ω) ∂μ ≤ ∫ ω, fitRes P Y ω * inner ℝ v (X ω) ∂μ)
    (h_conv_test : ∀ F : ℝ → ℝ,
      ContinuousOn F (Set.Icc (0 : ℝ) 1) →
      ConvexOn ℝ (Set.Icc (0 : ℝ) 1) F →
      (∀ q ∈ Set.Ioo (0 : ℝ) 1, DifferentiableAt ℝ F q) →
      MeasureTheory.Integrable
        (fun ω => if P ω ∈ Set.Ioo (0 : ℝ) 1 then fitRes P Y ω * deriv F (P ω) else 0) μ ∧
      (∫ ω, (if P ω ∈ Set.Ioo (0 : ℝ) 1 then fitRes P Y ω * deriv F (P ω) else 0) ∂μ) ≤ 0) :
    ∀ φ ∈ BinaryEntropyFamily β,
      (∀ᵐ ω ∂μ,
        binaryExtendedCanonicalLoss φ (P ω) (Y ω) ≠ ⊥ ∧
        binaryExtendedCanonicalLoss φ (P ω) (Y ω) ≠ ⊤) ∧
      MeasureTheory.Integrable
        (fun ω => (binaryExtendedCanonicalLoss φ (P ω) (Y ω)).toReal) μ ∧
      (∀ v : EuclideanSpace ℝ (Fin d), v ∈ C →
        MeasureTheory.Integrable
          (fun ω => binaryMatchingLoss φ (inner ℝ v (X ω)) (Y ω)) μ) ∧
      BddBelow ((fun v : EuclideanSpace ℝ (Fin d) =>
        ∫ ω, binaryMatchingLoss φ (inner ℝ v (X ω)) (Y ω) ∂μ) '' C) ∧
      (∫ ω, (binaryExtendedCanonicalLoss φ (P ω) (Y ω)).toReal ∂μ) ≤
        sInf ((fun v : EuclideanSpace ℝ (Fin d) =>
          ∫ ω, binaryMatchingLoss φ (inner ℝ v (X ω)) (Y ω) ∂μ) '' C) := by
  intro φ hφ
  obtain ⟨_, hφ_cont, hφ_diff, hφ_conv⟩ := hφ
  let F : ℝ → ℝ := fun q => extendUnitInterval φ q - (1 / (2 * β)) * q ^ 2
  have h_ext_cont : ContinuousOn (extendUnitInterval φ) (Set.Icc (0 : ℝ) 1) := by
    rw [continuousOn_iff_continuous_restrict]
    have hrest : (Set.Icc (0 : ℝ) 1).restrict (extendUnitInterval φ) = φ := by
      ext q
      unfold extendUnitInterval
      exact dif_pos q.2
    rw [hrest]
    exact hφ_cont
  have hF_cont : ContinuousOn F (Set.Icc (0 : ℝ) 1) :=
    h_ext_cont.sub (continuous_const.mul (continuous_pow 2)).continuousOn
  have hF_diff : ∀ q ∈ Set.Ioo (0 : ℝ) 1, DifferentiableAt ℝ F q := by
    intro q hq
    exact (hφ_diff q hq).sub
      ((differentiableAt_pow 2).const_mul (1 / (2 * β)))
  obtain ⟨hF_int, hF_le⟩ := h_conv_test F hF_cont hφ_conv hF_diff
  have hφP_meas : Measurable (fun ω => φ ⟨P ω, hP_mem ω⟩) :=
    hφ_cont.measurable.comp (hP_meas.subtype_mk)
  obtain ⟨C_φ, hC_φ⟩ := isCompact_univ.exists_bound_of_continuousOn hφ_cont.continuousOn
  have hφP_int : MeasureTheory.Integrable (fun ω => φ ⟨P ω, hP_mem ω⟩) μ := by
    refine MeasureTheory.Integrable.of_bound hφP_meas.aestronglyMeasurable C_φ ?_
    filter_upwards with ω
    exact hC_φ ⟨P ω, hP_mem ω⟩ (Set.mem_univ _)
  have hrP_int : MeasureTheory.Integrable (fun ω => fitRes P Y ω * P ω) μ := by
    have hm : Measurable (fun ω => fitRes P Y ω * P ω) :=
      (hP_meas.sub (measurable_yReal hY_meas)).mul hP_meas
    refine MeasureTheory.Integrable.of_bound hm.aestronglyMeasurable 1 ?_
    filter_upwards with ω
    rw [Real.norm_eq_abs, abs_mul]
    calc
      |fitRes P Y ω| * |P ω| ≤ 1 * 1 := by
        gcongr
        · exact abs_fitRes_le_one hP_mem Y ω
        · rw [abs_of_nonneg (hP_mem ω).1]
          exact (hP_mem ω).2
      _ = 1 := one_mul 1
  let L_rhs : Ω → ℝ := fun ω =>
    -φ ⟨P ω, hP_mem ω⟩ +
      (if P ω ∈ Set.Ioo (0 : ℝ) 1 then fitRes P Y ω * deriv F (P ω) else 0) +
      (1 / β) * (fitRes P Y ω * P ω)
  have hL_rhs_int : MeasureTheory.Integrable L_rhs μ :=
    (hφP_int.neg.add hF_int).add (hrP_int.const_mul (1 / β))
  have h_ae_both : ∀ᵐ ω ∂μ,
      (binaryExtendedCanonicalLoss φ (P ω) (Y ω) ≠ ⊥ ∧
        binaryExtendedCanonicalLoss φ (P ω) (Y ω) ≠ ⊤) ∧
      (binaryExtendedCanonicalLoss φ (P ω) (Y ω)).toReal = L_rhs ω := by
    filter_upwards [h_end] with ω hω
    exact canonicalLoss_pointwise hβ hφ_diff F rfl (P ω) (hP_mem ω) (Y ω) hω
  have h_ae_fin : ∀ᵐ ω ∂μ,
      binaryExtendedCanonicalLoss φ (P ω) (Y ω) ≠ ⊥ ∧
      binaryExtendedCanonicalLoss φ (P ω) (Y ω) ≠ ⊤ :=
    h_ae_both.mono fun _ h => h.1
  have h_ae_eq : (fun ω => (binaryExtendedCanonicalLoss φ (P ω) (Y ω)).toReal) =ᵐ[μ] L_rhs :=
    h_ae_both.mono fun _ h => h.2
  have hL_int : MeasureTheory.Integrable
      (fun ω => (binaryExtendedCanonicalLoss φ (P ω) (Y ω)).toReal) μ :=
    hL_rhs_int.congr h_ae_eq.symm
  have h_match_int : ∀ v : EuclideanSpace ℝ (Fin d),
      MeasureTheory.Integrable (fun ω => binaryMatchingLoss φ (inner ℝ v (X ω)) (Y ω)) μ := by
    intro v
    have hSv_meas : Measurable (fun ω => inner ℝ v (X ω)) :=
      (continuous_const.inner continuous_id).measurable.comp hX_meas
    have hm : Measurable (fun ω => binaryMatchingLoss φ (inner ℝ v (X ω)) (Y ω)) := by
      unfold binaryMatchingLoss
      exact ((continuous_binaryMatchingPotential hφ_cont).measurable.comp hSv_meas).sub
        ((measurable_yReal hY_meas).mul hSv_meas)
    let c0 : ℝ := |binaryMatchingPotential φ 0|
    have hdom : MeasureTheory.Integrable (fun ω => c0 + 2 * ‖v‖ * ‖X ω‖) μ :=
      (MeasureTheory.integrable_const c0).add (hX_int.const_mul (2 * ‖v‖))
    refine hdom.mono' hm.aestronglyMeasurable ?_
    filter_upwards with ω
    rw [Real.norm_eq_abs]
    let a := inner ℝ v (X ω)
    have hpot : |binaryMatchingPotential φ a| ≤ c0 + |a| := by
      have hlip := abs_binaryMatchingPotential_sub_le hφ_cont a 0
      simp only [sub_zero] at hlip
      have htri : |binaryMatchingPotential φ a| ≤
          |binaryMatchingPotential φ a - binaryMatchingPotential φ 0| +
            |binaryMatchingPotential φ 0| := by
        simpa using abs_add_le (binaryMatchingPotential φ a - binaryMatchingPotential φ 0)
          (binaryMatchingPotential φ 0)
      dsimp [c0]
      linarith
    have hy_le : |(Y ω).val * a| ≤ |a| := by
      change |yReal (Y ω) * a| ≤ |a|
      rw [abs_mul, abs_of_nonneg (yReal_mem_Icc (Y ω)).1]
      calc
        yReal (Y ω) * |a| ≤ 1 * |a| :=
          mul_le_mul_of_nonneg_right (yReal_mem_Icc (Y ω)).2 (abs_nonneg a)
        _ = |a| := one_mul _
    have ha_le : |a| ≤ ‖v‖ * ‖X ω‖ := abs_real_inner_le_norm v (X ω)
    unfold binaryMatchingLoss
    have hsub_abs : |binaryMatchingPotential φ a - (Y ω).val * a| ≤
        |binaryMatchingPotential φ a| + |(Y ω).val * a| := abs_sub _ _
    linarith
  have h_upper : (∫ ω, (binaryExtendedCanonicalLoss φ (P ω) (Y ω)).toReal ∂μ) ≤
      -(∫ ω, φ ⟨P ω, hP_mem ω⟩ ∂μ) +
        (1 / β) * ∫ ω, fitRes P Y ω * P ω ∂μ := by
    rw [MeasureTheory.integral_congr_ae h_ae_eq]
    have h1 : ∫ ω, L_rhs ω ∂μ =
        (∫ ω, (-φ ⟨P ω, hP_mem ω⟩ +
          (if P ω ∈ Set.Ioo (0 : ℝ) 1 then fitRes P Y ω * deriv F (P ω) else 0)) ∂μ) +
        ∫ ω, (1 / β) * (fitRes P Y ω * P ω) ∂μ :=
      MeasureTheory.integral_add (hφP_int.neg.add hF_int) (hrP_int.const_mul (1 / β))
    have h2 : ∫ ω, (-φ ⟨P ω, hP_mem ω⟩ +
          (if P ω ∈ Set.Ioo (0 : ℝ) 1 then fitRes P Y ω * deriv F (P ω) else 0)) ∂μ =
        (∫ ω, -φ ⟨P ω, hP_mem ω⟩ ∂μ) +
          ∫ ω, (if P ω ∈ Set.Ioo (0 : ℝ) 1 then fitRes P Y ω * deriv F (P ω) else 0) ∂μ :=
      MeasureTheory.integral_add hφP_int.neg hF_int
    rw [h1, h2, MeasureTheory.integral_neg, MeasureTheory.integral_const_mul]
    linarith
  let risks := (fun v : EuclideanSpace ℝ (Fin d) =>
    ∫ ω, binaryMatchingLoss φ (inner ℝ v (X ω)) (Y ω) ∂μ) '' C
  have h_lower : (∫ ω, (binaryExtendedCanonicalLoss φ (P ω) (Y ω)).toReal ∂μ) ∈
      lowerBounds risks := by
    rintro _ ⟨v, hv, rfl⟩
    have h_score_lb : (1 / β) * ∫ ω, fitRes P Y ω * P ω ∂μ ≤
        ∫ ω, fitRes P Y ω * inner ℝ v (X ω) ∂μ := by
      have hwv := h_fp v hv
      have hdiv : (1 / β) * ∫ ω, fitRes P Y ω * P ω ∂μ ≤
          ∫ ω, fitRes P Y ω * inner ℝ w (X ω) ∂μ := by
        rw [one_div, inv_mul_le_iff₀ hβ]
        linarith
      exact le_trans hdiv hwv
    have h_fenchel_int : -(∫ ω, φ ⟨P ω, hP_mem ω⟩ ∂μ) +
          (∫ ω, fitRes P Y ω * inner ℝ v (X ω) ∂μ) ≤
        ∫ ω, binaryMatchingLoss φ (inner ℝ v (X ω)) (Y ω) ∂μ := by
      have hrv_int := integrable_res_inner d μ hX_meas hY_meas hX_int hP_meas hP_mem v
      have hneg_int : MeasureTheory.Integrable (fun ω => -φ ⟨P ω, hP_mem ω⟩) μ := hφP_int.neg
      have hsum_eq : -(∫ ω, φ ⟨P ω, hP_mem ω⟩ ∂μ) +
            (∫ ω, fitRes P Y ω * inner ℝ v (X ω) ∂μ) =
          ∫ ω, (-φ ⟨P ω, hP_mem ω⟩ + fitRes P Y ω * inner ℝ v (X ω)) ∂μ := by
        rw [MeasureTheory.integral_add hneg_int hrv_int, MeasureTheory.integral_neg]
      rw [hsum_eq]
      refine MeasureTheory.integral_mono (hneg_int.add hrv_int) (h_match_int v) fun ω => ?_
      exact fenchel_binaryMatchingLoss hφ_cont ⟨P ω, hP_mem ω⟩ (inner ℝ v (X ω)) (Y ω)
    linarith
  exact ⟨h_ae_fin, hL_int, fun v _ => h_match_int v, ⟨_, h_lower⟩,
    le_csInf (hC.image _) h_lower⟩

theorem entropy_loss_comparison
    (d : ℕ) (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin 2)
    (hX_meas : Measurable X) (hY_meas : Measurable Y)
    (R β : ℝ) (hR : 0 < R) (hβ : 0 < β)
    (hX_int : MeasureTheory.Integrable (fun ω => ‖X ω‖) μ)
    (w : EuclideanSpace ℝ (Fin d))
    (P : Ω → ℝ) (hP_meas : Measurable P) (hP_mem : ∀ ω : Ω, P ω ∈ Set.Icc (0 : ℝ) 1)
    (h_end : ∀ᵐ ω ∂μ, (P ω = 0 → Y ω = 0) ∧ (P ω = 1 → Y ω = 1))
    (h_own : ∫ ω, fitRes P Y ω * P ω ∂μ ≤ β * ∫ ω, fitRes P Y ω * inner ℝ w (X ω) ∂μ)
    (h_fp : ∀ v : EuclideanSpace ℝ (Fin d), ‖v‖ ≤ R →
      ∫ ω, fitRes P Y ω * inner ℝ w (X ω) ∂μ ≤ ∫ ω, fitRes P Y ω * inner ℝ v (X ω) ∂μ)
    (h_conv_test : ∀ F : ℝ → ℝ,
      ContinuousOn F (Set.Icc (0 : ℝ) 1) →
      ConvexOn ℝ (Set.Icc (0 : ℝ) 1) F →
      (∀ q ∈ Set.Ioo (0 : ℝ) 1, DifferentiableAt ℝ F q) →
      MeasureTheory.Integrable
        (fun ω => if P ω ∈ Set.Ioo (0 : ℝ) 1 then fitRes P Y ω * deriv F (P ω) else 0) μ ∧
      (∫ ω, (if P ω ∈ Set.Ioo (0 : ℝ) 1 then fitRes P Y ω * deriv F (P ω) else 0) ∂μ) ≤ 0) :
    ∀ φ ∈ BinaryEntropyFamily β,
      (∀ᵐ ω ∂μ,
        binaryExtendedCanonicalLoss φ (P ω) (Y ω) ≠ ⊥ ∧
        binaryExtendedCanonicalLoss φ (P ω) (Y ω) ≠ ⊤) ∧
      MeasureTheory.Integrable
        (fun ω => (binaryExtendedCanonicalLoss φ (P ω) (Y ω)).toReal) μ ∧
      (∀ v : EuclideanSpace ℝ (Fin d), ‖v‖ ≤ R →
        MeasureTheory.Integrable
          (fun ω => binaryMatchingLoss φ (inner ℝ v (X ω)) (Y ω)) μ) ∧
      (∫ ω, (binaryExtendedCanonicalLoss φ (P ω) (Y ω)).toReal ∂μ) ≤
        sInf ((fun v : EuclideanSpace ℝ (Fin d) =>
          ∫ ω, binaryMatchingLoss φ (inner ℝ v (X ω)) (Y ω) ∂μ) '' {v | ‖v‖ ≤ R}) := by
  intro φ hφ
  have hC : ({v : EuclideanSpace ℝ (Fin d) | ‖v‖ ≤ R} : Set _).Nonempty :=
    ⟨0, by simp [hR.le]⟩
  obtain ⟨hfin, hpred, hcomp, _, hrisk⟩ :=
    entropy_loss_comparison_on_weights d Ω μ X Y hX_meas hY_meas _ hC β hβ hX_int
      w P hP_meas hP_mem h_end h_own h_fp h_conv_test φ hφ
  exact ⟨hfin, hpred, hcomp, hrisk⟩

end UL.Proof_thm_3_2

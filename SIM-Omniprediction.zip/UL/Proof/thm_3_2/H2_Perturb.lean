import UL.Proof.thm_3_2.H0_Defs
set_option autoImplicit false

namespace UL.Proof_thm_3_2

private lemma tendsto_one_div_nat_add (c : ℝ) :
    Filter.Tendsto (fun n : ℕ => 1 / ((n : ℝ) + c)) Filter.atTop (nhds 0) :=
  (tendsto_const_nhds (x := (1 : ℝ))).div_atTop
    (Filter.tendsto_atTop_add_const_right Filter.atTop c tendsto_natCast_atTop_atTop)

private lemma measurable_inner_comp {d : ℕ} {Ω : Type*} [MeasurableSpace Ω]
    {X : Ω → EuclideanSpace ℝ (Fin d)} (hX : Measurable X)
    (w : EuclideanSpace ℝ (Fin d)) :
    Measurable (fun ω => inner ℝ w (X ω)) :=
  (continuous_const.inner continuous_id).measurable.comp hX

private lemma abs_clampIcc_inner_quot_le_one {t p : ℝ}
    (ht0 : 0 < t) (ht1 : t ≤ 1 - t) (hp : p ∈ Set.Icc (0 : ℝ) 1) :
    |(clampIcc t (1 - t) p - p) / t| ≤ 1 := by
  rcases lt_or_ge p t with hpt | htp
  · have hcl : clampIcc t (1 - t) p = t := by
      unfold clampIcc
      rw [min_eq_right (le_trans hpt.le ht1), max_eq_left hpt.le]
    rw [hcl, abs_div, abs_of_pos ht0, abs_of_nonneg (by linarith [hpt]), div_le_one ht0]
    linarith [hp.1]
  · rcases lt_or_ge (1 - t) p with hp1 | hp1
    · have hcl : clampIcc t (1 - t) p = 1 - t := by
        unfold clampIcc
        rw [min_eq_left hp1.le, max_eq_right ht1]
      rw [hcl, abs_div, abs_of_pos ht0, abs_of_nonpos (by linarith [hp1]), div_le_one ht0]
      linarith [hp.2]
    · rw [clampIcc_of_mem ⟨htp, hp1⟩, sub_self, zero_div, abs_zero]
      exact zero_le_one

theorem ae_endpoint_support
    (d : ℕ) (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin 2)
    (hX_meas : Measurable X) (hY_meas : Measurable Y)
    (β : ℝ) (hβ : 0 < β)
    (w : EuclideanSpace ℝ (Fin d)) (ρ : ℝ → ℝ)
    (hρ : IsProfile β ρ)
    (hVI : ∀ ρ' : ℝ → ℝ, IsProfile β ρ' →
      0 ≤ ∫ ω, fitRes (fun ω' => ρ (inner ℝ w (X ω'))) Y ω *
        (ρ' (inner ℝ w (X ω)) - ρ (inner ℝ w (X ω))) ∂μ) :
    ∀ᵐ ω ∂μ, (ρ (inner ℝ w (X ω)) = 0 → Y ω = 0) ∧
      (ρ (inner ℝ w (X ω)) = 1 → Y ω = 1) := by
  let S : Ω → ℝ := fun ω => inner ℝ w (X ω)
  let P : Ω → ℝ := fun ω => ρ (S ω)
  let ξ : Ω → ℝ := fitRes P Y
  let t : ℕ → ℝ := fun n => 1 / ((n : ℝ) + 3)
  have hS_meas : Measurable S := measurable_inner_comp hX_meas w
  have hP_meas : Measurable P := hρ.measurable.comp hS_meas
  have hy_meas : Measurable (fun ω => yReal (Y ω)) := measurable_yReal hY_meas
  have hr_meas : Measurable ξ := hP_meas.sub hy_meas
  have ht_pos : ∀ n : ℕ, 0 < t n := fun n => by
    dsimp [t]; positivity
  have ht_le : ∀ n : ℕ, t n ≤ 1 - t n := by
    intro n
    have hn : (3 : ℝ) ≤ (n : ℝ) + 3 := by linarith [Nat.cast_nonneg (α := ℝ) n]
    have htn : t n ≤ 1 / 3 := by
      dsimp [t]
      exact one_div_le_one_div_of_le (by norm_num) hn
    linarith
  have hρ_n : ∀ n : ℕ, IsProfile β (fun u => clampIcc (t n) (1 - t n) (ρ u)) := by
    intro n
    refine ⟨(clampIcc_mono _ _).comp hρ.1, ?_, ?_⟩
    · rw [lipschitzWith_toNNReal_iff hβ.le]
      have hL := (lipschitzWith_toNNReal_iff hβ.le ρ).mp hρ.2.1
      intro x y
      exact le_trans (abs_clampIcc_sub_le _ _ _ _) (hL x y)
    · intro u
      have hm := clampIcc_mem (ht_le n) (ρ u)
      have htn0 : 0 ≤ t n := (ht_pos n).le
      exact ⟨by linarith [hm.1], by linarith [hm.2]⟩
  let F_seq : ℕ → Ω → ℝ := fun n ω =>
    ξ ω * ((clampIcc (t n) (1 - t n) (P ω) - P ω) / t n)
  let nonneg_term : Ω → ℝ := fun ω =>
    if P ω = 0 then yReal (Y ω) else if P ω = 1 then 1 - yReal (Y ω) else 0
  have hF_int_nonneg : ∀ n : ℕ, 0 ≤ ∫ ω, F_seq n ω ∂μ := by
    intro n
    have h0 := hVI (fun u => clampIcc (t n) (1 - t n) (ρ u)) (hρ_n n)
    have h1 : 0 ≤ (∫ ω, ξ ω * (clampIcc (t n) (1 - t n) (P ω) - P ω) ∂μ) / t n :=
      div_nonneg h0 (ht_pos n).le
    rw [← MeasureTheory.integral_div] at h1
    simpa only [F_seq, mul_div_assoc] using h1
  have hF_meas : ∀ n : ℕ, MeasureTheory.AEStronglyMeasurable (F_seq n) μ := by
    intro n
    have hcl_meas : Measurable (fun ω => clampIcc (t n) (1 - t n) (P ω)) := by
      unfold clampIcc
      exact measurable_const.max (measurable_const.min hP_meas)
    exact (hr_meas.mul ((hcl_meas.sub hP_meas).div_const (t n))).aestronglyMeasurable
  have hF_bound : ∀ n : ℕ, ∀ᵐ ω ∂μ, ‖F_seq n ω‖ ≤ (1 : ℝ) := by
    intro n
    refine Filter.Eventually.of_forall (fun ω => ?_)
    rw [Real.norm_eq_abs, abs_mul]
    have hr1 : |ξ ω| ≤ 1 := abs_fitRes_le_one (fun ω' => hρ.2.2 (S ω')) Y ω
    have hq1 : |(clampIcc (t n) (1 - t n) (P ω) - P ω) / t n| ≤ 1 :=
      abs_clampIcc_inner_quot_le_one (ht_pos n) (ht_le n) (hρ.2.2 (S ω))
    nlinarith [abs_nonneg (ξ ω), abs_nonneg ((clampIcc (t n) (1 - t n) (P ω) - P ω) / t n)]
  have ht_lim : Filter.Tendsto t Filter.atTop (nhds 0) := tendsto_one_div_nat_add 3
  have hF_lim : ∀ᵐ ω ∂μ, Filter.Tendsto (fun n => F_seq n ω) Filter.atTop
      (nhds (-nonneg_term ω)) := by
    refine Filter.Eventually.of_forall (fun ω => ?_)
    by_cases hp0 : P ω = 0
    · have heq : (fun n => F_seq n ω) = fun _ => -nonneg_term ω := by
        ext n
        have hcl : clampIcc (t n) (1 - t n) 0 = t n := by
          unfold clampIcc
          have h1 : 0 ≤ 1 - t n := by linarith [ht_pos n, ht_le n]
          rw [min_eq_right h1, max_eq_left (ht_pos n).le]
        have htn_ne : t n ≠ 0 := (ht_pos n).ne'
        simp [F_seq, nonneg_term, ξ, fitRes, hp0, hcl, htn_ne]
      rw [heq]
      exact tendsto_const_nhds
    · by_cases hp1 : P ω = 1
      · have heq : (fun n => F_seq n ω) = fun _ => -nonneg_term ω := by
          ext n
          have hcl : clampIcc (t n) (1 - t n) 1 = 1 - t n := by
            unfold clampIcc
            have h1 : 1 - t n ≤ 1 := by linarith [ht_pos n]
            rw [min_eq_left h1, max_eq_right (ht_le n)]
          have htn_ne : t n ≠ 0 := (ht_pos n).ne'
          dsimp [F_seq, nonneg_term, ξ, fitRes]
          rw [hp1, if_neg one_ne_zero, if_pos rfl, hcl]
          field_simp [htn_ne]
          ring
        rw [heq]
        exact tendsto_const_nhds
      · have hpIcc := hρ.2.2 (S ω)
        have hp_gt : 0 < P ω := lt_of_le_of_ne hpIcc.1 (Ne.symm hp0)
        have hp_lt : P ω < 1 := lt_of_le_of_ne hpIcc.2 hp1
        have hp_sub : 0 < 1 - P ω := sub_pos.mpr hp_lt
        have hev1 : ∀ᶠ n in Filter.atTop, t n < P ω :=
          ht_lim.eventually (gt_mem_nhds hp_gt)
        have hev2 : ∀ᶠ n in Filter.atTop, t n < 1 - P ω :=
          ht_lim.eventually (gt_mem_nhds hp_sub)
        have hev : (fun n => F_seq n ω) =ᶠ[Filter.atTop] fun _ => -nonneg_term ω := by
          filter_upwards [hev1, hev2] with n hn1 hn2
          have hcl : clampIcc (t n) (1 - t n) (P ω) = P ω :=
            clampIcc_of_mem ⟨hn1.le, by linarith⟩
          simp [F_seq, nonneg_term, hp0, hp1, hcl]
        exact tendsto_const_nhds.congr' hev.symm
  have h_tendsto_int :=
    MeasureTheory.tendsto_integral_of_dominated_convergence (fun _ => (1 : ℝ))
      hF_meas (MeasureTheory.integrable_const 1) hF_bound hF_lim
  have h_lim_nonneg : 0 ≤ ∫ ω, -nonneg_term ω ∂μ :=
    ge_of_tendsto' h_tendsto_int hF_int_nonneg
  rw [MeasureTheory.integral_neg] at h_lim_nonneg
  have h_int_le_zero : ∫ ω, nonneg_term ω ∂μ ≤ 0 := by linarith
  have h_nn : ∀ ω : Ω, 0 ≤ nonneg_term ω := by
    intro ω
    have hy := yReal_mem_Icc (Y ω)
    dsimp [nonneg_term]
    split_ifs <;> linarith [hy.1, hy.2]
  have h_nn_meas : Measurable nonneg_term := by
    dsimp [nonneg_term]
    refine Measurable.ite (measurableSet_eq_fun hP_meas measurable_const) hy_meas ?_
    exact Measurable.ite (measurableSet_eq_fun hP_meas measurable_const)
      (measurable_const.sub hy_meas) measurable_const
  have h_nn_int : MeasureTheory.Integrable nonneg_term μ := by
    refine (MeasureTheory.integrable_const (1 : ℝ)).mono' h_nn_meas.aestronglyMeasurable ?_
    refine Filter.Eventually.of_forall (fun ω => ?_)
    rw [Real.norm_eq_abs, abs_of_nonneg (h_nn ω)]
    have hy := yReal_mem_Icc (Y ω)
    dsimp [nonneg_term]
    split_ifs <;> linarith [hy.1, hy.2]
  have h_int_nonneg : 0 ≤ ∫ ω, nonneg_term ω ∂μ :=
    MeasureTheory.integral_nonneg h_nn
  have h_int_zero : ∫ ω, nonneg_term ω ∂μ = 0 :=
    le_antisymm h_int_le_zero h_int_nonneg
  have h_ae_zero : nonneg_term =ᵐ[μ] 0 :=
    (MeasureTheory.integral_eq_zero_iff_of_nonneg_ae
      (Filter.Eventually.of_forall h_nn) h_nn_int).mp h_int_zero
  filter_upwards [h_ae_zero] with ω hω
  change nonneg_term ω = 0 at hω
  dsimp [nonneg_term, P, S] at hω
  constructor
  · intro hp0
    rw [if_pos hp0] at hω
    exact eq_zero_of_yReal_eq_zero hω
  · intro hp1
    have hp0 : ρ (inner ℝ w (X ω)) ≠ 0 := by linarith
    rw [if_neg hp0, if_pos hp1] at hω
    exact eq_one_of_yReal_eq_one (by linarith)

private lemma ae_fitRes_eq_zero_of_not_mem_Ioo
    (d : ℕ) (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin 2)
    (hX_meas : Measurable X) (hY_meas : Measurable Y)
    (β : ℝ) (hβ : 0 < β)
    (w : EuclideanSpace ℝ (Fin d)) (ρ : ℝ → ℝ)
    (hρ : IsProfile β ρ)
    (hVI : ∀ ρ' : ℝ → ℝ, IsProfile β ρ' →
      0 ≤ ∫ ω, fitRes (fun ω' => ρ (inner ℝ w (X ω'))) Y ω *
        (ρ' (inner ℝ w (X ω)) - ρ (inner ℝ w (X ω))) ∂μ) :
    ∀ᵐ ω ∂μ, ρ (inner ℝ w (X ω)) ∉ Set.Ioo (0 : ℝ) 1 →
      fitRes (fun ω' => ρ (inner ℝ w (X ω'))) Y ω = 0 := by
  filter_upwards [ae_endpoint_support d Ω μ X Y hX_meas hY_meas β hβ w ρ hρ hVI] with ω hω hnot
  have hpIcc := hρ.2.2 (inner ℝ w (X ω))
  rcases eq_or_lt_of_le hpIcc.1 with hp0 | hp_pos
  · have hy0 := hω.1 hp0.symm
    simp [fitRes, yReal, ← hp0, hy0]
  · rcases eq_or_lt_of_le hpIcc.2 with hp1 | hp_lt
    · have hy1 := hω.2 hp1
      simp [fitRes, yReal, hp1, hy1]
    · exact False.elim (hnot ⟨hp_pos, hp_lt⟩)

theorem own_score_ineq
    (d : ℕ) (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin 2)
    (hX_meas : Measurable X) (hY_meas : Measurable Y)
    (β : ℝ) (hβ : 0 < β)
    (hX_int : MeasureTheory.Integrable (fun ω => ‖X ω‖) μ)
    (w : EuclideanSpace ℝ (Fin d)) (ρ : ℝ → ℝ)
    (hρ : IsProfile β ρ)
    (hVI : ∀ ρ' : ℝ → ℝ, IsProfile β ρ' →
      0 ≤ ∫ ω, fitRes (fun ω' => ρ (inner ℝ w (X ω'))) Y ω *
        (ρ' (inner ℝ w (X ω)) - ρ (inner ℝ w (X ω))) ∂μ) :
    ∫ ω, fitRes (fun ω' => ρ (inner ℝ w (X ω'))) Y ω * ρ (inner ℝ w (X ω)) ∂μ ≤
      β * ∫ ω, fitRes (fun ω' => ρ (inner ℝ w (X ω'))) Y ω * inner ℝ w (X ω) ∂μ := by
  let S : Ω → ℝ := fun ω => inner ℝ w (X ω)
  let P : Ω → ℝ := fun ω => ρ (S ω)
  let ξ : Ω → ℝ := fitRes P Y
  let t : ℕ → ℝ := fun n => 1 / ((n : ℝ) + 2)
  have hS_meas : Measurable S := measurable_inner_comp hX_meas w
  have hP_meas : Measurable P := hρ.measurable.comp hS_meas
  have hr_meas : Measurable ξ := hP_meas.sub (measurable_yReal hY_meas)
  have ht_pos : ∀ n : ℕ, 0 < t n := fun n => by dsimp [t]; positivity
  have ht_le_one : ∀ n : ℕ, t n ≤ 1 := by
    intro n
    have hn : (1 : ℝ) ≤ (n : ℝ) + 2 := by linarith [Nat.cast_nonneg (α := ℝ) n]
    dsimp [t]
    exact div_le_one_of_le₀ hn (by positivity)
  let ρ_seq : ℕ → ℝ → ℝ := fun n a => clampIcc 0 1 ((1 - t n) * ρ a + t n * (β * a))
  have hρ_seq : ∀ n : ℕ, IsProfile β (ρ_seq n) := by
    intro n
    have h1t : 0 ≤ 1 - t n := sub_nonneg.mpr (ht_le_one n)
    have htn : 0 ≤ t n := (ht_pos n).le
    refine ⟨?_, ?_, fun a => clampIcc_mem zero_le_one _⟩
    · intro x y hxy
      apply clampIcc_mono 0 1
      have h1 : (1 - t n) * ρ x ≤ (1 - t n) * ρ y :=
        mul_le_mul_of_nonneg_left (hρ.1 hxy) h1t
      have h2 : t n * (β * x) ≤ t n * (β * y) :=
        mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left hxy hβ.le) htn
      linarith
    · rw [lipschitzWith_toNNReal_iff hβ.le]
      have hL := (lipschitzWith_toNNReal_iff hβ.le ρ).mp hρ.2.1
      intro x y
      refine le_trans (abs_clampIcc_sub_le 0 1 _ _) ?_
      have heq : ((1 - t n) * ρ x + t n * (β * x)) - ((1 - t n) * ρ y + t n * (β * y)) =
          (1 - t n) * (ρ x - ρ y) + t n * (β * (x - y)) := by ring
      rw [heq]
      calc
        |(1 - t n) * (ρ x - ρ y) + t n * (β * (x - y))|
          ≤ |(1 - t n) * (ρ x - ρ y)| + |t n * (β * (x - y))| := abs_add_le _ _
        _ = (1 - t n) * |ρ x - ρ y| + t n * (β * |x - y|) := by
          rw [abs_mul, abs_mul, abs_mul, abs_of_nonneg h1t, abs_of_nonneg htn,
            abs_of_nonneg hβ.le]
        _ ≤ (1 - t n) * (β * |x - y|) + t n * (β * |x - y|) := by
          gcongr
          exact hL x y
        _ = β * |x - y| := by ring
  let F_seq : ℕ → Ω → ℝ := fun n ω => ξ ω * ((ρ_seq n (S ω) - P ω) / t n)
  let F_lim : Ω → ℝ := fun ω => ξ ω * (β * S ω - P ω)
  let B : Ω → ℝ := fun ω => β * (‖w‖ * ‖X ω‖) + 1
  have hF_nonneg : ∀ n : ℕ, 0 ≤ ∫ ω, F_seq n ω ∂μ := by
    intro n
    have h0 := hVI (ρ_seq n) (hρ_seq n)
    have h1 : 0 ≤ (∫ ω, ξ ω * (ρ_seq n (S ω) - P ω) ∂μ) / t n :=
      div_nonneg h0 (ht_pos n).le
    rw [← MeasureTheory.integral_div] at h1
    simpa only [F_seq, mul_div_assoc] using h1
  have hF_meas : ∀ n : ℕ, MeasureTheory.AEStronglyMeasurable (F_seq n) μ := by
    intro n
    have hρn_meas : Measurable (fun ω => ρ_seq n (S ω)) :=
      (hρ_seq n).measurable.comp hS_meas
    exact (hr_meas.mul ((hρn_meas.sub hP_meas).div_const (t n))).aestronglyMeasurable
  have hB_int : MeasureTheory.Integrable B μ :=
    ((hX_int.const_mul ‖w‖).const_mul β).add (MeasureTheory.integrable_const 1)
  have hF_bound : ∀ n : ℕ, ∀ᵐ ω ∂μ, ‖F_seq n ω‖ ≤ B ω := by
    intro n
    refine Filter.Eventually.of_forall (fun ω => ?_)
    rw [Real.norm_eq_abs, abs_mul]
    have hr1 : |ξ ω| ≤ 1 := abs_fitRes_le_one (fun ω' => hρ.2.2 (S ω')) Y ω
    have hpIcc := hρ.2.2 (S ω)
    have hp_cl : clampIcc 0 1 ((1 - t n) * P ω + t n * P ω) = P ω := by
      have heq : (1 - t n) * P ω + t n * P ω = P ω := by ring
      rw [heq]
      exact clampIcc_of_mem hpIcc
    have hdiff : |ρ_seq n (S ω) - P ω| ≤ t n * |β * S ω - P ω| := by
      have heq_sub : ((1 - t n) * P ω + t n * (β * S ω)) - ((1 - t n) * P ω + t n * P ω) =
          t n * (β * S ω - P ω) := by ring
      calc
        |ρ_seq n (S ω) - P ω|
          = |clampIcc 0 1 ((1 - t n) * P ω + t n * (β * S ω)) -
              clampIcc 0 1 ((1 - t n) * P ω + t n * P ω)| := by
            dsimp [ρ_seq]; rw [hp_cl]
        _ ≤ |((1 - t n) * P ω + t n * (β * S ω)) - ((1 - t n) * P ω + t n * P ω)| :=
            abs_clampIcc_sub_le 0 1 _ _
        _ = |t n * (β * S ω - P ω)| := by rw [heq_sub]
        _ = t n * |β * S ω - P ω| := by rw [abs_mul, abs_of_pos (ht_pos n)]
    have hquot : |(ρ_seq n (S ω) - P ω) / t n| ≤ |β * S ω - P ω| := by
      rw [abs_div, abs_of_pos (ht_pos n), div_le_iff₀ (ht_pos n)]
      linarith
    have h_inner : |S ω| ≤ ‖w‖ * ‖X ω‖ := abs_real_inner_le_norm w (X ω)
    have h_absP : |P ω| ≤ 1 := by
      rw [abs_of_nonneg hpIcc.1]; exact hpIcc.2
    have h_tri : |β * S ω - P ω| ≤ B ω := by
      calc
        |β * S ω - P ω| ≤ |β * S ω| + |P ω| := abs_sub _ _
        _ = β * |S ω| + |P ω| := by rw [abs_mul, abs_of_pos hβ]
        _ ≤ β * (‖w‖ * ‖X ω‖) + 1 := by gcongr
    calc
      |ξ ω| * |(ρ_seq n (S ω) - P ω) / t n| ≤ 1 * |β * S ω - P ω| := by
        gcongr
      _ ≤ B ω := by linarith
  have ht_lim : Filter.Tendsto t Filter.atTop (nhds 0) := tendsto_one_div_nat_add 2
  have h_ae_end := ae_fitRes_eq_zero_of_not_mem_Ioo d Ω μ X Y hX_meas hY_meas β hβ w ρ hρ hVI
  have hF_lim : ∀ᵐ ω ∂μ, Filter.Tendsto (fun n => F_seq n ω) Filter.atTop (nhds (F_lim ω)) := by
    filter_upwards [h_ae_end] with ω hω
    by_cases hp : P ω ∈ Set.Ioo (0 : ℝ) 1
    · have hcomb_lim : Filter.Tendsto (fun n => P ω + t n * (β * S ω - P ω))
          Filter.atTop (nhds (P ω)) := by
        simpa only [zero_mul, add_zero] using
          (tendsto_const_nhds (x := P ω)).add (ht_lim.mul_const (β * S ω - P ω))
      have hev_mem : ∀ᶠ n in Filter.atTop,
          P ω + t n * (β * S ω - P ω) ∈ Set.Ioo (0 : ℝ) 1 :=
        hcomb_lim.eventually (isOpen_Ioo.mem_nhds hp)
      have hev_eq : (fun n => F_seq n ω) =ᶠ[Filter.atTop] fun _ => F_lim ω := by
        filter_upwards [hev_mem] with n hn
        have heq_in : (1 - t n) * P ω + t n * (β * S ω) = P ω + t n * (β * S ω - P ω) := by ring
        have hcl : ρ_seq n (S ω) = P ω + t n * (β * S ω - P ω) := by
          dsimp [ρ_seq, P]
          rw [heq_in]
          exact clampIcc_of_mem ⟨hn.1.le, hn.2.le⟩
        have htn_ne : t n ≠ 0 := (ht_pos n).ne'
        dsimp [F_seq, F_lim]
        rw [hcl]
        congr 1
        field_simp [htn_ne]
        ring
      exact tendsto_const_nhds.congr' hev_eq.symm
    · have hr0 : ξ ω = 0 := hω hp
      simp [F_seq, F_lim, hr0]
  have h_tendsto_int :=
    MeasureTheory.tendsto_integral_of_dominated_convergence B hF_meas hB_int hF_bound hF_lim
  have h_lim_nonneg : 0 ≤ ∫ ω, F_lim ω ∂μ :=
    ge_of_tendsto' h_tendsto_int hF_nonneg
  have hrS_int : MeasureTheory.Integrable (fun ω => ξ ω * S ω) μ := by
    refine (hX_int.const_mul ‖w‖).mono' (hr_meas.mul hS_meas).aestronglyMeasurable ?_
    refine Filter.Eventually.of_forall (fun ω => ?_)
    rw [Real.norm_eq_abs, abs_mul]
    have hr1 : |ξ ω| ≤ 1 := abs_fitRes_le_one (fun ω' => hρ.2.2 (S ω')) Y ω
    have h_inner : |S ω| ≤ ‖w‖ * ‖X ω‖ := abs_real_inner_le_norm w (X ω)
    calc
      |ξ ω| * |S ω| ≤ 1 * (‖w‖ * ‖X ω‖) := by gcongr
      _ = ‖w‖ * ‖X ω‖ := one_mul _
  have hrP_int : MeasureTheory.Integrable (fun ω => ξ ω * P ω) μ := by
    refine (MeasureTheory.integrable_const (1 : ℝ)).mono'
      (hr_meas.mul hP_meas).aestronglyMeasurable ?_
    refine Filter.Eventually.of_forall (fun ω => ?_)
    rw [Real.norm_eq_abs, abs_mul]
    have hr1 : |ξ ω| ≤ 1 := abs_fitRes_le_one (fun ω' => hρ.2.2 (S ω')) Y ω
    have hpIcc := hρ.2.2 (S ω)
    have hP1 : |P ω| ≤ 1 := by rw [abs_of_nonneg hpIcc.1]; exact hpIcc.2
    nlinarith [abs_nonneg (ξ ω), abs_nonneg (P ω)]
  have h_rewrite : F_lim = fun ω => β * (ξ ω * S ω) - ξ ω * P ω := by
    ext ω; dsimp [F_lim]; ring
  rw [h_rewrite, MeasureTheory.integral_sub (hrS_int.const_mul β) hrP_int,
    MeasureTheory.integral_const_mul] at h_lim_nonneg
  linarith

private lemma convex_secant_three {F : ℝ → ℝ}
    (hF : ConvexOn ℝ (Set.Icc (0 : ℝ) 1) F)
    (x y z : ℝ) (hx : 0 ≤ x) (hxy : x < y) (hyz : y < z) (hz : z ≤ 1) :
    (F y - F x) / (y - x) ≤ (F z - F x) / (z - x) ∧
      (F z - F x) / (z - x) ≤ (F z - F y) / (z - y) := by
  have hzx : 0 < z - x := by linarith
  have hyx : 0 < y - x := by linarith
  have hzy : 0 < z - y := by linarith
  have hx_mem : x ∈ Set.Icc (0 : ℝ) 1 := ⟨hx, by linarith⟩
  have hz_mem : z ∈ Set.Icc (0 : ℝ) 1 := ⟨by linarith, hz⟩
  let a : ℝ := (z - y) / (z - x)
  let b : ℝ := (y - x) / (z - x)
  have ha : 0 ≤ a := div_nonneg hzy.le hzx.le
  have hb : 0 ≤ b := div_nonneg hyx.le hzx.le
  have hab : a + b = 1 := by
    dsimp [a, b]
    rw [← add_div, sub_add_sub_cancel, div_self hzx.ne']
  have hy_eq : a • x + b • z = y := by
    change a * x + b * z = y
    dsimp [a, b]
    field_simp [hzx.ne']
    ring
  have hconv := hF.2 hx_mem hz_mem ha hb hab
  rw [hy_eq] at hconv
  simp only [smul_eq_mul, a, b] at hconv
  have hmul : F y * (z - x) ≤ (z - y) * F x + (y - x) * F z := by
    have h1 := mul_le_mul_of_nonneg_right hconv hzx.le
    have h2 : ((z - y) / (z - x) * F x + (y - x) / (z - x) * F z) * (z - x) =
        (z - y) * F x + (y - x) * F z := by
      field_simp [hzx.ne']
    linarith
  constructor
  · rw [div_le_div_iff₀ hyx hzx]
    nlinarith
  · rw [div_le_div_iff₀ hzx hzy]
    nlinarith

private lemma convex_secant_ends {F : ℝ → ℝ}
    (hF : ConvexOn ℝ (Set.Icc (0 : ℝ) 1) F)
    (x y z : ℝ) (hx : 0 ≤ x) (hxy : x < y) (hyz : y < z) (hz : z ≤ 1) :
    (F y - F x) / (y - x) ≤ (F z - F y) / (z - y) := by
  have h := convex_secant_three hF x y z hx hxy hyz hz
  exact le_trans h.1 h.2

private lemma convex_subgradient_Icc {F : ℝ → ℝ}
    (hF_conv : ConvexOn ℝ (Set.Icc (0 : ℝ) 1) F)
    (hF_diff : ∀ q ∈ Set.Ioo (0 : ℝ) 1, DifferentiableAt ℝ F q)
    {q z : ℝ} (hq : q ∈ Set.Ioo (0 : ℝ) 1) (hz : z ∈ Set.Icc (0 : ℝ) 1) :
    deriv F q * (z - q) ≤ F z - F q := by
  rcases lt_trichotomy q z with hqz | rfl | hzq
  · have hsub_pos : 0 < z - q := sub_pos.mpr hqz
    let d : ℕ → ℝ := fun m => (z - q) / ((m : ℝ) + 2)
    have hd_pos : ∀ m : ℕ, 0 < d m := fun m => by dsimp [d]; positivity
    have hd_lt : ∀ m : ℕ, d m < z - q := by
      intro m
      dsimp [d]
      rw [div_lt_iff₀ (by positivity)]
      have hm : (0 : ℝ) ≤ m := Nat.cast_nonneg m
      nlinarith
    have hd_lim : Filter.Tendsto d Filter.atTop (nhds 0) := by
      have h0 : Filter.Tendsto (fun m : ℕ => (z - q) * (1 / ((m : ℝ) + 2)))
          Filter.atTop (nhds ((z - q) * 0)) :=
        (tendsto_const_nhds (x := z - q)).mul (tendsto_one_div_nat_add 2)
      rw [mul_zero] at h0
      refine h0.congr (fun m => ?_)
      dsimp [d]; ring
    have hd_nhds : Filter.Tendsto d Filter.atTop (nhdsWithin 0 (Set.Ioi 0)) :=
      tendsto_nhdsWithin_iff.mpr ⟨hd_lim, Filter.Eventually.of_forall hd_pos⟩
    have hslope := ((hF_diff q hq).hasDerivAt.tendsto_slope_zero_right).comp hd_nhds
    have hsec : ∀ m : ℕ,
        ((d m)⁻¹ • (F (q + d m) - F q)) ≤ (F z - F q) / (z - q) := by
      intro m
      have h3 := (convex_secant_three hF_conv q (q + d m) z hq.1.le
        (by linarith [hd_pos m]) (by linarith [hd_lt m]) hz.2).1
      have hsub_dm : q + d m - q = d m := by ring
      rw [hsub_dm] at h3
      simpa [smul_eq_mul, inv_mul_eq_div] using h3
    have hderiv_le : deriv F q ≤ (F z - F q) / (z - q) :=
      le_of_tendsto' hslope hsec
    exact (le_div_iff₀ hsub_pos).mp hderiv_le
  · simp
  · have hsub_pos : 0 < q - z := sub_pos.mpr hzq
    let d : ℕ → ℝ := fun m => (q - z) / ((m : ℝ) + 2)
    have hd_pos : ∀ m : ℕ, 0 < d m := fun m => by dsimp [d]; positivity
    have hd_lt : ∀ m : ℕ, d m < q - z := by
      intro m
      dsimp [d]
      rw [div_lt_iff₀ (by positivity)]
      have hm : (0 : ℝ) ≤ m := Nat.cast_nonneg m
      nlinarith
    have hd0 : Filter.Tendsto d Filter.atTop (nhds 0) := by
      have h0 : Filter.Tendsto (fun m : ℕ => (q - z) * (1 / ((m : ℝ) + 2)))
          Filter.atTop (nhds ((q - z) * 0)) :=
        (tendsto_const_nhds (x := q - z)).mul (tendsto_one_div_nat_add 2)
      rw [mul_zero] at h0
      refine h0.congr (fun m => ?_)
      dsimp [d]; ring
    have hd_lim : Filter.Tendsto (fun m => -d m) Filter.atTop (nhds 0) := by
      simpa using hd0.neg
    have hd_nhds : Filter.Tendsto (fun m => -d m) Filter.atTop (nhdsWithin 0 (Set.Iio 0)) :=
      tendsto_nhdsWithin_iff.mpr
        ⟨hd_lim, Filter.Eventually.of_forall (fun m => neg_lt_zero.mpr (hd_pos m))⟩
    have hslope := ((hF_diff q hq).hasDerivAt.tendsto_slope_zero_left).comp hd_nhds
    have hsec : ∀ m : ℕ,
        (F q - F z) / (q - z) ≤ ((-d m)⁻¹ • (F (q + -d m) - F q)) := by
      intro m
      have h3 := (convex_secant_three hF_conv z (q - d m) q hz.1
        (by linarith [hd_lt m]) (by linarith [hd_pos m]) hq.2.le).2
      have hdm_ne : d m ≠ 0 := (hd_pos m).ne'
      have heq : (-d m)⁻¹ • (F (q + -d m) - F q) = (F q - F (q - d m)) / (q - (q - d m)) := by
        change (-d m)⁻¹ * (F (q + -d m) - F q) = (F q - F (q - d m)) / (q - (q - d m))
        have hqsub : q + -d m = q - d m := by ring
        rw [hqsub]
        field_simp [hdm_ne]
        ring
      rw [heq]
      exact h3
    have hderiv_ge : (F q - F z) / (q - z) ≤ deriv F q :=
      ge_of_tendsto' hslope hsec
    have hmul : F q - F z ≤ deriv F q * (q - z) := (div_le_iff₀ hsub_pos).mp hderiv_ge
    linarith

private noncomputable def interiorLipConst (F : ℝ → ℝ) (s : ℝ) : ℝ :=
  max (|(F (s / 2) - F 0) / (s / 2)|) (|(F 1 - F (1 - s / 2)) / (s / 2)|) + 1

private lemma interiorLipConst_pos (F : ℝ → ℝ) (s : ℝ) : 0 < interiorLipConst F s := by
  unfold interiorLipConst
  have h0 : 0 ≤ max (|(F (s / 2) - F 0) / (s / 2)|) (|(F 1 - F (1 - s / 2)) / (s / 2)|) :=
    le_trans (abs_nonneg _) (le_max_left _ _)
  linarith

private lemma convex_interior_lip_lt {F : ℝ → ℝ}
    (hF_conv : ConvexOn ℝ (Set.Icc (0 : ℝ) 1) F)
    {s : ℝ} (hs : s ∈ Set.Ioo (0 : ℝ) (1 / 3))
    {x y : ℝ} (hx : x ∈ Set.Icc (s / 2) (1 - s / 2))
    (hy : y ∈ Set.Icc (s / 2) (1 - s / 2)) (hxy : x < y) :
    |F y - F x| ≤ interiorLipConst F s * (y - x) := by
  have hs_pos : 0 < s := hs.1
  have hs_lt : s < 1 / 3 := hs.2
  have hx_pos : 0 < x := by linarith [hx.1]
  have hy_lt1 : y < 1 := by linarith [hy.2]
  have hyx_pos : 0 < y - x := sub_pos.mpr hxy
  have h_lower : (F (s / 2) - F 0) / (s / 2) ≤ (F y - F x) / (y - x) := by
    have h1 : (F (s / 2) - F 0) / (s / 2) ≤ (F x - F 0) / x := by
      rcases eq_or_lt_of_le hx.1 with hxeq | hxgt
      · rw [← hxeq]
      · have hsec := (convex_secant_three hF_conv 0 (s / 2) x le_rfl
          (by linarith) hxgt (by linarith [hx.2])).1
        simpa using hsec
    have h2 : (F x - F 0) / x ≤ (F y - F x) / (y - x) := by
      have hsec := convex_secant_ends hF_conv 0 x y le_rfl hx_pos hxy hy_lt1.le
      simpa using hsec
    exact le_trans h1 h2
  have h_upper : (F y - F x) / (y - x) ≤ (F 1 - F (1 - s / 2)) / (s / 2) := by
    have h1 : (F y - F x) / (y - x) ≤ (F 1 - F y) / (1 - y) :=
      convex_secant_ends hF_conv x y 1 hx_pos.le hxy hy_lt1 le_rfl
    have h2 : (F 1 - F y) / (1 - y) ≤ (F 1 - F (1 - s / 2)) / (s / 2) := by
      rcases eq_or_lt_of_le hy.2 with hyeq | hylt
      · rw [hyeq]
        have h1sub : 1 - (1 - s / 2) = s / 2 := by ring
        rw [h1sub]
      · have hsec := (convex_secant_three hF_conv y (1 - s / 2) 1 (by linarith [hx_pos, hxy]) hylt
          (by linarith) le_rfl).2
        have h1sub : 1 - (1 - s / 2) = s / 2 := by ring
        simpa [h1sub] using hsec
    exact le_trans h1 h2
  have habs_quot : |(F y - F x) / (y - x)| ≤ interiorLipConst F s := by
    unfold interiorLipConst
    rw [abs_le]
    have hL : -max (|(F (s / 2) - F 0) / (s / 2)|) (|(F 1 - F (1 - s / 2)) / (s / 2)|) ≤
        (F (s / 2) - F 0) / (s / 2) := by
      have h := neg_abs_le ((F (s / 2) - F 0) / (s / 2))
      have hm := le_max_left (|(F (s / 2) - F 0) / (s / 2)|) (|(F 1 - F (1 - s / 2)) / (s / 2)|)
      linarith
    have hU : (F 1 - F (1 - s / 2)) / (s / 2) ≤
        max (|(F (s / 2) - F 0) / (s / 2)|) (|(F 1 - F (1 - s / 2)) / (s / 2)|) :=
      le_trans (le_abs_self _) (le_max_right _ _)
    constructor <;> linarith
  rw [abs_div, abs_of_pos hyx_pos, div_le_iff₀ hyx_pos] at habs_quot
  exact habs_quot

private lemma convex_interior_lip {F : ℝ → ℝ}
    (hF_conv : ConvexOn ℝ (Set.Icc (0 : ℝ) 1) F)
    {s : ℝ} (hs : s ∈ Set.Ioo (0 : ℝ) (1 / 3))
    {x y : ℝ} (hx : x ∈ Set.Icc (s / 2) (1 - s / 2))
    (hy : y ∈ Set.Icc (s / 2) (1 - s / 2)) :
    |F y - F x| ≤ interiorLipConst F s * |y - x| := by
  rcases lt_trichotomy x y with hxy | rfl | hyx
  · rw [abs_of_pos (sub_pos.mpr hxy)]
    exact convex_interior_lip_lt hF_conv hs hx hy hxy
  · simp
  · rw [abs_sub_comm (F y) (F x), abs_sub_comm y x, abs_of_pos (sub_pos.mpr hyx)]
    exact convex_interior_lip_lt hF_conv hs hy hx hyx

private noncomputable def diffQuot (F : ℝ → ℝ) (s δ p : ℝ) : ℝ :=
  (F (clampIcc s (1 - s) p + δ) - F (clampIcc s (1 - s) p - δ)) / (2 * δ)

private lemma clamp_pm_mem_Icc {s δ p : ℝ}
    (hs : s ∈ Set.Ioo (0 : ℝ) (1 / 3)) (hδ : δ ∈ Set.Ioc (0 : ℝ) (s / 2)) :
    clampIcc s (1 - s) p + δ ∈ Set.Icc (s / 2) (1 - s / 2) ∧
      clampIcc s (1 - s) p - δ ∈ Set.Icc (s / 2) (1 - s / 2) := by
  have hs_le : s ≤ 1 - s := by linarith [hs.2]
  have hu := clampIcc_mem hs_le p
  refine ⟨⟨by linarith [hs.1, hu.1, hδ.1], by linarith [hu.2, hδ.2]⟩,
    ⟨by linarith [hu.1, hδ.2], by linarith [hs.1, hu.2, hδ.1]⟩⟩

private lemma diffQuot_mono {F : ℝ → ℝ}
    (hF_conv : ConvexOn ℝ (Set.Icc (0 : ℝ) 1) F)
    {s δ : ℝ} (hs : s ∈ Set.Ioo (0 : ℝ) (1 / 3)) (hδ : δ ∈ Set.Ioc (0 : ℝ) (s / 2)) :
    Monotone (diffQuot F s δ) := by
  intro p₁ p₂ hp
  unfold diffQuot
  set u := clampIcc s (1 - s) p₁
  set v := clampIcc s (1 - s) p₂
  have huv : u ≤ v := clampIcc_mono s (1 - s) hp
  rcases eq_or_lt_of_le huv with heq | hlt
  · rw [heq]
  · have hu_mem := clamp_pm_mem_Icc (p := p₁) hs hδ
    have hv_mem := clamp_pm_mem_Icc (p := p₂) hs hδ
    have hδ_pos : 0 < δ := hδ.1
    have h1 := (convex_secant_three hF_conv (u - δ) (u + δ) (v + δ)
      (by linarith [hu_mem.2.1, hs.1]) (by linarith) (by linarith)
      (by linarith [hv_mem.1.2, hs.1])).1
    have h2 := (convex_secant_three hF_conv (u - δ) (v - δ) (v + δ)
      (by linarith [hu_mem.2.1, hs.1]) (by linarith) (by linarith)
      (by linarith [hv_mem.1.2, hs.1])).2
    have hd1 : u + δ - (u - δ) = 2 * δ := by ring
    have hd2 : v + δ - (v - δ) = 2 * δ := by ring
    rw [hd1] at h1
    rw [hd2] at h2
    exact le_trans h1 h2

private lemma abs_diffQuot_le {F : ℝ → ℝ}
    (hF_conv : ConvexOn ℝ (Set.Icc (0 : ℝ) 1) F)
    {s δ : ℝ} (hs : s ∈ Set.Ioo (0 : ℝ) (1 / 3)) (hδ : δ ∈ Set.Ioc (0 : ℝ) (s / 2)) (p : ℝ) :
    |diffQuot F s δ p| ≤ interiorLipConst F s := by
  unfold diffQuot
  have hmem := clamp_pm_mem_Icc (p := p) hs hδ
  have hlip := convex_interior_lip hF_conv hs hmem.2 hmem.1
  have h2δ : 0 < 2 * δ := by linarith [hδ.1]
  have hd : clampIcc s (1 - s) p + δ - (clampIcc s (1 - s) p - δ) = 2 * δ := by ring
  rw [hd, abs_of_pos h2δ] at hlip
  rw [abs_div, abs_of_pos h2δ, div_le_iff₀ h2δ]
  exact hlip

private lemma abs_diffQuot_sub_le {F : ℝ → ℝ}
    (hF_conv : ConvexOn ℝ (Set.Icc (0 : ℝ) 1) F)
    {s δ : ℝ} (hs : s ∈ Set.Ioo (0 : ℝ) (1 / 3)) (hδ : δ ∈ Set.Ioc (0 : ℝ) (s / 2))
    (p₁ p₂ : ℝ) :
    |diffQuot F s δ p₁ - diffQuot F s δ p₂| ≤ (interiorLipConst F s / δ) * |p₁ - p₂| := by
  unfold diffQuot
  have hm1 := clamp_pm_mem_Icc (p := p₁) hs hδ
  have hm2 := clamp_pm_mem_Icc (p := p₂) hs hδ
  have h2δ : 0 < 2 * δ := by linarith [hδ.1]
  have hL_pos : 0 < interiorLipConst F s := interiorLipConst_pos F s
  have hlip_plus := convex_interior_lip hF_conv hs hm2.1 hm1.1
  have hlip_minus := convex_interior_lip hF_conv hs hm2.2 hm1.2
  have hd_plus : (clampIcc s (1 - s) p₁ + δ) - (clampIcc s (1 - s) p₂ + δ) =
      clampIcc s (1 - s) p₁ - clampIcc s (1 - s) p₂ := by ring
  have hd_minus : (clampIcc s (1 - s) p₁ - δ) - (clampIcc s (1 - s) p₂ - δ) =
      clampIcc s (1 - s) p₁ - clampIcc s (1 - s) p₂ := by ring
  rw [hd_plus] at hlip_plus
  rw [hd_minus] at hlip_minus
  have hcl := abs_clampIcc_sub_le s (1 - s) p₁ p₂
  have hnum : |(F (clampIcc s (1 - s) p₁ + δ) - F (clampIcc s (1 - s) p₁ - δ)) -
      (F (clampIcc s (1 - s) p₂ + δ) - F (clampIcc s (1 - s) p₂ - δ))| ≤
      2 * interiorLipConst F s * |p₁ - p₂| := by
    have heq : (F (clampIcc s (1 - s) p₁ + δ) - F (clampIcc s (1 - s) p₁ - δ)) -
        (F (clampIcc s (1 - s) p₂ + δ) - F (clampIcc s (1 - s) p₂ - δ)) =
        (F (clampIcc s (1 - s) p₁ + δ) - F (clampIcc s (1 - s) p₂ + δ)) -
        (F (clampIcc s (1 - s) p₁ - δ) - F (clampIcc s (1 - s) p₂ - δ)) := by ring
    rw [heq]
    calc
      |(F (clampIcc s (1 - s) p₁ + δ) - F (clampIcc s (1 - s) p₂ + δ)) -
          (F (clampIcc s (1 - s) p₁ - δ) - F (clampIcc s (1 - s) p₂ - δ))|
        ≤ |F (clampIcc s (1 - s) p₁ + δ) - F (clampIcc s (1 - s) p₂ + δ)| +
          |F (clampIcc s (1 - s) p₁ - δ) - F (clampIcc s (1 - s) p₂ - δ)| := abs_sub _ _
      _ ≤ interiorLipConst F s * |clampIcc s (1 - s) p₁ - clampIcc s (1 - s) p₂| +
          interiorLipConst F s * |clampIcc s (1 - s) p₁ - clampIcc s (1 - s) p₂| :=
        add_le_add hlip_plus hlip_minus
      _ = 2 * interiorLipConst F s * |clampIcc s (1 - s) p₁ - clampIcc s (1 - s) p₂| := by ring
      _ ≤ 2 * interiorLipConst F s * |p₁ - p₂| := by gcongr
  rw [← sub_div, abs_div, abs_of_pos h2δ, div_le_iff₀ h2δ]
  have hrhs : interiorLipConst F s / δ * |p₁ - p₂| * (2 * δ) =
      2 * interiorLipConst F s * |p₁ - p₂| := by
    field_simp [hδ.1.ne']
  linarith

private lemma diffQuot_continuous {F : ℝ → ℝ}
    (hF_conv : ConvexOn ℝ (Set.Icc (0 : ℝ) 1) F)
    {s δ : ℝ} (hs : s ∈ Set.Ioo (0 : ℝ) (1 / 3)) (hδ : δ ∈ Set.Ioc (0 : ℝ) (s / 2)) :
    Continuous (diffQuot F s δ) := by
  have hL : 0 ≤ interiorLipConst F s / δ :=
    div_nonneg (interiorLipConst_pos F s).le hδ.1.le
  have hlip : LipschitzWith (Real.toNNReal (interiorLipConst F s / δ)) (diffQuot F s δ) :=
    (lipschitzWith_toNNReal_iff hL _).mpr (abs_diffQuot_sub_le hF_conv hs hδ)
  exact hlip.continuous

private lemma vi_diffQuot_le_zero
    (d : ℕ) (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin 2)
    (hX_meas : Measurable X) (hY_meas : Measurable Y)
    (β : ℝ) (hβ : 0 < β)
    (w : EuclideanSpace ℝ (Fin d)) (ρ : ℝ → ℝ)
    (hρ : IsProfile β ρ)
    (hVI : ∀ ρ' : ℝ → ℝ, IsProfile β ρ' →
      0 ≤ ∫ ω, fitRes (fun ω' => ρ (inner ℝ w (X ω'))) Y ω *
        (ρ' (inner ℝ w (X ω)) - ρ (inner ℝ w (X ω))) ∂μ)
    (F : ℝ → ℝ) (hF_conv : ConvexOn ℝ (Set.Icc (0 : ℝ) 1) F)
    {s δ : ℝ} (hs : s ∈ Set.Ioo (0 : ℝ) (1 / 3)) (hδ : δ ∈ Set.Ioc (0 : ℝ) (s / 2)) :
    ∫ ω, (if ρ (inner ℝ w (X ω)) ∈ Set.Ioo (0 : ℝ) 1 then
      fitRes (fun ω' => ρ (inner ℝ w (X ω'))) Y ω * diffQuot F s δ (ρ (inner ℝ w (X ω)))
    else 0) ∂μ ≤ 0 := by
  let S : Ω → ℝ := fun ω => inner ℝ w (X ω)
  let P : Ω → ℝ := fun ω => ρ (S ω)
  let ξ : Ω → ℝ := fitRes P Y
  let M_s : ℝ := interiorLipConst F s
  let L : ℝ := M_s / δ
  have hMs_pos : 0 < M_s := interiorLipConst_pos F s
  have hL_pos : 0 < L := div_pos hMs_pos hδ.1
  let t : ℕ → ℝ := fun k => 1 / (((k : ℝ) + 2) * (L + 1))
  have ht_pos : ∀ k : ℕ, 0 < t k := fun k => by dsimp [t]; positivity
  have htL_le : ∀ k : ℕ, t k * L ≤ 1 := by
    intro k
    dsimp [t]
    rw [one_div_mul_eq_div, div_le_one (by positivity)]
    have hk : (0 : ℝ) ≤ k := Nat.cast_nonneg k
    nlinarith
  have hψ_mono_lip : ∀ k : ℕ,
      Monotone (fun p => p - t k * diffQuot F s δ p) ∧
        ∀ p₁ p₂ : ℝ, |(p₁ - t k * diffQuot F s δ p₁) - (p₂ - t k * diffQuot F s δ p₂)| ≤
          |p₁ - p₂| := by
    intro k
    have hmono_h := diffQuot_mono hF_conv hs hδ
    have hlip_h := abs_diffQuot_sub_le hF_conv hs hδ
    have hstep : ∀ p₁ p₂ : ℝ, p₁ ≤ p₂ →
        0 ≤ (p₂ - t k * diffQuot F s δ p₂) - (p₁ - t k * diffQuot F s δ p₁) ∧
          (p₂ - t k * diffQuot F s δ p₂) - (p₁ - t k * diffQuot F s δ p₁) ≤ p₂ - p₁ := by
      intro p₁ p₂ hp
      have hh_nonneg : 0 ≤ diffQuot F s δ p₂ - diffQuot F s δ p₁ :=
        sub_nonneg.mpr (hmono_h hp)
      have hh_le : diffQuot F s δ p₂ - diffQuot F s δ p₁ ≤ L * (p₂ - p₁) := by
        have h := hlip_h p₂ p₁
        rw [abs_of_nonneg hh_nonneg, abs_of_nonneg (sub_nonneg.mpr hp)] at h
        exact h
      have hmul_le : t k * (diffQuot F s δ p₂ - diffQuot F s δ p₁) ≤ p₂ - p₁ := by
        calc
          t k * (diffQuot F s δ p₂ - diffQuot F s δ p₁) ≤ t k * (L * (p₂ - p₁)) :=
            mul_le_mul_of_nonneg_left hh_le (ht_pos k).le
          _ = (t k * L) * (p₂ - p₁) := by ring
          _ ≤ 1 * (p₂ - p₁) :=
            mul_le_mul_of_nonneg_right (htL_le k) (sub_nonneg.mpr hp)
          _ = p₂ - p₁ := one_mul _
      have hmul_nonneg : 0 ≤ t k * (diffQuot F s δ p₂ - diffQuot F s δ p₁) :=
        mul_nonneg (ht_pos k).le hh_nonneg
      constructor <;> linarith
    refine ⟨fun p₁ p₂ hp => by linarith [(hstep p₁ p₂ hp).1], ?_⟩
    intro p₁ p₂
    rcases le_total p₁ p₂ with hp | hp
    · obtain ⟨h0, h1⟩ := hstep p₁ p₂ hp
      rw [abs_sub_comm, abs_of_nonneg h0, abs_sub_comm p₁ p₂, abs_of_nonneg (sub_nonneg.mpr hp)]
      exact h1
    · obtain ⟨h0, h1⟩ := hstep p₂ p₁ hp
      rw [abs_of_nonneg h0, abs_of_nonneg (sub_nonneg.mpr hp)]
      exact h1
  let ρ_seq : ℕ → ℝ → ℝ := fun k a => clampIcc 0 1 (ρ a - t k * diffQuot F s δ (ρ a))
  have hρ_seq : ∀ k : ℕ, IsProfile β (ρ_seq k) := by
    intro k
    refine ⟨((clampIcc_mono 0 1).comp (hψ_mono_lip k).1).comp hρ.1, ?_,
      fun a => clampIcc_mem zero_le_one _⟩
    rw [lipschitzWith_toNNReal_iff hβ.le]
    have hLρ := (lipschitzWith_toNNReal_iff hβ.le ρ).mp hρ.2.1
    intro x y
    exact le_trans (abs_clampIcc_sub_le 0 1 _ _)
      (le_trans ((hψ_mono_lip k).2 (ρ x) (ρ y)) (hLρ x y))
  let G_seq : ℕ → Ω → ℝ := fun k ω => ξ ω * ((ρ_seq k (S ω) - P ω) / t k)
  let G_lim : Ω → ℝ := fun ω =>
    if P ω ∈ Set.Ioo (0 : ℝ) 1 then ξ ω * diffQuot F s δ (P ω) else 0
  have hG_nonneg : ∀ k : ℕ, 0 ≤ ∫ ω, G_seq k ω ∂μ := by
    intro k
    have h0 := hVI (ρ_seq k) (hρ_seq k)
    have h1 : 0 ≤ (∫ ω, ξ ω * (ρ_seq k (S ω) - P ω) ∂μ) / t k :=
      div_nonneg h0 (ht_pos k).le
    rw [← MeasureTheory.integral_div] at h1
    simpa only [G_seq, mul_div_assoc] using h1
  have hS_meas : Measurable S := measurable_inner_comp hX_meas w
  have hP_meas : Measurable P := hρ.measurable.comp hS_meas
  have hr_meas : Measurable ξ := hP_meas.sub (measurable_yReal hY_meas)
  have hG_meas : ∀ k : ℕ, MeasureTheory.AEStronglyMeasurable (G_seq k) μ := by
    intro k
    have hρk_meas : Measurable (fun ω => ρ_seq k (S ω)) :=
      (hρ_seq k).measurable.comp hS_meas
    exact (hr_meas.mul ((hρk_meas.sub hP_meas).div_const (t k))).aestronglyMeasurable
  have hG_bound : ∀ k : ℕ, ∀ᵐ ω ∂μ, ‖G_seq k ω‖ ≤ M_s := by
    intro k
    refine Filter.Eventually.of_forall (fun ω => ?_)
    rw [Real.norm_eq_abs, abs_mul]
    have hr1 : |ξ ω| ≤ 1 := abs_fitRes_le_one (fun ω' => hρ.2.2 (S ω')) Y ω
    have hp_cl : clampIcc 0 1 (P ω) = P ω := clampIcc_of_mem (hρ.2.2 (S ω))
    have hdiff : |ρ_seq k (S ω) - P ω| ≤ t k * M_s := by
      dsimp [ρ_seq]
      rw [← hp_cl]
      refine le_trans (abs_clampIcc_sub_le 0 1 _ _) ?_
      have heq : P ω - t k * diffQuot F s δ (P ω) - P ω = -(t k * diffQuot F s δ (P ω)) := by ring
      rw [heq, abs_neg, abs_mul, abs_of_pos (ht_pos k)]
      exact mul_le_mul_of_nonneg_left (abs_diffQuot_le hF_conv hs hδ (P ω)) (ht_pos k).le
    have hquot : |(ρ_seq k (S ω) - P ω) / t k| ≤ M_s := by
      rw [abs_div, abs_of_pos (ht_pos k), div_le_iff₀ (ht_pos k)]
      linarith
    calc
      |ξ ω| * |(ρ_seq k (S ω) - P ω) / t k| ≤ 1 * M_s := by gcongr
      _ = M_s := one_mul _
  have ht_lim : Filter.Tendsto t Filter.atTop (nhds 0) := by
    have h0 : Filter.Tendsto (fun k : ℕ => (1 / ((k : ℝ) + 2)) / (L + 1))
        Filter.atTop (nhds (0 / (L + 1))) :=
      (tendsto_one_div_nat_add 2).div_const (L + 1)
    rw [zero_div] at h0
    refine h0.congr (fun k => ?_)
    dsimp [t]
    exact div_div 1 ((k : ℝ) + 2) (L + 1)
  have h_ae_end := ae_fitRes_eq_zero_of_not_mem_Ioo d Ω μ X Y hX_meas hY_meas β hβ w ρ hρ hVI
  have hG_lim : ∀ᵐ ω ∂μ, Filter.Tendsto (fun k => G_seq k ω) Filter.atTop (nhds (-G_lim ω)) := by
    filter_upwards [h_ae_end] with ω hω
    by_cases hp : P ω ∈ Set.Ioo (0 : ℝ) 1
    · have hcomb : Filter.Tendsto (fun k => P ω - t k * diffQuot F s δ (P ω))
          Filter.atTop (nhds (P ω)) := by
        simpa only [zero_mul, sub_zero] using
          (tendsto_const_nhds (x := P ω)).sub (ht_lim.mul_const (diffQuot F s δ (P ω)))
      have hev_mem : ∀ᶠ k in Filter.atTop,
          P ω - t k * diffQuot F s δ (P ω) ∈ Set.Ioo (0 : ℝ) 1 :=
        hcomb.eventually (isOpen_Ioo.mem_nhds hp)
      have hev_eq : (fun k => G_seq k ω) =ᶠ[Filter.atTop] fun _ => -G_lim ω := by
        filter_upwards [hev_mem] with k hk
        have hcl : ρ_seq k (S ω) = P ω - t k * diffQuot F s δ (P ω) :=
          clampIcc_of_mem ⟨hk.1.le, hk.2.le⟩
        have htk_ne : t k ≠ 0 := (ht_pos k).ne'
        dsimp [G_seq, G_lim]
        rw [if_pos hp, hcl]
        field_simp [htk_ne]
        ring
      exact tendsto_const_nhds.congr' hev_eq.symm
    · have hr0 : ξ ω = 0 := hω hp
      dsimp [G_seq, G_lim]
      rw [if_neg hp]
      simp [hr0]
  have h_tendsto_int :=
    MeasureTheory.tendsto_integral_of_dominated_convergence (fun _ => M_s)
      hG_meas (MeasureTheory.integrable_const M_s) hG_bound hG_lim
  have h_lim_nonneg : 0 ≤ ∫ ω, -G_lim ω ∂μ :=
    ge_of_tendsto' h_tendsto_int hG_nonneg
  rw [MeasureTheory.integral_neg] at h_lim_nonneg
  linarith

private lemma tendsto_diffQuot_deriv {F : ℝ → ℝ}
    (hF_diff : ∀ q ∈ Set.Ioo (0 : ℝ) 1, DifferentiableAt ℝ F q)
    {s : ℝ} (hs : s ∈ Set.Ioo (0 : ℝ) (1 / 3)) (p : ℝ) :
    Filter.Tendsto (fun m : ℕ => diffQuot F s (s / (2 * ((m : ℝ) + 1))) p)
      Filter.atTop (nhds (deriv F (clampIcc s (1 - s) p))) := by
  let q := clampIcc s (1 - s) p
  have hs_le : s ≤ 1 - s := by linarith [hs.2]
  have hq_Icc := clampIcc_mem hs_le p
  have hq : q ∈ Set.Ioo (0 : ℝ) 1 := ⟨by linarith [hs.1, hq_Icc.1], by linarith [hs.1, hq_Icc.2]⟩
  let δ_seq : ℕ → ℝ := fun m => s / (2 * ((m : ℝ) + 1))
  have hδ_pos : ∀ m : ℕ, 0 < δ_seq m := fun m => by
    dsimp [δ_seq]; exact div_pos hs.1 (by positivity)
  have hδ_lim : Filter.Tendsto δ_seq Filter.atTop (nhds 0) := by
    have h0 : Filter.Tendsto (fun m : ℕ => (s / 2) * (1 / ((m : ℝ) + 1)))
        Filter.atTop (nhds ((s / 2) * 0)) :=
      (tendsto_const_nhds (x := s / 2)).mul (tendsto_one_div_nat_add 1)
    rw [mul_zero] at h0
    refine h0.congr (fun m => ?_)
    dsimp [δ_seq]
    have hm : (m : ℝ) + 1 ≠ 0 := by positivity
    field_simp [hm]
  have hδ_right : Filter.Tendsto δ_seq Filter.atTop (nhdsWithin 0 (Set.Ioi 0)) :=
    tendsto_nhdsWithin_iff.mpr ⟨hδ_lim, Filter.Eventually.of_forall hδ_pos⟩
  have hδ_left : Filter.Tendsto (fun m => -δ_seq m) Filter.atTop (nhdsWithin 0 (Set.Iio 0)) :=
    tendsto_nhdsWithin_iff.mpr
      ⟨by simpa using hδ_lim.neg,
        Filter.Eventually.of_forall (fun m => neg_lt_zero.mpr (hδ_pos m))⟩
  have h_r := ((hF_diff q hq).hasDerivAt.tendsto_slope_zero_right).comp hδ_right
  have h_l := ((hF_diff q hq).hasDerivAt.tendsto_slope_zero_left).comp hδ_left
  have h_avg := (h_r.add h_l).const_mul ((1 : ℝ) / 2)
  have h_target : (1 : ℝ) / 2 * (deriv F q + deriv F q) = deriv F q := by ring
  rw [h_target] at h_avg
  refine h_avg.congr (fun m => ?_)
  have hne : δ_seq m ≠ 0 := (hδ_pos m).ne'
  change (1 : ℝ) / 2 * ((δ_seq m)⁻¹ * (F (q + δ_seq m) - F q) +
      (-δ_seq m)⁻¹ * (F (q + -δ_seq m) - F q)) =
    (F (q + δ_seq m) - F (q - δ_seq m)) / (2 * δ_seq m)
  have hq_neg : q + -δ_seq m = q - δ_seq m := by ring
  rw [hq_neg]
  field_simp [hne]
  ring

private lemma vi_clamped_deriv_le_zero
    (d : ℕ) (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin 2)
    (hX_meas : Measurable X) (hY_meas : Measurable Y)
    (β : ℝ) (hβ : 0 < β)
    (w : EuclideanSpace ℝ (Fin d)) (ρ : ℝ → ℝ)
    (hρ : IsProfile β ρ)
    (hVI : ∀ ρ' : ℝ → ℝ, IsProfile β ρ' →
      0 ≤ ∫ ω, fitRes (fun ω' => ρ (inner ℝ w (X ω'))) Y ω *
        (ρ' (inner ℝ w (X ω)) - ρ (inner ℝ w (X ω))) ∂μ)
    (F : ℝ → ℝ) (hF_conv : ConvexOn ℝ (Set.Icc (0 : ℝ) 1) F)
    (hF_diff : ∀ q ∈ Set.Ioo (0 : ℝ) 1, DifferentiableAt ℝ F q)
    {s : ℝ} (hs : s ∈ Set.Ioo (0 : ℝ) (1 / 3)) :
    let H_s : Ω → ℝ := fun ω =>
      if ρ (inner ℝ w (X ω)) ∈ Set.Ioo (0 : ℝ) 1 then
        fitRes (fun ω' => ρ (inner ℝ w (X ω'))) Y ω *
          deriv F (clampIcc s (1 - s) (ρ (inner ℝ w (X ω))))
      else 0
    Measurable H_s ∧ MeasureTheory.Integrable H_s μ ∧ ∫ ω, H_s ω ∂μ ≤ 0 := by
  intro H_s
  let S : Ω → ℝ := fun ω => inner ℝ w (X ω)
  let P : Ω → ℝ := fun ω => ρ (S ω)
  let ξ : Ω → ℝ := fitRes P Y
  let M_s : ℝ := interiorLipConst F s
  let δ_seq : ℕ → ℝ := fun m => s / (2 * ((m : ℝ) + 1))
  have hδ_mem : ∀ m : ℕ, δ_seq m ∈ Set.Ioc (0 : ℝ) (s / 2) := by
    intro m
    refine ⟨by dsimp [δ_seq]; exact div_pos hs.1 (by positivity), ?_⟩
    dsimp [δ_seq]
    rw [div_le_div_iff₀ (by positivity) (by norm_num)]
    have hm : (0 : ℝ) ≤ m := Nat.cast_nonneg m
    nlinarith [hs.1]
  let H_seq : ℕ → Ω → ℝ := fun m ω =>
    if P ω ∈ Set.Ioo (0 : ℝ) 1 then ξ ω * diffQuot F s (δ_seq m) (P ω) else 0
  have hS_meas : Measurable S := measurable_inner_comp hX_meas w
  have hP_meas : Measurable P := hρ.measurable.comp hS_meas
  have hr_meas : Measurable ξ := hP_meas.sub (measurable_yReal hY_meas)
  have hIoo_meas : MeasurableSet {ω : Ω | P ω ∈ Set.Ioo (0 : ℝ) 1} :=
    hP_meas isOpen_Ioo.measurableSet
  have hH_seq_meas : ∀ m : ℕ, Measurable (H_seq m) := by
    intro m
    have hd_meas : Measurable (fun ω => diffQuot F s (δ_seq m) (P ω)) :=
      (diffQuot_continuous hF_conv hs (hδ_mem m)).measurable.comp hP_meas
    exact Measurable.ite hIoo_meas (hr_meas.mul hd_meas) measurable_const
  have hH_lim_all : ∀ ω : Ω, Filter.Tendsto (fun m => H_seq m ω) Filter.atTop (nhds (H_s ω)) := by
    intro ω
    by_cases hp : P ω ∈ Set.Ioo (0 : ℝ) 1
    · dsimp [H_seq, H_s, P, S, ξ] at hp ⊢
      simp only [if_pos hp]
      exact (tendsto_diffQuot_deriv hF_diff hs (ρ (inner ℝ w (X ω)))).const_mul _
    · dsimp [H_seq, H_s, P, S, ξ] at hp ⊢
      simp only [if_neg hp]
      exact tendsto_const_nhds
  have hHs_meas : Measurable H_s :=
    measurable_of_tendsto_metrizable hH_seq_meas (tendsto_pi_nhds.mpr hH_lim_all)
  have hH_seq_bound : ∀ m : ℕ, ∀ ω : Ω, ‖H_seq m ω‖ ≤ M_s := by
    intro m ω
    rw [Real.norm_eq_abs]
    by_cases hp : P ω ∈ Set.Ioo (0 : ℝ) 1
    · dsimp [H_seq]
      rw [if_pos hp, abs_mul]
      have hr1 : |ξ ω| ≤ 1 := abs_fitRes_le_one (fun ω' => hρ.2.2 (S ω')) Y ω
      have hd_le := abs_diffQuot_le hF_conv hs (hδ_mem m) (P ω)
      calc
        |ξ ω| * |diffQuot F s (δ_seq m) (P ω)| ≤ 1 * M_s := by gcongr
        _ = M_s := one_mul _
    · dsimp [H_seq]
      rw [if_neg hp, abs_zero]
      exact (interiorLipConst_pos F s).le
  have hHs_bound : ∀ ω : Ω, ‖H_s ω‖ ≤ M_s := by
    intro ω
    exact le_of_tendsto' ((hH_lim_all ω).norm) (fun m => hH_seq_bound m ω)
  have hHs_int : MeasureTheory.Integrable H_s μ :=
    (MeasureTheory.integrable_const M_s).mono' hHs_meas.aestronglyMeasurable
      (Filter.Eventually.of_forall hHs_bound)
  have h_tendsto_int :=
    MeasureTheory.tendsto_integral_of_dominated_convergence (μ := μ) (fun _ => M_s)
      (fun m => (hH_seq_meas m).aestronglyMeasurable)
      (MeasureTheory.integrable_const M_s)
      (fun m => Filter.Eventually.of_forall (hH_seq_bound m))
      (Filter.Eventually.of_forall hH_lim_all)
  have h_seq_le_zero : ∀ m : ℕ, ∫ ω, H_seq m ω ∂μ ≤ 0 := fun m =>
    vi_diffQuot_le_zero d Ω μ X Y hX_meas hY_meas β hβ w ρ hρ hVI F hF_conv hs (hδ_mem m)
  have hHs_int_le : ∫ ω, H_s ω ∂μ ≤ 0 :=
    le_of_tendsto' h_tendsto_int h_seq_le_zero
  exact ⟨hHs_meas, hHs_int, hHs_int_le⟩

private lemma lower_bound_deriv_term {F : ℝ → ℝ}
    (hF_conv : ConvexOn ℝ (Set.Icc (0 : ℝ) 1) F)
    (hF_diff : ∀ q ∈ Set.Ioo (0 : ℝ) 1, DifferentiableAt ℝ F q)
    {M_F : ℝ} (hMF_nonneg : 0 ≤ M_F) (hMF : ∀ z ∈ Set.Icc (0 : ℝ) 1, |F z| ≤ M_F)
    {p : ℝ} (hp : p ∈ Set.Ioo (0 : ℝ) 1) (y : Fin 2) :
    -3 * M_F ≤ (p - yReal y) * deriv F p := by
  have hdiff_le : ∀ z ∈ Set.Icc (0 : ℝ) 1, F z - F p ≤ 2 * M_F := by
    intro z hz
    have h1 := le_abs_self (F z)
    have h2 := neg_abs_le (F p)
    have b1 := hMF z hz
    have b2 := hMF p ⟨hp.1.le, hp.2.le⟩
    linarith
  rcases yReal_eq_zero_or_one y with hy0 | hy1
  · rw [hy0]
    have hsub := convex_subgradient_Icc hF_conv hF_diff hp ⟨le_rfl, zero_le_one⟩
    have h2 := hdiff_le 0 ⟨le_rfl, zero_le_one⟩
    linarith
  · rw [hy1]
    have hsub := convex_subgradient_Icc hF_conv hF_diff hp ⟨zero_le_one, le_rfl⟩
    have h2 := hdiff_le 1 ⟨zero_le_one, le_rfl⟩
    linarith

private lemma lower_bound_clamped_deriv_term {F : ℝ → ℝ}
    (hF_conv : ConvexOn ℝ (Set.Icc (0 : ℝ) 1) F)
    (hF_diff : ∀ q ∈ Set.Ioo (0 : ℝ) 1, DifferentiableAt ℝ F q)
    {M_F : ℝ} (hMF_nonneg : 0 ≤ M_F) (hMF : ∀ z ∈ Set.Icc (0 : ℝ) 1, |F z| ≤ M_F)
    {s : ℝ} (hs : s ∈ Set.Ioo (0 : ℝ) (1 / 3))
    {p : ℝ} (hp : p ∈ Set.Ioo (0 : ℝ) 1) (y : Fin 2) :
    -3 * M_F ≤ (p - yReal y) * deriv F (clampIcc s (1 - s) p) := by
  have hs_le : s ≤ 1 - s := by linarith [hs.2]
  have hdiff_le : ∀ q ∈ Set.Ioo (0 : ℝ) 1, ∀ z ∈ Set.Icc (0 : ℝ) 1, F z - F q ≤ 2 * M_F := by
    intro q hq z hz
    have h1 := le_abs_self (F z)
    have h2 := neg_abs_le (F q)
    have b1 := hMF z hz
    have b2 := hMF q ⟨hq.1.le, hq.2.le⟩
    linarith
  rcases lt_or_ge p s with hps | hsp
  · have hcl : clampIcc s (1 - s) p = s := by
      unfold clampIcc
      rw [min_eq_right (le_trans hps.le hs_le), max_eq_left hps.le]
    rw [hcl]
    have hs_mem : s ∈ Set.Ioo (0 : ℝ) 1 := ⟨hs.1, by linarith [hs.2]⟩
    have hsub0 := le_trans
      (convex_subgradient_Icc hF_conv hF_diff hs_mem ⟨le_rfl, zero_le_one⟩)
      (hdiff_le s hs_mem 0 ⟨le_rfl, zero_le_one⟩)
    have hsub1 := le_trans
      (convex_subgradient_Icc hF_conv hF_diff hs_mem ⟨zero_le_one, le_rfl⟩)
      (hdiff_le s hs_mem 1 ⟨zero_le_one, le_rfl⟩)
    have hderiv_upper : deriv F s ≤ 3 * M_F := by
      have h1s : 2 / 3 < 1 - s := by linarith [hs.2]
      rcases le_or_gt (deriv F s) 0 with hd | hd
      · linarith
      · have hmul : (2 / 3) * deriv F s ≤ (1 - s) * deriv F s :=
          mul_le_mul_of_nonneg_right h1s.le hd.le
        linarith
    rcases yReal_eq_zero_or_one y with hy0 | hy1
    · rw [hy0, sub_zero]
      rcases le_or_gt 0 (deriv F s) with hd | hd
      · have hp_nonneg : 0 ≤ p * deriv F s := mul_nonneg hp.1.le hd
        linarith
      · have hmul : s * deriv F s ≤ p * deriv F s :=
          mul_le_mul_of_nonpos_right hps.le hd.le
        linarith
    · rw [hy1]
      rcases le_or_gt (deriv F s) 0 with hd | hd
      · have hmul : 0 ≤ (p - 1) * deriv F s :=
          mul_nonneg_of_nonpos_of_nonpos (by linarith [hp.2]) hd
        linarith
      · have hmul : (1 - p) * deriv F s ≤ 1 * (3 * M_F) :=
          mul_le_mul (by linarith [hp.1]) hderiv_upper hd.le zero_le_one
        linarith
  · rcases lt_or_ge (1 - s) p with hp1s | hp1s
    · have hcl : clampIcc s (1 - s) p = 1 - s := by
        unfold clampIcc
        rw [min_eq_left hp1s.le, max_eq_right hs_le]
      rw [hcl]
      have h1s_mem : 1 - s ∈ Set.Ioo (0 : ℝ) 1 := ⟨by linarith [hs.2], by linarith [hs.1]⟩
      have hsub0 := le_trans
        (convex_subgradient_Icc hF_conv hF_diff h1s_mem ⟨le_rfl, zero_le_one⟩)
        (hdiff_le (1 - s) h1s_mem 0 ⟨le_rfl, zero_le_one⟩)
      have hsub1 := le_trans
        (convex_subgradient_Icc hF_conv hF_diff h1s_mem ⟨zero_le_one, le_rfl⟩)
        (hdiff_le (1 - s) h1s_mem 1 ⟨zero_le_one, le_rfl⟩)
      have hderiv_lower : -3 * M_F ≤ deriv F (1 - s) := by
        have h1s : 2 / 3 < 1 - s := by linarith [hs.2]
        rcases le_or_gt 0 (deriv F (1 - s)) with hd | hd
        · linarith
        · have hmul : (2 / 3) * (-deriv F (1 - s)) ≤ (1 - s) * (-deriv F (1 - s)) :=
            mul_le_mul_of_nonneg_right h1s.le (by linarith)
          linarith
      rcases yReal_eq_zero_or_one y with hy0 | hy1
      · rw [hy0, sub_zero]
        rcases le_or_gt 0 (deriv F (1 - s)) with hd | hd
        · have hp_nonneg : 0 ≤ p * deriv F (1 - s) := mul_nonneg hp.1.le hd
          linarith
        · have hmul : p * (-deriv F (1 - s)) ≤ 1 * (3 * M_F) :=
            mul_le_mul hp.2.le (by linarith) (by linarith) zero_le_one
          linarith
      · rw [hy1]
        rcases le_or_gt (deriv F (1 - s)) 0 with hd | hd
        · have hmul : 0 ≤ (p - 1) * deriv F (1 - s) :=
            mul_nonneg_of_nonpos_of_nonpos (by linarith [hp.2]) hd
          linarith
        · have hmul : (1 - p) * deriv F (1 - s) ≤ s * deriv F (1 - s) :=
            mul_le_mul_of_nonneg_right (by linarith [hp1s]) hd.le
          linarith
    · rw [clampIcc_of_mem ⟨hsp, hp1s⟩]
      exact lower_bound_deriv_term hF_conv hF_diff hMF_nonneg hMF hp y

theorem convex_test_ineq
    (d : ℕ) (Ω : Type*) [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MeasureTheory.IsProbabilityMeasure μ]
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin 2)
    (hX_meas : Measurable X) (hY_meas : Measurable Y)
    (β : ℝ) (hβ : 0 < β)
    (w : EuclideanSpace ℝ (Fin d)) (ρ : ℝ → ℝ)
    (hρ : IsProfile β ρ)
    (hVI : ∀ ρ' : ℝ → ℝ, IsProfile β ρ' →
      0 ≤ ∫ ω, fitRes (fun ω' => ρ (inner ℝ w (X ω'))) Y ω *
        (ρ' (inner ℝ w (X ω)) - ρ (inner ℝ w (X ω))) ∂μ)
    (F : ℝ → ℝ)
    (hF_cont : ContinuousOn F (Set.Icc (0 : ℝ) 1))
    (hF_conv : ConvexOn ℝ (Set.Icc (0 : ℝ) 1) F)
    (hF_diff : ∀ q ∈ Set.Ioo (0 : ℝ) 1, DifferentiableAt ℝ F q) :
    MeasureTheory.Integrable
      (fun ω => if ρ (inner ℝ w (X ω)) ∈ Set.Ioo (0 : ℝ) 1 then
        fitRes (fun ω' => ρ (inner ℝ w (X ω'))) Y ω * deriv F (ρ (inner ℝ w (X ω)))
      else 0) μ ∧
    (∫ ω, (if ρ (inner ℝ w (X ω)) ∈ Set.Ioo (0 : ℝ) 1 then
        fitRes (fun ω' => ρ (inner ℝ w (X ω'))) Y ω * deriv F (ρ (inner ℝ w (X ω)))
      else 0) ∂μ) ≤ 0 := by
  obtain ⟨C_F, hCF⟩ := (isCompact_Icc.image_of_continuousOn hF_cont.norm).bddAbove
  let M_F : ℝ := max C_F 0
  have hMF_nonneg : 0 ≤ M_F := le_max_right C_F 0
  have hMF : ∀ z ∈ Set.Icc (0 : ℝ) 1, |F z| ≤ M_F := by
    intro z hz
    have h1 : ‖F z‖ ≤ C_F := hCF ⟨z, hz, rfl⟩
    rw [Real.norm_eq_abs] at h1
    exact le_trans h1 (le_max_left C_F 0)
  let S : Ω → ℝ := fun ω => inner ℝ w (X ω)
  let P : Ω → ℝ := fun ω => ρ (S ω)
  let ξ : Ω → ℝ := fitRes P Y
  let s_seq : ℕ → ℝ := fun n => 1 / ((n : ℝ) + 4)
  have hs_mem : ∀ n : ℕ, s_seq n ∈ Set.Ioo (0 : ℝ) (1 / 3) := by
    intro n
    refine ⟨by dsimp [s_seq]; positivity, ?_⟩
    dsimp [s_seq]
    rw [one_div_lt_one_div (by positivity) (by norm_num)]
    have hn : (0 : ℝ) ≤ n := Nat.cast_nonneg n
    linarith
  let H_seq : ℕ → Ω → ℝ := fun n ω =>
    if P ω ∈ Set.Ioo (0 : ℝ) 1 then
      ξ ω * deriv F (clampIcc (s_seq n) (1 - s_seq n) (P ω))
    else 0
  let H : Ω → ℝ := fun ω =>
    if P ω ∈ Set.Ioo (0 : ℝ) 1 then ξ ω * deriv F (P ω) else 0
  let g_seq : ℕ → Ω → ℝ := fun n ω => H_seq n ω + 3 * M_F
  let g : Ω → ℝ := fun ω => H ω + 3 * M_F
  have hH_seq_props : ∀ n : ℕ,
      Measurable (H_seq n) ∧ MeasureTheory.Integrable (H_seq n) μ ∧ ∫ ω, H_seq n ω ∂μ ≤ 0 :=
    fun n => vi_clamped_deriv_le_zero d Ω μ X Y hX_meas hY_meas β hβ w ρ hρ hVI F
      hF_conv hF_diff (hs_mem n)
  have hg_seq_nonneg : ∀ n : ℕ, ∀ ω : Ω, 0 ≤ g_seq n ω := by
    intro n ω
    dsimp [g_seq, H_seq]
    by_cases hp : P ω ∈ Set.Ioo (0 : ℝ) 1
    · rw [if_pos hp]
      have hlb := lower_bound_clamped_deriv_term hF_conv hF_diff hMF_nonneg hMF
        (hs_mem n) hp (Y ω)
      dsimp [ξ, fitRes]
      linarith
    · rw [if_neg hp]
      linarith
  have hg_nonneg : ∀ ω : Ω, 0 ≤ g ω := by
    intro ω
    dsimp [g, H]
    by_cases hp : P ω ∈ Set.Ioo (0 : ℝ) 1
    · rw [if_pos hp]
      have hlb := lower_bound_deriv_term hF_conv hF_diff hMF_nonneg hMF hp (Y ω)
      dsimp [ξ, fitRes]
      linarith
    · rw [if_neg hp]
      linarith
  have hs_lim : Filter.Tendsto s_seq Filter.atTop (nhds 0) := tendsto_one_div_nat_add 4
  have hg_ev : ∀ ω : Ω, (fun n => g_seq n ω) =ᶠ[Filter.atTop] fun _ => g ω := by
    intro ω
    by_cases hp : P ω ∈ Set.Ioo (0 : ℝ) 1
    · have hp_sub : 0 < 1 - P ω := sub_pos.mpr hp.2
      have hev1 : ∀ᶠ n in Filter.atTop, s_seq n < P ω :=
        hs_lim.eventually (gt_mem_nhds hp.1)
      have hev2 : ∀ᶠ n in Filter.atTop, s_seq n < 1 - P ω :=
        hs_lim.eventually (gt_mem_nhds hp_sub)
      filter_upwards [hev1, hev2] with n hn1 hn2
      have hcl : clampIcc (s_seq n) (1 - s_seq n) (P ω) = P ω :=
        clampIcc_of_mem ⟨hn1.le, by linarith⟩
      dsimp [g_seq, g, H_seq, H]
      rw [if_pos hp, if_pos hp, hcl]
    · refine Filter.Eventually.of_forall (fun n => ?_)
      dsimp [g_seq, g, H_seq, H]
      rw [if_neg hp, if_neg hp]
  have hg_lim : ∀ ω : Ω, Filter.Tendsto (fun n => g_seq n ω) Filter.atTop (nhds (g ω)) :=
    fun ω => tendsto_const_nhds.congr' (hg_ev ω).symm
  have hg_seq_meas : ∀ n : ℕ, Measurable (g_seq n) :=
    fun n => (hH_seq_props n).1.add measurable_const
  have hg_meas : Measurable g :=
    measurable_of_tendsto_metrizable hg_seq_meas (tendsto_pi_nhds.mpr hg_lim)
  have hg_seq_int : ∀ n : ℕ, MeasureTheory.Integrable (g_seq n) μ :=
    fun n => (hH_seq_props n).2.1.add (MeasureTheory.integrable_const (3 * M_F))
  have hg_seq_lint_le : ∀ n : ℕ,
      ∫⁻ ω, ENNReal.ofReal (g_seq n ω) ∂μ ≤ ENNReal.ofReal (3 * M_F) := by
    intro n
    rw [← MeasureTheory.ofReal_integral_eq_lintegral_ofReal (hg_seq_int n)
      (Filter.Eventually.of_forall (hg_seq_nonneg n))]
    apply ENNReal.ofReal_le_ofReal
    rw [MeasureTheory.integral_add (hH_seq_props n).2.1 (MeasureTheory.integrable_const (3 * M_F)),
      MeasureTheory.integral_const]
    simp only [MeasureTheory.probReal_univ, one_smul]
    linarith [(hH_seq_props n).2.2]
  have h_liminf_pt : ∀ ω : Ω,
      Filter.liminf (fun n => ENNReal.ofReal (g_seq n ω)) Filter.atTop = ENNReal.ofReal (g ω) := by
    intro ω
    have hev_enn : (fun n => ENNReal.ofReal (g_seq n ω)) =ᶠ[Filter.atTop]
        fun _ => ENNReal.ofReal (g ω) := by
      filter_upwards [hg_ev ω] with n hn
      rw [hn]
    exact (tendsto_const_nhds.congr' hev_enn.symm).liminf_eq
  have h_fatou : ∫⁻ ω, ENNReal.ofReal (g ω) ∂μ ≤ ENNReal.ofReal (3 * M_F) := by
    calc
      ∫⁻ ω, ENNReal.ofReal (g ω) ∂μ
        = ∫⁻ ω, Filter.liminf (fun n => ENNReal.ofReal (g_seq n ω)) Filter.atTop ∂μ := by
          congr 1; ext ω; exact (h_liminf_pt ω).symm
      _ ≤ Filter.liminf (fun n => ∫⁻ ω, ENNReal.ofReal (g_seq n ω) ∂μ) Filter.atTop :=
        MeasureTheory.lintegral_liminf_le (fun n => ENNReal.measurable_ofReal.comp (hg_seq_meas n))
      _ ≤ ENNReal.ofReal (3 * M_F) :=
        Filter.liminf_le_of_frequently_le' (Filter.Frequently.of_forall hg_seq_lint_le)
  have hg_lint_ne_top : ∫⁻ ω, ENNReal.ofReal (g ω) ∂μ ≠ ⊤ :=
    ne_top_of_le_ne_top ENNReal.ofReal_ne_top h_fatou
  have hg_int : MeasureTheory.Integrable g μ :=
    (MeasureTheory.lintegral_ofReal_ne_top_iff_integrable hg_meas.aestronglyMeasurable
      (Filter.Eventually.of_forall hg_nonneg)).mp hg_lint_ne_top
  have hg_int_le : ∫ ω, g ω ∂μ ≤ 3 * M_F := by
    have h_ofReal : ENNReal.ofReal (∫ ω, g ω ∂μ) ≤ ENNReal.ofReal (3 * M_F) := by
      rw [MeasureTheory.ofReal_integral_eq_lintegral_ofReal hg_int
        (Filter.Eventually.of_forall hg_nonneg)]
      exact h_fatou
    exact (ENNReal.ofReal_le_ofReal_iff (by positivity)).mp h_ofReal
  have hH_eq : H = fun ω => g ω - 3 * M_F := by
    ext ω; dsimp [g]; ring
  have hH_int : MeasureTheory.Integrable H μ := by
    rw [hH_eq]
    exact hg_int.sub (MeasureTheory.integrable_const (3 * M_F))
  have hH_int_le : ∫ ω, H ω ∂μ ≤ 0 := by
    rw [hH_eq, MeasureTheory.integral_sub hg_int (MeasureTheory.integrable_const (3 * M_F)),
      MeasureTheory.integral_const]
    simp only [MeasureTheory.probReal_univ, one_smul]
    linarith
  exact ⟨hH_int, hH_int_le⟩

end UL.Proof_thm_3_2

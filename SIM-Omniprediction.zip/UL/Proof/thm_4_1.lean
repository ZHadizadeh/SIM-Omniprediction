import UL.Stmt.thm_4_1
import UL.Stmt.thm_A_9
import UL.Proof.thm_4_1.H1
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_thm_4_1 (h_thm_A_9 : S_thm_A_9) : S_thm_4_1 := by
  intro K hK R β L hR hβ hL hcond
  obtain ⟨P, Φ, hProb, hUnif, hEnt, ⟨M, b, c₀, hΦ_quad⟩, _, _, h_pos, h_zero⟩ :=
    h_thm_A_9 K hK R β L hR hβ hL hcond
  refine ⟨P, Φ, hProb, hUnif, hEnt, Proof_thm_4_1.quadratic_decomp Φ M b c₀ hΦ_quad, ?_, ?_⟩
  · intro r hr1 hrm B hB
    obtain ⟨h_lb, _, W₀, ρ₀, _, _, hW₀_rk, hW₀_frob, hρ₀_lip, _, _, h_att⟩ :=
      h_pos r hr1 hrm B hB
    have hp₀ : (ρ₀ ∘ W₀) ∈
        {p : EuclideanSpace ℝ (Fin (K - 1)) → Simplex K |
          ∃ k ≤ r, ∃ (A : EuclideanSpace ℝ (Fin (K - 1)) →ₗ[ℝ] EuclideanSpace ℝ (Fin k))
            (h : EuclideanSpace ℝ (Fin k) → Simplex K),
            frobeniusNorm A ≤ R ∧ LipschitzWith (Real.toNNReal B) h ∧
            ∀ x, p x = h (A x)} :=
      Proof_thm_4_1.rank_to_feasible W₀ ρ₀ hW₀_rk hW₀_frob hρ₀_lip
    refine ⟨?_, ρ₀ ∘ W₀, hp₀, h_att⟩
    apply le_antisymm
    · exact le_trans (biInf_le _ hp₀) (le_of_eq h_att)
    · refine le_iInf₂ fun p hp => ?_
      rcases hp with ⟨k, hk, A, h, hA, hh, hp_eq⟩
      obtain ⟨W, ρ, hW_rk, hW_frob, hρ_lip, h_eq⟩ :=
        Proof_thm_4_1.feasible_to_rank hK hrm hk A h hA hh
      have hp_fun : ρ ∘ W = p := funext fun x => (h_eq x).trans (hp_eq x).symm
      simpa [hp_fun] using h_lb W ρ hW_rk hW_frob hρ_lip
  · intro B hB
    obtain ⟨h_lb, _, W₀, ρ₀, _, _, hW₀_rk, hW₀_frob, hρ₀_lip, _, _, h_att⟩ :=
      h_zero B hB
    have hp₀ : (ρ₀ ∘ W₀) ∈
        {p : EuclideanSpace ℝ (Fin (K - 1)) → Simplex K |
          ∃ k ≤ 0, ∃ (A : EuclideanSpace ℝ (Fin (K - 1)) →ₗ[ℝ] EuclideanSpace ℝ (Fin k))
            (h : EuclideanSpace ℝ (Fin k) → Simplex K),
            frobeniusNorm A ≤ R ∧ LipschitzWith (Real.toNNReal B) h ∧
            ∀ x, p x = h (A x)} :=
      Proof_thm_4_1.rank_to_feasible W₀ ρ₀ hW₀_rk hW₀_frob hρ₀_lip
    refine ⟨?_, ρ₀ ∘ W₀, hp₀, h_att⟩
    apply le_antisymm
    · exact le_trans (biInf_le _ hp₀) (le_of_eq h_att)
    · refine le_iInf₂ fun p hp => ?_
      rcases hp with ⟨k, hk, A, h, hA, hh, hp_eq⟩
      obtain ⟨W, ρ, hW_rk, hW_frob, hρ_lip, h_eq⟩ :=
        Proof_thm_4_1.feasible_to_rank hK (Nat.zero_le _) hk A h hA hh
      have hp_fun : ρ ∘ W = p := funext fun x => (h_eq x).trans (hp_eq x).symm
      simpa [hp_fun] using h_lb W ρ hW_rk hW_frob hρ_lip

end UL

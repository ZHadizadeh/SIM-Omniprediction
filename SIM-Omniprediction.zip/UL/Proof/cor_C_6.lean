import UL.Arxiv.BinarySampleRounding
import UL.Stmt.cor_C_6
import UL.Stmt.cit_brouwer
import UL.Stmt.lem_C_3
import UL.Proof.cor_C_6.H1_UniverseTransfer
import UL.Proof.cor_C_6.H2_EmpiricalLearner
import UL.Proof.cor_C_6.H3_BinaryProfiles
import UL.Proof.cor_C_6.H4_SampleRate
set_option autoImplicit false

namespace UL

/-- A Borel choice from countably coded training samples. -/
theorem P_cor_C_6_measurable (h_cit_brouwer : S_cit_brouwer) (h_lem_C_3 : S_lem_C_3) : BinaryLearningStatement true := by
  classical
  let _ := h_cit_brouwer
  obtain ⟨C_2, hC2_pos, h_unif⟩ := Proof_cor_C_6.lem_C_3_binary_transfer h_lem_C_3
  unfold BinaryLearningStatement
  let K₀ : ℝ := max (4 * (2 * C_2)) 1
  let C : ℝ := 64 * K₀ ^ 2
  have hK₀_pos : 0 < K₀ := lt_of_lt_of_le zero_lt_one (le_max_right _ _)
  have hC_pos : 0 < C := by positivity
  refine ⟨C, hC_pos, ?_⟩
  intro X _ _ _ _ _ _ L R β lam M B hL hR hβ hlam hM hB
  dsimp only
  let D_bin : ℝ := M + L * R + B * lam * L * R
  have hB_pos : 0 < B := lt_of_lt_of_le hβ hB
  have hD_bin_pos : 0 < D_bin := by positivity
  intro ε δ hε0 hεD hδ0 hδ1 n hn hn_large
  obtain ⟨baseW, baseRho, hbase, hemp⟩ :=
    Proof_cor_C_6.exists_empirical_monotone_learner X R β B hR hβ hB n hn
  let η := ε / (2 * ((lam * B + 1) * R))
  have hη : 0 < η := by dsimp [η]; positivity
  obtain ⟨code, hcode, hnear⟩ := Arxiv.BinaryRounding.sampleCodes X η hη
  let encode (s : Fin n → X × Fin 2) := fun i => (code (s i).1, (s i).2)
  let decode (a : Fin n → ℕ × Fin 2) := fun i => (TopologicalSpace.denseSeq X (a i).1, (a i).2)
  let rounded := decode ∘ encode
  let learnerW := baseW ∘ rounded
  let learnerRho := baseRho ∘ rounded
  have h_learner_props s := hbase (rounded s)
  have hJoint := Arxiv.BinaryRounding.jointEvaluation code hcode
    (baseW ∘ decode) (baseRho ∘ decode) (fun a => (hbase (decode a)).2.2.1.continuous)
  refine ⟨learnerW, learnerRho, ⟨h_learner_props, hJoint⟩, ?_⟩
  intro ν _ hX_bound Ω _ μ _ X_samp Y_samp hX_meas hY_meas hindep hident
  by_cases hBlam : 1 ≤ B * lam
  · let C_lip : ℝ := B * lam
    let M₀ : ℝ := 2 * M + L * R
    have hC_lip_pos : 0 < C_lip := mul_pos hB_pos hlam
    have hM₀_pos : 0 < M₀ := by positivity
    have hδ_lt_one : δ < 1 := by linarith
    obtain ⟨E, hE_meas, hE_prob, hE_good⟩ :=
      h_unif X L R C_lip M₀ hL hR hC_lip_pos hM₀_pos n hn δ hδ0 hδ_lt_one
        ν hX_bound Ω μ X_samp Y_samp hX_meas hY_meas hindep hident
    refine ⟨E, hE_meas, hE_prob, ?_⟩
    intro ω hω
    obtain ⟨hx_norm, h_sup⟩ := hE_good ω hω
    let sample : Fin n → X × Fin 2 := fun i => (X_samp i ω, Y_samp i ω)
    intro φ U φ_ext hφ hU_open hU_sub hφ_ext hφ_diff hφ_cont_deriv hφ_M hφ_lip
    have h_props := h_learner_props sample
    let D₀ : ℝ := M₀ + C_lip * (L * R)
    let bound : ℝ :=
      C_2 * (D₀ * Real.log (2 * (n : ℝ)) + M₀ * Real.sqrt (Real.log (2 / δ))) /
        Real.sqrt (n : ℝ)
    have hLR_pos : 0 < L * R := mul_pos hL hR
    have hBlamLR_pos : 0 < B * lam * L * R := by positivity
    have hD₀_le : D₀ ≤ 2 * D_bin := by
      dsimp [D₀, M₀, C_lip, D_bin]
      linarith
    have hM₀_le : M₀ ≤ 2 * D_bin := by
      dsimp [M₀, D_bin]
      linarith
    have h_2bound_le_eps : 2 * bound ≤ ε / 2 := by
      have hh := 
        Proof_cor_C_6.two_mul_bound_le_eps (2 * C_2) D_bin D₀ M₀ ε δ n
          (by positivity) hD_bin_pos hD₀_le hM₀_le hε0 hεD hδ0 hδ1 hn hn_large
      suffices 4 * bound ≤ ε by linarith only [this]
      convert hh using 1 <;> dsimp [bound] <;> ring
    have h_le_sInf :
        (∫ xy, binaryMatchingLoss φ
            (deriv φ_ext (learnerRho sample (inner ℝ (learnerW sample) xy.1))) xy.2 ∂ν) - ε ≤
          sInf ((fun v : X =>
            ∫ xy, binaryMatchingLoss φ (inner ℝ v xy.1) xy.2 ∂ν) '' {v : X | ‖v‖ ≤ R}) := by
      refine le_csInf ?_ ?_
      · refine ⟨∫ xy, binaryMatchingLoss φ (inner ℝ (0 : X) xy.1) xy.2 ∂ν, ⟨0, ?_, rfl⟩⟩
        simp [hR.le]
      · rintro _ ⟨v, hv, rfl⟩
        have hv_norm : ‖v‖ ≤ R := hv
        have h_round := hemp (rounded sample) φ U φ_ext hφ hU_open hU_sub hφ_ext hφ_diff v hv_norm
        have h_emp := Arxiv.BinaryRounding.empiricalTransfer hn
          (fun i => (sample i).1) (fun i => (rounded sample i).1) (fun i => (sample i).2)
          hB_pos.le hR.le hlam.le (fun i => hnear (sample i).1)
          h_props.1 hv_norm h_props.2.2.1 h_props.2.2.2 hφ.2.1 hφ_lip h_round
        have herr : (lam * B + 1) * R * η = ε / 2 := by
          dsimp [η]
          field_simp [hR.ne', show lam * B + 1 ≠ 0 by positivity] <;> ring
        have h_pop :=
          Proof_cor_C_6.population_comparison_of_uniform_dev X
            hL hR hβ hlam hM hB hBlam hn ν hX_bound
            (fun i => X_samp i ω) (fun i => Y_samp i ω) hx_norm h_sup
            h_props.1 h_props.2.2.1 h_props.2.2.2
            hφ hU_open hU_sub hφ_ext hφ_diff hφ_cont_deriv hφ_M hφ_lip hv_norm h_emp
        change (∫ xy, binaryMatchingLoss φ
            (deriv φ_ext (learnerRho sample (inner ℝ (learnerW sample) xy.1))) xy.2 ∂ν) ≤
          (∫ xy, binaryMatchingLoss φ (inner ℝ v xy.1) xy.2 ∂ν) +
            2 * bound + (lam * B + 1) * R * η at h_pop
        dsimp only
        linarith only [h_pop, herr, h_2bound_le_eps]
    linarith
  · refine ⟨Set.univ, MeasurableSet.univ, ?_, ?_⟩
    · rw [MeasureTheory.measure_univ, ENNReal.toReal_one]
      linarith
    · intro ω _ φ U φ_ext hφ hU_open hU_sub hφ_ext hφ_diff _ _ hφ_lip
      exfalso
      have h1 : 1 ≤ β * lam :=
        Proof_cor_C_6.one_le_beta_mul_lam hβ hlam hφ hU_open hU_sub hφ_ext hφ_diff hφ_lip
      have h2 : β * lam ≤ B * lam := mul_le_mul_of_nonneg_right hB hlam.le
      exact hBlam (le_trans h1 h2)

theorem P_cor_C_6 (hb : S_cit_brouwer) (hu : S_lem_C_3) : S_cor_C_6 := by
  obtain ⟨C,hC,h⟩ := P_cor_C_6_measurable hb hu
  refine ⟨C,hC,?_⟩
  intro X _ _ _ _ _ _ L R β lam M B hL hR hβ hlam hM hB
  dsimp only
  intro ε δ hε hεD hδ hδ' n hn hsize
  obtain ⟨w,ρ,hprop,hrisk⟩ :=
    h X L R β lam M B hL hR hβ hlam hM hB ε δ hε hεD hδ hδ' n hn hsize
  exact ⟨w,ρ,hprop.1,hrisk⟩

end UL

import Mathlib
import UL.Def.def_2_1
import UL.Def.def_2_matching
import UL.Def.def_5_smooth
import UL.Proof.lem_A_5.H1_Simplex
import UL.Proof.lem_C_2.H1_HilbertSchmidt
set_option autoImplicit false

namespace UL.Proof_thm_5_1

open Set Filter Topology

/-! ### Coordinate, `matchingPotential`, and `matchingLoss` Lipschitz bounds -/

lemma coord_abs_le_norm {K : ℕ} (v : EuclideanSpace ℝ (Fin K)) (y : Fin K) :
    |v y| ≤ ‖v‖ := by
  have hsq : |v y| ^ 2 ≤ ‖v‖ ^ 2 := by
    rw [EuclideanSpace.norm_sq_eq, sq_abs]
    have h1 : (v y) ^ 2 = ‖v.ofLp y‖ ^ 2 := by
      rw [Real.norm_eq_abs, sq_abs]
    rw [h1]
    exact Finset.single_le_sum (f := fun j : Fin K => ‖v.ofLp j‖ ^ 2)
      (fun j _ => sq_nonneg _) (Finset.mem_univ y)
  nlinarith [norm_nonneg v, abs_nonneg (v y)]

lemma matchingPotential_sub_le {K : ℕ} (hK : 2 ≤ K) {Φ : UL.Simplex K → ℝ}
    (hΦ : Continuous Φ) (a a' : EuclideanSpace ℝ (Fin K)) :
    UL.matchingPotential Φ a - UL.matchingPotential Φ a' ≤ 2 * ‖a - a'‖ := by
  haveI : Nonempty (UL.Simplex K) :=
    ⟨⟨UL.uniformVec K, UL.Proof_lem_A_5.uniformVec_mem_simplex hK⟩⟩
  haveI : CompactSpace (UL.Simplex K) :=
    isCompact_iff_compactSpace.mp (UL.Proof_lem_A_5.isCompact_simplex K)
  have hcont' : Continuous (fun q : UL.Simplex K =>
      inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) a' - Φ q) :=
    ((continuous_subtype_val.sub continuous_const).inner continuous_const).sub hΦ
  have hbdd' : BddAbove (Set.range (fun q : UL.Simplex K =>
      inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) a' - Φ q)) :=
    (isCompact_range hcont').bddAbove
  have hle : UL.matchingPotential Φ a ≤ UL.matchingPotential Φ a' + 2 * ‖a - a'‖ := by
    unfold UL.matchingPotential
    refine ciSup_le fun q => ?_
    have hq_le : inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) a' - Φ q ≤
        ⨆ r : UL.Simplex K,
          (inner ℝ ((r : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) a' - Φ r) :=
      le_ciSup hbdd' q
    have hqu : ‖(q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K‖ ≤ 2 := by
      calc ‖(q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K‖
          ≤ ‖(q : EuclideanSpace ℝ (Fin K))‖ + ‖UL.uniformVec K‖ := norm_sub_le _ _
        _ ≤ 1 + 1 := add_le_add (UL.Proof_lem_A_5.norm_le_one_of_mem_simplex q.2)
            (UL.Proof_lem_A_5.norm_le_one_of_mem_simplex
              (UL.Proof_lem_A_5.uniformVec_mem_simplex hK))
        _ = 2 := by norm_num
    have hdiff : (inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) a - Φ q) -
        (inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) a' - Φ q) =
        inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) (a - a') := by
      rw [sub_sub_sub_cancel_right, ← inner_sub_right]
    have hcs : inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - UL.uniformVec K) (a - a') ≤
        2 * ‖a - a'‖ :=
      le_trans (real_inner_le_norm _ _)
        (mul_le_mul_of_nonneg_right hqu (norm_nonneg _))
    linarith
  linarith

lemma abs_matchingPotential_sub_le {K : ℕ} (hK : 2 ≤ K) {Φ : UL.Simplex K → ℝ}
    (hΦ : Continuous Φ) (a a' : EuclideanSpace ℝ (Fin K)) :
    |UL.matchingPotential Φ a - UL.matchingPotential Φ a'| ≤ 2 * ‖a - a'‖ := by
  rw [abs_le]
  refine ⟨?_, matchingPotential_sub_le hK hΦ a a'⟩
  have h := matchingPotential_sub_le hK hΦ a' a
  rw [norm_sub_rev] at h
  linarith

lemma matchingLoss_lipschitz {K : ℕ} (hK : 2 ≤ K) {Φ : UL.Simplex K → ℝ}
    (hΦ : Continuous Φ) (a a' : EuclideanSpace ℝ (Fin K)) (y : Fin K) :
    |UL.matchingLoss Φ a y - UL.matchingLoss Φ a' y| ≤ 3 * ‖a - a'‖ := by
  have hpot := abs_matchingPotential_sub_le hK hΦ a a'
  have hcoord : |a y - a' y| ≤ ‖a - a'‖ := coord_abs_le_norm (a - a') y
  have heq : UL.matchingLoss Φ a y - UL.matchingLoss Φ a' y =
      (UL.matchingPotential Φ a - UL.matchingPotential Φ a') - (a y - a' y) := by
    unfold UL.matchingLoss; ring
  rw [heq]
  calc |(UL.matchingPotential Φ a - UL.matchingPotential Φ a') - (a y - a' y)|
      ≤ |UL.matchingPotential Φ a - UL.matchingPotential Φ a'| + |a y - a' y| :=
        abs_sub _ _
    _ ≤ 2 * ‖a - a'‖ + ‖a - a'‖ := add_le_add hpot hcoord
    _ = 3 * ‖a - a'‖ := by ring

lemma matchingLoss_zero {K : ℕ} (Φ : UL.Simplex K → ℝ) (y : Fin K) :
    UL.matchingLoss Φ 0 y = UL.matchingPotential Φ 0 := by
  simp [UL.matchingLoss]

lemma abs_matchingLoss_sub_pot0_le {K : ℕ} (hK : 2 ≤ K) {Φ : UL.Simplex K → ℝ}
    (hΦ : Continuous Φ) (a : EuclideanSpace ℝ (Fin K)) (y : Fin K) :
    |UL.matchingLoss Φ a y - UL.matchingPotential Φ 0| ≤ 3 * ‖a‖ := by
  have h := matchingLoss_lipschitz hK hΦ a 0 y
  rwa [matchingLoss_zero, sub_zero] at h

lemma continuous_matchingLoss_y {K : ℕ} (hK : 2 ≤ K) {Φ : UL.Simplex K → ℝ}
    (hΦ : Continuous Φ) (y : Fin K) :
    Continuous (fun a : EuclideanSpace ℝ (Fin K) => UL.matchingLoss Φ a y) := by
  have hlip : LipschitzWith 3 (fun a : EuclideanSpace ℝ (Fin K) => UL.matchingLoss Φ a y) := by
    rw [lipschitzWith_iff_dist_le_mul]
    intro a a'
    rw [Real.dist_eq, dist_eq_norm]
    exact_mod_cast matchingLoss_lipschitz hK hΦ a a' y
  exact hlip.continuous

lemma continuous_matchingLoss_pair {K : ℕ} (hK : 2 ≤ K) {Φ : UL.Simplex K → ℝ}
    (hΦ : Continuous Φ) :
    Continuous (fun p : EuclideanSpace ℝ (Fin K) × Fin K => UL.matchingLoss Φ p.1 p.2) := by
  have heq : (fun p : EuclideanSpace ℝ (Fin K) × Fin K => UL.matchingLoss Φ p.1 p.2) =
      fun p => ∑ y : Fin K, (if p.2 = y then (1 : ℝ) else 0) * UL.matchingLoss Φ p.1 y := by
    funext p
    simp
  rw [heq]
  refine continuous_finset_sum _ fun y _ => Continuous.mul ?_ ?_
  · exact (continuous_of_discreteTopology (f := fun z : Fin K => if z = y then (1 : ℝ) else 0)).comp
      continuous_snd
  · exact (continuous_matchingLoss_y hK hΦ y).comp continuous_fst

lemma finiteCanonicalLoss_lipschitz_on_simplex {K : ℕ} (hK : 2 ≤ K)
    {β lam M : ℝ} {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    {q q' : EuclideanSpace ℝ (Fin K)} (hq : q ∈ UL.Simplex K) (hq' : q' ∈ UL.Simplex K)
    (y : Fin K) :
    |UL.matchingLoss Φ (UL.finiteCanonicalAction Φ q) y -
      UL.matchingLoss Φ (UL.finiteCanonicalAction Φ q') y| ≤ (3 * lam) * ‖q - q'‖ := by
  calc |UL.matchingLoss Φ (UL.finiteCanonicalAction Φ q) y -
        UL.matchingLoss Φ (UL.finiteCanonicalAction Φ q') y|
      ≤ 3 * ‖UL.simplexGrad Φ q - UL.simplexGrad Φ q'‖ :=
        matchingLoss_lipschitz hK hΦ.1.2.1 _ _ y
    _ ≤ 3 * (lam * ‖q - q'‖) :=
        mul_le_mul_of_nonneg_left (hΦ.2.2.2.2.1 q hq q' hq') (by norm_num)
    _ = (3 * lam) * ‖q - q'‖ := by ring

lemma abs_finiteCanonicalLoss_sub_pot0_le {K : ℕ} (hK : 2 ≤ K)
    {β lam M : ℝ} {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    {q : EuclideanSpace ℝ (Fin K)} (hq : q ∈ UL.Simplex K) (y : Fin K) :
    |UL.matchingLoss Φ (UL.finiteCanonicalAction Φ q) y - UL.matchingPotential Φ 0| ≤
      3 * M := by
  calc |UL.matchingLoss Φ (UL.finiteCanonicalAction Φ q) y - UL.matchingPotential Φ 0|
      ≤ 3 * ‖UL.simplexGrad Φ q‖ := abs_matchingLoss_sub_pot0_le hK hΦ.1.2.1 _ y
    _ ≤ 3 * M := mul_le_mul_of_nonneg_left (hΦ.2.2.2.2.2 q hq) (by norm_num)

/-! ### Candidate hypotheses and Arzelà–Ascoli finite net -/

abbrev CandType (d K : ℕ) : Type :=
  (EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K) ×
    (UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K))

def IsCand {d K : ℕ} (R β : ℝ) (h : CandType d K) : Prop :=
  UL.hilbertSchmidtNorm h.1 ≤ R ∧
  (∀ s : UL.ZeroSumSubspace K, h.2 s ∈ UL.Simplex K) ∧
  (∀ s s' : UL.ZeroSumSubspace K, ‖h.2 s - h.2 s'‖ ≤ β * ‖s - s'‖)

noncomputable def defaultCand (d K : ℕ) : CandType d K :=
  (0, fun _ => UL.uniformVec K)

lemma isCand_default {d K : ℕ} (hK : 2 ≤ K) {R β : ℝ} (hR : 0 < R) (hβ : 0 < β) :
    IsCand R β (defaultCand d K) := by
  refine ⟨?_, fun _ => UL.Proof_lem_A_5.uniformVec_mem_simplex hK, fun s s' => ?_⟩
  · rw [defaultCand, UL.Proof_lem_C_2.hilbertSchmidtNorm_zero]
    exact hR.le
  · dsimp [defaultCand]
    rw [sub_self, norm_zero]
    exact mul_nonneg hβ.le (norm_nonneg _)

lemma lipschitzWith_cand_head {d K : ℕ} {R β : ℝ} (hβ : 0 < β)
    {h : CandType d K} (hh : IsCand R β h) :
    LipschitzWith (Real.toNNReal β) h.2 := by
  rw [lipschitzWith_iff_dist_le_mul]
  intro s s'
  rw [dist_eq_norm, dist_eq_norm, Real.coe_toNNReal β hβ.le]
  exact hh.2.2 s s'

lemma continuous_forecast_action {d K : ℕ} {R β lam M : ℝ} (hβ : 0 < β)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    {h : CandType d K} (hh : IsCand R β h) :
    Continuous (fun x : EuclideanSpace ℝ (Fin d) =>
      UL.finiteCanonicalAction Φ (h.2 (h.1 x))) := by
  have hlam : 0 < lam := hΦ.2.1
  have hlip_grad : LipschitzOnWith (Real.toNNReal lam) (UL.simplexGrad Φ) (UL.Simplex K) := by
    rw [lipschitzOnWith_iff_dist_le_mul]
    intro q hq q' hq'
    rw [dist_eq_norm, dist_eq_norm, Real.coe_toNNReal lam hlam.le]
    exact hΦ.2.2.2.2.1 q hq q' hq'
  have hp_cont : Continuous (fun x : EuclideanSpace ℝ (Fin d) => h.2 (h.1 x)) :=
    (lipschitzWith_cand_head hβ hh).continuous.comp h.1.continuous
  exact hlip_grad.continuousOn.comp_continuous hp_cont (fun x => hh.2.1 (h.1 x))

lemma continuous_forecastLoss_pair {d K : ℕ} (hK : 2 ≤ K) {R β lam M : ℝ} (hβ : 0 < β)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    {h : CandType d K} (hh : IsCand R β h) :
    Continuous (fun z : EuclideanSpace ℝ (Fin d) × Fin K =>
      UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 (h.1 z.1))) z.2) := by
  have h1 : Continuous (fun z : EuclideanSpace ℝ (Fin d) × Fin K =>
      UL.finiteCanonicalAction Φ (h.2 (h.1 z.1))) :=
    (continuous_forecast_action hβ hΦ hh).comp continuous_fst
  have heq : (fun z : EuclideanSpace ℝ (Fin d) × Fin K =>
      UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 (h.1 z.1))) z.2) =
      fun z => ∑ y : Fin K, (if z.2 = y then (1 : ℝ) else 0) *
        UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 (h.1 z.1))) y := by
    funext z; simp
  rw [heq]
  refine continuous_finset_sum _ fun y _ => Continuous.mul ?_ ?_
  · exact (continuous_of_discreteTopology (f := fun w : Fin K => if w = y then (1 : ℝ) else 0)).comp
      continuous_snd
  · exact (continuous_matchingLoss_y hK hΦ.1.2.1 y).comp h1

private abbrev BallX (d : ℕ) (L : ℝ) : Type :=
  Metric.closedBall (0 : EuclideanSpace ℝ (Fin d)) L

private noncomputable def candToBCF {d K : ℕ} (L : ℝ) {R β : ℝ} (hβ : 0 < β)
    (h : CandType d K) (hh : IsCand R β h) :
    BoundedContinuousFunction (BallX d L) (EuclideanSpace ℝ (Fin K)) where
  toFun x := h.2 (h.1 x.1)
  continuous_toFun :=
    (lipschitzWith_cand_head hβ hh).continuous.comp (h.1.continuous.comp continuous_subtype_val)
  map_bounded' := ⟨2, fun x y => by
    rw [dist_eq_norm]
    calc ‖h.2 (h.1 x.1) - h.2 (h.1 y.1)‖
        ≤ ‖h.2 (h.1 x.1)‖ + ‖h.2 (h.1 y.1)‖ := norm_sub_le _ _
      _ ≤ 1 + 1 := add_le_add
          (UL.Proof_lem_A_5.norm_le_one_of_mem_simplex (hh.2.1 _))
          (UL.Proof_lem_A_5.norm_le_one_of_mem_simplex (hh.2.1 _))
      _ = 2 := by norm_num⟩

private lemma candToBCF_dist_le {d K : ℕ} (L : ℝ) {R β : ℝ} (_hR : 0 < R) (hβ : 0 < β)
    {h : CandType d K} (hh : IsCand R β h) (x x' : BallX d L) :
    dist (candToBCF L hβ h hh x) (candToBCF L hβ h hh x') ≤ (β * R) * dist x x' := by
  change ‖h.2 (h.1 x.1) - h.2 (h.1 x'.1)‖ ≤ (β * R) * ‖x.1 - x'.1‖
  calc ‖h.2 (h.1 x.1) - h.2 (h.1 x'.1)‖
      ≤ β * ‖h.1 x.1 - h.1 x'.1‖ := hh.2.2 _ _
    _ = β * ‖h.1 (x.1 - x'.1)‖ := by rw [← map_sub]
    _ ≤ β * (UL.hilbertSchmidtNorm h.1 * ‖x.1 - x'.1‖) :=
        mul_le_mul_of_nonneg_left
          (UL.Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm h.1 _) hβ.le
    _ ≤ β * (R * ‖x.1 - x'.1‖) :=
        mul_le_mul_of_nonneg_left
          (mul_le_mul_of_nonneg_right hh.1 (norm_nonneg _)) hβ.le
    _ = (β * R) * ‖x.1 - x'.1‖ := by ring

/-- Arzelà–Ascoli extraction of a nonempty finite internal net `H_cand` in `IsCand R β`. -/
lemma exists_finite_cand_net {d K : ℕ} (hK : 2 ≤ K) (L : ℝ) {R β η : ℝ}
    (hR : 0 < R) (hβ : 0 < β) (hη : 0 < η) :
    ∃ H_cand : Finset (CandType d K),
      H_cand.Nonempty ∧
      (∀ h ∈ H_cand, IsCand R β h) ∧
      (∀ h : CandType d K, IsCand R β h →
        ∃ h' ∈ H_cand, ∀ x : EuclideanSpace ℝ (Fin d), ‖x‖ ≤ L →
          ‖h'.2 (h'.1 x) - h.2 (h.1 x)‖ < η) := by
  classical
  haveI : CompactSpace (BallX d L) :=
    isCompact_iff_compactSpace.mp (isCompact_closedBall (0 : EuclideanSpace ℝ (Fin d)) L)
  let A : Set (BoundedContinuousFunction (BallX d L) (EuclideanSpace ℝ (Fin K))) :=
    {f | ∃ (h : CandType d K) (hh : IsCand R β h), f = candToBCF L hβ h hh}
  have h_in_s : ∀ (f : BoundedContinuousFunction (BallX d L) (EuclideanSpace ℝ (Fin K)))
      (x : BallX d L), f ∈ A → f x ∈ UL.Simplex K := by
    intro f x hf
    rcases hf with ⟨h, hh, hf_eq⟩
    rw [hf_eq]
    exact hh.2.1 (h.1 x.1)
  have h_equi : Equicontinuous
      (fun (f : A) => (f.1 : BallX d L → EuclideanSpace ℝ (Fin K))) := by
    intro x₀
    rw [Metric.equicontinuousAt_iff]
    intro ε hε
    have hden_pos : 0 < β * R + 1 := by positivity
    refine ⟨ε / (β * R + 1), div_pos hε hden_pos, fun x hx f => ?_⟩
    rcases f.2 with ⟨h, hh, hf_eq⟩
    change dist (f.1 x₀) (f.1 x) < ε
    rw [hf_eq]
    have hd := candToBCF_dist_le L hR hβ hh x₀ x
    rw [dist_comm x x₀] at hx
    calc dist (candToBCF L hβ h hh x₀) (candToBCF L hβ h hh x)
        ≤ (β * R) * dist x₀ x := hd
      _ ≤ (β * R) * (ε / (β * R + 1)) :=
          mul_le_mul_of_nonneg_left hx.le (by positivity)
      _ < (β * R + 1) * (ε / (β * R + 1)) :=
          mul_lt_mul_of_pos_right (by linarith) (div_pos hε hden_pos)
      _ = ε := mul_div_cancel₀ ε hden_pos.ne'
  have hcomp_cl : IsCompact (closure A) :=
    BoundedContinuousFunction.arzela_ascoli (UL.Simplex K)
      (UL.Proof_lem_A_5.isCompact_simplex K) A h_in_s h_equi
  have htb_A : TotallyBounded A := hcomp_cl.totallyBounded.subset subset_closure
  obtain ⟨t, ht_sub, ht_fin, ht_cov⟩ := Metric.finite_approx_of_totallyBounded htb_A η hη
  let liftFn : BoundedContinuousFunction (BallX d L) (EuclideanSpace ℝ (Fin K)) → CandType d K :=
    fun g => if hg : g ∈ A then Classical.choose hg else defaultCand d K
  let H_cand : Finset (CandType d K) :=
    insert (defaultCand d K) (ht_fin.toFinset.image liftFn)
  refine ⟨H_cand, ⟨defaultCand d K, Finset.mem_insert_self _ _⟩, ?_, ?_⟩
  · intro h hh_mem
    rcases Finset.mem_insert.mp hh_mem with rfl | hh_img
    · exact isCand_default hK hR hβ
    · rcases Finset.mem_image.mp hh_img with ⟨g, hg_mem, rfl⟩
      have hgA : g ∈ A := ht_sub (ht_fin.mem_toFinset.mp hg_mem)
      dsimp [liftFn]
      rw [dif_pos hgA]
      exact (Classical.choose_spec hgA).1
  · intro h hh
    have hfA : candToBCF L hβ h hh ∈ A := ⟨h, hh, rfl⟩
    have hf_cov := ht_cov hfA
    rw [Set.mem_iUnion₂] at hf_cov
    rcases hf_cov with ⟨g, hg_t, hg_ball⟩
    have hgA : g ∈ A := ht_sub hg_t
    let h' : CandType d K := liftFn g
    have hh'_mem : h' ∈ H_cand :=
      Finset.mem_insert_of_mem (Finset.mem_image_of_mem liftFn (ht_fin.mem_toFinset.mpr hg_t))
    have hg_eq : g = candToBCF L hβ h' (by
        dsimp [h', liftFn]; rw [dif_pos hgA]; exact (Classical.choose_spec hgA).1) := by
      dsimp [h', liftFn]
      simp only [dif_pos hgA]
      exact (Classical.choose_spec hgA).2
    refine ⟨h', hh'_mem, fun x hx => ?_⟩
    let xb : BallX d L := ⟨x, mem_closedBall_zero_iff.mpr hx⟩
    have hpt : dist (candToBCF L hβ h hh xb) (g xb) ≤ dist (candToBCF L hβ h hh) g :=
      BoundedContinuousFunction.dist_coe_le_dist xb
    rw [Metric.mem_ball] at hg_ball
    have hlt : dist (candToBCF L hβ h hh xb) (g xb) < η := lt_of_le_of_lt hpt hg_ball
    rw [hg_eq, dist_comm, dist_eq_norm] at hlt
    exact hlt

/-! ### Clamped empirical excess risk, `empScore` continuity, and measurable ERM -/

noncomputable def clampBall {X : Type*} [SeminormedAddCommGroup X] [NormedSpace ℝ X]
    (L : ℝ) (x : X) : X :=
  (L / max L ‖x‖) • x

lemma clampBall_eq_self {X : Type*} [SeminormedAddCommGroup X] [NormedSpace ℝ X]
    {L : ℝ} (hL : 0 < L) {x : X} (hx : ‖x‖ ≤ L) :
    clampBall L x = x := by
  unfold clampBall
  rw [max_eq_left hx, div_self hL.ne', one_smul]

lemma norm_clampBall_le {X : Type*} [SeminormedAddCommGroup X] [NormedSpace ℝ X]
    {L : ℝ} (hL : 0 < L) (x : X) :
    ‖clampBall L x‖ ≤ L := by
  unfold clampBall
  have hmax_pos : 0 < max L ‖x‖ := lt_of_lt_of_le hL (le_max_left L ‖x‖)
  rw [norm_smul, Real.norm_eq_abs, abs_of_pos (div_pos hL hmax_pos)]
  calc (L / max L ‖x‖) * ‖x‖
      ≤ (L / max L ‖x‖) * max L ‖x‖ :=
        mul_le_mul_of_nonneg_left (le_max_right L ‖x‖) (div_pos hL hmax_pos).le
    _ = L := div_mul_cancel₀ L hmax_pos.ne'

lemma continuous_clampBall {X : Type*} [SeminormedAddCommGroup X] [NormedSpace ℝ X]
    {L : ℝ} (hL : 0 < L) :
    Continuous (clampBall L : X → X) := by
  unfold clampBall
  refine (continuous_const.div (continuous_const.max continuous_norm) (fun x => ?_)).smul
    continuous_id
  exact ne_of_gt (lt_of_lt_of_le hL (le_max_left L ‖x‖))

noncomputable def empCompObjClamped {d K n : ℕ} (L : ℝ)
    (Φ : UL.Simplex K → ℝ) (V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K)
    (S : Fin n → EuclideanSpace ℝ (Fin d) × Fin K) : ℝ :=
  ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
    UL.matchingLoss Φ
      ((V (clampBall L (S i).1) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) (S i).2

noncomputable def empExcessClamped {d K n : ℕ} (L R : ℝ)
    (Φ : UL.Simplex K → ℝ) (h : CandType d K)
    (S : Fin n → EuclideanSpace ℝ (Fin d) × Fin K) : ℝ :=
  ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
      UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 (h.1 (clampBall L (S i).1)))) (S i).2 -
    (⨅ V : {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K //
        UL.hilbertSchmidtNorm V ≤ R},
      empCompObjClamped L Φ V.1 S)

lemma empExcessClamped_eq_of_norm_le {d K n : ℕ} {L R : ℝ} (hL : 0 < L)
    (Φ : UL.Simplex K → ℝ) (h : CandType d K)
    {S : Fin n → EuclideanSpace ℝ (Fin d) × Fin K}
    (hS : ∀ i : Fin n, ‖(S i).1‖ ≤ L) :
    empExcessClamped L R Φ h S =
      ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
          UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 (h.1 (S i).1))) (S i).2 -
        (⨅ V : {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K //
            UL.hilbertSchmidtNorm V ≤ R},
          ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
            UL.matchingLoss Φ
              ((V.1 (S i).1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) (S i).2) := by
  unfold empExcessClamped empCompObjClamped
  have hcl : ∀ i : Fin n, clampBall L (S i).1 = (S i).1 :=
    fun i => clampBall_eq_self hL (hS i)
  simp_rw [hcl]

lemma empCompObjClamped_bounds {d K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R : ℝ} (hL : 0 < L) (_hR : 0 < R)
    {Φ : UL.Simplex K → ℝ} (hΦ_cont : Continuous Φ)
    {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K}
    (hV : UL.hilbertSchmidtNorm V ≤ R)
    (S : Fin n → EuclideanSpace ℝ (Fin d) × Fin K) :
    |empCompObjClamped L Φ V S - UL.matchingPotential Φ 0| ≤ 3 * (L * R) := by
  have hn_pos : (0 : ℝ) < (n : ℝ) := by exact_mod_cast (by omega : 0 < n)
  have hconst : ((1 : ℝ) / (n : ℝ)) * ∑ _i : Fin n, UL.matchingPotential Φ 0 =
      UL.matchingPotential Φ 0 := by
    simp [Finset.sum_const, nsmul_eq_mul, hn_pos.ne']
  unfold empCompObjClamped
  rw [← hconst, ← mul_sub, ← Finset.sum_sub_distrib, abs_mul,
    abs_of_pos (one_div_pos.mpr hn_pos)]
  have hsum : |∑ i : Fin n,
      (UL.matchingLoss Φ ((V (clampBall L (S i).1) : UL.ZeroSumSubspace K) :
          EuclideanSpace ℝ (Fin K)) (S i).2 - UL.matchingPotential Φ 0)| ≤
      (n : ℝ) * (3 * (L * R)) := by
    calc |∑ i : Fin n, _|
        ≤ ∑ i : Fin n, |UL.matchingLoss Φ
            ((V (clampBall L (S i).1) : UL.ZeroSumSubspace K) :
              EuclideanSpace ℝ (Fin K)) (S i).2 - UL.matchingPotential Φ 0| :=
          Finset.abs_sum_le_sum_abs _ _
      _ ≤ ∑ _i : Fin n, 3 * (L * R) := by
          refine Finset.sum_le_sum fun i _ => ?_
          have h1 := abs_matchingLoss_sub_pot0_le hK hΦ_cont
            ((V (clampBall L (S i).1) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) (S i).2
          have h2 : ‖((V (clampBall L (S i).1) : UL.ZeroSumSubspace K) :
              EuclideanSpace ℝ (Fin K))‖ ≤ L * R := by
            change ‖V (clampBall L (S i).1)‖ ≤ L * R
            calc ‖V (clampBall L (S i).1)‖
                ≤ UL.hilbertSchmidtNorm V * ‖clampBall L (S i).1‖ :=
                  UL.Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm V _
              _ ≤ R * L := mul_le_mul hV (norm_clampBall_le hL _) (norm_nonneg _)
                  (le_trans (UL.Proof_lem_C_2.hilbertSchmidtNorm_nonneg V) hV)
              _ = L * R := mul_comm R L
          linarith
      _ = (n : ℝ) * (3 * (L * R)) := by simp [Finset.sum_const, nsmul_eq_mul]
  calc (1 / (n : ℝ)) * |∑ i : Fin n, _|
      ≤ (1 / (n : ℝ)) * ((n : ℝ) * (3 * (L * R))) :=
        mul_le_mul_of_nonneg_left hsum (by positivity)
    _ = 3 * (L * R) := by field_simp [hn_pos.ne']

lemma abs_empExcessClamped_le {d K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R β lam M : ℝ} (hL : 0 < L) (hR : 0 < R)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    {h : CandType d K} (hh : IsCand R β h)
    (S : Fin n → EuclideanSpace ℝ (Fin d) × Fin K) :
    |empExcessClamped L R Φ h S| ≤ 3 * M + 3 * (L * R) := by
  have hn_pos : (0 : ℝ) < (n : ℝ) := by exact_mod_cast (by omega : 0 < n)
  set c₀ := UL.matchingPotential Φ 0
  have hconst : ((1 : ℝ) / (n : ℝ)) * ∑ _i : Fin n, c₀ = c₀ := by
    simp [Finset.sum_const, nsmul_eq_mul, hn_pos.ne']
  have hfore : |(((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
      UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 (h.1 (clampBall L (S i).1)))) (S i).2) -
      c₀| ≤ 3 * M := by
    rw [← hconst, ← mul_sub, ← Finset.sum_sub_distrib, abs_mul,
      abs_of_pos (one_div_pos.mpr hn_pos)]
    have hsum : |∑ i : Fin n,
        (UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 (h.1 (clampBall L (S i).1)))) (S i).2 -
          c₀)| ≤ (n : ℝ) * (3 * M) := by
      calc |∑ i : Fin n, _|
          ≤ ∑ i : Fin n, |UL.matchingLoss Φ
              (UL.finiteCanonicalAction Φ (h.2 (h.1 (clampBall L (S i).1)))) (S i).2 - c₀| :=
            Finset.abs_sum_le_sum_abs _ _
        _ ≤ ∑ _i : Fin n, 3 * M := Finset.sum_le_sum fun i _ =>
            abs_finiteCanonicalLoss_sub_pot0_le hK hΦ (hh.2.1 _) (S i).2
        _ = (n : ℝ) * (3 * M) := by simp [Finset.sum_const, nsmul_eq_mul]
    calc (1 / (n : ℝ)) * |∑ i : Fin n, _|
        ≤ (1 / (n : ℝ)) * ((n : ℝ) * (3 * M)) := mul_le_mul_of_nonneg_left hsum (by positivity)
      _ = 3 * M := by field_simp [hn_pos.ne']
  let V₀ : {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K //
      UL.hilbertSchmidtNorm V ≤ R} :=
    ⟨0, by rw [UL.Proof_lem_C_2.hilbertSchmidtNorm_zero]; exact hR.le⟩
  haveI : Nonempty {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K //
      UL.hilbertSchmidtNorm V ≤ R} := ⟨V₀⟩
  have hbdd : BddBelow (Set.range (fun V : {V // UL.hilbertSchmidtNorm V ≤ R} =>
      empCompObjClamped L Φ V.1 S)) := by
    refine ⟨c₀ - 3 * (L * R), Set.forall_mem_range.mpr fun V => ?_⟩
    have hb := (abs_le.mp (empCompObjClamped_bounds hK hn hL hR hΦ.1.2.1 V.2 S)).1
    linarith
  have hinf_ge : c₀ - 3 * (L * R) ≤
      ⨅ V : {V // UL.hilbertSchmidtNorm V ≤ R}, empCompObjClamped L Φ V.1 S :=
    le_ciInf fun V => by
      have hb := (abs_le.mp (empCompObjClamped_bounds hK hn hL hR hΦ.1.2.1 V.2 S)).1
      linarith
  have hinf_le : (⨅ V : {V // UL.hilbertSchmidtNorm V ≤ R}, empCompObjClamped L Φ V.1 S) ≤
      c₀ + 3 * (L * R) := by
    refine le_trans (ciInf_le hbdd V₀) ?_
    have hb := (abs_le.mp (empCompObjClamped_bounds hK hn hL hR hΦ.1.2.1 V₀.2 S)).2
    linarith
  obtain ⟨hf_lo, hf_hi⟩ := abs_le.mp hfore
  unfold empExcessClamped
  rw [abs_le]
  constructor <;> linarith

private lemma empFore_sub_le_of_same_labels {d K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R β lam M : ℝ} (_hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) (hlam : 0 < lam)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    {h : CandType d K} (hh : IsCand R β h)
    {S S' : Fin n → EuclideanSpace ℝ (Fin d) × Fin K}
    (hy : ∀ i : Fin n, (S i).2 = (S' i).2) :
    (((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
        UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 (h.1 (clampBall L (S i).1)))) (S i).2) -
      (((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
        UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 (h.1 (clampBall L (S' i).1)))) (S' i).2) ≤
      (3 * lam * β * R) * ∑ i : Fin n, ‖clampBall L (S i).1 - clampBall L (S' i).1‖ := by
  have hn_pos : (0 : ℝ) < (n : ℝ) := by exact_mod_cast (by omega : 0 < n)
  have hn_inv_le1 : (1 : ℝ) / (n : ℝ) ≤ 1 :=
    div_le_one_of_le₀ (by exact_mod_cast hn) hn_pos.le
  set Δ := ∑ i : Fin n, ‖clampBall L (S i).1 - clampBall L (S' i).1‖
  have hΔ_nn : 0 ≤ Δ := Finset.sum_nonneg fun _ _ => norm_nonneg _
  rw [← mul_sub, ← Finset.sum_sub_distrib]
  have hsum : ∑ i : Fin n,
      (UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 (h.1 (clampBall L (S i).1)))) (S i).2 -
        UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 (h.1 (clampBall L (S' i).1))))
          (S' i).2) ≤ (3 * lam * β * R) * Δ := by
    rw [Finset.mul_sum]
    refine Finset.sum_le_sum fun i _ => ?_
    rw [← hy i]
    have h1 := le_trans (le_abs_self _)
      (finiteCanonicalLoss_lipschitz_on_simplex hK hΦ
        (hh.2.1 (h.1 (clampBall L (S i).1))) (hh.2.1 (h.1 (clampBall L (S' i).1))) (S i).2)
    have h2 : ‖h.2 (h.1 (clampBall L (S i).1)) - h.2 (h.1 (clampBall L (S' i).1))‖ ≤
        (β * R) * ‖clampBall L (S i).1 - clampBall L (S' i).1‖ := by
      calc ‖h.2 (h.1 (clampBall L (S i).1)) - h.2 (h.1 (clampBall L (S' i).1))‖
          ≤ β * ‖h.1 (clampBall L (S i).1) - h.1 (clampBall L (S' i).1)‖ := hh.2.2 _ _
        _ = β * ‖h.1 (clampBall L (S i).1 - clampBall L (S' i).1)‖ := by rw [← map_sub]
        _ ≤ β * (R * ‖clampBall L (S i).1 - clampBall L (S' i).1‖) :=
            mul_le_mul_of_nonneg_left
              (le_trans (UL.Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm h.1 _)
                (mul_le_mul_of_nonneg_right hh.1 (norm_nonneg _))) hβ.le
        _ = (β * R) * ‖clampBall L (S i).1 - clampBall L (S' i).1‖ := by ring
    calc _ ≤ (3 * lam) * ‖h.2 (h.1 (clampBall L (S i).1)) - h.2 (h.1 (clampBall L (S' i).1))‖ := h1
      _ ≤ (3 * lam) * ((β * R) * ‖clampBall L (S i).1 - clampBall L (S' i).1‖) :=
          mul_le_mul_of_nonneg_left h2 (by positivity)
      _ = (3 * lam * β * R) * ‖clampBall L (S i).1 - clampBall L (S' i).1‖ := by ring
  calc (1 / (n : ℝ)) * ∑ i : Fin n, _
      ≤ (1 / (n : ℝ)) * ((3 * lam * β * R) * Δ) :=
        mul_le_mul_of_nonneg_left hsum (by positivity)
    _ ≤ 1 * ((3 * lam * β * R) * Δ) :=
        mul_le_mul_of_nonneg_right hn_inv_le1 (by positivity)
    _ = (3 * lam * β * R) * Δ := one_mul _

private lemma empCompInf_sub_le_of_same_labels {d K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R : ℝ} (hL : 0 < L) (hR : 0 < R)
    {Φ : UL.Simplex K → ℝ} (hΦ_cont : Continuous Φ)
    {S S' : Fin n → EuclideanSpace ℝ (Fin d) × Fin K}
    (hy : ∀ i : Fin n, (S i).2 = (S' i).2) :
    (⨅ V : {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K //
        UL.hilbertSchmidtNorm V ≤ R}, empCompObjClamped L Φ V.1 S') ≤
      (⨅ V : {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K //
        UL.hilbertSchmidtNorm V ≤ R}, empCompObjClamped L Φ V.1 S) +
        (3 * R) * ∑ i : Fin n, ‖clampBall L (S i).1 - clampBall L (S' i).1‖ := by
  have hn_pos : (0 : ℝ) < (n : ℝ) := by exact_mod_cast (by omega : 0 < n)
  have hn_inv_le1 : (1 : ℝ) / (n : ℝ) ≤ 1 :=
    div_le_one_of_le₀ (by exact_mod_cast hn) hn_pos.le
  set Δ := ∑ i : Fin n, ‖clampBall L (S i).1 - clampBall L (S' i).1‖
  have hΔ_nn : 0 ≤ Δ := Finset.sum_nonneg fun _ _ => norm_nonneg _
  let V₀ : {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K //
      UL.hilbertSchmidtNorm V ≤ R} :=
    ⟨0, by rw [UL.Proof_lem_C_2.hilbertSchmidtNorm_zero]; exact hR.le⟩
  haveI : Nonempty {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K //
      UL.hilbertSchmidtNorm V ≤ R} := ⟨V₀⟩
  have hbddS' : BddBelow (Set.range (fun V : {V // UL.hilbertSchmidtNorm V ≤ R} =>
      empCompObjClamped L Φ V.1 S')) := by
    refine ⟨UL.matchingPotential Φ 0 - 3 * (L * R), Set.forall_mem_range.mpr fun V => ?_⟩
    have hb := (abs_le.mp (empCompObjClamped_bounds hK hn hL hR hΦ_cont V.2 S')).1
    linarith
  rw [← sub_le_iff_le_add]
  refine le_ciInf fun V => ?_
  rw [sub_le_iff_le_add]
  refine le_trans (ciInf_le hbddS' V) ?_
  have hv_step : empCompObjClamped L Φ V.1 S' - empCompObjClamped L Φ V.1 S ≤ (3 * R) * Δ := by
    unfold empCompObjClamped
    rw [← mul_sub, ← Finset.sum_sub_distrib]
    have hsum : ∑ i : Fin n,
        (UL.matchingLoss Φ ((V.1 (clampBall L (S' i).1) : UL.ZeroSumSubspace K) :
            EuclideanSpace ℝ (Fin K)) (S' i).2 -
          UL.matchingLoss Φ ((V.1 (clampBall L (S i).1) : UL.ZeroSumSubspace K) :
            EuclideanSpace ℝ (Fin K)) (S i).2) ≤ (3 * R) * Δ := by
      rw [Finset.mul_sum]
      refine Finset.sum_le_sum fun i _ => ?_
      rw [← hy i]
      have h1 := le_trans (le_abs_self _) (matchingLoss_lipschitz hK hΦ_cont
        ((V.1 (clampBall L (S' i).1) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))
        ((V.1 (clampBall L (S i).1) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) (S i).2)
      have h2 : ‖((V.1 (clampBall L (S' i).1) : UL.ZeroSumSubspace K) :
            EuclideanSpace ℝ (Fin K)) -
          ((V.1 (clampBall L (S i).1) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))‖ ≤
          R * ‖clampBall L (S i).1 - clampBall L (S' i).1‖ := by
        change ‖V.1 (clampBall L (S' i).1) - V.1 (clampBall L (S i).1)‖ ≤ _
        rw [← map_sub, norm_sub_rev]
        exact le_trans (UL.Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm V.1 _)
          (mul_le_mul_of_nonneg_right V.2 (norm_nonneg _))
      linarith
    calc (1 / (n : ℝ)) * ∑ i : Fin n, _
        ≤ (1 / (n : ℝ)) * ((3 * R) * Δ) := mul_le_mul_of_nonneg_left hsum (by positivity)
      _ ≤ 1 * ((3 * R) * Δ) := mul_le_mul_of_nonneg_right hn_inv_le1 (by positivity)
      _ = (3 * R) * Δ := one_mul _
  linarith

lemma empExcessClamped_sub_le_of_same_labels {d K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R β lam M : ℝ} (hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) (hlam : 0 < lam)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    {h : CandType d K} (hh : IsCand R β h)
    {S S' : Fin n → EuclideanSpace ℝ (Fin d) × Fin K}
    (hy : ∀ i : Fin n, (S i).2 = (S' i).2) :
    empExcessClamped L R Φ h S - empExcessClamped L R Φ h S' ≤
      (3 * lam * β * R + 3 * R) *
        ∑ i : Fin n, ‖clampBall L (S i).1 - clampBall L (S' i).1‖ := by
  have hfore := empFore_sub_le_of_same_labels hK hn hL hR hβ hlam hΦ hh hy
  have hcomp := empCompInf_sub_le_of_same_labels hK hn hL hR hΦ.1.2.1 hy
  unfold empExcessClamped
  linarith

/-- Empirical worst-case excess risk over `Φ ∈ SmoothEntropyFamily K β lam M`. -/
noncomputable def empScore {d K n : ℕ} (L R β lam M : ℝ) (h : CandType d K)
    (S : Fin n → EuclideanSpace ℝ (Fin d) × Fin K) : ℝ :=
  ⨆ Φ : UL.SmoothEntropyFamily K β lam M, empExcessClamped L R Φ.1 h S

lemma empScore_bddAbove {d K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R β lam M : ℝ} (hL : 0 < L) (hR : 0 < R)
    {h : CandType d K} (hh : IsCand R β h)
    (S : Fin n → EuclideanSpace ℝ (Fin d) × Fin K) :
    BddAbove (Set.range (fun Φ : UL.SmoothEntropyFamily K β lam M =>
      empExcessClamped L R Φ.1 h S)) := by
  refine ⟨3 * M + 3 * (L * R), Set.forall_mem_range.mpr fun Φ => ?_⟩
  exact le_trans (le_abs_self _) (abs_empExcessClamped_le hK hn hL hR Φ.2 hh S)

lemma le_empScore {d K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R β lam M : ℝ} (hL : 0 < L) (hR : 0 < R)
    {h : CandType d K} (hh : IsCand R β h)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    (S : Fin n → EuclideanSpace ℝ (Fin d) × Fin K) :
    empExcessClamped L R Φ h S ≤ empScore L R β lam M h S :=
  le_ciSup (empScore_bddAbove hK hn hL hR hh S) ⟨Φ, hΦ⟩

lemma empScore_le_of_forall {d K n : ℕ}
    {L R β lam M B : ℝ}
    (hSmooth : (UL.SmoothEntropyFamily K β lam M).Nonempty)
    (h : CandType d K) (S : Fin n → EuclideanSpace ℝ (Fin d) × Fin K)
    (hB : ∀ Φ ∈ UL.SmoothEntropyFamily K β lam M, empExcessClamped L R Φ h S ≤ B) :
    empScore L R β lam M h S ≤ B := by
  haveI : Nonempty (UL.SmoothEntropyFamily K β lam M) := hSmooth.to_subtype
  exact ciSup_le fun Φ => hB Φ.1 Φ.2

lemma continuous_empScore {d K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R β lam M : ℝ} (hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) (hlam : 0 < lam)
    (hSmooth : (UL.SmoothEntropyFamily K β lam M).Nonempty)
    {h : CandType d K} (hh : IsCand R β h) :
    Continuous (empScore L R β lam M h : (Fin n → EuclideanSpace ℝ (Fin d) × Fin K) → ℝ) := by
  haveI : Nonempty (UL.SmoothEntropyFamily K β lam M) := hSmooth.to_subtype
  rw [continuous_iff_continuousAt]
  intro S₀
  rw [ContinuousAt, Metric.tendsto_nhds]
  intro ε hε
  let C_lip : ℝ := 3 * lam * β * R + 3 * R
  have hC_pos : 0 < C_lip := by dsimp [C_lip]; positivity
  let g : (Fin n → EuclideanSpace ℝ (Fin d) × Fin K) → ℝ :=
    fun S => ∑ i : Fin n, ‖clampBall L (S i).1 - clampBall L (S₀ i).1‖
  have hg_cont : Continuous g := by
    refine continuous_finset_sum _ fun i _ => ?_
    exact (((continuous_clampBall hL).comp (continuous_fst.comp (continuous_apply i))).sub
      continuous_const).norm
  have hg0 : g S₀ = 0 := by simp [g]
  have hU₁_open : IsOpen {S : Fin n → EuclideanSpace ℝ (Fin d) × Fin K |
      ∀ i : Fin n, (S i).2 = (S₀ i).2} := by
    have heq : {S : Fin n → EuclideanSpace ℝ (Fin d) × Fin K |
        ∀ i : Fin n, (S i).2 = (S₀ i).2} =
        ⋂ i : Fin n, {S | (S i).2 = (S₀ i).2} := by
      ext S; simp
    rw [heq]
    exact isOpen_iInter_of_finite fun i =>
      (isOpen_discrete ({(S₀ i).2} : Set (Fin K))).preimage
        (continuous_snd.comp (continuous_apply i))
  have hU₂_open : IsOpen {S | g S < ε / C_lip} :=
    isOpen_lt hg_cont continuous_const
  have hmem : S₀ ∈ {S | ∀ i : Fin n, (S i).2 = (S₀ i).2} ∩ {S | g S < ε / C_lip} :=
    ⟨fun _ => rfl, by simp [hg0, div_pos hε hC_pos]⟩
  refine Filter.eventually_of_mem ((hU₁_open.inter hU₂_open).mem_nhds hmem) ?_
  rintro S ⟨hy, hg_lt⟩
  have h_le1 : empScore L R β lam M h S ≤ empScore L R β lam M h S₀ + C_lip * g S := by
    refine ciSup_le fun Φ => ?_
    have hstep := empExcessClamped_sub_le_of_same_labels hK hn hL hR hβ hlam Φ.2 hh hy
    have hle0 := le_empScore hK hn hL hR hh Φ.2 S₀
    dsimp [C_lip, g] at hstep ⊢
    linarith
  have h_le2 : empScore L R β lam M h S₀ ≤ empScore L R β lam M h S + C_lip * g S := by
    refine ciSup_le fun Φ => ?_
    have hy' : ∀ i : Fin n, (S₀ i).2 = (S i).2 := fun i => (hy i).symm
    have hstep := empExcessClamped_sub_le_of_same_labels hK hn hL hR hβ hlam Φ.2 hh hy'
    have hsym : ∑ i : Fin n, ‖clampBall L (S₀ i).1 - clampBall L (S i).1‖ = g S := by
      dsimp [g]
      refine Finset.sum_congr rfl fun i _ => norm_sub_rev _ _
    rw [hsym] at hstep
    have hleS := le_empScore hK hn hL hR hh Φ.2 S
    dsimp [C_lip] at hstep ⊢
    linarith
  rw [Real.dist_eq, abs_lt]
  have hCg : C_lip * g S < ε := by
    calc C_lip * g S < C_lip * (ε / C_lip) := mul_lt_mul_of_pos_left hg_lt hC_pos
      _ = ε := mul_div_cancel₀ ε hC_pos.ne'
  constructor <;> linarith

/-! ### List-based measurable finite argmin -/

private noncomputable def pickBest {α Ω₀ : Type*} (score : α → Ω₀ → ℝ) :
    α → List α → Ω₀ → α
  | cur, [], _ => cur
  | cur, h :: rest, S =>
      open Classical in
      if score h S < score cur S then pickBest score h rest S else pickBest score cur rest S

private lemma pickBest_mem {α Ω₀ : Type*} (score : α → Ω₀ → ℝ)
    (cur : α) (rest : List α) (S : Ω₀) :
    pickBest score cur rest S = cur ∨ pickBest score cur rest S ∈ rest := by
  induction rest generalizing cur with
  | nil => exact Or.inl rfl
  | cons h rest ih =>
    dsimp [pickBest]
    split_ifs with hlt
    · rcases ih h with heq | hmem
      · rw [heq]; exact Or.inr List.mem_cons_self
      · exact Or.inr (List.mem_cons_of_mem _ hmem)
    · rcases ih cur with heq | hmem
      · exact Or.inl heq
      · exact Or.inr (List.mem_cons_of_mem _ hmem)

private lemma score_pickBest_le_cur {α Ω₀ : Type*} (score : α → Ω₀ → ℝ)
    (cur : α) (rest : List α) (S : Ω₀) :
    score (pickBest score cur rest S) S ≤ score cur S := by
  induction rest generalizing cur with
  | nil => exact le_rfl
  | cons h rest ih =>
    dsimp [pickBest]
    split_ifs with hlt
    · exact le_trans (ih h) hlt.le
    · exact ih cur

private lemma score_pickBest_le_all {α Ω₀ : Type*} (score : α → Ω₀ → ℝ)
    (cur : α) (rest : List α) (S : Ω₀) :
    ∀ h, (h = cur ∨ h ∈ rest) → score (pickBest score cur rest S) S ≤ score h S := by
  induction rest generalizing cur with
  | nil =>
    intro h hh
    rcases hh with rfl | hmem
    · exact le_rfl
    · cases hmem
  | cons a rest ih =>
    intro h hh
    dsimp [pickBest]
    split_ifs with hlt
    · rcases hh with heq | hcons
      · rw [heq]; exact le_trans (score_pickBest_le_cur score a rest S) hlt.le
      · rcases List.mem_cons.mp hcons with heq | hrest
        · rw [heq]; exact ih a a (Or.inl rfl)
        · exact ih a h (Or.inr hrest)
    · rcases hh with heq | hcons
      · rw [heq]; exact ih cur cur (Or.inl rfl)
      · rcases List.mem_cons.mp hcons with heq | hrest
        · rw [heq]; exact le_trans (score_pickBest_le_cur score cur rest S) (not_lt.mp hlt)
        · exact ih cur h (Or.inr hrest)

private lemma measurableSet_pickBest_eq {α Ω₀ : Type*} [MeasurableSpace Ω₀]
    (score : α → Ω₀ → ℝ) (cur : α) (rest : List α)
    (hmeas : ∀ h, (h = cur ∨ h ∈ rest) → Measurable (score h)) (target : α) :
    MeasurableSet {S : Ω₀ | pickBest score cur rest S = target} := by
  induction rest generalizing cur with
  | nil =>
    dsimp [pickBest]
    exact MeasurableSet.const (cur = target)
  | cons a rest ih =>
    have hm_a : Measurable (score a) := hmeas a (Or.inr List.mem_cons_self)
    have hm_cur : Measurable (score cur) := hmeas cur (Or.inl rfl)
    have hA : MeasurableSet {S : Ω₀ | score a S < score cur S} := measurableSet_lt hm_a hm_cur
    have h_ih_a : MeasurableSet {S : Ω₀ | pickBest score a rest S = target} :=
      ih a fun h hh => hmeas h (by
        rcases hh with rfl | hr
        · exact Or.inr List.mem_cons_self
        · exact Or.inr (List.mem_cons_of_mem _ hr))
    have h_ih_cur : MeasurableSet {S : Ω₀ | pickBest score cur rest S = target} :=
      ih cur fun h hh => hmeas h (by
        rcases hh with rfl | hr
        · exact Or.inl rfl
        · exact Or.inr (List.mem_cons_of_mem _ hr))
    have heq : {S : Ω₀ | pickBest score cur (a :: rest) S = target} =
        ({S | score a S < score cur S} ∩ {S | pickBest score a rest S = target}) ∪
          ({S | score a S < score cur S}ᶜ ∩ {S | pickBest score cur rest S = target}) := by
      ext S
      simp only [pickBest, Set.mem_setOf_eq, Set.mem_union, Set.mem_inter_iff, Set.mem_compl_iff]
      by_cases hlt : score a S < score cur S <;> simp [hlt]
    rw [heq]
    exact (hA.inter h_ih_a).union (hA.compl.inter h_ih_cur)

/-- Measurable finite-search ERM learner minimizing `empScore` over `H_cand`. -/
lemma exists_measurable_erm_learner {d K n : ℕ} (hK : 2 ≤ K) (hn : 1 ≤ n)
    {L R β lam M : ℝ} (hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) (hlam : 0 < lam)
    (hSmooth : (UL.SmoothEntropyFamily K β lam M).Nonempty)
    (H_cand : Finset (CandType d K)) (hH_ne : H_cand.Nonempty)
    (hH_cand : ∀ h ∈ H_cand, IsCand R β h) :
    ∃ learner : (Fin n → EuclideanSpace ℝ (Fin d) × Fin K) → CandType d K,
      (∀ S, learner S ∈ H_cand) ∧
      (∀ h ∈ H_cand, MeasurableSet {S | learner S = h}) ∧
      (∀ S, ∀ h ∈ H_cand,
        empScore L R β lam M (learner S) S ≤ empScore L R β lam M h S) := by
  classical
  obtain ⟨h₀, hh₀⟩ := hH_ne
  let L_cand : List (CandType d K) := H_cand.toList
  let score : CandType d K → (Fin n → EuclideanSpace ℝ (Fin d) × Fin K) → ℝ :=
    empScore L R β lam M
  let learner : (Fin n → EuclideanSpace ℝ (Fin d) × Fin K) → CandType d K :=
    pickBest score h₀ L_cand
  have hmem_L : ∀ h : CandType d K, h ∈ L_cand ↔ h ∈ H_cand := fun h => Finset.mem_toList
  refine ⟨learner, ?_, ?_, ?_⟩
  · intro S
    rcases pickBest_mem score h₀ L_cand S with heq | h_in
    · change pickBest score h₀ L_cand S ∈ H_cand
      rwa [heq]
    · exact (hmem_L _).mp h_in
  · intro t _ht
    refine measurableSet_pickBest_eq score h₀ L_cand (fun h hh => ?_) t
    have hh_cand : h ∈ H_cand := by
      rcases hh with rfl | h_in
      · exact hh₀
      · exact (hmem_L _).mp h_in
    exact (continuous_empScore hK hn hL hR hβ hlam hSmooth (hH_cand h hh_cand)).measurable
  · intro S h hh
    exact score_pickBest_le_all score h₀ L_cand S h (Or.inr ((hmem_L h).mpr hh))

end UL.Proof_thm_5_1

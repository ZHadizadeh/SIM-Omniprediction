import Mathlib
set_option autoImplicit false

namespace UL.Proof_thm_5_1

/-- Combined constant `C_K ≥ 8` depending only on `(K, C₁, C₃)`. -/
noncomputable def chooseCK (K : ℕ) (C₁ C₃ : ℝ) : ℝ :=
  let m : ℕ := K - 1
  max (max 8 (16 * C₁ * (1 + |Real.log (8 * C₁)| / Real.log 2) ^ 2))
    (max (max (C₁ * (4 : ℝ) ^ m) (32 * C₁))
      (max ((1152 * C₃) ^ 2) ((192 * C₃) ^ m)))

lemma eight_le_chooseCK (K : ℕ) (C₁ C₃ : ℝ) : 8 ≤ chooseCK K C₁ C₃ :=
  le_trans (le_max_left 8 _) (le_max_left _ _)

lemma one_le_chooseCK (K : ℕ) (C₁ C₃ : ℝ) : 1 ≤ chooseCK K C₁ C₃ := by
  linarith [eight_le_chooseCK K C₁ C₃]

lemma chooseCK_ge_c1_quad (K : ℕ) (C₁ C₃ : ℝ) :
    16 * C₁ * (1 + |Real.log (8 * C₁)| / Real.log 2) ^ 2 ≤ chooseCK K C₁ C₃ :=
  le_trans (le_max_right 8 _) (le_max_left _ _)

lemma chooseCK_ge_c1_pow (K : ℕ) (C₁ C₃ : ℝ) :
    C₁ * (4 : ℝ) ^ (K - 1) ≤ chooseCK K C₁ C₃ :=
  le_trans (le_max_left _ _) (le_trans (le_max_left _ _) (le_max_right _ _))

lemma chooseCK_ge_32_c1 (K : ℕ) (C₁ C₃ : ℝ) :
    32 * C₁ ≤ chooseCK K C₁ C₃ :=
  le_trans (le_max_right _ _) (le_trans (le_max_left _ _) (le_max_right _ _))

lemma chooseCK_ge_c3_sq (K : ℕ) (C₁ C₃ : ℝ) :
    (1152 * C₃) ^ 2 ≤ chooseCK K C₁ C₃ :=
  le_trans (le_max_left _ _) (le_trans (le_max_right _ _) (le_max_right _ _))

lemma chooseCK_ge_c3_pow (K : ℕ) (C₁ C₃ : ℝ) :
    (192 * C₃) ^ (K - 1) ≤ chooseCK K C₁ C₃ :=
  le_trans (le_max_right _ _) (le_trans (le_max_right _ _) (le_max_right _ _))

lemma sqrt_chooseCK_ge (K : ℕ) {C₁ C₃ : ℝ} (hC₃ : 0 < C₃) :
    1152 * C₃ ≤ Real.sqrt (chooseCK K C₁ C₃) := by
  have h1 := Real.sqrt_le_sqrt (chooseCK_ge_c3_sq K C₁ C₃)
  rwa [Real.sqrt_sq (by positivity)] at h1

private lemma exp_two_lt_sixteen : Real.exp 2 < 16 := by
  have h1 : Real.exp 1 < 3 := lt_trans Real.exp_one_lt_d9 (by norm_num)
  have h2 : Real.exp 2 = Real.exp 1 * Real.exp 1 := by
    rw [show (2 : ℝ) = 1 + 1 by norm_num, Real.exp_add]
  have hpos : 0 < Real.exp 1 := Real.exp_pos 1
  nlinarith

private lemma two_lt_log_of_sixteen_le {x : ℝ} (hx : 16 ≤ x) : 2 < Real.log x := by
  have hexp : Real.exp 2 < x := lt_of_lt_of_le exp_two_lt_sixteen hx
  have h := Real.log_lt_log (Real.exp_pos 2) hexp
  rwa [Real.log_exp] at h

/-- Antitonicity of `t ↦ log (2 * t) / √t` on `[8, ∞)`. -/
lemma log_two_mul_div_sqrt_antitone {x y : ℝ} (hx : 8 ≤ x) (hxy : x ≤ y) :
    Real.log (2 * y) / Real.sqrt y ≤ Real.log (2 * x) / Real.sqrt x := by
  have hx_pos : 0 < x := by linarith
  have hy_pos : 0 < y := by linarith
  have hsqrt_x : 0 < Real.sqrt x := Real.sqrt_pos.mpr hx_pos
  have hsqrt_y : 0 < Real.sqrt y := Real.sqrt_pos.mpr hy_pos
  let u : ℝ := Real.sqrt y / Real.sqrt x
  have hu_ge1 : 1 ≤ u := (one_le_div hsqrt_x).mpr (Real.sqrt_le_sqrt hxy)
  have hu_pos : 0 < u := by linarith
  have hy_eq : y = u ^ 2 * x := by
    dsimp [u]
    rw [div_pow, Real.sq_sqrt hy_pos.le, Real.sq_sqrt hx_pos.le, div_mul_cancel₀ _ hx_pos.ne']
  have hsy_eq : Real.sqrt y = u * Real.sqrt x := by
    dsimp [u]
    exact (div_mul_cancel₀ _ hsqrt_x.ne').symm
  have hlog2x : 2 < Real.log (2 * x) := two_lt_log_of_sixteen_le (by linarith)
  have hlog_u : Real.log u ≤ u - 1 := Real.log_le_sub_one_of_pos hu_pos
  have hineq : Real.log (2 * y) ≤ u * Real.log (2 * x) := by
    rw [hy_eq, show 2 * (u ^ 2 * x) = u ^ 2 * (2 * x) by ring,
      Real.log_mul (pow_pos hu_pos 2).ne' (by positivity), Real.log_pow]
    push_cast
    have hmul : 2 * (u - 1) ≤ (u - 1) * Real.log (2 * x) := by
      nlinarith [hu_ge1, hlog2x]
    linarith
  rw [hsy_eq, div_le_iff₀ (mul_pos hu_pos hsqrt_x)]
  calc Real.log (2 * y)
      ≤ u * Real.log (2 * x) := hineq
    _ = (Real.log (2 * x) / Real.sqrt x) * (u * Real.sqrt x) := by
        field_simp [hsqrt_x.ne']

/-- The `S_thm_5_1` sample bound implies `1 ≤ n`. -/
lemma sample_ge_one {K : ℕ} (_hK : 2 ≤ K) {C_K D ε δ : ℝ}
    (hCK : 8 ≤ C_K) (hε_pos : 0 < ε) (hε_le : ε ≤ D)
    (hδ_pos : 0 < δ) (hδ_lt : δ < (1 : ℝ) / 2) {n : ℕ}
    (hn : (if K - 1 ≤ 2 then
        C_K * (D / ε) ^ 2 * (Real.log (C_K * D / (ε * δ))) ^ 2 ≤ (n : ℝ)
      else
        C_K * ((D / ε) ^ (K - 1) + (D / ε) ^ 2 * Real.log (2 / δ)) ≤ (n : ℝ))) :
    1 ≤ n := by
  have hDe : 1 ≤ D / ε := (one_le_div hε_pos).mpr hε_le
  have h1_le_n : (1 : ℝ) ≤ (n : ℝ) := by
    split_ifs at hn with hm
    · have hU : 16 ≤ C_K * D / (ε * δ) := by
        rw [le_div_iff₀ (mul_pos hε_pos hδ_pos)]
        have h1 : 8 * D ≤ C_K * D := mul_le_mul_of_nonneg_right hCK (le_trans hε_pos.le hε_le)
        nlinarith
      have hlog : 2 < Real.log (C_K * D / (ε * δ)) := two_lt_log_of_sixteen_le hU
      have hsq1 : 1 ≤ (D / ε) ^ 2 := by nlinarith
      have hsq2 : 4 ≤ (Real.log (C_K * D / (ε * δ))) ^ 2 := by nlinarith
      have hprod : 32 ≤ C_K * (D / ε) ^ 2 * (Real.log (C_K * D / (ε * δ))) ^ 2 := by
        have h1 : 8 ≤ C_K * (D / ε) ^ 2 := by nlinarith
        nlinarith
      linarith
    · have hpow : 1 ≤ (D / ε) ^ (K - 1) := one_le_pow₀ hDe
      have h2d : 4 < 2 / δ := by
        rw [lt_div_iff₀ hδ_pos]
        linarith
      have hlog_pos : 0 < Real.log (2 / δ) := Real.log_pos (by linarith)
      have hnn : 0 ≤ (D / ε) ^ 2 * Real.log (2 / δ) := by positivity
      have hprod : 8 ≤ C_K * ((D / ε) ^ (K - 1) + (D / ε) ^ 2 * Real.log (2 / δ)) := by
        nlinarith
      linarith
  exact_mod_cast h1_le_n

/-- The `S_thm_5_1` sample bound implies the `S_thm_C_1` sample bound at `(ε / 4, δ / 2)`. -/
lemma sample_implies_thm_C_1 {K : ℕ} (_hK : 2 ≤ K) {C₁ C₃ D ε δ : ℝ}
    (hC₁ : 0 < C₁) (hε_pos : 0 < ε) (hε_le : ε ≤ D)
    (hδ_pos : 0 < δ) (hδ_lt : δ < (1 : ℝ) / 2) {n : ℕ}
    (hn : (if K - 1 ≤ 2 then
        chooseCK K C₁ C₃ * (D / ε) ^ 2 *
          (Real.log (chooseCK K C₁ C₃ * D / (ε * δ))) ^ 2 ≤ (n : ℝ)
      else
        chooseCK K C₁ C₃ *
          ((D / ε) ^ (K - 1) + (D / ε) ^ 2 * Real.log (2 / δ)) ≤ (n : ℝ))) :
    (n : ℝ) ≥
      (if K - 1 ≤ 2 then
        C₁ * (D / (ε / 4)) ^ 2 * (Real.log (C₁ * D / ((ε / 4) * (δ / 2)))) ^ 2
      else
        C₁ * ((D / (ε / 4)) ^ (K - 1) +
          (D / (ε / 4)) ^ 2 * Real.log ((2 : ℝ) / (δ / 2)))) := by
  have hCK1 : 1 ≤ chooseCK K C₁ C₃ := one_le_chooseCK K C₁ C₃
  have hCK_quad : 16 * C₁ * (1 + |Real.log (8 * C₁)| / Real.log 2) ^ 2 ≤ chooseCK K C₁ C₃ :=
    chooseCK_ge_c1_quad K C₁ C₃
  have hCK_pow : C₁ * (4 : ℝ) ^ (K - 1) ≤ chooseCK K C₁ C₃ := chooseCK_ge_c1_pow K C₁ C₃
  have hCK_32 : 32 * C₁ ≤ chooseCK K C₁ C₃ := chooseCK_ge_32_c1 K C₁ C₃
  generalize chooseCK K C₁ C₃ = C_K at hn hCK1 hCK_quad hCK_pow hCK_32
  have hD_pos : 0 < D := lt_of_lt_of_le hε_pos hε_le
  split_ifs at hn ⊢ with hm
  · set u : ℝ := D / (ε * δ)
    have hu_gt2 : 2 < u := by
      dsimp [u]
      rw [lt_div_iff₀ (mul_pos hε_pos hδ_pos)]
      nlinarith
    have hu_pos : 0 < u := by linarith
    have hlog2_pos : 0 < Real.log 2 := Real.log_pos (by norm_num)
    have hlogu_gt : Real.log 2 < Real.log u := Real.log_lt_log (by norm_num) hu_gt2
    have hlogu_pos : 0 < Real.log u := lt_trans hlog2_pos hlogu_gt
    have hlog_le_CK : Real.log u ≤ Real.log (C_K * D / (ε * δ)) := by
      apply Real.log_le_log hu_pos
      have h1 : 1 * D ≤ C_K * D := mul_le_mul_of_nonneg_right hCK1 hD_pos.le
      rw [one_mul] at h1
      exact div_le_div_of_nonneg_right h1 (mul_pos hε_pos hδ_pos).le
    have harg_eq : C₁ * D / ((ε / 4) * (δ / 2)) = (8 * C₁) * u := by
      dsimp [u]; ring
    have h_abs_log : |Real.log (C₁ * D / ((ε / 4) * (δ / 2)))| ≤
        (1 + |Real.log (8 * C₁)| / Real.log 2) * Real.log (C_K * D / (ε * δ)) := by
      rw [harg_eq, Real.log_mul (by positivity) hu_pos.ne']
      have h1 : |Real.log (8 * C₁) + Real.log u| ≤ |Real.log (8 * C₁)| + |Real.log u| :=
        abs_add_le _ _
      rw [abs_of_pos hlogu_pos] at h1
      have h2 : |Real.log (8 * C₁)| ≤ (|Real.log (8 * C₁)| / Real.log 2) * Real.log u := by
        have hdiv : |Real.log (8 * C₁)| =
            (|Real.log (8 * C₁)| / Real.log 2) * Real.log 2 :=
          (div_mul_cancel₀ _ hlog2_pos.ne').symm
        conv_lhs => rw [hdiv]
        exact mul_le_mul_of_nonneg_left hlogu_gt.le (div_nonneg (abs_nonneg _) hlog2_pos.le)
      have h3 : |Real.log (8 * C₁) + Real.log u| ≤
          (1 + |Real.log (8 * C₁)| / Real.log 2) * Real.log u := by linarith
      exact le_trans h3 (mul_le_mul_of_nonneg_left hlog_le_CK (by positivity))
    have h_sq_log : (Real.log (C₁ * D / ((ε / 4) * (δ / 2)))) ^ 2 ≤
        (1 + |Real.log (8 * C₁)| / Real.log 2) ^ 2 * (Real.log (C_K * D / (ε * δ))) ^ 2 := by
      have h := pow_le_pow_left₀ (abs_nonneg _) h_abs_log 2
      rwa [sq_abs, mul_pow] at h
    have hDe4 : (D / (ε / 4)) ^ 2 = 16 * (D / ε) ^ 2 := by ring
    calc C₁ * (D / (ε / 4)) ^ 2 * (Real.log (C₁ * D / ((ε / 4) * (δ / 2)))) ^ 2
        = 16 * C₁ * (D / ε) ^ 2 * (Real.log (C₁ * D / ((ε / 4) * (δ / 2)))) ^ 2 := by
            rw [hDe4]; ring
      _ ≤ 16 * C₁ * (D / ε) ^ 2 *
            ((1 + |Real.log (8 * C₁)| / Real.log 2) ^ 2 *
              (Real.log (C_K * D / (ε * δ))) ^ 2) :=
          mul_le_mul_of_nonneg_left h_sq_log (by positivity)
      _ = (16 * C₁ * (1 + |Real.log (8 * C₁)| / Real.log 2) ^ 2) *
            ((D / ε) ^ 2 * (Real.log (C_K * D / (ε * δ))) ^ 2) := by ring
      _ ≤ C_K * ((D / ε) ^ 2 * (Real.log (C_K * D / (ε * δ))) ^ 2) :=
          mul_le_mul_of_nonneg_right hCK_quad (by positivity)
      _ = C_K * (D / ε) ^ 2 * (Real.log (C_K * D / (ε * δ))) ^ 2 := by ring
      _ ≤ (n : ℝ) := hn
  · have hDe_pow : (D / (ε / 4)) ^ (K - 1) = (4 : ℝ) ^ (K - 1) * (D / ε) ^ (K - 1) := by
      rw [show D / (ε / 4) = 4 * (D / ε) by ring, mul_pow]
    have hDe_sq : (D / (ε / 4)) ^ 2 = 16 * (D / ε) ^ 2 := by ring
    have h2d : 2 < 2 / δ := by
      rw [lt_div_iff₀ hδ_pos]; linarith
    have hlog_d : Real.log ((2 : ℝ) / (δ / 2)) ≤ 2 * Real.log (2 / δ) := by
      have heq : (2 : ℝ) / (δ / 2) = 2 * (2 / δ) := by ring
      rw [heq, Real.log_mul two_ne_zero (by positivity)]
      have hlt : Real.log 2 < Real.log (2 / δ) := Real.log_lt_log (by norm_num) h2d
      linarith
    have hterm1 : C₁ * (D / (ε / 4)) ^ (K - 1) ≤ C_K * (D / ε) ^ (K - 1) := by
      rw [hDe_pow, ← mul_assoc]
      exact mul_le_mul_of_nonneg_right hCK_pow (by positivity)
    have hterm2 : C₁ * ((D / (ε / 4)) ^ 2 * Real.log ((2 : ℝ) / (δ / 2))) ≤
        C_K * ((D / ε) ^ 2 * Real.log (2 / δ)) := by
      calc C₁ * ((D / (ε / 4)) ^ 2 * Real.log ((2 : ℝ) / (δ / 2)))
          ≤ C₁ * ((16 * (D / ε) ^ 2) * (2 * Real.log (2 / δ))) := by
            rw [hDe_sq]
            exact mul_le_mul_of_nonneg_left
              (mul_le_mul_of_nonneg_left hlog_d (by positivity)) hC₁.le
        _ = (32 * C₁) * ((D / ε) ^ 2 * Real.log (2 / δ)) := by ring
        _ ≤ C_K * ((D / ε) ^ 2 * Real.log (2 / δ)) := by
            have hlog_nn : 0 ≤ Real.log (2 / δ) := (Real.log_pos (by linarith)).le
            exact mul_le_mul_of_nonneg_right hCK_32 (by positivity)
    linarith

private lemma x0_log_ratio_le {C_K D ε δ N : ℝ}
    (hCK8 : 8 ≤ C_K) (hε_pos : 0 < ε) (hε_le : ε ≤ D)
    (hδ_pos : 0 < δ) (hδ_lt : δ < (1 : ℝ) / 2)
    (hN : C_K * (D / ε) ^ 2 * (Real.log (C_K * D / (ε * δ))) ^ 2 ≤ N) :
    0 < N ∧
    Real.log (2 * N) / Real.sqrt N ≤ 5 / (Real.sqrt C_K * (D / ε)) ∧
    Real.sqrt (Real.log (2 / (δ / 4))) / Real.sqrt N ≤ 1 / (Real.sqrt C_K * (D / ε)) := by
  have hCK_pos : 0 < C_K := by linarith
  have hsqrtCK_pos : 0 < Real.sqrt C_K := Real.sqrt_pos.mpr hCK_pos
  have hD_pos : 0 < D := lt_of_lt_of_le hε_pos hε_le
  have hDe_ge1 : 1 ≤ D / ε := (one_le_div hε_pos).mpr hε_le
  have hDe_pos : 0 < D / ε := by linarith
  have hU_ge16 : 16 ≤ C_K * D / (ε * δ) := by
    rw [le_div_iff₀ (mul_pos hε_pos hδ_pos)]
    have h1 : 8 * D ≤ C_K * D := mul_le_mul_of_nonneg_right hCK8 hD_pos.le
    nlinarith
  have h2CK_le : 2 * C_K ≤ C_K * D / (ε * δ) := by
    rw [le_div_iff₀ (mul_pos hε_pos hδ_pos)]
    have h1 : 2 * (ε * δ) ≤ D := by nlinarith
    calc 2 * C_K * (ε * δ) = C_K * (2 * (ε * δ)) := by ring
      _ ≤ C_K * D := mul_le_mul_of_nonneg_left h1 hCK_pos.le
  have hDe_le : D / ε ≤ C_K * D / (ε * δ) := by
    rw [div_le_div_iff₀ hε_pos (mul_pos hε_pos hδ_pos)]
    have h1 : δ ≤ C_K := by linarith
    calc D * (ε * δ) = (D * ε) * δ := by ring
      _ ≤ (D * ε) * C_K := mul_le_mul_of_nonneg_left h1 (mul_nonneg hD_pos.le hε_pos.le)
      _ = C_K * D * ε := by ring
  have h8d_le : 8 / δ ≤ C_K * D / (ε * δ) := by
    rw [div_le_div_iff₀ hδ_pos (mul_pos hε_pos hδ_pos)]
    have h1 : 8 * ε ≤ C_K * D := le_trans (mul_le_mul_of_nonneg_left hε_le (by norm_num))
      (mul_le_mul_of_nonneg_right hCK8 hD_pos.le)
    calc 8 * (ε * δ) = (8 * ε) * δ := by ring
      _ ≤ (C_K * D) * δ := mul_le_mul_of_nonneg_right h1 hδ_pos.le
  generalize C_K * D / (ε * δ) = U at hN hU_ge16 h2CK_le hDe_le h8d_le
  have hU_pos : 0 < U := by linarith
  have hlogU_gt2 : 2 < Real.log U := two_lt_log_of_sixteen_le hU_ge16
  have hlogU_pos : 0 < Real.log U := by linarith
  have hx₀_ge8 : 8 ≤ C_K * (D / ε) ^ 2 * (Real.log U) ^ 2 := by
    have h1 : 1 ≤ (D / ε) ^ 2 := by nlinarith
    have h2 : 4 ≤ (Real.log U) ^ 2 := by nlinarith
    have h3 : 8 ≤ C_K * (D / ε) ^ 2 := by nlinarith
    nlinarith
  have hN_pos : 0 < N := lt_of_lt_of_le (by norm_num : (0 : ℝ) < 8) (le_trans hx₀_ge8 hN)
  have hsqrt_x₀ : Real.sqrt (C_K * (D / ε) ^ 2 * (Real.log U) ^ 2) =
      Real.sqrt C_K * (D / ε) * Real.log U := by
    have hsq : C_K * (D / ε) ^ 2 * (Real.log U) ^ 2 =
        (Real.sqrt C_K * (D / ε) * Real.log U) ^ 2 := by
      rw [mul_pow, mul_pow, Real.sq_sqrt hCK_pos.le]
    rw [hsq, Real.sqrt_sq (by positivity)]
  have h2x₀_le : 2 * (C_K * (D / ε) ^ 2 * (Real.log U) ^ 2) ≤ U ^ 5 := by
    have hlogU_le_U : Real.log U ≤ U := by linarith [Real.log_le_sub_one_of_pos hU_pos]
    have hDe_sq : (D / ε) ^ 2 ≤ U ^ 2 := pow_le_pow_left₀ hDe_pos.le hDe_le 2
    have hlog_sq : (Real.log U) ^ 2 ≤ U ^ 2 := pow_le_pow_left₀ hlogU_pos.le hlogU_le_U 2
    calc 2 * (C_K * (D / ε) ^ 2 * (Real.log U) ^ 2)
        = (2 * C_K) * (D / ε) ^ 2 * (Real.log U) ^ 2 := by ring
      _ ≤ U * U ^ 2 * U ^ 2 :=
          mul_le_mul (mul_le_mul h2CK_le hDe_sq (sq_nonneg _) hU_pos.le)
            hlog_sq (sq_nonneg _) (by positivity)
      _ = U ^ 5 := by ring
  have hlog2x₀ : Real.log (2 * (C_K * (D / ε) ^ 2 * (Real.log U) ^ 2)) ≤ 5 * Real.log U := by
    have h := Real.log_le_log (by linarith) h2x₀_le
    rwa [Real.log_pow, Nat.cast_ofNat] at h
  have hr1 : Real.log (2 * N) / Real.sqrt N ≤ 5 / (Real.sqrt C_K * (D / ε)) := by
    calc Real.log (2 * N) / Real.sqrt N
        ≤ Real.log (2 * (C_K * (D / ε) ^ 2 * (Real.log U) ^ 2)) /
            Real.sqrt (C_K * (D / ε) ^ 2 * (Real.log U) ^ 2) :=
          log_two_mul_div_sqrt_antitone hx₀_ge8 hN
      _ ≤ (5 * Real.log U) / (Real.sqrt C_K * (D / ε) * Real.log U) := by
          rw [hsqrt_x₀]
          exact div_le_div_of_nonneg_right hlog2x₀ (by positivity)
      _ = 5 / (Real.sqrt C_K * (D / ε)) := by
          field_simp [hsqrtCK_pos.ne', hDe_pos.ne', hlogU_pos.ne']
  have h8d_ge16 : 16 ≤ 8 / δ := by rw [le_div_iff₀ hδ_pos]; linarith
  have hlog8d_gt2 : 2 < Real.log (8 / δ) := two_lt_log_of_sixteen_le h8d_ge16
  have hsqrt_log8d : Real.sqrt (Real.log (2 / (δ / 4))) ≤ Real.log U := by
    rw [show 2 / (δ / 4) = 8 / δ by ring]
    have h1 : Real.sqrt (Real.log (8 / δ)) ≤ Real.log (8 / δ) := by
      have hsq : Real.sqrt (Real.log (8 / δ)) ^ 2 ≤ (Real.log (8 / δ)) ^ 2 := by
        rw [Real.sq_sqrt (by linarith)]; nlinarith
      nlinarith [Real.sqrt_nonneg (Real.log (8 / δ))]
    exact le_trans h1 (Real.log_le_log (by linarith) h8d_le)
  have hr2 : Real.sqrt (Real.log (2 / (δ / 4))) / Real.sqrt N ≤
      1 / (Real.sqrt C_K * (D / ε)) := by
    calc Real.sqrt (Real.log (2 / (δ / 4))) / Real.sqrt N
        ≤ Real.log U / Real.sqrt (C_K * (D / ε) ^ 2 * (Real.log U) ^ 2) :=
          div_le_div₀ hlogU_pos.le hsqrt_log8d (by rw [hsqrt_x₀]; positivity) (Real.sqrt_le_sqrt hN)
      _ = Real.log U / (Real.sqrt C_K * (D / ε) * Real.log U) := by rw [hsqrt_x₀]
      _ = 1 / (Real.sqrt C_K * (D / ε)) := by
          field_simp [hsqrtCK_pos.ne', hDe_pos.ne', hlogU_pos.ne']
  exact ⟨hN_pos, hr1, hr2⟩

private lemma lem_C_3_bound_le_quad {C_K C₃ D D₀ M₀ ε δ N : ℝ}
    (hCK8 : 8 ≤ C_K) (hsqrtCK_ge : 1152 * C₃ ≤ Real.sqrt C_K)
    (hC₃ : 0 < C₃) (hM₀_le : M₀ ≤ 6 * D) (hD₀_le : D₀ ≤ 6 * D)
    (hε_pos : 0 < ε) (hε_le : ε ≤ D)
    (hδ_pos : 0 < δ) (hδ_lt : δ < (1 : ℝ) / 2)
    (hN : C_K * (D / ε) ^ 2 * (Real.log (C_K * D / (ε * δ))) ^ 2 ≤ N) :
    C₃ * (D₀ * Real.log (2 * N) + M₀ * Real.sqrt (Real.log (2 / (δ / 4)))) / Real.sqrt N ≤
      ε / 16 := by
  obtain ⟨hN_pos, hr1, hr2⟩ := x0_log_ratio_le hCK8 hε_pos hε_le hδ_pos hδ_lt hN
  have hsqrtCK_pos : 0 < Real.sqrt C_K := Real.sqrt_pos.mpr (by linarith)
  have hD_pos : 0 < D := lt_of_lt_of_le hε_pos hε_le
  have hsqrtN_pos : 0 < Real.sqrt N := Real.sqrt_pos.mpr hN_pos
  have hlog2N_nn : 0 ≤ Real.log (2 * N) / Real.sqrt N := by
    have hN1 : 1 ≤ 2 * N := by
      have hU : 16 ≤ C_K * D / (ε * δ) := by
        rw [le_div_iff₀ (mul_pos hε_pos hδ_pos)]
        have h1 : 8 * D ≤ C_K * D := mul_le_mul_of_nonneg_right hCK8 hD_pos.le
        nlinarith
      have hlog : 2 < Real.log (C_K * D / (ε * δ)) := two_lt_log_of_sixteen_le hU
      have hDe : 1 ≤ D / ε := (one_le_div hε_pos).mpr hε_le
      have hsq1 : 1 ≤ (D / ε) ^ 2 := by nlinarith
      have hsq2 : 4 ≤ (Real.log (C_K * D / (ε * δ))) ^ 2 := by nlinarith
      have h8 : 8 ≤ C_K * (D / ε) ^ 2 := by nlinarith
      nlinarith
    exact div_nonneg (Real.log_nonneg hN1) hsqrtN_pos.le
  have ht1 : C₃ * D₀ * (Real.log (2 * N) / Real.sqrt N) ≤ (30 * C₃ / Real.sqrt C_K) * ε := by
    calc C₃ * D₀ * (Real.log (2 * N) / Real.sqrt N)
        ≤ C₃ * (6 * D) * (5 / (Real.sqrt C_K * (D / ε))) :=
          mul_le_mul (mul_le_mul_of_nonneg_left hD₀_le hC₃.le) hr1 hlog2N_nn (by positivity)
      _ = (30 * C₃ / Real.sqrt C_K) * ε := by
          field_simp [hsqrtCK_pos.ne', hε_pos.ne', hD_pos.ne']; ring
  have ht2 : C₃ * M₀ * (Real.sqrt (Real.log (2 / (δ / 4))) / Real.sqrt N) ≤
      (6 * C₃ / Real.sqrt C_K) * ε := by
    calc C₃ * M₀ * (Real.sqrt (Real.log (2 / (δ / 4))) / Real.sqrt N)
        ≤ C₃ * (6 * D) * (1 / (Real.sqrt C_K * (D / ε))) :=
          mul_le_mul (mul_le_mul_of_nonneg_left hM₀_le hC₃.le) hr2
            (div_nonneg (Real.sqrt_nonneg _) hsqrtN_pos.le) (by positivity)
      _ = (6 * C₃ / Real.sqrt C_K) * ε := by
          field_simp [hsqrtCK_pos.ne', hε_pos.ne', hD_pos.ne']
  have h36 : 36 * C₃ / Real.sqrt C_K ≤ 1 / 16 := by
    rw [div_le_iff₀ hsqrtCK_pos]; linarith
  calc C₃ * (D₀ * Real.log (2 * N) + M₀ * Real.sqrt (Real.log (2 / (δ / 4)))) / Real.sqrt N
      = C₃ * D₀ * (Real.log (2 * N) / Real.sqrt N) +
          C₃ * M₀ * (Real.sqrt (Real.log (2 / (δ / 4))) / Real.sqrt N) := by ring
    _ ≤ (30 * C₃ / Real.sqrt C_K) * ε + (6 * C₃ / Real.sqrt C_K) * ε := add_le_add ht1 ht2
    _ = (36 * C₃ / Real.sqrt C_K) * ε := by ring
    _ ≤ (1 / 16) * ε := mul_le_mul_of_nonneg_right h36 hε_pos.le
    _ = ε / 16 := by ring

private lemma lem_C_3_bound_le_high {m : ℕ} (hm : 3 ≤ m) {C_K C₃ D D₀ M₀ ε δ N : ℝ}
    (hCK8 : 8 ≤ C_K) (hsqrtCK_ge : 1152 * C₃ ≤ Real.sqrt C_K)
    (hCK_pow : (192 * C₃) ^ m ≤ C_K)
    (hC₃ : 0 < C₃) (hM₀_le : M₀ ≤ 6 * D) (hD₀_le : D₀ ≤ 6 * D)
    (hε_pos : 0 < ε) (hε_le : ε ≤ D)
    (hδ_pos : 0 < δ) (hδ_lt : δ < (1 : ℝ) / 2)
    (hN : C_K * ((D / ε) ^ m + (D / ε) ^ 2 * Real.log (2 / δ)) ≤ N) :
    C₃ * D₀ * (N ^ (-(1 : ℝ) / (m : ℝ))) +
      C₃ * M₀ * Real.sqrt (Real.log (2 / (δ / 4)) / N) ≤ ε / 16 := by
  have hCK_pos : 0 < C_K := by linarith
  have hsqrtCK_pos : 0 < Real.sqrt C_K := Real.sqrt_pos.mpr hCK_pos
  have hD_pos : 0 < D := lt_of_lt_of_le hε_pos hε_le
  have hDe_pos : 0 < D / ε := div_pos hD_pos hε_pos
  have hm_pos : 0 < (m : ℝ) := by exact_mod_cast (by omega : 0 < m)
  have h2d_gt4 : 4 < 2 / δ := by rw [lt_div_iff₀ hδ_pos]; linarith
  have hlog2d_pos : 0 < Real.log (2 / δ) := Real.log_pos (by linarith)
  have hN_pow : C_K * (D / ε) ^ m ≤ N := by
    have hnn : 0 ≤ C_K * ((D / ε) ^ 2 * Real.log (2 / δ)) := by positivity
    linarith
  have hN_log : C_K * (D / ε) ^ 2 * Real.log (2 / δ) ≤ N := by
    have hnn : 0 ≤ C_K * (D / ε) ^ m := by positivity
    linarith
  have hN_pos : 0 < N := lt_of_lt_of_le (by positivity) hN_pow
  have h_base_pow : (192 * C₃ * (D / ε)) ^ m ≤ N := by
    calc (192 * C₃ * (D / ε)) ^ m
        = (192 * C₃) ^ m * (D / ε) ^ m := mul_pow _ _ _
      _ ≤ C_K * (D / ε) ^ m := mul_le_mul_of_nonneg_right hCK_pow (by positivity)
      _ ≤ N := hN_pow
  have h_rpow_ge : 192 * C₃ * (D / ε) ≤ N ^ ((1 : ℝ) / (m : ℝ)) := by
    have h1 := Real.rpow_le_rpow (by positivity) h_base_pow (one_div_pos.mpr hm_pos).le
    rw [← Real.rpow_natCast, ← Real.rpow_mul (by positivity),
      mul_one_div_cancel hm_pos.ne', Real.rpow_one] at h1
    exact h1
  have h_rpow_neg : N ^ (-(1 : ℝ) / (m : ℝ)) ≤ (192 * C₃ * (D / ε))⁻¹ := by
    rw [show -(1 : ℝ) / (m : ℝ) = -((1 : ℝ) / (m : ℝ)) by ring, Real.rpow_neg hN_pos.le]
    exact inv_anti₀ (by positivity) h_rpow_ge
  have hterm1 : C₃ * D₀ * (N ^ (-(1 : ℝ) / (m : ℝ))) ≤ ε / 32 := by
    calc C₃ * D₀ * (N ^ (-(1 : ℝ) / (m : ℝ)))
        ≤ C₃ * (6 * D) * (192 * C₃ * (D / ε))⁻¹ :=
          mul_le_mul (mul_le_mul_of_nonneg_left hD₀_le hC₃.le) h_rpow_neg
            (Real.rpow_nonneg hN_pos.le _) (by positivity)
      _ = ε / 32 := by
          field_simp [hC₃.ne', hD_pos.ne', hε_pos.ne']
          ring
  have hlog_num : Real.log (2 / (δ / 4)) ≤ 2 * Real.log (2 / δ) := by
    rw [show 2 / (δ / 4) = 4 * (2 / δ) by ring, Real.log_mul (by norm_num) (by positivity)]
    have hlt : Real.log 4 < Real.log (2 / δ) := Real.log_lt_log (by norm_num) h2d_gt4
    linarith
  have h_quot : Real.log (2 / (δ / 4)) / N ≤ (2 / (Real.sqrt C_K * (D / ε))) ^ 2 := by
    calc Real.log (2 / (δ / 4)) / N
        ≤ (2 * Real.log (2 / δ)) / (C_K * (D / ε) ^ 2 * Real.log (2 / δ)) :=
          div_le_div₀ (by positivity) hlog_num (by positivity) hN_log
      _ = 2 / (C_K * (D / ε) ^ 2) := by
          field_simp [hlog2d_pos.ne', hDe_pos.ne', hCK_pos.ne']
      _ ≤ 4 / (C_K * (D / ε) ^ 2) :=
          div_le_div_of_nonneg_right (by norm_num) (by positivity)
      _ = (2 / (Real.sqrt C_K * (D / ε))) ^ 2 := by
          rw [div_pow 2, mul_pow, Real.sq_sqrt hCK_pos.le]; norm_num
  have h_sqrt_quot : Real.sqrt (Real.log (2 / (δ / 4)) / N) ≤
      2 / (Real.sqrt C_K * (D / ε)) := by
    have h := Real.sqrt_le_sqrt h_quot
    rwa [Real.sqrt_sq (by positivity)] at h
  have hterm2 : C₃ * M₀ * Real.sqrt (Real.log (2 / (δ / 4)) / N) ≤ ε / 32 := by
    have h12 : 12 * C₃ / Real.sqrt C_K ≤ 1 / 32 := by
      rw [div_le_iff₀ hsqrtCK_pos]; linarith
    calc C₃ * M₀ * Real.sqrt (Real.log (2 / (δ / 4)) / N)
        ≤ C₃ * (6 * D) * (2 / (Real.sqrt C_K * (D / ε))) :=
          mul_le_mul (mul_le_mul_of_nonneg_left hM₀_le hC₃.le) h_sqrt_quot
            (Real.sqrt_nonneg _) (by positivity)
      _ = (12 * C₃ / Real.sqrt C_K) * ε := by
          field_simp [hsqrtCK_pos.ne', hD_pos.ne', hε_pos.ne']; ring
      _ ≤ (1 / 32) * ε := mul_le_mul_of_nonneg_right h12 hε_pos.le
      _ = ε / 32 := by ring
  linarith

/-- The `S_lem_C_3` uniform deviation bound at `(C₃, D₀, M₀, n, δ / 4)` is at most `ε / 16`
whenever `0 < M₀ ≤ 6 * D` and `0 < D₀ ≤ 6 * D`. -/
lemma lem_C_3_bound_le {K : ℕ} (_hK : 2 ≤ K) {C₁ C₃ D D₀ M₀ ε δ : ℝ}
    (hC₃ : 0 < C₃) (_hM₀_pos : 0 < M₀) (hM₀_le : M₀ ≤ 6 * D)
    (_hD₀_pos : 0 < D₀) (hD₀_le : D₀ ≤ 6 * D)
    (hε_pos : 0 < ε) (hε_le : ε ≤ D)
    (hδ_pos : 0 < δ) (hδ_lt : δ < (1 : ℝ) / 2) {n : ℕ}
    (hn : (if K - 1 ≤ 2 then
        chooseCK K C₁ C₃ * (D / ε) ^ 2 *
          (Real.log (chooseCK K C₁ C₃ * D / (ε * δ))) ^ 2 ≤ (n : ℝ)
      else
        chooseCK K C₁ C₃ *
          ((D / ε) ^ (K - 1) + (D / ε) ^ 2 * Real.log (2 / δ)) ≤ (n : ℝ))) :
    (if K - 1 ≤ 2 then
      C₃ * (D₀ * Real.log (2 * (n : ℝ)) + M₀ * Real.sqrt (Real.log (2 / (δ / 4)))) /
        Real.sqrt (n : ℝ)
    else
      C₃ * D₀ * ((n : ℝ) ^ (-(1 : ℝ) / ((K - 1 : ℕ) : ℝ))) +
        C₃ * M₀ * Real.sqrt (Real.log (2 / (δ / 4)) / (n : ℝ))) ≤ ε / 16 := by
  split_ifs at hn ⊢ with hm
  · exact lem_C_3_bound_le_quad (eight_le_chooseCK K C₁ C₃) (sqrt_chooseCK_ge K hC₃)
      hC₃ hM₀_le hD₀_le hε_pos hε_le hδ_pos hδ_lt hn
  · exact lem_C_3_bound_le_high (by omega) (eight_le_chooseCK K C₁ C₃) (sqrt_chooseCK_ge K hC₃)
      (chooseCK_ge_c3_pow K C₁ C₃) hC₃ hM₀_le hD₀_le hε_pos hε_le hδ_pos hδ_lt hn

end UL.Proof_thm_5_1

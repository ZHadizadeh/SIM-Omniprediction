import Mathlib
import UL.Stmt.lem_C_3
import UL.Stmt.thm_C_1
import UL.Proof.thm_5_1.H1_Rates
import UL.Proof.thm_5_1.H2_LossAndNet
set_option autoImplicit false

namespace UL.Proof_thm_5_1

open Set Filter Topology MeasureTheory

/-! ### Universe-lifted Euclidean space and Hilbert–Schmidt invariance -/

abbrev LiftX.{u} (d : ℕ) : Type u :=
  EuclideanSpace ℝ (ULift.{u} (Fin d))

noncomputable def isoX.{u} (d : ℕ) : LiftX.{u} d ≃ₗᵢ[ℝ] EuclideanSpace ℝ (Fin d) :=
  LinearIsometryEquiv.piLpCongrLeft 2 ℝ ℝ Equiv.ulift

lemma adjVec_comp_linearIsometryEquiv {E₁ E₂ Y : Type*}
    [NormedAddCommGroup E₁] [InnerProductSpace ℝ E₁] [CompleteSpace E₁]
    [NormedAddCommGroup E₂] [InnerProductSpace ℝ E₂] [CompleteSpace E₂]
    [NormedAddCommGroup Y] [InnerProductSpace ℝ Y] [FiniteDimensional ℝ Y]
    (e : E₁ ≃ₗᵢ[ℝ] E₂) (W : E₂ →L[ℝ] Y) (y : Y) :
    UL.Proof_lem_C_2.adjVec (W.comp e.toLinearIsometry.toContinuousLinearMap) y =
      e.symm (UL.Proof_lem_C_2.adjVec W y) := by
  refine ext_inner_right ℝ fun x => ?_
  rw [UL.Proof_lem_C_2.inner_adjVec_left]
  change inner ℝ y (W (e x)) = inner ℝ (e.symm (UL.Proof_lem_C_2.adjVec W y)) x
  rw [← e.inner_map_map (e.symm (UL.Proof_lem_C_2.adjVec W y)) x,
    e.apply_symm_apply, UL.Proof_lem_C_2.inner_adjVec_left]

lemma hilbertSchmidtNorm_comp_linearIsometryEquiv {E₁ E₂ Y : Type*}
    [NormedAddCommGroup E₁] [InnerProductSpace ℝ E₁] [CompleteSpace E₁]
    [NormedAddCommGroup E₂] [InnerProductSpace ℝ E₂] [CompleteSpace E₂]
    [NormedAddCommGroup Y] [InnerProductSpace ℝ Y] [FiniteDimensional ℝ Y]
    (e : E₁ ≃ₗᵢ[ℝ] E₂) (W : E₂ →L[ℝ] Y) :
    UL.hilbertSchmidtNorm (W.comp e.toLinearIsometry.toContinuousLinearMap) =
      UL.hilbertSchmidtNorm W := by
  rw [UL.Proof_lem_C_2.hilbertSchmidtNorm_eq_sqrt (W.comp e.toLinearIsometry.toContinuousLinearMap),
    UL.Proof_lem_C_2.hilbertSchmidtNorm_eq_sqrt W]
  congr 1
  refine Finset.sum_congr rfl fun j _ => ?_
  rw [adjVec_comp_linearIsometryEquiv, e.symm.norm_map]

noncomputable def pullOp.{u} {d K : ℕ}
    (W : LiftX.{u} d →L[ℝ] UL.ZeroSumSubspace K) :
    EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K :=
  W.comp (isoX.{u} d).symm.toLinearIsometry.toContinuousLinearMap

noncomputable def pushOp.{u} {d K : ℕ}
    (V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K) :
    LiftX.{u} d →L[ℝ] UL.ZeroSumSubspace K :=
  V.comp (isoX.{u} d).toLinearIsometry.toContinuousLinearMap

@[simp]
lemma pullOp_apply.{u} {d K : ℕ} (W : LiftX.{u} d →L[ℝ] UL.ZeroSumSubspace K)
    (x : EuclideanSpace ℝ (Fin d)) :
    pullOp.{u} W x = W ((isoX.{u} d).symm x) := rfl

@[simp]
lemma pushOp_apply.{u} {d K : ℕ}
    (V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K) (x : LiftX.{u} d) :
    pushOp.{u} V x = V (isoX.{u} d x) := rfl

lemma hilbertSchmidtNorm_pullOp.{u} {d K : ℕ}
    (W : LiftX.{u} d →L[ℝ] UL.ZeroSumSubspace K) :
    UL.hilbertSchmidtNorm (pullOp.{u} W) = UL.hilbertSchmidtNorm W :=
  hilbertSchmidtNorm_comp_linearIsometryEquiv (isoX.{u} d).symm W

lemma hilbertSchmidtNorm_pushOp.{u} {d K : ℕ}
    (V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K) :
    UL.hilbertSchmidtNorm (pushOp.{u} V) = UL.hilbertSchmidtNorm V :=
  hilbertSchmidtNorm_comp_linearIsometryEquiv (isoX.{u} d) V

/-! ### Universe-lifted measures and i.i.d. sample spaces -/

noncomputable def measEquivXK.{u} (d K : ℕ) :
    (EuclideanSpace ℝ (Fin d) × Fin K) ≃ᵐ (LiftX.{u} d × Fin K) :=
  (isoX.{u} d).symm.toHomeomorph.toMeasurableEquiv.prodCongr (MeasurableEquiv.refl (Fin K))

@[simp]
lemma measEquivXK_apply.{u} {d K : ℕ} (z : EuclideanSpace ℝ (Fin d) × Fin K) :
    measEquivXK.{u} d K z = ((isoX.{u} d).symm z.1, z.2) := rfl

noncomputable def liftNu.{u} {d K : ℕ}
    (μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K)) :
    Measure (LiftX.{u} d × Fin K) :=
  μ.map (measEquivXK.{u} d K)

lemma isProbabilityMeasure_liftNu.{u} {d K : ℕ}
    (μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K)) [IsProbabilityMeasure μ] :
    IsProbabilityMeasure (liftNu.{u} μ) :=
  Measure.isProbabilityMeasure_map (measEquivXK.{u} d K).measurable.aemeasurable

lemma ae_norm_le_liftNu.{u} {d K : ℕ} {L : ℝ}
    {μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K)}
    (hL_ae : ∀ᵐ z ∂μ, ‖z.1‖ ≤ L) :
    ∀ᵐ xy ∂(liftNu.{u} μ), ‖xy.1‖ ≤ L := by
  have hmeas : MeasurableSet {xy : LiftX.{u} d × Fin K | ‖xy.1‖ ≤ L} :=
    (isClosed_le (continuous_norm.comp continuous_fst) continuous_const).measurableSet
  rw [liftNu, ae_map_iff (measEquivXK.{u} d K).measurable.aemeasurable hmeas]
  filter_upwards [hL_ae] with z hz
  change ‖(isoX.{u} d).symm z.1‖ ≤ L
  rwa [(isoX.{u} d).symm.norm_map]

lemma integral_liftNu.{u} {d K : ℕ}
    (μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K))
    (f : LiftX.{u} d → Fin K → ℝ) :
    (∫ xy, f xy.1 xy.2 ∂(liftNu.{u} μ)) =
      ∫ z, f ((isoX.{u} d).symm z.1) z.2 ∂μ :=
  integral_map_equiv (measEquivXK.{u} d K) (fun xy => f xy.1 xy.2)

abbrev SampSpace (d K n : ℕ) : Type :=
  Fin n → EuclideanSpace ℝ (Fin d) × Fin K

abbrev LiftΩ.{v} (d K n : ℕ) : Type v :=
  PUnit.{v + 1} × SampSpace d K n

noncomputable def eΩ.{v} (d K n : ℕ) : LiftΩ.{v} d K n ≃ᵐ SampSpace d K n :=
  MeasurableEquiv.punitProd

noncomputable def liftMuPi.{v} {d K n : ℕ}
    (μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K)) :
    Measure (LiftΩ.{v} d K n) :=
  (Measure.pi (fun _ : Fin n => μ)).map (eΩ.{v} d K n).symm

lemma isProbabilityMeasure_liftMuPi.{v} {d K n : ℕ}
    (μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K)) [IsProbabilityMeasure μ] :
    IsProbabilityMeasure (liftMuPi.{v} (n := n) μ) :=
  Measure.isProbabilityMeasure_map (eΩ.{v} d K n).symm.measurable.aemeasurable

lemma map_eΩ_liftMuPi.{v} {d K n : ℕ}
    (μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K)) :
    (liftMuPi.{v} (n := n) μ).map (eΩ.{v} d K n) = Measure.pi (fun _ : Fin n => μ) := by
  unfold liftMuPi
  rw [Measure.map_map (eΩ.{v} d K n).measurable (eΩ.{v} d K n).symm.measurable]
  have hid : (⇑(eΩ.{v} d K n) ∘ ⇑(eΩ.{v} d K n).symm) = id := by
    funext S; exact (eΩ.{v} d K n).apply_symm_apply S
  rw [hid, Measure.map_id]

noncomputable def liftXSamp.{u, v} {d K n : ℕ} (i : Fin n) (ω : LiftΩ.{v} d K n) : LiftX.{u} d :=
  (isoX.{u} d).symm ((eΩ.{v} d K n ω i).1)

noncomputable def liftYSamp.{v} {d K n : ℕ} (i : Fin n) (ω : LiftΩ.{v} d K n) : Fin K :=
  (eΩ.{v} d K n ω i).2

lemma measurable_liftXSamp.{u, v} (d K n : ℕ) (i : Fin n) :
    Measurable (@liftXSamp.{u, v} d K n i) :=
  (isoX.{u} d).symm.continuous.measurable.comp
    (measurable_fst.comp ((measurable_pi_apply i).comp (eΩ.{v} d K n).measurable))

lemma measurable_liftYSamp.{v} (d K n : ℕ) (i : Fin n) :
    Measurable (@liftYSamp.{v} d K n i) :=
  measurable_snd.comp ((measurable_pi_apply i).comp (eΩ.{v} d K n).measurable)

lemma map_liftSamp_eq_liftNu.{u, v} {d K n : ℕ}
    (μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K)) [IsProbabilityMeasure μ] (i : Fin n) :
    Measure.map (fun ω : LiftΩ.{v} d K n => (liftXSamp.{u, v} i ω, liftYSamp.{v} i ω))
      (liftMuPi.{v} μ) = liftNu.{u} μ := by
  have hf_eq : (fun ω : LiftΩ.{v} d K n => (liftXSamp.{u, v} i ω, liftYSamp.{v} i ω)) =
      (⇑(measEquivXK.{u} d K) ∘ Function.eval i) ∘ ⇑(eΩ.{v} d K n) := rfl
  rw [hf_eq, ← Measure.map_map ((measEquivXK.{u} d K).measurable.comp (measurable_pi_apply i))
      (eΩ.{v} d K n).measurable,
    map_eΩ_liftMuPi,
    ← Measure.map_map (measEquivXK.{u} d K).measurable (measurable_pi_apply i),
    (measurePreserving_eval (fun _ : Fin n => μ) i).map_eq]
  rfl

lemma iIndepFun_liftSamp.{u, v} {d K n : ℕ}
    (μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K)) [IsProbabilityMeasure μ] :
    ProbabilityTheory.iIndepFun
      (fun i (ω : LiftΩ.{v} d K n) => (liftXSamp.{u, v} i ω, liftYSamp.{v} i ω))
      (liftMuPi.{v} μ) := by
  let μ_pi := Measure.pi (fun _ : Fin n => μ)
  have hind₀ : ProbabilityTheory.iIndepFun (fun (i : Fin n) (S : SampSpace d K n) => S i) μ_pi :=
    ProbabilityTheory.iIndepFun_pi (fun _ => aemeasurable_id)
  have hind₁ : ProbabilityTheory.iIndepFun
      (fun (i : Fin n) (S : SampSpace d K n) => measEquivXK.{u} d K (S i)) μ_pi :=
    hind₀.comp (fun _ => ⇑(measEquivXK.{u} d K)) (fun _ => (measEquivXK.{u} d K).measurable)
  rw [ProbabilityTheory.iIndepFun_iff_measure_inter_preimage_eq_mul] at hind₁ ⊢
  intro s sets hsets
  have hmap_eq : μ_pi = (liftMuPi.{v} (n := n) μ).map (eΩ.{v} d K n) :=
    (map_eΩ_liftMuPi.{v} μ).symm
  have h_inter_meas : MeasurableSet
      (⋂ i ∈ s, (fun S : SampSpace d K n => measEquivXK.{u} d K (S i)) ⁻¹' sets i) :=
    Finset.measurableSet_biInter s fun i hi =>
      ((measEquivXK.{u} d K).measurable.comp (measurable_pi_apply i)) (hsets i hi)
  have hlhs : (liftMuPi.{v} (n := n) μ)
      (⋂ i ∈ s, (fun ω => (liftXSamp.{u, v} i ω, liftYSamp.{v} i ω)) ⁻¹' sets i) =
      μ_pi (⋂ i ∈ s, (fun S : SampSpace d K n => measEquivXK.{u} d K (S i)) ⁻¹' sets i) := by
    rw [hmap_eq, Measure.map_apply (eΩ.{v} d K n).measurable h_inter_meas]
    congr 1
    ext ω
    simp [liftXSamp, liftYSamp]
  rw [hlhs, hind₁ s hsets]
  refine Finset.prod_congr rfl fun i hi => ?_
  have hi_meas : MeasurableSet
      ((fun S : SampSpace d K n => measEquivXK.{u} d K (S i)) ⁻¹' sets i) :=
    ((measEquivXK.{u} d K).measurable.comp (measurable_pi_apply i)) (hsets i hi)
  rw [hmap_eq, Measure.map_apply (eΩ.{v} d K n).measurable hi_meas]
  rfl

lemma compl_measure_le_of_toReal_ge {Ω₀ : Type*} [MeasurableSpace Ω₀]
    (μ₀ : Measure Ω₀) [IsProbabilityMeasure μ₀] {E₀ : Set Ω₀} (hE₀ : MeasurableSet E₀)
    {δ' : ℝ} (hge : (μ₀ E₀).toReal ≥ 1 - δ') :
    μ₀ (E₀ᶜ) ≤ ENNReal.ofReal δ' := by
  have hsum : μ₀ E₀ + μ₀ (E₀ᶜ) = 1 := by
    rw [measure_add_measure_compl hE₀, measure_univ]
  have hsum_real : (μ₀ E₀).toReal + (μ₀ (E₀ᶜ)).toReal = 1 := by
    have h := congrArg ENNReal.toReal hsum
    rwa [ENNReal.toReal_add (measure_ne_top μ₀ E₀) (measure_ne_top μ₀ (E₀ᶜ)),
      ENNReal.toReal_one] at h
  have hle_real : (μ₀ (E₀ᶜ)).toReal ≤ δ' := by linarith
  rw [← ENNReal.ofReal_toReal (measure_ne_top μ₀ (E₀ᶜ))]
  exact ENNReal.ofReal_le_ofReal hle_real

lemma pullEvent_spec.{v} {d K n : ℕ}
    (μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K)) [IsProbabilityMeasure μ]
    {E : Set (LiftΩ.{v} d K n)} (hE : MeasurableSet E)
    {δ' : ℝ} (hge : (liftMuPi.{v} (n := n) μ E).toReal ≥ 1 - δ') :
    let E₀ : Set (SampSpace d K n) := (eΩ.{v} d K n).symm ⁻¹' E
    MeasurableSet E₀ ∧
    Measure.pi (fun _ : Fin n => μ) (E₀ᶜ) ≤ ENNReal.ofReal δ' ∧
    (∀ S ∈ E₀, (eΩ.{v} d K n).symm S ∈ E) := by
  intro E₀
  have hE₀_meas : MeasurableSet E₀ := (eΩ.{v} d K n).symm.measurable hE
  have h_eq : Measure.pi (fun _ : Fin n => μ) E₀ = liftMuPi.{v} (n := n) μ E :=
    (Measure.map_apply (eΩ.{v} d K n).symm.measurable hE).symm
  have hge₀ : (Measure.pi (fun _ : Fin n => μ) E₀).toReal ≥ 1 - δ' := by
    rwa [h_eq]
  exact ⟨hE₀_meas, compl_measure_le_of_toReal_ge _ hE₀_meas hge₀, fun _ hS => hS⟩

/-! ### Population objective, integrability, and perturbation -/

noncomputable def popForeObj {d K : ℕ}
    (μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K))
    (Φ : UL.Simplex K → ℝ) (h : CandType d K) : ℝ :=
  ∫ z, UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 (h.1 z.1))) z.2 ∂μ

noncomputable def popCompObj {d K : ℕ}
    (μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K))
    (Φ : UL.Simplex K → ℝ) (V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K) : ℝ :=
  ∫ z, UL.matchingLoss Φ ((V z.1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) z.2 ∂μ

noncomputable def popExcess {d K : ℕ}
    (μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K)) (R : ℝ)
    (Φ : UL.Simplex K → ℝ) (h : CandType d K) : ℝ :=
  popForeObj μ Φ h -
    (⨅ V : {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K //
        UL.hilbertSchmidtNorm V ≤ R},
      popCompObj μ Φ V.1)

lemma integrable_popFore {d K : ℕ} (hK : 2 ≤ K)
    {μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K)} [IsProbabilityMeasure μ]
    {R β lam M : ℝ} (hβ : 0 < β)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    {h : CandType d K} (hh : IsCand R β h) :
    Integrable (fun z : EuclideanSpace ℝ (Fin d) × Fin K =>
      UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 (h.1 z.1))) z.2) μ := by
  have hcont := continuous_forecastLoss_pair hK hβ hΦ hh
  refine (integrable_const (3 * M + |UL.matchingPotential Φ 0|)).mono'
    hcont.aestronglyMeasurable (Eventually.of_forall fun z => ?_)
  rw [Real.norm_eq_abs]
  have hb := abs_finiteCanonicalLoss_sub_pot0_le hK hΦ (hh.2.1 (h.1 z.1)) z.2
  calc |UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 (h.1 z.1))) z.2|
      = |(UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 (h.1 z.1))) z.2 -
          UL.matchingPotential Φ 0) + UL.matchingPotential Φ 0| := by ring_nf
    _ ≤ |UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 (h.1 z.1))) z.2 -
          UL.matchingPotential Φ 0| + |UL.matchingPotential Φ 0| := abs_add_le _ _
    _ ≤ 3 * M + |UL.matchingPotential Φ 0| := add_le_add hb le_rfl

lemma integrable_popComp {d K : ℕ} (hK : 2 ≤ K)
    {μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K)} [IsProbabilityMeasure μ]
    {L R : ℝ} (_hL : 0 < L) (_hR : 0 < R) (hL_ae : ∀ᵐ z ∂μ, ‖z.1‖ ≤ L)
    {Φ : UL.Simplex K → ℝ} (hΦ_cont : Continuous Φ)
    {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K}
    (hV : UL.hilbertSchmidtNorm V ≤ R) :
    Integrable (fun z : EuclideanSpace ℝ (Fin d) × Fin K =>
      UL.matchingLoss Φ ((V z.1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) z.2) μ := by
  have h1 : Continuous (fun z : EuclideanSpace ℝ (Fin d) × Fin K =>
      ((V z.1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))) :=
    continuous_subtype_val.comp (V.continuous.comp continuous_fst)
  have hcont : Continuous (fun z : EuclideanSpace ℝ (Fin d) × Fin K =>
      UL.matchingLoss Φ ((V z.1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) z.2) := by
    have heq : (fun z : EuclideanSpace ℝ (Fin d) × Fin K =>
        UL.matchingLoss Φ ((V z.1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) z.2) =
        fun z => ∑ y : Fin K, (if z.2 = y then (1 : ℝ) else 0) *
          UL.matchingLoss Φ ((V z.1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) y := by
      funext z; simp
    rw [heq]
    refine continuous_finset_sum _ fun y _ => Continuous.mul ?_ ?_
    · exact (continuous_of_discreteTopology
        (f := fun w : Fin K => if w = y then (1 : ℝ) else 0)).comp continuous_snd
    · exact (continuous_matchingLoss_y hK hΦ_cont y).comp h1
  refine (integrable_const (3 * (L * R) + |UL.matchingPotential Φ 0|)).mono'
    hcont.aestronglyMeasurable ?_
  filter_upwards [hL_ae] with z hz
  rw [Real.norm_eq_abs]
  have hnorm : ‖((V z.1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))‖ ≤ L * R := by
    change ‖V z.1‖ ≤ L * R
    calc ‖V z.1‖ ≤ UL.hilbertSchmidtNorm V * ‖z.1‖ :=
          UL.Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm V z.1
      _ ≤ R * L := mul_le_mul hV hz (norm_nonneg _)
          (le_trans (UL.Proof_lem_C_2.hilbertSchmidtNorm_nonneg V) hV)
      _ = L * R := mul_comm R L
  have hb : |UL.matchingLoss Φ ((V z.1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) z.2 -
      UL.matchingPotential Φ 0| ≤ 3 * (L * R) :=
    le_trans (abs_matchingLoss_sub_pot0_le hK hΦ_cont _ z.2)
      (mul_le_mul_of_nonneg_left hnorm (by norm_num))
  calc |UL.matchingLoss Φ ((V z.1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) z.2|
      = |(UL.matchingLoss Φ ((V z.1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) z.2 -
          UL.matchingPotential Φ 0) + UL.matchingPotential Φ 0| := by ring_nf
    _ ≤ |UL.matchingLoss Φ ((V z.1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) z.2 -
          UL.matchingPotential Φ 0| + |UL.matchingPotential Φ 0| := abs_add_le _ _
    _ ≤ 3 * (L * R) + |UL.matchingPotential Φ 0| := add_le_add hb le_rfl

lemma popCompObj_sub_pot0_bounds {d K : ℕ} (hK : 2 ≤ K)
    {μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K)} [IsProbabilityMeasure μ]
    {L R : ℝ} (hL : 0 < L) (hR : 0 < R) (hL_ae : ∀ᵐ z ∂μ, ‖z.1‖ ≤ L)
    {Φ : UL.Simplex K → ℝ} (hΦ_cont : Continuous Φ)
    {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K}
    (hV : UL.hilbertSchmidtNorm V ≤ R) :
    |popCompObj μ Φ V - UL.matchingPotential Φ 0| ≤ 3 * (L * R) := by
  have hInt := integrable_popComp hK hL hR hL_ae hΦ_cont hV
  have hconst_eq : UL.matchingPotential Φ 0 = ∫ _z, UL.matchingPotential Φ 0 ∂μ := by
    simp [integral_const]
  unfold popCompObj
  rw [hconst_eq, ← integral_sub hInt (integrable_const _), ← Real.norm_eq_abs]
  have hle := norm_integral_le_of_norm_le_const (C := 3 * (L * R)) (μ := μ)
    (f := fun z => UL.matchingLoss Φ ((V z.1 : UL.ZeroSumSubspace K) :
      EuclideanSpace ℝ (Fin K)) z.2 - UL.matchingPotential Φ 0) (by
      filter_upwards [hL_ae] with z hz
      rw [Real.norm_eq_abs]
      have hnorm : ‖((V z.1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K))‖ ≤ L * R := by
        change ‖V z.1‖ ≤ L * R
        calc ‖V z.1‖ ≤ UL.hilbertSchmidtNorm V * ‖z.1‖ :=
              UL.Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm V z.1
          _ ≤ R * L := mul_le_mul hV hz (norm_nonneg _)
              (le_trans (UL.Proof_lem_C_2.hilbertSchmidtNorm_nonneg V) hV)
          _ = L * R := mul_comm R L
      exact le_trans (abs_matchingLoss_sub_pot0_le hK hΦ_cont _ z.2)
        (mul_le_mul_of_nonneg_left hnorm (by norm_num)))
  simpa [measureReal_def] using hle

lemma popExcess_perturbation {d K : ℕ} (hK : 2 ≤ K)
    {μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K)} [IsProbabilityMeasure μ]
    {L R β lam M η : ℝ} (hβ : 0 < β) (hlam : 0 < lam) (_hη : 0 < η)
    (hL_ae : ∀ᵐ z ∂μ, ‖z.1‖ ≤ L)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    {h h' : CandType d K} (hh : IsCand R β h) (hh' : IsCand R β h')
    (hdist : ∀ x : EuclideanSpace ℝ (Fin d), ‖x‖ ≤ L →
      ‖h'.2 (h'.1 x) - h.2 (h.1 x)‖ < η) :
    popExcess μ R Φ h' ≤ popExcess μ R Φ h + (3 * lam) * η := by
  have hInt := integrable_popFore (μ := μ) hK hβ hΦ hh
  have hInt' := integrable_popFore (μ := μ) hK hβ hΦ hh'
  have hdiff : popForeObj μ Φ h' - popForeObj μ Φ h ≤ (3 * lam) * η := by
    unfold popForeObj
    rw [← integral_sub hInt' hInt]
    refine le_trans (le_abs_self _) ?_
    rw [← Real.norm_eq_abs]
    have hle := norm_integral_le_of_norm_le_const (C := (3 * lam) * η) (μ := μ)
      (f := fun z => UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h'.2 (h'.1 z.1))) z.2 -
        UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 (h.1 z.1))) z.2) (by
        filter_upwards [hL_ae] with z hz
        rw [Real.norm_eq_abs]
        exact le_trans
          (finiteCanonicalLoss_lipschitz_on_simplex hK hΦ (hh'.2.1 (h'.1 z.1)) (hh.2.1 (h.1 z.1)) z.2)
          (mul_le_mul_of_nonneg_left (hdist z.1 hz).le (by positivity)))
    simpa [measureReal_def] using hle
  unfold popExcess
  linarith

/-! ### Instantiating Theorem C.1 (`exists_c1_event`) -/

lemma exists_c1_event.{u₁, u₂} {d K n : ℕ} (hK : 2 ≤ K) (hn1 : 1 ≤ n)
    {C₁ C₃ L R β lam M ε δ : ℝ}
    (hC₁ : 0 < C₁) (hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) (hlam : 0 < lam) (hM : 0 < M)
    (hε_pos : 0 < ε) (hε_le : ε ≤ M + (L * R) + β * lam * (L * R))
    (hδ_pos : 0 < δ) (hδ_lt : δ < (1 : ℝ) / 2)
    (hn_c1 : (n : ℝ) ≥
      (if K - 1 ≤ 2 then
        C₁ * ((M + (L * R) + β * lam * (L * R)) / (ε / 4)) ^ 2 *
          (Real.log (C₁ * (M + (L * R) + β * lam * (L * R)) / ((ε / 4) * (δ / 2)))) ^ 2
      else
        C₁ * (((M + (L * R) + β * lam * (L * R)) / (ε / 4)) ^ (K - 1) +
          ((M + (L * R) + β * lam * (L * R)) / (ε / 4)) ^ 2 * Real.log ((2 : ℝ) / (δ / 2)))))
    (hc1_main : ∀ (X : Type u₁) [NormedAddCommGroup X] [InnerProductSpace ℝ X]
        [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
        [MeasurableSpace X] [BorelSpace X]
        (L R β lam M B : ℝ),
        0 < L → 0 < R → 0 < β → 0 < lam → 0 < M → β ≤ B →
        let m : ℕ := K - 1
        let A₀ : ℝ := L * R
        let D : ℝ := M + A₀ + B * lam * A₀
        ∀ (ε' δ' : ℝ), 0 < ε' → ε' ≤ D → 0 < δ' → δ' < (1 : ℝ) / 2 →
          ∀ (n : ℕ), 1 ≤ n →
            (n : ℝ) ≥
              (if m ≤ 2 then
                C₁ * (D / ε') ^ 2 * (Real.log (C₁ * D / (ε' * δ'))) ^ 2
              else
                C₁ * ((D / ε') ^ m + (D / ε') ^ 2 * Real.log ((2 : ℝ) / δ'))) →
            ∃ (learnerW : (Fin n → X × Fin K) → (X →L[ℝ] UL.ZeroSumSubspace K))
              (learnerRho : (Fin n → X × Fin K) →
                (UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K))),
              (∀ sample : Fin n → X × Fin K,
                UL.hilbertSchmidtNorm (learnerW sample) ≤ R ∧
                (∀ s : UL.ZeroSumSubspace K, learnerRho sample s ∈ UL.Simplex K) ∧
                LipschitzWith (Real.toNNReal B) (learnerRho sample)) ∧
              ∀ (ν : Measure (X × Fin K)) [IsProbabilityMeasure ν],
                (∀ᵐ xy ∂ν, ‖xy.1‖ ≤ L) →
                ∀ (Ω : Type u₂) [MeasurableSpace Ω] (μΩ : Measure Ω)
                  [IsProbabilityMeasure μΩ]
                  (X_samp : Fin n → Ω → X) (Y_samp : Fin n → Ω → Fin K),
                  (∀ i : Fin n, Measurable (X_samp i)) →
                  (∀ i : Fin n, Measurable (Y_samp i)) →
                  ProbabilityTheory.iIndepFun (fun i ω => (X_samp i ω, Y_samp i ω)) μΩ →
                  (∀ i : Fin n, Measure.map (fun ω => (X_samp i ω, Y_samp i ω)) μΩ = ν) →
                  ∃ E : Set Ω, MeasurableSet E ∧ (μΩ E).toReal ≥ 1 - δ' ∧
                    ∀ ω ∈ E,
                      let sample : Fin n → X × Fin K := fun i => (X_samp i ω, Y_samp i ω)
                      let W : X →L[ℝ] UL.ZeroSumSubspace K := learnerW sample
                      let ρ : UL.ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) := learnerRho sample
                      let p : X → EuclideanSpace ℝ (Fin K) := fun x => ρ (W x)
                      ∀ Φ ∈ UL.SmoothEntropyFamily K β lam M,
                        (∫ xy, UL.finiteCanonicalLoss Φ (p xy.1) xy.2 ∂ν) ≤
                          sInf ((fun V : X →L[ℝ] UL.ZeroSumSubspace K =>
                            ∫ xy, UL.matchingLoss Φ (V xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 ∂ν) ''
                            {V | UL.hilbertSchmidtNorm V ≤ R}) + ε')
    (μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K)) [IsProbabilityMeasure μ]
    (hL_ae : ∀ᵐ z ∂μ, ‖z.1‖ ≤ L) :
    let _ := C₁ + C₃
    ∃ E_C1 : Set (SampSpace d K n),
      MeasurableSet E_C1 ∧
      Measure.pi (fun _ : Fin n => μ) (E_C1ᶜ) ≤ ENNReal.ofReal (δ / 2) ∧
      ∀ S ∈ E_C1, ∃ h_S : CandType d K, IsCand R β h_S ∧
        ∀ Φ ∈ UL.SmoothEntropyFamily K β lam M, popExcess μ R Φ h_S ≤ ε / 4 := by
  intro _
  have _ := hC₁
  obtain ⟨learnerW, learnerRho, hfeas, hprob⟩ :=
    hc1_main (LiftX.{u₁} d) L R β lam M β hL hR hβ hlam hM le_rfl
      (ε / 4) (δ / 2) (by positivity) (by linarith) (by positivity) (by linarith) n hn1 hn_c1
  let ν : Measure (LiftX.{u₁} d × Fin K) := liftNu.{u₁} μ
  haveI : IsProbabilityMeasure ν := isProbabilityMeasure_liftNu.{u₁} μ
  let μΩ : Measure (LiftΩ.{u₂} d K n) := liftMuPi.{u₂} (n := n) μ
  haveI : IsProbabilityMeasure μΩ := isProbabilityMeasure_liftMuPi.{u₂} (n := n) μ
  obtain ⟨E, hE_meas, hE_prob, hE_good⟩ :=
    hprob ν (ae_norm_le_liftNu.{u₁} hL_ae) (LiftΩ.{u₂} d K n) μΩ
      (fun i => liftXSamp.{u₁, u₂} i) (fun i => liftYSamp.{u₂} i)
      (measurable_liftXSamp.{u₁, u₂} d K n) (measurable_liftYSamp.{u₂} d K n)
      (iIndepFun_liftSamp.{u₁, u₂} μ) (map_liftSamp_eq_liftNu.{u₁, u₂} μ)
  obtain ⟨hE₀_meas, hE₀_compl, hE₀_mem⟩ := pullEvent_spec.{u₂} μ hE_meas hE_prob
  refine ⟨(eΩ.{u₂} d K n).symm ⁻¹' E, hE₀_meas, hE₀_compl, fun S hS => ?_⟩
  let ω : LiftΩ.{u₂} d K n := (eΩ.{u₂} d K n).symm S
  have hω : ω ∈ E := hE₀_mem S hS
  let sample : Fin n → LiftX.{u₁} d × Fin K :=
    fun i => (liftXSamp.{u₁, u₂} i ω, liftYSamp.{u₂} i ω)
  let W_lift := learnerW sample
  let ρ := learnerRho sample
  obtain ⟨hW_hs, hρ_simp, hρ_lip⟩ := hfeas sample
  let h_S : CandType d K := (pullOp.{u₁} W_lift, ρ)
  have hh_S : IsCand R β h_S := by
    refine ⟨?_, hρ_simp, fun s s' => ?_⟩
    · dsimp [h_S]
      rw [hilbertSchmidtNorm_pullOp.{u₁}]
      exact hW_hs
    · have hd := hρ_lip.dist_le_mul s s'
      rwa [dist_eq_norm, dist_eq_norm, Real.coe_toNNReal β hβ.le] at hd
  refine ⟨h_S, hh_S, fun Φ hΦ => ?_⟩
  have hineq := hE_good ω hω Φ hΦ
  have hfore_eq : (∫ xy, UL.finiteCanonicalLoss Φ (ρ (W_lift xy.1)) xy.2 ∂ν) =
      popForeObj μ Φ h_S := by
    dsimp [ν]
    rw [integral_liftNu.{u₁} μ (fun x y => UL.finiteCanonicalLoss Φ (ρ (W_lift x)) y)]
    rfl
  let g_lift : (LiftX.{u₁} d →L[ℝ] UL.ZeroSumSubspace K) → ℝ :=
    fun V_l => ∫ xy, UL.matchingLoss Φ (V_l xy.1 : EuclideanSpace ℝ (Fin K)) xy.2 ∂ν
  have hg_pull : ∀ V_l : LiftX.{u₁} d →L[ℝ] UL.ZeroSumSubspace K,
      g_lift V_l = popCompObj μ Φ (pullOp.{u₁} V_l) := by
    intro V_l
    dsimp [g_lift, ν, popCompObj]
    exact integral_liftNu.{u₁} μ
      (fun x y => UL.matchingLoss Φ (V_l x : EuclideanSpace ℝ (Fin K)) y)
  have hbdd_lift : BddBelow (g_lift '' {V_l | UL.hilbertSchmidtNorm V_l ≤ R}) := by
    refine ⟨UL.matchingPotential Φ 0 - 3 * (L * R), ?_⟩
    rintro _ ⟨V_l, hV_l, rfl⟩
    rw [hg_pull V_l]
    have hV₀ : UL.hilbertSchmidtNorm (pullOp.{u₁} V_l) ≤ R := by
      rwa [hilbertSchmidtNorm_pullOp.{u₁}]
    have hb := (abs_le.mp (popCompObj_sub_pot0_bounds hK hL hR hL_ae hΦ.1.2.1 hV₀)).1
    linarith
  have hinf_le : sInf (g_lift '' {V_l | UL.hilbertSchmidtNorm V_l ≤ R}) ≤
      ⨅ V : {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K //
          UL.hilbertSchmidtNorm V ≤ R},
        popCompObj μ Φ V.1 := by
    let V₀ : {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K //
        UL.hilbertSchmidtNorm V ≤ R} :=
      ⟨0, by rw [UL.Proof_lem_C_2.hilbertSchmidtNorm_zero]; exact hR.le⟩
    haveI : Nonempty {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K //
        UL.hilbertSchmidtNorm V ≤ R} := ⟨V₀⟩
    refine le_ciInf fun V => ?_
    let V_l := pushOp.{u₁} V.1
    have hV_l_mem : V_l ∈ {W_l | UL.hilbertSchmidtNorm W_l ≤ R} := by
      change UL.hilbertSchmidtNorm (pushOp.{u₁} V.1) ≤ R
      rw [hilbertSchmidtNorm_pushOp.{u₁}]
      exact V.2
    have hval : g_lift V_l = popCompObj μ Φ V.1 := by
      dsimp [g_lift, V_l, ν, popCompObj]
      rw [integral_liftNu.{u₁} μ
        (fun x y => UL.matchingLoss Φ
          ((V.1 (isoX.{u₁} d x) : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) y)]
      congr 1
    rw [← hval]
    exact csInf_le hbdd_lift (Set.mem_image_of_mem g_lift hV_l_mem)
  rw [hfore_eq] at hineq
  change popForeObj μ Φ h_S ≤ sInf (g_lift '' {V_l | UL.hilbertSchmidtNorm V_l ≤ R}) + ε / 4 at hineq
  unfold popExcess
  linarith

/-! ### `ScoreProfileClass` membership and uniform convergence (`exists_uc_event`) -/

private noncomputable def evalProfileLift.{u} {d K : ℕ} (L : ℝ)
    (f : Metric.closedBall (0 : LiftX.{u} d) L × Fin K → ℝ)
    (x : LiftX.{u} d) (y : Fin K) : ℝ :=
  open Classical in
  if hx : x ∈ Metric.closedBall (0 : LiftX.{u} d) L then f (⟨x, hx⟩, y) else 0

private lemma abs_evalProfileLift_le.{u} {d K : ℕ} {L R C M₀ : ℝ}
    {f : Metric.closedBall (0 : LiftX.{u} d) L × Fin K → ℝ}
    (hf : f ∈ UL.ScoreProfileClass (LiftX.{u} d) K L R C M₀)
    (x : LiftX.{u} d) (y : Fin K) :
    |evalProfileLift.{u} L f x y| ≤ M₀ := by
  rcases hf with ⟨_, hL, hR, _, hM₀, W, a, hW_hs, ha_spec, hf_eq⟩
  unfold evalProfileLift
  split_ifs with hx
  · rw [hf_eq ⟨x, hx⟩ y]
    have hWx : W x ∈ Metric.closedBall (0 : UL.ZeroSumSubspace K) (L * R) := by
      rw [Metric.mem_closedBall, dist_zero_right]
      rw [Metric.mem_closedBall, dist_zero_right] at hx
      calc ‖W x‖ ≤ UL.hilbertSchmidtNorm W * ‖x‖ :=
            UL.Proof_lem_C_2.norm_apply_le_hilbertSchmidtNorm W x
        _ ≤ R * L := mul_le_mul hW_hs hx (norm_nonneg _)
            (le_trans (UL.Proof_lem_C_2.hilbertSchmidtNorm_nonneg W) hW_hs)
        _ = L * R := mul_comm R L
    have hmem := (ha_spec y).2 hWx
    exact abs_le.mpr hmem
  · rw [abs_zero]
    exact hM₀.le

private lemma scoreProfile_dev_bddAbove.{u} {d K n : ℕ} (hn1 : 1 ≤ n)
    {L R C M₀ : ℝ} (hM₀ : 0 < M₀)
    (ν : Measure (LiftX.{u} d × Fin K)) [IsProbabilityMeasure ν]
    (x_s : Fin n → LiftX.{u} d) (y_s : Fin n → Fin K) :
    BddAbove ((fun f : Metric.closedBall (0 : LiftX.{u} d) L × Fin K → ℝ =>
      |(∫ xy, evalProfileLift.{u} L f xy.1 xy.2 ∂ν) -
        ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalProfileLift.{u} L f (x_s i) (y_s i)|) ''
      UL.ScoreProfileClass (LiftX.{u} d) K L R C M₀) := by
  have hn_pos : (0 : ℝ) < (n : ℝ) := by exact_mod_cast (by omega : 0 < n)
  refine ⟨2 * M₀, ?_⟩
  rintro _ ⟨f, hf, rfl⟩
  have hint_le : |∫ xy, evalProfileLift.{u} L f xy.1 xy.2 ∂ν| ≤ M₀ := by
    rw [← Real.norm_eq_abs]
    have hle := norm_integral_le_of_norm_le_const (C := M₀) (μ := ν)
      (f := fun xy => evalProfileLift.{u} L f xy.1 xy.2)
      (Eventually.of_forall fun xy => by
        rw [Real.norm_eq_abs]
        exact abs_evalProfileLift_le.{u} hf xy.1 xy.2)
    simpa [measureReal_def] using hle
  have hemp_le : |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalProfileLift.{u} L f (x_s i) (y_s i)| ≤
      M₀ := by
    rw [abs_mul, abs_of_pos (one_div_pos.mpr hn_pos)]
    have hsum : |∑ i : Fin n, evalProfileLift.{u} L f (x_s i) (y_s i)| ≤ (n : ℝ) * M₀ := by
      calc |∑ i : Fin n, _|
          ≤ ∑ i : Fin n, |evalProfileLift.{u} L f (x_s i) (y_s i)| :=
            Finset.abs_sum_le_sum_abs _ _
        _ ≤ ∑ _i : Fin n, M₀ := Finset.sum_le_sum fun i _ => abs_evalProfileLift_le.{u} hf _ _
        _ = (n : ℝ) * M₀ := by simp [Finset.sum_const, nsmul_eq_mul]
    calc (1 / (n : ℝ)) * |∑ i : Fin n, _|
        ≤ (1 / (n : ℝ)) * ((n : ℝ) * M₀) := mul_le_mul_of_nonneg_left hsum (by positivity)
      _ = M₀ := by field_simp [hn_pos.ne']
  calc |(∫ xy, evalProfileLift.{u} L f xy.1 xy.2 ∂ν) -
        ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalProfileLift.{u} L f (x_s i) (y_s i)|
      ≤ |∫ xy, evalProfileLift.{u} L f xy.1 xy.2 ∂ν| +
          |((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalProfileLift.{u} L f (x_s i) (y_s i)| :=
        abs_sub _ _
    _ ≤ M₀ + M₀ := add_le_add hint_le hemp_le
    _ = 2 * M₀ := by ring

private noncomputable def foreProfileLift.{u} {d K : ℕ} (L : ℝ)
    (Φ : UL.Simplex K → ℝ) (h : CandType d K) :
    Metric.closedBall (0 : LiftX.{u} d) L × Fin K → ℝ :=
  fun xy => UL.matchingLoss Φ
    (UL.finiteCanonicalAction Φ (h.2 (pushOp.{u} h.1 xy.1.1))) xy.2 -
    UL.matchingPotential Φ 0

private lemma foreProfileLift_mem.{u} {d K : ℕ} (hK : 2 ≤ K)
    {L R β lam M : ℝ} (hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) (hlam : 0 < lam) (hM : 0 < M)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    {h : CandType d K} (hh : IsCand R β h) :
    foreProfileLift.{u} L Φ h ∈
      UL.ScoreProfileClass (LiftX.{u} d) K L R (3 * β * lam) (3 * M) := by
  refine ⟨hK, hL, hR, by positivity, by positivity, pushOp.{u} h.1,
    fun y s => UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 s)) y - UL.matchingPotential Φ 0,
    ?_, ?_, fun _ _ => rfl⟩
  · rw [hilbertSchmidtNorm_pushOp.{u}]; exact hh.1
  · intro y
    refine ⟨?_, fun s _hs => ?_⟩
    · rw [lipschitzOnWith_iff_dist_le_mul]
      intro s _ s' _
      rw [Real.dist_eq, dist_eq_norm, Real.coe_toNNReal _ (by positivity)]
      rw [sub_sub_sub_cancel_right]
      calc |UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 s)) y -
            UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 s')) y|
          ≤ (3 * lam) * ‖h.2 s - h.2 s'‖ :=
            finiteCanonicalLoss_lipschitz_on_simplex hK hΦ (hh.2.1 s) (hh.2.1 s') y
        _ ≤ (3 * lam) * (β * ‖s - s'‖) :=
            mul_le_mul_of_nonneg_left (hh.2.2 s s') (by positivity)
        _ = (3 * β * lam) * ‖s - s'‖ := by ring
    · exact abs_le.mp (abs_finiteCanonicalLoss_sub_pot0_le hK hΦ (hh.2.1 s) y)

private noncomputable def compProfileLift.{u} {d K : ℕ} (L : ℝ)
    (Φ : UL.Simplex K → ℝ) (V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K) :
    Metric.closedBall (0 : LiftX.{u} d) L × Fin K → ℝ :=
  fun xy => UL.matchingLoss Φ
    ((pushOp.{u} V xy.1.1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) xy.2 -
    UL.matchingPotential Φ 0

private lemma compProfileLift_mem.{u} {d K : ℕ} (hK : 2 ≤ K)
    {L R : ℝ} (hL : 0 < L) (hR : 0 < R)
    {Φ : UL.Simplex K → ℝ} (hΦ_cont : Continuous Φ)
    {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K}
    (hV : UL.hilbertSchmidtNorm V ≤ R) :
    compProfileLift.{u} L Φ V ∈
      UL.ScoreProfileClass (LiftX.{u} d) K L R 3 (3 * (L * R)) := by
  refine ⟨hK, hL, hR, by norm_num, by positivity, pushOp.{u} V,
    fun y s => UL.matchingLoss Φ (s : EuclideanSpace ℝ (Fin K)) y - UL.matchingPotential Φ 0,
    ?_, ?_, fun _ _ => rfl⟩
  · rw [hilbertSchmidtNorm_pushOp.{u}]; exact hV
  · intro y
    refine ⟨?_, fun s hs => ?_⟩
    · rw [lipschitzOnWith_iff_dist_le_mul]
      intro s _ s' _
      rw [Real.dist_eq, dist_eq_norm, Real.coe_toNNReal _ (by norm_num)]
      rw [sub_sub_sub_cancel_right]
      exact matchingLoss_lipschitz hK hΦ_cont (s : EuclideanSpace ℝ (Fin K))
        (s' : EuclideanSpace ℝ (Fin K)) y
    · rw [Metric.mem_closedBall, dist_zero_right] at hs
      refine abs_le.mp ?_
      exact le_trans (abs_matchingLoss_sub_pot0_le hK hΦ_cont (s : EuclideanSpace ℝ (Fin K)) y)
        (mul_le_mul_of_nonneg_left hs (by norm_num))

private lemma single_class_uc_event.{u₃, u₄} {d K n : ℕ} (_hK : 2 ≤ K) (hn1 : 1 ≤ n)
    {C₃ L R C M₀ δ' B_target : ℝ}
    (hL : 0 < L) (hR : 0 < R) (hC : 0 < C) (hM₀ : 0 < M₀)
    (hδ'0 : 0 < δ') (hδ'1 : δ' < 1)
    (hbound_le : (if K - 1 ≤ 2 then
        C₃ * ((M₀ + C * (L * R)) * Real.log (2 * (n : ℝ)) +
          M₀ * Real.sqrt (Real.log (2 / δ'))) / Real.sqrt (n : ℝ)
      else
        C₃ * (M₀ + C * (L * R)) * ((n : ℝ) ^ (-(1 : ℝ) / ((K - 1 : ℕ) : ℝ))) +
          C₃ * M₀ * Real.sqrt (Real.log (2 / δ') / (n : ℝ))) ≤ B_target)
    (hc3_main : ∀ (X : Type u₃) [NormedAddCommGroup X] [InnerProductSpace ℝ X]
        [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
        [MeasurableSpace X] [BorelSpace X]
        (L R C M₀ : ℝ),
        0 < L → 0 < R → 0 < C → 0 < M₀ →
        ∀ (n : ℕ), 1 ≤ n →
        ∀ (δ : ℝ), 0 < δ → δ < 1 →
        ∀ (ν : Measure (X × Fin K)) [IsProbabilityMeasure ν],
        (∀ᵐ xy ∂ν, ‖xy.1‖ ≤ L) →
        ∀ (Ω : Type u₄) [MeasurableSpace Ω] (μΩ : Measure Ω) [IsProbabilityMeasure μΩ]
          (X_samp : Fin n → Ω → X) (Y_samp : Fin n → Ω → Fin K),
          (∀ i : Fin n, Measurable (X_samp i)) →
          (∀ i : Fin n, Measurable (Y_samp i)) →
          ProbabilityTheory.iIndepFun (fun i ω => (X_samp i ω, Y_samp i ω)) μΩ →
          (∀ i : Fin n, Measure.map (fun ω => (X_samp i ω, Y_samp i ω)) μΩ = ν) →
          let m : ℕ := K - 1
          let A₀ : ℝ := L * R
          let D₀ : ℝ := M₀ + C * A₀
          let evalProfile : (Metric.closedBall (0 : X) L × Fin K → ℝ) → X → Fin K → ℝ :=
            open Classical in
            fun f x y => if hx : x ∈ Metric.closedBall (0 : X) L then f (⟨x, hx⟩, y) else 0
          let bound : ℝ :=
            if m ≤ 2 then
              C₃ * (D₀ * Real.log (2 * (n : ℝ)) + M₀ * Real.sqrt (Real.log (2 / δ))) /
                Real.sqrt (n : ℝ)
            else
              C₃ * D₀ * ((n : ℝ) ^ (-(1 : ℝ) / (m : ℝ))) +
                C₃ * M₀ * Real.sqrt (Real.log (2 / δ) / (n : ℝ))
          ∃ E : Set Ω, MeasurableSet E ∧ (μΩ E).toReal ≥ 1 - δ ∧
            ∀ ω ∈ E,
              sSup ((fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
                |(∫ xy, evalProfile f xy.1 xy.2 ∂ν) -
                  ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalProfile f (X_samp i ω) (Y_samp i ω)|) ''
                UL.ScoreProfileClass X K L R C M₀) ≤ bound)
    (μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K)) [IsProbabilityMeasure μ]
    (hL_ae : ∀ᵐ z ∂μ, ‖z.1‖ ≤ L) :
    ∃ E₀ : Set (SampSpace d K n),
      MeasurableSet E₀ ∧
      Measure.pi (fun _ : Fin n => μ) (E₀ᶜ) ≤ ENNReal.ofReal δ' ∧
      ∀ S ∈ E₀, ∀ f ∈ UL.ScoreProfileClass (LiftX.{u₃} d) K L R C M₀,
        |(∫ z, evalProfileLift.{u₃} L f ((isoX.{u₃} d).symm z.1) z.2 ∂μ) -
          ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
            evalProfileLift.{u₃} L f ((isoX.{u₃} d).symm (S i).1) (S i).2| ≤ B_target := by
  let ν : Measure (LiftX.{u₃} d × Fin K) := liftNu.{u₃} μ
  haveI : IsProbabilityMeasure ν := isProbabilityMeasure_liftNu.{u₃} μ
  let μΩ : Measure (LiftΩ.{u₄} d K n) := liftMuPi.{u₄} (n := n) μ
  haveI : IsProbabilityMeasure μΩ := isProbabilityMeasure_liftMuPi.{u₄} (n := n) μ
  obtain ⟨E, hE_meas, hE_prob, hE_sup⟩ :=
    hc3_main (LiftX.{u₃} d) L R C M₀ hL hR hC hM₀ n hn1 δ' hδ'0 hδ'1 ν
      (ae_norm_le_liftNu.{u₃} hL_ae) (LiftΩ.{u₄} d K n) μΩ
      (fun i => liftXSamp.{u₃, u₄} i) (fun i => liftYSamp.{u₄} i)
      (measurable_liftXSamp.{u₃, u₄} d K n) (measurable_liftYSamp.{u₄} d K n)
      (iIndepFun_liftSamp.{u₃, u₄} μ) (map_liftSamp_eq_liftNu.{u₃, u₄} μ)
  obtain ⟨hE₀_meas, hE₀_compl, hE₀_mem⟩ := pullEvent_spec.{u₄} μ hE_meas hE_prob
  refine ⟨(eΩ.{u₄} d K n).symm ⁻¹' E, hE₀_meas, hE₀_compl, fun S hS f hf => ?_⟩
  let ω : LiftΩ.{u₄} d K n := (eΩ.{u₄} d K n).symm S
  have hω : ω ∈ E := hE₀_mem S hS
  have hsup := hE_sup ω hω
  have hbdd := scoreProfile_dev_bddAbove.{u₃} (L := L) (R := R) (C := C) hn1 hM₀ ν
    (fun i => liftXSamp.{u₃, u₄} i ω) (fun i => liftYSamp.{u₄} i ω)
  have hmem_img : |(∫ xy, evalProfileLift.{u₃} L f xy.1 xy.2 ∂ν) -
      ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
        evalProfileLift.{u₃} L f (liftXSamp.{u₃, u₄} i ω) (liftYSamp.{u₄} i ω)| ∈
      ((fun g : Metric.closedBall (0 : LiftX.{u₃} d) L × Fin K → ℝ =>
        |(∫ xy, evalProfileLift.{u₃} L g xy.1 xy.2 ∂ν) -
          ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
            evalProfileLift.{u₃} L g (liftXSamp.{u₃, u₄} i ω) (liftYSamp.{u₄} i ω)|) ''
        UL.ScoreProfileClass (LiftX.{u₃} d) K L R C M₀) :=
    Set.mem_image_of_mem _ hf
  have hle1 : |(∫ xy, evalProfileLift.{u₃} L f xy.1 xy.2 ∂ν) -
      ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
        evalProfileLift.{u₃} L f (liftXSamp.{u₃, u₄} i ω) (liftYSamp.{u₄} i ω)| ≤ B_target :=
    le_trans (le_csSup hbdd hmem_img) (le_trans hsup hbound_le)
  have hint_eq : (∫ xy, evalProfileLift.{u₃} L f xy.1 xy.2 ∂ν) =
      ∫ z, evalProfileLift.{u₃} L f ((isoX.{u₃} d).symm z.1) z.2 ∂μ :=
    integral_liftNu.{u₃} μ (evalProfileLift.{u₃} L f)
  have hω_eq : ∀ i : Fin n,
      evalProfileLift.{u₃} L f (liftXSamp.{u₃, u₄} i ω) (liftYSamp.{u₄} i ω) =
        evalProfileLift.{u₃} L f ((isoX.{u₃} d).symm (S i).1) (S i).2 := fun _ => rfl
  simpa only [hint_eq, hω_eq] using hle1

private lemma norm_event_compl_zero {d K n : ℕ} {L : ℝ}
    (μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K)) [IsProbabilityMeasure μ]
    (hL_ae : ∀ᵐ z ∂μ, ‖z.1‖ ≤ L) :
    MeasurableSet {S : SampSpace d K n | ∀ i : Fin n, ‖(S i).1‖ ≤ L} ∧
    Measure.pi (fun _ : Fin n => μ) ({S : SampSpace d K n | ∀ i : Fin n, ‖(S i).1‖ ≤ L}ᶜ) = 0 := by
  let E_norm : Set (SampSpace d K n) := {S | ∀ i : Fin n, ‖(S i).1‖ ≤ L}
  have hE_eq : E_norm = ⋂ i : Fin n, {S : SampSpace d K n | ‖(S i).1‖ ≤ L} := by
    ext S; simp [E_norm]
  have hmeas : MeasurableSet E_norm := by
    rw [hE_eq]
    exact MeasurableSet.iInter fun i =>
      (isClosed_le (continuous_norm.comp (continuous_fst.comp (continuous_apply i)))
        continuous_const).measurableSet
  have hcompl_eq : E_normᶜ = ⋃ i : Fin n, {S : SampSpace d K n | ¬ ‖(S i).1‖ ≤ L} := by
    ext S; simp [E_norm]
  have hi_zero : ∀ i : Fin n,
      Measure.pi (fun _ : Fin n => μ) {S : SampSpace d K n | ¬ ‖(S i).1‖ ≤ L} = 0 := by
    intro i
    have hset : {S : SampSpace d K n | ¬ ‖(S i).1‖ ≤ L} =
        Function.eval i ⁻¹' {z : EuclideanSpace ℝ (Fin d) × Fin K | ¬ ‖z.1‖ ≤ L} := rfl
    have hz_meas : MeasurableSet {z : EuclideanSpace ℝ (Fin d) × Fin K | ¬ ‖z.1‖ ≤ L} :=
      (isClosed_le (continuous_norm.comp continuous_fst) continuous_const).measurableSet.compl
    rw [hset, ← Measure.map_apply (measurable_pi_apply i) hz_meas,
      (measurePreserving_eval (fun _ : Fin n => μ) i).map_eq]
    exact ae_iff.mp hL_ae
  refine ⟨hmeas, ?_⟩
  rw [hcompl_eq]
  exact measure_iUnion_null hi_zero

private lemma fore_dev_on_norm.{u₃} {d K n : ℕ} (hK : 2 ≤ K) (hn1 : 1 ≤ n)
    {L R β lam M B : ℝ} (_hL : 0 < L) (_hR : 0 < R) (hβ : 0 < β)
    {μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K)} [IsProbabilityMeasure μ]
    (hL_ae : ∀ᵐ z ∂μ, ‖z.1‖ ≤ L)
    {S : SampSpace d K n} (hSn : ∀ i : Fin n, ‖(S i).1‖ ≤ L)
    {Φ : UL.Simplex K → ℝ} (hΦ : Φ ∈ UL.SmoothEntropyFamily K β lam M)
    {h : CandType d K} (hh : IsCand R β h)
    (hdev : |(∫ z, evalProfileLift.{u₃} L (foreProfileLift.{u₃} L Φ h)
        ((isoX.{u₃} d).symm z.1) z.2 ∂μ) -
      ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
        evalProfileLift.{u₃} L (foreProfileLift.{u₃} L Φ h)
          ((isoX.{u₃} d).symm (S i).1) (S i).2| ≤ B) :
    |(((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
        UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 (h.1 (S i).1))) (S i).2) -
      popForeObj μ Φ h| ≤ B := by
  have hn_pos : (0 : ℝ) < (n : ℝ) := by exact_mod_cast (by omega : 0 < n)
  set c₀ := UL.matchingPotential Φ 0
  have hc₀_sum : ((1 : ℝ) / (n : ℝ)) * ∑ _i : Fin n, c₀ = c₀ := by
    simp [Finset.sum_const, nsmul_eq_mul, hn_pos.ne']
  have hint_eq : (∫ z, evalProfileLift.{u₃} L (foreProfileLift.{u₃} L Φ h)
      ((isoX.{u₃} d).symm z.1) z.2 ∂μ) = popForeObj μ Φ h - c₀ := by
    have hae : (fun z : EuclideanSpace ℝ (Fin d) × Fin K =>
        evalProfileLift.{u₃} L (foreProfileLift.{u₃} L Φ h) ((isoX.{u₃} d).symm z.1) z.2) =ᵐ[μ]
        (fun z => UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 (h.1 z.1))) z.2 - c₀) := by
      filter_upwards [hL_ae] with z hz
      have hball : (isoX.{u₃} d).symm z.1 ∈ Metric.closedBall (0 : LiftX.{u₃} d) L := by
        rw [Metric.mem_closedBall, dist_zero_right, (isoX.{u₃} d).symm.norm_map]
        exact hz
      dsimp [evalProfileLift]
      rw [dif_pos hball]
      dsimp [foreProfileLift, pushOp, c₀]
      rw [(isoX.{u₃} d).apply_symm_apply]
    rw [integral_congr_ae hae,
      integral_sub (integrable_popFore (μ := μ) hK hβ hΦ hh) (integrable_const _),
      integral_const, measureReal_def, measure_univ, ENNReal.toReal_one, one_smul]
    rfl
  have hemp_eq : ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
      evalProfileLift.{u₃} L (foreProfileLift.{u₃} L Φ h) ((isoX.{u₃} d).symm (S i).1) (S i).2 =
      (((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
        UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 (h.1 (S i).1))) (S i).2) - c₀ := by
    have hterm : ∀ i : Fin n,
        evalProfileLift.{u₃} L (foreProfileLift.{u₃} L Φ h) ((isoX.{u₃} d).symm (S i).1) (S i).2 =
          UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 (h.1 (S i).1))) (S i).2 - c₀ := by
      intro i
      have hball : (isoX.{u₃} d).symm (S i).1 ∈ Metric.closedBall (0 : LiftX.{u₃} d) L := by
        rw [Metric.mem_closedBall, dist_zero_right, (isoX.{u₃} d).symm.norm_map]
        exact hSn i
      dsimp [evalProfileLift]
      rw [dif_pos hball]
      dsimp [foreProfileLift, pushOp, c₀]
      rw [(isoX.{u₃} d).apply_symm_apply]
    simp_rw [hterm, Finset.sum_sub_distrib, mul_sub, hc₀_sum]
  rw [hint_eq, hemp_eq, sub_sub_sub_cancel_right, abs_sub_comm] at hdev
  exact hdev

private lemma comp_dev_on_norm.{u₃} {d K n : ℕ} (hK : 2 ≤ K) (hn1 : 1 ≤ n)
    {L R B : ℝ} (hL : 0 < L) (hR : 0 < R)
    {μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K)} [IsProbabilityMeasure μ]
    (hL_ae : ∀ᵐ z ∂μ, ‖z.1‖ ≤ L)
    {S : SampSpace d K n} (hSn : ∀ i : Fin n, ‖(S i).1‖ ≤ L)
    {Φ : UL.Simplex K → ℝ} (hΦ_cont : Continuous Φ)
    {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K} (hV : UL.hilbertSchmidtNorm V ≤ R)
    (hdev : |(∫ z, evalProfileLift.{u₃} L (compProfileLift.{u₃} L Φ V)
        ((isoX.{u₃} d).symm z.1) z.2 ∂μ) -
      ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
        evalProfileLift.{u₃} L (compProfileLift.{u₃} L Φ V)
          ((isoX.{u₃} d).symm (S i).1) (S i).2| ≤ B) :
    |empCompObjClamped L Φ V S - popCompObj μ Φ V| ≤ B := by
  have hn_pos : (0 : ℝ) < (n : ℝ) := by exact_mod_cast (by omega : 0 < n)
  set c₀ := UL.matchingPotential Φ 0
  have hc₀_sum : ((1 : ℝ) / (n : ℝ)) * ∑ _i : Fin n, c₀ = c₀ := by
    simp [Finset.sum_const, nsmul_eq_mul, hn_pos.ne']
  have hint_eq : (∫ z, evalProfileLift.{u₃} L (compProfileLift.{u₃} L Φ V)
      ((isoX.{u₃} d).symm z.1) z.2 ∂μ) = popCompObj μ Φ V - c₀ := by
    have hae : (fun z : EuclideanSpace ℝ (Fin d) × Fin K =>
        evalProfileLift.{u₃} L (compProfileLift.{u₃} L Φ V) ((isoX.{u₃} d).symm z.1) z.2) =ᵐ[μ]
        (fun z => UL.matchingLoss Φ
          ((V z.1 : UL.ZeroSumSubspace K) : EuclideanSpace ℝ (Fin K)) z.2 - c₀) := by
      filter_upwards [hL_ae] with z hz
      have hball : (isoX.{u₃} d).symm z.1 ∈ Metric.closedBall (0 : LiftX.{u₃} d) L := by
        rw [Metric.mem_closedBall, dist_zero_right, (isoX.{u₃} d).symm.norm_map]
        exact hz
      dsimp [evalProfileLift]
      rw [dif_pos hball]
      dsimp [compProfileLift, pushOp, c₀]
      rw [(isoX.{u₃} d).apply_symm_apply]
    rw [integral_congr_ae hae,
      integral_sub (integrable_popComp hK hL hR hL_ae hΦ_cont hV) (integrable_const _),
      integral_const, measureReal_def, measure_univ, ENNReal.toReal_one, one_smul]
    rfl
  have hemp_eq : ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
      evalProfileLift.{u₃} L (compProfileLift.{u₃} L Φ V) ((isoX.{u₃} d).symm (S i).1) (S i).2 =
      empCompObjClamped L Φ V S - c₀ := by
    have hterm : ∀ i : Fin n,
        evalProfileLift.{u₃} L (compProfileLift.{u₃} L Φ V) ((isoX.{u₃} d).symm (S i).1) (S i).2 =
          UL.matchingLoss Φ ((V (clampBall L (S i).1) : UL.ZeroSumSubspace K) :
            EuclideanSpace ℝ (Fin K)) (S i).2 - c₀ := by
      intro i
      have hball : (isoX.{u₃} d).symm (S i).1 ∈ Metric.closedBall (0 : LiftX.{u₃} d) L := by
        rw [Metric.mem_closedBall, dist_zero_right, (isoX.{u₃} d).symm.norm_map]
        exact hSn i
      rw [clampBall_eq_self hL (hSn i)]
      dsimp [evalProfileLift]
      rw [dif_pos hball]
      dsimp [compProfileLift, pushOp, c₀]
      rw [(isoX.{u₃} d).apply_symm_apply]
    unfold empCompObjClamped
    simp_rw [hterm, Finset.sum_sub_distrib, mul_sub, hc₀_sum]
  rw [hint_eq, hemp_eq, sub_sub_sub_cancel_right, abs_sub_comm] at hdev
  exact hdev

private lemma emp_pop_excess_diff_le {d K n : ℕ} (hK : 2 ≤ K) (hn1 : 1 ≤ n)
    {L R ε : ℝ} (hL : 0 < L) (hR : 0 < R)
    {μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K)} [IsProbabilityMeasure μ]
    (hL_ae : ∀ᵐ z ∂μ, ‖z.1‖ ≤ L)
    {S : SampSpace d K n} (hSn : ∀ i : Fin n, ‖(S i).1‖ ≤ L)
    {Φ : UL.Simplex K → ℝ} (hΦ_cont : Continuous Φ)
    (h : CandType d K)
    (hfore_dev : |(((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
        UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 (h.1 (S i).1))) (S i).2) -
      popForeObj μ Φ h| ≤ ε / 16)
    (hcomp_pt : ∀ V : {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K //
        UL.hilbertSchmidtNorm V ≤ R},
      |empCompObjClamped L Φ V.1 S - popCompObj μ Φ V.1| ≤ ε / 16) :
    |empExcessClamped L R Φ h S - popExcess μ R Φ h| ≤ ε / 8 := by
  set c₀ := UL.matchingPotential Φ 0
  let V₀ : {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K //
      UL.hilbertSchmidtNorm V ≤ R} :=
    ⟨0, by rw [UL.Proof_lem_C_2.hilbertSchmidtNorm_zero]; exact hR.le⟩
  haveI : Nonempty {V : EuclideanSpace ℝ (Fin d) →L[ℝ] UL.ZeroSumSubspace K //
      UL.hilbertSchmidtNorm V ≤ R} := ⟨V₀⟩
  have hbdd_emp : BddBelow (Set.range (fun V : {V // UL.hilbertSchmidtNorm V ≤ R} =>
      empCompObjClamped L Φ V.1 S)) := by
    refine ⟨c₀ - 3 * (L * R), Set.forall_mem_range.mpr fun V => ?_⟩
    have hb := (abs_le.mp (empCompObjClamped_bounds hK hn1 hL hR hΦ_cont V.2 S)).1
    linarith
  have hbdd_pop : BddBelow (Set.range (fun V : {V // UL.hilbertSchmidtNorm V ≤ R} =>
      popCompObj μ Φ V.1)) := by
    refine ⟨c₀ - 3 * (L * R), Set.forall_mem_range.mpr fun V => ?_⟩
    have hb := (abs_le.mp (popCompObj_sub_pot0_bounds hK hL hR hL_ae hΦ_cont V.2)).1
    linarith
  have hinf_le1 : (⨅ V : {V // UL.hilbertSchmidtNorm V ≤ R}, empCompObjClamped L Φ V.1 S) ≤
      (⨅ V : {V // UL.hilbertSchmidtNorm V ≤ R}, popCompObj μ Φ V.1) + ε / 16 := by
    rw [← sub_le_iff_le_add]
    refine le_ciInf fun V => ?_
    rw [sub_le_iff_le_add]
    exact le_trans (ciInf_le hbdd_emp V) (by linarith [(abs_le.mp (hcomp_pt V)).2])
  have hinf_le2 : (⨅ V : {V // UL.hilbertSchmidtNorm V ≤ R}, popCompObj μ Φ V.1) ≤
      (⨅ V : {V // UL.hilbertSchmidtNorm V ≤ R}, empCompObjClamped L Φ V.1 S) + ε / 16 := by
    rw [← sub_le_iff_le_add]
    refine le_ciInf fun V => ?_
    rw [sub_le_iff_le_add]
    exact le_trans (ciInf_le hbdd_pop V) (by linarith [(abs_le.mp (hcomp_pt V)).1])
  have hfore_clamp : ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
      UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 (h.1 (clampBall L (S i).1)))) (S i).2 =
      ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n,
        UL.matchingLoss Φ (UL.finiteCanonicalAction Φ (h.2 (h.1 (S i).1))) (S i).2 := by
    have hcl : ∀ i : Fin n, clampBall L (S i).1 = (S i).1 := fun i => clampBall_eq_self hL (hSn i)
    simp_rw [hcl]
  obtain ⟨hf_lo, hf_hi⟩ := abs_le.mp hfore_dev
  unfold empExcessClamped popExcess
  rw [hfore_clamp, abs_le]
  constructor <;> linarith

/-- Combined uniform-convergence event `E_uc` ensuring empirical and population excess risks
agree within `ε / 8` simultaneously over `IsCand R β` and `SmoothEntropyFamily K β lam M`. -/
lemma exists_uc_event.{u₃, u₄} {d K n : ℕ} (hK : 2 ≤ K) (hn1 : 1 ≤ n)
    {C₁ C₃ L R β lam M ε δ : ℝ}
    (hC₃ : 0 < C₃) (hL : 0 < L) (hR : 0 < R) (hβ : 0 < β) (hlam : 0 < lam) (hM : 0 < M)
    (hε_pos : 0 < ε) (hε_le : ε ≤ M + (L * R) + β * lam * (L * R))
    (hδ_pos : 0 < δ) (hδ_lt : δ < (1 : ℝ) / 2)
    (hn_bound : (if K - 1 ≤ 2 then
        chooseCK K C₁ C₃ * ((M + (L * R) + β * lam * (L * R)) / ε) ^ 2 *
          (Real.log (chooseCK K C₁ C₃ * (M + (L * R) + β * lam * (L * R)) / (ε * δ))) ^ 2 ≤
          (n : ℝ)
      else
        chooseCK K C₁ C₃ *
          (((M + (L * R) + β * lam * (L * R)) / ε) ^ (K - 1) +
            ((M + (L * R) + β * lam * (L * R)) / ε) ^ 2 * Real.log (2 / δ)) ≤ (n : ℝ)))
    (hc3_main : ∀ (X : Type u₃) [NormedAddCommGroup X] [InnerProductSpace ℝ X]
        [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
        [MeasurableSpace X] [BorelSpace X]
        (L R C M₀ : ℝ),
        0 < L → 0 < R → 0 < C → 0 < M₀ →
        ∀ (n : ℕ), 1 ≤ n →
        ∀ (δ : ℝ), 0 < δ → δ < 1 →
        ∀ (ν : Measure (X × Fin K)) [IsProbabilityMeasure ν],
        (∀ᵐ xy ∂ν, ‖xy.1‖ ≤ L) →
        ∀ (Ω : Type u₄) [MeasurableSpace Ω] (μΩ : Measure Ω) [IsProbabilityMeasure μΩ]
          (X_samp : Fin n → Ω → X) (Y_samp : Fin n → Ω → Fin K),
          (∀ i : Fin n, Measurable (X_samp i)) →
          (∀ i : Fin n, Measurable (Y_samp i)) →
          ProbabilityTheory.iIndepFun (fun i ω => (X_samp i ω, Y_samp i ω)) μΩ →
          (∀ i : Fin n, Measure.map (fun ω => (X_samp i ω, Y_samp i ω)) μΩ = ν) →
          let m : ℕ := K - 1
          let A₀ : ℝ := L * R
          let D₀ : ℝ := M₀ + C * A₀
          let evalProfile : (Metric.closedBall (0 : X) L × Fin K → ℝ) → X → Fin K → ℝ :=
            open Classical in
            fun f x y => if hx : x ∈ Metric.closedBall (0 : X) L then f (⟨x, hx⟩, y) else 0
          let bound : ℝ :=
            if m ≤ 2 then
              C₃ * (D₀ * Real.log (2 * (n : ℝ)) + M₀ * Real.sqrt (Real.log (2 / δ))) /
                Real.sqrt (n : ℝ)
            else
              C₃ * D₀ * ((n : ℝ) ^ (-(1 : ℝ) / (m : ℝ))) +
                C₃ * M₀ * Real.sqrt (Real.log (2 / δ) / (n : ℝ))
          ∃ E : Set Ω, MeasurableSet E ∧ (μΩ E).toReal ≥ 1 - δ ∧
            ∀ ω ∈ E,
              sSup ((fun f : Metric.closedBall (0 : X) L × Fin K → ℝ =>
                |(∫ xy, evalProfile f xy.1 xy.2 ∂ν) -
                  ((1 : ℝ) / (n : ℝ)) * ∑ i : Fin n, evalProfile f (X_samp i ω) (Y_samp i ω)|) ''
                UL.ScoreProfileClass X K L R C M₀) ≤ bound)
    (μ : Measure (EuclideanSpace ℝ (Fin d) × Fin K)) [IsProbabilityMeasure μ]
    (hL_ae : ∀ᵐ z ∂μ, ‖z.1‖ ≤ L) :
    ∃ E_uc : Set (SampSpace d K n),
      MeasurableSet E_uc ∧
      Measure.pi (fun _ : Fin n => μ) (E_ucᶜ) ≤ ENNReal.ofReal (δ / 2) ∧
      ∀ S ∈ E_uc, ∀ h : CandType d K, IsCand R β h →
        ∀ Φ ∈ UL.SmoothEntropyFamily K β lam M,
          |empExcessClamped L R Φ h S - popExcess μ R Φ h| ≤ ε / 8 := by
  have hA_pos : 0 < L * R := mul_pos hL hR
  have hblA_pos : 0 < β * lam * (L * R) := by positivity
  have hb₁ := lem_C_3_bound_le hK hC₃ (M₀ := 3 * M) (D₀ := 3 * M + (3 * β * lam) * (L * R))
    (by positivity) (by linarith) (by positivity) (by linarith)
    hε_pos hε_le hδ_pos hδ_lt hn_bound
  obtain ⟨E₁, hE₁_meas, hE₁_compl, hE₁_dev⟩ :=
    single_class_uc_event.{u₃, u₄} hK hn1 hL hR (C := 3 * β * lam) (M₀ := 3 * M)
      (by positivity) (by positivity) (by positivity) (by linarith) hb₁ hc3_main μ hL_ae
  have hb₂ := lem_C_3_bound_le hK hC₃ (M₀ := 3 * (L * R)) (D₀ := 3 * (L * R) + 3 * (L * R))
    (by positivity) (by linarith) (by positivity) (by linarith)
    hε_pos hε_le hδ_pos hδ_lt hn_bound
  obtain ⟨E₂, hE₂_meas, hE₂_compl, hE₂_dev⟩ :=
    single_class_uc_event.{u₃, u₄} hK hn1 hL hR (C := 3) (M₀ := 3 * (L * R))
      (by norm_num) (by positivity) (by positivity) (by linarith) hb₂ hc3_main μ hL_ae
  obtain ⟨hEn_meas, hEn_compl⟩ := norm_event_compl_zero μ hL_ae
  let E_norm : Set (SampSpace d K n) := {S | ∀ i : Fin n, ‖(S i).1‖ ≤ L}
  let E_uc : Set (SampSpace d K n) := E_norm ∩ (E₁ ∩ E₂)
  have hEuc_meas : MeasurableSet E_uc := hEn_meas.inter (hE₁_meas.inter hE₂_meas)
  have hEuc_compl : Measure.pi (fun _ : Fin n => μ) (E_ucᶜ) ≤ ENNReal.ofReal (δ / 2) := by
    have hsub : E_ucᶜ ⊆ E_normᶜ ∪ (E₁ᶜ ∪ E₂ᶜ) := by
      intro S hS
      simp only [E_uc, Set.mem_compl_iff, Set.mem_inter_iff, Set.mem_union] at hS ⊢
      tauto
    calc Measure.pi (fun _ : Fin n => μ) (E_ucᶜ)
        ≤ Measure.pi (fun _ : Fin n => μ) (E_normᶜ ∪ (E₁ᶜ ∪ E₂ᶜ)) := measure_mono hsub
      _ ≤ Measure.pi (fun _ : Fin n => μ) (E_normᶜ) +
            Measure.pi (fun _ : Fin n => μ) (E₁ᶜ ∪ E₂ᶜ) := measure_union_le _ _
      _ ≤ Measure.pi (fun _ : Fin n => μ) (E_normᶜ) +
            (Measure.pi (fun _ : Fin n => μ) (E₁ᶜ) +
              Measure.pi (fun _ : Fin n => μ) (E₂ᶜ)) :=
          add_le_add le_rfl (measure_union_le _ _)
      _ ≤ 0 + (ENNReal.ofReal (δ / 4) + ENNReal.ofReal (δ / 4)) :=
          add_le_add (le_of_eq hEn_compl) (add_le_add hE₁_compl hE₂_compl)
      _ = ENNReal.ofReal (δ / 2) := by
          rw [zero_add, ← ENNReal.ofReal_add (by positivity) (by positivity)]
          congr 1; ring
  refine ⟨E_uc, hEuc_meas, hEuc_compl, fun S ⟨hSn, hS₁, hS₂⟩ h hh Φ hΦ => ?_⟩
  refine emp_pop_excess_diff_le hK hn1 hL hR hL_ae hSn hΦ.1.2.1 h ?_ (fun V => ?_)
  · exact fore_dev_on_norm.{u₃} hK hn1 hL hR hβ hL_ae hSn hΦ hh
      (hE₁_dev S hS₁ _ (foreProfileLift_mem.{u₃} hK hL hR hβ hlam hM hΦ hh))
  · exact comp_dev_on_norm.{u₃} hK hn1 hL hR hL_ae hSn hΦ.1.2.1 V.2
      (hE₂_dev S hS₂ _ (compProfileLift_mem.{u₃} hK hL hR hΦ.1.2.1 V.2))

end UL.Proof_thm_5_1

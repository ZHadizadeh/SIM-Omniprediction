import Mathlib
import UL.Def.def_2_1
import UL.Def.def_A_fit
import UL.Proof.lem_A_2.H1_SimplexLipschitz
import UL.Proof.lem_A_2.H2_ExistenceUniqueness
set_option autoImplicit false

open scoped ENNReal

namespace UL.Proof_lem_A_2

lemma exists_subseq_ae_tendsto_linearFittedPrediction {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ] {d K : ℕ}
    {B : ℝ} (hB : 0 < B)
    {X : Ω → EuclideanSpace ℝ (Fin d)} (hX : Measurable X)
    {Y : Ω → Fin K} (hY : Measurable Y)
    {W_seq : ℕ → EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K}
    {W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K}
    (hW : Filter.Tendsto W_seq Filter.atTop (nhds W)) :
    ∃ φ : ℕ → ℕ, StrictMono φ ∧
      ∀ᵐ ω ∂μ, Filter.Tendsto
        (fun k => linearFittedPrediction μ B (W_seq (φ k)) X Y ω)
        Filter.atTop (nhds (linearFittedPrediction μ B W X Y ω)) := by
  have hfit_n : ∀ n : ℕ,
      ∃ ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K),
        IsLipschitzLSFitProfile μ B (linearScore (W_seq n) X) Y ρ ∧
          linearFittedPrediction μ B (W_seq n) X Y = fun ω => ρ (linearScore (W_seq n) X ω) :=
    fun n => linearFittedPrediction_isLinearLipschitzLSFit μ hB (W_seq n) hX hY
  let ρ_seq : ℕ → ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) :=
    fun n => Classical.choose (hfit_n n)
  have hρ_seq_prof : ∀ n : ℕ,
      IsLipschitzLSFitProfile μ B (linearScore (W_seq n) X) Y (ρ_seq n) :=
    fun n => (Classical.choose_spec (hfit_n n)).1
  have hρ_seq_eq : ∀ n : ℕ,
      linearFittedPrediction μ B (W_seq n) X Y = fun ω => ρ_seq n (linearScore (W_seq n) X ω) :=
    fun n => (Classical.choose_spec (hfit_n n)).2
  have hρ_seq_mem : ∀ n : ℕ, ρ_seq n ∈ LipschitzSimplexMaps K B :=
    fun n => (hρ_seq_prof n).2.1
  obtain ⟨ρ, φ, hρ_mem, hφ_mono, hρ_pt⟩ := exists_subseq_tendsto_pointwise hρ_seq_mem
  have hW_sub : Filter.Tendsto (fun k => W_seq (φ k)) Filter.atTop (nhds W) :=
    hW.comp hφ_mono.tendsto_atTop
  have h_score_pt : ∀ ω : Ω,
      Filter.Tendsto (fun k => linearScore (W_seq (φ k)) X ω)
        Filter.atTop (nhds (linearScore W X ω)) := by
    intro ω
    exact (ContinuousLinearMap.apply ℝ (ZeroSumSubspace K) (X ω)).continuous.continuousAt.tendsto.comp
      hW_sub
  have h_pred_pt : ∀ ω : Ω,
      Filter.Tendsto (fun k => ρ_seq (φ k) (linearScore (W_seq (φ k)) X ω))
        Filter.atTop (nhds (ρ (linearScore W X ω))) := by
    intro ω
    rw [tendsto_iff_dist_tendsto_zero]
    have hd1 : Filter.Tendsto
        (fun k => dist (linearScore (W_seq (φ k)) X ω) (linearScore W X ω))
        Filter.atTop (nhds 0) :=
      tendsto_iff_dist_tendsto_zero.mp (h_score_pt ω)
    have hd2 : Filter.Tendsto
        (fun k => dist (ρ_seq (φ k) (linearScore W X ω)) (ρ (linearScore W X ω)))
        Filter.atTop (nhds 0) :=
      tendsto_iff_dist_tendsto_zero.mp (hρ_pt (linearScore W X ω))
    have h_upper : Filter.Tendsto
        (fun k => B * dist (linearScore (W_seq (φ k)) X ω) (linearScore W X ω) +
          dist (ρ_seq (φ k) (linearScore W X ω)) (ρ (linearScore W X ω)))
        Filter.atTop (nhds 0) := by
      simpa using (hd1.const_mul B).add hd2
    refine tendsto_of_tendsto_of_tendsto_of_le_of_le tendsto_const_nhds h_upper
      (fun _ => dist_nonneg) (fun k => ?_)
    have htri := dist_triangle
      (ρ_seq (φ k) (linearScore (W_seq (φ k)) X ω))
      (ρ_seq (φ k) (linearScore W X ω))
      (ρ (linearScore W X ω))
    have hlip : dist (ρ_seq (φ k) (linearScore (W_seq (φ k)) X ω))
        (ρ_seq (φ k) (linearScore W X ω)) ≤
        B * dist (linearScore (W_seq (φ k)) X ω) (linearScore W X ω) := by
      have h := lipschitzWith_iff_dist_le_mul.mp (hρ_seq_mem (φ k)).2.1
        (linearScore (W_seq (φ k)) X ω) (linearScore W X ω)
      rw [Real.coe_toNNReal B (le_of_lt hB)] at h
      exact h
    linarith
  have h_risk_sub : Filter.Tendsto
      (fun k => lsFitRisk μ (linearScore (W_seq (φ k)) X) Y (ρ_seq (φ k)))
      Filter.atTop (nhds (lsFitRisk μ (linearScore W X) Y ρ)) :=
    tendsto_lsFitRisk μ (fun k => linearScore_measurable (W_seq (φ k)) hX)
      (linearScore_measurable W hX) hY (fun k => hρ_seq_mem (φ k)) hρ_mem h_pred_pt
  have hρ_min : IsMinOn (lsFitRisk μ (linearScore W X) Y) (LipschitzSimplexMaps K B) ρ := by
    rw [isMinOn_iff]
    intro ρ' hρ'
    have h_comp_pt : ∀ ω : Ω,
        Filter.Tendsto (fun k => ρ' (linearScore (W_seq (φ k)) X ω))
          Filter.atTop (nhds (ρ' (linearScore W X ω))) :=
      fun ω => hρ'.2.1.continuous.continuousAt.tendsto.comp (h_score_pt ω)
    have h_risk_comp : Filter.Tendsto
        (fun k => lsFitRisk μ (linearScore (W_seq (φ k)) X) Y ρ')
        Filter.atTop (nhds (lsFitRisk μ (linearScore W X) Y ρ')) :=
      tendsto_lsFitRisk μ (fun k => linearScore_measurable (W_seq (φ k)) hX)
        (linearScore_measurable W hX) hY (fun _ => hρ') hρ' h_comp_pt
    exact le_of_tendsto_of_tendsto h_risk_sub h_risk_comp
      (Filter.Eventually.of_forall fun k =>
        isMinOn_iff.mp (hρ_seq_prof (φ k)).2.2 ρ' hρ')
  have hQ_fit : IsLinearLipschitzLSFit μ B W X Y (fun ω => ρ (linearScore W X ω)) :=
    ⟨ρ, ⟨hB, hρ_mem, hρ_min⟩, rfl⟩
  have hPW_fit : IsLinearLipschitzLSFit μ B W X Y (linearFittedPrediction μ B W X Y) :=
    linearFittedPrediction_isLinearLipschitzLSFit μ hB W hX hY
  have h_ae_eq : (fun ω => ρ (linearScore W X ω)) =ᵐ[μ] linearFittedPrediction μ B W X Y :=
    isLipschitzLSFit_ae_eq μ (linearScore_measurable W hX) hY hQ_fit hPW_fit
  refine ⟨φ, hφ_mono, ?_⟩
  filter_upwards [h_ae_eq] with ω hω
  have h_eq_fn : (fun k => linearFittedPrediction μ B (W_seq (φ k)) X Y ω) =
      (fun k => ρ_seq (φ k) (linearScore (W_seq (φ k)) X ω)) := by
    ext k
    rw [hρ_seq_eq (φ k)]
  rw [h_eq_fn, ← hω]
  exact h_pred_pt ω

lemma tendsto_eLpNorm_linearFittedPrediction {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ] {d K : ℕ}
    {B : ℝ} (hB : 0 < B)
    {X : Ω → EuclideanSpace ℝ (Fin d)} (hX : Measurable X)
    {Y : Ω → Fin K} (hY : Measurable Y)
    {W_seq : ℕ → EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K}
    {W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K}
    (hW : Filter.Tendsto W_seq Filter.atTop (nhds W)) :
    Filter.Tendsto
      (fun n => MeasureTheory.eLpNorm
        (linearFittedPrediction μ B (W_seq n) X Y - linearFittedPrediction μ B W X Y) 2 μ)
      Filter.atTop (nhds 0) := by
  refine Filter.tendsto_of_subseq_tendsto fun ns hns => ?_
  obtain ⟨φ, _, h_ae⟩ :=
    exists_subseq_ae_tendsto_linearFittedPrediction μ hB hX hY (hW.comp hns)
  refine ⟨φ, ?_⟩
  let F : ℕ → Ω → EuclideanSpace ℝ (Fin K) := fun k =>
    linearFittedPrediction μ B (W_seq (ns (φ k))) X Y - linearFittedPrediction μ B W X Y
  have hp0 : (2 : ℝ≥0∞) ≠ 0 := by norm_num
  have hptop : (2 : ℝ≥0∞) ≠ ∞ := by norm_num
  have hp_pos : (0 : ℝ) < (2 : ℝ≥0∞).toReal := ENNReal.toReal_pos hp0 hptop
  suffices h_lint : Filter.Tendsto
      (fun k => ∫⁻ ω, ‖F k ω‖ₑ ^ (2 : ℝ≥0∞).toReal ∂μ) Filter.atTop (nhds 0) by
    change Filter.Tendsto (fun k => MeasureTheory.eLpNorm (F k) 2 μ) Filter.atTop (nhds 0)
    simp only [MeasureTheory.eLpNorm_eq_lintegral_rpow_enorm hp0 hptop]
    convert ENNReal.continuous_rpow_const.continuousAt.tendsto.comp h_lint
    simp
  have hF_meas : ∀ k : ℕ, Measurable (fun ω => ‖F k ω‖ₑ ^ (2 : ℝ≥0∞).toReal) := by
    intro k
    have hFk : Measurable (F k) :=
      (linearFittedPrediction_measurable μ hB (W_seq (ns (φ k))) hX hY).sub
        (linearFittedPrediction_measurable μ hB W hX hY)
    exact ENNReal.continuous_rpow_const.measurable.comp hFk.enorm
  have h_bound : ∀ k : ℕ,
      (fun ω => ‖F k ω‖ₑ ^ (2 : ℝ≥0∞).toReal) ≤ᵐ[μ]
        (fun _ : Ω => ((2 : NNReal) : ℝ≥0∞) ^ (2 : ℝ≥0∞).toReal) := by
    intro k
    refine Filter.Eventually.of_forall fun ω => ?_
    refine ENNReal.rpow_le_rpow ?_ ENNReal.toReal_nonneg
    have hnorm2 : ‖F k ω‖ ≤ 2 :=
      norm_sub_le_two_of_mem_simplex
        (linearFittedPrediction_mem_simplex μ hB (W_seq (ns (φ k))) hX hY ω)
        (linearFittedPrediction_mem_simplex μ hB W hX hY ω)
    have hnn : ‖F k ω‖₊ ≤ (2 : NNReal) := hnorm2
    exact ENNReal.coe_mono hnn
  have h_fin : (∫⁻ _ : Ω, ((2 : NNReal) : ℝ≥0∞) ^ (2 : ℝ≥0∞).toReal ∂μ) ≠ ⊤ := by
    rw [MeasureTheory.lintegral_const, MeasureTheory.measure_univ, mul_one]
    exact (ENNReal.rpow_lt_top_of_nonneg ENNReal.toReal_nonneg (ENNReal.coe_ne_top)).ne
  have h_lim : ∀ᵐ ω ∂μ,
      Filter.Tendsto (fun k => ‖F k ω‖ₑ ^ (2 : ℝ≥0∞).toReal) Filter.atTop (nhds 0) := by
    filter_upwards [h_ae] with ω hω
    have hsub0 : Filter.Tendsto (fun k => F k ω) Filter.atTop (nhds 0) := by
      have h1 := hω.sub (tendsto_const_nhds (x := linearFittedPrediction μ B W X Y ω))
      simpa [F] using h1
    have henorm0 : Filter.Tendsto (fun k => ‖F k ω‖ₑ) Filter.atTop (nhds 0) := by
      simpa [enorm] using ENNReal.tendsto_coe.mpr hsub0.nnnorm
    convert ENNReal.continuous_rpow_const.continuousAt.tendsto.comp henorm0
    simp [ENNReal.zero_rpow_of_pos hp_pos]
  simpa using MeasureTheory.tendsto_lintegral_of_dominated_convergence _ hF_meas h_bound h_fin h_lim

/-- The rank-one operator (P_W − e_Y) Xᵀ whose expectation is g(W). -/
noncomputable def matIntegrand {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) {d K : ℕ} (B : ℝ)
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin K) (ω : Ω) :
    EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin K) :=
  (innerSL ℝ (X ω)).smulRight (linearFittedPrediction μ B W X Y ω - oneHotLabel Y ω)

lemma matIntegrand_aestronglyMeasurable {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ] {d K : ℕ}
    {B : ℝ} (hB : 0 < B)
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
    {X : Ω → EuclideanSpace ℝ (Fin d)} (hX : Measurable X)
    {Y : Ω → Fin K} (hY : Measurable Y) :
    MeasureTheory.AEStronglyMeasurable (matIntegrand μ B W X Y) μ := by
  have hV : Measurable (fun ω => linearFittedPrediction μ B W X Y ω - oneHotLabel Y ω) :=
    (linearFittedPrediction_measurable μ hB W hX hY).sub (oneHotLabel_measurable hY)
  have aux0 : Continuous
      (fun p : EuclideanSpace ℝ (Fin d) × EuclideanSpace ℝ (Fin K) =>
        (innerSL ℝ p.1).smulRight p.2) :=
    (ContinuousLinearMap.smulRightL ℝ (EuclideanSpace ℝ (Fin d))
      (EuclideanSpace ℝ (Fin K))).continuous₂.comp
      (((innerSL ℝ).continuous.comp continuous_fst).prodMk continuous_snd)
  have aux1 : MeasureTheory.AEStronglyMeasurable
      (fun ω => (X ω, linearFittedPrediction μ B W X Y ω - oneHotLabel Y ω)) μ :=
    (hX.prodMk hV).aestronglyMeasurable
  exact (aux0.comp_aestronglyMeasurable aux1 :)

lemma matIntegrand_norm_le {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ] {d K : ℕ}
    {B : ℝ} (hB : 0 < B)
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
    {X : Ω → EuclideanSpace ℝ (Fin d)} (hX : Measurable X)
    {Y : Ω → Fin K} (hY : Measurable Y) (ω : Ω) :
    ‖matIntegrand μ B W X Y ω‖ ≤ 2 * ‖X ω‖ := by
  unfold matIntegrand
  rw [ContinuousLinearMap.norm_smulRight_apply, innerSL_apply_norm]
  have h2 : ‖linearFittedPrediction μ B W X Y ω - oneHotLabel Y ω‖ ≤ 2 :=
    norm_sub_le_two_of_mem_simplex
      (linearFittedPrediction_mem_simplex μ hB W hX hY ω)
      (oneHotLabel_mem_simplex Y ω)
  nlinarith [norm_nonneg (X ω)]

lemma matIntegrand_integrable {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ] {d K : ℕ}
    {B : ℝ} (hB : 0 < B)
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
    {X : Ω → EuclideanSpace ℝ (Fin d)} (hX : Measurable X)
    (hX_int : MeasureTheory.Integrable X μ)
    {Y : Ω → Fin K} (hY : Measurable Y) :
    MeasureTheory.Integrable (matIntegrand μ B W X Y) μ :=
  (hX_int.norm.const_mul 2).mono'
    (matIntegrand_aestronglyMeasurable μ hB W hX hY)
    (Filter.Eventually.of_forall (matIntegrand_norm_le μ hB W hX hY))

lemma matIntegral_apply_mem_zeroSumSubspace {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ] {d K : ℕ}
    {B : ℝ} (hB : 0 < B)
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
    {X : Ω → EuclideanSpace ℝ (Fin d)} (hX : Measurable X)
    (hX_int : MeasureTheory.Integrable X μ)
    {Y : Ω → Fin K} (hY : Measurable Y)
    (x : EuclideanSpace ℝ (Fin d)) :
    (∫ ω, matIntegrand μ B W X Y ω ∂μ) x ∈ ZeroSumSubspace K := by
  have hint := matIntegrand_integrable μ hB W hX hX_int hY
  let ev_x : (EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin K)) →L[ℝ]
      EuclideanSpace ℝ (Fin K) :=
    ContinuousLinearMap.apply ℝ (EuclideanSpace ℝ (Fin K)) x
  have hev_eq : (∫ ω, matIntegrand μ B W X Y ω ∂μ) x =
      ∫ ω, ev_x (matIntegrand μ B W X Y ω) ∂μ :=
    (ev_x.integral_comp_comm hint).symm
  rw [hev_eq]
  change (innerSL ℝ (onesVec K)) (∫ ω, ev_x (matIntegrand μ B W X Y ω) ∂μ) = 0
  rw [← (innerSL ℝ (onesVec K)).integral_comp_comm (ev_x.integrable_comp hint)]
  have hzero : ∀ ω : Ω, (innerSL ℝ (onesVec K)) (ev_x (matIntegrand μ B W X Y ω)) = 0 := by
    intro ω
    have hmem : linearFittedPrediction μ B W X Y ω - oneHotLabel Y ω ∈ ZeroSumSubspace K :=
      sub_mem_zeroSumSubspace
        (linearFittedPrediction_mem_simplex μ hB W hX hY ω)
        (oneHotLabel_mem_simplex Y ω)
    have hsmul : (inner ℝ (X ω) x) •
        (linearFittedPrediction μ B W X Y ω - oneHotLabel Y ω) ∈ ZeroSumSubspace K :=
      (ZeroSumSubspace K).smul_mem (inner ℝ (X ω) x) hmem
    exact hsmul
  simp [hzero]

lemma matIntegral_continuous {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ] {d K : ℕ}
    {B : ℝ} (hB : 0 < B)
    {X : Ω → EuclideanSpace ℝ (Fin d)} (hX : Measurable X)
    (hX_int : MeasureTheory.Integrable X μ)
    {Y : Ω → Fin K} (hY : Measurable Y) :
    Continuous (fun W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K =>
      ∫ ω, matIntegrand μ B W X Y ω ∂μ) := by
  rw [continuous_iff_continuousAt]
  intro W
  haveI : (nhds W).IsCountablyGenerated :=
    (Metric.nhds_basis_ball_inv_nat_pos (x := W)).isCountablyGenerated
  rw [ContinuousAt, Filter.tendsto_iff_seq_tendsto]
  intro W_seq hW
  refine Filter.tendsto_of_subseq_tendsto fun ns hns => ?_
  obtain ⟨φ, _, h_ae⟩ :=
    exists_subseq_ae_tendsto_linearFittedPrediction μ hB hX hY (hW.comp hns)
  refine ⟨φ, ?_⟩
  refine MeasureTheory.tendsto_integral_of_dominated_convergence
    (fun ω => 2 * ‖X ω‖)
    (fun k => matIntegrand_aestronglyMeasurable μ hB (W_seq (ns (φ k))) hX hY)
    (hX_int.norm.const_mul 2)
    (fun k => Filter.Eventually.of_forall (matIntegrand_norm_le μ hB (W_seq (ns (φ k))) hX hY))
    ?_
  filter_upwards [h_ae] with ω hω
  have hcont_v : Continuous
      (fun v : EuclideanSpace ℝ (Fin K) =>
        (innerSL ℝ (X ω)).smulRight (v - oneHotLabel Y ω)) :=
    (ContinuousLinearMap.smulRightL ℝ (EuclideanSpace ℝ (Fin d)) (EuclideanSpace ℝ (Fin K))
      (innerSL ℝ (X ω))).continuous.comp (continuous_id.sub continuous_const)
  exact hcont_v.continuousAt.tendsto.comp hω

end UL.Proof_lem_A_2

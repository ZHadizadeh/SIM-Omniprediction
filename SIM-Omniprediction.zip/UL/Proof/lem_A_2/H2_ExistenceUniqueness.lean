import Mathlib
import UL.Def.def_2_1
import UL.Def.def_A_fit
import UL.Proof.lem_A_2.H1_SimplexLipschitz
set_option autoImplicit false

namespace UL.Proof_lem_A_2

lemma parallelogram_midpoint_sq {E : Type*} [SeminormedAddCommGroup E] [InnerProductSpace ℝ E]
    (u v z : E) :
    ‖((1 / 2 : ℝ) • u + (1 / 2 : ℝ) • v) - z‖ ^ 2 + (1 / 4 : ℝ) * ‖u - v‖ ^ 2 =
      (1 / 2 : ℝ) * ‖u - z‖ ^ 2 + (1 / 2 : ℝ) * ‖v - z‖ ^ 2 := by
  let a : E := u - z
  let b : E := v - z
  have h1 : ((1 / 2 : ℝ) • u + (1 / 2 : ℝ) • v) - z = (1 / 2 : ℝ) • (a + b) := by
    dsimp [a, b]
    module
  have h2 : u - v = a - b := by
    dsimp [a, b]
    module
  rw [h1, h2, norm_smul, Real.norm_eq_abs]
  have hab_add := norm_add_sq_real a b
  have hab_sub := norm_sub_sq_real a b
  have habs : |(1 / 2 : ℝ)| = 1 / 2 := by norm_num
  rw [habs]
  change (1 / 2 * ‖a + b‖) ^ 2 + 1 / 4 * ‖a - b‖ ^ 2 =
    1 / 2 * ‖a‖ ^ 2 + 1 / 2 * ‖b‖ ^ 2
  linarith

lemma measurable_sq_norm_sub_oneHotLabel {Ω : Type*} [MeasurableSpace Ω] {K : ℕ} {B : ℝ}
    {S : Ω → ZeroSumSubspace K} (hS : Measurable S)
    {Y : Ω → Fin K} (hY : Measurable Y)
    {ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hρ : ρ ∈ LipschitzSimplexMaps K B) :
    Measurable (fun ω => ‖ρ (S ω) - oneHotLabel Y ω‖ ^ 2) := by
  have hpred : Measurable (fun ω => ρ (S ω)) := hρ.2.1.continuous.measurable.comp hS
  have hdiff : Measurable (fun ω => ρ (S ω) - oneHotLabel Y ω) :=
    hpred.sub (oneHotLabel_measurable hY)
  exact (continuous_pow 2).measurable.comp hdiff.norm

lemma sq_norm_sub_oneHotLabel_le_four {Ω : Type*} {K : ℕ} {B : ℝ}
    (S : Ω → ZeroSumSubspace K) (Y : Ω → Fin K)
    {ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hρ : ρ ∈ LipschitzSimplexMaps K B) (ω : Ω) :
    ‖ρ (S ω) - oneHotLabel Y ω‖ ^ 2 ≤ 4 := by
  have h2 : ‖ρ (S ω) - oneHotLabel Y ω‖ ≤ 2 :=
    norm_sub_le_two_of_mem_simplex (hρ.2.2 (S ω)) (oneHotLabel_mem_simplex Y ω)
  nlinarith [norm_nonneg (ρ (S ω) - oneHotLabel Y ω)]

lemma integrable_sq_norm_sub_oneHotLabel {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ] {K : ℕ} {B : ℝ}
    {S : Ω → ZeroSumSubspace K} (hS : Measurable S)
    {Y : Ω → Fin K} (hY : Measurable Y)
    {ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hρ : ρ ∈ LipschitzSimplexMaps K B) :
    MeasureTheory.Integrable (fun ω => ‖ρ (S ω) - oneHotLabel Y ω‖ ^ 2) μ := by
  refine (MeasureTheory.integrable_const (4 : ℝ)).mono'
    (measurable_sq_norm_sub_oneHotLabel hS hY hρ).aestronglyMeasurable
    (Filter.Eventually.of_forall fun ω => ?_)
  rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
  exact sq_norm_sub_oneHotLabel_le_four S Y hρ ω

lemma lsFitRisk_nonneg {Ω : Type*} [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    {K : ℕ} (S : Ω → ZeroSumSubspace K) (Y : Ω → Fin K)
    (ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)) :
    0 ≤ lsFitRisk μ S Y ρ :=
  MeasureTheory.integral_nonneg (fun _ => sq_nonneg _)

lemma tendsto_lsFitRisk {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ] {K : ℕ} {B : ℝ}
    {S_seq : ℕ → Ω → ZeroSumSubspace K} (hS_seq : ∀ n, Measurable (S_seq n))
    {S : Ω → ZeroSumSubspace K} (hS : Measurable S)
    {Y : Ω → Fin K} (hY : Measurable Y)
    {ρ_seq : ℕ → ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hρ_seq : ∀ n, ρ_seq n ∈ LipschitzSimplexMaps K B)
    {ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (_hρ : ρ ∈ LipschitzSimplexMaps K B)
    (h_pt : ∀ ω : Ω, Filter.Tendsto (fun n => ρ_seq n (S_seq n ω)) Filter.atTop (nhds (ρ (S ω)))) :
    Filter.Tendsto (fun n => lsFitRisk μ (S_seq n) Y (ρ_seq n))
      Filter.atTop (nhds (lsFitRisk μ S Y ρ)) := by
  unfold lsFitRisk
  refine MeasureTheory.tendsto_integral_of_dominated_convergence (fun _ : Ω => (4 : ℝ))
    (fun n => (measurable_sq_norm_sub_oneHotLabel (hS_seq n) hY (hρ_seq n)).aestronglyMeasurable)
    (MeasureTheory.integrable_const (4 : ℝ))
    (fun n => Filter.Eventually.of_forall fun ω => ?_)
    (Filter.Eventually.of_forall fun ω => ?_)
  · rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
    exact sq_norm_sub_oneHotLabel_le_four (S_seq n) Y (hρ_seq n) ω
  · exact (continuous_pow 2).continuousAt.tendsto.comp
      (((h_pt ω).sub tendsto_const_nhds).norm)

lemma exists_isLipschitzLSFitProfile {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ] {K : ℕ}
    {B : ℝ} (hB : 0 < B)
    {S : Ω → ZeroSumSubspace K} (hS : Measurable S)
    {Y : Ω → Fin K} (hY : Measurable Y) :
    ∃ ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K),
      IsLipschitzLSFitProfile μ B S Y ρ := by
  have ⟨ω₀⟩ := nonempty_of_isProbabilityMeasure μ
  let ρ₀ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) := fun _ => oneHotVec (Y ω₀)
  have hρ₀ : ρ₀ ∈ LipschitzSimplexMaps K B :=
    const_mem_lipschitzSimplexMaps (le_of_lt hB) (oneHotVec_mem_simplex (Y ω₀))
  let Rset : Set ℝ := (lsFitRisk μ S Y) '' (LipschitzSimplexMaps K B)
  have hR_ne : Rset.Nonempty := ⟨lsFitRisk μ S Y ρ₀, ρ₀, hρ₀, rfl⟩
  have hR_bdd : BddBelow Rset := ⟨0, fun _ ⟨ρ', _, hEq⟩ => hEq ▸ lsFitRisk_nonneg μ S Y ρ'⟩
  let I : ℝ := sInf Rset
  have h_min_seq : ∀ n : ℕ, ∃ ρ' ∈ LipschitzSimplexMaps K B,
      lsFitRisk μ S Y ρ' < I + 1 / ((n : ℝ) + 1) := by
    intro n
    have hlt : I < I + 1 / ((n : ℝ) + 1) := lt_add_of_pos_right I (by positivity)
    obtain ⟨r, ⟨ρ', hρ'_mem, rfl⟩, hr_lt⟩ := exists_lt_of_csInf_lt hR_ne hlt
    exact ⟨ρ', hρ'_mem, hr_lt⟩
  let ρ_seq : ℕ → ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) :=
    fun n => Classical.choose (h_min_seq n)
  have hρ_seq_mem : ∀ n, ρ_seq n ∈ LipschitzSimplexMaps K B :=
    fun n => (Classical.choose_spec (h_min_seq n)).1
  have hρ_seq_lt : ∀ n : ℕ, lsFitRisk μ S Y (ρ_seq n) < I + 1 / ((n : ℝ) + 1) :=
    fun n => (Classical.choose_spec (h_min_seq n)).2
  have hρ_seq_ge : ∀ n : ℕ, I ≤ lsFitRisk μ S Y (ρ_seq n) :=
    fun n => csInf_le hR_bdd ⟨ρ_seq n, hρ_seq_mem n, rfl⟩
  have h_upper : Filter.Tendsto (fun n : ℕ => I + 1 / ((n : ℝ) + 1)) Filter.atTop (nhds I) := by
    have h0 : Filter.Tendsto (fun n : ℕ => 1 / ((n : ℝ) + 1)) Filter.atTop (nhds 0) :=
      tendsto_one_div_add_atTop_nhds_zero_nat
    simpa using tendsto_const_nhds.add h0
  have h_risk_I : Filter.Tendsto (fun n => lsFitRisk μ S Y (ρ_seq n)) Filter.atTop (nhds I) :=
    tendsto_of_tendsto_of_tendsto_of_le_of_le tendsto_const_nhds h_upper hρ_seq_ge
      (fun n => le_of_lt (hρ_seq_lt n))
  obtain ⟨ρ, φ, hρ_mem, hφ_mono, hρ_pt⟩ := exists_subseq_tendsto_pointwise hρ_seq_mem
  have h_sub_I : Filter.Tendsto (fun k => lsFitRisk μ S Y (ρ_seq (φ k))) Filter.atTop (nhds I) :=
    h_risk_I.comp hφ_mono.tendsto_atTop
  have h_sub_ρ : Filter.Tendsto (fun k => lsFitRisk μ S Y (ρ_seq (φ k)))
      Filter.atTop (nhds (lsFitRisk μ S Y ρ)) :=
    tendsto_lsFitRisk μ (fun _ => hS) hS hY (fun k => hρ_seq_mem (φ k)) hρ_mem
      (fun ω => hρ_pt (S ω))
  have h_eq : lsFitRisk μ S Y ρ = I := tendsto_nhds_unique h_sub_ρ h_sub_I
  refine ⟨ρ, hB, hρ_mem, ?_⟩
  rw [isMinOn_iff]
  intro ρ' hρ'
  rw [h_eq]
  exact csInf_le hR_bdd ⟨ρ', hρ', rfl⟩

lemma exists_isLipschitzLSFit {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ] {K : ℕ}
    {B : ℝ} (hB : 0 < B)
    {S : Ω → ZeroSumSubspace K} (hS : Measurable S)
    {Y : Ω → Fin K} (hY : Measurable Y) :
    ∃ P : Ω → EuclideanSpace ℝ (Fin K), IsLipschitzLSFit μ B S Y P := by
  obtain ⟨ρ, hρ⟩ := exists_isLipschitzLSFitProfile μ hB hS hY
  exact ⟨fun ω => ρ (S ω), ρ, hρ, rfl⟩

lemma isLipschitzLSFit_ae_eq {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ] {K : ℕ}
    {B : ℝ} {S : Ω → ZeroSumSubspace K} (hS : Measurable S)
    {Y : Ω → Fin K} (hY : Measurable Y)
    {P₁ P₂ : Ω → EuclideanSpace ℝ (Fin K)}
    (h₁ : IsLipschitzLSFit μ B S Y P₁) (h₂ : IsLipschitzLSFit μ B S Y P₂) :
    P₁ =ᵐ[μ] P₂ := by
  rcases h₁ with ⟨ρ₁, ⟨_, hρ₁_mem, hρ₁_min⟩, rfl⟩
  rcases h₂ with ⟨ρ₂, ⟨_, hρ₂_mem, hρ₂_min⟩, rfl⟩
  let ρ_mid : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) :=
    fun s => (1 / 2 : ℝ) • ρ₁ s + (1 / 2 : ℝ) • ρ₂ s
  have h_mid_mem : ρ_mid ∈ LipschitzSimplexMaps K B :=
    midpoint_mem_lipschitzSimplexMaps hρ₁_mem hρ₂_mem
  have hint_mid := integrable_sq_norm_sub_oneHotLabel μ hS hY h_mid_mem
  have hint₁ := integrable_sq_norm_sub_oneHotLabel μ hS hY hρ₁_mem
  have hint₂ := integrable_sq_norm_sub_oneHotLabel μ hS hY hρ₂_mem
  have hdiff_meas : Measurable (fun ω => ‖ρ₁ (S ω) - ρ₂ (S ω)‖ ^ 2) := by
    have hp₁ : Measurable (fun ω => ρ₁ (S ω)) := hρ₁_mem.2.1.continuous.measurable.comp hS
    have hp₂ : Measurable (fun ω => ρ₂ (S ω)) := hρ₂_mem.2.1.continuous.measurable.comp hS
    exact (continuous_pow 2).measurable.comp (hp₁.sub hp₂).norm
  have hint_diff : MeasureTheory.Integrable (fun ω => ‖ρ₁ (S ω) - ρ₂ (S ω)‖ ^ 2) μ := by
    refine (MeasureTheory.integrable_const (4 : ℝ)).mono' hdiff_meas.aestronglyMeasurable
      (Filter.Eventually.of_forall fun ω => ?_)
    rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
    have h2 : ‖ρ₁ (S ω) - ρ₂ (S ω)‖ ≤ 2 :=
      norm_sub_le_two_of_mem_simplex (hρ₁_mem.2.2 (S ω)) (hρ₂_mem.2.2 (S ω))
    nlinarith [norm_nonneg (ρ₁ (S ω) - ρ₂ (S ω))]
  have h_pt : ∀ ω : Ω,
      ‖ρ_mid (S ω) - oneHotLabel Y ω‖ ^ 2 + (1 / 4 : ℝ) * ‖ρ₁ (S ω) - ρ₂ (S ω)‖ ^ 2 =
        (1 / 2 : ℝ) * ‖ρ₁ (S ω) - oneHotLabel Y ω‖ ^ 2 +
          (1 / 2 : ℝ) * ‖ρ₂ (S ω) - oneHotLabel Y ω‖ ^ 2 :=
    fun ω => parallelogram_midpoint_sq (ρ₁ (S ω)) (ρ₂ (S ω)) (oneHotLabel Y ω)
  have h_int_eq :
      lsFitRisk μ S Y ρ_mid + (1 / 4 : ℝ) * (∫ ω, ‖ρ₁ (S ω) - ρ₂ (S ω)‖ ^ 2 ∂μ) =
        (1 / 2 : ℝ) * lsFitRisk μ S Y ρ₁ + (1 / 2 : ℝ) * lsFitRisk μ S Y ρ₂ := by
    have hL : ∫ ω, (‖ρ_mid (S ω) - oneHotLabel Y ω‖ ^ 2 +
          (1 / 4 : ℝ) * ‖ρ₁ (S ω) - ρ₂ (S ω)‖ ^ 2) ∂μ =
        lsFitRisk μ S Y ρ_mid + (1 / 4 : ℝ) * (∫ ω, ‖ρ₁ (S ω) - ρ₂ (S ω)‖ ^ 2 ∂μ) := by
      rw [MeasureTheory.integral_add hint_mid (hint_diff.const_mul (1 / 4 : ℝ)),
        MeasureTheory.integral_const_mul]
      rfl
    have hR : ∫ ω, ((1 / 2 : ℝ) * ‖ρ₁ (S ω) - oneHotLabel Y ω‖ ^ 2 +
          (1 / 2 : ℝ) * ‖ρ₂ (S ω) - oneHotLabel Y ω‖ ^ 2) ∂μ =
        (1 / 2 : ℝ) * lsFitRisk μ S Y ρ₁ + (1 / 2 : ℝ) * lsFitRisk μ S Y ρ₂ := by
      rw [MeasureTheory.integral_add (hint₁.const_mul (1 / 2 : ℝ)) (hint₂.const_mul (1 / 2 : ℝ)),
        MeasureTheory.integral_const_mul, MeasureTheory.integral_const_mul]
      rfl
    rw [← hL, ← hR]
    exact MeasureTheory.integral_congr_ae (Filter.Eventually.of_forall h_pt)
  have hle₁ : lsFitRisk μ S Y ρ₁ ≤ lsFitRisk μ S Y ρ_mid := isMinOn_iff.mp hρ₁_min ρ_mid h_mid_mem
  have hle₂ : lsFitRisk μ S Y ρ₂ ≤ lsFitRisk μ S Y ρ_mid := isMinOn_iff.mp hρ₂_min ρ_mid h_mid_mem
  have h_int_nonneg : 0 ≤ ∫ ω, ‖ρ₁ (S ω) - ρ₂ (S ω)‖ ^ 2 ∂μ :=
    MeasureTheory.integral_nonneg (fun _ => sq_nonneg _)
  have h_int_zero : ∫ ω, ‖ρ₁ (S ω) - ρ₂ (S ω)‖ ^ 2 ∂μ = 0 := by linarith
  have h_ae_zero : (fun ω => ‖ρ₁ (S ω) - ρ₂ (S ω)‖ ^ 2) =ᵐ[μ] 0 :=
    (MeasureTheory.integral_eq_zero_iff_of_nonneg_ae
      (Filter.Eventually.of_forall fun _ => sq_nonneg _) hint_diff).mp h_int_zero
  filter_upwards [h_ae_zero] with ω hω
  have hsq0 : ‖ρ₁ (S ω) - ρ₂ (S ω)‖ ^ 2 = 0 := hω
  have hn0 : ‖ρ₁ (S ω) - ρ₂ (S ω)‖ = 0 := sq_eq_zero_iff.mp hsq0
  exact sub_eq_zero.mp (norm_eq_zero.mp hn0)

lemma fittedPrediction_isLipschitzLSFit {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ] {K : ℕ}
    {B : ℝ} (hB : 0 < B)
    {S : Ω → ZeroSumSubspace K} (hS : Measurable S)
    {Y : Ω → Fin K} (hY : Measurable Y) :
    IsLipschitzLSFit μ B S Y (fittedPrediction μ B S Y) := by
  have hex : ∃ P, IsLipschitzLSFit μ B S Y P := exists_isLipschitzLSFit μ hB hS hY
  unfold fittedPrediction
  rw [dif_pos hex]
  exact Classical.choose_spec hex

lemma linearScore_measurable {Ω : Type*} [MeasurableSpace Ω] {d K : ℕ}
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
    {X : Ω → EuclideanSpace ℝ (Fin d)} (hX : Measurable X) :
    Measurable (linearScore W X) :=
  W.continuous.measurable.comp hX

lemma linearFittedPrediction_isLinearLipschitzLSFit {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ] {d K : ℕ}
    {B : ℝ} (hB : 0 < B)
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
    {X : Ω → EuclideanSpace ℝ (Fin d)} (hX : Measurable X)
    {Y : Ω → Fin K} (hY : Measurable Y) :
    IsLinearLipschitzLSFit μ B W X Y (linearFittedPrediction μ B W X Y) :=
  fittedPrediction_isLipschitzLSFit μ hB (linearScore_measurable W hX) hY

lemma linearFittedPrediction_measurable {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ] {d K : ℕ}
    {B : ℝ} (hB : 0 < B)
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
    {X : Ω → EuclideanSpace ℝ (Fin d)} (hX : Measurable X)
    {Y : Ω → Fin K} (hY : Measurable Y) :
    Measurable (linearFittedPrediction μ B W X Y) := by
  obtain ⟨ρ, ⟨_, hρ_mem, _⟩, hP_eq⟩ :=
    linearFittedPrediction_isLinearLipschitzLSFit μ hB W hX hY
  rw [hP_eq]
  exact hρ_mem.2.1.continuous.measurable.comp (linearScore_measurable W hX)

lemma linearFittedPrediction_mem_simplex {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ] {d K : ℕ}
    {B : ℝ} (hB : 0 < B)
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
    {X : Ω → EuclideanSpace ℝ (Fin d)} (hX : Measurable X)
    {Y : Ω → Fin K} (hY : Measurable Y) (ω : Ω) :
    linearFittedPrediction μ B W X Y ω ∈ Simplex K := by
  obtain ⟨ρ, ⟨_, hρ_mem, _⟩, hP_eq⟩ :=
    linearFittedPrediction_isLinearLipschitzLSFit μ hB W hX hY
  rw [hP_eq]
  exact hρ_mem.2.2 _

end UL.Proof_lem_A_2

import Mathlib
import UL.Def.def_2_1
import UL.Def.def_A_fit
set_option autoImplicit false

namespace UL.Proof_lem_A_2

lemma nonempty_of_isProbabilityMeasure {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ] :
    Nonempty Ω := by
  by_contra h
  rw [not_nonempty_iff] at h
  have huniv : (Set.univ : Set Ω) = ∅ := Set.eq_empty_of_isEmpty Set.univ
  have h1 : μ Set.univ = 1 := MeasureTheory.measure_univ
  rw [huniv, MeasureTheory.measure_empty] at h1
  exact zero_ne_one h1

lemma inner_eq_sum {N : ℕ} (x y : EuclideanSpace ℝ (Fin N)) :
    inner ℝ x y = ∑ i : Fin N, x i * y i := by
  rw [PiLp.inner_apply]
  refine Finset.sum_congr rfl (fun i _ => ?_)
  simp [mul_comm]

lemma norm_sq_eq_sum {N : ℕ} (x : EuclideanSpace ℝ (Fin N)) :
    ‖x‖ ^ 2 = ∑ i : Fin N, (x i) ^ 2 := by
  rw [← real_inner_self_eq_norm_sq, inner_eq_sum]
  refine Finset.sum_congr rfl (fun i _ => ?_)
  ring

lemma onesVec_apply (K : ℕ) (j : Fin K) : onesVec K j = 1 := rfl

lemma inner_onesVec {K : ℕ} (x : EuclideanSpace ℝ (Fin K)) :
    inner ℝ (onesVec K) x = ∑ j : Fin K, x j := by
  rw [inner_eq_sum]
  simp [onesVec_apply]

lemma oneHotVec_mem_simplex {K : ℕ} (y : Fin K) : oneHotVec y ∈ Simplex K := by
  refine ⟨fun j => ?_, ?_⟩
  · simp only [oneHotVec, EuclideanSpace.single_apply]
    split_ifs <;> norm_num
  · simp [oneHotVec, EuclideanSpace.single_apply]

lemma oneHotLabel_mem_simplex {Ω : Type*} {K : ℕ} (Y : Ω → Fin K) (ω : Ω) :
    oneHotLabel Y ω ∈ Simplex K :=
  oneHotVec_mem_simplex (Y ω)

lemma oneHotLabel_measurable {Ω : Type*} [MeasurableSpace Ω] {K : ℕ}
    {Y : Ω → Fin K} (hY : Measurable Y) :
    Measurable (oneHotLabel Y) :=
  ( measurable_of_countable (oneHotVec (K := K)) ).comp hY

lemma coord_le_one_of_mem_simplex {K : ℕ} {q : EuclideanSpace ℝ (Fin K)}
    (hq : q ∈ Simplex K) (j : Fin K) : q j ≤ 1 := by
  have hsub : q j ≤ ∑ i : Fin K, q i :=
    Finset.single_le_sum (fun i _ => hq.1 i) (Finset.mem_univ j)
  linarith [hq.2]

lemma norm_le_one_of_mem_simplex {K : ℕ} {q : EuclideanSpace ℝ (Fin K)}
    (hq : q ∈ Simplex K) : ‖q‖ ≤ 1 := by
  have hsq : ‖q‖ ^ 2 ≤ 1 := by
    rw [norm_sq_eq_sum]
    calc ∑ i : Fin K, (q i) ^ 2
        ≤ ∑ i : Fin K, q i := by
          refine Finset.sum_le_sum (fun i _ => ?_)
          nlinarith [hq.1 i, coord_le_one_of_mem_simplex hq i]
      _ = 1 := hq.2
  nlinarith [norm_nonneg q]

lemma norm_sub_le_two_of_mem_simplex {K : ℕ} {p q : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ Simplex K) (hq : q ∈ Simplex K) : ‖p - q‖ ≤ 2 := by
  calc ‖p - q‖
      ≤ ‖p‖ + ‖q‖ := norm_sub_le p q
    _ ≤ 1 + 1 := add_le_add (norm_le_one_of_mem_simplex hp) (norm_le_one_of_mem_simplex hq)
    _ = 2 := by norm_num

lemma sub_mem_zeroSumSubspace {K : ℕ} {p q : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ Simplex K) (hq : q ∈ Simplex K) :
    p - q ∈ ZeroSumSubspace K := by
  change inner ℝ (onesVec K) (p - q) = 0
  rw [inner_sub_right, inner_onesVec, inner_onesVec, hp.2, hq.2, sub_self]

lemma simplex_convex (K : ℕ) : Convex ℝ (Simplex K) := by
  intro x hx y hy a b ha hb hab
  refine ⟨fun j => ?_, ?_⟩
  · change 0 ≤ a * x j + b * y j
    exact add_nonneg (mul_nonneg ha (hx.1 j)) (mul_nonneg hb (hy.1 j))
  · have h : ∑ j : Fin K, (a • x + b • y) j =
        a * (∑ j : Fin K, x j) + b * (∑ j : Fin K, y j) := by
      calc ∑ j : Fin K, (a • x + b • y) j
          = ∑ j : Fin K, (a * x j + b * y j) := rfl
        _ = (∑ j : Fin K, a * x j) + ∑ j : Fin K, b * y j := Finset.sum_add_distrib
        _ = a * (∑ j : Fin K, x j) + b * (∑ j : Fin K, y j) := by
              rw [← Finset.mul_sum, ← Finset.mul_sum]
    rw [h, hx.2, hy.2]
    linarith

lemma simplex_isClosed (K : ℕ) : IsClosed (Simplex K) := by
  have hEq : Simplex K = (⋂ j : Fin K, {q : EuclideanSpace ℝ (Fin K) | 0 ≤ q j}) ∩
      {q : EuclideanSpace ℝ (Fin K) | ∑ j : Fin K, q j = 1} := by
    ext q
    simp [Simplex]
  rw [hEq]
  have hcont : ∀ j : Fin K, Continuous (fun q : EuclideanSpace ℝ (Fin K) => q j) :=
    fun j => PiLp.continuous_apply 2 (fun _ : Fin K => ℝ) j
  refine IsClosed.inter ?_ ?_
  · exact isClosed_iInter (fun j => isClosed_le continuous_const (hcont j))
  · exact isClosed_eq (continuous_finset_sum Finset.univ (fun j _ => hcont j)) continuous_const

lemma simplex_isCompact (K : ℕ) : IsCompact (Simplex K) := by
  rw [Metric.isCompact_iff_isClosed_bounded]
  refine ⟨simplex_isClosed K, ?_⟩
  rw [Metric.isBounded_iff_subset_closedBall 0]
  refine ⟨1, fun q hq => ?_⟩
  rw [Metric.mem_closedBall, dist_zero_right]
  exact norm_le_one_of_mem_simplex hq

lemma const_mem_lipschitzSimplexMaps {K : ℕ} {B : ℝ} (hB : 0 ≤ B)
    {q : EuclideanSpace ℝ (Fin K)} (hq : q ∈ Simplex K) :
    (fun _ : ZeroSumSubspace K => q) ∈ LipschitzSimplexMaps K B := by
  refine ⟨hB, ?_, fun _ => hq⟩
  rw [lipschitzWith_iff_dist_le_mul]
  intro x y
  rw [dist_self]
  positivity

lemma midpoint_mem_lipschitzSimplexMaps {K : ℕ} {B : ℝ}
    {ρ₁ ρ₂ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (h₁ : ρ₁ ∈ LipschitzSimplexMaps K B) (h₂ : ρ₂ ∈ LipschitzSimplexMaps K B) :
    (fun s => (1 / 2 : ℝ) • ρ₁ s + (1 / 2 : ℝ) • ρ₂ s) ∈ LipschitzSimplexMaps K B := by
  refine ⟨h₁.1, ?_, fun s => ?_⟩
  · rw [lipschitzWith_iff_dist_le_mul]
    intro x y
    have hd₁ := lipschitzWith_iff_dist_le_mul.mp h₁.2.1 x y
    have hd₂ := lipschitzWith_iff_dist_le_mul.mp h₂.2.1 x y
    rw [dist_eq_norm] at hd₁ hd₂ ⊢
    have hrew : ((1 / 2 : ℝ) • ρ₁ x + (1 / 2 : ℝ) • ρ₂ x) -
        ((1 / 2 : ℝ) • ρ₁ y + (1 / 2 : ℝ) • ρ₂ y) =
        (1 / 2 : ℝ) • (ρ₁ x - ρ₁ y) + (1 / 2 : ℝ) • (ρ₂ x - ρ₂ y) := by
      module
    rw [hrew]
    calc ‖(1 / 2 : ℝ) • (ρ₁ x - ρ₁ y) + (1 / 2 : ℝ) • (ρ₂ x - ρ₂ y)‖
        ≤ ‖(1 / 2 : ℝ) • (ρ₁ x - ρ₁ y)‖ + ‖(1 / 2 : ℝ) • (ρ₂ x - ρ₂ y)‖ := norm_add_le _ _
      _ = (1 / 2 : ℝ) * ‖ρ₁ x - ρ₁ y‖ + (1 / 2 : ℝ) * ‖ρ₂ x - ρ₂ y‖ := by
            simp [norm_smul, Real.norm_eq_abs]
      _ ≤ (Real.toNNReal B : ℝ) * dist x y := by linarith
  · exact simplex_convex K (h₁.2.2 s) (h₂.2.2 s) (by norm_num) (by norm_num) (by norm_num)

lemma exists_subseq_tendsto_pointwise {K : ℕ} {B : ℝ}
    {ρ_seq : ℕ → ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (h_mem : ∀ n, ρ_seq n ∈ LipschitzSimplexMaps K B) :
    ∃ (ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)) (φ : ℕ → ℕ),
      ρ ∈ LipschitzSimplexMaps K B ∧ StrictMono φ ∧
      ∀ s : ZeroSumSubspace K,
        Filter.Tendsto (fun k => ρ_seq (φ k) s) Filter.atTop (nhds (ρ s)) := by
  have hB0 : 0 ≤ B := (h_mem 0).1
  let d : ℕ → ZeroSumSubspace K := TopologicalSpace.denseSeq (ZeroSumSubspace K)
  have hd : DenseRange d := TopologicalSpace.denseRange_denseSeq (ZeroSumSubspace K)
  let P : Set (ℕ → EuclideanSpace ℝ (Fin K)) := {x | ∀ m : ℕ, x m ∈ Simplex K}
  have hP_compact : IsCompact P := isCompact_pi_infinite (fun _ => simplex_isCompact K)
  have hP_seq : IsSeqCompact P := hP_compact.isSeqCompact
  let g : ℕ → (ℕ → EuclideanSpace ℝ (Fin K)) := fun n m => ρ_seq n (d m)
  have hg_mem : ∀ n, g n ∈ P := fun n m => (h_mem n).2.2 (d m)
  obtain ⟨L, _, φ, hφ_mono, hφ_lim⟩ := hP_seq hg_mem
  have hφ_coord : ∀ m : ℕ,
      Filter.Tendsto (fun k => ρ_seq (φ k) (d m)) Filter.atTop (nhds (L m)) :=
    tendsto_pi_nhds.mp hφ_lim
  have h_cauchy : ∀ s : ZeroSumSubspace K, CauchySeq (fun k => ρ_seq (φ k) s) := by
    intro s
    rw [Metric.cauchySeq_iff]
    intro ε hε
    have hB1_pos : 0 < B + 1 := by linarith
    have h3B1_pos : 0 < 3 * (B + 1) := by linarith
    let δ : ℝ := ε / (3 * (B + 1))
    have hδ : 0 < δ := div_pos hε h3B1_pos
    obtain ⟨m₀, hm₀⟩ := Metric.denseRange_iff.mp hd s δ hδ
    have hdm : dist s (d m₀) < δ := by simpa [dist_comm] using hm₀
    obtain ⟨N, hN⟩ := Metric.cauchySeq_iff.mp (hφ_coord m₀).cauchySeq (ε / 3) (by linarith)
    refine ⟨N, fun k hk j hj => ?_⟩
    have hlip_k : dist (ρ_seq (φ k) s) (ρ_seq (φ k) (d m₀)) ≤ B * dist s (d m₀) := by
      have h := lipschitzWith_iff_dist_le_mul.mp (h_mem (φ k)).2.1 s (d m₀)
      rw [Real.coe_toNNReal B hB0] at h
      exact h
    have hlip_j : dist (ρ_seq (φ j) (d m₀)) (ρ_seq (φ j) s) ≤ B * dist s (d m₀) := by
      rw [dist_comm s (d m₀)]
      have h := lipschitzWith_iff_dist_le_mul.mp (h_mem (φ j)).2.1 (d m₀) s
      rw [Real.coe_toNNReal B hB0] at h
      exact h
    have hB_bound : B * dist s (d m₀) ≤ ε / 3 := by
      have h1 : B * dist s (d m₀) ≤ (B + 1) * δ := by
        calc B * dist s (d m₀)
            ≤ (B + 1) * dist s (d m₀) := by nlinarith [dist_nonneg (x := s) (y := d m₀)]
          _ ≤ (B + 1) * δ := by nlinarith
      have h2 : (B + 1) * δ = ε / 3 := by
        dsimp [δ]
        field_simp
      linarith
    have hmid : dist (ρ_seq (φ k) (d m₀)) (ρ_seq (φ j) (d m₀)) < ε / 3 := hN k hk j hj
    have htri1 := dist_triangle (ρ_seq (φ k) s) (ρ_seq (φ k) (d m₀)) (ρ_seq (φ j) s)
    have htri2 := dist_triangle (ρ_seq (φ k) (d m₀)) (ρ_seq (φ j) (d m₀)) (ρ_seq (φ j) s)
    linarith
  have h_conv : ∀ s : ZeroSumSubspace K,
      ∃ y : EuclideanSpace ℝ (Fin K),
        Filter.Tendsto (fun k => ρ_seq (φ k) s) Filter.atTop (nhds y) :=
    fun s => cauchySeq_tendsto_of_complete (h_cauchy s)
  let ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) :=
    fun s => Classical.choose (h_conv s)
  have hρ_lim : ∀ s : ZeroSumSubspace K,
      Filter.Tendsto (fun k => ρ_seq (φ k) s) Filter.atTop (nhds (ρ s)) :=
    fun s => Classical.choose_spec (h_conv s)
  refine ⟨ρ, φ, ⟨hB0, ?_, ?_⟩, hφ_mono, hρ_lim⟩
  · rw [lipschitzWith_iff_dist_le_mul]
    intro s₁ s₂
    have hdist_lim : Filter.Tendsto
        (fun k => dist (ρ_seq (φ k) s₁) (ρ_seq (φ k) s₂))
        Filter.atTop (nhds (dist (ρ s₁) (ρ s₂))) :=
      Filter.Tendsto.dist (hρ_lim s₁) (hρ_lim s₂)
    exact le_of_tendsto hdist_lim (Filter.Eventually.of_forall fun k =>
      lipschitzWith_iff_dist_le_mul.mp (h_mem (φ k)).2.1 s₁ s₂)
  · intro s
    exact (simplex_isClosed K).mem_of_tendsto (hρ_lim s)
      (Filter.Eventually.of_forall fun k => (h_mem (φ k)).2.2 s)

end UL.Proof_lem_A_2

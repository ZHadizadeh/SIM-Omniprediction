import Mathlib
set_option autoImplicit false

namespace UL.Proof_lem_A_4

section Proximal

variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]

lemma hasGradientAt_fderiv [CompleteSpace E] {f : E → ℝ} (hf : Differentiable ℝ f) (x : E) :
    HasFDerivAt f ((InnerProductSpace.toDual ℝ E) (gradient f x)) x :=
  (hf x).hasGradientAt

lemma convex_gradient_subgradient [CompleteSpace E] {f : E → ℝ}
    (hf_diff : Differentiable ℝ f) (hf_conv : ConvexOn ℝ Set.univ f) (x y : E) :
    f x + inner ℝ (gradient f x) (y - x) ≤ f y := by
  let g : ℝ → ℝ := fun θ => f (x + θ • (y - x))
  have h_ray : HasDerivAt (fun θ : ℝ => x + θ • (y - x)) (y - x) 0 := by
    simpa using ((hasDerivAt_id (0 : ℝ)).smul_const (y - x)).const_add x
  have hg_deriv : HasDerivAt g (inner ℝ (gradient f x) (y - x)) 0 := by
    have hx0 : HasFDerivAt f ((InnerProductSpace.toDual ℝ E) (gradient f x))
        (x + (0 : ℝ) • (y - x)) := by
      simpa using hasGradientAt_fderiv hf_diff x
    have hcomp := hx0.comp_hasDerivAt 0 h_ray
    simpa [g, InnerProductSpace.toDual_apply] using hcomp
  have h_tendsto := hg_deriv.tendsto_slope_zero_right
  have h_ev : ∀ᶠ θ in nhdsWithin (0 : ℝ) (Set.Ioi 0),
      θ⁻¹ • (g (0 + θ) - g 0) ≤ f y - f x := by
    have hIoo : Set.Ioo (0 : ℝ) 1 ∈ nhdsWithin (0 : ℝ) (Set.Ioi 0) :=
      mem_nhdsWithin.mpr ⟨Set.Iio 1, isOpen_Iio, Set.mem_Iio.mpr zero_lt_one,
        fun t ht => ⟨ht.2, ht.1⟩⟩
    filter_upwards [hIoo] with θ hθ
    have hθ0 : 0 < θ := hθ.1
    have hθ1 : θ < 1 := hθ.2
    have hcomb : (1 - θ) • x + θ • y = x + θ • (y - x) := by
      rw [sub_smul, one_smul, smul_sub]
      abel
    have hconv_step : f (x + θ • (y - x)) ≤ (1 - θ) * f x + θ * f y := by
      rw [← hcomb]
      exact hf_conv.2 trivial trivial (by linarith) hθ0.le (by linarith)
    change θ⁻¹ * (f (x + (0 + θ) • (y - x)) - f (x + (0 : ℝ) • (y - x))) ≤ f y - f x
    rw [zero_add, zero_smul, add_zero, inv_mul_le_iff₀ hθ0]
    linarith
  have h_le : inner ℝ (gradient f x) (y - x) ≤ f y - f x :=
    le_of_tendsto h_tendsto h_ev
  linarith

lemma gradient_monotone [CompleteSpace E] {f : E → ℝ}
    (hf_diff : Differentiable ℝ f) (hf_conv : ConvexOn ℝ Set.univ f) (x y : E) :
    0 ≤ inner ℝ (gradient f x - gradient f y) (x - y) := by
  have hxy := convex_gradient_subgradient hf_diff hf_conv x y
  have hyx := convex_gradient_subgradient hf_diff hf_conv y x
  have h_alg : inner ℝ (gradient f x - gradient f y) (x - y) =
      -inner ℝ (gradient f x) (y - x) - inner ℝ (gradient f y) (x - y) := by
    rw [inner_sub_left, ← inner_neg_right (gradient f x), neg_sub]
  linarith

lemma exists_prox_min [FiniteDimensional ℝ E] {f : E → ℝ}
    (hf_diff : Differentiable ℝ f) (hf_conv : ConvexOn ℝ Set.univ f)
    {t : ℝ} (ht : 0 < t) (s : E) :
    ∃ a₀ : E, ∀ a : E,
      f a₀ + (1 / (2 * t)) * ‖a₀ - s‖ ^ 2 ≤ f a + (1 / (2 * t)) * ‖a - s‖ ^ 2 := by
  let φ : E → ℝ := fun a => f a + (1 / (2 * t)) * ‖a - s‖ ^ 2
  let R₀ : ℝ := 2 * t * ‖gradient f s‖ + 1
  have hR₀ : 0 < R₀ := by positivity
  have hcomp : IsCompact (Metric.closedBall s R₀) := isCompact_closedBall s R₀
  have hne : (Metric.closedBall s R₀).Nonempty := ⟨s, Metric.mem_closedBall_self hR₀.le⟩
  have hcont : Continuous φ :=
    hf_diff.continuous.add (continuous_const.mul (((continuous_id.sub continuous_const).norm).pow 2))
  obtain ⟨a₀, ha₀_mem, ha₀_min⟩ := hcomp.exists_isMinOn hne hcont.continuousOn
  have ha₀_le_s : φ a₀ ≤ f s := by
    have hs_mem : s ∈ Metric.closedBall s R₀ := Metric.mem_closedBall_self hR₀.le
    have h := ha₀_min hs_mem
    simpa [φ] using h
  refine ⟨a₀, fun a => ?_⟩
  by_cases ha : a ∈ Metric.closedBall s R₀
  · exact ha₀_min ha
  · have hdist : R₀ < ‖a - s‖ := by
      rw [Metric.mem_closedBall, dist_eq_norm, not_le] at ha
      exact ha
    have hgt : 2 * t * ‖gradient f s‖ < ‖a - s‖ := by
      dsimp [R₀] at hdist
      linarith
    have hnorm_pos : 0 < ‖a - s‖ := lt_of_le_of_lt (by positivity) hgt
    have hsub := convex_gradient_subgradient hf_diff hf_conv s a
    have hcs : - (‖gradient f s‖ * ‖a - s‖) ≤ inner ℝ (gradient f s) (a - s) := by
      have h1 := abs_real_inner_le_norm (gradient f s) (a - s)
      linarith [neg_abs_le (inner ℝ (gradient f s) (a - s))]
    have hfa_lb : f s - ‖gradient f s‖ * ‖a - s‖ ≤ f a := by linarith
    have hquad : ‖gradient f s‖ * ‖a - s‖ < (1 / (2 * t)) * ‖a - s‖ ^ 2 := by
      have hdiv : ‖gradient f s‖ < (1 / (2 * t)) * ‖a - s‖ := by
        rw [one_div_mul_eq_div, lt_div_iff₀ (by positivity)]
        linarith
      calc ‖gradient f s‖ * ‖a - s‖
          < ((1 / (2 * t)) * ‖a - s‖) * ‖a - s‖ :=
            mul_lt_mul_of_pos_right hdiv hnorm_pos
        _ = (1 / (2 * t)) * ‖a - s‖ ^ 2 := by ring
    change φ a₀ ≤ φ a
    dsimp [φ]
    linarith

open Classical in
noncomputable def proxMap (f : E → ℝ) (t : ℝ) (s : E) : E :=
  if h : ∃ a₀ : E, ∀ a : E,
      f a₀ + (1 / (2 * t)) * ‖a₀ - s‖ ^ 2 ≤ f a + (1 / (2 * t)) * ‖a - s‖ ^ 2 then
    Classical.choose h
  else
    s

lemma proxMap_min [FiniteDimensional ℝ E] {f : E → ℝ}
    (hf_diff : Differentiable ℝ f) (hf_conv : ConvexOn ℝ Set.univ f)
    {t : ℝ} (ht : 0 < t) (s a : E) :
    f (proxMap f t s) + (1 / (2 * t)) * ‖proxMap f t s - s‖ ^ 2 ≤
      f a + (1 / (2 * t)) * ‖a - s‖ ^ 2 := by
  classical
  have hex := exists_prox_min hf_diff hf_conv ht s
  unfold proxMap
  rw [dif_pos hex]
  exact Classical.choose_spec hex a

lemma proxMap_sub_norm_le [FiniteDimensional ℝ E] {f : E → ℝ}
    (hf_diff : Differentiable ℝ f) (hf_conv : ConvexOn ℝ Set.univ f)
    {t : ℝ} (ht : 0 < t) (s : E) :
    ‖proxMap f t s - s‖ ≤ 2 * t * ‖gradient f s‖ := by
  let a₀ := proxMap f t s
  have hmin : f a₀ + (1 / (2 * t)) * ‖a₀ - s‖ ^ 2 ≤ f s := by
    simpa [a₀] using proxMap_min hf_diff hf_conv ht s s
  have hsub := convex_gradient_subgradient hf_diff hf_conv s a₀
  have hcs : - (‖gradient f s‖ * ‖a₀ - s‖) ≤ inner ℝ (gradient f s) (a₀ - s) := by
    have h1 := abs_real_inner_le_norm (gradient f s) (a₀ - s)
    linarith [neg_abs_le (inner ℝ (gradient f s) (a₀ - s))]
  have h1 : (1 / (2 * t)) * ‖a₀ - s‖ ^ 2 ≤ ‖gradient f s‖ * ‖a₀ - s‖ := by linarith
  have h2 : ‖a₀ - s‖ ^ 2 ≤ (2 * t * ‖gradient f s‖) * ‖a₀ - s‖ := by
    have hmul := mul_le_mul_of_nonneg_left h1 (by positivity : (0 : ℝ) ≤ 2 * t)
    have h_lhs : (2 * t) * ((1 / (2 * t)) * ‖a₀ - s‖ ^ 2) = ‖a₀ - s‖ ^ 2 := by
      field_simp [ht.ne']
    linarith
  rcases eq_or_lt_of_le (norm_nonneg (a₀ - s)) with hzero | hpos
  · rw [← hzero]
    positivity
  · exact le_of_mul_le_mul_right (by simpa [sq] using h2) hpos

lemma proxMap_sub_eq [FiniteDimensional ℝ E] {f : E → ℝ}
    (hf_diff : Differentiable ℝ f) (hf_conv : ConvexOn ℝ Set.univ f)
    {t : ℝ} (ht : 0 < t) (s : E) :
    proxMap f t s - s = - (t • gradient f (proxMap f t s)) := by
  let a₀ := proxMap f t s
  have h_orth : ∀ w : E, inner ℝ (gradient f a₀ + (1 / t) • (a₀ - s)) w = 0 := by
    intro w
    let ψ : ℝ → ℝ := fun θ => f (a₀ + θ • w) + (1 / (2 * t)) * ‖(a₀ + θ • w) - s‖ ^ 2
    have hmin_all : ∀ θ : ℝ, ψ 0 ≤ ψ θ := by
      intro θ
      simpa [ψ, a₀] using proxMap_min hf_diff hf_conv ht s (a₀ + θ • w)
    have hloc : IsLocalMin ψ 0 := Filter.Eventually.of_forall hmin_all
    have hψ_eq : ψ = fun θ => f (a₀ + θ • w) +
        (1 / (2 * t)) * (‖a₀ - s‖ ^ 2 + 2 * inner ℝ (a₀ - s) w * θ + ‖w‖ ^ 2 * θ ^ 2) := by
      ext θ
      dsimp [ψ]
      congr 2
      have hsub_eq : (a₀ + θ • w) - s = (a₀ - s) + θ • w := by abel
      rw [hsub_eq, norm_add_sq_real, inner_smul_right, norm_smul, Real.norm_eq_abs,
        mul_pow, sq_abs]
      ring
    have h_ray : HasDerivAt (fun θ : ℝ => a₀ + θ • w) w 0 := by
      simpa using ((hasDerivAt_id (0 : ℝ)).smul_const w).const_add a₀
    have hf_d : HasDerivAt (fun θ : ℝ => f (a₀ + θ • w)) (inner ℝ (gradient f a₀) w) 0 := by
      have ha0 : HasFDerivAt f ((InnerProductSpace.toDual ℝ E) (gradient f a₀))
          (a₀ + (0 : ℝ) • w) := by
        simpa using hasGradientAt_fderiv hf_diff a₀
      have hcomp := ha0.comp_hasDerivAt 0 h_ray
      simpa [InnerProductSpace.toDual_apply] using hcomp
    have hq_d : HasDerivAt
        (fun θ : ℝ => (1 / (2 * t)) *
          (‖a₀ - s‖ ^ 2 + 2 * inner ℝ (a₀ - s) w * θ + ‖w‖ ^ 2 * θ ^ 2))
        ((1 / t) * inner ℝ (a₀ - s) w) 0 := by
      have hraw := (((hasDerivAt_const 0 (‖a₀ - s‖ ^ 2)).add
        ((hasDerivAt_id 0).const_mul (2 * inner ℝ (a₀ - s) w))).add
        ((hasDerivAt_pow 2 (0 : ℝ)).const_mul (‖w‖ ^ 2))).const_mul (1 / (2 * t))
      convert hraw using 1
      field_simp [ht.ne']
      ring
    have hψ_d : HasDerivAt ψ (inner ℝ (gradient f a₀) w + (1 / t) * inner ℝ (a₀ - s) w) 0 := by
      rw [hψ_eq]
      exact hf_d.add hq_d
    have hzero := hloc.hasDerivAt_eq_zero hψ_d
    rw [inner_add_left, inner_smul_left]
    simpa using hzero
  have h_vec_zero : gradient f a₀ + (1 / t) • (a₀ - s) = 0 :=
    inner_self_eq_zero.mp (h_orth (gradient f a₀ + (1 / t) • (a₀ - s)))
  have h_smul : t • (gradient f a₀ + (1 / t) • (a₀ - s)) = 0 := by
    rw [h_vec_zero, smul_zero]
  rw [smul_add, smul_smul, mul_one_div_cancel ht.ne', one_smul] at h_smul
  exact eq_neg_of_add_eq_zero_right h_smul

lemma proxMap_lipschitz [FiniteDimensional ℝ E] {f : E → ℝ}
    (hf_diff : Differentiable ℝ f) (hf_conv : ConvexOn ℝ Set.univ f)
    {t : ℝ} (ht : 0 < t) :
    LipschitzWith 1 (proxMap f t) := by
  rw [lipschitzWith_iff_norm_sub_le]
  intro s₁ s₂
  let a₁ := proxMap f t s₁
  let a₂ := proxMap f t s₂
  have eq₁ : a₁ - s₁ = - (t • gradient f a₁) := proxMap_sub_eq hf_diff hf_conv ht s₁
  have eq₂ : a₂ - s₂ = - (t • gradient f a₂) := proxMap_sub_eq hf_diff hf_conv ht s₂
  have hdiff : (s₁ - s₂) - (a₁ - a₂) = t • (gradient f a₁ - gradient f a₂) := by
    have h : (a₁ - s₁) - (a₂ - s₂) = - (t • (gradient f a₁ - gradient f a₂)) := by
      rw [eq₁, eq₂, smul_sub]
      abel
    have h2 : (s₁ - s₂) - (a₁ - a₂) = - ((a₁ - s₁) - (a₂ - s₂)) := by abel
    rw [h2, h, neg_neg]
  have hmono := gradient_monotone hf_diff hf_conv a₁ a₂
  have h_nonneg : 0 ≤ inner ℝ ((s₁ - s₂) - (a₁ - a₂)) (a₁ - a₂) := by
    rw [hdiff, inner_smul_left]
    simpa using mul_nonneg ht.le hmono
  rw [inner_sub_left, real_inner_self_eq_norm_sq] at h_nonneg
  have h_sq : ‖a₁ - a₂‖ ^ 2 ≤ ‖s₁ - s₂‖ * ‖a₁ - a₂‖ :=
    le_trans (by linarith) (real_inner_le_norm (s₁ - s₂) (a₁ - a₂))
  rcases eq_or_lt_of_le (norm_nonneg (a₁ - a₂)) with hzero | hpos
  · change ‖a₁ - a₂‖ ≤ (1 : NNReal) * ‖s₁ - s₂‖
    rw [← hzero]
    positivity
  · have hle : ‖a₁ - a₂‖ ≤ ‖s₁ - s₂‖ :=
      le_of_mul_le_mul_right (by simpa [sq] using h_sq) hpos
    simpa using hle

lemma proxMap_step_error [FiniteDimensional ℝ E] {f : E → ℝ} {L : NNReal}
    (hf_diff : Differentiable ℝ f) (hf_conv : ConvexOn ℝ Set.univ f)
    (hf_lip : LipschitzWith L (gradient f))
    {t : ℝ} (ht : 0 < t) (s : E) :
    ‖(proxMap f t s - s) + t • gradient f s‖ ≤ 2 * (L : ℝ) * ‖gradient f s‖ * t ^ 2 := by
  have heq : (proxMap f t s - s) + t • gradient f s =
      t • (gradient f s - gradient f (proxMap f t s)) := by
    rw [proxMap_sub_eq hf_diff hf_conv ht s, smul_sub]
    abel
  have hlip_bound : ‖gradient f s - gradient f (proxMap f t s)‖ ≤
      (L : ℝ) * ‖proxMap f t s - s‖ := by
    rw [norm_sub_rev (proxMap f t s) s]
    exact hf_lip.norm_sub_le s (proxMap f t s)
  have hdisp := proxMap_sub_norm_le hf_diff hf_conv ht s
  rw [heq, norm_smul, Real.norm_eq_abs, abs_of_pos ht]
  calc t * ‖gradient f s - gradient f (proxMap f t s)‖
      ≤ t * ((L : ℝ) * ‖proxMap f t s - s‖) :=
        mul_le_mul_of_nonneg_left hlip_bound ht.le
    _ ≤ t * ((L : ℝ) * (2 * t * ‖gradient f s‖)) :=
        mul_le_mul_of_nonneg_left
          (mul_le_mul_of_nonneg_left hdisp (NNReal.coe_nonneg L)) ht.le
    _ = 2 * (L : ℝ) * ‖gradient f s‖ * t ^ 2 := by ring

end Proximal

end UL.Proof_lem_A_4

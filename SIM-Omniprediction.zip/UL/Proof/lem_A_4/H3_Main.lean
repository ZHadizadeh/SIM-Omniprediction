import UL.Stmt.lem_A_4
import UL.Stmt.lem_A_3
import UL.Proof.lem_A_4.H1_SimplexFit
import UL.Proof.lem_A_4.H2_Proximal
set_option autoImplicit false

namespace UL.Proof_lem_A_4

open MeasureTheory Filter

lemma fit_vi_quotient {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {K : ℕ} {B : ℝ} {S : Ω → ZeroSumSubspace K} {Y : Ω → Fin K}
    (hS_meas : Measurable S) (hY_meas : Measurable Y)
    {ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hProfile : IsLipschitzLSFitProfile μ B S Y ρ)
    {ρ' : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hρ' : ρ' ∈ LipschitzSimplexMaps K B) {t : ℝ} (ht : 0 < t) :
    0 ≤ ∫ ω, inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω)
      (((1 : ℝ) / t) • (ρ' (S ω) - ρ (S ω))) ∂μ := by
  have hvi := fit_vi hS_meas hY_meas hProfile hρ'
  have hmul : 0 ≤ ((1 : ℝ) / t) *
      ∫ ω, inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω) (ρ' (S ω) - ρ (S ω)) ∂μ :=
    mul_nonneg (by positivity) hvi
  rw [← integral_const_mul] at hmul
  simpa only [inner_smul_right] using hmul

section MeasurableCase

universe u v

lemma part1_mean_zero (h_lem_A_3 : S_lem_A_3.{u})
    {Ω : Type u} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    {K : ℕ} (hK : 2 ≤ K) {B : ℝ} (hB : 0 < B)
    {S : Ω → ZeroSumSubspace K} {Y : Ω → Fin K}
    (hS_meas : Measurable S) (hY_meas : Measurable Y)
    {ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hProfile : IsLipschitzLSFitProfile μ B S Y ρ) :
    ∫ ω, fitResidual (fun ω => ρ (S ω)) Y ω ∂μ = 0 := by
  haveI : (nhdsWithin (0 : ℝ) (Set.Ioi 0)).NeBot := nhdsWithin_Ioi_neBot (le_refl 0)
  have hK1 : 1 ≤ K := by omega
  let P : Ω → EuclideanSpace ℝ (Fin K) := fun ω => ρ (S ω)
  let ξ : Ω → EuclideanSpace ℝ (Fin K) := fitResidual P Y
  have hFit : IsLipschitzLSFit μ B S Y P := ⟨ρ, hProfile, rfl⟩
  have hA3 := (h_lem_A_3 Ω μ K hK B hB S Y hS_meas hY_meas P hFit).2
  have hP_meas : Measurable P := hProfile.2.1.2.1.continuous.measurable.comp hS_meas
  have hr_meas : Measurable ξ := hP_meas.sub (oneHotLabel_measurable hY_meas)
  have hr_int : Integrable ξ μ :=
    integrable_of_aestronglyMeasurable_bounded hr_meas.aestronglyMeasurable 2
      (fitResidual_norm_le_two Y (fun ω => hProfile.2.1.2.2 (S ω)))
  have h_nonneg : ∀ v₀ : ZeroSumSubspace K,
      0 ≤ inner ℝ (∫ ω, ξ ω ∂μ) (v₀ : EuclideanSpace ℝ (Fin K)) := by
    intro v₀
    have h_tendsto := (hA3 (fun _ => v₀) (integrable_const v₀)).2
    have h_ev : ∀ᶠ t in nhdsWithin (0 : ℝ) (Set.Ioi 0),
        0 ≤ ∫ ω, inner ℝ (ξ ω)
          (((1 : ℝ) / t) • (projSimplex (P ω + t • (v₀ : EuclideanSpace ℝ (Fin K))) - P ω)) ∂μ := by
      filter_upwards [self_mem_nhdsWithin] with t ht
      have ht_pos : 0 < t := ht
      let ρ'_t : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) :=
        fun s => projSimplex (ρ s + t • (v₀ : EuclideanSpace ℝ (Fin K)))
      have hρ'_mem : ρ'_t ∈ LipschitzSimplexMaps K B := by
        refine ⟨hB.le, ?_, fun s => projSimplex_mem hK1 _⟩
        rw [lipschitzWith_iff_norm_sub_le]
        intro s₁ s₂
        calc ‖ρ'_t s₁ - ρ'_t s₂‖
            ≤ (1 : NNReal) * ‖(ρ s₁ + t • (v₀ : EuclideanSpace ℝ (Fin K))) -
                (ρ s₂ + t • (v₀ : EuclideanSpace ℝ (Fin K)))‖ :=
              (projSimplex_lipschitz hK1).norm_sub_le _ _
          _ = ‖ρ s₁ - ρ s₂‖ := by simp [add_sub_add_right_eq_sub]
          _ ≤ ↑(Real.toNNReal B) * ‖s₁ - s₂‖ := hProfile.2.1.2.1.norm_sub_le s₁ s₂
      exact fit_vi_quotient hS_meas hY_meas hProfile hρ'_mem ht_pos
    have h_int_ge : 0 ≤ ∫ ω, inner ℝ (ξ ω) (v₀ : EuclideanSpace ℝ (Fin K)) ∂μ :=
      ge_of_tendsto h_tendsto h_ev
    have h_comm : ∫ ω, inner ℝ (ξ ω) (v₀ : EuclideanSpace ℝ (Fin K)) ∂μ =
        inner ℝ (∫ ω, ξ ω ∂μ) (v₀ : EuclideanSpace ℝ (Fin K)) := by
      calc ∫ ω, inner ℝ (ξ ω) (v₀ : EuclideanSpace ℝ (Fin K)) ∂μ
          = ∫ ω, (innerSL ℝ (v₀ : EuclideanSpace ℝ (Fin K))) (ξ ω) ∂μ := by
              refine integral_congr_ae (Eventually.of_forall (fun ω => ?_))
              simp [real_inner_comm]
        _ = (innerSL ℝ (v₀ : EuclideanSpace ℝ (Fin K))) (∫ ω, ξ ω ∂μ) :=
              (innerSL ℝ (v₀ : EuclideanSpace ℝ (Fin K))).integral_comp_comm hr_int
        _ = inner ℝ (∫ ω, ξ ω ∂μ) (v₀ : EuclideanSpace ℝ (Fin K)) := by
              simp [real_inner_comm]
    rwa [h_comm] at h_int_ge
  have h_zero_on_H : ∀ v₀ : ZeroSumSubspace K,
      inner ℝ (∫ ω, ξ ω ∂μ) (v₀ : EuclideanSpace ℝ (Fin K)) = 0 := by
    intro v₀
    have h1 := h_nonneg v₀
    have h2 := h_nonneg (-v₀)
    simp only [Submodule.coe_neg, inner_neg_right] at h2
    linarith
  have hm_mem : (∫ ω, ξ ω ∂μ) ∈ ZeroSumSubspace K := by
    rw [mem_zeroSumSubspace_iff]
    change (innerSL ℝ (onesVec K)) (∫ ω, ξ ω ∂μ) = 0
    rw [← (innerSL ℝ (onesVec K)).integral_comp_comm hr_int]
    have h_ae : ∀ ω, (innerSL ℝ (onesVec K)) (ξ ω) = 0 := by
      intro ω
      change inner ℝ (onesVec K) (P ω - oneHotLabel Y ω) = 0
      exact (mem_zeroSumSubspace_iff _).mp
        (sub_mem_zeroSumSubspace_of_mem_simplex (hProfile.2.1.2.2 (S ω))
          (oneHotLabel_mem_simplex Y ω))
    simp [h_ae]
  exact inner_self_eq_zero.mp (h_zero_on_H ⟨∫ ω, ξ ω ∂μ, hm_mem⟩)

lemma part2_smooth_test (h_lem_A_3 : S_lem_A_3.{u})
    {Ω : Type u} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    {K : ℕ} (hK : 2 ≤ K) {B : ℝ} (hB : 0 < B)
    {S : Ω → ZeroSumSubspace K} {Y : Ω → Fin K}
    (hS_meas : Measurable S) (hY_meas : Measurable Y)
    {ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hProfile : IsLipschitzLSFitProfile μ B S Y ρ)
    (f : ZeroSumSubspace K → ℝ) (hf_diff : Differentiable ℝ f)
    (hf_conv : ConvexOn ℝ Set.univ f) {L : NNReal} (hf_lip : LipschitzWith L (gradient f)) :
    ∫ ω, inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω)
      (↑(gradient f ((ZeroSumSubspace K).orthogonalProjection
        (ρ (S ω) - uniformVec K))) : EuclideanSpace ℝ (Fin K)) ∂μ ≤ 0 := by
  haveI : (nhdsWithin (0 : ℝ) (Set.Ioi 0)).NeBot := nhdsWithin_Ioi_neBot (le_refl 0)
  let P : Ω → EuclideanSpace ℝ (Fin K) := fun ω => ρ (S ω)
  let ξ : Ω → EuclideanSpace ℝ (Fin K) := fitResidual P Y
  let u : EuclideanSpace ℝ (Fin K) := uniformVec K
  let s_of : ZeroSumSubspace K → ZeroSumSubspace K :=
    fun x => (ZeroSumSubspace K).orthogonalProjection (ρ x - u)
  let P_H : Ω → ZeroSumSubspace K := fun ω => s_of (S ω)
  have hFit : IsLipschitzLSFit μ B S Y P := ⟨ρ, hProfile, rfl⟩
  have hA3 := (h_lem_A_3 Ω μ K hK B hB S Y hS_meas hY_meas P hFit).2
  have hK1 : 1 ≤ K := by omega
  have hs_coe : ∀ x : ZeroSumSubspace K,
      (s_of x : EuclideanSpace ℝ (Fin K)) = ρ x - u :=
    fun x => orthProj_sub_uniformVec_coe hK1 (hProfile.2.1.2.2 x)
  have hPH_coe : ∀ ω : Ω, (P_H ω : EuclideanSpace ℝ (Fin K)) = P ω - u :=
    fun ω => hs_coe (S ω)
  have hu_add_PH : ∀ ω : Ω, u + (P_H ω : EuclideanSpace ℝ (Fin K)) = P ω := by
    intro ω
    rw [hPH_coe]
    abel
  have hPH_norm : ∀ ω : Ω, ‖P_H ω‖ ≤ 2 := by
    intro ω
    rw [Submodule.coe_norm, hPH_coe]
    calc ‖P ω - u‖ ≤ ‖P ω‖ + ‖u‖ := norm_sub_le _ _
      _ ≤ 1 + 1 := add_le_add (simplex_norm_le_one (hProfile.2.1.2.2 (S ω)))
          (simplex_norm_le_one (uniformVec_mem_simplex hK1))
      _ = 2 := by norm_num
  let G : ℝ := ‖gradient f 0‖ + 2 * (L : ℝ)
  have hG_nn : 0 ≤ G := by positivity
  have hgrad_bound : ∀ ω : Ω, ‖gradient f (P_H ω)‖ ≤ G := by
    intro ω
    calc ‖gradient f (P_H ω)‖
        = ‖gradient f 0 + (gradient f (P_H ω) - gradient f 0)‖ := by abel_nf
      _ ≤ ‖gradient f 0‖ + ‖gradient f (P_H ω) - gradient f 0‖ := norm_add_le _ _
      _ ≤ ‖gradient f 0‖ + (L : ℝ) * ‖P_H ω - 0‖ :=
          add_le_add le_rfl (hf_lip.norm_sub_le (P_H ω) 0)
      _ ≤ ‖gradient f 0‖ + (L : ℝ) * 2 := by
          rw [sub_zero]
          exact add_le_add le_rfl (mul_le_mul_of_nonneg_left (hPH_norm ω) (NNReal.coe_nonneg L))
      _ = G := by dsimp [G]; ring
  have hP_meas : Measurable P := hProfile.2.1.2.1.continuous.measurable.comp hS_meas
  have hr_meas : Measurable ξ := hP_meas.sub (oneHotLabel_measurable hY_meas)
  have hr_bound : ∀ ω, ‖ξ ω‖ ≤ 2 :=
    fitResidual_norm_le_two Y (fun ω => hProfile.2.1.2.2 (S ω))
  have hPH_meas : Measurable P_H :=
    (ZeroSumSubspace K).orthogonalProjection.continuous.measurable.comp
      (hP_meas.sub measurable_const)
  let v : Ω → ZeroSumSubspace K := fun ω => -gradient f (P_H ω)
  have hv_meas : Measurable v :=
    continuous_neg.measurable.comp (hf_lip.continuous.measurable.comp hPH_meas)
  have hv_int : Integrable v μ :=
    integrable_of_aestronglyMeasurable_bounded hv_meas.aestronglyMeasurable G
      (fun ω => by simpa [v] using hgrad_bound ω)
  let ρ'_t : ℝ → ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) :=
    fun t x => projSimplex (u + (↑(proxMap f t (s_of x)) : EuclideanSpace ℝ (Fin K)))
  let F_A : ℝ → ℝ := fun t =>
    ∫ ω, inner ℝ (ξ ω) (((1 : ℝ) / t) • (ρ'_t t (S ω) - P ω)) ∂μ
  let F_B : ℝ → ℝ := fun t =>
    ∫ ω, inner ℝ (ξ ω)
      (((1 : ℝ) / t) • (projSimplex (P ω + t • (v ω : EuclideanSpace ℝ (Fin K))) - P ω)) ∂μ
  have hρ'_mem : ∀ {t : ℝ}, 0 < t → ρ'_t t ∈ LipschitzSimplexMaps K B := by
    intro t ht
    refine ⟨hB.le, ?_, fun x => projSimplex_mem hK1 _⟩
    rw [lipschitzWith_iff_norm_sub_le]
    intro x₁ x₂
    calc ‖ρ'_t t x₁ - ρ'_t t x₂‖
        ≤ (1 : NNReal) * ‖(u + (↑(proxMap f t (s_of x₁)) : EuclideanSpace ℝ (Fin K))) -
            (u + (↑(proxMap f t (s_of x₂)) : EuclideanSpace ℝ (Fin K)))‖ :=
          (projSimplex_lipschitz hK1).norm_sub_le _ _
      _ = ‖proxMap f t (s_of x₁) - proxMap f t (s_of x₂)‖ := by
          simp only [NNReal.coe_one, one_mul, add_sub_add_left_eq_sub, ← Submodule.coe_sub,
            Submodule.coe_norm]
      _ ≤ (1 : NNReal) * ‖s_of x₁ - s_of x₂‖ :=
          (proxMap_lipschitz hf_diff hf_conv ht).norm_sub_le _ _
      _ = ‖ρ x₁ - ρ x₂‖ := by
          have hsn : ‖s_of x₁ - s_of x₂‖ =
              ‖(↑(s_of x₁ - s_of x₂) : EuclideanSpace ℝ (Fin K))‖ :=
            (Submodule.coe_norm (s_of x₁ - s_of x₂)).symm
          rw [NNReal.coe_one, one_mul, hsn, Submodule.coe_sub,
            hs_coe x₁, hs_coe x₂, sub_sub_sub_cancel_right]
      _ ≤ ↑(Real.toNNReal B) * ‖x₁ - x₂‖ := hProfile.2.1.2.1.norm_sub_le x₁ x₂
  have hFA_nonneg : ∀ᶠ t in nhdsWithin (0 : ℝ) (Set.Ioi 0), 0 ≤ F_A t := by
    filter_upwards [self_mem_nhdsWithin] with t ht
    exact fit_vi_quotient hS_meas hY_meas hProfile (hρ'_mem ht) ht
  have h_diff_bound : ∀ᶠ t in nhdsWithin (0 : ℝ) (Set.Ioi 0),
      ‖F_A t - F_B t‖ ≤ (4 * (L : ℝ) * G) * t := by
    filter_upwards [self_mem_nhdsWithin] with t ht
    have ht_pos : 0 < t := ht
    let intA : Ω → ℝ := fun ω => inner ℝ (ξ ω) (((1 : ℝ) / t) • (ρ'_t t (S ω) - P ω))
    let intB : Ω → ℝ := fun ω => inner ℝ (ξ ω)
      (((1 : ℝ) / t) • (projSimplex (P ω + t • (v ω : EuclideanSpace ℝ (Fin K))) - P ω))
    have hIntA : Integrable intA μ := by
      have hQ_meas : Measurable (fun ω => ρ'_t t (S ω)) :=
        (hρ'_mem ht_pos).2.1.continuous.measurable.comp hS_meas
      have hm : Measurable intA :=
        hr_meas.inner ((hQ_meas.sub hP_meas).const_smul ((1 : ℝ) / t))
      refine integrable_of_aestronglyMeasurable_bounded hm.aestronglyMeasurable (4 / t) (fun ω => ?_)
      rw [Real.norm_eq_abs]
      have hdiff_le : ‖ρ'_t t (S ω) - P ω‖ ≤ 2 := by
        calc ‖ρ'_t t (S ω) - P ω‖ ≤ ‖ρ'_t t (S ω)‖ + ‖P ω‖ := norm_sub_le _ _
          _ ≤ 1 + 1 := add_le_add (simplex_norm_le_one (projSimplex_mem hK1 _))
              (simplex_norm_le_one (hProfile.2.1.2.2 (S ω)))
          _ = 2 := by norm_num
      calc |inner ℝ (ξ ω) (((1 : ℝ) / t) • (ρ'_t t (S ω) - P ω))|
          ≤ ‖ξ ω‖ * ‖((1 : ℝ) / t) • (ρ'_t t (S ω) - P ω)‖ := abs_real_inner_le_norm _ _
        _ = ‖ξ ω‖ * ((1 / t) * ‖ρ'_t t (S ω) - P ω‖) := by
            rw [norm_smul, Real.norm_eq_abs, abs_of_pos (by positivity)]
        _ ≤ 2 * ((1 / t) * 2) :=
            mul_le_mul (hr_bound ω)
              (mul_le_mul_of_nonneg_left hdiff_le (by positivity))
              (by positivity) (by norm_num)
        _ = 4 / t := by ring
    have hIntB : Integrable intB μ := by
      have hv_coe_meas : Measurable (fun ω => (v ω : EuclideanSpace ℝ (Fin K))) :=
        (ZeroSumSubspace K).subtypeL.continuous.measurable.comp hv_meas
      have hQ_meas : Measurable
          (fun ω => projSimplex (P ω + t • (v ω : EuclideanSpace ℝ (Fin K)))) :=
        (projSimplex_lipschitz hK1).continuous.measurable.comp
          (hP_meas.add (hv_coe_meas.const_smul t))
      have hm : Measurable intB :=
        hr_meas.inner ((hQ_meas.sub hP_meas).const_smul ((1 : ℝ) / t))
      refine integrable_of_aestronglyMeasurable_bounded hm.aestronglyMeasurable (4 / t) (fun ω => ?_)
      rw [Real.norm_eq_abs]
      have hdiff_le : ‖projSimplex (P ω + t • (v ω : EuclideanSpace ℝ (Fin K))) - P ω‖ ≤ 2 := by
        calc ‖projSimplex (P ω + t • (v ω : EuclideanSpace ℝ (Fin K))) - P ω‖
            ≤ ‖projSimplex (P ω + t • (v ω : EuclideanSpace ℝ (Fin K)))‖ + ‖P ω‖ := norm_sub_le _ _
          _ ≤ 1 + 1 := add_le_add (simplex_norm_le_one (projSimplex_mem hK1 _))
              (simplex_norm_le_one (hProfile.2.1.2.2 (S ω)))
          _ = 2 := by norm_num
      calc |inner ℝ (ξ ω) (((1 : ℝ) / t) •
              (projSimplex (P ω + t • (v ω : EuclideanSpace ℝ (Fin K))) - P ω))|
          ≤ ‖ξ ω‖ * ‖((1 : ℝ) / t) •
              (projSimplex (P ω + t • (v ω : EuclideanSpace ℝ (Fin K))) - P ω)‖ :=
            abs_real_inner_le_norm _ _
        _ = ‖ξ ω‖ * ((1 / t) *
              ‖projSimplex (P ω + t • (v ω : EuclideanSpace ℝ (Fin K))) - P ω‖) := by
            rw [norm_smul, Real.norm_eq_abs, abs_of_pos (by positivity)]
        _ ≤ 2 * ((1 / t) * 2) :=
            mul_le_mul (hr_bound ω)
              (mul_le_mul_of_nonneg_left hdiff_le (by positivity))
              (by positivity) (by norm_num)
        _ = 4 / t := by ring
    have h_pt_bound : ∀ ω : Ω, ‖intA ω - intB ω‖ ≤ (4 * (L : ℝ) * G) * t := by
      intro ω
      have h_inner_diff : intA ω - intB ω = inner ℝ (ξ ω)
          (((1 : ℝ) / t) •
            (ρ'_t t (S ω) - projSimplex (P ω + t • (v ω : EuclideanSpace ℝ (Fin K))))) := by
        dsimp [intA, intB]
        rw [← inner_sub_right, ← smul_sub, sub_sub_sub_cancel_right]
      have h_proj_diff : ‖ρ'_t t (S ω) -
          projSimplex (P ω + t • (v ω : EuclideanSpace ℝ (Fin K)))‖ ≤
          2 * (L : ℝ) * G * t ^ 2 := by
        have harg : (u + (↑(proxMap f t (P_H ω)) : EuclideanSpace ℝ (Fin K))) -
            (P ω + t • (v ω : EuclideanSpace ℝ (Fin K))) =
            (↑((proxMap f t (P_H ω) - P_H ω) + t • gradient f (P_H ω)) :
              EuclideanSpace ℝ (Fin K)) := by
          rw [← hu_add_PH ω]
          dsimp [v]
          simp only [Submodule.coe_sub, Submodule.coe_smul_of_tower,
            Submodule.coe_neg, smul_neg]
          abel
        calc ‖ρ'_t t (S ω) - projSimplex (P ω + t • (v ω : EuclideanSpace ℝ (Fin K)))‖
            ≤ (1 : NNReal) * ‖(u + (↑(proxMap f t (P_H ω)) : EuclideanSpace ℝ (Fin K))) -
                (P ω + t • (v ω : EuclideanSpace ℝ (Fin K)))‖ :=
              (projSimplex_lipschitz hK1).norm_sub_le _ _
          _ = ‖(proxMap f t (P_H ω) - P_H ω) + t • gradient f (P_H ω)‖ := by
              rw [NNReal.coe_one, one_mul, harg, Submodule.coe_norm]
          _ ≤ 2 * (L : ℝ) * ‖gradient f (P_H ω)‖ * t ^ 2 :=
              proxMap_step_error hf_diff hf_conv hf_lip ht_pos (P_H ω)
          _ ≤ 2 * (L : ℝ) * G * t ^ 2 := by
              have h1 : 2 * (L : ℝ) * ‖gradient f (P_H ω)‖ ≤ 2 * (L : ℝ) * G :=
                mul_le_mul_of_nonneg_left (hgrad_bound ω) (by positivity)
              exact mul_le_mul_of_nonneg_right h1 (sq_nonneg t)
      rw [h_inner_diff, Real.norm_eq_abs]
      calc |inner ℝ (ξ ω) (((1 : ℝ) / t) •
              (ρ'_t t (S ω) - projSimplex (P ω + t • (v ω : EuclideanSpace ℝ (Fin K)))))|
          ≤ ‖ξ ω‖ * ‖((1 : ℝ) / t) •
              (ρ'_t t (S ω) - projSimplex (P ω + t • (v ω : EuclideanSpace ℝ (Fin K))))‖ :=
            abs_real_inner_le_norm _ _
        _ = ‖ξ ω‖ * ((1 / t) *
              ‖ρ'_t t (S ω) - projSimplex (P ω + t • (v ω : EuclideanSpace ℝ (Fin K)))‖) := by
            rw [norm_smul, Real.norm_eq_abs, abs_of_pos (by positivity)]
        _ ≤ 2 * ((1 / t) * (2 * (L : ℝ) * G * t ^ 2)) :=
            mul_le_mul (hr_bound ω)
              (mul_le_mul_of_nonneg_left h_proj_diff (by positivity))
              (by positivity) (by norm_num)
        _ = (4 * (L : ℝ) * G) * t := by
            field_simp [ht_pos.ne']
            ring
    have h_sub_int : F_A t - F_B t = ∫ ω, (intA ω - intB ω) ∂μ :=
      (integral_sub hIntA hIntB).symm
    rw [h_sub_int]
    calc ‖∫ ω, (intA ω - intB ω) ∂μ‖
        ≤ ((4 * (L : ℝ) * G) * t) * μ.real Set.univ :=
          norm_integral_le_of_norm_le_const (Eventually.of_forall h_pt_bound)
      _ = (4 * (L : ℝ) * G) * t := by simp
  have h_zero_lim : Tendsto (fun t : ℝ => (4 * (L : ℝ) * G) * t)
      (nhdsWithin 0 (Set.Ioi 0)) (nhds 0) := by
    have hc : Continuous (fun t : ℝ => (4 * (L : ℝ) * G) * t) :=
      continuous_const.mul continuous_id
    simpa using (hc.tendsto 0).mono_left nhdsWithin_le_nhds
  have h_diff_tendsto : Tendsto (fun t => F_A t - F_B t)
      (nhdsWithin 0 (Set.Ioi 0)) (nhds 0) :=
    squeeze_zero_norm' h_diff_bound h_zero_lim
  have hFB_tendsto : Tendsto F_B (nhdsWithin 0 (Set.Ioi 0))
      (nhds (∫ ω, inner ℝ (ξ ω) (v ω : EuclideanSpace ℝ (Fin K)) ∂μ)) :=
    (hA3 v hv_int).2
  have hFA_tendsto : Tendsto F_A (nhdsWithin 0 (Set.Ioi 0))
      (nhds (∫ ω, inner ℝ (ξ ω) (v ω : EuclideanSpace ℝ (Fin K)) ∂μ)) := by
    have hsum := h_diff_tendsto.add hFB_tendsto
    rw [zero_add] at hsum
    exact hsum.congr (fun t => sub_add_cancel (F_A t) (F_B t))
  have h_ge : 0 ≤ ∫ ω, inner ℝ (ξ ω) (v ω : EuclideanSpace ℝ (Fin K)) ∂μ :=
    ge_of_tendsto hFA_tendsto hFA_nonneg
  have h_neg_eq : (∫ ω, inner ℝ (ξ ω) (v ω : EuclideanSpace ℝ (Fin K)) ∂μ) =
      -∫ ω, inner ℝ (ξ ω)
        (↑(gradient f (P_H ω)) : EuclideanSpace ℝ (Fin K)) ∂μ := by
    have hpt : (fun ω => inner ℝ (ξ ω) (v ω : EuclideanSpace ℝ (Fin K))) =
        fun ω => -inner ℝ (ξ ω) (↑(gradient f (P_H ω)) : EuclideanSpace ℝ (Fin K)) := by
      ext ω
      simp [v, inner_neg_right]
    rw [hpt, integral_neg]
  linarith

lemma part3_own_score (h_lem_A_3 : S_lem_A_3.{u})
    {Ω : Type u} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    {K : ℕ} (hK : 2 ≤ K) {B : ℝ} (hB : 0 < B)
    {S : Ω → ZeroSumSubspace K} {Y : Ω → Fin K}
    (hS_meas : Measurable S) (hS_int : Integrable S μ) (hY_meas : Measurable Y)
    {ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hProfile : IsLipschitzLSFitProfile μ B S Y ρ) :
    B * ∫ ω, inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω)
        (S ω : EuclideanSpace ℝ (Fin K)) ∂μ ≥
      ∫ ω, inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω)
        (ρ (S ω) - uniformVec K) ∂μ := by
  haveI : (nhdsWithin (0 : ℝ) (Set.Ioi 0)).NeBot := nhdsWithin_Ioi_neBot (le_refl 0)
  let P : Ω → EuclideanSpace ℝ (Fin K) := fun ω => ρ (S ω)
  let ξ : Ω → EuclideanSpace ℝ (Fin K) := fitResidual P Y
  let u : EuclideanSpace ℝ (Fin K) := uniformVec K
  let P_H : Ω → ZeroSumSubspace K :=
    fun ω => (ZeroSumSubspace K).orthogonalProjection (P ω - u)
  have hFit : IsLipschitzLSFit μ B S Y P := ⟨ρ, hProfile, rfl⟩
  have hA3 := (h_lem_A_3 Ω μ K hK B hB S Y hS_meas hY_meas P hFit).2
  have hK1 : 1 ≤ K := by omega
  have hPH_coe : ∀ ω : Ω, (P_H ω : EuclideanSpace ℝ (Fin K)) = P ω - u :=
    fun ω => orthProj_sub_uniformVec_coe hK1 (hProfile.2.1.2.2 (S ω))
  have hP_meas : Measurable P := hProfile.2.1.2.1.continuous.measurable.comp hS_meas
  have hr_meas : Measurable ξ := hP_meas.sub (oneHotLabel_measurable hY_meas)
  have hr_bound : ∀ ω, ‖ξ ω‖ ≤ 2 :=
    fitResidual_norm_le_two Y (fun ω => hProfile.2.1.2.2 (S ω))
  have hPH_meas : Measurable P_H :=
    (ZeroSumSubspace K).orthogonalProjection.continuous.measurable.comp
      (hP_meas.sub measurable_const)
  have hPu_bound : ∀ ω : Ω, ‖P ω - u‖ ≤ 2 := by
    intro ω
    calc ‖P ω - u‖ ≤ ‖P ω‖ + ‖u‖ := norm_sub_le _ _
      _ ≤ 1 + 1 := add_le_add (simplex_norm_le_one (hProfile.2.1.2.2 (S ω)))
          (simplex_norm_le_one (uniformVec_mem_simplex hK1))
      _ = 2 := by norm_num
  have hPH_int : Integrable P_H μ :=
    integrable_of_aestronglyMeasurable_bounded hPH_meas.aestronglyMeasurable 2
      (fun ω => by rw [Submodule.coe_norm, hPH_coe]; exact hPu_bound ω)
  let v : Ω → ZeroSumSubspace K := fun ω => B • S ω - P_H ω
  have hv_int : Integrable v μ := (hS_int.smul B).sub hPH_int
  have hv_coe : ∀ ω : Ω,
      (v ω : EuclideanSpace ℝ (Fin K)) = B • (S ω : EuclideanSpace ℝ (Fin K)) - (P ω - u) := by
    intro ω
    simp [v, hPH_coe]
  have h_ev : ∀ᶠ t in nhdsWithin (0 : ℝ) (Set.Ioi 0),
      0 ≤ ∫ ω, inner ℝ (ξ ω)
        (((1 : ℝ) / t) • (projSimplex (P ω + t • (v ω : EuclideanSpace ℝ (Fin K))) - P ω)) ∂μ := by
    have hIoo : Set.Ioo (0 : ℝ) 1 ∈ nhdsWithin (0 : ℝ) (Set.Ioi 0) :=
      mem_nhdsWithin.mpr ⟨Set.Iio 1, isOpen_Iio, Set.mem_Iio.mpr zero_lt_one,
        fun t ht => ⟨ht.2, ht.1⟩⟩
    filter_upwards [hIoo] with t ht
    have ht0 : 0 < t := ht.1
    have ht1 : t ≤ 1 := ht.2.le
    let ρ'_t : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K) :=
      fun x => projSimplex (u + (1 - t) • (ρ x - u) + t • (B • (x : EuclideanSpace ℝ (Fin K))))
    have hρ'_mem : ρ'_t ∈ LipschitzSimplexMaps K B := by
      refine ⟨hB.le, ?_, fun x => projSimplex_mem hK1 _⟩
      rw [lipschitzWith_iff_norm_sub_le]
      intro x₁ x₂
      have hB_coe : (↑(Real.toNNReal B) : ℝ) = B := Real.coe_toNNReal B hB.le
      have h1 := hProfile.2.1.2.1.norm_sub_le x₁ x₂
      rw [hB_coe] at h1 ⊢
      have hlin : (u + (1 - t) • (ρ x₁ - u) + t • (B • (x₁ : EuclideanSpace ℝ (Fin K)))) -
          (u + (1 - t) • (ρ x₂ - u) + t • (B • (x₂ : EuclideanSpace ℝ (Fin K)))) =
          (1 - t) • (ρ x₁ - ρ x₂) + (t * B) • ((x₁ : EuclideanSpace ℝ (Fin K)) - ↑x₂) := by
        simp only [smul_smul, smul_sub]
        abel
      calc ‖ρ'_t x₁ - ρ'_t x₂‖
          ≤ (1 : NNReal) *
              ‖(u + (1 - t) • (ρ x₁ - u) + t • (B • (x₁ : EuclideanSpace ℝ (Fin K)))) -
               (u + (1 - t) • (ρ x₂ - u) + t • (B • (x₂ : EuclideanSpace ℝ (Fin K))))‖ :=
            (projSimplex_lipschitz hK1).norm_sub_le _ _
        _ = ‖(1 - t) • (ρ x₁ - ρ x₂) + (t * B) • ((x₁ : EuclideanSpace ℝ (Fin K)) - ↑x₂)‖ := by
            rw [NNReal.coe_one, one_mul, hlin]
        _ ≤ ‖(1 - t) • (ρ x₁ - ρ x₂)‖ + ‖(t * B) • ((x₁ : EuclideanSpace ℝ (Fin K)) - ↑x₂)‖ :=
            norm_add_le _ _
        _ = (1 - t) * ‖ρ x₁ - ρ x₂‖ + (t * B) * ‖x₁ - x₂‖ := by
            rw [norm_smul, norm_smul, Real.norm_eq_abs, Real.norm_eq_abs,
              abs_of_nonneg (by linarith), abs_of_nonneg (by positivity),
              ← Submodule.coe_sub, Submodule.coe_norm]
        _ ≤ (1 - t) * (B * ‖x₁ - x₂‖) + (t * B) * ‖x₁ - x₂‖ :=
            add_le_add (mul_le_mul_of_nonneg_left h1 (by linarith)) le_rfl
        _ = B * ‖x₁ - x₂‖ := by ring
    have h_eq_pt : ∀ ω : Ω,
        ρ'_t (S ω) = projSimplex (P ω + t • (v ω : EuclideanSpace ℝ (Fin K))) := by
      intro ω
      have h_arg : u + (1 - t) • (P ω - u) + t • (B • (S ω : EuclideanSpace ℝ (Fin K))) =
          P ω + t • (v ω : EuclideanSpace ℝ (Fin K)) := by
        simp only [hv_coe ω, sub_smul, one_smul, smul_sub]
        abel
      exact congrArg projSimplex h_arg
    have hq := fit_vi_quotient hS_meas hY_meas hProfile hρ'_mem ht0
    simpa only [h_eq_pt] using hq
  have h_ge : 0 ≤ ∫ ω, inner ℝ (ξ ω) (v ω : EuclideanSpace ℝ (Fin K)) ∂μ :=
    ge_of_tendsto (hA3 v hv_int).2 h_ev
  have hInt_rS : Integrable (fun ω => inner ℝ (ξ ω) (S ω : EuclideanSpace ℝ (Fin K))) μ := by
    have hS_coe_meas : Measurable (fun ω => (S ω : EuclideanSpace ℝ (Fin K))) :=
      (ZeroSumSubspace K).subtypeL.continuous.measurable.comp hS_meas
    refine (hS_int.norm.const_mul 2).mono'
      (hr_meas.inner hS_coe_meas).aestronglyMeasurable (Eventually.of_forall (fun ω => ?_))
    rw [Real.norm_eq_abs]
    calc |inner ℝ (ξ ω) (S ω : EuclideanSpace ℝ (Fin K))|
        ≤ ‖ξ ω‖ * ‖(S ω : EuclideanSpace ℝ (Fin K))‖ := abs_real_inner_le_norm _ _
      _ = ‖ξ ω‖ * ‖S ω‖ := by rw [Submodule.coe_norm]
      _ ≤ 2 * ‖S ω‖ := mul_le_mul_of_nonneg_right (hr_bound ω) (norm_nonneg _)
  have hInt_rPu : Integrable (fun ω => inner ℝ (ξ ω) (P ω - u)) μ := by
    refine integrable_of_aestronglyMeasurable_bounded
      (hr_meas.inner (hP_meas.sub measurable_const)).aestronglyMeasurable 4 (fun ω => ?_)
    rw [Real.norm_eq_abs]
    calc |inner ℝ (ξ ω) (P ω - u)|
        ≤ ‖ξ ω‖ * ‖P ω - u‖ := abs_real_inner_le_norm _ _
      _ ≤ 2 * 2 := mul_le_mul (hr_bound ω) (hPu_bound ω) (norm_nonneg _) (by norm_num)
      _ = 4 := by norm_num
  have h_split : (∫ ω, inner ℝ (ξ ω) (v ω : EuclideanSpace ℝ (Fin K)) ∂μ) =
      B * (∫ ω, inner ℝ (ξ ω) (S ω : EuclideanSpace ℝ (Fin K)) ∂μ) -
        ∫ ω, inner ℝ (ξ ω) (P ω - u) ∂μ := by
    have hpt : (fun ω => inner ℝ (ξ ω) (v ω : EuclideanSpace ℝ (Fin K))) =
        fun ω => B * inner ℝ (ξ ω) (S ω : EuclideanSpace ℝ (Fin K)) -
          inner ℝ (ξ ω) (P ω - u) := by
      ext ω
      rw [hv_coe ω, inner_sub_right, inner_smul_right]
    rw [hpt, integral_sub (hInt_rS.const_mul B) hInt_rPu, integral_const_mul]
  linarith

lemma prove_cross_universe (h_lem_A_3 : S_lem_A_3.{u})
    {Ω : Type v} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    {K : ℕ} (hK : 2 ≤ K) {B : ℝ} (hB : 0 < B)
    {S : Ω → ZeroSumSubspace K} {Y : Ω → Fin K}
    (hS_meas : Measurable S) (hS_int : Integrable S μ) (hY_meas : Measurable Y)
    {ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hProfile : IsLipschitzLSFitProfile μ B S Y ρ) :
    (∫ ω, fitResidual (fun ω => ρ (S ω)) Y ω ∂μ = 0) ∧
    (∀ (f : ZeroSumSubspace K → ℝ),
      Differentiable ℝ f →
      ConvexOn ℝ Set.univ f →
      (∃ L : NNReal, LipschitzWith L (gradient f)) →
      ∫ ω, inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω)
        (↑(gradient f ((ZeroSumSubspace K).orthogonalProjection
          (ρ (S ω) - uniformVec K))) : EuclideanSpace ℝ (Fin K)) ∂μ ≤ 0) ∧
    (B * ∫ ω, inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω)
        (S ω : EuclideanSpace ℝ (Fin K)) ∂μ ≥
      ∫ ω, inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω)
        (ρ (S ω) - uniformVec K) ∂μ) := by
  let Ω₁ : Type u := ULift.{u} (ZeroSumSubspace K × Fin K)
  letI mΩ₁ : MeasurableSpace Ω₁ := MeasurableSpace.comap ULift.down inferInstance
  let Φ : Ω → Ω₁ := fun ω => ULift.up (S ω, Y ω)
  have hdown_meas : @Measurable Ω₁ (ZeroSumSubspace K × Fin K) mΩ₁ _ ULift.down :=
    comap_measurable ULift.down
  have hΦ_meas : @Measurable Ω Ω₁ _ mΩ₁ Φ :=
    measurable_comap_iff.mpr (hS_meas.prodMk hY_meas)
  let μ₁ : @Measure Ω₁ mΩ₁ := Measure.map Φ μ
  haveI : IsProbabilityMeasure μ₁ := Measure.isProbabilityMeasure_map hΦ_meas.aemeasurable
  let S₁ : Ω₁ → ZeroSumSubspace K := fun z => z.down.1
  let Y₁ : Ω₁ → Fin K := fun z => z.down.2
  have hS₁_meas : Measurable S₁ := measurable_fst.comp hdown_meas
  have hY₁_meas : Measurable Y₁ := measurable_snd.comp hdown_meas
  have hS₁_int : Integrable S₁ μ₁ :=
    (integrable_map_measure hS₁_meas.aestronglyMeasurable hΦ_meas.aemeasurable).mpr hS_int
  have hRisk_map : ∀ {ρ₁ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)},
      ρ₁ ∈ LipschitzSimplexMaps K B →
      lsFitRisk μ₁ S₁ Y₁ ρ₁ = lsFitRisk μ S Y ρ₁ := by
    intro ρ₁ hρ₁
    unfold lsFitRisk
    have hg_meas : Measurable (fun z : Ω₁ => ‖ρ₁ (S₁ z) - oneHotLabel Y₁ z‖ ^ 2) :=
      (((hρ₁.2.1.continuous.measurable.comp hS₁_meas).sub
        (oneHotLabel_measurable hY₁_meas)).norm).pow_const 2
    exact integral_map hΦ_meas.aemeasurable hg_meas.aestronglyMeasurable
  have hProfile₁ : IsLipschitzLSFitProfile μ₁ B S₁ Y₁ ρ := by
    refine ⟨hProfile.1, hProfile.2.1, fun ρ₁ hρ₁ => ?_⟩
    change lsFitRisk μ₁ S₁ Y₁ ρ ≤ lsFitRisk μ₁ S₁ Y₁ ρ₁
    rw [hRisk_map hProfile.2.1, hRisk_map hρ₁]
    exact hProfile.2.2 hρ₁
  have hr₁_meas : Measurable (fitResidual (fun z : Ω₁ => ρ (S₁ z)) Y₁) :=
    (hProfile.2.1.2.1.continuous.measurable.comp hS₁_meas).sub (oneHotLabel_measurable hY₁_meas)
  refine ⟨?_, ?_, ?_⟩
  · have hmap : (∫ z, fitResidual (fun z => ρ (S₁ z)) Y₁ z ∂μ₁) =
        ∫ ω, fitResidual (fun ω => ρ (S ω)) Y ω ∂μ :=
      integral_map hΦ_meas.aemeasurable hr₁_meas.aestronglyMeasurable
    rw [← hmap]
    exact part1_mean_zero h_lem_A_3 μ₁ hK hB hS₁_meas hY₁_meas hProfile₁
  · intro f hf_diff hf_conv ⟨L, hf_lip⟩
    have hg_meas : Measurable (fun z : Ω₁ =>
        inner ℝ (fitResidual (fun z => ρ (S₁ z)) Y₁ z)
          (↑(gradient f ((ZeroSumSubspace K).orthogonalProjection
            (ρ (S₁ z) - uniformVec K))) : EuclideanSpace ℝ (Fin K))) := by
      have hgrad_coe_meas : Measurable (fun z : Ω₁ =>
          (↑(gradient f ((ZeroSumSubspace K).orthogonalProjection
            (ρ (S₁ z) - uniformVec K))) : EuclideanSpace ℝ (Fin K))) :=
        (ZeroSumSubspace K).subtypeL.continuous.measurable.comp
          (hf_lip.continuous.measurable.comp
            ((ZeroSumSubspace K).orthogonalProjection.continuous.measurable.comp
              ((hProfile.2.1.2.1.continuous.measurable.comp hS₁_meas).sub measurable_const)))
      exact hr₁_meas.inner hgrad_coe_meas
    have hmap : (∫ z, inner ℝ (fitResidual (fun z => ρ (S₁ z)) Y₁ z)
        (↑(gradient f ((ZeroSumSubspace K).orthogonalProjection
          (ρ (S₁ z) - uniformVec K))) : EuclideanSpace ℝ (Fin K)) ∂μ₁) =
      ∫ ω, inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω)
        (↑(gradient f ((ZeroSumSubspace K).orthogonalProjection
          (ρ (S ω) - uniformVec K))) : EuclideanSpace ℝ (Fin K)) ∂μ :=
      integral_map hΦ_meas.aemeasurable hg_meas.aestronglyMeasurable
    rw [← hmap]
    exact part2_smooth_test h_lem_A_3 μ₁ hK hB hS₁_meas hY₁_meas hProfile₁ f hf_diff hf_conv hf_lip
  · have hg₁_meas : Measurable (fun z : Ω₁ =>
        inner ℝ (fitResidual (fun z => ρ (S₁ z)) Y₁ z)
          (S₁ z : EuclideanSpace ℝ (Fin K))) :=
      hr₁_meas.inner ((ZeroSumSubspace K).subtypeL.continuous.measurable.comp hS₁_meas)
    have hg₂_meas : Measurable (fun z : Ω₁ =>
        inner ℝ (fitResidual (fun z => ρ (S₁ z)) Y₁ z)
          (ρ (S₁ z) - uniformVec K)) :=
      hr₁_meas.inner ((hProfile.2.1.2.1.continuous.measurable.comp hS₁_meas).sub measurable_const)
    have hmap₁ : (∫ z, inner ℝ (fitResidual (fun z => ρ (S₁ z)) Y₁ z)
        (S₁ z : EuclideanSpace ℝ (Fin K)) ∂μ₁) =
      ∫ ω, inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω)
        (S ω : EuclideanSpace ℝ (Fin K)) ∂μ :=
      integral_map hΦ_meas.aemeasurable hg₁_meas.aestronglyMeasurable
    have hmap₂ : (∫ z, inner ℝ (fitResidual (fun z => ρ (S₁ z)) Y₁ z)
        (ρ (S₁ z) - uniformVec K) ∂μ₁) =
      ∫ ω, inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω)
        (ρ (S ω) - uniformVec K) ∂μ :=
      integral_map hΦ_meas.aemeasurable hg₂_meas.aestronglyMeasurable
    rw [← hmap₁, ← hmap₂]
    exact part3_own_score h_lem_A_3 μ₁ hK hB hS₁_meas hS₁_int hY₁_meas hProfile₁

end MeasurableCase

end UL.Proof_lem_A_4

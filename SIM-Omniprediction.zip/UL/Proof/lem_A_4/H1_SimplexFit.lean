import Mathlib
import UL.Def.def_2_1
import UL.Def.def_A_fit
set_option autoImplicit false

namespace UL.Proof_lem_A_4

open MeasureTheory

section SimplexGeometry

lemma sum_apply {K : ℕ} {α : Type*} (s : Finset α)
    (f : α → EuclideanSpace ℝ (Fin K)) (j : Fin K) :
    (∑ a ∈ s, f a) j = ∑ a ∈ s, f a j := by
  classical
  induction s using Finset.induction_on with
  | empty => rfl
  | @insert a s ha ih => simp [Finset.sum_insert ha, ih]

lemma inner_eq_sum {K : ℕ} (x y : EuclideanSpace ℝ (Fin K)) :
    inner ℝ x y = ∑ i : Fin K, x i * y i := by
  rw [PiLp.inner_apply]
  refine Finset.sum_congr rfl (fun i _ => ?_)
  simp [mul_comm]

lemma norm_sq_eq_sum {K : ℕ} (x : EuclideanSpace ℝ (Fin K)) :
    ‖x‖ ^ 2 = ∑ i : Fin K, (x i) ^ 2 := by
  rw [← real_inner_self_eq_norm_sq, inner_eq_sum]
  refine Finset.sum_congr rfl (fun i _ => ?_)
  ring

lemma onesVec_apply (K : ℕ) (j : Fin K) : onesVec K j = 1 := rfl

lemma inner_onesVec_eq_sum {K : ℕ} (x : EuclideanSpace ℝ (Fin K)) :
    inner ℝ (onesVec K) x = ∑ j : Fin K, x j := by
  rw [inner_eq_sum]
  simp [onesVec_apply]

lemma mem_zeroSumSubspace_iff {K : ℕ} (x : EuclideanSpace ℝ (Fin K)) :
    x ∈ ZeroSumSubspace K ↔ inner ℝ (onesVec K) x = 0 := by
  simp [ZeroSumSubspace, LinearMap.mem_ker]

lemma simplex_coord_le_one {K : ℕ} {q : EuclideanSpace ℝ (Fin K)}
    (hq : q ∈ Simplex K) (j : Fin K) : q j ≤ 1 := by
  rw [← hq.2]
  exact Finset.single_le_sum (fun i _ => hq.1 i) (Finset.mem_univ j)

lemma simplex_norm_le_one {K : ℕ} {q : EuclideanSpace ℝ (Fin K)} (hq : q ∈ Simplex K) :
    ‖q‖ ≤ 1 := by
  have hsq : ‖q‖ ^ 2 ≤ 1 := by
    rw [norm_sq_eq_sum, ← hq.2]
    refine Finset.sum_le_sum (fun j _ => ?_)
    have h0 := hq.1 j
    have h1 := simplex_coord_le_one hq j
    nlinarith
  have hnn : 0 ≤ ‖q‖ := norm_nonneg q
  nlinarith

lemma oneHotVec_mem_simplex {K : ℕ} (y : Fin K) : oneHotVec y ∈ Simplex K := by
  refine ⟨fun j => ?_, ?_⟩
  · simp only [oneHotVec, EuclideanSpace.single_apply]
    split_ifs <;> norm_num
  · simp [oneHotVec, EuclideanSpace.single_apply]

lemma oneHotLabel_mem_simplex {Ω : Type*} {K : ℕ} (Y : Ω → Fin K) (ω : Ω) :
    oneHotLabel Y ω ∈ Simplex K :=
  oneHotVec_mem_simplex (Y ω)

lemma uniformVec_mem_simplex {K : ℕ} (hK : 1 ≤ K) : uniformVec K ∈ Simplex K := by
  have hK_pos : (0 : ℝ) < (K : ℝ) := Nat.cast_pos.mpr (by omega)
  refine ⟨fun j => ?_, ?_⟩
  · change 0 ≤ ((1 : ℝ) / (K : ℝ)) * onesVec K j
    rw [onesVec_apply, mul_one]
    positivity
  · have h : ∑ j : Fin K, (uniformVec K) j = ∑ _j : Fin K, (1 : ℝ) / (K : ℝ) := by
      refine Finset.sum_congr rfl (fun j _ => ?_)
      change ((1 : ℝ) / (K : ℝ)) * onesVec K j = 1 / (K : ℝ)
      rw [onesVec_apply, mul_one]
    rw [h, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
    field_simp [hK_pos.ne']

lemma inner_onesVec_of_mem_simplex {K : ℕ} {q : EuclideanSpace ℝ (Fin K)}
    (hq : q ∈ Simplex K) : inner ℝ (onesVec K) q = 1 := by
  rw [inner_onesVec_eq_sum]
  exact hq.2

lemma sub_mem_zeroSumSubspace_of_mem_simplex {K : ℕ} {p q : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ Simplex K) (hq : q ∈ Simplex K) :
    p - q ∈ ZeroSumSubspace K := by
  rw [mem_zeroSumSubspace_iff, inner_sub_right,
    inner_onesVec_of_mem_simplex hp, inner_onesVec_of_mem_simplex hq, sub_self]

lemma orthProj_sub_uniformVec_coe {K : ℕ} (hK : 1 ≤ K) {p : EuclideanSpace ℝ (Fin K)}
    (hp : p ∈ Simplex K) :
    ((ZeroSumSubspace K).orthogonalProjection (p - uniformVec K) :
      EuclideanSpace ℝ (Fin K)) = p - uniformVec K := by
  have hmem : p - uniformVec K ∈ ZeroSumSubspace K :=
    sub_mem_zeroSumSubspace_of_mem_simplex hp (uniformVec_mem_simplex hK)
  rw [Submodule.orthogonalProjection_mem_subspace_eq_self ⟨p - uniformVec K, hmem⟩]

lemma simplex_convex (K : ℕ) : Convex ℝ (Simplex K) := by
  intro x hx y hy a b ha hb hab
  refine ⟨fun j => ?_, ?_⟩
  · change 0 ≤ a * x j + b * y j
    exact add_nonneg (mul_nonneg ha (hx.1 j)) (mul_nonneg hb (hy.1 j))
  · have h : ∑ j : Fin K, (a • x + b • y) j =
        a * (∑ j : Fin K, x j) + b * (∑ j : Fin K, y j) := by
      calc ∑ j : Fin K, (a • x + b • y) j
          = ∑ j : Fin K, (a * x j + b * y j) := rfl
        _ = (∑ j : Fin K, a * x j) + ∑ j : Fin K, b * y j := Finset.sum_add_distrib
        _ = a * (∑ j : Fin K, x j) + b * (∑ j : Fin K, y j) := by
              rw [← Finset.mul_sum, ← Finset.mul_sum]
    rw [h, hx.2, hy.2]
    linarith

lemma simplex_isCompact (K : ℕ) : IsCompact (Simplex K) := by
  rw [Metric.isCompact_iff_isClosed_bounded]
  constructor
  · have hEq : Simplex K =
        (⋂ j : Fin K, {q : EuclideanSpace ℝ (Fin K) | 0 ≤ q j}) ∩
        {q : EuclideanSpace ℝ (Fin K) | ∑ j : Fin K, q j = 1} := by
      ext q
      simp [Simplex]
    rw [hEq]
    refine IsClosed.inter ?_ ?_
    · refine isClosed_iInter (fun j => ?_)
      exact isClosed_le continuous_const (EuclideanSpace.proj j).continuous
    · exact isClosed_eq
        (continuous_finset_sum Finset.univ (fun j _ => (EuclideanSpace.proj j).continuous))
        continuous_const
  · rw [isBounded_iff_forall_norm_le]
    exact ⟨1, fun q hq => simplex_norm_le_one hq⟩

open Classical in
noncomputable def projSimplex {K : ℕ} (x : EuclideanSpace ℝ (Fin K)) :
    EuclideanSpace ℝ (Fin K) :=
  if h : ∃ q : EuclideanSpace ℝ (Fin K),
      q ∈ Simplex K ∧ IsMinOn (fun q' => ‖x - q'‖) (Simplex K) q then
    Classical.choose h
  else
    0

lemma projSimplex_mem_and_min {K : ℕ} (hK : 1 ≤ K) (x : EuclideanSpace ℝ (Fin K)) :
    projSimplex x ∈ Simplex K ∧
      IsMinOn (fun q' => ‖x - q'‖) (Simplex K) (projSimplex x) := by
  classical
  have hne : (Simplex K).Nonempty := ⟨uniformVec K, uniformVec_mem_simplex hK⟩
  have hcont : ContinuousOn (fun q' : EuclideanSpace ℝ (Fin K) => ‖x - q'‖) (Simplex K) :=
    (continuous_const.sub continuous_id).norm.continuousOn
  obtain ⟨q, hq_mem, hq_min⟩ := (simplex_isCompact K).exists_isMinOn hne hcont
  have hex : ∃ q : EuclideanSpace ℝ (Fin K),
      q ∈ Simplex K ∧ IsMinOn (fun q' => ‖x - q'‖) (Simplex K) q := ⟨q, hq_mem, hq_min⟩
  unfold projSimplex
  rw [dif_pos hex]
  exact Classical.choose_spec hex

lemma projSimplex_mem {K : ℕ} (hK : 1 ≤ K) (x : EuclideanSpace ℝ (Fin K)) :
    projSimplex x ∈ Simplex K :=
  (projSimplex_mem_and_min hK x).1

lemma projSimplex_variational {K : ℕ} (hK : 1 ≤ K) (x : EuclideanSpace ℝ (Fin K))
    {q : EuclideanSpace ℝ (Fin K)} (hq : q ∈ Simplex K) :
    inner ℝ (x - projSimplex x) (q - projSimplex x) ≤ 0 := by
  obtain ⟨hp₀, hmin⟩ := projSimplex_mem_and_min hK x
  set p₀ := projSimplex x
  set c := inner ℝ (x - p₀) (q - p₀)
  by_contra hc_neg
  push_neg at hc_neg
  let M := ‖q - p₀‖ ^ 2
  have hM_nn : 0 ≤ M := sq_nonneg _
  let t := min (1 : ℝ) (c / (M + 1))
  have ht_pos : 0 < t := lt_min zero_lt_one (div_pos hc_neg (by linarith))
  have ht_le1 : t ≤ 1 := min_le_left _ _
  have ht_le_div : t ≤ c / (M + 1) := min_le_right _ _
  have h_pt_mem : (1 - t) • p₀ + t • q ∈ Simplex K :=
    simplex_convex K hp₀ hq (by linarith) ht_pos.le (by linarith)
  have h_pt_eq : (1 - t) • p₀ + t • q = p₀ + t • (q - p₀) := by
    rw [sub_smul, one_smul, smul_sub]
    abel
  have hnorm_le : ‖x - p₀‖ ≤ ‖x - (p₀ + t • (q - p₀))‖ := by
    rw [← h_pt_eq]
    exact hmin h_pt_mem
  have hsq_le : ‖x - p₀‖ ^ 2 ≤ ‖x - (p₀ + t • (q - p₀))‖ ^ 2 :=
    pow_le_pow_left₀ (norm_nonneg _) hnorm_le 2
  have h_expand : ‖x - (p₀ + t • (q - p₀))‖ ^ 2 =
      ‖x - p₀‖ ^ 2 - 2 * t * c + t ^ 2 * M := by
    have hsub : x - (p₀ + t • (q - p₀)) = (x - p₀) - t • (q - p₀) := by abel
    rw [hsub, norm_sub_sq_real, inner_smul_right, norm_smul, Real.norm_eq_abs,
      mul_pow, sq_abs]
    dsimp [c, M]
    ring
  rw [h_expand] at hsq_le
  have h2tc : 2 * t * c ≤ t ^ 2 * M := by linarith
  have h2c : 2 * c ≤ t * M := by
    have hmul : t * (2 * c) ≤ t * (t * M) := by linarith
    exact le_of_mul_le_mul_left hmul ht_pos
  have htM : t * M < c := by
    calc t * M
        ≤ (c / (M + 1)) * M := mul_le_mul_of_nonneg_right ht_le_div hM_nn
      _ = c * (M / (M + 1)) := by ring
      _ < c * 1 := by
          refine mul_lt_mul_of_pos_left ?_ hc_neg
          rw [div_lt_one (by linarith)]
          linarith
      _ = c := mul_one c
  linarith

lemma projSimplex_lipschitz {K : ℕ} (hK : 1 ≤ K) :
    LipschitzWith 1 (@projSimplex K) := by
  rw [lipschitzWith_iff_norm_sub_le]
  intro x y
  set px := projSimplex x
  set py := projSimplex y
  have h1 : inner ℝ (x - px) (py - px) ≤ 0 :=
    projSimplex_variational hK x (projSimplex_mem hK y)
  have h2 : inner ℝ (y - py) (px - py) ≤ 0 :=
    projSimplex_variational hK y (projSimplex_mem hK x)
  have h_sum : inner ℝ ((x - y) - (px - py)) (px - py) ≥ 0 := by
    have hsplit : (x - y) - (px - py) = (x - px) - (y - py) := by abel
    have hneg : inner ℝ (x - px) (px - py) = -inner ℝ (x - px) (py - px) := by
      have hp : px - py = -(py - px) := by abel
      rw [hp, inner_neg_right]
    have h_alg : inner ℝ ((x - y) - (px - py)) (px - py) =
        -inner ℝ (x - px) (py - px) - inner ℝ (y - py) (px - py) := by
      rw [hsplit, inner_sub_left, hneg]
    linarith
  rw [inner_sub_left, real_inner_self_eq_norm_sq] at h_sum
  have h_sq : ‖px - py‖ ^ 2 ≤ ‖x - y‖ * ‖px - py‖ :=
    le_trans (by linarith) (real_inner_le_norm (x - y) (px - py))
  rcases eq_or_lt_of_le (norm_nonneg (px - py)) with hzero | hpos
  · change ‖px - py‖ ≤ (1 : NNReal) * ‖x - y‖
    rw [← hzero]
    positivity
  · have hle : ‖px - py‖ ≤ ‖x - y‖ :=
      le_of_mul_le_mul_right (by simpa [sq] using h_sq) hpos
    simpa using hle

end SimplexGeometry

section FitProperties

lemma integrable_of_measurable_bounded {Ω E : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ]
    [NormedAddCommGroup E] [MeasurableSpace E] [BorelSpace E] [SecondCountableTopology E]
    {g : Ω → E} (hg_meas : Measurable g) (C : ℝ) (hg_bound : ∀ ω, ‖g ω‖ ≤ C) :
    Integrable g μ :=
  (memLp_top_of_bound hg_meas.aestronglyMeasurable C
    (Filter.Eventually.of_forall hg_bound)).integrable le_top

lemma integrable_of_aestronglyMeasurable_bounded {Ω E : Type*} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] [NormedAddCommGroup E]
    {g : Ω → E} (hg_meas : AEStronglyMeasurable g μ) (C : ℝ) (hg_bound : ∀ ω, ‖g ω‖ ≤ C) :
    Integrable g μ :=
  (memLp_top_of_bound hg_meas C (Filter.Eventually.of_forall hg_bound)).integrable le_top

lemma oneHotLabel_measurable {Ω : Type*} [MeasurableSpace Ω] {K : ℕ}
    {Y : Ω → Fin K} (hY : Measurable Y) :
    Measurable (oneHotLabel Y) :=
  ( measurable_of_countable oneHotVec ).comp hY

lemma fitResidual_norm_le_two {Ω : Type*} {K : ℕ}
    {P : Ω → EuclideanSpace ℝ (Fin K)} (Y : Ω → Fin K)
    (hP : ∀ ω, P ω ∈ Simplex K) (ω : Ω) :
    ‖fitResidual P Y ω‖ ≤ 2 := by
  calc ‖P ω - oneHotLabel Y ω‖
      ≤ ‖P ω‖ + ‖oneHotLabel Y ω‖ := norm_sub_le _ _
    _ ≤ 1 + 1 := add_le_add (simplex_norm_le_one (hP ω))
        (simplex_norm_le_one (oneHotLabel_mem_simplex Y ω))
    _ = 2 := by norm_num

lemma lipschitzSimplexMaps_convex_comb {K : ℕ} {B : ℝ}
    {ρ ρ' : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hρ : ρ ∈ LipschitzSimplexMaps K B) (hρ' : ρ' ∈ LipschitzSimplexMaps K B)
    {t : ℝ} (ht0 : 0 ≤ t) (ht1 : t ≤ 1) :
    (fun s => (1 - t) • ρ s + t • ρ' s) ∈ LipschitzSimplexMaps K B := by
  refine ⟨hρ.1, ?_, fun s => simplex_convex K (hρ.2.2 s) (hρ'.2.2 s) (by linarith) ht0 (by linarith)⟩
  rw [lipschitzWith_iff_norm_sub_le]
  intro s₁ s₂
  have hsub : ((1 - t) • ρ s₁ + t • ρ' s₁) - ((1 - t) • ρ s₂ + t • ρ' s₂) =
      (1 - t) • (ρ s₁ - ρ s₂) + t • (ρ' s₁ - ρ' s₂) := by
    rw [smul_sub, smul_sub]
    abel
  rw [hsub]
  have h1 := hρ.2.1.norm_sub_le s₁ s₂
  have h2 := hρ'.2.1.norm_sub_le s₁ s₂
  calc ‖(1 - t) • (ρ s₁ - ρ s₂) + t • (ρ' s₁ - ρ' s₂)‖
      ≤ ‖(1 - t) • (ρ s₁ - ρ s₂)‖ + ‖t • (ρ' s₁ - ρ' s₂)‖ := norm_add_le _ _
    _ = (1 - t) * ‖ρ s₁ - ρ s₂‖ + t * ‖ρ' s₁ - ρ' s₂‖ := by
        rw [norm_smul, norm_smul, Real.norm_eq_abs, Real.norm_eq_abs,
          abs_of_nonneg (by linarith), abs_of_nonneg ht0]
    _ ≤ (1 - t) * (↑(Real.toNNReal B) * ‖s₁ - s₂‖) +
        t * (↑(Real.toNNReal B) * ‖s₁ - s₂‖) :=
        add_le_add (mul_le_mul_of_nonneg_left h1 (by linarith))
          (mul_le_mul_of_nonneg_left h2 ht0)
    _ = ↑(Real.toNNReal B) * ‖s₁ - s₂‖ := by ring

lemma fit_vi {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {K : ℕ} {B : ℝ} {S : Ω → ZeroSumSubspace K} {Y : Ω → Fin K}
    (hS_meas : Measurable S) (hY_meas : Measurable Y)
    {ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hProfile : IsLipschitzLSFitProfile μ B S Y ρ)
    {ρ' : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)}
    (hρ' : ρ' ∈ LipschitzSimplexMaps K B) :
    0 ≤ ∫ ω, inner ℝ (fitResidual (fun ω => ρ (S ω)) Y ω)
      (ρ' (S ω) - ρ (S ω)) ∂μ := by
  let P : Ω → EuclideanSpace ℝ (Fin K) := fun ω => ρ (S ω)
  let Q : Ω → EuclideanSpace ℝ (Fin K) := fun ω => ρ' (S ω)
  let eY : Ω → EuclideanSpace ℝ (Fin K) := oneHotLabel Y
  let ξ : Ω → EuclideanSpace ℝ (Fin K) := fitResidual P Y
  have hP_meas : Measurable P := hProfile.2.1.2.1.continuous.measurable.comp hS_meas
  have hQ_meas : Measurable Q := hρ'.2.1.continuous.measurable.comp hS_meas
  have hZ_meas : Measurable eY := oneHotLabel_measurable hY_meas
  have hr_meas : Measurable ξ := hP_meas.sub hZ_meas
  have hQP_meas : Measurable (fun ω => Q ω - P ω) := hQ_meas.sub hP_meas
  have hr_bound : ∀ ω, ‖ξ ω‖ ≤ 2 := fitResidual_norm_le_two Y (fun ω => hProfile.2.1.2.2 (S ω))
  have hQP_bound : ∀ ω, ‖Q ω - P ω‖ ≤ 2 := fun ω => by
    calc ‖Q ω - P ω‖ ≤ ‖Q ω‖ + ‖P ω‖ := norm_sub_le _ _
      _ ≤ 1 + 1 := add_le_add (simplex_norm_le_one (hρ'.2.2 (S ω)))
          (simplex_norm_le_one (hProfile.2.1.2.2 (S ω)))
      _ = 2 := by norm_num
  have hInt_r2 : Integrable (fun ω => ‖ξ ω‖ ^ 2) μ :=
    integrable_of_aestronglyMeasurable_bounded (hr_meas.norm.pow_const 2).aestronglyMeasurable 4
      (fun ω => by
        rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
        have h := hr_bound ω; have h0 := norm_nonneg (ξ ω); nlinarith)
  have hInt_inn : Integrable (fun ω => inner ℝ (ξ ω) (Q ω - P ω)) μ :=
    integrable_of_aestronglyMeasurable_bounded (hr_meas.inner hQP_meas).aestronglyMeasurable 4
      (fun ω => by
        rw [Real.norm_eq_abs]
        calc |inner ℝ (ξ ω) (Q ω - P ω)|
            ≤ ‖ξ ω‖ * ‖Q ω - P ω‖ := abs_real_inner_le_norm _ _
          _ ≤ 2 * 2 := mul_le_mul (hr_bound ω) (hQP_bound ω) (norm_nonneg _) (by norm_num)
          _ = 4 := by norm_num)
  have hInt_QP2 : Integrable (fun ω => ‖Q ω - P ω‖ ^ 2) μ :=
    integrable_of_aestronglyMeasurable_bounded (hQP_meas.norm.pow_const 2).aestronglyMeasurable 4
      (fun ω => by
        rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
        have h := hQP_bound ω; have h0 := norm_nonneg (Q ω - P ω); nlinarith)
  set I := ∫ ω, inner ℝ (ξ ω) (Q ω - P ω) ∂μ
  set M := ∫ ω, ‖Q ω - P ω‖ ^ 2 ∂μ
  have hM_nn : 0 ≤ M := integral_nonneg (fun ω => sq_nonneg _)
  by_contra hI_neg
  push_neg at hI_neg
  let t := min (1 : ℝ) ((-I) / (M + 1))
  have ht_pos : 0 < t := lt_min zero_lt_one (div_pos (by linarith) (by linarith))
  have ht_le1 : t ≤ 1 := min_le_left _ _
  have ht_le_div : t ≤ (-I) / (M + 1) := min_le_right _ _
  let ρ_t := fun s => (1 - t) • ρ s + t • ρ' s
  have hρ_t_mem : ρ_t ∈ LipschitzSimplexMaps K B :=
    lipschitzSimplexMaps_convex_comb hProfile.2.1 hρ' ht_pos.le ht_le1
  have h_risk_le : lsFitRisk μ S Y ρ ≤ lsFitRisk μ S Y ρ_t := hProfile.2.2 hρ_t_mem
  have h_ptwise : ∀ ω, ‖ρ_t (S ω) - oneHotLabel Y ω‖ ^ 2 =
      ‖ξ ω‖ ^ 2 + (2 * t) * inner ℝ (ξ ω) (Q ω - P ω) + t ^ 2 * ‖Q ω - P ω‖ ^ 2 := by
    intro ω
    have hvec : ρ_t (S ω) - oneHotLabel Y ω = ξ ω + t • (Q ω - P ω) := by
      dsimp [ρ_t, ξ, fitResidual, P, Q]
      rw [sub_smul, one_smul, smul_sub]
      abel
    rw [hvec, norm_add_sq_real, inner_smul_right, norm_smul, Real.norm_eq_abs,
      mul_pow, sq_abs]
    ring
  have h_int_eq : lsFitRisk μ S Y ρ_t =
      lsFitRisk μ S Y ρ + (2 * t) * I + t ^ 2 * M := by
    have hInt_sum1 : Integrable (fun ω => ‖ξ ω‖ ^ 2 + (2 * t) * inner ℝ (ξ ω) (Q ω - P ω)) μ :=
      hInt_r2.add (hInt_inn.const_mul (2 * t))
    unfold lsFitRisk
    simp only [h_ptwise]
    rw [integral_add hInt_sum1 (hInt_QP2.const_mul (t ^ 2)),
      integral_add hInt_r2 (hInt_inn.const_mul (2 * t)),
      integral_const_mul, integral_const_mul]
    rfl
  rw [h_int_eq] at h_risk_le
  have h2tI : 0 ≤ (2 * t) * I + t ^ 2 * M := by linarith
  have h2I : 0 ≤ 2 * I + t * M := by
    have hmul : t * 0 ≤ t * (2 * I + t * M) := by linarith
    exact le_of_mul_le_mul_left hmul ht_pos
  have htM : t * M ≤ -I := by
    calc t * M
        ≤ ((-I) / (M + 1)) * M := mul_le_mul_of_nonneg_right ht_le_div hM_nn
      _ = (-I) * (M / (M + 1)) := by ring
      _ ≤ (-I) * 1 := by
          refine mul_le_mul_of_nonneg_left ?_ (by linarith)
          rw [div_le_one (by linarith)]
          linarith
      _ = -I := mul_one _
  linarith

end FitProperties

end UL.Proof_lem_A_4

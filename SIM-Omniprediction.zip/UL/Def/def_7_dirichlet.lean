import Mathlib
set_option autoImplicit false

/-! Dirichlet feature condition. Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

/-- Predicate that `B` is the Moore–Penrose pseudoinverse of a real matrix `A`,
characterized by the four Moore–Penrose equations. -/
def IsMoorePenrosePseudoinverse {m n : Type*} [Fintype m] [Fintype n]
    (A : Matrix m n ℝ) (B : Matrix n m ℝ) : Prop :=
  A * B * A = A ∧
    B * A * B = B ∧
    (A * B).transpose = A * B ∧
    (B * A).transpose = B * A

/-- The Moore–Penrose pseudoinverse `A†` of a real matrix `A` (in particular, `0† = 0`). -/
noncomputable def moorePenrosePseudoinverse {m n : Type*} [Fintype m] [Fintype n]
    (A : Matrix m n ℝ) : Matrix n m ℝ :=
  open Classical in
  if h : ∃ B : Matrix n m ℝ, IsMoorePenrosePseudoinverse A B then Classical.choose h else 0

/-- The `N × d` dictionary matrix `X` whose `i`-th row is `(x i)ᵀ` for `x₁, …, x_N ∈ ℝ^d`. -/
def dictionaryRowMatrix {N d : ℕ} (x : Fin N → EuclideanSpace ℝ (Fin d)) :
    Matrix (Fin N) (Fin d) ℝ :=
  Matrix.of fun i j => x i j

/-- The `N × N` centering matrix `J_N = I_N - (1 / N) 1 1ᵀ`. -/
noncomputable def centeringMatrix (N : ℕ) : Matrix (Fin N) (Fin N) ℝ :=
  (1 : Matrix (Fin N) (Fin N) ℝ) -
    (1 / (N : ℝ)) • Matrix.vecMulVec (1 : Fin N → ℝ) (1 : Fin N → ℝ)

/-- The `N × N` centered Gram matrix `G = J_N X Xᵀ J_N` associated with dictionary `x`. -/
noncomputable def centeredGramMatrix {N d : ℕ} (x : Fin N → EuclideanSpace ℝ (Fin d)) :
    Matrix (Fin N) (Fin N) ℝ :=
  centeringMatrix N * dictionaryRowMatrix x * (dictionaryRowMatrix x).transpose * centeringMatrix N

/-- The Dirichlet feature condition on a finite dictionary `x₁, …, x_N ∈ ℝ^d` (`N ≥ 1`):
`rank G = N - 1` and `(G†)_{ij} ≤ 0` for all `i ≠ j`, where `G = J_N X Xᵀ J_N`. -/
def DirichletFeatureCondition {N d : ℕ} (x : Fin N → EuclideanSpace ℝ (Fin d)) : Prop :=
  1 ≤ N ∧
    ((centeredGramMatrix x).rank : ℤ) = (N : ℤ) - 1 ∧
    ∀ i j : Fin N, i ≠ j → moorePenrosePseudoinverse (centeredGramMatrix x) i j ≤ 0

end UL

import Mathlib
set_option autoImplicit false

/-! The class simplex and centered score space. -/

namespace UL

noncomputable def onesVec (K : ℕ) : EuclideanSpace ℝ (Fin K) :=
  (WithLp.equiv 2 (Fin K → ℝ)).symm (fun _ => 1)

noncomputable def uniformVec (K : ℕ) : EuclideanSpace ℝ (Fin K) :=
  ((1 : ℝ) / (K : ℝ)) • onesVec K

def Simplex (K : ℕ) : Set (EuclideanSpace ℝ (Fin K)) :=
  {q | (∀ j : Fin K, 0 ≤ q j) ∧ ∑ j : Fin K, q j = 1}

noncomputable def ZeroSumSubspace (K : ℕ) : Submodule ℝ (EuclideanSpace ℝ (Fin K)) :=
  LinearMap.ker (innerSL ℝ (onesVec K)).toLinearMap

def SimplexFace (K : ℕ) (J : Finset (Fin K)) : Set (EuclideanSpace ℝ (Fin K)) :=
  {q ∈ Simplex K | ∀ j : Fin K, j ∉ J → q j = 0}

def SimplexFaceRelint (K : ℕ) (J : Finset (Fin K)) : Set (EuclideanSpace ℝ (Fin K)) :=
  {q ∈ SimplexFace K J | ∀ j ∈ J, 0 < q j}

noncomputable def FaceTangentSpace (K : ℕ) (J : Finset (Fin K)) :
    Submodule ℝ (EuclideanSpace ℝ (Fin K)) :=
  ZeroSumSubspace K ⊓ ⨅ j ∉ J, LinearMap.ker (EuclideanSpace.proj j).toLinearMap

open Classical in
noncomputable def extendSimplex {K : ℕ} (Φ : Simplex K → ℝ) (q : EuclideanSpace ℝ (Fin K)) : ℝ :=
  if hq : q ∈ Simplex K then Φ ⟨q, hq⟩ else 0

def HasFaceGradAt {K : ℕ} (Φ : Simplex K → ℝ) (J : Finset (Fin K))
    (p g : EuclideanSpace ℝ (Fin K)) : Prop :=
  g ∈ FaceTangentSpace K J ∧
    HasFDerivWithinAt (extendSimplex Φ) (innerSL ℝ g) (SimplexFace K J) p

open Classical in
noncomputable def faceGrad {K : ℕ} (Φ : Simplex K → ℝ) (J : Finset (Fin K))
    (p : EuclideanSpace ℝ (Fin K)) : EuclideanSpace ℝ (Fin K) :=
  if h : ∃ g, HasFaceGradAt Φ J p g then Classical.choose h else 0

noncomputable def simplexGrad {K : ℕ} (Φ : Simplex K → ℝ)
    (p : EuclideanSpace ℝ (Fin K)) : EuclideanSpace ℝ (Fin K) :=
  faceGrad Φ Finset.univ p

def EntropyFamily (K : ℕ) (β : ℝ) : Set (Simplex K → ℝ) :=
  {Φ | 0 < β ∧
    Continuous Φ ∧
    (∀ J : Finset (Fin K), J.Nonempty →
      ∀ p ∈ SimplexFaceRelint K J, ∃ g, HasFaceGradAt Φ J p g) ∧
    ConvexOn ℝ (Simplex K)
      (fun q => extendSimplex Φ q - (1 / (2 * β)) * ‖q - uniformVec K‖ ^ 2)}

end UL

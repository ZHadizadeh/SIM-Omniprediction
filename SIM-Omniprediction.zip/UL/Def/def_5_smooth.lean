import Mathlib
import UL.Def.def_2_1
import UL.Def.def_2_matching
set_option autoImplicit false

/-! Smooth entropy family and finite canonical action. Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

def SimplexAffineHull (K : ℕ) : Set (EuclideanSpace ℝ (Fin K)) :=
  {q | ∑ j : Fin K, q j = 1}

def SmoothEntropyFamily (K : ℕ) (β lam M : ℝ) : Set (Simplex K → ℝ) :=
  {Φ | Φ ∈ EntropyFamily K β ∧
    0 < lam ∧
    0 < M ∧
    (∃ (U : Set (EuclideanSpace ℝ (Fin K)))
       (Φ_ext : EuclideanSpace ℝ (Fin K) → ℝ)
       (G : EuclideanSpace ℝ (Fin K) → EuclideanSpace ℝ (Fin K)),
      (∃ V : Set (EuclideanSpace ℝ (Fin K)), IsOpen V ∧ U = V ∩ SimplexAffineHull K) ∧
      Simplex K ⊆ U ∧
      (∀ q : Simplex K, Φ_ext q = Φ q) ∧
      ConvexOn ℝ U Φ_ext ∧
      (∀ q ∈ U, G q ∈ ZeroSumSubspace K ∧
        HasFDerivWithinAt Φ_ext (innerSL ℝ (G q)) U q) ∧
      ContinuousOn G U) ∧
    (∀ q ∈ Simplex K, ∀ q' ∈ Simplex K,
      ‖simplexGrad Φ q - simplexGrad Φ q'‖ ≤ lam * ‖q - q'‖) ∧
    (∀ q ∈ Simplex K, ‖simplexGrad Φ q‖ ≤ M)}

noncomputable def finiteCanonicalAction {K : ℕ} (Φ : Simplex K → ℝ)
    (q : EuclideanSpace ℝ (Fin K)) : EuclideanSpace ℝ (Fin K) :=
  simplexGrad Φ q

noncomputable def finiteCanonicalLoss {K : ℕ} (Φ : Simplex K → ℝ)
    (q : EuclideanSpace ℝ (Fin K)) (y : Fin K) : ℝ :=
  matchingLoss Φ (finiteCanonicalAction Φ q) y

noncomputable def hilbertSchmidtNorm {X Y : Type*}
    [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [NormedAddCommGroup Y] [InnerProductSpace ℝ Y] [FiniteDimensional ℝ Y]
    (W : X →L[ℝ] Y) : ℝ :=
  Real.sqrt (⨆ s : {s : Finset X // Orthonormal ℝ (Subtype.val : s → X)}, ∑ x ∈ s.1, ‖W x‖ ^ 2)

end UL

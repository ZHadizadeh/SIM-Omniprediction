import Mathlib
import UL.Def.def_2_1
set_option autoImplicit false

/-! Separate scalar probability link architecture.
Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

/-- A measurable scalar probability link `r : ℝ → [0, 1]`. -/
def IsScalarProbLink (r : ℝ → ℝ) : Prop :=
  Measurable r ∧ ∀ t : ℝ, r t ∈ Set.Icc (0 : ℝ) 1

/-- The vector-valued map on `ℝ^d` defined by `K - 1` linear score directions
`a_0, …, a_{K-2} ∈ ℝ^d` and scalar links `r_0, …, r_{K-2} : ℝ → ℝ` as in
eq. `\eqref{separate:architecture}`:
`p_j(x) = r_j(⟨a_j, x⟩)` for `j < K - 1`, and
`p_{K-1}(x) = 1 - ∑_{i < K - 1} r_i(⟨a_i, x⟩)` for the final coordinate. -/
noncomputable def separateLinkMap {K d : ℕ}
    (a : Fin (K - 1) → EuclideanSpace ℝ (Fin d))
    (r : Fin (K - 1) → ℝ → ℝ)
    (x : EuclideanSpace ℝ (Fin d)) : EuclideanSpace ℝ (Fin K) :=
  (WithLp.equiv 2 (Fin K → ℝ)).symm fun j =>
    if hj : j.val < K - 1 then
      r ⟨j.val, hj⟩ (inner ℝ (a ⟨j.val, hj⟩) x)
    else
      1 - ∑ i : Fin (K - 1), r i (inner ℝ (a i) x)

/-- A forecast `p : ℝ^d → ℝ^K` has the separate scalar probability-link architecture
with respect to feature law `μ` if `K ≥ 1` and there exist `K - 1` score vectors
`a_i ∈ ℝ^d` and measurable scalar links `r_i : ℝ → [0, 1]` such that
`p = separateLinkMap a r` and `p(x) ∈ Δ_K` holds `μ`-almost surely. -/
def HasSeparateLinkArchitecture {K d : ℕ}
    (μ : MeasureTheory.Measure (EuclideanSpace ℝ (Fin d)))
    (p : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin K)) : Prop :=
  1 ≤ K ∧ ∃ (a : Fin (K - 1) → EuclideanSpace ℝ (Fin d))
      (r : Fin (K - 1) → ℝ → ℝ),
    (∀ i : Fin (K - 1), IsScalarProbLink (r i)) ∧
    p = separateLinkMap a r ∧
    ∀ᵐ x ∂μ, p x ∈ Simplex K

/-- A forecast `p : ℝ^d → ℝ^K` has the nondecreasing separate scalar probability-link
architecture with respect to feature law `μ` if `K ≥ 1` and there exist `K - 1` score
vectors `a_i ∈ ℝ^d` and nondecreasing measurable scalar links `r_i : ℝ → [0, 1]` such
that `p = separateLinkMap a r` and `p(x) ∈ Δ_K` holds `μ`-almost surely. -/
def HasMonotoneSeparateLinkArchitecture {K d : ℕ}
    (μ : MeasureTheory.Measure (EuclideanSpace ℝ (Fin d)))
    (p : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin K)) : Prop :=
  1 ≤ K ∧ ∃ (a : Fin (K - 1) → EuclideanSpace ℝ (Fin d))
      (r : Fin (K - 1) → ℝ → ℝ),
    (∀ i : Fin (K - 1), IsScalarProbLink (r i) ∧ Monotone (r i)) ∧
    p = separateLinkMap a r ∧
    ∀ᵐ x ∂μ, p x ∈ Simplex K

/-- Almost-sure version of `HasSeparateLinkArchitecture`: `p` agrees `μ`-almost everywhere
with a forecast having the separate scalar probability-link architecture (e.g., when a
forecast is modified on a `μ`-null set so as to take values in `Δ_K` everywhere). -/
def HasSeparateLinkArchitectureAE {K d : ℕ}
    (μ : MeasureTheory.Measure (EuclideanSpace ℝ (Fin d)))
    (p : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin K)) : Prop :=
  ∃ q, HasSeparateLinkArchitecture μ q ∧ ∀ᵐ x ∂μ, p x = q x

/-- Almost-sure version of `HasMonotoneSeparateLinkArchitecture`: `p` agrees `μ`-almost
everywhere with a forecast having the nondecreasing separate scalar probability-link
architecture. -/
def HasMonotoneSeparateLinkArchitectureAE {K d : ℕ}
    (μ : MeasureTheory.Measure (EuclideanSpace ℝ (Fin d)))
    (p : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin K)) : Prop :=
  ∃ q, HasMonotoneSeparateLinkArchitecture μ q ∧ ∀ᵐ x ∂μ, p x = q x

end UL

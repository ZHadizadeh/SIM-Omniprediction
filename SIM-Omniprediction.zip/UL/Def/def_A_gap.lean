import Mathlib
import UL.Def.def_2_1
import UL.Def.def_A_fit
set_option autoImplicit false

/-! Simultaneous certificate gap.
Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

/-- A set `𝒲` of linear score maps (matrices) mapping `ℝ^d` to `H = 1^⊥ ⊂ ℝ^K` is a valid
comparator class if it is nonempty, compact, and convex. -/
def IsCompactConvexScoreSet {d K : ℕ}
    (𝒲 : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)) : Prop :=
  𝒲.Nonempty ∧ IsCompact 𝒲 ∧ Convex ℝ 𝒲

/-- Simultaneous certificate gap `sup_{V ∈ 𝒲} 𝔼⟨P - e_Y, (W - V) X⟩` for a prediction `P`
(such as a fitted prediction `P_W` at `W ∈ 𝒲`) and one-hot label `e_Y` under `μ`. -/
noncomputable def predictionCertificateGap {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) {d K : ℕ}
    (𝒲 : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K))
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin K)
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
    (P : Ω → EuclideanSpace ℝ (Fin K)) : ℝ :=
  sSup ((fun V => ∫ ω,
    inner ℝ (P ω - oneHotLabel Y ω) ((W - V) (X ω) : EuclideanSpace ℝ (Fin K)) ∂μ) '' 𝒲)

/-- Simultaneous certificate gap `Γ(W) = sup_{V ∈ 𝒲} 𝔼⟨P_W - e_Y, (W - V) X⟩` at `W ∈ 𝒲`,
where `P_W` is the `B`-Lipschitz least-squares fitted prediction at `W`. -/
noncomputable def certificateGap {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) {d K : ℕ} (B : ℝ)
    (𝒲 : Set (EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K))
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin K)
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K) : ℝ :=
  predictionCertificateGap μ 𝒲 X Y W (linearFittedPrediction μ B W X Y)

end UL

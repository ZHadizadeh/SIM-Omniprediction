import Mathlib
import UL.Def.def_2_1
set_option autoImplicit false

/-! Matching potential and extended canonical loss. Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

noncomputable def matchingPotential {K : ℕ} (Φ : Simplex K → ℝ)
    (a : EuclideanSpace ℝ (Fin K)) : ℝ :=
  ⨆ q : Simplex K, (inner ℝ ((q : EuclideanSpace ℝ (Fin K)) - uniformVec K) a - Φ q)

noncomputable def matchingLoss {K : ℕ} (Φ : Simplex K → ℝ)
    (a : EuclideanSpace ℝ (Fin K)) (y : Fin K) : ℝ :=
  matchingPotential Φ a - a y

open Classical in
noncomputable def posSupport {K : ℕ} (p : EuclideanSpace ℝ (Fin K)) : Finset (Fin K) :=
  Finset.univ.filter (fun j => 0 < p j)

noncomputable def extendedCanonicalLoss {K : ℕ} (Φ : Simplex K → ℝ)
    (p : EuclideanSpace ℝ (Fin K)) (y : Fin K) : EReal :=
  if y ∈ posSupport p then
    (((-extendSimplex Φ p +
      inner ℝ (faceGrad Φ (posSupport p) p) (p - EuclideanSpace.single y (1 : ℝ))) : ℝ) : EReal)
  else
    ⊤

end UL

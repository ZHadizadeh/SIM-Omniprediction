import Mathlib
set_option autoImplicit false

/-! Feature symmetry for the spherical lower bound, Proposition 1.5. -/

namespace UL

/-- Orthogonal matrices $Q \in \mathbb{R}^{d \times d}$ ($Q^\top Q = I_d$) acting as the identity on
the linear subspace $U \subseteq \mathbb{R}^d$ ($Q|_U = \mathrm{id}_U$). -/
def orthogonalFixing {d : ℕ}
    (U : Submodule ℝ (EuclideanSpace ℝ (Fin d))) :
    Set (Matrix (Fin d) (Fin d) ℝ) :=
  { Q | Q.transpose * Q = 1 ∧ ∀ x ∈ U, Matrix.toEuclideanLin Q x = x }

/-- Exact partial feature symmetry with respect to a linear subspace $U \subseteq \mathbb{R}^d$:
$Q_\# \mu = \mu$ (i.e., $QX \stackrel{d}{=} X$ for $X \sim \mu$) for every orthogonal $Q$ fixing $U$
pointwise. -/
def HasPartialFeatureSymmetry {d : ℕ}
    (U : Submodule ℝ (EuclideanSpace ℝ (Fin d)))
    (μ : MeasureTheory.Measure (EuclideanSpace ℝ (Fin d))) : Prop :=
  ∀ Q ∈ orthogonalFixing U, μ.map (Matrix.toEuclideanLin Q) = μ

/-- Full spherical feature symmetry ($U = \{0\}$): $Q_\# \mu = \mu$ for every orthogonal $Q$. -/
def HasSphericalFeatureSymmetry {d : ℕ}
    (μ : MeasureTheory.Measure (EuclideanSpace ℝ (Fin d))) : Prop :=
  HasPartialFeatureSymmetry ⊥ μ

end UL

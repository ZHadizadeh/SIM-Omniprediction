import Mathlib
import UL.Def.def_2_1
import UL.Def.def_2_matching
set_option autoImplicit false

/-! Linear scores, comparator budgets and omniprediction. -/

namespace UL

noncomputable def frobeniusNorm {d : ℕ} {E : Type*} [SeminormedAddCommGroup E] [Module ℝ E]
    (V : EuclideanSpace ℝ (Fin d) →ₗ[ℝ] E) : ℝ :=
  Real.sqrt (∑ i : Fin d, ‖V (EuclideanSpace.single i (1 : ℝ))‖ ^ 2)

def ComparatorBall (d K : ℕ) (R : ℝ) :
    Set (EuclideanSpace ℝ (Fin d) →ₗ[ℝ] ZeroSumSubspace K) :=
  {V | frobeniusNorm V ≤ R}

noncomputable def erealExpectation {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) (Z : Ω → EReal) : EReal :=
  (∫⁻ ω, (Z ω).toENNReal ∂μ).toEReal - (∫⁻ ω, (-Z ω).toENNReal ∂μ).toEReal

noncomputable def expectedCanonicalLoss {Ω : Type*} [MeasurableSpace Ω] {d K : ℕ}
    (μ : MeasureTheory.Measure Ω)
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin K)
    (Φ : Simplex K → ℝ) (p : EuclideanSpace ℝ (Fin d) → Simplex K) : EReal :=
  erealExpectation μ
    (fun ω => extendedCanonicalLoss Φ (p (X ω) : EuclideanSpace ℝ (Fin K)) (Y ω))

noncomputable def expectedMatchingLoss {Ω : Type*} [MeasurableSpace Ω] {d K : ℕ}
    (μ : MeasureTheory.Measure Ω)
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin K)
    (Φ : Simplex K → ℝ) (V : EuclideanSpace ℝ (Fin d) →ₗ[ℝ] ZeroSumSubspace K) : EReal :=
  erealExpectation μ
    (fun ω => (matchingLoss Φ (V (X ω) : EuclideanSpace ℝ (Fin K)) (Y ω) : EReal))

def ExactlyOmnipredicts {Ω : Type*} [MeasurableSpace Ω] {d K : ℕ}
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ]
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin K)
    (β R : ℝ) (p : EuclideanSpace ℝ (Fin d) → Simplex K) : Prop :=
  ∀ Φ ∈ EntropyFamily K β,
    expectedCanonicalLoss μ X Y Φ p ≤
      ⨅ V ∈ ComparatorBall d K R, expectedMatchingLoss μ X Y Φ V

def EpsOmnipredicts {Ω : Type*} [MeasurableSpace Ω] {d K : ℕ}
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ]
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin K)
    (β R ε : ℝ) (p : EuclideanSpace ℝ (Fin d) → Simplex K) : Prop :=
  ∀ Φ ∈ EntropyFamily K β,
    expectedCanonicalLoss μ X Y Φ p ≤
      (⨅ V ∈ ComparatorBall d K R, expectedMatchingLoss μ X Y Φ V) + (ε : EReal)

end UL

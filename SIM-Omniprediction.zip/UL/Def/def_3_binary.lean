import Mathlib
set_option autoImplicit false

/-! Scalar binary entropy and canonical loss. Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

open Classical in
noncomputable def extendUnitInterval (φ : Set.Icc (0 : ℝ) 1 → ℝ) (q : ℝ) : ℝ :=
  if hq : q ∈ Set.Icc (0 : ℝ) 1 then φ ⟨q, hq⟩ else 0

def BinaryEntropyFamily (β : ℝ) : Set (Set.Icc (0 : ℝ) 1 → ℝ) :=
  {φ | 0 < β ∧
    Continuous φ ∧
    (∀ q ∈ Set.Ioo (0 : ℝ) 1, DifferentiableAt ℝ (extendUnitInterval φ) q) ∧
    ConvexOn ℝ (Set.Icc (0 : ℝ) 1)
      (fun q => extendUnitInterval φ q - (1 / (2 * β)) * q ^ 2)}

noncomputable def binaryMatchingPotential (φ : Set.Icc (0 : ℝ) 1 → ℝ) (a : ℝ) : ℝ :=
  ⨆ q : Set.Icc (0 : ℝ) 1, ((q : ℝ) * a - φ q)

noncomputable def binaryMatchingLoss (φ : Set.Icc (0 : ℝ) 1 → ℝ) (a : ℝ) (y : Fin 2) : ℝ :=
  binaryMatchingPotential φ a - (y.val : ℝ) * a

open Classical in
noncomputable def binaryExtendedCanonicalLoss (φ : Set.Icc (0 : ℝ) 1 → ℝ)
    (p : ℝ) (y : Fin 2) : EReal :=
  if hp : p ∈ Set.Ioo (0 : ℝ) 1 then
    (((-φ ⟨p, Set.Ioo_subset_Icc_self hp⟩ +
      deriv (extendUnitInterval φ) p * (p - (y.val : ℝ))) : ℝ) : EReal)
  else if p = 0 ∧ y = 0 then
    ((-φ ⟨0, Set.left_mem_Icc.mpr zero_le_one⟩ : ℝ) : EReal)
  else if p = 1 ∧ y = 1 then
    ((-φ ⟨1, Set.right_mem_Icc.mpr zero_le_one⟩ : ℝ) : EReal)
  else
    ⊤

end UL

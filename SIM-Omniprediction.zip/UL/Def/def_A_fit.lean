import Mathlib
import UL.Def.def_2_1
set_option autoImplicit false

/-! Lipschitz least-squares fit.
Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

/-- The one-hot basis vector $e_y \in \Delta_K \subset \mathbb{R}^K$ for a label $y \in [K]$. -/
noncomputable def oneHotVec {K : ℕ} (y : Fin K) : EuclideanSpace ℝ (Fin K) :=
  EuclideanSpace.single y 1

/-- The uncentered one-hot label random vector $e_Y \in \Delta_K \subset \mathbb{R}^K$ for $Y : \Omega \to [K]$. -/
noncomputable def oneHotLabel {Ω : Type*} {K : ℕ} (Y : Ω → Fin K) (ω : Ω) :
    EuclideanSpace ℝ (Fin K) :=
  oneHotVec (Y ω)

/-- The linear score random vector $S = W X \in H$ for a linear map $W : \mathbb{R}^d \to H$
and feature vector $X : \Omega \to \mathbb{R}^d$, where $H = \mathbf{1}^\perp \subset \mathbb{R}^K$. -/
def linearScore {Ω : Type*} {d K : ℕ}
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
    (X : Ω → EuclideanSpace ℝ (Fin d)) (ω : Ω) : ZeroSumSubspace K :=
  W (X ω)

/-- The class of $B$-Lipschitz maps $\rho : H \to \Delta_K$ (with respect to the Euclidean norms
on $H = \mathbf{1}^\perp \subset \mathbb{R}^K$ and $\mathbb{R}^K$). -/
def LipschitzSimplexMaps (K : ℕ) (B : ℝ) :
    Set (ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)) :=
  {ρ | 0 ≤ B ∧ LipschitzWith (Real.toNNReal B) ρ ∧ ∀ s : ZeroSumSubspace K, ρ s ∈ Simplex K}

/-- The expected squared error $\mathbb{E}\|\rho(S) - e_Y\|^2$ for score $S : \Omega \to H$,
label $Y : \Omega \to [K]$, and map $\rho : H \to \mathbb{R}^K$ under $\mu$. -/
noncomputable def lsFitRisk {Ω : Type*} [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    {K : ℕ} (S : Ω → ZeroSumSubspace K) (Y : Ω → Fin K)
    (ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)) : ℝ :=
  ∫ ω, ‖ρ (S ω) - oneHotLabel Y ω‖ ^ 2 ∂μ

/-- A map $\rho : H \to \Delta_K$ is an optimal $B$-Lipschitz least-squares profile for score $S$
and label $Y$ under $\mu$ if $B > 0$, $\rho$ is $B$-Lipschitz into $\Delta_K$, and
$\rho$ minimizes $\mathbb{E}\|\rho(S) - e_Y\|^2$ over all $B$-Lipschitz maps $H \to \Delta_K$. -/
def IsLipschitzLSFitProfile {Ω : Type*} [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    {K : ℕ} (B : ℝ) (S : Ω → ZeroSumSubspace K) (Y : Ω → Fin K)
    (ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K)) : Prop :=
  0 < B ∧ ρ ∈ LipschitzSimplexMaps K B ∧
    IsMinOn (lsFitRisk μ S Y) (LipschitzSimplexMaps K B) ρ

/-- A random vector $P : \Omega \to \mathbb{R}^K$ is a $B$-Lipschitz least-squares fit at score
$S : \Omega \to H$ to $e_Y$ under $\mu$ if $P = \rho(S)$ for some optimal $B$-Lipschitz
profile $\rho : H \to \Delta_K$ minimizing $\mathbb{E}\|\rho(S) - e_Y\|^2$. -/
def IsLipschitzLSFit {Ω : Type*} [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    {K : ℕ} (B : ℝ) (S : Ω → ZeroSumSubspace K) (Y : Ω → Fin K)
    (P : Ω → EuclideanSpace ℝ (Fin K)) : Prop :=
  ∃ ρ : ZeroSumSubspace K → EuclideanSpace ℝ (Fin K),
    IsLipschitzLSFitProfile μ B S Y ρ ∧ P = fun ω => ρ (S ω)

/-- A random vector $P : \Omega \to \mathbb{R}^K$ is a $B$-Lipschitz least-squares fit at linear
map $W : \mathbb{R}^d \to H$ (with score $S = W X$) and feature-label pair $(X, Y)$ under $\mu$. -/
def IsLinearLipschitzLSFit {Ω : Type*} [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    {d K : ℕ} (B : ℝ) (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin K)
    (P : Ω → EuclideanSpace ℝ (Fin K)) : Prop :=
  IsLipschitzLSFit μ B (linearScore W X) Y P

/-- Selected $B$-Lipschitz least-squares fitted prediction $P = \rho(S)$ at score $S$
(or $0$ if no fit exists). -/
noncomputable def fittedPrediction {Ω : Type*} [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    {K : ℕ} (B : ℝ) (S : Ω → ZeroSumSubspace K) (Y : Ω → Fin K) :
    Ω → EuclideanSpace ℝ (Fin K) :=
  open Classical in
  if h : ∃ P, IsLipschitzLSFit μ B S Y P then Classical.choose h else 0

/-- Selected $B$-Lipschitz least-squares fitted prediction $P_W = \rho(W X)$ at linear map $W$
(or $0$ if no fit exists). -/
noncomputable def linearFittedPrediction {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) {d K : ℕ} (B : ℝ)
    (W : EuclideanSpace ℝ (Fin d) →L[ℝ] ZeroSumSubspace K)
    (X : Ω → EuclideanSpace ℝ (Fin d)) (Y : Ω → Fin K) :
    Ω → EuclideanSpace ℝ (Fin K) :=
  fittedPrediction μ B (linearScore W X) Y

/-- The least-squares fit residual $\xi = P - e_Y$ (lying in $H = \mathbf{1}^\perp$ whenever
$P$ takes values in $\Delta_K$). -/
noncomputable def fitResidual {Ω : Type*} {K : ℕ}
    (P : Ω → EuclideanSpace ℝ (Fin K)) (Y : Ω → Fin K) (ω : Ω) :
    EuclideanSpace ℝ (Fin K) :=
  P ω - oneHotLabel Y ω

end UL

import Mathlib
import UL.Def.def_2_1
import UL.Def.def_5_smooth
set_option autoImplicit false

/-! Bounded Lipschitz score-profile class. Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

/-- The bounded Lipschitz score-profile class `ℱ_{m, C, M₀}` (with `m = K - 1 = dim H` and
score-ball radius `A₀ = L * R`) on the feature-label domain `{x ∈ X : ‖x‖ ≤ L} × [K]` for a
separable real Hilbert space `X`, consisting of functions `f(x, y) = a_y(W x)` with `‖W‖_F ≤ R`
and each `a_y` being `C`-Lipschitz and `[-M₀, M₀]`-valued on `{s ∈ H : ‖s‖ ≤ A₀}`. -/
def ScoreProfileClass (X : Type*) [NormedAddCommGroup X] [InnerProductSpace ℝ X]
    [CompleteSpace X] [TopologicalSpace.SeparableSpace X]
    (K : ℕ) (L R C M₀ : ℝ) : Set (Metric.closedBall (0 : X) L × Fin K → ℝ) :=
  {f | 2 ≤ K ∧ 0 < L ∧ 0 < R ∧ 0 < C ∧ 0 < M₀ ∧
    ∃ (W : X →L[ℝ] ZeroSumSubspace K) (a : Fin K → ZeroSumSubspace K → ℝ),
      hilbertSchmidtNorm W ≤ R ∧
      (∀ y : Fin K,
        LipschitzOnWith (Real.toNNReal C) (a y)
          (Metric.closedBall (0 : ZeroSumSubspace K) (L * R)) ∧
        Set.MapsTo (a y)
          (Metric.closedBall (0 : ZeroSumSubspace K) (L * R)) (Set.Icc (-M₀) M₀)) ∧
      ∀ (x : Metric.closedBall (0 : X) L) (y : Fin K), f (x, y) = a y (W (x : X))}

end UL
